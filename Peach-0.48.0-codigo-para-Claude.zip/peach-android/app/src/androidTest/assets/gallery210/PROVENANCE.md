PNG sintético propio, 120 × 60, rojo/azul. Copia exacta de src/test/resources/media/small.png. No contiene imágenes de FANBOX ni de terceros.
