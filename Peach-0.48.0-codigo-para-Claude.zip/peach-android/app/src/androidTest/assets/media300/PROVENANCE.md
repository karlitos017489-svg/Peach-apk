# Own animation fixture

`own-animated.webp` is an 80×60 WebP with two solid color frames, red and blue,
200 ms each and an infinite loop. Generated locally with Pillow for these tests;
no source-site image, screenshot, creator, account or user media is included.
The identical file is used in test resources. Only the test APK includes this asset.

Recreate with Python/Pillow:

```python
from PIL import Image
a = Image.new('RGB', (80, 60), (220, 40, 40))
b = Image.new('RGB', (80, 60), (40, 40, 220))
a.save('own-animated.webp', save_all=True, append_images=[b], duration=200,
       loop=0, lossless=True)
```

The GIF comes from the existing own `media280` fixture, whose provenance remains
with that asset. These fixtures do not demonstrate a real provider's delivery.
