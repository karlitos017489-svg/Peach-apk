JSON sintético propio, sin cuerpos, imágenes o datos descargados de Pawchive.
