HTML sintético escrito para probar selectores del conector, con texto propio. No contiene cuerpos, imágenes ni datos descargados de SubscribeStar.
