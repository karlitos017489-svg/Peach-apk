package com.peach.local;

import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import androidx.lifecycle.Lifecycle;
import androidx.media3.session.*;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Needs a real Android runtime; compilation does not verify system media controls or screen lock. */
@RunWith(AndroidJUnit4.class)
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public class AudioIntegrationTest {
    private static long pausedPosition(android.app.Instrumentation instrumentation,MediaController controller)throws Exception {
        long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(10),previous=-1;int stable=0;long[] value={0};boolean[] paused={false};
        while(System.nanoTime()<deadline){instrumentation.runOnMainSync(()->{value[0]=controller.getCurrentPosition();paused[0]=!controller.isPlaying()&&!controller.getPlayWhenReady();});
            if(paused[0]&&value[0]>0&&value[0]==previous){if(++stable>=2)return value[0];}else stable=0;previous=value[0];Thread.sleep(100);
        }
        throw new AssertionError("A nonzero paused position did not settle: "+value[0]);
    }
    @Test public void servicePlaysOwnWavWhileScreenIsStoppedAndReconnectDoesNotRestartIt()throws Exception{
        var instrumentation=InstrumentationRegistry.getInstrumentation();var context=instrumentation.getTargetContext();var db=LibraryDatabase.get(context);String id="native-audio-180";
        MediaEntry row=new MediaEntry();row.id=id;row.name="tone20s.wav";row.title="Audio propio de prueba";row.mediaType=MediaRules.AUDIO;
        row.uri=DocumentsContract.buildDocumentUri(FixtureDocumentsProvider.AUTHORITY,"audio").toString();db.getOpenHelper().getWritableDatabase().execSQL("DELETE FROM media WHERE id=?",new Object[]{id});db.library().insertMedia(row);
        AtomicReference<ListenableFuture<MediaController>> future=new AtomicReference<>();MediaController[] controller={null};
        try(var screen=ActivityScenario.<AudioActivity>launch(new Intent(context,AudioActivity.class).putExtra("mediaId",id))){
            instrumentation.runOnMainSync(()->future.set(new MediaController.Builder(context,new SessionToken(context,new ComponentName(context,AudioService.class))).buildAsync()));controller[0]=future.get().get(30,TimeUnit.SECONDS);
            long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(30);boolean[] playing={false};while(System.nanoTime()<deadline){instrumentation.runOnMainSync(()->playing[0]=controller[0].isPlaying());if(playing[0])break;Thread.sleep(50);}assertTrue("Real WAV starts",playing[0]);
            screen.moveToState(Lifecycle.State.CREATED);Thread.sleep(1000);long[] position={0};instrumentation.runOnMainSync(()->{assertTrue(controller[0].isPlaying());position[0]=controller[0].getCurrentPosition();assertTrue(position[0]>0);controller[0].pause();});
            position[0]=pausedPosition(instrumentation,controller[0]);
            screen.moveToState(Lifecycle.State.RESUMED);screen.recreate();instrumentation.waitForIdleSync();instrumentation.runOnMainSync(()->{assertFalse("Paused audio restarted after reconnect",controller[0].isPlaying());assertTrue("Position before="+position[0]+" after="+controller[0].getCurrentPosition(),controller[0].getCurrentPosition()>=position[0]);assertNull("Player error after reconnect",controller[0].getPlayerError());});
            LibraryDatabase.IO.submit(()->{}).get(10,TimeUnit.SECONDS);assertEquals(1,db.library().get(id).playCount);
            AtomicReference<ListenableFuture<SessionResult>> stopped=new AtomicReference<>();instrumentation.runOnMainSync(()->stopped.set(controller[0].sendCustomCommand(AudioService.STOP,Bundle.EMPTY)));assertEquals(SessionResult.RESULT_SUCCESS,stopped.get().get(10,TimeUnit.SECONDS).resultCode);
        }finally{instrumentation.runOnMainSync(()->{if(controller[0]!=null)controller[0].release();});context.stopService(new Intent(context,AudioService.class));LibraryDatabase.IO.submit(()->{}).get(10,TimeUnit.SECONDS);db.getOpenHelper().getWritableDatabase().execSQL("DELETE FROM media WHERE id=?",new Object[]{id});}
    }
}
