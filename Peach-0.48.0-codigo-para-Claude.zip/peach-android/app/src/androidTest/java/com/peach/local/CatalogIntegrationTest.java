package com.peach.local;

import android.database.sqlite.SQLiteDatabase;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.File;
import java.nio.file.Files;
import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class CatalogIntegrationTest {
    @Test public void nativePatreonHtmlParserAndProviderNamespacesPersistWithoutNetwork()throws Exception {
        var context=InstrumentationRegistry.getInstrumentation().getTargetContext();String name="patreon-integration.db";context.deleteDatabase(name);LibraryDatabase db=androidx.room.Room.databaseBuilder(context,LibraryDatabase.class,name).allowMainThreadQueries().build();
        try {
            String html="<html><head><link rel='canonical' href='https://www.patreon.com/cw/artist'></head><body><div hidden id='S:0'><article><h3>Tarjeta pública</h3><p>Adelanto</p><a href='/artist/posts/example-1234'>Read</a></article></div><script>notExecuted()</script></body></html>";byte[] bytes=html.getBytes(java.nio.charset.StandardCharsets.UTF_8);SourceStore store=new SourceStore(db,(u,e,m,t)->new SourceHttp.Response(200,bytes,"",""));String fanbox=store.create("artist","Fanbox",null),patreon=store.create("patreon","artist","Patreon",null);assertNotEquals(fanbox,patreon);store.fetch(patreon,false,new SourceHttp.Token());store.apply(store.review(patreon));String publication=db.library().publications().get(0).id;db.close();db=androidx.room.Room.databaseBuilder(context,LibraryDatabase.class,name).allowMainThreadQueries().build();assertEquals("patreon",db.library().source(patreon).provider);assertEquals("fanbox",db.library().source(fanbox).provider);assertEquals("public-card",db.library().publicationContent(publication).type);assertTrue(db.library().publicationContent(publication).partial);assertFalse(db.library().publicationContent(publication).text.contains("notExecuted"));
        }finally{db.close();context.deleteDatabase(name);}
    }

    @Test public void nativeSourceCacheAndPublicContentPersistWithoutNetwork()throws Exception {
        var context=InstrumentationRegistry.getInstrumentation().getTargetContext();String name="source-integration.db";context.deleteDatabase(name);LibraryDatabase db=androidx.room.Room.databaseBuilder(context,LibraryDatabase.class,name).allowMainThreadQueries().build();
        try {
            org.json.JSONObject post=new org.json.JSONObject().put("id","1").put("creatorId","artist").put("title","Prueba pública").put("feeRequired",0).put("isRestricted",false).put("excerpt","Resumen");byte[] json=new org.json.JSONObject().put("body",new org.json.JSONObject().put("posts",new org.json.JSONArray().put(post))).toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);
            SourceStore store=new SourceStore(db,(u,e,m,t)->new SourceHttp.Response(200,json,"",""));String source=store.create("artist","Autor",null);store.fetch(source,false,new SourceHttp.Token());store.apply(store.review(source));String publication=db.library().publications().get(0).id;db.close();db=androidx.room.Room.databaseBuilder(context,LibraryDatabase.class,name).allowMainThreadQueries().build();assertEquals("artist",db.library().source(source).ref);assertEquals("Resumen",db.library().publicationContent(publication).text);new SourceStore(db,SourceHttp.direct()).remove(source);assertNull(db.library().publicationContent(publication).sourceId);assertNotNull(db.library().publication(publication));
        }finally{db.close();context.deleteDatabase(name);}
    }

    @Test public void nativePublicationAndTrackingPersistAndUndoKeepsMediaProgress()throws Exception {
        var context=InstrumentationRegistry.getInstrumentation().getTargetContext();String name="tracking-integration.db";context.deleteDatabase(name);LibraryDatabase db=androidx.room.Room.databaseBuilder(context,LibraryDatabase.class,name).allowMainThreadQueries().build();
        try {
            String p=new PublicationStore(db).create("Publicación de prueba","P","Autor","2026-10-01","exact","release",""),w=new WantStore(db).fromPublication(p);new WantStore(db).edit(w,"Obra","CAM-1","");MediaEntry m=new MediaEntry();m.id="synthetic";m.name="a.mp4";m.nfoDetails="{\"code\":\"CAM-1\"}";db.library().insertMedia(m);db.library().progress(m.id,7000,90000,1,false);String batch=new WantStore(db).acquire(new WantStore(db).review());db.close();
            db=androidx.room.Room.databaseBuilder(context,LibraryDatabase.class,name).allowMainThreadQueries().build();assertEquals("acquired",db.library().want(w).state);assertEquals(p,db.library().want(w).publicationId);assertEquals("release",db.library().publication(p).semantics);assertEquals(1,new WantStore(db).revert(batch));assertEquals("wanted",db.library().want(w).state);assertEquals(7000,db.library().get(m.id).position);
        }finally{db.close();context.deleteDatabase(name);}
    }

    @Test public void nativeAgencyMembershipPersistsAndDeletionKeepsMedia()throws Exception {
        var context=InstrumentationRegistry.getInstrumentation().getTargetContext();String name="agency-integration.db";context.deleteDatabase(name);LibraryDatabase db=androidx.room.Room.databaseBuilder(context,LibraryDatabase.class,name).allowMainThreadQueries().build();
        try {
            EntityStore entities=new EntityStore(db);String person=entities.create("performer","Persona de prueba",""),agency=entities.create("agency","Agencia de prueba","");MediaEntry m=new MediaEntry();m.id="synthetic";m.name="a.mp4";m.actors="Persona de prueba";db.library().insertMedia(m);new AgencyStore(db).assign(person,agency);db.close();
            db=androidx.room.Room.databaseBuilder(context,LibraryDatabase.class,name).allowMainThreadQueries().build();assertEquals(agency,db.library().membership(person).agencyId);assertEquals(1,EntityIndex.select(db.library(),db.library().allMedia(),agency).size());db.library().deleteEntity(agency);assertTrue(db.library().memberships().isEmpty());assertNotNull(db.library().get("synthetic"));
        }finally{db.close();context.deleteDatabase(name);}
    }
    @Test public void nativeRoomPersistsImportedMetadataIndependentlyOfPersonalState()throws Exception {
        var context=InstrumentationRegistry.getInstrumentation().getTargetContext();String name="catalog-metadata-integration.db";context.deleteDatabase(name);
        LibraryDatabase db=androidx.room.Room.databaseBuilder(context,LibraryDatabase.class,name).allowMainThreadQueries().build();
        try {
            MediaEntry m=new MediaEntry();m.id="synthetic";m.name="a.mp4";m.title="a";db.library().insertMedia(m);db.library().editMetadata(m.id,"Personal",null);db.library().restoreState(m.id,true,false,7000,90000,1,2);
            org.json.JSONObject tables=new org.json.JSONObject();for(String key:CatalogTransfer.COLUMNS.keySet())tables.put(key,new org.json.JSONArray());tables.getJSONArray("asset").put(new org.json.JSONObject().put("id",1).put("location","demo").put("path","R:/Media/a.mp4").put("catalog_title","Catálogo").put("code","CAM-1"));
            CatalogSnapshot snapshot=new CatalogSnapshot();snapshot.id=CatalogBridge.key("Demo","snapshot","");snapshot.label="Demo";snapshot.bindings="{\"1\":\"synthetic\"}";snapshot.payload=CatalogTransfer.validate(new org.json.JSONObject().put("format","peach-catalog-transfer").put("version",1).put("tables",tables)).encoded();
            LibraryDatabase initial=db;initial.runInTransaction(()->{initial.library().putSnapshot(snapshot);try{CatalogMetadata.sync(initial.getOpenHelper().getWritableDatabase(),snapshot);}catch(org.json.JSONException e){throw new IllegalArgumentException(e);}});db.close();
            db=androidx.room.Room.databaseBuilder(context,LibraryDatabase.class,name).allowMainThreadQueries().build();MediaEntry loaded=db.library().get("synthetic");assertEquals("CAM-1",loaded.details().get("code"));assertEquals("Personal",loaded.displayTitle());assertEquals(7000,loaded.position);assertTrue(loaded.favorite);
        }finally{db.close();context.deleteDatabase(name);}
    }
    @Test public void nativeSqliteProjectsStandaloneCatalogWithoutModifyingSource()throws Exception {
        var context=InstrumentationRegistry.getInstrumentation().getTargetContext();File file=File.createTempFile("ledger-android-",".db",context.getCacheDir());
        try {
            try(SQLiteDatabase db=SQLiteDatabase.openOrCreateDatabase(file,null)){db.disableWriteAheadLogging();try(var mode=db.rawQuery("PRAGMA journal_mode=DELETE",null)){assertTrue(mode.moveToFirst());assertEquals("delete",mode.getString(0));}db.execSQL("CREATE TABLE asset(id INTEGER PRIMARY KEY,location TEXT,path TEXT,name TEXT,size INTEGER)");db.execSQL("INSERT INTO asset VALUES(1,'disk','R:/Media/a.mp4','a.mp4',123)");}
            byte[] before=Files.readAllBytes(file.toPath());var transfer=CatalogTransfer.fromDatabase(file);assertEquals(1,transfer.json().getJSONObject("tables").getJSONArray("asset").length());assertArrayEquals(before,Files.readAllBytes(file.toPath()));
        }finally{SQLiteDatabase.deleteDatabase(file);}
    }
}
