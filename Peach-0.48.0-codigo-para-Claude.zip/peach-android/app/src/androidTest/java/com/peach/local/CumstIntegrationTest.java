package com.peach.local;
import androidx.room.Room;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.nio.charset.StandardCharsets;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;
@RunWith(AndroidJUnit4.class)
public class CumstIntegrationTest {
    @Test public void ownPublicContractRoundTripsWithoutFetchingMediaOrMergingPawchive()throws Exception{
        var context=InstrumentationRegistry.getInstrumentation().getTargetContext();var db=Room.inMemoryDatabaseBuilder(context,LibraryDatabase.class).build();
        try{
            JSONObject p=new JSONObject().put("id","own-1").put("service","patreon").put("creatorId","123").put("caption","Texto propio").put("published",1760000000L).put("attachments",new JSONArray());
            byte[] payload=new JSONObject().put("posts",new JSONArray().put(p)).toString().getBytes(StandardCharsets.UTF_8);int[] calls={0};
            var store=new SourceStore(db,(u,e,m,t)->{calls[0]++;assertEquals(CumstUrls.page("patreon/123",0),u);return new SourceHttp.Response(200,payload,"","");});
            String id=store.create("cumst","patreon/123","Fuente propia",null);store.create("pawchive","patreon/123","Otra fuente",null);assertEquals(0,calls[0]);store.fetch(id,false,new SourceHttp.Token());assertTrue(db.library().publications().isEmpty());store.apply(store.review(id));
            assertEquals("cumst",db.library().publications().get(0).provider);assertTrue(db.library().allMedia().isEmpty());ByteArrayOutputStream out=new ByteArrayOutputStream();BackupStore.write(db.library(),out);assertEquals(19,new JSONObject(out.toString("UTF-8")).getInt("version"));BackupStore.read(db,new ByteArrayInputStream(out.toByteArray()));assertEquals(2,db.library().sources().size());assertEquals(1,calls[0]);
        }finally{db.close();}
    }
}
