package com.peach.local;

import android.net.Uri;
import android.os.Bundle;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.util.*;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Disposable document from the existing TEST-ONLY provider. No upstream media/cloud accounts. */
@RunWith(AndroidJUnit4.class)
public class DirectTransfer460IntegrationTest {
    @Test public void androidOutputStreamReceivesOwnIncrementalBytesAndHash()throws Exception {
        var context=InstrumentationRegistry.getInstrumentation().getTargetContext();var resolver=context.getContentResolver();Uri uri=Uri.parse("content://com.peach.local.test.exchange/document/own-exchange");byte[] own=new byte[300000];new Random(460).nextBytes(own);String sha=GalleryCache.hex(GalleryCache.digest(own));
        try{var result=DirectTransfer.copy(new ByteArrayInputStream(own),own.length,sha,false,()->resolver.openOutputStream(uri,"w"),new SourceHttp.Token(),(n,total)->assertTrue(n<=total),SourceHttp.LARGE_DOWNLOAD_LIMIT);assertEquals(own.length,result.bytes());assertEquals(sha,result.sha256());try(InputStream in=resolver.openInputStream(uri)){ByteArrayOutputStream read=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1)read.write(buffer,0,n);assertArrayEquals(own,read.toByteArray());}}
        finally{Bundle extras=new Bundle();extras.putParcelable("uri",uri);resolver.call(uri,"android:deleteDocument",null,extras);}
    }
    @Test public void canceledOwnStreamDoesNotOpenOrWriteProvider()throws Exception {SourceHttp.Token token=new SourceHttp.Token();token.cancel();try{DirectTransfer.copy(new ByteArrayInputStream(new byte[]{1,2,3}),3,"",false,()->{throw new AssertionError("Provider must remain unopened");},token,(n,total)->{},10);fail();}catch(InterruptedIOException expected){}}
}
