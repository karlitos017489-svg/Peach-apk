package com.peach.local;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfDocument;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.File;
import java.io.FileOutputStream;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Requires a real Android runtime. Compilation alone does not execute these tests. */
@RunWith(AndroidJUnit4.class)
public class DocumentIntegrationTest {
    @Test public void frameworkPdfRendererRendersBothPagesOfAnOwnSyntheticDocument() throws Exception {
        File file=File.createTempFile("native-pdf-",".pdf",InstrumentationRegistry.getInstrumentation().getTargetContext().getCacheDir());
        try {
            PdfDocument document=new PdfDocument();try {
                for(int page=0;page<2;page++){var canvas=document.startPage(new PdfDocument.PageInfo.Builder(120,60,page+1).create());canvas.getCanvas().drawColor(page==0?Color.RED:Color.BLUE);document.finishPage(canvas);}
                try(var out=new FileOutputStream(file)){document.writeTo(out);}
            }finally{document.close();}
            try(PdfPages pages=new PdfPages(file)) {
                assertEquals(2,pages.count());Bitmap first=pages.render(0,120),second=pages.render(1,120);
                try{assertEquals(120,first.getWidth());assertEquals(60,first.getHeight());assertTrue(Color.red(first.getPixel(20,20))>200);assertTrue(Color.blue(second.getPixel(20,20))>200);}
                finally{first.recycle();second.recycle();}
            }
        }finally{file.delete();}
    }
    @Test public void frameworkPdfRendererRejectsNonPdfInput() throws Exception {
        File file=File.createTempFile("invalid-pdf-",".pdf",InstrumentationRegistry.getInstrumentation().getTargetContext().getCacheDir());
        try {
            try(var out=new FileOutputStream(file)){out.write("This is not a PDF".getBytes(java.nio.charset.StandardCharsets.UTF_8));}
            try(PdfPages pages=new PdfPages(file)){fail("Non-PDF input accepted");}catch(java.io.IOException expected){}
        }finally{file.delete();}
    }
    @Test public void nativeTarGzipBackendReadsSyntheticImageAndPdfWithoutFilesystemExtraction()throws Exception {
        File directory=java.nio.file.Files.createTempDirectory(InstrumentationRegistry.getInstrumentation().getTargetContext().getCacheDir().toPath(),"tar-native-").toFile();
        File pdf=new File(directory,"test.pdf"),archive=new File(directory,"test.tgz");
        try {
            PdfDocument document=new PdfDocument();try{var page=document.startPage(new PdfDocument.PageInfo.Builder(120,60,1).create());page.getCanvas().drawColor(Color.BLUE);document.finishPage(page);try(var output=new FileOutputStream(pdf)){document.writeTo(output);}}finally{document.close();}
            Bitmap image=Bitmap.createBitmap(20,20,Bitmap.Config.ARGB_8888);image.eraseColor(Color.RED);var png=new java.io.ByteArrayOutputStream();try{assertTrue(image.compress(Bitmap.CompressFormat.PNG,100,png));}finally{image.recycle();}
            try(var tar=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(new java.util.zip.GZIPOutputStream(new FileOutputStream(archive)))) {
                for(String name:java.util.List.of("images/2.png","docs/page.pdf")){byte[] data=name.endsWith("png")?png.toByteArray():java.nio.file.Files.readAllBytes(pdf.toPath());var entry=new org.apache.commons.compress.archivers.tar.TarArchiveEntry(name);entry.setSize(data.length);tar.putArchiveEntry(entry);tar.write(data);tar.closeArchiveEntry();}
            }
            try(var book=ArchiveBook.open(archive,"test.tgz",directory)){assertEquals(2,book.items().size());Bitmap decoded=ImageFiles.decode(book.read("images/2.png",directory),2048).bitmap();try{assertEquals(Color.RED,decoded.getPixel(5,5));}finally{decoded.recycle();}try(PdfPages pages=new PdfPages(book.read("docs/page.pdf",directory))){assertEquals(1,pages.count());Bitmap rendered=pages.render(0,120);try{assertTrue(Color.blue(rendered.getPixel(20,20))>200);}finally{rendered.recycle();}}}
            assertFalse(new File(directory,"images").exists());assertFalse(new File(directory,"docs").exists());
        }finally{File[] files=directory.listFiles();if(files!=null)for(File file:files)file.delete();directory.delete();}
    }

    @Test public void nativeSevenZipLzma2FixtureDecodesImageAndTextWithoutFilesystemExtraction()throws Exception {
        var instrumentation=InstrumentationRegistry.getInstrumentation();File directory=java.nio.file.Files.createTempDirectory(instrumentation.getTargetContext().getCacheDir().toPath(),"7z-native-").toFile();File source=new File(directory,"source");
        try{
            try(var input=instrumentation.getContext().getAssets().open("archives160/album-solid.7z");var output=new FileOutputStream(source)){byte[] bytes=new byte[8192];int n;while((n=input.read(bytes))!=-1)output.write(bytes,0,n);}
            try(var archive=new SevenZipBook(source)){Bitmap image=ImageFiles.decode(archive.read("images/2.png",directory),2048).bitmap();try{assertEquals(Color.RED,image.getPixel(10,10));}finally{image.recycle();}assertTrue(new String(java.nio.file.Files.readAllBytes(archive.read("notes.txt",directory).toPath()),java.nio.charset.StandardCharsets.UTF_8).contains("estratos"));assertEquals("",archive.item("link.txt").kind());assertFalse(new File(directory,"images").exists());}
        }finally{File[] files=directory.listFiles();if(files!=null)for(File file:files)file.delete();directory.delete();}
    }

    @Test public void nativeEpubXmlSpineTextAndImageFixtureUseLocalDecoders()throws Exception {
        var instrumentation=InstrumentationRegistry.getInstrumentation();File directory=java.nio.file.Files.createTempDirectory(instrumentation.getTargetContext().getCacheDir().toPath(),"epub-native-").toFile();File source=new File(directory,"source");
        try{
            try(var input=instrumentation.getContext().getAssets().open("epub170/book3.epub");var output=new FileOutputStream(source)){byte[] bytes=new byte[8192];int n;while((n=input.read(bytes))!=-1)output.write(bytes,0,n);}
            try(var book=new EpubBook(source,directory)){assertEquals("EPUB/text/10.xhtml",book.chapters().get(0));assertEquals(2,book.chapters().size());String text=EpubBook.preview(book.read(book.chapters().get(0),directory)).text();assertTrue(text.contains("sedimentarias"));assertFalse(text.contains("NO_SCRIPT"));Bitmap image=ImageFiles.decode(book.read("EPUB/images/portada color.png",directory),2048).bitmap();try{assertEquals(Color.RED,image.getPixel(10,10));}finally{image.recycle();}assertFalse(new File(directory,"EPUB").exists());}
        }finally{File[] files=directory.listFiles();if(files!=null)for(File file:files)file.delete();directory.delete();}
    }

}
