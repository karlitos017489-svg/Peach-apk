package com.peach.local;
import android.graphics.drawable.AnimatedImageDrawable;
import android.net.Uri;
import android.provider.DocumentsContract;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;
@RunWith(AndroidJUnit4.class)
public class Download280IntegrationTest {
    @Test @androidx.test.filters.SdkSuppress(minSdkVersion=28)
    public void actualGifDrawableStartsAndStopsFromGrantedFixtureDocument()throws Exception{
        var context=InstrumentationRegistry.getInstrumentation().getTargetContext();Uri uri=DocumentsContract.buildDocumentUri(FixtureDocumentsProvider.AUTHORITY,"gif280");var drawable=AnimatedImages.decode(context.getContentResolver(),uri);assertTrue(drawable instanceof AnimatedImageDrawable);assertEquals(64,drawable.getIntrinsicWidth());
        InstrumentationRegistry.getInstrumentation().runOnMainSync(()->{AnimatedImages.start(drawable);assertTrue(((AnimatedImageDrawable)drawable).isRunning());AnimatedImages.stop(drawable);assertFalse(((AnimatedImageDrawable)drawable).isRunning());});
    }
    @Test public void preparedOwnVideoIsCopiedToActualTestDocumentAndReopenedByteForByte()throws Exception{
        var instrumentation=InstrumentationRegistry.getInstrumentation();var app=(android.app.Application)instrumentation.getTargetContext().getApplicationContext();byte[] own;try(var in=instrumentation.getContext().getAssets().open("sample.mp4")){ByteArrayOutputStream bytes=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)bytes.write(b,0,n);own=bytes.toByteArray();}
        var previous=SourcesActivity.attachmentFetcher;SourcesActivity.Draft draft=new SourcesActivity.Draft(app);
        SourcesActivity.attachmentFetcher=(u,f,t)->SourceHttp.copyAttachment(u,new ByteArrayInputStream(own),f,own.length,t,SourceHttp.LARGE_DOWNLOAD_LIMIT);
        try{draft.prepare("https://downloads.fanbox.cc/own.bin","own.bin","video");assertTrue(draft.preparedName.endsWith(".mp4"));Uri uri=DocumentsContract.buildDocumentUri(FixtureDocumentsProvider.AUTHORITY,"download280");draft.savePrepared(uri);try(var in=app.getContentResolver().openInputStream(uri)){assertNotNull(in);ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);assertArrayEquals(own,out.toByteArray());}assertEquals(uri.toString(),draft.lastVideoUri);assertNull(draft.prepared);}finally{draft.onCleared();SourcesActivity.attachmentFetcher=previous;}
    }
}
