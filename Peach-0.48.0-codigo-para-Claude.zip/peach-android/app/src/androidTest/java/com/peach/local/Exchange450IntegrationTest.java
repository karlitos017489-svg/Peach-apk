package com.peach.local;
import android.content.*;
import android.net.Uri;
import android.os.Bundle;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Own in-memory databases and a disposable provider document. Not user libraries or cloud accounts. */
@RunWith(AndroidJUnit4.class)
public class Exchange450IntegrationTest {
    static final class Device implements AutoCloseable {
        final LibraryDatabase db;final ExchangeStore store;final Context context;final File directory;final String root,id;
        Device(Context app,String label)throws Exception {
            directory=Files.createTempDirectory(app.getCacheDir().toPath(),"own-exchange450-").toFile();context=new ContextWrapper(app){@Override public Context getApplicationContext(){return this;}@Override public File getNoBackupFilesDir(){return directory;}};db=androidx.room.Room.inMemoryDatabaseBuilder(context,LibraryDatabase.class).build();store=new ExchangeStore(context,db);
            root="content://own.exchange450/tree/"+label;LibraryRoot r=new LibraryRoot();r.uri=root;r.label=label;r.state=0;db.library().addRoot(r);MediaEntry m=new MediaEntry();id=m.id="content://own.exchange450/document/"+label;m.uri=id;m.root=root;m.name="own.txt";m.title="Own text";m.mediaType=MediaRules.OTHER;m.folder=label;m.bytes=50;db.library().insertMedia(m);
        }
        public void close(){db.close();try(var paths=Files.walk(directory.toPath())){paths.sorted(Comparator.reverseOrder()).forEach(p->p.toFile().delete());}catch(Exception ignored){}}
    }
    @Test public void androidRoomPortableMappingApplyAndUndoRestoreOnlyOwnState()throws Exception {
        Context app=InstrumentationRegistry.getInstrumentation().getTargetContext();try(Device a=new Device(app,"A");Device b=new Device(app,"B")){a.db.library().toggleFavorite(a.id);var packet=PortableState.export(PortableState.capture(a.db),UUID.randomUUID().toString(),"Own A");assertFalse(packet.encoded.contains("content://"));PortableState.validate(app,packet);String before=PortableState.capture(b.db).stamp();String remote=packet.data.getJSONArray("roots").getJSONObject(0).getString("id");var review=b.store.review(packet,Map.of(remote,b.root),Map.of());Map<String,Boolean> selected=new HashMap<>();for(var c:review.fields.changes)selected.put(c.key(),true);b.store.apply(review,selected);assertTrue(b.db.library().get(b.id).favorite);b.store.undo();assertEquals(before,PortableState.capture(b.db).stamp());}
    }
    @Test public void actualAndroidContentResolverSavesAndReadsOwnExchangeDocument()throws Exception {
        var instrumentation=InstrumentationRegistry.getInstrumentation();Context app=instrumentation.getTargetContext();try(Device a=new Device(app,"C")){var packet=PortableState.export(PortableState.capture(a.db),UUID.randomUUID().toString(),"Own JSON");Uri uri=Uri.parse("content://com.peach.local.test.exchange/document/own-exchange");ExchangeDocuments.writeNew(app,uri,packet);try(var in=app.getContentResolver().openInputStream(uri)){assertEquals(packet.encoded,new PortableState.Packet(ExchangeJson.read(in)).encoded);}finally{Bundle extras=new Bundle();extras.putParcelable("uri",uri);app.getContentResolver().call(uri,"android:deleteDocument",null,extras);}}
    }
    @Test public void androidJsonAndDetachedValidatorsAcceptOwnSampleAndRejectDigestChanges()throws Exception {
        var instrumentation=InstrumentationRegistry.getInstrumentation();try(var in=instrumentation.getContext().getAssets().open("exchange450/Peach-ejemplo-intercambio.json")){var packet=new PortableState.Packet(ExchangeJson.read(in));PortableState.validate(instrumentation.getTargetContext(),packet);var changed=new org.json.JSONObject(packet.encoded);changed.getJSONObject("data").getJSONObject("state").getJSONArray("items").getJSONObject(0).put("favorite",false);try{new PortableState.Packet(changed);fail();}catch(IOException expected){}}
    }
}
