package com.peach.local;
import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.os.*;
import java.io.*;

/** Own disposable JSON only. Registered exclusively in the Android test APK. */
public final class ExchangeDocFixtureProvider extends ContentProvider {
    static final String AUTH="com.peach.local.test.exchange";
    public boolean onCreate(){return true;}
    private File file(Uri u)throws FileNotFoundException{if(!u.getPath().equals("/document/own-exchange"))throw new FileNotFoundException();return new File(getContext().getCacheDir(),"own-exchange450.json");}
    public ParcelFileDescriptor openFile(Uri u,String mode)throws FileNotFoundException{return ParcelFileDescriptor.open(file(u),ParcelFileDescriptor.parseMode(mode));}
    public Cursor query(Uri u,String[] p,String s,String[] a,String order){return null;}
    public String getType(Uri u){return "application/json";}
    public Uri insert(Uri u,ContentValues v){throw new UnsupportedOperationException();}
    public int update(Uri u,ContentValues v,String s,String[] a){return 0;}
    public int delete(Uri u,String s,String[] a){return 0;}
    @Override public Bundle call(String method,String arg,Bundle extras){if(method.equals("peach:prepare-fixtures")){for(String authority:new String[]{FixtureDocumentsProvider.AUTHORITY,OrganizeFixtureProvider.AUTH})getContext().grantUriPermission("com.peach.local",Uri.parse("content://"+authority+"/"),Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);Bundle ready=new Bundle();ready.putBoolean("ready",true);return ready;}if(method.equals("android:deleteDocument")){try{file(extras.getParcelable("uri")).delete();}catch(Exception ignored){}return new Bundle();}return super.call(method,arg,extras);}
}
