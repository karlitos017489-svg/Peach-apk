package com.peach.local;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Isolated Room and exclusive test Keystore alias; never user sessions or upstream requests. */
@RunWith(AndroidJUnit4.class)
public class F95Session370IntegrationTest {
    @Test public void ownSessionResolvesReviewedMetadataAndBackup18ExcludesIt()throws Exception{
        var app=InstrumentationRegistry.getInstrumentation().getTargetContext();var db=androidx.room.Room.inMemoryDatabaseBuilder(app,LibraryDatabase.class).allowMainThreadQueries().build();try{String masked="https://f95zone.to/masked/OwnNative/",target="https://gofile.io/d/Own123";Publication p=new Publication();p.id="own-f95-370";p.provider="f95zone";p.sourceRef="123";p.externalId="1";p.url="https://f95zone.to/threads/123/post-1";p.title="Own native title";PublicationContent c=new PublicationContent();c.publicationId=p.id;c.text="Own "+masked;db.library().insertPublication(p);db.library().putPublicationContent(c);F95Session own=new F95Session("xf_session=OWN_NATIVE_SESSION_370");var access=new F95MaskedReview.Access(){public F95Session read(){return own;}public long waitUntil(){return 0;}public void waitUntil(long end){throw new AssertionError();}};JSONObject response=new JSONObject().put("status","ok").put("msg",target);int[] calls={0};var review=F95MaskedReview.query(db,p.id,masked,access,(u,post,session,e,m,t)->{calls[0]++;assertEquals(masked,u);assertTrue(post);assertEquals(own,session);return new SourceHttp.Response(200,response.toString().getBytes(StandardCharsets.UTF_8),"","");},new SourceHttp.Token());assertEquals("[]",db.library().publicationContent(p.id).attachments);assertEquals(1,F95MaskedReview.apply(db,review,access,new SourceHttp.Token()));assertEquals(List.of("Own123"),GofileUrls.folders(db.library().publicationContent(p.id)));ByteArrayOutputStream out=new ByteArrayOutputStream();BackupStore.write(db.library(),out);String copy=out.toString("UTF-8");assertEquals(19,new JSONObject(copy).getInt("version"));assertFalse(copy.contains(own.value()));db.library().deletePublication(p.id);BackupStore.read(db,new ByteArrayInputStream(out.toByteArray()));assertEquals(List.of(masked),F95MaskedReview.links(db.library().publicationContent(p.id)));assertEquals(1,calls[0]);assertEquals(0,db.library().usageCount());assertTrue(db.library().allMedia().isEmpty());}finally{db.close();}
    }
    @Test public void exclusiveTestAliasStoresSessionAndClearPreservesWait()throws Exception{
        var app=InstrumentationRegistry.getInstrumentation().getTargetContext();File dir=new File(app.getNoBackupFilesDir(),"own-f95-370-"+UUID.randomUUID());assertTrue(dir.mkdir());String alias="OwnF95Session370-"+UUID.randomUUID();var secrets=new F95Secrets(new File(dir,"session.bin"),new File(dir,"wait.txt"),()->SourceSecrets.key(alias));try{var own=new F95Session("xf_session=OWN_NATIVE_SESSION_370");secrets.write(own);assertEquals(own,secrets.read());long end=System.currentTimeMillis()+10000;secrets.waitUntil(end);secrets.clear();assertNull(secrets.read());assertTrue(secrets.waitUntil()>=end);}finally{secrets.clear();for(File f:Objects.requireNonNull(dir.listFiles()))f.delete();dir.delete();var store=java.security.KeyStore.getInstance("AndroidKeyStore");store.load(null);store.deleteEntry(alias);}
    }
}
