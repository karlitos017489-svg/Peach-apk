package com.peach.local;

import android.database.Cursor;
import android.database.MatrixCursor;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.provider.DocumentsProvider;
import java.io.File;
import java.io.FileNotFoundException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/** Synthetic, non-private fixture. Exists only in the separate test APK. */
public final class FixtureDocumentsProvider extends DocumentsProvider {
    public static final String AUTHORITY="com.peach.local.test.documents";
    public static final int VIDEOS=1105;
    private File video,nfo,sub,audio,gif,downloaded;
    private static final String[] DOCUMENT_COLUMNS={"document_id","_display_name","mime_type","_size","last_modified","flags"};
    @Override public boolean onCreate() {
        try {
            video=new File(getContext().getCacheDir(),"sample.mp4");
            try (var in=getContext().getAssets().open("sample.mp4");var out=Files.newOutputStream(video.toPath())) {
                byte[] b=new byte[8192];int n;while ((n=in.read(b))!=-1) out.write(b,0,n);
            }
            nfo=new File(getContext().getCacheDir(),"sample.nfo");
            Files.write(nfo.toPath(),"<movie><title>Video de prueba local</title><year>2026</year><tag>Prueba</tag></movie>".getBytes(StandardCharsets.UTF_8));
            sub=new File(getContext().getCacheDir(),"sample.es.srt");
            Files.write(sub.toPath(),"1\n00:00:00,000 --> 00:00:15,000\nSubtítulo local de prueba\n".getBytes(StandardCharsets.UTF_8));
            audio=new File(getContext().getCacheDir(),"tone20s.wav");
            try(var in=getContext().getAssets().open("audio180/tone20s.wav");var out=Files.newOutputStream(audio.toPath())){byte[] bytes=new byte[8192];int n;while((n=in.read(bytes))!=-1)out.write(bytes,0,n);}
            gif=new File(getContext().getCacheDir(),"own-animated.gif");
            try(var in=getContext().getAssets().open("media280/own-animated.gif");var out=Files.newOutputStream(gif.toPath())){byte[] bytes=new byte[8192];int n;while((n=in.read(bytes))!=-1)out.write(bytes,0,n);}
            downloaded=new File(getContext().getCacheDir(),"own-prepared280.mp4");
            return true;
        } catch (Exception e) { return false; }
    }
    @Override public Cursor queryRoots(String[] projection) {
        MatrixCursor c=new MatrixCursor(projection==null?new String[]{"root_id","document_id","title","flags","mime_types"}:projection);
        MatrixCursor.RowBuilder row=c.newRow();row.add("root_id","fixture");row.add("document_id","root");
        row.add("title","Peach Test Media");row.add("flags",DocumentsContract.Root.FLAG_SUPPORTS_IS_CHILD|DocumentsContract.Root.FLAG_LOCAL_ONLY);
        row.add("mime_types","video/*");return c;
    }
    private void add(MatrixCursor cursor,String id,String name,String mime,long size) {
        MatrixCursor.RowBuilder row=cursor.newRow();row.add("document_id",id);row.add("_display_name",name);
        row.add("mime_type",mime);row.add("_size",size);row.add("last_modified",1L);row.add("flags",0);
    }
    @Override public Cursor queryDocument(String id,String[] projection) {
        MatrixCursor c=new MatrixCursor(projection==null?DOCUMENT_COLUMNS:projection);
        if ("root".equals(id)) add(c,id,"Peach Test Media",DocumentsContract.Document.MIME_TYPE_DIR,0);
        else if (id.equals("nfo")) add(c,id,"sample.nfo","text/plain",nfo.length());
        else if (id.equals("sub")) add(c,id,"sample.es.srt","application/x-subrip",sub.length());
        else if (id.equals("gif280")) add(c,id,"own-animated.gif","image/gif",gif.length());
        else if (id.equals("download280")) add(c,id,"own-prepared280.mp4","video/mp4",downloaded.length());
        else if (id.equals("audio")) add(c,id,"tone20s.wav","audio/wav",audio.length());
        else add(c,id,id.equals("v0")?"sample.mp4":id+".mp4","video/mp4",video.length());
        return c;
    }
    @Override public Cursor queryChildDocuments(String parent,String[] projection,String sort) {
        MatrixCursor c=new MatrixCursor(projection==null?DOCUMENT_COLUMNS:projection);
        for (int i=0;i<VIDEOS;i++) add(c,"v"+i,i==0?"sample.mp4":"video-"+i+".mp4","video/mp4",video.length());
        add(c,"nfo","sample.nfo","text/plain",nfo.length());add(c,"sub","sample.es.srt","application/x-subrip",sub.length());return c;
    }
    @Override public boolean isChildDocument(String parent,String child) { return parent.equals("root") && !child.equals("root"); }
    @Override public ParcelFileDescriptor openDocument(String id,String mode,CancellationSignal signal) throws FileNotFoundException {
        if(id.equals("download280"))return ParcelFileDescriptor.open(downloaded,ParcelFileDescriptor.parseMode(mode));
        if (!"r".equals(mode)) throw new FileNotFoundException("Read only");
        return ParcelFileDescriptor.open(id.equals("gif280")?gif:id.equals("nfo")?nfo:id.equals("sub")?sub:id.equals("audio")?audio:video,ParcelFileDescriptor.MODE_READ_ONLY);
    }
}
