package com.peach.local;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.nio.file.*;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Compiling these tests is not Android execution. Only own fixtures/cache are used. */
@RunWith(AndroidJUnit4.class)
public class Formats440IntegrationTest {
    File sample(File dir,String name)throws Exception{File f=new File(dir,name);try(var in=InstrumentationRegistry.getInstrumentation().getContext().getAssets().open("formats440/"+name)){Files.copy(in,f.toPath(),StandardCopyOption.REPLACE_EXISTING);}return f;}
    File directory()throws Exception{return Files.createTempDirectory(InstrumentationRegistry.getInstrumentation().getTargetContext().getCacheDir().toPath(),"own-formats440-").toFile();}
    void clear(File dir){for(File f:dir.listFiles())f.delete();dir.delete();}
    @Test public void nativePdfRendererRendersSearchesAndAcceptsOnlyCorrectOwnPasswordOnAndroid15()throws Exception {
        Assume.assumeTrue(android.os.Build.VERSION.SDK_INT>=35);File dir=directory();try{File plain=sample(dir,"muestra.pdf"),encrypted=sample(dir,"muestra-protegida.pdf");try(var pdf=new PdfPages(plain)){assertEquals(3,pdf.count());var b=pdf.render(1,1024);assertTrue(b.getWidth()>0);b.recycle();assertTrue(pdf.search(1,"minerales")>0);}
            try(var pdf=new PdfPages(encrypted,"wrong".toCharArray())){fail();}catch(SecurityException expected){}
            try(var pdf=new PdfPages(encrypted,"test-only".toCharArray())){assertEquals(3,pdf.count());assertTrue(pdf.search(0,"minerales")>0);}
        }finally{clear(dir);}
    }
    @Test public void androidZip64And7zPasswordReadOwnTextWithoutExtractingWholeArchive()throws Exception {
        File dir=directory();try{try(var zip=new ZipBook(sample(dir,"muestra-zip64.cbz"))){assertTrue(new String(Files.readAllBytes(zip.read("notas.txt",dir).toPath()),java.nio.charset.StandardCharsets.UTF_8).contains("ZIP64"));}
            try(var seven=new SevenZipBook(sample(dir,"muestra-clave.7z"),"test-only".toCharArray())){assertTrue(new String(Files.readAllBytes(seven.read("notas.txt",dir).toPath()),java.nio.charset.StandardCharsets.UTF_8).contains("estratos"));}
        }finally{clear(dir);}
    }
    @Test public void androidEpubNavPreservesThreeNamedDestinationsAndLocalFragment()throws Exception {
        File dir=directory();try(var book=new EpubBook(sample(dir,"muestra-epub3.epub"),dir)){assertEquals(3,book.contents().size());var target=book.contents().get(1);assertTrue(EpubBook.chapter(book.read(target.path(),dir),target.fragment()).anchor()>1000);}finally{clear(dir);}
    }
    @Test public void isolatedAndroidRar64MiBDictionaryReadsOwnSelectedEntry()throws Exception {
        File dir=directory();try{var app=InstrumentationRegistry.getInstrumentation().getTargetContext();try(var book=new RarBook(sample(dir,"rar5-solid-dict64.cbr"),new RarClient(app))){File selected=book.read("01/notas-ñ.txt",dir);assertTrue(new String(Files.readAllBytes(selected.toPath()),java.nio.charset.StandardCharsets.UTF_8).startsWith("Peach: estratos sedimentarios"));}}finally{clear(dir);}
    }
}
