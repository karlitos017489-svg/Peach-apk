package com.peach.local;

import android.graphics.drawable.AnimatedImageDrawable;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Own media only, no upstream URLs opened. Must execute on Android to validate the device. */
@RunWith(AndroidJUnit4.class)
public class Gallery300IntegrationTest {
    static byte[] asset(String path)throws Exception{try(var in=InstrumentationRegistry.getInstrumentation().getContext().getAssets().open(path);var bytes=new ByteArrayOutputStream()){byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1)bytes.write(buffer,0,n);return bytes.toByteArray();}}
    static void clean(File base)throws Exception{try(var paths=Files.walk(base.toPath())){paths.sorted(Comparator.reverseOrder()).forEach(p->p.toFile().delete());}}
    @Test public void sixImportedProvidersUseOwnImageAndVerifiedOfflineCache()throws Exception{
        byte[] bytes=asset("gallery210/own.png");String hash=GalleryCache.hex(GalleryCache.digest(bytes));
        String[][] samples={{"fanbox","https://downloads.fanbox.cc/own.png"},{"pawchive","https://file.pawchive.pw/data/"+hash.substring(0,2)+"/"+hash.substring(2,4)+"/"+hash+".png"},{"cumst","https://e1.cum.st/media/own/image/original.png"},{"rule34paheal","https://r34i.paheal-cdn.net/aa/bb/aabb"+"0".repeat(28)},{"rule34xxx","https://api-cdn.rule34.xxx/images/1/"+"a".repeat(32)+".png"},{"f95zone","https://attachments.f95zone.to/own.png"}};
        File base=Files.createTempDirectory(InstrumentationRegistry.getInstrumentation().getTargetContext().getCacheDir().toPath(),"native-gallery300-").toFile();
        try{GalleryCache cache=new GalleryCache(base);int[] calls={0};for(String[] row:samples){
            Publication p=new Publication();p.id="own-"+row[0];p.provider=row[0];p.title="Own image";PublicationContent c=new PublicationContent();c.publicationId=p.id;
            c.attachments=new JSONArray().put(new JSONObject().put("kind","image").put("name","own.png").put("url",row[1]).put("downloadable",!row[0].equals("pawchive"))).toString();
            var image=SourceGallery.select(p,c).images().get(0);var frame=cache.acquire(image,false,new SourceHttp.Token(),(u,f,t)->{calls[0]++;Files.write(f.toPath(),bytes);return new SourceHttp.Download(bytes.length,GalleryCache.checksum(f));});assertEquals(120,frame.image().originalWidth());frame.release();
            frame=cache.acquire(image,true,new SourceHttp.Token(),(u,f,t)->{fail("Offline fetched");return null;});assertTrue(frame.cached());assertEquals(60,frame.image().originalHeight());frame.release();
        }assertEquals(6,calls[0]);}finally{clean(base);}
    }
    @Test @androidx.test.filters.SdkSuppress(minSdkVersion=28)
    public void gifAndWebpAnimateFromOfflineVerifiedPrivateCache()throws Exception{
        File base=Files.createTempDirectory(InstrumentationRegistry.getInstrumentation().getTargetContext().getCacheDir().toPath(),"native-animation300-").toFile();
        try{GalleryCache cache=new GalleryCache(base);for(String fixture:List.of("media280/own-animated.gif","media300/own-animated.webp")){
            byte[] bytes=asset(fixture);var image=new SourceGallery.Image("Own.bin","https://downloads.fanbox.cc/"+fixture);
            cache.acquire(image,false,new SourceHttp.Token(),(u,f,t)->{Files.write(f.toPath(),bytes);return new SourceHttp.Download(bytes.length,GalleryCache.checksum(f));}).release();
            var frame=cache.acquire(image,true,new SourceHttp.Token(),(u,f,t)->{fail("Offline fetched");return null;});assertTrue(frame.cached());assertTrue(frame.animation() instanceof AnimatedImageDrawable);
            InstrumentationRegistry.getInstrumentation().runOnMainSync(()->{var animated=(AnimatedImageDrawable)frame.animation();AnimatedImages.start(animated);assertTrue(animated.isRunning());frame.release();assertFalse(animated.isRunning());});
        }}finally{clean(base);}
    }
}
