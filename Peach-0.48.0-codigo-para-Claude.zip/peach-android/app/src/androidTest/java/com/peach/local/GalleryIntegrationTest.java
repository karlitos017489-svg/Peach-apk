package com.peach.local;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.nio.file.Files;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;
/** Requires an Android runtime. Compilation alone does not establish native decoding or HTTPS behavior. */
@RunWith(AndroidJUnit4.class)
public class GalleryIntegrationTest {
    @Test public void nativeBitmapCacheDecodesOwnPngAndOfflineNeverFetches()throws Exception{
        var instrumentation=InstrumentationRegistry.getInstrumentation();var context=instrumentation.getTargetContext();File base=Files.createTempDirectory(context.getCacheDir().toPath(),"native-gallery-").toFile();GalleryCache cache=new GalleryCache(base);int[] calls={0};
        try{var image=new SourceGallery.Image("propia.png","https://downloads.fanbox.cc/own.png");var first=cache.acquire(image,false,new SourceHttp.Token(),(u,f,t)->{calls[0]++;try(var in=instrumentation.getContext().getAssets().open("gallery210/own.png")){Files.copy(in,f.toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING);}return new SourceHttp.Download(f.length(),GalleryCache.checksum(f));});assertEquals(120,first.image().originalWidth());assertEquals(60,first.image().originalHeight());int color=first.image().bitmap().getPixel(10,10);first.image().bitmap().recycle();var second=cache.acquire(image,true,new SourceHttp.Token(),(u,f,t)->{fail("Offline must never fetch");return null;});assertTrue(second.cached());assertEquals(color,second.image().bitmap().getPixel(10,10));assertEquals(1,calls[0]);second.image().bitmap().recycle();}
        finally{try(var paths=Files.walk(base.toPath())){paths.sorted(java.util.Comparator.reverseOrder()).forEach(p->p.toFile().delete());}}
    }
}
