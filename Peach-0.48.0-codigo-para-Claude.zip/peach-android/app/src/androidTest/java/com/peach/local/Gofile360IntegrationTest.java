package com.peach.local;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Isolated Room/Keystore fixtures only; no user account, publication or remote request. */
@RunWith(AndroidJUnit4.class)
public class Gofile360IntegrationTest {
    @Test public void metadataReviewAddsAttachmentAndBackup18RoundTripsWithoutMediaDownload()throws Exception{
        var app=InstrumentationRegistry.getInstrumentation().getTargetContext();var db=androidx.room.Room.inMemoryDatabaseBuilder(app,LibraryDatabase.class).allowMainThreadQueries().build();try{Publication p=new Publication();p.id="own-gofile-360";p.provider="fanbox";p.sourceRef="own";p.externalId="1";p.title="Own title";PublicationContent c=new PublicationContent();c.publicationId=p.id;c.text="Own https://gofile.io/d/Own123";db.library().insertPublication(p);db.library().putPublicationContent(c);String key="OWN_GOFILE_TEST_TOKEN";var access=new GofileReview.Access(){public String token(){return key;}public long waitUntil(){return 0;}public void waitUntil(long end){throw new AssertionError();}};String id="11111111-2222-3333-4444-555555555555",url="https://store-1.gofile.io/download/web/"+id+"/Own.mp4";JSONObject json=new JSONObject().put("status","ok").put("data",new JSONObject().put("type","folder").put("children",new JSONObject().put(id,new JSONObject().put("id",id).put("type","file").put("mimetype","video/mp4").put("name","Own.mp4").put("link",url))));int[] calls={0};var review=GofileReview.query(db,p.id,new GofileReview.Target("Own123","Own123","Own"),1,access,(f,n,k,t)->{calls[0]++;assertEquals(key,k);return new GofileHttp.Response(200,json.toString().getBytes(StandardCharsets.UTF_8),0);},new SourceHttp.Token());assertEquals("[]",db.library().publicationContent(p.id).attachments);GofileReview.apply(db,review,access,new SourceHttp.Token());assertEquals(1,SourceVideos.load(db,p.id).videos().size());ByteArrayOutputStream out=new ByteArrayOutputStream();BackupStore.write(db.library(),out);String encoded=out.toString("UTF-8");assertEquals(19,new JSONObject(encoded).getInt("version"));assertFalse(encoded.contains(key));db.library().deletePublication(p.id);BackupStore.read(db,new ByteArrayInputStream(out.toByteArray()));assertEquals(url,SourceVideos.load(db,p.id).videos().get(0).url());assertEquals(1,calls[0]);assertEquals(0,db.library().usageCount());assertTrue(db.library().allMedia().isEmpty());}finally{db.close();}
    }
    @Test public void ownKeystoreAliasEncryptsTokenAndClearingItKeepsWait()throws Exception{
        var app=InstrumentationRegistry.getInstrumentation().getTargetContext();File dir=new File(app.getNoBackupFilesDir(),"own-gofile-360-"+UUID.randomUUID());assertTrue(dir.mkdir());String alias="OwnGofile360-"+UUID.randomUUID();SourceSecrets vault=new SourceSecrets(new File(dir,"key.bin"),()->SourceSecrets.key(alias));var secrets=new GofileSecrets(vault,new File(dir,"wait.txt"));try{String own="OWN_GOFILE_TOKEN_360";secrets.write(own);assertEquals(own,secrets.token());long until=System.currentTimeMillis()+10000;secrets.waitUntil(until);secrets.clear();assertNull(secrets.token());assertTrue(secrets.waitUntil()>=until);assertEquals(app.getNoBackupFilesDir(),dir.getParentFile());}finally{vault.clear();for(File f:Objects.requireNonNull(dir.listFiles()))f.delete();dir.delete();var store=java.security.KeyStore.getInstance("AndroidKeyStore");store.load(null);store.deleteEntry(alias);}
    }
}
