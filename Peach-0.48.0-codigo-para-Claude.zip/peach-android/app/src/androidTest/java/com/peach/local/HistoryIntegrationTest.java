package com.peach.local;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import androidx.room.Room;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import org.json.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Requires Android execution. Compiling this case alone does not validate native migration. */
@RunWith(AndroidJUnit4.class)
public class HistoryIntegrationTest {
    static byte[] readFixture(java.io.InputStream in)throws java.io.IOException {java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){if(out.size()+n>2*1024*1024)throw new java.io.IOException("Own migration fixture exceeds limit");out.write(b,0,n);}return out.toByteArray();}
    @Test public void nativeMigrationAndHistoryBackupKeepExistingCountsAndProgress()throws Exception{
        var instrumentation=InstrumentationRegistry.getInstrumentation();var context=instrumentation.getTargetContext();String name="history-200-"+UUID.randomUUID()+".db";var path=context.getDatabasePath(name);path.getParentFile().mkdirs();LibraryDatabase db=null;
        try{
            JSONObject schema;try(var in=instrumentation.getContext().getAssets().open("migration200/room12.json")){schema=new JSONObject(new String(readFixture(in),StandardCharsets.UTF_8)).getJSONObject("database");}
            try(SQLiteDatabase old=SQLiteDatabase.openOrCreateDatabase(path,null)){
                JSONArray tables=schema.getJSONArray("entities");for(int i=0;i<tables.length();i++){JSONObject table=tables.getJSONObject(i);String key=table.getString("tableName");old.execSQL(table.getString("createSql").replace("${TABLE_NAME}",key));JSONArray indexes=table.optJSONArray("indices");if(indexes!=null)for(int j=0;j<indexes.length();j++)old.execSQL(indexes.getJSONObject(j).getString("createSql").replace("${TABLE_NAME}",key));
                    if(key.equals("media")){ContentValues values=new ContentValues();JSONArray fields=table.getJSONArray("fields");for(int j=0;j<fields.length();j++){JSONObject field=fields.getJSONObject(j);String column=field.getString("columnName");if(!field.optBoolean("notNull"))values.putNull(column);else if(field.getString("affinity").equals("TEXT"))values.put(column,"");else values.put(column,0);}values.put("id","old");values.put("name","own.mp4");values.put("title","Visita propia");values.put("mediaType","video");values.put("nfoDetails","{}");values.put("catalogMetadata","[]");values.put("position",5000);values.put("duration",10000);values.put("playCount",8);old.insertOrThrow(key,null,values);}}
                JSONArray setup=schema.getJSONArray("setupQueries");for(int i=0;i<setup.length();i++)old.execSQL(setup.getString(i));old.setVersion(12);
            }
            db=Room.databaseBuilder(context,LibraryDatabase.class,name).addMigrations(LibraryDatabase.MIGRATION_12_13).build();assertEquals(13,db.getOpenHelper().getReadableDatabase().getVersion());assertEquals(0,db.library().usageCount());assertEquals(8,db.library().get("old").playCount);
            UsageStore store=new UsageStore(db);String id=UUID.randomUUID().toString();store.begin(id,"old","video",100);store.checkpoint(id,6000,10000,"",0,0,"paused",false,200);ByteArrayOutputStream copy=new ByteArrayOutputStream();BackupStore.write(db.library(),copy);db.library().clearUsage();BackupStore.read(db,new ByteArrayInputStream(copy.toByteArray()));assertEquals(1,db.library().usageCount());assertEquals(6000,db.library().usage(id).position);assertEquals(5000,db.library().get("old").position);assertEquals(8,db.library().get("old").playCount);
        }finally{if(db!=null)db.close();context.deleteDatabase(name);}
    }
}
