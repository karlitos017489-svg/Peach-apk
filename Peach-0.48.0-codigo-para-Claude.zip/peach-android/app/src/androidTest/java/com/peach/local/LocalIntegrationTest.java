package com.peach.local;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.CancellationSignal;
import android.provider.DocumentsContract;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.room.Room;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.work.testing.TestWorkerBuilder;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public class LocalIntegrationTest {
    private Context context() { return InstrumentationRegistry.getInstrumentation().getTargetContext(); }
    private LibraryRoot root() {
        LibraryRoot r=new LibraryRoot();r.label="Pruebas";
        r.uri=DocumentsContract.buildTreeDocumentUri(FixtureDocumentsProvider.AUTHORITY,"root").toString();return r;
    }
    @Test public void scan1105DocumentsAndLocalSidecars() throws Exception {
        LibraryRoot r=root();Uri tree=Uri.parse(r.uri);
        ScanDirectory directory=new ScanDirectory(r.uri,DocumentsContract.buildDocumentUriUsingTree(tree,"root").toString(),r.label);
        long start=System.nanoTime();
        var batch=new DocumentScanner(context().getContentResolver()).scan(r,directory,new CancellationSignal());
        assertEquals(FixtureDocumentsProvider.VIDEOS,batch.media().size());assertEquals(0,batch.warnings());
        MediaEntry first=batch.media().get(0);
        assertEquals("Video de prueba local",first.title);assertEquals("Prueba",first.tags);
        assertTrue(first.subtitles.contains("sample.es.srt"));assertTrue(batch.media().get(1).subtitles.equals("[]"));
        System.out.println("PEACH_SCAN_1105_MS="+TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-start));
    }
    @Test public void workerPersistsCatalogAndRefreshPreservesUserState() throws Exception {
        LibraryDatabase db=LibraryDatabase.get(context());LibraryRoot r=root();
        db.runInTransaction(()-> {db.library().forgetMedia(r.uri);db.library().clearQueue(r.uri);db.library().forgetRoot(r.uri);
            db.library().addRoot(r);db.library().enqueue(new ScanDirectory(r.uri,
                DocumentsContract.buildDocumentUriUsingTree(Uri.parse(r.uri),"root").toString(),r.label));});
        var executor=Executors.newSingleThreadExecutor();
        try {
            ScanWorker worker=TestWorkerBuilder.from(context(),ScanWorker.class,executor).build();
            assertEquals(androidx.work.ListenableWorker.Result.success(),worker.doWork());
            assertEquals(FixtureDocumentsProvider.VIDEOS,db.library().allMedia().size());
            MediaEntry first=db.library().allMedia().stream().filter(m->m.name.equals("sample.mp4")).findFirst().orElseThrow();
            db.library().toggleFavorite(first.id); db.library().progress(first.id,7000,20000,1,false);
            db.library().nextGeneration(r.uri);db.library().clearQueue(r.uri);
            db.library().enqueue(new ScanDirectory(r.uri,DocumentsContract.buildDocumentUriUsingTree(Uri.parse(r.uri),"root").toString(),r.label));
            assertEquals(androidx.work.ListenableWorker.Result.success(),TestWorkerBuilder.from(context(),ScanWorker.class,executor).build().doWork());
            assertTrue(db.library().get(first.id).favorite);assertEquals(7000,db.library().get(first.id).position);
            assertEquals(0,db.library().roots().get(0).state);
        } finally { executor.shutdownNow(); }
    }
    @Test public void databaseReopenAndBackupRoundTrip() throws Exception {
        String name="persistence-test.db";context().deleteDatabase(name);
        LibraryDatabase db=Room.databaseBuilder(context(),LibraryDatabase.class,name).build();
        MediaEntry m=new MediaEntry();m.id="sample";m.title="Prueba";
        db.library().insertMedia(m);db.library().toggleFavorite(m.id);db.library().progress(m.id,8000,20000,2,false);db.close();
        db=Room.databaseBuilder(context(),LibraryDatabase.class,name).build();
        assertEquals(8000,db.library().get(m.id).position);assertTrue(db.library().get(m.id).favorite);
        ByteArrayOutputStream backup=new ByteArrayOutputStream();BackupStore.write(db.library(),backup);
        db.library().toggleFavorite(m.id);db.library().progress(m.id,0,20000,3,false);
        assertEquals(1,BackupStore.read(db,new ByteArrayInputStream(backup.toByteArray())));
        assertTrue(db.library().get(m.id).favorite);assertEquals(8000,db.library().get(m.id).position);
        db.close();context().deleteDatabase(name);
    }
    @Test public void media3DecodesH264AacAndExternalSrt() throws Exception {
        CountDownLatch ready=new CountDownLatch(1),advanced=new CountDownLatch(1);
        ExoPlayer[] player={null};
        String uri=DocumentsContract.buildDocumentUriUsingTree(Uri.parse(root().uri),"v0").toString();
        Uri sub=DocumentsContract.buildDocumentUriUsingTree(Uri.parse(root().uri),"sub");
        InstrumentationRegistry.getInstrumentation().runOnMainSync(()-> {
            player[0]=new ExoPlayer.Builder(context()).build();
            player[0].addListener(new Player.Listener(){
                @Override public void onPlaybackStateChanged(int state) { if (state==Player.STATE_READY) ready.countDown(); }
            });
            MediaItem.SubtitleConfiguration subtitle=new MediaItem.SubtitleConfiguration.Builder(sub)
                .setMimeType("application/x-subrip").setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build();
            player[0].setMediaItem(new MediaItem.Builder().setUri(uri).setSubtitleConfigurations(List.of(subtitle)).build());
            player[0].prepare();player[0].play();
        });
        try {
            assertTrue("Player ready",ready.await(90,TimeUnit.SECONDS));
            Thread.sleep(2500);
            InstrumentationRegistry.getInstrumentation().runOnMainSync(()-> {
                assertNull(player[0].getPlayerError()); assertNotNull(player[0].getVideoFormat());
                assertNotNull(player[0].getAudioFormat());
                assertTrue(player[0].getCurrentTracks().isTypeSupported(C.TRACK_TYPE_TEXT));
                assertTrue(player[0].getCurrentPosition()>0);player[0].pause();player[0].seekTo(7000);advanced.countDown();
            });
            assertTrue(advanced.await(10,TimeUnit.SECONDS));
        } finally { InstrumentationRegistry.getInstrumentation().runOnMainSync(()->player[0].release()); }
    }
    @Test public void appLaunchesAndRecreatesWithDeclaredOptionalNetworkAndPlaybackPermissions() {
        assertEquals(PackageManager.PERMISSION_GRANTED,context().checkSelfPermission("android.permission.INTERNET"));
        assertEquals(PackageManager.PERMISSION_GRANTED,context().checkSelfPermission("android.permission.WAKE_LOCK"));
        if(android.os.Build.VERSION.SDK_INT>=28)assertEquals(PackageManager.PERMISSION_GRANTED,context().checkSelfPermission("android.permission.FOREGROUND_SERVICE"));
        if(android.os.Build.VERSION.SDK_INT>=34)assertEquals(PackageManager.PERMISSION_GRANTED,context().checkSelfPermission("android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"));
        assertEquals(PackageManager.PERMISSION_DENIED,context().checkSelfPermission("android.permission.MANAGE_EXTERNAL_STORAGE"));
        try (ActivityScenario<MainActivity> activity=ActivityScenario.launch(MainActivity.class)) {
            activity.onActivity(a->assertNotNull(a.findViewById(R.id.addFolder)));activity.recreate();
            activity.onActivity(a->assertNotNull(a.findViewById(R.id.grid)));
        }
    }
    @Test public void cancellationDoesNotProduceAPartialBatch() throws Exception {
        CancellationSignal signal=new CancellationSignal();signal.cancel();
        try {
            new DocumentScanner(context().getContentResolver()).scan(root(),new ScanDirectory(root().uri,
                DocumentsContract.buildDocumentUriUsingTree(Uri.parse(root().uri),"root").toString(),"Test"),signal);
            fail("Expected cancellation");
        } catch (android.os.OperationCanceledException expected) { assertTrue(signal.isCanceled()); }
    }
}
