package com.peach.local;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.util.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class Organization420IntegrationTest {
 String root="content://"+OrganizeFixtureProvider.AUTH+"/tree/own",target="content://"+OrganizeFixtureProvider.AUTH+"/tree/target";
 /** Uses real ContentResolver/provider operations; persisted picker grants are separately tested on device. */
 FileOrganizer.Fs transport(FileOrganizer.Saf saf){return new FileOrganizer.Fs(){public FileOrganizer.Doc stat(String u)throws Exception{return saf.stat(u);}public List<FileOrganizer.Doc> children(String p)throws Exception{return saf.children(p);}public String rename(String u,String n)throws Exception{return saf.rename(u,n);}public String move(String u,String p,String t)throws Exception{return saf.move(u,p,t);}public String create(String p,String m,String n)throws Exception{return saf.create(p,m,n);}public InputStream read(String u)throws Exception{return saf.read(u);}public void write(String u,byte[] b)throws Exception{saf.write(u,b);}public void delete(String u)throws Exception{saf.delete(u);}public void permit(String r){}};}
 @Test public void realProviderRenameMoveAndUndoKeepOwnBytesAndDatabaseState()throws Exception{
  var app=InstrumentationRegistry.getInstrumentation().getTargetContext();var saf=new FileOrganizer.Saf(app);String label="own-"+UUID.randomUUID()+".mp4",uri=saf.create(FileOrganizer.treeDoc(root),"video/mp4",label);byte[] payload="Own geology fixture".getBytes(java.nio.charset.StandardCharsets.UTF_8);saf.write(uri,payload);
  var db=androidx.room.Room.inMemoryDatabaseBuilder(app,LibraryDatabase.class).allowMainThreadQueries().build();File journal=new File(app.getCacheDir(),"own-organization-"+UUID.randomUUID()+".json");
  try{LibraryRoot r=new LibraryRoot();r.uri=root;r.label="own";r.state=0;db.library().addRoot(r);MediaEntry m=new MediaEntry();m.id=FileOrganizer.key(uri);m.uri=uri;m.root=root;m.folder="own";m.name=label;m.title="Own";m.bytes=payload.length;m.favorite=true;m.position=42;db.library().insertMedia(m);db.library().enqueue(new ScanDirectory(root,FileOrganizer.treeDoc(root),"own"));var store=new FileOrganizer(transport(saf),db,journal);
   String rename=store.apply(store.plan(m.id,"rename","renamed-"+label,"")),move=store.apply(store.plan(m.id,"move","",target));assertEquals(42,db.library().get(m.id).position);assertTrue(db.library().get(m.id).favorite);assertEquals(FileOrganizer.hash(payload),store.digest(db.library().get(m.id).uri,payload.length));store.undo(move);store.undo(rename);uri=db.library().get(m.id).uri;assertEquals(label,db.library().get(m.id).name);assertEquals(root,db.library().get(m.id).root);
  }finally{try{saf.delete(uri);}catch(Exception ignored){}db.close();journal.delete();}
 }
 @Test public void metadataWriterUsesNativeXmlReaderAndPreservesUnknownNfoNodes()throws Exception{
  byte[] original="<movie><title>Old</title><custom>own metadata</custom></movie>".getBytes(java.nio.charset.StandardCharsets.UTF_8);MediaEntry m=new MediaEntry();m.title="Estratos & minerales";byte[] result=NfoWriter.merge(original,NfoWriter.encode(m));assertEquals(m.title,NfoReader.read(new ByteArrayInputStream(result)).title());assertTrue(new String(result,java.nio.charset.StandardCharsets.UTF_8).contains("own metadata"));
 }
}
