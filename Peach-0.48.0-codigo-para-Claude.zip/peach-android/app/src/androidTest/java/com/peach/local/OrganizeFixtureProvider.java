package com.peach.local;
import android.database.*;
import android.os.*;
import android.provider.*;
import android.provider.DocumentsContract.Document;
import android.provider.DocumentsContract.Root;
import java.io.*;

/** Test APK only: exposes only its own disposable cache fixture directory. */
public class OrganizeFixtureProvider extends DocumentsProvider {
 public static final String AUTH="com.peach.local.test.organize";
 @Override public boolean onCreate(){return true;}
 File base(){File b=new File(getContext().getCacheDir(),"organize420-fixture");b.mkdirs();new File(b,"target").mkdirs();return b;}
 File file(String id)throws FileNotFoundException{
  File b=base();if(id.equals("own"))return b;if(id.equals("target"))return new File(b,"target");
  String[] s=id.split("/",-1);if(s.length!=2||!s[1].matches("[A-Za-z0-9_.-]{1,160}")||s[1].equals(".")||s[1].equals("..")||!java.util.Set.of("own","target").contains(s[0]))throw new FileNotFoundException();return new File(s[0].equals("own")?b:new File(b,"target"),s[1]);
 }
 String name(String n)throws FileNotFoundException{if(!n.matches("[A-Za-z0-9_.-]{1,160}")||n.equals(".")||n.equals(".."))throw new FileNotFoundException();return n;}
 String parent(String id)throws FileNotFoundException{int at=id.indexOf('/');if(at<1)throw new FileNotFoundException();return id.substring(0,at);}
 String[] columns(String[] p){return p==null?new String[]{Document.COLUMN_DOCUMENT_ID,Document.COLUMN_DISPLAY_NAME,Document.COLUMN_MIME_TYPE,Document.COLUMN_SIZE,Document.COLUMN_LAST_MODIFIED,Document.COLUMN_FLAGS}:p;}
 void row(MatrixCursor c,String id)throws FileNotFoundException{File f=file(id);if(!f.exists())throw new FileNotFoundException();var row=c.newRow();for(String col:c.getColumnNames())row.add(col,switch(col){case Document.COLUMN_DOCUMENT_ID->id;case Document.COLUMN_DISPLAY_NAME->f.getName();case Document.COLUMN_MIME_TYPE->f.isDirectory()?Document.MIME_TYPE_DIR:"application/octet-stream";case Document.COLUMN_SIZE->f.length();case Document.COLUMN_LAST_MODIFIED->f.lastModified();case Document.COLUMN_FLAGS->f.isDirectory()?Document.FLAG_DIR_SUPPORTS_CREATE:Document.FLAG_SUPPORTS_RENAME|Document.FLAG_SUPPORTS_MOVE|Document.FLAG_SUPPORTS_WRITE|Document.FLAG_SUPPORTS_DELETE;default->null;});}
 @Override public Cursor queryRoots(String[] projection){return new MatrixCursor(projection==null?new String[]{Root.COLUMN_ROOT_ID,Root.COLUMN_DOCUMENT_ID}:projection);}
 @Override public Cursor queryDocument(String id,String[] projection)throws FileNotFoundException{MatrixCursor c=new MatrixCursor(columns(projection));row(c,id);return c;}
 @Override public Cursor queryChildDocuments(String id,String[] projection,String sort)throws FileNotFoundException{MatrixCursor c=new MatrixCursor(columns(projection));for(File f:file(id).listFiles())if(f.isFile())row(c,id+"/"+f.getName());return c;}
 @Override public ParcelFileDescriptor openDocument(String id,String mode,CancellationSignal signal)throws FileNotFoundException{File f=file(id);if(f.isDirectory())throw new FileNotFoundException();return ParcelFileDescriptor.open(f,ParcelFileDescriptor.parseMode(mode));}
 @Override public String createDocument(String parent,String mime,String display)throws FileNotFoundException{File f=new File(file(parent),name(display));try{if(f.exists()||!f.createNewFile())throw new IOException();}catch(IOException e){throw new FileNotFoundException();}return parent+"/"+display;}
 @Override public String renameDocument(String id,String display)throws FileNotFoundException{String p=parent(id);File source=file(id),dest=new File(file(p),name(display));if(dest.exists()||!source.renameTo(dest))throw new FileNotFoundException();return p+"/"+display;}
 @Override public String moveDocument(String id,String from,String to)throws FileNotFoundException{if(!parent(id).equals(from))throw new FileNotFoundException();File source=file(id),dest=new File(file(to),source.getName());if(dest.exists()||!source.renameTo(dest))throw new FileNotFoundException();return to+"/"+dest.getName();}
 @Override public void deleteDocument(String id)throws FileNotFoundException{File f=file(id);if(!f.isFile()||!f.delete())throw new FileNotFoundException();}
 @Override public boolean isChildDocument(String parent,String child){return child.startsWith(parent+"/");}
}
