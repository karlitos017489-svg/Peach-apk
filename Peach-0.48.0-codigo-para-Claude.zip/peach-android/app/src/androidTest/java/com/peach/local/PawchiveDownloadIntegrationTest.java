package com.peach.local;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.nio.file.Files;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;
/** Real stream/file/hash path with own bytes; requires device execution, no network proof. */
@RunWith(AndroidJUnit4.class)
public class PawchiveDownloadIntegrationTest {
    @Test public void ownBytesAreVerifiedAndMismatchingPayloadIsRemoved()throws Exception{String hash="ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",url="https://file.pawchive.pw/data/ba/78/"+hash+".txt";File f=File.createTempFile("native-paw-download-",".tmp",InstrumentationRegistry.getInstrumentation().getTargetContext().getCacheDir());try{var d=SourceHttp.copyAttachment(url,new ByteArrayInputStream("abc".getBytes()),f,3,new SourceHttp.Token());assertEquals(hash,d.sha256());assertArrayEquals("abc".getBytes(),Files.readAllBytes(f.toPath()));assertTrue(SourceHttp.canSave(url,false));try{SourceHttp.copyAttachment(url,new ByteArrayInputStream("abd".getBytes()),f,3,new SourceHttp.Token());fail();}catch(IOException expected){}assertFalse(f.exists());}finally{f.delete();}}
}
