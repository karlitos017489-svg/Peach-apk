package com.peach.local;
import androidx.room.Room;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;
@RunWith(AndroidJUnit4.class)
public class PawchiveIntegrationTest {
    @Test public void syntheticJsonParsesAndReviewedImportBacksUpWithoutMediaRequests()throws Exception{var i=InstrumentationRegistry.getInstrumentation();byte[] bytes;try(var in=i.getContext().getAssets().open("pawchive230/public.json")){var out=new java.io.ByteArrayOutputStream();byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);bytes=out.toByteArray();}var db=Room.inMemoryDatabaseBuilder(i.getTargetContext(),LibraryDatabase.class).build();try{int[] calls={0};var store=new SourceStore(db,(u,e,m,t)->{calls[0]++;return new SourceHttp.Response(200,bytes,"","");});String id=store.create("pawchive","patreon/123","Fuente propia",null);assertEquals(0,calls[0]);store.fetch(id,false,new SourceHttp.Token());assertTrue(db.library().publications().isEmpty());store.apply(store.review(id));assertEquals(1,db.library().publications().size());assertEquals("own-1",db.library().publications().get(0).externalId);assertTrue(db.library().allMedia().isEmpty());var out=new java.io.ByteArrayOutputStream();BackupStore.write(db.library(),out);assertEquals(19,new org.json.JSONObject(out.toString("UTF-8")).getInt("version"));BackupStore.read(db,new java.io.ByteArrayInputStream(out.toByteArray()));assertEquals(1,calls[0]);}finally{db.close();}}
}
