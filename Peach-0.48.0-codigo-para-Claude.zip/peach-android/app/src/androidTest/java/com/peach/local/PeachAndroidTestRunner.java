package com.peach.local;

/** Explicit fixture-only grants from the test APK owner before each instrumentation run. */
public final class PeachAndroidTestRunner extends androidx.test.runner.AndroidJUnitRunner {
    @Override public void onStart(){
        android.os.Bundle ready=getTargetContext().getContentResolver().call(android.net.Uri.parse("content://com.peach.local.test.exchange/document/own-exchange"),"peach:prepare-fixtures",null,null);
        if(ready==null||!ready.getBoolean("ready"))throw new IllegalStateException("No se pudieron preparar los proveedores de prueba propios.");
        super.onStart();
    }
}
