package com.peach.local;
import android.content.*;
import android.net.Uri;
import android.os.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.security.cert.Certificate;
import java.util.*;
import javax.net.ssl.HttpsURLConnection;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Isolated no-backup directories and in-memory Room, never the installed user's queue. */
@RunWith(AndroidJUnit4.class)
public class Queue320IntegrationTest {
    static final String URL="https://downloads.fanbox.cc/own-native-queue.mp4";
    static class Reply extends HttpsURLConnection {
        byte[] bytes;int status;long length;Map<String,String> headers=new HashMap<>();boolean closed;
        Reply(int status,byte[] bytes)throws Exception{super(new URL(URL));this.status=status;this.bytes=bytes;length=bytes.length;headers.put("ETag","\"own-v1\"");}
        public void connect(){}public void disconnect(){closed=true;}public boolean usingProxy(){return false;}public String getCipherSuite(){return "OWN_FIXTURE";}public Certificate[] getLocalCertificates(){return null;}public Certificate[] getServerCertificates(){return new Certificate[0];}
        public int getResponseCode(){return status;}public String getHeaderField(String name){return headers.get(name);}public long getContentLengthLong(){return length;}public String getContentType(){return "video/mp4";}public InputStream getInputStream(){return new ByteArrayInputStream(bytes);}
    }
    static byte[] own()throws Exception{try(var in=InstrumentationRegistry.getInstrumentation().getContext().getAssets().open("sample.mp4");var out=new ByteArrayOutputStream()){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toByteArray();}}
    static void clean(File root)throws Exception{try(var files=Files.walk(root.toPath())){files.sorted(Comparator.reverseOrder()).forEach(p->p.toFile().delete());}}
    static Publication publication(){Publication p=new Publication();p.id="own-native-queue";p.provider="fanbox";p.externalId="1";p.sourceRef="own";p.sourceLabel="Own";p.title="Own queue fixture";return p;}
    static void insert(LibraryDatabase db)throws Exception{Publication p=publication();PublicationContent c=new PublicationContent();c.publicationId=p.id;c.attachments=new JSONArray().put(new JSONObject().put("name","Own.bin").put("kind","video").put("url",URL).put("downloadable",true)).toString();db.library().insertPublication(p);db.library().putPublicationContent(c);}
    @Test public void actualAtomicQueueReloadResumesExactRangeOfOwnMp4()throws Exception{
        Context app=InstrumentationRegistry.getInstrumentation().getTargetContext();File base=Files.createTempDirectory(app.getCacheDir().toPath(),"native-queue320-").toFile();LibraryDatabase db=androidx.room.Room.inMemoryDatabaseBuilder(app,LibraryDatabase.class).allowMainThreadQueries().build();byte[] own=own();
        try{insert(db);DownloadQueue queue=new DownloadQueue(base);queue.enqueue(publication().id,SourceAttachments.load(db,publication().id));int cut=100000;Reply first=new Reply(200,Arrays.copyOf(own,cut));first.length=own.length;queue.run(db,(u,f,m,t,l,p)->PartialDownload.get(u,f,m,t,l,p,v->first,h->new InetAddress[]{InetAddress.getByName("93.184.216.34")}));assertEquals(cut,queue.snapshot().get(0).mark.offset());
            queue=new DownloadQueue(base);queue.continueAll();Reply second=new Reply(206,Arrays.copyOfRange(own,cut,own.length));second.headers.put("Content-Range","bytes "+cut+"-"+(own.length-1)+"/"+own.length);queue.run(db,(u,f,m,t,l,p)->PartialDownload.get(u,f,m,t,l,p,v->second,h->new InetAddress[]{InetAddress.getByName("93.184.216.34")}));var ready=queue.snapshot().get(0);assertEquals("ready",ready.state);assertEquals("bytes="+cut+"-",second.getRequestProperty("Range"));assertArrayEquals(own,Files.readAllBytes(queue.verify(ready.id,new SourceHttp.Token()).toPath()));assertTrue(first.closed&&second.closed);
        }finally{db.close();clean(base);}
    }
    @Test public void nativeReadOnlyProviderPinsOnlyCompletedOpaqueJobFiles()throws Exception{
        Context target=InstrumentationRegistry.getInstrumentation().getTargetContext();File base=Files.createTempDirectory(target.getCacheDir().toPath(),"native-provider320-").toFile();Context isolated=new ContextWrapper(target){@Override public File getNoBackupFilesDir(){return base;}};LibraryDatabase db=androidx.room.Room.inMemoryDatabaseBuilder(target,LibraryDatabase.class).allowMainThreadQueries().build();byte[] own=own();DownloadQueue queue=null;
        try{insert(db);queue=DownloadQueue.get(isolated);queue.enqueue(publication().id,SourceAttachments.load(db,publication().id));queue.run(db,(u,f,m,t,l,p)->SourceHttp.copyAttachment(u,new ByteArrayInputStream(own),f,own.length,t,l));var j=queue.snapshot().get(0);
            QueueFilesProvider provider=new QueueFilesProvider();android.content.pm.ProviderInfo info=new android.content.pm.ProviderInfo();info.authority=target.getPackageName()+".queue";info.exported=false;provider.attachInfo(isolated,info);Uri uri=QueueFilesProvider.uri(isolated,j.id);
            try(var in=new ParcelFileDescriptor.AutoCloseInputStream(provider.openFile(uri,"r"))){assertEquals(own[0]&255,in.read());try{queue.remove(j.id);fail();}catch(IOException expected){}}
            InstrumentationRegistry.getInstrumentation().waitForIdleSync();assertTrue(queue.pins.isEmpty());try{provider.openFile(uri,"rw");fail();}catch(FileNotFoundException expected){}try{provider.openFile(Uri.parse("content://"+info.authority+"/../../outside"),"r");fail();}catch(FileNotFoundException expected){}queue.remove(j.id);assertTrue(queue.snapshot().isEmpty());
        }finally{if(queue!=null)DownloadQueue.STORES.remove(queue.root);db.close();clean(base);}
    }
    @Test public void operationalQueueDoesNotEnterPersonalBackupOrCreateCatalogVisits()throws Exception{
        Context app=InstrumentationRegistry.getInstrumentation().getTargetContext();File base=Files.createTempDirectory(app.getCacheDir().toPath(),"native-backup320-").toFile();LibraryDatabase db=androidx.room.Room.inMemoryDatabaseBuilder(app,LibraryDatabase.class).allowMainThreadQueries().build();
        try{insert(db);DownloadQueue queue=new DownloadQueue(base);queue.enqueue(publication().id,SourceAttachments.load(db,publication().id));ByteArrayOutputStream out=new ByteArrayOutputStream();BackupStore.write(db.library(),out);JSONObject copy=new JSONObject(out.toString("UTF-8"));assertEquals(19,copy.getInt("version"));assertFalse(copy.has("downloadQueue"));assertTrue(db.library().allMedia().isEmpty());assertEquals(0,db.library().usageCount());DownloadQueue restored=new DownloadQueue(base);assertEquals(queue.snapshot().get(0).id,restored.snapshot().get(0).id);
        }finally{db.close();clean(base);}
    }
}
