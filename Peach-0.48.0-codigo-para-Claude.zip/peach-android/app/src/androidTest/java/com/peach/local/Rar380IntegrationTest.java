package com.peach.local;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.nio.file.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;
/** Own fixtures and cache only; no user library or upstream connection. */
@RunWith(AndroidJUnit4.class)
public class Rar380IntegrationTest {
 @Test public void actualAndroidRar4Rar5DecodePngAndReadTextInPrivateTemporaryDirectory()throws Exception{
  var instrumentation=InstrumentationRegistry.getInstrumentation();var app=instrumentation.getTargetContext();File dir=Files.createTempDirectory(app.getCacheDir().toPath(),"own-rar380-").toFile();
  try{for(String n:new String[]{"album-rar4.cbr","album-rar5.rar"}){File f=new File(dir,"source");try(var in=instrumentation.getContext().getAssets().open("rar038/"+n)){Files.copy(in,f.toPath(),StandardCopyOption.REPLACE_EXISTING);}try(var r=ArchiveBook.open(f,n,dir)){File image=r.read("images/2.png",dir);var decoded=ImageFiles.decode(image,2048);assertEquals(120,decoded.bitmap().getWidth());assertEquals(android.graphics.Color.RED,decoded.bitmap().getPixel(10,10));decoded.bitmap().recycle();String note=n.contains("rar4")?"notes.txt":"notas/ñ.txt";assertTrue(new String(Files.readAllBytes(r.read(note,dir).toPath()),java.nio.charset.StandardCharsets.UTF_8).contains("estratos"));}}}finally{for(File f:dir.listFiles())f.delete();dir.delete();}
 }
 @Test public void isolatedRoomBackup18RestoresCbrReaderProgressWithoutAvPosition()throws Exception{
  var app=InstrumentationRegistry.getInstrumentation().getTargetContext();var db=androidx.room.Room.inMemoryDatabaseBuilder(app,LibraryDatabase.class).allowMainThreadQueries().build();try{MediaEntry m=new MediaEntry();m.id="own-rar380";m.name="comic.cbr";m.uri="content://own/rar380";m.mediaType=MediaRules.ARCHIVE;db.library().insertMedia(m);ReaderProgress p=new ReaderProgress();p.mediaId=m.id;p.entry="images/10.png";p.page=1;ReaderStore.save(db,p);var out=new ByteArrayOutputStream();BackupStore.write(db.library(),out);assertEquals(19,new org.json.JSONObject(out.toString("UTF-8")).getInt("version"));BackupStore.read(db,new ByteArrayInputStream(out.toByteArray()));assertEquals("images/10.png",db.library().readerProgress(m.id).entry);assertEquals(0,db.library().get(m.id).position);}finally{db.close();}
 }
}
