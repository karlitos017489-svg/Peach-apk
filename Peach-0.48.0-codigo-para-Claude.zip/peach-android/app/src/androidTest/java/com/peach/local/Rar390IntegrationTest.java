package com.peach.local;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import android.content.ComponentName;
import android.content.pm.ServiceInfo;
import java.io.*;
import java.nio.file.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;
/** Real isolated Android service/ABI checks when executed; own fixtures only. */
@RunWith(AndroidJUnit4.class)
public class Rar390IntegrationTest {
 void check(String fixture)throws Exception{
  var instrument=InstrumentationRegistry.getInstrumentation();var app=instrument.getTargetContext();File dir=Files.createTempDirectory(app.getCacheDir().toPath(),"own-rar390-").toFile();
  try{
   ServiceInfo info=app.getPackageManager().getServiceInfo(new ComponentName(app,RarService.class),0);assertFalse(info.exported);assertTrue((info.flags&ServiceInfo.FLAG_ISOLATED_PROCESS)!=0);
   File source=new File(dir,"source");try(var in=instrument.getContext().getAssets().open("rar039/"+fixture)){Files.copy(in,source.toPath());}
   try(var r=new RarBook(source,new RarClient(app))){File notes=r.read("notes.txt",dir);assertTrue(new String(Files.readAllBytes(notes.toPath()),java.nio.charset.StandardCharsets.UTF_8).startsWith("Peach: estratos"));File picture=r.read("page.bmp",dir);var image=ImageFiles.decode(picture,2048);assertEquals(android.graphics.Color.RED,image.bitmap().getPixel(10,10));assertEquals(android.graphics.Color.BLUE,image.bitmap().getPixel(110,10));image.bitmap().recycle();}
  }finally{for(File f:dir.listFiles())f.delete();dir.delete();}
 }
 @Test public void ownCompressedRar4UsesRealIsolatedServiceAndRendersBmp()throws Exception{check("own-rar4-m3.cbr");}
 @Test public void ownCompressedRar5UsesRealIsolatedServiceAndRendersBmp()throws Exception{check("own-rar5-m3.cbr");}
}
