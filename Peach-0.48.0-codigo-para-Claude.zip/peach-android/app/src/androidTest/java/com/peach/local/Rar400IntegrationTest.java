package com.peach.local;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Own legacy-Unicode fixtures. Requires a real Android service/ABI when executed. */
@RunWith(AndroidJUnit4.class)
public class Rar400IntegrationTest {
    private void check(String fixture) throws Exception {
        var instrumentation=InstrumentationRegistry.getInstrumentation();
        var app=instrumentation.getTargetContext();
        File dir=Files.createTempDirectory(app.getCacheDir().toPath(),"own-rar400-").toFile();
        try {
            File source=new File(dir,"source");
            try(var in=instrumentation.getContext().getAssets().open("rar040/"+fixture)) {
                Files.copy(in,source.toPath());
            }
            byte[] original=Files.readAllBytes(source.toPath());
            try(var book=new RarBook(source,new RarClient(app))) {
                assertEquals(4,book.items().size());
                StringBuilder expected=new StringBuilder();
                for(int i=0;i<2000;i++)expected.append("Peach: estratos sedimentarios y minerales.\n");
                byte[] text=expected.toString().getBytes(StandardCharsets.UTF_8);
                for(String name:List.of("notas/niñez.txt","日本語/地層.txt","emoji/roca-🪨.txt")) {
                    assertNotNull(book.item(name));
                    assertArrayEquals(text,Files.readAllBytes(book.read(name,dir).toPath()));
                }
                File picture=book.read("imágenes/2.bmp",dir);
                var image=ImageFiles.decode(picture,2048);
                assertEquals(android.graphics.Color.RED,image.bitmap().getPixel(10,10));
                assertEquals(android.graphics.Color.BLUE,image.bitmap().getPixel(110,10));
                image.bitmap().recycle();
            }
            assertArrayEquals(original,Files.readAllBytes(source.toPath()));
        } finally {
            for(File file:dir.listFiles())file.delete();
            dir.delete();
        }
    }
    @Test public void storedLegacyUnicodeNamesReadExactContents() throws Exception {check("legacy-stored.cbr");}
    @Test public void compressedLegacyUnicodeNamesUseIsolatedDecoder() throws Exception {check("legacy-compressed.cbr");}
}
