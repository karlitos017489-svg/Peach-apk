package com.peach.local;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.nio.file.*;
import java.util.Arrays;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Requires Android ABI and actual isolated Binder service. Own solid fixture only. */
@RunWith(AndroidJUnit4.class)
public class Rar410IntegrationTest {
 private void check(boolean image)throws Exception{
  var instrument=InstrumentationRegistry.getInstrumentation();var app=instrument.getTargetContext();
  File dir=Files.createTempDirectory(app.getCacheDir().toPath(),"own-solid410-").toFile();
  try{
   File source=new File(dir,"source");try(var in=instrument.getContext().getAssets().open("rar041/own-solid-rar5-m3.cbr")){Files.copy(in,source.toPath());}
   byte[] original=Files.readAllBytes(source.toPath());
   try(var book=new RarBook(source,new RarClient(app))){
    assertEquals(4,book.items().size());
    if(image){var frame=ImageFiles.decode(book.read("03/imagen.bmp",dir),2048);assertEquals(android.graphics.Color.RED,frame.bitmap().getPixel(10,10));assertEquals(android.graphics.Color.BLUE,frame.bitmap().getPixel(110,10));frame.bitmap().recycle();}
    else{
     byte[] note=Files.readAllBytes(book.read("01/notas-ñ.txt",dir).toPath());assertEquals(86000,note.length);
     byte[] second=Files.readAllBytes(book.read("02/capa-日本語.txt",dir).toPath());assertEquals(86014,second.length);assertArrayEquals(note,Arrays.copyOf(second,note.length));
     assertArrayEquals(note,Files.readAllBytes(book.read("01/notas-ñ.txt",dir).toPath()));
    }
   }
   assertArrayEquals(original,Files.readAllBytes(source.toPath()));assertFalse(new File(dir,"entry-part").exists());
  }finally{for(File f:dir.listFiles())f.delete();dir.delete();}
 }
 @Test public void solidTextReadsLastAndMiddleEntriesWithRealService()throws Exception{check(false);}
 @Test public void solidBmpRendersWithRealService()throws Exception{check(true);}
}
