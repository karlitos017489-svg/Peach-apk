package com.peach.local;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.*;
import org.json.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Own disposable files/alias only. No user's account, cookies, media or current library is modified. */
@RunWith(AndroidJUnit4.class)
public class SourcePart243IntegrationTest {
 @Test public void androidKeyStoreVaultRoundTripsAndRejectsCrossSiteCiphertext()throws Exception{var app=InstrumentationRegistry.getInstrumentation().getTargetContext();File dir=new File(app.getCacheDir(),"peach-test-account-"+UUID.randomUUID());assertTrue(dir.mkdirs());String alias="PeachOwnTest430-"+UUID.randomUUID();SiteSessions vault=new SiteSessions(dir,()->SourceSecrets.key(alias));try{SiteSession own=new SiteSession("fanbox","FANBOXSESSID=OWN_DISPOSABLE_SESSION_430");vault.write(own);assertEquals(own,vault.read("fanbox"));java.nio.file.Files.copy(vault.path("fanbox").toPath(),vault.path("patreon").toPath());try{vault.read("patreon");fail();}catch(IOException expected){}assertFalse(new String(java.nio.file.Files.readAllBytes(vault.path("fanbox").toPath()),StandardCharsets.ISO_8859_1).contains("OWN_DISPOSABLE_SESSION_430"));}finally{for(File f:Objects.requireNonNull(dir.listFiles()))assertTrue(f.delete());assertTrue(dir.delete());KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);store.deleteEntry(alias);}}
 @Test public void nativeHtmlAndPixeldrainMetadataRouteToExpectedMediaWithHashes()throws Exception{String url="https://www.patreon.com/own/posts/test-1234";var body=VisiblePostBody.parse("patreon","own","1234",url,"<link rel=canonical href='"+url+"'><div class=patreon-post-content>Own text<img src='https://c10.patreonusercontent.com/4/patreon-media/p/post/1234/own.png'></div>");assertTrue(body.getBoolean("partial"));assertEquals(1,body.getJSONArray("attachments").length());var star=VisiblePostBody.parse("subscribestar","subscribestar.com/own","1234","https://subscribestar.com/posts/1234","<meta property=og:url content=https://subscribestar.com/posts/1234><div class=post data-id=1234><a class=star_link href=https://subscribestar.com/own>Own</a><div class=post-content>Own text</div></div>");assertTrue(star.getBoolean("partial"));JSONObject info=new JSONObject().put("success",true).put("id","Own_430a").put("name","Own.mp4").put("mime_type","video/mp4").put("size",3).put("hash_sha256","a".repeat(64)).put("availability","").put("can_download",true);JSONObject asset=PixeldrainReview.parse("Own_430a",info);PixeldrainUrls.validate(asset);assertEquals("video",asset.getString("kind"));assertEquals("a".repeat(64),asset.getString("expectedSha256"));}
}
