package com.peach.local;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.security.KeyStore;
import java.util.UUID;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;
@RunWith(AndroidJUnit4.class)
public class SourceSecretsIntegrationTest {
    @Test public void isolatedTestKeyUsesAndroidKeystoreAndNeverTouchesUserCredential()throws Exception{var context=InstrumentationRegistry.getInstrumentation().getTargetContext();String alias="PeachTest-"+UUID.randomUUID();File file=File.createTempFile("own-secret-",".bin",context.getCacheDir());file.delete();var store=new SourceSecrets(file,()->SourceSecrets.key(alias));try{var value=new SourceCredentials.ApiKey("123","OWN_ONLY_TEST_KEY_123456");store.write(value);assertEquals(value,store.read());store.clear();assertNull(store.read());}finally{store.clear();KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);ks.deleteEntry(alias);}}
}
