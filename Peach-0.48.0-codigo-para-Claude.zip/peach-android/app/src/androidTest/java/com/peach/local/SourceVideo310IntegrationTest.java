package com.peach.local;
import android.net.Uri;
import androidx.media3.datasource.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Own MP4 only. These checks require Android; compilation is not device execution. */
@RunWith(AndroidJUnit4.class)
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public class SourceVideo310IntegrationTest {
    static byte[] own()throws Exception{try(var in=InstrumentationRegistry.getInstrumentation().getContext().getAssets().open("sample.mp4");var out=new ByteArrayOutputStream()){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toByteArray();}}
    static void clean(File base)throws Exception{try(var paths=Files.walk(base.toPath())){paths.sorted(Comparator.reverseOrder()).forEach(p->p.toFile().delete());}}
    @Test public void privateCopyOpensWithActualMedia3FileDataSourceAndMp4ExtractorOffline()throws Exception{
        byte[] own=own();File base=Files.createTempDirectory(InstrumentationRegistry.getInstrumentation().getTargetContext().getCacheDir().toPath(),"native-source-video310-").toFile();
        var video=new SourceVideos.Video("Own.bin","https://rule34video.com/get_file/1/own/own.mp4/?download=true","rule34video");int[] calls={0};
        try{VideoCache cache=new VideoCache(base);
            try(var file=cache.acquire(video,false,new SourceHttp.Token(),(u,f,t,l)->{calls[0]++;return SourceHttp.copyAttachment(u,new ByteArrayInputStream(own),f,own.length,t,l);})){assertEquals(own.length,file.stamp.bytes());}
            try(var file=cache.acquire(video,true,new SourceHttp.Token(),(u,f,t,l)->{fail("Offline fetch");return null;})){
                assertTrue(file.cached);assertArrayEquals(own,Files.readAllBytes(file.file.toPath()));FileDataSource source=new FileDataSource();try{source.open(new DataSpec(Uri.fromFile(file.file)));var input=new androidx.media3.extractor.DefaultExtractorInput(source,0,own.length);assertTrue(new androidx.media3.extractor.mp4.Mp4Extractor().sniff(input));}finally{source.close();}
            }assertEquals(1,calls[0]);
        }finally{clean(base);}
    }
    @Test public void pinnedNativeCopyCannotBeRemovedAndPawHashMismatchIsRejected()throws Exception{
        byte[] own=own();File base=Files.createTempDirectory(InstrumentationRegistry.getInstrumentation().getTargetContext().getCacheDir().toPath(),"native-source-pins310-").toFile();VideoCache cache=new VideoCache(base);
        try{var video=new SourceVideos.Video("Own.mp4","https://downloads.fanbox.cc/own.mp4","fanbox");String key;
            try(var file=cache.acquire(video,false,new SourceHttp.Token(),(u,f,t,l)->SourceHttp.copyAttachment(u,new ByteArrayInputStream(own),f,own.length,t,l))){key=file.key;try{cache.discard(key);fail();}catch(VideoCache.Problem expected){}assertTrue(file.file.isFile());}
            cache.discard(key);assertTrue(cache.files().isEmpty());
            var bad=new SourceVideos.Video("Own.mp4","https://file.pawchive.pw/data/aa/bb/aabb"+"0".repeat(60)+".mp4","pawchive");
            try{cache.acquire(bad,false,new SourceHttp.Token(),(u,f,t,l)->{Files.write(f.toPath(),own);return new SourceHttp.Download(own.length,GalleryCache.checksum(f));});fail();}catch(IOException expected){}assertTrue(cache.files().isEmpty());
        }finally{clean(base);}
    }
}
