package com.peach.local;

import android.net.Uri;
import android.os.SystemClock;
import android.provider.DocumentsContract;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Own H264/AAC fixture, native renderer and content://. Compile is not execution. */
@RunWith(AndroidJUnit4.class)
public class SourceVideoIntegrationTest {
    @Test public void standaloneSavedDocumentDecodesAndKeepsPositionAfterRecreation()throws Exception{
        var context=InstrumentationRegistry.getInstrumentation().getTargetContext();
        Uri uri=DocumentsContract.buildDocumentUri(FixtureDocumentsProvider.AUTHORITY,"v0");
        try(ActivityScenario<PlayerActivity> scenario=ActivityScenario.launch(SourceFiles.play(context,uri,"own-previous-download.bin"))){
            await(scenario,false);
            scenario.onActivity(a->{ExoPlayer p=player(a);p.pause();p.seekTo(7000);});
            scenario.recreate();await(scenario,true);
        }
    }
    private ExoPlayer player(PlayerActivity activity){try{var f=PlayerActivity.class.getDeclaredField("player");f.setAccessible(true);return (ExoPlayer)f.get(activity);}catch(Exception e){throw new AssertionError(e);}}
    private void await(ActivityScenario<PlayerActivity> scenario,boolean resumed)throws Exception{
        long deadline=SystemClock.elapsedRealtime()+90000;boolean[] ready={false};
        while(SystemClock.elapsedRealtime()<deadline){scenario.onActivity(a->{ExoPlayer p=player(a);if(p==null)return;assertNull(p.getPlayerError());ready[0]=p.getPlaybackState()==androidx.media3.common.Player.STATE_READY&&p.getVideoFormat()!=null&&p.getAudioFormat()!=null&&(resumed?p.getCurrentPosition()>=6500:p.getCurrentPosition()>100);});if(ready[0])return;SystemClock.sleep(100);}
        fail("Native H264/AAC decode/position was not ready before deadline");
    }
}
