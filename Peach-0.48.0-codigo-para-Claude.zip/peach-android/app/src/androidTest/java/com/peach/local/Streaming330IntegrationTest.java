package com.peach.local;
import androidx.media3.common.C;
import androidx.media3.datasource.DataSpec;
import androidx.media3.extractor.DefaultExtractorInput;
import androidx.media3.extractor.mp4.Mp4Extractor;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import javax.net.ssl.HttpsURLConnection;
import java.io.*;
import java.net.*;
import java.security.cert.Certificate;
import java.util.*;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Own bytes and simulated HTTPS only, never the installed user's Room or queue. */
@RunWith(AndroidJUnit4.class)
public class Streaming330IntegrationTest {
    static final String URL="https://downloads.fanbox.cc/own-native-stream.mp4";
    static final class Factory implements SourceHttp.ConnectionFactory {
        byte[] bytes;List<Reply> replies=new ArrayList<>();Factory(byte[] bytes){this.bytes=bytes;}
        public HttpsURLConnection open(String url)throws IOException{try{Reply r=new Reply(bytes);replies.add(r);return r;}catch(Exception e){throw new IOException(e);}}
    }
    static final class Reply extends HttpsURLConnection {
        final byte[] bytes;int at,consumed,status=200;boolean closed,inputClosed;String range;
        Reply(byte[] bytes)throws Exception{super(new URL(URL));this.bytes=bytes;}
        public void connect(){}public void disconnect(){closed=true;}public boolean usingProxy(){return false;}public String getCipherSuite(){return "OWN_FIXTURE";}public Certificate[] getLocalCertificates(){return null;}public Certificate[] getServerCertificates(){return new Certificate[0];}
        public int getResponseCode(){range=getRequestProperty("Range");if(range!=null){at=Integer.parseInt(range.substring(6,range.length()-1));status=206;}return status;}
        public String getHeaderField(String key){if(key.equalsIgnoreCase("ETag"))return "\"own-native\"";if(key.equalsIgnoreCase("Content-Range")&&status==206)return "bytes "+at+"-"+(bytes.length-1)+"/"+bytes.length;return null;}
        public long getContentLengthLong(){return bytes.length-at;}public String getContentType(){return "video/mp4";}
        public InputStream getInputStream(){return new FilterInputStream(new ByteArrayInputStream(bytes,at,bytes.length-at)){@Override public int read(byte[] b,int o,int n)throws IOException{int count=super.read(b,o,n);if(count>0)consumed+=count;return count;}@Override public void close()throws IOException{inputClosed=true;super.close();}};}
    }
    static byte[] own()throws Exception{try(var in=InstrumentationRegistry.getInstrumentation().getContext().getAssets().open("sample.mp4");var out=new ByteArrayOutputStream()){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toByteArray();}}
    static VideoStream.Session session(Factory factory){VideoStream.Session s=new VideoStream.Session(URL,()->true,factory,h->new InetAddress[]{InetAddress.getByName("93.184.216.34")});s.resume();return s;}
    @Test public void nativeMedia3ReadsTheMp4HeaderBeforeTheWholeVideoArrives()throws Exception {
        Factory f=new Factory(own());try(var session=session(f)){StreamDataSource data=new StreamDataSource(session);try{long length=data.open(new DataSpec(StreamDataSource.uri(session.key)));assertEquals(f.bytes.length,length);assertEquals(4096,f.replies.get(0).consumed);DefaultExtractorInput input=new DefaultExtractorInput(data,0,length);Mp4Extractor extractor=new Mp4Extractor();try{assertTrue(extractor.sniff(input));assertTrue(f.replies.get(0).consumed<f.bytes.length);}finally{extractor.release();}}finally{data.close();}assertTrue(session.active.isEmpty());assertTrue(f.replies.get(0).closed&&f.replies.get(0).inputClosed);}
    }
    @Test public void nativeRangeAdapterReadsOnlyTheRequestedPosition()throws Exception {
        Factory f=new Factory(own());try(var session=session(f)){StreamDataSource data=new StreamDataSource(session);try{data.open(new DataSpec(StreamDataSource.uri(session.key)));}finally{data.close();}data=new StreamDataSource(session);try{assertEquals(32,data.open(new DataSpec.Builder().setUri(StreamDataSource.uri(session.key)).setPosition(100000).setLength(32).build()));byte[] b=new byte[32];assertEquals(32,data.read(b,0,32));assertArrayEquals(Arrays.copyOfRange(f.bytes,100000,100032),b);assertEquals(C.RESULT_END_OF_INPUT,data.read(b,0,32));assertEquals("bytes=100000-",f.replies.get(1).range);assertEquals(32,f.replies.get(1).consumed);}finally{data.close();}}
    }
    @Test public void nativePauseClosesTheConnectionAndIdentityContainsNoRemoteUrl()throws Exception {
        Factory f=new Factory(own());try(var session=session(f)){StreamDataSource data=new StreamDataSource(session);try{data.open(new DataSpec(StreamDataSource.uri(session.key)));session.pause();assertTrue(f.replies.get(0).closed);try{data.read(new byte[1],0,1);fail();}catch(IOException expected){}var app=InstrumentationRegistry.getInstrumentation().getTargetContext();var intent=SourceVideoStream.intent(app,"own-native-publication",session.key);assertNull(intent.getData());assertEquals(2,intent.getExtras().size());assertFalse(intent.getStringExtra(SourceVideoStream.KEY).contains("https://"));}finally{data.close();}assertTrue(session.active.isEmpty());}
    }
}
