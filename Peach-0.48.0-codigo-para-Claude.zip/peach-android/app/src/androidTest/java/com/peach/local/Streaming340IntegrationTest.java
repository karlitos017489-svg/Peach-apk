package com.peach.local;

import androidx.media3.common.*;
import androidx.media3.datasource.*;
import androidx.media3.decoder.DecoderInputBuffer;
import androidx.media3.exoplayer.*;
import androidx.media3.exoplayer.analytics.PlayerId;
import androidx.media3.exoplayer.source.*;
import androidx.media3.exoplayer.trackselection.*;
import androidx.media3.exoplayer.upstream.DefaultAllocator;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Own MP4 and simulated HTTPS; no Room, private user queue or upstream media. */
@RunWith(AndroidJUnit4.class)
public class Streaming340IntegrationTest {
    @Test public void nativeAdapterConsumesMedia3IcyHintWithoutForwardingIt()throws Exception {
        var network=new Streaming330IntegrationTest.Factory(Streaming330IntegrationTest.own());try(var session=Streaming330IntegrationTest.session(network)){var data=new StreamDataSource(session);try{data.open(new DataSpec.Builder().setUri(StreamDataSource.uri(session.key)).setHttpRequestHeaders(Map.of("Icy-MetaData","1")).build());assertEquals(16,data.read(new byte[16],0,16));assertNull(network.replies.get(0).getRequestProperty("Icy-MetaData"));assertNull(network.replies.get(0).getRequestProperty("Authorization"));}finally{data.close();}}
    }
    @Test public void nativeRealProgressivePeriodPreparesAndSuppliesAVideoSample()throws Exception {
        var instrumentation=InstrumentationRegistry.getInstrumentation();var network=new Streaming330IntegrationTest.Factory(Streaming330IntegrationTest.own());var session=Streaming330IntegrationTest.session(network);AtomicReference<ProgressiveMediaSource> source=new AtomicReference<>();AtomicReference<MediaPeriod> period=new AtomicReference<>();CountDownLatch prepared=new CountDownLatch(1);MediaSource.MediaSourceCaller[] caller=new MediaSource.MediaSourceCaller[1];SampleStream[] streams=new SampleStream[1];FormatHolder format=new FormatHolder();DecoderInputBuffer buffer=new DecoderInputBuffer(DecoderInputBuffer.BUFFER_REPLACEMENT_MODE_NORMAL);
        try{instrumentation.runOnMainSync(()->{
            var media=new ProgressiveMediaSource.Factory(()->new StreamDataSource(session)).setLoadErrorHandlingPolicy(new SourceVideoStream.NoRetry()).createMediaSource(new MediaItem.Builder().setUri(StreamDataSource.uri(session.key)).build());source.set(media);
            caller[0]=(s,t)->{if(period.get()!=null)return;var p=media.createPeriod(new MediaSource.MediaPeriodId(t.getUidOfPeriod(0)),new DefaultAllocator(true,C.DEFAULT_BUFFER_SEGMENT_SIZE),0);period.set(p);p.prepare(new MediaPeriod.Callback(){public void onPrepared(MediaPeriod value){prepared.countDown();}public void onContinueLoadingRequested(MediaPeriod value){value.continueLoading(new LoadingInfo.Builder().setPlaybackPositionUs(0).build());}},0);};media.prepareSource(caller[0],null,PlayerId.UNSET);
        });assertTrue("Real progressive media period must prepare",prepared.await(10,TimeUnit.SECONDS));
            instrumentation.runOnMainSync(()->{var groups=period.get().getTrackGroups();TrackGroup video=null;for(int i=0;i<groups.length;i++)if(groups.get(i).type==C.TRACK_TYPE_VIDEO)video=groups.get(i);assertNotNull(video);period.get().selectTracks(new ExoTrackSelection[]{new FixedTrackSelection(video,0)},new boolean[1],streams,new boolean[1],0);});
            AtomicBoolean sample=new AtomicBoolean();long end=System.nanoTime()+5_000_000_000L;while(!sample.get()&&System.nanoTime()<end){instrumentation.runOnMainSync(()->{period.get().continueLoading(new LoadingInfo.Builder().setPlaybackPositionUs(0).build());int result=streams[0].readData(format,buffer,0);if(result==C.RESULT_FORMAT_READ)assertEquals("video/avc",format.format.sampleMimeType);if(result==C.RESULT_BUFFER_READ&&!buffer.isEndOfStream()){assertNotNull(buffer.data);assertTrue(buffer.data.position()>0);sample.set(true);}});if(!sample.get())Thread.sleep(5);}assertTrue("Video sample must pass through the real media period",sample.get());assertFalse(network.replies.isEmpty());for(var r:network.replies)assertNull(r.getRequestProperty("Icy-MetaData"));
        }finally{session.pause();instrumentation.runOnMainSync(()->{if(period.get()!=null)source.get().releasePeriod(period.get());if(source.get()!=null)source.get().releaseSource(caller[0]);});session.close();long end=System.nanoTime()+5_000_000_000L;while(System.nanoTime()<end){synchronized(session){if(session.active.isEmpty())break;}Thread.sleep(5);}synchronized(session){assertTrue(session.active.isEmpty());}}
    }
}
