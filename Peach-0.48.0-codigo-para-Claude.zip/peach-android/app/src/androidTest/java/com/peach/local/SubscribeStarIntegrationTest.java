package com.peach.local;
import androidx.room.Room;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.nio.charset.StandardCharsets;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;
/** Synthetic HTML integration only. Does not establish direct HTTPS behavior on the user's tablet. */
@RunWith(AndroidJUnit4.class)
public class SubscribeStarIntegrationTest {
    @Test public void nativeParserReviewedImportAndBackupRoundTripUseOwnHtmlOnly()throws Exception{
        var i=InstrumentationRegistry.getInstrumentation();byte[] html;try(var in=i.getContext().getAssets().open("subscribestar220/public.html")){java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream();byte[] buffer=new byte[4096];int n;while((n=in.read(buffer))!=-1)bytes.write(buffer,0,n);html=bytes.toByteArray();}
        var db=Room.inMemoryDatabaseBuilder(i.getTargetContext(),LibraryDatabase.class).build();try{
            int[] calls={0};var store=new SourceStore(db,(u,e,m,t)->{calls[0]++;return new SourceHttp.Response(200,html,"","");});String source=store.create("subscribestar","artist","Fuente propia",null);assertEquals(0,calls[0]);store.fetch(source,false,new SourceHttp.Token());assertTrue(db.library().publications().isEmpty());store.apply(store.review(source));assertEquals(1,db.library().publications().size());var p=db.library().publications().get(0);var c=db.library().publicationContent(p.id);assertTrue(c.partial);assertFalse(c.text.contains("SECRET_"));assertTrue(db.library().allMedia().isEmpty());java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();BackupStore.write(db.library(),out);assertEquals(19,new org.json.JSONObject(out.toString(StandardCharsets.UTF_8.name())).getInt("version"));BackupStore.read(db,new java.io.ByteArrayInputStream(out.toByteArray()));assertEquals(1,db.library().publications().size());assertEquals(1,calls[0]);
        }finally{db.close();}
    }
}
