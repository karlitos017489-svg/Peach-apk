package com.peach.local;

import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.os.*;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.nio.file.*;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Self-owned files and fixtures only. Emulator execution is distinct from Samsung hardware execution. */
@RunWith(AndroidJUnit4.class)
public class Validation470IntegrationTest {
    @Test public void actualAndroidRunsOwnRoomPdfImageCodecAndIsolatedRarChecks()throws Exception {
        Context app=InstrumentationRegistry.getInstrumentation().getTargetContext();var report=new DeviceChecks(app).run(new DeviceChecks.Token(),(rows,current)->{});System.out.println("PEACH_DEVICE_CHECK="+report.json());assertEquals(8,report.rows().size());assertFalse(report.cancelled());for(var row:report.rows())assertEquals(row.label()+": "+row.detail(),"passed",row.state());assertFalse(new org.json.JSONObject(report.json()).getBoolean("testProbesInjected"));
    }
    @Test public void wallpaperAtomicRecoveryAndRemovalUseOnlyOwnIsolatedDirectory()throws Exception {
        Context app=InstrumentationRegistry.getInstrumentation().getTargetContext();File directory=Files.createTempDirectory(app.getCacheDir().toPath(),"own-wall470-").toFile();String prefix="own-wall470-"+System.nanoTime();Context local=new ContextWrapper(app){@Override public File getFilesDir(){return directory;}@Override public SharedPreferences getSharedPreferences(String n,int m){return app.getSharedPreferences(prefix+n,m);}};
        try{File base=WallpaperStore.file(local);android.util.AtomicFile atomic=new android.util.AtomicFile(base);Bitmap image=Bitmap.createBitmap(100,50,Bitmap.Config.ARGB_8888);image.eraseColor(Color.BLUE);FileOutputStream out=atomic.startWrite();assertTrue(image.compress(Bitmap.CompressFormat.JPEG,90,out));atomic.finishWrite(out);image.recycle();byte[] expected=Files.readAllBytes(base.toPath());out=atomic.startWrite();out.write(new byte[]{1,2,3});out.close();UiAppearance.clearWallpaperMemory();assertEquals(100,WallpaperStore.load(local).bitmap().getWidth());assertArrayEquals(expected,Files.readAllBytes(base.toPath()));assertTrue(WallpaperStore.remove(local));try{WallpaperStore.load(local);fail();}catch(FileNotFoundException expectedMissing){}}
        finally{WallpaperStore.remove(local);DeviceChecks.removeOwn(directory);app.deleteSharedPreferences(prefix+UiAppearance.PREFS);}
    }
    @Test public void actualContentResolverExportsOnlyTheChosenOwnReportDocument()throws Exception {
        Context app=InstrumentationRegistry.getInstrumentation().getTargetContext();var token=new DeviceChecks.Token();token.cancel();var report=new DeviceChecks(app).run(token,(r,c)->{});Uri uri=Uri.parse("content://com.peach.local.test.exchange/document/own-exchange");try{CheckReports.export(app,uri,report);try(InputStream in=app.getContentResolver().openInputStream(uri)){assertEquals(report.json(),new String(DeviceChecks.read(in,DeviceChecks.MAX_REPORT),java.nio.charset.StandardCharsets.UTF_8));}}finally{Bundle extras=new Bundle();extras.putParcelable("uri",uri);app.getContentResolver().call(uri,"android:deleteDocument",null,extras);}
    }
    @Test public void openingAndRecreatingCheckScreenDoesNotAutomaticallyRunIt(){try(var scenario=ActivityScenario.launch(DeviceCheckActivity.class)){scenario.onActivity(a->{assertFalse(a.draft.checking);assertNotNull(a.findViewById(R.id.check_start));});scenario.recreate();scenario.onActivity(a->assertFalse(a.draft.checking));}}
}
