package com.peach.local;

import android.content.Intent;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Compiled native Room/UI case; only running it on Android would validate that runtime. */
@RunWith(AndroidJUnit4.class)
public class VersionReviewIntegrationTest {
    @Test public void reviewedPartsUseNativeRoomAndExistingOrderedPlaylist()throws Exception{
        var instrumentation=InstrumentationRegistry.getInstrumentation();var context=instrumentation.getTargetContext();var db=LibraryDatabase.get(context);String root="native-version-190-"+UUID.randomUUID();List<String> ids=List.of(root+"a",root+"b");String[] saved={null};
        try{
            LibraryRoot r=new LibraryRoot();r.uri=root;r.label="Prueba de versiones";db.library().addRoot(r);
            for(int i=0;i<2;i++){MediaEntry m=new MediaEntry();m.id=ids.get(i);m.root=root;m.name="Obra part"+(i+1)+" 1080p.mp4";m.title=m.name;m.mediaType=MediaRules.VIDEO;db.library().insertMedia(m);}
            try(var screen=ActivityScenario.<VersionsActivity>launch(new Intent(context,VersionsActivity.class).putExtra("root",root))){
                LibraryDatabase.IO.submit(()->{}).get(20,TimeUnit.SECONDS);instrumentation.waitForIdleSync();screen.onActivity(a->a.findViewById(R.id.versions_scan).performClick());LibraryDatabase.IO.submit(()->{}).get(20,TimeUnit.SECONDS);instrumentation.waitForIdleSync();
                screen.onActivity(a->assertEquals(1,((android.widget.ListView)a.findViewById(R.id.versions_list)).getAdapter().getCount()));
                var proposal=VersionIndex.scan(db.library().reviewMedia(root,"",201)).get(0);saved[0]=new VersionReviewStore(db).apply(proposal,List.of(ids.get(1),ids.get(0)),"Prueba por partes",true).id();
                assertEquals(ids,db.library().playlistItems(saved[0]).stream().map(i->i.mediaId).toList());assertEquals(0,db.library().get(ids.get(0)).position);
            }
        }finally{if(saved[0]!=null)db.library().deletePlaylist(saved[0]);db.library().forgetMedia(root);db.library().forgetRoot(root);}
    }
}
