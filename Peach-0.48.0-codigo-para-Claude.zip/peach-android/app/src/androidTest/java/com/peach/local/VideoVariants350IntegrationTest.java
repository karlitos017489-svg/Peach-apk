package com.peach.local;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.nio.charset.StandardCharsets;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Isolated in-memory metadata only, never upstream media or the installed user's data. */
@RunWith(AndroidJUnit4.class)
public class VideoVariants350IntegrationTest {
    static Publication publication(){Publication p=new Publication();p.id="own-native-variants";p.provider="rule34video";p.sourceRef="own";p.externalId="1";p.url="https://rule34video.com/video/1/own/";p.title="Own personal title";p.notes="Own notes";return p;}
    @Test public void nativeReviewedRefreshPreservesPublicationAndChoosesDeclared1080p()throws Exception {
        var app=InstrumentationRegistry.getInstrumentation().getTargetContext();var db=androidx.room.Room.inMemoryDatabaseBuilder(app,LibraryDatabase.class).allowMainThreadQueries().build();try{Publication p=publication();PublicationContent c=new PublicationContent();c.publicationId=p.id;c.type="list";c.attachments=new JSONArray().put(new JSONObject().put("kind","video").put("name","Vista previa").put("url","https://rule34video.com/get_file/1/own/preview.mp4").put("downloadable",true)).toString();db.library().insertPublication(p);db.library().putPublicationContent(c);assertEquals("preview",SourceVideos.load(db,p.id).videos().get(0).variant().role());String html="<script type='application/ld+json'>{\"@type\":\"VideoObject\"}</script><a href='https://rule34video.com/get_file/1/own/low.mp4?download=true'>MP4 360p 1 MB</a><a href='https://rule34video.com/get_file/1/own/high.mp4?download=true'>MP4 1080p 4 MB</a>";
            int[] requests={0};var review=VideoVersionReview.query(db,p.id,(u,e,m,t)->{requests[0]++;assertEquals(p.url,u);return new SourceHttp.Response(200,html.getBytes(StandardCharsets.UTF_8),"","");},new SourceHttp.Token());assertEquals(c.attachments,db.library().publicationContent(p.id).attachments);VideoVersionReview.apply(db,review,new SourceHttp.Token());var selection=SourceVideos.load(db,p.id);assertEquals(1080,selection.videos().get(VideoVariants.best(selection.videos())).variant().height());assertEquals(1,requests[0]);assertEquals(p.title,db.library().publication(p.id).title);assertEquals(p.notes,db.library().publication(p.id).notes);assertTrue(db.library().allMedia().isEmpty());assertEquals(0,db.library().usageCount());
        }finally{db.close();}
    }
    @Test public void nativeBackupRetainsOptionalVariantFieldsInVersionSeventeen()throws Exception {
        var app=InstrumentationRegistry.getInstrumentation().getTargetContext();var db=androidx.room.Room.inMemoryDatabaseBuilder(app,LibraryDatabase.class).allowMainThreadQueries().build();try{Publication p=publication();PublicationContent c=new PublicationContent();c.publicationId=p.id;c.type="rule34video-detail";c.attachments=new JSONArray().put(VideoVariants.mark(new JSONObject().put("kind","video").put("name","Own high.mp4").put("url","https://rule34video.com/get_file/1/own/high.mp4").put("downloadable",true),"download",1080,1000,"")).toString();db.library().insertPublication(p);db.library().putPublicationContent(c);ByteArrayOutputStream out=new ByteArrayOutputStream();BackupStore.write(db.library(),out);assertEquals(19,new JSONObject(out.toString("UTF-8")).getInt("version"));db.library().deletePublication(p.id);BackupStore.read(db,new ByteArrayInputStream(out.toByteArray()));var video=SourceVideos.load(db,p.id).videos().get(0);assertEquals(1080,video.variant().height());assertEquals(1000,video.variant().bytes());assertEquals("download",video.variant().role());assertEquals(0,db.library().usageCount());}finally{db.close();}
    }
}
