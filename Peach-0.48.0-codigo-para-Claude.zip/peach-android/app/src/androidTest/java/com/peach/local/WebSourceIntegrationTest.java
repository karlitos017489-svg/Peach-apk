package com.peach.local;
import androidx.room.Room;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;
@RunWith(AndroidJUnit4.class)
public class WebSourceIntegrationTest {
    @Test public void fourOwnFixturesImportAndRestoreWithoutMediaOrCredentialBackup()throws Exception{
        var context=InstrumentationRegistry.getInstrumentation().getTargetContext();var db=Room.inMemoryDatabaseBuilder(context,LibraryDatabase.class).build();
        Map<String,String> fixtures=Map.of("rule34paheal","<div class='shm-image-list'><i class='shm-thumb' data-post-id='1' data-tags='own'></i></div>","rule34video","<div class='list-videos'><a href='https://rule34video.com/video/1/own/' title='Propio'></a></div>","rule34xxx","[{\"id\":1,\"tags\":\"own\"}]","f95zone","<h1 class='p-title-value'>Hilo propio</h1><article data-content='post-1'><div class='bbWrapper'>Texto propio</div></article>");
        try{var secret=new SourceCredentials.ApiKey("123","OWN_ONLY_TEST_KEY_123456");int[] calls={0};var transport=(SourceHttp.Transport)(u,e,m,t)->{calls[0]++;String host=SourceHttp.https(u).getHost(),p=host.equals("f95zone.to")?"f95zone":host.equals("rule34video.com")?"rule34video":host.equals("rule34.paheal.net")?"rule34paheal":"rule34xxx";return new SourceHttp.Response(200,fixtures.get(p).getBytes(StandardCharsets.UTF_8),"","");};var store=new SourceStore(db,transport,()->secret);for(String provider:fixtures.keySet()){String id=store.create(provider,provider.equals("f95zone")?"123":"own",provider,null);store.fetch(id,false,new SourceHttp.Token());store.apply(store.review(id));}assertEquals(4,db.library().publications().size());assertTrue(db.library().allMedia().isEmpty());ByteArrayOutputStream out=new ByteArrayOutputStream();BackupStore.write(db.library(),out);String text=out.toString("UTF-8");assertEquals(19,new JSONObject(text).getInt("version"));assertFalse(text.contains(secret.key()));BackupStore.read(db,new ByteArrayInputStream(out.toByteArray()));assertEquals(4,calls[0]);assertEquals(4,db.library().sources().size());}finally{db.close();}
    }
}
