package com.peach.local;
import android.os.ParcelFileDescriptor;
interface IRarEngine {
    long[] decode(long job, in ParcelFileDescriptor source, in ParcelFileDescriptor output, in byte[] name, long expected, long crc);
    void cancel(long job);
}
