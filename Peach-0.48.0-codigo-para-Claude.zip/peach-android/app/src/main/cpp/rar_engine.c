#define _POSIX_C_SOURCE 200809L
#include <jni.h>
#include <archive.h>
#include <archive_entry.h>
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <time.h>
#include <errno.h>
#include <limits.h>
#include <pthread.h>
#ifdef __ANDROID__
#include <sys/resource.h>
#endif

/* Link-time wrappers cover allocations from the statically linked archive reader.
 * Header alignment preserves malloc's max_align_t contract. libc/JVM internals are
 * not included in this budget; Android runs the decoder in an isolated service. */
typedef union {max_align_t align;struct {size_t size;} value;} Header;
typedef struct {size_t used,peak,limit,single;int failed;int64_t deadline;} Budget;
/* API 26 uses compiler emulated TLS, which allocates through our link-time wrappers.
 * Reading a _Thread_local budget from those wrappers recurses into that allocator.
 * libc pthread keys keep per-thread budgets without invoking compiler TLS allocation.
 * Failure to create/set the key rejects a decode before entering libarchive. */
static pthread_key_t budget_key;
static pthread_once_t budget_once=PTHREAD_ONCE_INIT;
static int budget_ready;
static void create_budget_key(void){budget_ready=pthread_key_create(&budget_key,NULL)==0;}
static Budget *current_budget(void){pthread_once(&budget_once,create_budget_key);return budget_ready?pthread_getspecific(budget_key):NULL;}
void *__real_malloc(size_t);void __real_free(void*);void *__real_realloc(void*,size_t);
void *__wrap_malloc(size_t n){
 Budget *budget=current_budget();
 if(n>SIZE_MAX-sizeof(Header) || (budget && (n>budget->single || n>budget->limit-budget->used))){if(budget)budget->failed=1;errno=ENOMEM;return NULL;}
 Header *h=__real_malloc(sizeof(Header)+n);if(!h){if(budget)budget->failed=1;return NULL;}h->value.size=n;
 if(budget){budget->used+=n;if(budget->used>budget->peak)budget->peak=budget->used;}return h+1;
}
void __wrap_free(void *p){Budget *budget=current_budget();if(!p)return;Header *h=(Header*)p-1;if(budget)budget->used-=h->value.size;__real_free(h);}
void *__wrap_calloc(size_t n,size_t size){Budget *budget=current_budget();if(size && n>SIZE_MAX/size){if(budget)budget->failed=1;return NULL;}size_t len=n*size;void *p=__wrap_malloc(len);if(p)memset(p,0,len);return p;}
void *__wrap_realloc(void *p,size_t n){Budget *budget=current_budget();if(!p)return __wrap_malloc(n);if(!n){__wrap_free(p);return NULL;}Header *h=(Header*)p-1;size_t old=h->value.size;
 if(n>SIZE_MAX-sizeof(Header) || (budget && (n>budget->single || n>budget->limit-(budget->used-old)))){if(budget)budget->failed=1;return NULL;}
 Header *q=__real_realloc(h,n+sizeof(Header));if(!q){if(budget)budget->failed=1;return NULL;}q->value.size=n;if(budget){budget->used=budget->used-old+n;if(budget->used>budget->peak)budget->peak=budget->used;}return q+1;
}
char *__wrap_strdup(const char *s){size_t n=strlen(s)+1;char *p=__wrap_malloc(n);if(p)memcpy(p,s,n);return p;}
char *__wrap_strndup(const char *s,size_t max){size_t n=strnlen(s,max);char *p=__wrap_malloc(n+1);if(p){memcpy(p,s,n);p[n]=0;}return p;}
static int64_t now_ns(void){struct timespec t;if(clock_gettime(CLOCK_MONOTONIC,&t))return INT64_MAX;return (int64_t)t.tv_sec*1000000000+t.tv_nsec;}
static int expired(void){Budget *budget=current_budget();return budget && now_ns()>budget->deadline;}
typedef struct {int fd;int64_t size,pos,read;unsigned char buffer[65536];} Input;
static la_ssize_t read_cb(struct archive *a,void *opaque,const void **out){Input *in=opaque;if(expired() || in->read>536870912LL+8388608){archive_set_error(a,EIO,"bounded input");return -1;}
 size_t len=(size_t)((in->size-in->pos)>65536?65536:(in->size-in->pos));ssize_t n=pread(in->fd,in->buffer,len,in->pos);if(n<0){archive_set_error(a,EIO,"input failed");return -1;}in->pos+=n;in->read+=n;*out=in->buffer;return n;}
static la_int64_t seek_cb(struct archive *a,void *opaque,la_int64_t offset,int whence){Input *in=opaque;int64_t base=whence==SEEK_SET?0:whence==SEEK_CUR?in->pos:whence==SEEK_END?in->size:-1;
 if(expired() || base<0 || (offset<0 && offset < -base) || (offset>=0 && offset>in->size-base)){archive_set_error(a,EIO,"bounded seek");return -1;}in->pos=base+offset;return in->pos;}
static int same_name(const char *a,const char *b){if(!a || !b)return 0;for(size_t i=0;i<=4096;i++){unsigned char x=a[i]=='\\'?'/':a[i],y=b[i];if(x!=y)return 0;if(!x)return 1;}return 0;}
static uint32_t checksum(uint32_t crc,const unsigned char *b,size_t n){for(size_t i=0;i<n;i++){crc^=b[i];for(int k=0;k<8;k++)crc=(crc>>1)^(0xedb88320U&-(crc&1));}return crc;}
/* Result [status, peak tracked allocation, remaining tracked allocations]. Statuses
 * are constants only. No path, native parser text, or data leaves this API. */
JNIEXPORT jlongArray JNICALL Java_com_peach_local_RarNative_decode(JNIEnv *env,jclass clazz,jint source,jint output,jbyteArray wanted,jlong expected,jlong expected_crc,jlong allocation_limit){
 (void)clazz;long status=1;struct archive *a=NULL;struct archive_entry *entry;Input input={.fd=source};Budget b={.limit=(size_t)allocation_limit,.single=67108864,.deadline=now_ns()+85000000000LL};
 unsigned char name[4097],block[65536];jsize name_len=(*env)->GetArrayLength(env,wanted);struct stat st;
 if(name_len<1 || name_len>4096 || expected<0 || expected>67108864 || expected_crc<0 || expected_crc>UINT32_MAX || allocation_limit<1048576 || allocation_limit>167772160)goto done;
 (*env)->GetByteArrayRegion(env,wanted,0,name_len,(jbyte*)name);if((*env)->ExceptionCheck(env))return NULL;name[name_len]=0;if(memchr(name,0,name_len))goto done;
 if(fstat(source,&st) || !S_ISREG(st.st_mode) || st.st_size<14 || st.st_size>536870912)goto done;input.size=st.st_size;
 #ifdef __ANDROID__
 struct rlimit file_limit={67108864,67108864};if(setrlimit(RLIMIT_FSIZE,&file_limit)!=0)goto done;
 #endif
 if(ftruncate(output,0) || lseek(output,0,SEEK_SET)<0)goto done;
 pthread_once(&budget_once,create_budget_key);if(!budget_ready || pthread_setspecific(budget_key,&b)!=0){status=9;goto done;}
 a=archive_read_new();if(!a)goto cleanup;
 if(archive_read_support_filter_none(a)!=ARCHIVE_OK || archive_read_support_format_rar(a)!=ARCHIVE_OK || archive_read_support_format_rar5(a)!=ARCHIVE_OK)goto cleanup;
 archive_read_set_seek_callback(a,seek_cb);if(archive_read_open(a,&input,NULL,read_cb,NULL)!=ARCHIVE_OK)goto cleanup;
 for(int count=0;count<10000;count++){
  int rc=archive_read_next_header(a,&entry);if(rc==ARCHIVE_EOF){status=2;break;}if(rc!=ARCHIVE_OK || expired())break;
  const char *path=archive_entry_pathname_utf8(entry);if(!same_name(path,(char*)name))continue;
  if(archive_entry_filetype(entry)!=AE_IFREG || archive_entry_size(entry)!=expected || archive_entry_is_encrypted(entry) || archive_entry_symlink(entry) || archive_entry_hardlink(entry)){status=3;break;}
  uint64_t total=0;uint32_t crc=UINT32_MAX;status=0;
  for(;;){if(expired()){status=5;break;}la_ssize_t n=archive_read_data(a,block,sizeof(block));if(n<0){status=1;break;}if(!n)break;
   if((uint64_t)n>(uint64_t)expected-total){status=3;break;}total+=(uint64_t)n;crc=checksum(crc,block,(size_t)n);
   size_t at=0;while(at<(size_t)n){ssize_t w=write(output,block+at,(size_t)n-at);if(w<=0){status=6;break;}at+=(size_t)w;}if(status)break;
  }
  if(!status && (total!=(uint64_t)expected || (crc^UINT32_MAX)!=(uint32_t)expected_crc))status=3;
  break;
 }
cleanup:
 if(a)archive_read_free(a);if(b.failed)status=4;if(expired())status=5;pthread_setspecific(budget_key,NULL);
done:;
 jlong values[3]={status,(jlong)b.peak,(jlong)b.used};jlongArray result=(*env)->NewLongArray(env,3);if(result)(*env)->SetLongArrayRegion(env,result,0,3,values);return result;
}
#ifdef PEACH_HOST_TEST
#include <fcntl.h>
JNIEXPORT jint JNICALL Java_com_peach_local_RarNativeTest_openFd(JNIEnv *env,jclass type,jstring path,jboolean writable){
 (void)type;const char *p=(*env)->GetStringUTFChars(env,path,NULL);if(!p)return -1;int fd=open(p,writable?O_CREAT|O_RDWR|O_TRUNC:O_RDONLY,0600);(*env)->ReleaseStringUTFChars(env,path,p);return fd;
}
JNIEXPORT void JNICALL Java_com_peach_local_RarNativeTest_closeFd(JNIEnv *env,jclass type,jint fd){(void)env;(void)type;close(fd);}
#endif
