package com.peach.local;

import java.util.*;
import org.json.*;

public final class AgencyStore {
    private final LibraryDatabase db;
    public AgencyStore(LibraryDatabase db){this.db=db;}
    public static boolean memberKind(String kind){return kind.equals("performer") || kind.equals("creator");}
    public void assign(String member,String agency){db.runInTransaction(()->{EntityMembership row=new EntityMembership();row.memberId=member;row.agencyId=agency;row.checkedAt=java.time.Instant.now().toString();validate(row,db.library());db.library().putMembership(row);});}
    public void remove(String member){db.library().removeMembership(member);}
    public static void validate(EntityMembership row,LibraryDao dao) {
        CatalogEntity member=dao.entity(row.memberId),agency=dao.entity(row.agencyId);
        validate(row,member,agency);
    }
    private static void validate(EntityMembership row,CatalogEntity member,CatalogEntity agency) {
        if(member==null || agency==null || !memberKind(member.kind) || !agency.kind.equals("agency") || row.memberId.equals(row.agencyId))throw new IllegalArgumentException("La afiliación requiere una persona o creador y una agencia distintos.");
        if(!Double.isFinite(row.confidence) || row.confidence<0 || row.confidence>1 || row.source.isBlank() || row.source.length()>300 || row.checkedAt.isBlank() || row.checkedAt.length()>100 || !(row.origin.equals("manual") || row.origin.matches("catalog:[0-9a-f-]{36}")))throw new IllegalArgumentException("Procedencia de afiliación inválida.");
    }
    public static void validateAll(LibraryDao dao){Map<String,CatalogEntity> entities=new HashMap<>();for(CatalogEntity e:dao.entities())entities.put(e.id,e);for(EntityMembership row:dao.memberships())validate(row,entities.get(row.memberId),entities.get(row.agencyId));}
    public static JSONArray backup(LibraryDao dao)throws JSONException {
        validateAll(dao);if(dao.memberships().size()>5000)throw new IllegalArgumentException("Demasiadas afiliaciones.");JSONArray rows=new JSONArray();
        for(EntityMembership m:dao.memberships())rows.put(new JSONObject().put("memberId",m.memberId).put("agencyId",m.agencyId).put("source",m.source).put("origin",m.origin).put("checkedAt",m.checkedAt).put("confidence",m.confidence));return rows;
    }
    public static void restore(LibraryDao dao,JSONObject backup)throws JSONException {
        JSONArray rows=backup.getJSONArray("memberships");if(rows.length()>5000)throw new IllegalArgumentException("Demasiadas afiliaciones.");Set<String> incoming=new HashSet<>();JSONArray entities=backup.getJSONArray("entities");for(int i=0;i<entities.length();i++)incoming.add(entities.getJSONObject(i).getString("id"));
        for(String id:incoming)dao.removeMembership(id);Set<String> seen=new HashSet<>();
        for(int i=0;i<rows.length();i++) {
            JSONObject r=rows.getJSONObject(i);EntityMembership m=new EntityMembership();m.memberId=CatalogTransfer.string(r,"memberId",true,1000);m.agencyId=CatalogTransfer.string(r,"agencyId",true,1000);m.source=CatalogTransfer.string(r,"source",true,300);m.origin=CatalogTransfer.string(r,"origin",true,100);m.checkedAt=CatalogTransfer.string(r,"checkedAt",true,100);
            Object value=r.opt("confidence");if(!(value instanceof Number n))throw new IllegalArgumentException("Confianza inválida.");m.confidence=n.doubleValue();
            if(!incoming.contains(m.memberId) || !incoming.contains(m.agencyId) || !seen.add(m.memberId))throw new IllegalArgumentException("Afiliación ajena o duplicada.");validate(m,dao);dao.putMembership(m);
        }
    }
    public static List<EntityIndex.Relation> relations(CatalogEntity agency,List<MediaEntry> media,List<CatalogEntity> entities,List<EntityAlias> aliases,List<MediaEntityLink> links,List<EntityMembership> memberships) {
        Set<String> ids=new HashSet<>();for(EntityMembership m:memberships)if(m.agencyId.equals(agency.id))ids.add(m.memberId);
        Map<String,CatalogEntity> members=new HashMap<>();Map<String,Map<String,CatalogEntity>> terms=new LinkedHashMap<>();
        Map<String,Set<String>> aliasesByEntity=new HashMap<>();for(EntityAlias alias:aliases)if(ids.contains(alias.entityId))aliasesByEntity.computeIfAbsent(alias.entityId,k->new LinkedHashSet<>()).add(alias.name);
        for(CatalogEntity e:entities)if(ids.contains(e.id) && memberKind(e.kind)){members.put(e.id,e);Set<String> names=new LinkedHashSet<>(aliasesByEntity.getOrDefault(e.id,Set.of()));names.add(e.name);for(String facet:EntityIndex.kind(e.kind).facets())for(String name:names)terms.computeIfAbsent(facet,k->new HashMap<>()).put(name,e);}
        List<EntityIndex.Relation> result=new ArrayList<>();Set<String> available=new HashSet<>();
        for(MediaEntry m:media){available.add(m.id);for(var facet:terms.entrySet()) {
            for(String term:CatalogIndex.localValues(m,facet.getKey())){CatalogEntity e=facet.getValue().get(term);if(e!=null)result.add(new EntityIndex.Relation(m.id,EntityIndex.role(facet.getKey()),"agency-nfo",e.name+" · "+term));}
            for(String term:m.catalog().values(facet.getKey())){CatalogEntity e=facet.getValue().get(term);if(e!=null)result.add(new EntityIndex.Relation(m.id,EntityIndex.role(facet.getKey()),"agency-catalog",e.name+" · "+term));}
        }}
        for(MediaEntityLink link:links){CatalogEntity e=members.get(link.entityId);if(e!=null && available.contains(link.mediaId))result.add(new EntityIndex.Relation(link.mediaId,link.role,"agency-manual",e.name));}return result;
    }
}
