package com.peach.local;

import android.content.ContentResolver;
import android.graphics.ImageDecoder;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

/** Android28+ bounded animated-image decoder. API26/27 use the existing still-frame path. */
final class AnimatedImages {
    private AnimatedImages() {}
    @androidx.annotation.RequiresApi(28)
    static Drawable decode(ContentResolver resolver,Uri uri)throws IOException {
        if(!SourceFiles.local(uri))throw new IOException("Elige una imagen local autorizada.");
        return decode(encoded(resolver,uri));
    }
    @androidx.annotation.RequiresApi(28)
    static Drawable decode(File file)throws IOException {
        // A private cache file may be evicted after decoding. The immutable mapping
        // remains readable by AnimatedImageDrawable without retaining a descriptor.
        try(FileInputStream input=new FileInputStream(file)){
            long length=input.getChannel().size();
            if(length<1 || length>SourceHttp.IMAGE_LIMIT)throw new IOException("Imagen fuera del límite de la galería.");
            return decode(input.getChannel().map(FileChannel.MapMode.READ_ONLY,0,length));
        }
    }
    @androidx.annotation.RequiresApi(28)
    private static Drawable decode(ByteBuffer encoded)throws IOException {
        return ImageDecoder.decodeDrawable(ImageDecoder.createSource(encoded),(decoder,info,source)->{
            int w=info.getSize().getWidth(),h=info.getSize().getHeight();
            if(w<1||h<1||w>32768||h>32768)throw new IllegalArgumentException("Dimensiones de imagen fuera del límite.");
            double scale=Math.min(1.0,1024.0/Math.max(w,h));decoder.setTargetSize(Math.max(1,(int)(w*scale)),Math.max(1,(int)(h*scale)));
            decoder.setOnPartialImageListener(error->false);
        });
    }
    static ByteBuffer encoded(ContentResolver resolver,Uri uri)throws IOException {
        // Keep encoded pages in a mapping, not an implicitly owned animation descriptor.
        // Closing this descriptor does not invalidate a read-only file mapping.
        try(android.content.res.AssetFileDescriptor afd=resolver.openAssetFileDescriptor(uri,"r")){
            if(afd==null)throw new IOException("Imagen inaccesible.");
            try(FileInputStream input=afd.createInputStream()){
                long length=afd.getDeclaredLength();if(length<0)length=input.getChannel().size()-afd.getStartOffset();
                if(length>0&&length<=Integer.MAX_VALUE)return input.getChannel().map(FileChannel.MapMode.READ_ONLY,afd.getStartOffset(),length);
            }
        }catch(IOException|UnsupportedOperationException ignored){/* Non-seekable providers use the bounded stream path. */}
        try(InputStream input=resolver.openInputStream(uri);ByteArrayOutputStream bytes=new ByteArrayOutputStream()){
            if(input==null)throw new IOException("Imagen inaccesible.");byte[] b=new byte[32768];int n;
            while((n=input.read(b))!=-1){if(Thread.currentThread().isInterrupted())throw new java.io.InterruptedIOException("Imagen cancelada.");if(bytes.size()+(long)n>64L*1024*1024)throw new IOException("Este proveedor no permite leer por posiciones una animación de más de64MiB. Guarda una copia local.");bytes.write(b,0,n);}
            if(bytes.size()==0)throw new IOException("Imagen vacía.");return ByteBuffer.wrap(bytes.toByteArray());
        }
    }
    static void stop(Drawable drawable){if(drawable instanceof Animatable a)a.stop();}
    static void start(Drawable drawable){if(drawable instanceof Animatable a)a.start();}
}
