package com.peach.local;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.activity.result.contract.ActivityResultContracts;
import java.util.concurrent.*;

/** Consumer settings; appearance never replaces library or playback preferences. */
public final class AppearanceActivity extends PeachActivity {
    private TextView message;private boolean working;
    private final androidx.activity.result.ActivityResultLauncher<Intent> image=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),result->{
        if(result.getResultCode()!=RESULT_OK||result.getData()==null||!SourceFiles.local(result.getData().getData()))return;
        var uri=result.getData().getData();working=true;message.setText("Preparando fondo…");UiAppearance.IO.execute(()->{String text;
            try{UiAppearance.saveWallpaper(getApplicationContext(),uri);text="Fondo guardado para Biblioteca. Puedes retirar el original sin perder este fondo.";}catch(Exception|OutOfMemoryError e){text="No se pudo usar la imagen. Elige JPG, PNG o WebP de hasta 16 MiB; el fondo anterior se conserva.";}
            String done=text;runOnUiThread(()->{working=false;if(!isDestroyed()){message.setText(done);}});
        });
    });
    @Override protected void onCreate(Bundle state){super.onCreate(state);LinearLayout root=UiAppearance.column(this,"Ajustes y apariencia");
        note(root,"Haz Peach a tu gusto. Los fondos se muestran en Biblioteca; el video y la lectura conservan sus controles propios.");
        option(root,"Tema",R.id.appearance_mode,new String[]{"Como el sistema","Oscuro","Claro"},"mode",1);
        option(root,"Color de la interfaz",R.id.appearance_accent,UiAppearance.NAMES,"accent",0);
        option(root,"Movimiento",R.id.appearance_motion,new String[]{"Sin animaciones","Transiciones suaves","Deslizamiento suave"},"motion",1);
        option(root,"Tamaño de las tarjetas",R.id.appearance_density,new String[]{"Compactas","Equilibradas","Grandes","Vista de lista"},"density",1);
        note(root,"Vista previa");LinearLayout preview=new LinearLayout(this);preview.setOrientation(LinearLayout.VERTICAL);preview.setPadding(24,24,24,24);preview.setBackground(UiAppearance.rounded(this,UiAppearance.surface(this),20));root.addView(preview);
        TextView sample=new TextView(this);sample.setText("Tu biblioteca, a tu manera");sample.setTextSize(20);sample.setTextColor(UiAppearance.accent(this));preview.addView(sample);TextView body=new TextView(this);body.setText("Colores legibles, botones amplios y menos distracciones.");preview.addView(body);
        Button add=new Button(this);add.setId(R.id.appearance_wallpaper);add.setText("Elegir imagen de fondo");add.setOnClickListener(v->{if(!working)image.launch(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));});root.addView(add);
        note(root,"Intensidad del fondo");SeekBar strength=new SeekBar(this);strength.setId(R.id.appearance_strength);strength.setMax(70);strength.setProgress(Math.max(0,Math.min(70,UiAppearance.prefs(this).getInt("wallpaperStrength",35)-10)));strength.setContentDescription("Intensidad del fondo, de 10 a 80 por ciento");root.addView(strength);
        strength.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){}public void onProgressChanged(SeekBar s,int p,boolean fromUser){}public void onStopTrackingTouch(SeekBar s){UiAppearance.prefs(AppearanceActivity.this).edit().putInt("wallpaperStrength",s.getProgress()+10).apply();}});
        Button remove=new Button(this);remove.setId(R.id.appearance_remove);remove.setText("Quitar fondo");remove.setOnClickListener(v->{if(working)return;if(!WallpaperStore.remove(this)){message.setText("No se pudo retirar el fondo.");return;}UiAppearance.clearWallpaperMemory();message.setText("Fondo retirado. Se usa el color del tema.");});root.addView(remove);
        Button storage=new Button(this);storage.setText("Almacenamiento y caché");storage.setOnClickListener(v->startActivity(new Intent(this,StorageActivity.class)));root.addView(storage);
        Button sync=new Button(this);sync.setText("Copias e intercambio");sync.setOnClickListener(v->startActivity(new Intent(this,ExchangeActivity.class)));root.addView(sync);
        Button check=new Button(this);check.setText("Comprobar funcionamiento");check.setOnClickListener(v->startActivity(new Intent(this,DeviceCheckActivity.class)));root.addView(check);
        message=new TextView(this);message.setText("Los ajustes se guardan en esta tablet. También se respeta la desactivación de animaciones de Android.");root.addView(message);
    }
    void note(LinearLayout root,String value){TextView t=new TextView(this);t.setText(value);t.setPadding(0,20,0,12);root.addView(t);}
    void option(LinearLayout root,String label,int id,String[] options,String key,int fallback){note(root,label);Spinner spinner=new Spinner(this);spinner.setId(id);spinner.setContentDescription(label);spinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,options));int current=Math.max(0,Math.min(options.length-1,UiAppearance.prefs(this).getInt(key,fallback)));spinner.setSelection(current);root.addView(spinner,new LinearLayout.LayoutParams(-1,UiAppearance.dp(this,56)));
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> p){}public void onItemSelected(AdapterView<?> p,android.view.View v,int index,long item){if(UiAppearance.prefs(AppearanceActivity.this).getInt(key,fallback)!=index){UiAppearance.prefs(AppearanceActivity.this).edit().putInt(key,index).apply();recreate();}}});}
}
