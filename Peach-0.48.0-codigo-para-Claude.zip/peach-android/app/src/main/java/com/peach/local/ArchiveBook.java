package com.peach.local;

import java.io.*;
import java.util.List;

/** Local archive view; internal names never become output paths. Worker-confined. */
public interface ArchiveBook extends AutoCloseable {
    record Item(String name,long bytes,String kind) {}
    List<Item> items();
    default void cancel(){}
    default String explanation(String name){return "Entrada catalogada sin lector integrado.";}
    default Item item(String name){return items().stream().filter(i->i.name().equals(name)).findFirst().orElse(null);}
    File read(String name,File directory)throws IOException;
    @Override void close()throws IOException;
    static ArchiveBook open(File source,String name,File directory)throws IOException {
        return switch(DocumentRules.kind(name)) {
            case DocumentRules.ZIP->new ZipBook(source);
            case DocumentRules.TAR->new TarBook(source);
            case DocumentRules.SEVEN->new SevenZipBook(source);
            case DocumentRules.RAR->new RarBook(source);
            case DocumentRules.EPUB->new EpubBook(source,directory);
            case DocumentRules.GZIP->GzipBook.open(source,name,directory);
            default->throw new IOException("Comprimido sin lector integrado.");
        };
    }
}
