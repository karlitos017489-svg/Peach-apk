package com.peach.local;

import java.io.*;

/** Disposable bounded materialization to fixed private names only. */
final class ArchiveFiles {
    static final long RESERVE=64L*1024*1024;
    private ArchiveFiles(){}
    static void check(long deadline)throws IOException {
        if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("Lectura cancelada.");
        if(System.nanoTime()>deadline)throw new IOException("La preparación del comprimido excedió 90 segundos.");
    }
    static File copy(InputStream input,File directory,String fixedName,long limit,long expected)throws IOException {
        File part=new File(directory,fixedName+"-part"),target=new File(directory,fixedName);boolean done=false;
        try {
            long total=0,deadline=System.nanoTime()+90_000_000_000L;byte[] buffer=new byte[65536];
            try(InputStream in=input;OutputStream out=new FileOutputStream(part)) {
                int n;while((n=in.read(buffer))!=-1){check(deadline);if(n==0)throw new IOException("El comprimido no devolvió datos.");total+=n;
                    if(total>limit)throw new IOException("El contenido descomprimido excede "+(limit/1024/1024)+" MiB.");
                    if(directory.getUsableSpace()<n+RESERVE)throw new IOException("No hay espacio suficiente para la vista temporal.");out.write(buffer,0,n);}
                check(deadline);if(expected>=0 && expected!=total)throw new IOException("Entrada truncada o tamaño no válido.");
            }
            if(target.exists() && !target.delete())throw new IOException("No se pudo renovar la vista temporal.");
            if(!part.renameTo(target))throw new IOException("No se pudo preparar la vista temporal.");done=true;return target;
        }finally{if(!done)part.delete();}
    }
}
