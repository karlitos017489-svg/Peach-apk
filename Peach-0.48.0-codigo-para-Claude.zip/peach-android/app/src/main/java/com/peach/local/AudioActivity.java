package com.peach.local;

import android.content.ComponentName;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.session.*;
import androidx.media3.ui.PlayerView;
import com.google.common.util.concurrent.ListenableFuture;

/** Only a controller: leaving or recreating this screen never releases the service player. */
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public class AudioActivity extends PeachActivity {
    private androidx.appcompat.app.AlertDialog volumeDialog;
    private PlayerView view;private MediaController controller;private ListenableFuture<MediaController> connection;
    private boolean started,requestApplied;private int generation;
    private final Player.Listener events=new Player.Listener(){
        @Override public void onMediaItemTransition(MediaItem item,int reason){show();}
        @Override public void onPlaybackStateChanged(int state){show();}
        @Override public void onPlayerError(PlaybackException error){message("No se pudo reproducir. Revisa el permiso y los códecs. Código: "+error.getErrorCodeName());}
    };
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);setContentView(R.layout.activity_player);PeachDesign.player(this,true);requestApplied=state!=null && state.getBoolean("audioRequestApplied");
        WindowCompat.setDecorFitsSystemWindows(getWindow(),false);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.playerRoot),(v,insets)->{var bars=insets.getInsets(WindowInsetsCompat.Type.systemBars()|WindowInsetsCompat.Type.displayCutout());v.setPadding(bars.left,bars.top,bars.right,bars.bottom);return insets;});
        view=findViewById(R.id.player);view.setUseArtwork(true);view.setDefaultArtwork(androidx.appcompat.content.res.AppCompatResources.getDrawable(this,R.drawable.art_audio));view.setShowSubtitleButton(false);view.setShowNextButton(true);view.setShowPreviousButton(true);
        findViewById(R.id.player_volume).setOnClickListener(v->volumeDialog=PlaybackVolume.show(this,()->controller,v));
        findViewById(R.id.subtitle).setVisibility(View.GONE);findViewById(R.id.fullscreen).setVisibility(View.GONE);
        findViewById(R.id.playerFormats).setOnClickListener(v->new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Pistas y compatibilidad").setMessage(PlaybackFormat.describe(controller==null?androidx.media3.common.Tracks.EMPTY:controller.getCurrentTracks())).setPositiveButton("Cerrar",null).show());
        findViewById(R.id.audioInfo).setVisibility(View.VISIBLE);((TextView)findViewById(R.id.playerTitle)).setText("Audio de Peach");
        findViewById(R.id.back).setOnClickListener(v->finish());findViewById(R.id.audioStop).setVisibility(View.VISIBLE);findViewById(R.id.audioStop).setEnabled(false);
        findViewById(R.id.audioStop).setOnClickListener(v->{if(controller!=null){v.setEnabled(false);var stopped=controller.sendCustomCommand(AudioService.STOP,Bundle.EMPTY);stopped.addListener(()->{if(!started)return;try{if(stopped.get().resultCode==SessionResult.RESULT_SUCCESS)finish();else{v.setEnabled(true);message("No se pudo detener el audio.");}}catch(Exception error){v.setEnabled(true);message("No se pudo detener el audio.");}},ContextCompat.getMainExecutor(this));}});
        ((TextView)findViewById(R.id.audioInfo)).setText("Conectando al audio…");
    }
    protected ListenableFuture<MediaController> connect(){return new MediaController.Builder(this,new SessionToken(this,new ComponentName(this,AudioService.class)))
        .setListener(new MediaController.Listener(){@Override public void onDisconnected(MediaController ignored){if(started){message("El audio se detuvo. Puedes abrirlo de nuevo desde la biblioteca.");findViewById(R.id.audioStop).setEnabled(false);}}
            @Override public void onError(MediaController ignored,SessionError error){message(error.message);}}).buildAsync();}
    @Override protected void onStart(){super.onStart();started=true;int token=++generation;connection=connect();var pending=connection;
        pending.addListener(()->{if(!started || token!=generation)return;try{controller=pending.get();controller.addListener(events);view.setPlayer(controller);show();
            String id=getIntent().getStringExtra("mediaId");
            if(id!=null && (!requestApplied || controller.getMediaItemCount()==0)){
                var result=controller.sendCustomCommand(AudioService.SELECT,getIntent().getExtras()==null?Bundle.EMPTY:getIntent().getExtras());
                result.addListener(()->{if(!started || token!=generation)return;try{var reply=result.get();if(reply.resultCode==SessionResult.RESULT_SUCCESS){requestApplied=true;findViewById(R.id.playerError).setVisibility(View.GONE);show();}else message(reply.extras.getString("message","No se pudo abrir la selección de audio."));}catch(Exception error){message("No se pudo abrir la selección de audio.");}},ContextCompat.getMainExecutor(this));
            }
        }catch(Exception error){message("No se pudo conectar al audio. Abre el archivo desde la biblioteca.");}},ContextCompat.getMainExecutor(this));
    }
    private void show(){if(controller==null)return;MediaItem item=controller.getCurrentMediaItem();boolean active=item!=null;findViewById(R.id.audioStop).setEnabled(active);
        ((TextView)findViewById(R.id.playerTitle)).setText(active?item.mediaMetadata.title:"Audio de Peach");
        ((TextView)findViewById(R.id.audioInfo)).setText(active?"En reproducción · "+(controller.getCurrentMediaItemIndex()+1)+" de "+controller.getMediaItemCount():"No hay audio activo. Abre uno desde la biblioteca.");
        if(controller.getPlayerError()==null && active)findViewById(R.id.playerError).setVisibility(View.GONE);
    }
    private void message(String value){if(isDestroyed())return;TextView error=findViewById(R.id.playerError);error.setText(value);error.setVisibility(View.VISIBLE);}
    @Override protected void onNewIntent(android.content.Intent intent){super.onNewIntent(intent);setIntent(intent);requestApplied=false;show();}
    @Override protected void onStop(){if(volumeDialog!=null){volumeDialog.dismiss();volumeDialog=null;}started=false;generation++;view.setPlayer(null);if(controller!=null)controller.removeListener(events);controller=null;if(connection!=null){MediaController.releaseFuture(connection);connection=null;}super.onStop();}
    @Override protected void onSaveInstanceState(Bundle state){state.putBoolean("audioRequestApplied",requestApplied);super.onSaveInstanceState(state);}
}
