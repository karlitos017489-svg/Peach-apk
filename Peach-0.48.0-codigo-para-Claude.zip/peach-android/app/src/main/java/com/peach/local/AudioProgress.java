package com.peach.local;

import android.os.Handler;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/** The service owns progress. Attaching/detaching a screen never creates another playback. */
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public final class AudioProgress implements Player.Listener,AutoCloseable {
    public record Position(String id,long position,long duration,long now,boolean watched){}
    private final Player player;private final Handler handler;private final Consumer<Position> persist;private final Consumer<String> record;
    private final UsageTracker history;
    private final Map<String,MediaEntry> rows=new HashMap<>();private String current="";private boolean recorded,closed;
    private final Runnable checkpoint=new Runnable(){public void run(){if(!closed){save(false);if(player.isPlaying())handler.postDelayed(this,5000);}}};
    public AudioProgress(Player player,Consumer<Position> persist,Consumer<String> record){this(player,persist,record,null);}
    public AudioProgress(Player player,Consumer<Position> persist,Consumer<String> record,UsageTracker history){this.player=player;this.persist=persist;this.record=record;this.history=history;handler=new Handler(player.getApplicationLooper());player.addListener(this);}
    public void replace(List<MediaEntry> incoming){save(false);if(incoming.isEmpty()&&history!=null)history.finish();rows.clear();for(MediaEntry row:incoming)rows.put(row.id,row);}
    private MediaEntry selected(){MediaItem item=player.getCurrentMediaItem();return item==null?null:rows.get(item.mediaId);}
    private void count(){MediaEntry row=selected();if(row==null)return;if(history!=null)history.open(row,"audio");if(!row.id.equals(current)){current=row.id;recorded=false;}if(!recorded){recorded=true;record.accept(row.id);}}
    private void duration(MediaEntry row){long duration=player.getDuration();if(duration!=C.TIME_UNSET && duration>0)row.duration=duration;}
    public void save(boolean ended){if(closed)return;ended=ended || player.getPlaybackState()==Player.STATE_ENDED;MediaEntry row=selected();if(row==null)return;duration(row);long position=ended?0:Math.max(0,player.getCurrentPosition());persist.accept(new Position(row.id,position,row.duration,System.currentTimeMillis(),ended || MediaRules.watchedByProgress(player.getCurrentPosition(),row.duration)));if(history!=null&&history.matches(row.id))history.checkpoint(position,row.duration,"",0,0,ended?"ended":player.isPlaying()?"active":"paused",ended);}
    @Override public void onMediaItemTransition(MediaItem item,int reason){if(item==null){current="";recorded=false;return;}if(!item.mediaId.equals(current)){current=item.mediaId;recorded=false;}if(player.getPlaybackState()==Player.STATE_READY)count();}
    @Override public void onPlaybackStateChanged(int state){if(state==Player.STATE_READY){count();save(false);}else if(state==Player.STATE_ENDED)save(true);}
    @Override public void onIsPlayingChanged(boolean playing){handler.removeCallbacks(checkpoint);if(playing){count();handler.postDelayed(checkpoint,5000);}else save(player.getPlaybackState()==Player.STATE_ENDED);}
    @Override public void onPositionDiscontinuity(Player.PositionInfo oldPosition,Player.PositionInfo newPosition,int reason){
        if(oldPosition.mediaItem==null)return;MediaEntry row=rows.get(oldPosition.mediaItem.mediaId);if(row==null)return;
        boolean ended=reason==Player.DISCONTINUITY_REASON_AUTO_TRANSITION;long position=ended?0:Math.max(0,oldPosition.positionMs);
        persist.accept(new Position(row.id,position,row.duration,System.currentTimeMillis(),ended || MediaRules.watchedByProgress(position,row.duration)));
        if(history!=null&&history.matches(row.id)){history.checkpoint(position,row.duration,"",0,0,ended?"ended":"paused",ended);if(newPosition.mediaItem==null||!row.id.equals(newPosition.mediaItem.mediaId))history.finish();}
    }
    @Override public void onPlayerError(androidx.media3.common.PlaybackException error){save(false);if(history!=null)history.touch("error");}
    @Override public void close(){if(closed)return;save(player.getPlaybackState()==Player.STATE_ENDED);if(history!=null)history.finish();closed=true;handler.removeCallbacks(checkpoint);player.removeListener(this);rows.clear();}
}
