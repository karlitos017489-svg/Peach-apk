package com.peach.local;

import android.net.Uri;
import android.os.Bundle;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import java.util.List;

/** Resolve an explicit library selection, never caller-supplied media URLs. Runs on database IO. */
public final class AudioSelection {
    public static final int MAX_QUEUE=5000;
    private AudioSelection(){}
    public record Queue(List<MediaEntry> rows,int start,long position){
        public Queue{rows=List.copyOf(rows);}
        public List<MediaItem> items(){return rows.stream().map(row->new MediaItem.Builder().setMediaId(row.id)
            .setUri(row.uri).setMediaMetadata(new MediaMetadata.Builder().setTitle(row.displayTitle())
                .setArtist(row.details().getOrDefault("artists","")).build()).build()).toList();}
    }
    static String text(Bundle args,String key){String value=args.getString(key,"");if(value==null || value.length()>4096)throw new IllegalArgumentException("Selección de audio no válida.");return value;}
    static boolean local(MediaEntry row){Uri uri=Uri.parse(row.uri);return MediaRules.AUDIO.equals(row.mediaType) && "content".equals(uri.getScheme()) && uri.getAuthority()!=null && !uri.getAuthority().isEmpty();}
    public static Queue load(LibraryDatabase db,Bundle args){
        String id=text(args,"mediaId"),playlist=text(args,"playlistId");int filter=args.getInt("filter",0),order=args.getInt("order",0);
        if(id.isEmpty() || filter<0 || filter>4 || order<0 || order>4)throw new IllegalArgumentException("Selección de audio no válida.");
        MediaEntry selected=db.library().get(id);
        if(selected==null || !local(selected))throw new IllegalArgumentException("Ese audio ya no está disponible en la biblioteca.");
        List<MediaEntry> scope=LibraryView.select(EntityIndex.select(db.library(),CatalogIndex.select(db.library().allMedia(),
            text(args,"facet"),text(args,"term"),text(args,"group"),db.library().groupItems()),text(args,"entityId")),text(args,"query"),filter,
            text(args,"root"),text(args,"folder"),playlist,playlist.isEmpty()?List.of():db.library().playlistItems(playlist),order,MediaRules.AUDIO);
        List<MediaEntry> rows=MediaQueues.select(scope,selected,false).stream().filter(AudioSelection::local).toList();
        if(rows.size()>MAX_QUEUE)throw new IllegalArgumentException("Hay más de 5.000 audios en esta selección. Filtra la biblioteca o elige una lista menor.");
        int start=0;for(int i=0;i<rows.size();i++)if(rows.get(i).id.equals(id))start=i;
        long position=Math.max(0,selected.position);if(selected.duration>0)position=Math.min(position,selected.duration);
        return new Queue(rows,start,position);
    }
}
