package com.peach.local;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.session.*;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.SettableFuture;
import java.util.HashSet;
import java.util.Set;

@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public class AudioService extends MediaSessionService {
    public static final SessionCommand SELECT=new SessionCommand("com.peach.local.audio.SELECT",Bundle.EMPTY),STOP=new SessionCommand("com.peach.local.audio.STOP",Bundle.EMPTY);
    private final Handler main=new Handler(Looper.getMainLooper());private final Set<SettableFuture<SessionResult>> pending=new HashSet<>();
    private MediaSession session;private Player player;private AudioProgress progress;private LibraryDatabase db;private boolean destroyed;private int request;
    protected Player createPlayer(){ExoPlayer engine=new ExoPlayer.Builder(this).build();engine.setVolume(PlaybackVolume.saved(this));engine.setAudioAttributes(new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),true);engine.setHandleAudioBecomingNoisy(true);engine.setWakeMode(C.WAKE_MODE_LOCAL);return engine;}
    @Override public void onCreate(){
        super.onCreate();db=LibraryDatabase.get(this);player=createPlayer();
        progress=new AudioProgress(player,p->LibraryDatabase.IO.execute(()->db.library().progress(p.id(),p.position(),p.duration(),p.now(),p.watched())),id->LibraryDatabase.IO.execute(()->db.library().recordPlay(id,System.currentTimeMillis())),new UsageTracker(db,null));
        PendingIntent activity=PendingIntent.getActivity(this,18,new Intent(this,AudioActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        session=new MediaSession.Builder(this,player).setSessionActivity(activity).setCallback(new Callback()).build();
        setListener(new MediaSessionService.Listener(){@Override public void onForegroundServiceStartNotAllowedException(){if(destroyed)return;player.pause();progress.save(false);session.sendError(new SessionError(SessionError.ERROR_UNKNOWN,"Android no permitió iniciar el audio en segundo plano. Abre el audio desde Peach.",Bundle.EMPTY));stopSelf();}});
    }
    static boolean allowed(int uid,boolean trusted){return uid==Process.myUid() || trusted;}
    @Override public MediaSession onGetSession(MediaSession.ControllerInfo controller){return allowed(controller.getUid(),controller.isTrusted())?session:null;}
    private final class Callback implements MediaSession.Callback {
        @Override public MediaSession.ConnectionResult onConnect(MediaSession session,MediaSession.ControllerInfo controller){
            if(!allowed(controller.getUid(),controller.isTrusted()))return MediaSession.ConnectionResult.reject();
            SessionCommands commands=controller.getUid()==Process.myUid()?new SessionCommands.Builder().add(SELECT).add(STOP).build():SessionCommands.EMPTY;
            return new MediaSession.ConnectionResult.AcceptedResultBuilder(session).setAvailableSessionCommands(commands)
                .setAvailablePlayerCommands(MediaSession.ConnectionResult.DEFAULT_PLAYER_COMMANDS.buildUpon().remove(Player.COMMAND_CHANGE_MEDIA_ITEMS).remove(Player.COMMAND_SET_MEDIA_ITEM).remove(Player.COMMAND_SET_VIDEO_SURFACE).build()).build();
        }
        @Override public ListenableFuture<SessionResult> onCustomCommand(MediaSession session,MediaSession.ControllerInfo controller,SessionCommand command,Bundle args){
            if(controller.getUid()!=Process.myUid())return Futures.immediateFuture(result(SessionError.ERROR_PERMISSION_DENIED,"Control no autorizado."));
            if(command.equals(STOP)){request++;progress.replace(java.util.List.of());player.stop();player.clearMediaItems();pauseAllPlayersAndStopSelf();return Futures.immediateFuture(new SessionResult(SessionResult.RESULT_SUCCESS));}
            if(command.equals(SELECT))return select(new Bundle(args));return Futures.immediateFuture(new SessionResult(SessionError.ERROR_NOT_SUPPORTED));
        }
    }
    static SessionResult result(int code,String message){Bundle extra=new Bundle();extra.putString("message",message);return new SessionResult(code,extra);}
    ListenableFuture<SessionResult> select(Bundle args){
        String id;try{id=AudioSelection.text(args,"mediaId");if(id.isEmpty())throw new IllegalArgumentException();}catch(Exception error){return Futures.immediateFuture(result(SessionError.ERROR_BAD_VALUE,"Selección de audio no válida."));}
        int token=++request;
        if(player.getCurrentMediaItem()!=null && player.getCurrentMediaItem().mediaId.equals(id) && player.getPlaybackState()!=Player.STATE_IDLE && player.getPlaybackState()!=Player.STATE_ENDED)return Futures.immediateFuture(new SessionResult(SessionResult.RESULT_SUCCESS));
        SettableFuture<SessionResult> future=SettableFuture.create();pending.add(future);
        LibraryDatabase.IO.execute(()->{
            try{
                AudioSelection.Queue queue=AudioSelection.load(db,args);
                main.post(()->{pending.remove(future);if(destroyed || token!=request){future.set(result(SessionError.ERROR_INVALID_STATE,"La selección fue sustituida por otra."));return;}
                    try{progress.replace(queue.rows());player.setMediaItems(queue.items(),queue.start(),queue.position());player.prepare();player.play();future.set(new SessionResult(SessionResult.RESULT_SUCCESS));}
                    catch(Exception error){player.pause();future.set(result(SessionError.ERROR_UNKNOWN,"No se pudo iniciar el audio. Revisa el permiso y el formato."));}
                });
            }catch(Exception error){main.post(()->{pending.remove(future);future.set(result(SessionError.ERROR_BAD_VALUE,error instanceof IllegalArgumentException?error.getMessage():"No se pudo consultar el audio de la biblioteca."));});}
        });return future;
    }
    MediaSession session(){return session;}
    @Override public void onTaskRemoved(Intent intent){if(player.isPlaying())super.onTaskRemoved(intent);else{progress.replace(java.util.List.of());player.clearMediaItems();if(session!=null)session.release();pauseAllPlayersAndStopSelf();}}
    @Override public void onDestroy(){destroyed=true;request++;for(var future:pending)future.set(result(SessionError.ERROR_INVALID_STATE,"El servicio de audio se cerró."));pending.clear();try{if(progress!=null)progress.close();}finally{if(session!=null){session.release();session=null;}if(player!=null){player.release();player=null;}super.onDestroy();}}
}
