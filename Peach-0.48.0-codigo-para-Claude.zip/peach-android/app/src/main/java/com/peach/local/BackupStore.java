package com.peach.local;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import org.json.JSONArray;
import org.json.JSONObject;

/** User state only: media and document grants are never embedded in the backup. */
public final class BackupStore {
    private BackupStore() {}
    public static void write(LibraryDao dao,OutputStream output) throws Exception {
        JSONArray items=new JSONArray();
        for (MediaEntry m : dao.allMedia()) {
            JSONObject row=new JSONObject(); row.put("id",m.id); row.put("favorite",m.favorite);
            row.put("watched",m.watched); row.put("position",m.position); row.put("duration",m.duration);
            row.put("lastPlayed",m.lastPlayed); row.put("playCount",m.playCount); items.put(row);
            row.put("userTitle",m.userTitle==null?JSONObject.NULL:m.userTitle);
            row.put("userTags",m.userTags==null?JSONObject.NULL:m.userTags);
        }
        JSONArray playlists=new JSONArray();
        for (Playlist list:dao.playlists()) {
            JSONObject row=new JSONObject();row.put("id",list.id);row.put("name",list.name);row.put("createdAt",list.createdAt);
            JSONArray members=new JSONArray();
            for (PlaylistItem item:dao.playlistItems(list.id)) members.put(item.mediaId);
            row.put("items",members);playlists.put(row);
        }
        JSONArray groups=new JSONArray();
        for(MediaGroup group:dao.groups()) {
            JSONObject row=new JSONObject();row.put("id",group.id);row.put("name",group.name);row.put("createdAt",group.createdAt);
            JSONArray members=new JSONArray();for(MediaGroupItem item:dao.groupItems(group.id))members.put(item.mediaId);
            row.put("items",members);groups.put(row);
        }
        JSONObject backup=new JSONObject(); backup.put("format","peach-local-state");
        backup.put("version",19); backup.put("items",items);backup.put("playlists",playlists);backup.put("groups",groups);
        backup.put("usageSessions",UsageStore.backup(dao));
        OrganizationBackup.write(dao,backup);
        backup.put("readerProgress",ReaderStore.backup(dao));
        backup.put("catalogSnapshots",CatalogSnapshots.backup(dao));
        backup.put("memberships",AgencyStore.backup(dao));
        TrackingBackup.write(dao,backup);
        SourceBackup.write(dao,backup);
        if(items.length()>50000 || playlists.length()>1000 || groups.length()>1000)
            throw new IllegalArgumentException("Copia demasiado grande");
        for(JSONArray collections:new JSONArray[]{playlists,groups})for(int i=0;i<collections.length();i++)
            if(collections.getJSONObject(i).getJSONArray("items").length()>50000)
                throw new IllegalArgumentException("Copia demasiado grande");
        byte[] encoded=backup.toString(2).getBytes(StandardCharsets.UTF_8);
        if (encoded.length>8*1024*1024) throw new IllegalArgumentException("Copia demasiado grande");
        output.write(encoded);
    }
    public static int read(LibraryDatabase db,InputStream input) throws Exception {
        ByteArrayOutputStream data=new ByteArrayOutputStream(); byte[] chunk=new byte[8192]; int count;
        while ((count=input.read(chunk))!=-1) {
            data.write(chunk,0,count);
            if (data.size()>8*1024*1024) throw new IllegalArgumentException("Copia demasiado grande");
        }
        JSONObject backup=new JSONObject(data.toString(StandardCharsets.UTF_8.name()));
        Object rawVersion=backup.opt("version");
        if(!(rawVersion instanceof Number number) || number.doubleValue()!=number.longValue() || number.longValue()<1 || number.longValue()>19)
            throw new IllegalArgumentException("Formato de copia incompatible");
        int version=number.intValue();
        if (!"peach-local-state".equals(backup.optString("format")))
            throw new IllegalArgumentException("Formato de copia incompatible");
        JSONArray items=backup.getJSONArray("items"); int[] matched={0};
        JSONArray playlists=version>=2?backup.getJSONArray("playlists"):new JSONArray();
        JSONArray groups=version>=3?backup.getJSONArray("groups"):new JSONArray();
        if (items.length()>50000 || playlists.length()>1000 || groups.length()>1000) throw new IllegalArgumentException("Copia demasiado grande");
        db.runInTransaction(() -> {
            for (int i=0;i<items.length();i++) {
                JSONObject row=items.optJSONObject(i);
                if (row==null) throw new IllegalArgumentException("Registro inválido");
                String id=row.optString("id");
                if (db.library().get(id)==null) continue;
                long duration=Math.max(0,row.optLong("duration"));
                long position=Math.max(0,row.optLong("position"));
                if (duration>0) position=Math.min(position,duration);
                db.library().restoreState(id,row.optBoolean("favorite"),row.optBoolean("watched"),
                    position,duration,Math.max(0,row.optLong("lastPlayed")),Math.max(0,row.optLong("playCount")));
                if (version>=2) {
                    String title=row.isNull("userTitle")?null:row.optString("userTitle",null);
                    String tags=row.isNull("userTags")?null:row.optString("userTags",null);
                    if (title!=null) title=PlaylistStore.validName(title,300);
                    if (tags!=null && tags.length()>2000) throw new IllegalArgumentException("Etiquetas demasiado largas");
                    db.library().editMetadata(id,title,tags);
                }
                matched[0]++;
            }
            java.util.Set<String> seen=new java.util.HashSet<>();
            for (int i=0;i<playlists.length();i++) {
                JSONObject row=playlists.optJSONObject(i);
                if (row==null) throw new IllegalArgumentException("Lista inválida");
                String id=row.optString("id");
                JSONArray members=row.optJSONArray("items");
                if (id.isEmpty() || id.length()>100 || !seen.add(id) || members==null || members.length()>50000)
                    throw new IllegalArgumentException("Lista inválida");
                Playlist list=new Playlist();list.id=id;list.name=PlaylistStore.validName(row.optString("name"),80);
                list.createdAt=Math.max(0,row.optLong("createdAt"));
                db.library().insertPlaylist(list);db.library().renamePlaylist(id,list.name);db.library().clearPlaylist(id);
                for (int j=0;j<members.length();j++) {
                    String mediaId=members.optString(j);
                    if (db.library().get(mediaId)==null) continue;
                    PlaylistItem item=new PlaylistItem();item.playlistId=id;item.mediaId=mediaId;item.position=j;
                    db.library().insertPlaylistItem(item);
                }
            }
            seen.clear();
            for(int i=0;i<groups.length();i++) {
                JSONObject row=groups.optJSONObject(i);
                if(row==null)throw new IllegalArgumentException("Grupo inválido");
                String id=row.optString("id");JSONArray members=row.optJSONArray("items");
                if(id.isEmpty() || id.length()>100 || !seen.add(id) || members==null || members.length()>50000)
                    throw new IllegalArgumentException("Grupo inválido");
                MediaGroup group=new MediaGroup();group.id=id;group.name=PlaylistStore.validName(row.optString("name"),80);
                group.createdAt=Math.max(0,row.optLong("createdAt"));
                db.library().insertGroup(group);db.library().renameGroup(id,group.name);db.library().clearGroup(id);
                for(int j=0;j<members.length();j++) {
                    Object value=members.opt(j);
                    if(!(value instanceof String mediaId) || mediaId.isEmpty())throw new IllegalArgumentException("Documento inválido");
                    if(db.library().get(mediaId)==null)continue;
                    MediaGroupItem item=new MediaGroupItem();item.groupId=id;item.mediaId=mediaId;db.library().insertGroupItem(item);
                }
            }
            if(version>=4)OrganizationBackup.read(db,backup);
            if(version>=5)ReaderStore.restore(db,backup);
            if(version>=6)try{CatalogSnapshots.restore(db.library(),backup);CatalogMetadata.rebuild(db.getOpenHelper().getWritableDatabase());}catch(org.json.JSONException e){throw new IllegalArgumentException("Catálogo inválido.",e);}
            if(version>=7)try{AgencyStore.restore(db.library(),backup);}catch(org.json.JSONException e){throw new IllegalArgumentException("Afiliación inválida.",e);}
            if(version>=8)try{TrackingBackup.restore(db.library(),backup);}catch(org.json.JSONException e){throw new IllegalArgumentException("Seguimiento inválido.",e);}
            if(version>=9)try{SourceBackup.restore(db.library(),backup);}catch(Exception e){throw new IllegalArgumentException("Fuentes o cuerpos no válidos.",e);}
            AgencyStore.validateAll(db.library());
            if(version>=11)UsageStore.restore(db,backup);
        });
        return matched[0];
    }
}
