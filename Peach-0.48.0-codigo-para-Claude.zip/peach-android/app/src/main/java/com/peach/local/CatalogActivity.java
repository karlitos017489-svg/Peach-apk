package com.peach.local;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import android.view.View;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.lifecycle.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Native catalog review, with explicit source path to scanned SAF root mapping. */
public class CatalogActivity extends PeachActivity {
    public static class Draft extends ViewModel {
        final MutableLiveData<Integer> updates=new MutableLiveData<>(0);
        volatile CatalogTransfer transfer;volatile CatalogBridge.Plan plan;volatile boolean busy;
        volatile String status="Elige una copia SQLite autónoma de ledger.db o un JSON de intercambio. Se leen campos seleccionados; el archivo original no se modifica.";
        String source="Peach principal",prefix="",root="",query="";
        List<LibraryRoot> roots=List.of();List<CatalogSnapshot.Head> snapshots=List.of();
        void notifyChange(){updates.postValue(1);}
    }
    private Draft draft;private LibraryDatabase db;private EditText source,prefix,search;private Spinner roots;
    private TextView status;private Button open,saved,preview,apply,export;private ArrayAdapter<String> adapter;
    private final List<String> descriptions=new ArrayList<>();private final List<String> labels=new ArrayList<>();private final List<Integer> visible=new ArrayList<>();private boolean rendering;
    private CatalogTransfer shownTransfer;private CatalogBridge.Plan shownPlan;
    private final ActivityResultLauncher<Intent> picker=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),result->{
        if(result.getResultCode()==Activity.RESULT_OK && result.getData()!=null && result.getData().getData()!=null) {
            var uri=result.getData().getData();work(()->{draft.transfer=CatalogTransfer.open(getApplicationContext(),uri);draft.plan=null;draft.status="Archivo leído. Revisa el nombre de origen, la ruta y la carpeta destino; después genera la vista previa.";});
        }
    });
    private final ActivityResultLauncher<Intent> savePicker=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),result->{
        if(result.getResultCode()==Activity.RESULT_OK && result.getData()!=null && result.getData().getData()!=null && draft.transfer!=null) {
            var uri=result.getData().getData();CatalogTransfer transfer=draft.transfer;
            work(()->{try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException("Destino no disponible.");out.write(transfer.encoded().getBytes(StandardCharsets.UTF_8));}draft.status="JSON de intercambio guardado. Contiene los campos seleccionados del origen; no incluye medios, contraseñas ni permisos SAF.";});
        }
    });
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);db=LibraryDatabase.get(this);draft=new ViewModelProvider(this).get(Draft.class);
        LinearLayout column=new LinearLayout(this);column.setOrientation(LinearLayout.VERTICAL);int pad=(int)(12*getResources().getDisplayMetrics().density);column.setPadding(pad,pad,pad,pad);setContentView(column);
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(column,(view,insets)->{var bars=insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars()|androidx.core.view.WindowInsetsCompat.Type.displayCutout()|androidx.core.view.WindowInsetsCompat.Type.ime());view.setPadding(pad+bars.left,pad+bars.top,pad+bars.right,pad+bars.bottom);return insets;});
        LinearLayout toolbar=row(column);button(toolbar,"Volver",v->finish());TextView title=new TextView(this);title.setText("Catálogo de Peach original");title.setTextSize(20);toolbar.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout files=row(column);open=button(files,"Elegir archivo",v->picker.launch(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE)));saved=button(files,"Catálogos guardados",v->saved());export=button(files,"Exportar JSON",v->savePicker.launch(new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/json").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"Peach-catalogo-intercambio.json")));
        source=input(column,"Nombre único del origen (usa el mismo para reimportarlo)",draft.source);prefix=input(column,"Ruta original que corresponde a la carpeta destino, por ejemplo R:\\Media",draft.prefix);
        roots=new Spinner(this);column.addView(roots);roots.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View view,int position,long id){if(rendering)return;String root=position==0?"":draft.roots.get(position-1).uri;if(!root.equals(draft.root)){draft.root=root;invalidatePlan();}}});
        LinearLayout actions=row(column);preview=button(actions,"Vista previa",v->preview());apply=button(actions,"Importar lo revisado",v->confirm());
        status=new TextView(this);status.setTextIsSelectable(true);column.addView(status);
        search=input(column,"Buscar rutas, identidades y listas",draft.query);ListView list=new ListView(this);column.addView(list,new LinearLayout.LayoutParams(-1,0,1));adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,new ArrayList<>());list.setAdapter(adapter);list.setOnItemClickListener((p,v,index,id)->details(descriptions.get(visible.get(index))));
        watch(source,()->{draft.source=source.getText().toString();invalidatePlan();});watch(prefix,()->{draft.prefix=prefix.getText().toString();invalidatePlan();});watch(search,()->{draft.query=search.getText().toString();filter();});
        draft.updates.observe(this,n->render());
        if(draft.roots.isEmpty() && !draft.busy)work(()->{draft.roots=db.library().roots();draft.snapshots=db.library().snapshotHeads();});
    }
    private LinearLayout row(LinearLayout parent){LinearLayout line=new LinearLayout(this);line.setOrientation(LinearLayout.HORIZONTAL);parent.addView(line);return line;}
    private Button button(LinearLayout parent,String text,View.OnClickListener click){Button b=new Button(this);b.setText(text);b.setAllCaps(false);b.setOnClickListener(click);parent.addView(b,new LinearLayout.LayoutParams(0,-2,1));return b;}
    private EditText input(LinearLayout parent,String hint,String text){EditText input=new EditText(this);input.setHint(hint);input.setText(text);input.setSingleLine(true);parent.addView(input);return input;}
    private void watch(EditText input,Runnable changed){input.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){if(!rendering)changed.run();}public void afterTextChanged(android.text.Editable e){}});}
    private void invalidatePlan(){draft.plan=null;draft.status="Genera una vista previa con las opciones actuales.";render();}
    interface Job{void run()throws Exception;}
    private void work(Job job){if(draft.busy)return;draft.busy=true;render();Draft retained=draft;LibraryDatabase.IO.execute(()->{try{job.run();}catch(Exception e){retained.status="No se pudo completar: "+(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage());}finally{retained.busy=false;retained.notifyChange();}});}
    private void preview(){if(draft.transfer==null)return;CatalogTransfer transfer=draft.transfer;CatalogBridge.Options options=new CatalogBridge.Options(draft.source,draft.prefix,draft.root);work(()->{draft.plan=CatalogBridge.preview(db.library(),transfer,options);draft.status=draft.plan.summary;});}
    private void confirm(){CatalogBridge.Plan plan=draft.plan;if(plan==null)return;new AlertDialog.Builder(this).setTitle("Importar datos revisados")
        .setMessage(plan.summary+"\n\nLas relaciones compatibles del origen se añadirán como vínculos explícitos después de tu revisión. Su fuente y confianza originales quedan en la instantánea. Las rutas coincidentes no comprueban el contenido byte por byte.")
        .setNegativeButton("Cancelar",null).setPositiveButton("Importar",(d,w)->work(()->{CatalogBridge.apply(db,plan);draft.snapshots=db.library().snapshotHeads();draft.plan=null;draft.status="Importación completada. La instantánea está guardada; las fichas y listas compatibles están disponibles en la biblioteca. Puedes elegir otro mapeo y generar una vista previa nueva.";})).show();}
    private void saved(){if(draft.snapshots.isEmpty()){draft.status="Todavía no hay catálogos importados.";render();return;}
        new AlertDialog.Builder(this).setTitle("Catálogos guardados").setItems(draft.snapshots.stream().map(s->s.label).toArray(String[]::new),(d,index)->{String id=draft.snapshots.get(index).id;work(()->{CatalogSnapshot snapshot=db.library().snapshot(id);if(snapshot==null)throw new IOException("Catálogo no disponible.");draft.transfer=CatalogTransfer.parse(new ByteArrayInputStream(snapshot.payload.getBytes(StandardCharsets.UTF_8)));draft.source=snapshot.label;draft.plan=null;draft.status="Instantánea recuperada. Sus registros se pueden consultar, exportar o mapear a otra carpeta escaneada.";});}).show();}
    private void render(){if(isDestroyed())return;rendering=true;
        if(!source.getText().toString().equals(draft.source))source.setText(draft.source);
        List<String> options=new ArrayList<>();options.add("Solo conservar catálogo; sin carpeta destino");int selected=0;for(LibraryRoot root:draft.roots){options.add(root.label+(root.state==0?"":" · escaneo pendiente"));if(root.uri.equals(draft.root))selected=options.size()-1;}
        roots.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,options));roots.setSelection(selected);
        open.setEnabled(!draft.busy);saved.setEnabled(!draft.busy);export.setEnabled(!draft.busy && draft.transfer!=null);preview.setEnabled(!draft.busy && draft.transfer!=null);apply.setEnabled(!draft.busy && draft.plan!=null);source.setEnabled(!draft.busy);prefix.setEnabled(!draft.busy);roots.setEnabled(!draft.busy);status.setText(draft.busy?"Procesando catálogo…":draft.status);
        if(shownTransfer!=draft.transfer || shownPlan!=draft.plan) {shownTransfer=draft.transfer;shownPlan=draft.plan;labels.clear();descriptions.clear();
        try {
            org.json.JSONObject tables=draft.transfer==null?null:draft.transfer.json().getJSONObject("tables");
            Map<Long,StringBuilder> related=new HashMap<>();if(tables!=null)for(String table:List.of("asset_tag","asset_entity"))for(var row:CatalogTransfer.rows(tables,table))related.computeIfAbsent(row.getLong("asset_id"),k->new StringBuilder()).append("\n").append(table).append(": ").append(row.toString());
            if(draft.plan!=null) {
                for(CatalogBridge.Asset a:draft.plan.assets){labels.add(a.label());descriptions.add(a.state()+"\nDocumento Android: "+a.mediaId()+"\n"+a.original().toString(2)+related.getOrDefault(a.id(),new StringBuilder()));}
                for(String review:draft.plan.review){labels.add(review);descriptions.add(review);}
            }else if(tables!=null)for(String table:CatalogTransfer.COLUMNS.keySet())for(org.json.JSONObject row:CatalogTransfer.rows(tables,table)){String description=table+"\n"+row.toString(2);labels.add(description);descriptions.add(description);}
        }catch(org.json.JSONException e){status.setText("No se pudo mostrar el catálogo.");}}
        filter();rendering=false;
    }
    private void filter(){if(adapter==null)return;String query=draft.query.toLowerCase(Locale.ROOT);visible.clear();List<String> shown=new ArrayList<>();for(int i=0;i<labels.size();i++)if(descriptions.get(i).toLowerCase(Locale.ROOT).contains(query)){visible.add(i);String label=labels.get(i);shown.add(label.length()>500?label.substring(0,500)+"…":label);}adapter.clear();adapter.addAll(shown);}
    private void details(String text){TextView view=new TextView(this);view.setText(text);view.setTextIsSelectable(true);view.setPadding(20,16,20,16);ScrollView scroll=new ScrollView(this);scroll.addView(view);new AlertDialog.Builder(this).setTitle("Campos y correspondencia").setView(scroll).setPositiveButton("Cerrar",null).show();}
}
