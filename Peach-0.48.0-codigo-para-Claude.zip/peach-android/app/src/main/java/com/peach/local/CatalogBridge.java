package com.peach.local;

import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;

/** Builds a review plan first; applies only additions and rechecks the plan in one transaction. */
public final class CatalogBridge {
    public record Options(String source,String prefix,String root) {}
    public record Asset(long id,String path,String mediaId,String state,JSONObject original) {
        public String label(){return state+" · "+path;}
    }
    record Identity(String id,JSONObject original,List<String> aliases,String state) {}
    record ListPlan(String id,JSONObject original,List<String> media,String state) {}
    record Affiliation(EntityMembership row,String state) {}
    public static final class Plan {
        final CatalogTransfer transfer;final Options options;final List<Identity> identities;final List<ListPlan> lists;final List<MediaEntityLink> links;
        final List<Affiliation> affiliations;final PublicationCatalog.Plan tracking;
        public final List<Asset> assets;public final List<String> review;public final String summary;
        Plan(CatalogTransfer transfer,Options options,List<Asset> assets,List<Identity> identities,List<ListPlan> lists,List<MediaEntityLink> links,List<String> review,List<Affiliation> affiliations,PublicationCatalog.Plan tracking) {
            this.affiliations=List.copyOf(affiliations);this.tracking=tracking;
            this.transfer=transfer;this.options=options;this.assets=List.copyOf(assets);this.identities=List.copyOf(identities);this.lists=List.copyOf(lists);this.links=List.copyOf(links);this.review=List.copyOf(review);
            long mapped=assets.stream().filter(a->!a.mediaId().isEmpty()).count(),newEntities=identities.stream().filter(i->i.state().equals("Nueva")).count(),conflicts=identities.stream().filter(i->i.state().equals("Conflicto")).count();
            summary="Publicaciones nuevas: "+tracking.publications()+" · deseos nuevos: "+tracking.wants()+" · conflictos de código: "+tracking.conflicts()+"\nArchivos: "+assets.size()+" · vinculables: "+mapped+" · sin vínculo: "+(assets.size()-mapped)+"\nIdentidades nuevas: "+newEntities+" · conflictos: "+conflicts+"\nListas nuevas: "+lists.stream().filter(l->l.state().equals("Nueva")).count()+" · relaciones explícitas: "+links.size()+"\nAfiliaciones nuevas: "+affiliations.stream().filter(a->a.state().equals("Nueva")).count()+" · conflictos: "+affiliations.stream().filter(a->a.state().equals("Conflicto")).count()+"\nSe conserva una instantánea de los campos seleccionados, incluidos registros sin archivo local. Se añaden fichas, referencias, relaciones y listas compatibles. Los datos vinculados se consultan en fichas, búsqueda y filtros, con su origen. Un título único del catálogo puede mostrarse si solo había nombre de archivo. No se reemplazan NFO, ediciones personales, favoritos, historial, lectura ni listas existentes.";
        }
        String stamp(){StringBuilder s=new StringBuilder(summary).append(tracking.stamp());for(Asset a:assets)s.append(a.id()).append(a.mediaId()).append(a.state());for(Identity i:identities)s.append(i.id()).append(i.state());for(ListPlan l:lists)s.append(l.id()).append(l.state()).append(l.media());for(MediaEntityLink l:links)s.append(l.entityId).append(l.mediaId).append(l.role);for(Affiliation a:affiliations)s.append(a.row().memberId).append(a.row().agencyId).append(a.state());return s.toString();}
    }
    private CatalogBridge() {}
    public static String key(String source,String kind,String id){return UUID.nameUUIDFromBytes(("peach-ledger\0"+source+"\0"+kind+"\0"+id).getBytes(StandardCharsets.UTF_8)).toString();}
    static String path(String raw) {
        String normalized=raw.replace('\\','/');if(normalized.endsWith("/"))normalized=normalized.substring(0,normalized.length()-1);
        if(normalized.length()>4096 || normalized.isEmpty())throw CatalogTransfer.invalid("Ruta vacía o demasiado larga.");
        String[] parts=normalized.split("/",-1);for(int i=0;i<parts.length;i++) {
            String p=parts[i];if(p.equals(".") || p.equals("..") || p.isEmpty() && !(i<2 && normalized.startsWith("/")))throw CatalogTransfer.invalid("Ruta con componentes ambiguos.");
            for(int j=0;j<p.length();j++)if(Character.isISOControl(p.charAt(j)))throw CatalogTransfer.invalid("Ruta con caracteres de control.");
        }return normalized;
    }
    static String relative(MediaEntry media) {
        if(media.name.contains("/") || media.name.contains("\\"))return "";
        return media.folder.isEmpty()?media.name:media.folder.replace(" / ","/")+"/"+media.name;
    }
    static String scanBase(LibraryDao dao,String root) {
        try {android.net.Uri tree=android.net.Uri.parse(root);String uri=android.provider.DocumentsContract.buildDocumentUriUsingTree(tree,android.provider.DocumentsContract.getTreeDocumentId(tree)).toString();ScanDirectory base=dao.scanDirectory(root,uri);return base==null?"":base.folder;}
        catch(IllegalArgumentException invalid){return "";}
    }
    static String relative(MediaEntry media,String base) {
        if(base.isEmpty())return relative(media);
        if(!media.folder.equals(base) && !media.folder.startsWith(base+" / "))return "";
        String folder=media.folder.equals(base)?"":media.folder.substring(base.length()+3);
        if(media.name.contains("/") || media.name.contains("\\"))return "";return folder.isEmpty()?media.name:folder.replace(" / ","/")+"/"+media.name;
    }
    public static Plan preview(LibraryDao dao,CatalogTransfer transfer,Options raw) throws JSONException {
        String source=PlaylistStore.validName(raw.source(),80),prefix=raw.prefix().isBlank()?"":path(raw.prefix());Options options=new Options(source,prefix,raw.root());
        if(!raw.root().isEmpty() && (prefix.isEmpty() || dao.roots().stream().noneMatch(r->r.uri.equals(raw.root()) && r.state==0)))throw CatalogTransfer.invalid("Selecciona una raíz completamente escaneada y su ruta original.");
        String base=raw.root().isEmpty()?"":scanBase(dao,raw.root());
        Map<String,List<MediaEntry>> byPath=new HashMap<>();for(MediaEntry m:dao.allMedia())if(m.root.equals(raw.root()) && !m.missing) {
            String relative=relative(m,base);if(!relative.isEmpty())byPath.computeIfAbsent(relative,k->new ArrayList<>()).add(m);
        }
        JSONObject tables=transfer.json().getJSONObject("tables");List<Asset> assets=new ArrayList<>();Map<String,Integer> uses=new HashMap<>();
        for(JSONObject row:CatalogTransfer.rows(tables,"asset")) {
            String original=row.getString("path"),mediaId="",state="Sin correspondencia";
            try {
                String p=path(original);
                if(!prefix.isEmpty() && !raw.root().isEmpty() && p.startsWith(prefix+"/")) {
                    var matches=byPath.getOrDefault(p.substring(prefix.length()+1),List.of());
                    if(matches.size()>1)state="Ruta local ambigua";
                    else if(matches.size()==1) {
                        MediaEntry m=matches.get(0);long size=row.optLong("size",0);
                        if(size>0 && m.bytes>0 && size!=m.bytes)state="Tamaño diferente";
                        else {state="Vinculable";mediaId=m.id;uses.merge(mediaId,1,Integer::sum);}
                    }
                }
            }catch(IllegalArgumentException invalid){state="Ruta no compatible";}
            assets.add(new Asset(row.getLong("id"),original,mediaId,state,row));
        }
        Map<Long,String> mediaIds=new HashMap<>();
        for(int i=0;i<assets.size();i++) {
            Asset a=assets.get(i);if(!a.mediaId().isEmpty() && uses.get(a.mediaId())>1)assets.set(i,new Asset(a.id(),a.path(),"","Varios assets para un documento",a.original()));
            else if(!a.mediaId().isEmpty())mediaIds.put(a.id(),a.mediaId());
        }
        Map<String,String> owners=new HashMap<>();Map<String,CatalogEntity> existing=new HashMap<>();
        for(CatalogEntity e:dao.entities()){existing.put(e.id,e);owners.put(e.kind+"\0"+e.name,e.id);}
        for(EntityAlias a:dao.aliases()){CatalogEntity e=existing.get(a.entityId);if(e!=null)owners.put(e.kind+"\0"+a.name,a.entityId);}
        Map<Long,LinkedHashSet<String>> aliases=new HashMap<>();for(JSONObject row:CatalogTransfer.rows(tables,"entity_alias"))aliases.computeIfAbsent(row.getLong("entity_id"),k->new LinkedHashSet<>()).add(row.getString("alias").trim());
        // Reserve all incoming names before classifying: both sides of an ambiguous claim are rejected.
        Map<String,Set<String>> claims=new HashMap<>();
        for(JSONObject row:CatalogTransfer.rows(tables,"entity")) {
            String id=key(source,"entity",row.getString("id")),kind=row.getString("kind");Set<String> names=new LinkedHashSet<>(aliases.getOrDefault(row.getLong("id"),new LinkedHashSet<>()));names.add(row.getString("canonical_name").trim());
            for(String name:names)claims.computeIfAbsent(kind+"\0"+name,k->new HashSet<>()).add(id);
        }
        List<Identity> identities=new ArrayList<>();Map<Long,Identity> entityIds=new HashMap<>();List<String> review=new ArrayList<>();
        for(JSONObject row:CatalogTransfer.rows(tables,"entity")) {
            String id=key(source,"entity",row.getString("id")),kind=row.getString("kind"),name=row.getString("canonical_name").trim(),state=existing.containsKey(id)?"Existente, se conserva":"Nueva";
            Set<String> names=new LinkedHashSet<>(aliases.getOrDefault(row.getLong("id"),new LinkedHashSet<>()));names.add(name);
            CatalogEntity old=existing.get(id);boolean conflict=old!=null && (!old.kind.equals(kind) || !old.name.equals(name));
            for(String n:names){String claim=kind+"\0"+n;if(owners.containsKey(claim) && !owners.get(claim).equals(id) || claims.get(claim).size()>1)conflict=true;}
            if(conflict)state="Conflicto";
            boolean supported=EntityIndex.KINDS.stream().anyMatch(k->k.key().equals(kind));if(!supported)state="Tipo pendiente";
            if(raw.root().isEmpty())state="Solo catálogo";
            Identity identity=new Identity(id,row,List.copyOf(names),state);identities.add(identity);entityIds.put(row.getLong("id"),identity);
            review.add(state+" · "+(supported?EntityIndex.kind(kind).label():kind)+" · "+name+"\nAlias: "+String.join(" · ",names));
        }
        List<MediaEntityLink> links=new ArrayList<>();Set<String> dedup=new HashSet<>();
        for(JSONObject row:CatalogTransfer.rows(tables,"asset_entity")) {
            Identity e=entityIds.get(row.getLong("entity_id"));String media=mediaIds.get(row.getLong("asset_id")),role=row.getString("role");
            if(!List.of("Nueva","Existente, se conserva").contains(e.state()) || media==null || !EntityIndex.roles(e.original().getString("kind")).contains(role))continue;
            if(dedup.add(e.id()+"\0"+media+"\0"+role)){MediaEntityLink link=new MediaEntityLink();link.entityId=e.id();link.mediaId=media;link.role=role;links.add(link);}
        }
        List<ListPlan> lists=new ArrayList<>();Map<Long,List<JSONObject>> members=new HashMap<>();
        for(JSONObject row:CatalogTransfer.rows(tables,"playlist_item"))members.computeIfAbsent(row.getLong("playlist_id"),k->new ArrayList<>()).add(row);
        for(JSONObject row:CatalogTransfer.rows(tables,"playlist")) {
            String id=key(source,"playlist",row.getString("id"));List<JSONObject> items=members.getOrDefault(row.getLong("id"),new ArrayList<>());
            items.sort(Comparator.comparingLong((JSONObject j)->j.optLong("position")).thenComparingLong(j->j.optLong("asset_id")));
            LinkedHashSet<String> mapped=new LinkedHashSet<>();for(JSONObject item:items){String media=mediaIds.get(item.getLong("asset_id"));if(media!=null)mapped.add(media);}
            String state=raw.root().isEmpty()?"Solo catálogo":dao.playlist(id)==null?"Nueva":"Existente, se conserva";lists.add(new ListPlan(id,row,List.copyOf(mapped),state));
            review.add(state+" · Lista: "+row.getString("name")+" · perfil "+row.getString("profile_id")+"\nMiembros vinculables: "+mapped.size()+" / "+items.size());
        }
        List<Affiliation> affiliations=new ArrayList<>();
        for(JSONObject r:CatalogTransfer.rows(tables,"entity_membership")) {
            Identity member=entityIds.get(r.getLong("member_id")),agency=entityIds.get(r.getLong("agency_id"));EntityMembership row=new EntityMembership();row.memberId=member.id();row.agencyId=agency.id();row.source=r.getString("source");row.confidence=r.getDouble("confidence");row.checkedAt=r.getString("checked_at");row.origin="catalog:"+key(source,"snapshot","");String state="Nueva";
            if(!AgencyStore.memberKind(member.original().getString("kind")) || !agency.original().getString("kind").equals("agency"))state="Tipo no compatible";
            else if(!List.of("Nueva","Existente, se conserva").contains(member.state()) || !List.of("Nueva","Existente, se conserva").contains(agency.state()))state="Sin fichas compatibles";
            else {EntityMembership current=dao.membership(row.memberId);if(current!=null)state=current.agencyId.equals(row.agencyId)?"Existente, se conserva":"Conflicto";}
            if(raw.root().isEmpty())state="Solo catálogo";affiliations.add(new Affiliation(row,state));review.add(state+" · Afiliación: "+member.original().getString("canonical_name")+" → "+agency.original().getString("canonical_name")+"\nFuente: "+row.source+" · confianza: "+row.confidence+" · fecha: "+row.checkedAt);
        }
        Map<Long,String> compatible=new HashMap<>();for(var entry:entityIds.entrySet())if(List.of("Nueva","Existente, se conserva").contains(entry.getValue().state()))compatible.put(entry.getKey(),entry.getValue().id());
        PublicationCatalog.Plan tracking=PublicationCatalog.preview(dao,transfer,source,!raw.root().isEmpty(),mediaIds,compatible);review.addAll(tracking.review());
        return new Plan(transfer,options,assets,identities,lists,links,review,affiliations,tracking);
    }
    public static void apply(LibraryDatabase db,Plan plan) {
        db.runInTransaction(()-> {
            try {
                Plan current=preview(db.library(),plan.transfer,plan.options);if(!current.stamp().equals(plan.stamp()))throw CatalogTransfer.invalid("La biblioteca cambió. Genera una vista previa nueva.");
                LibraryDao dao=db.library();long now=System.currentTimeMillis();Map<Long,List<JSONObject>> references=new HashMap<>();
                for(JSONObject r:CatalogTransfer.rows(plan.transfer.json().getJSONObject("tables"),"entity_external_ref"))references.computeIfAbsent(r.getLong("entity_id"),k->new ArrayList<>()).add(r);
                for(Identity p:current.identities) {
                    if(p.state().equals("Conflicto"))continue;
                    if(!p.state().equals("Nueva"))continue;
                    CatalogEntity e=new CatalogEntity();e.id=p.id();e.kind=p.original().getString("kind");e.name=p.original().getString("canonical_name").trim();e.createdAt=now;e.notes="Importado del catálogo «"+plan.options.source()+"». Campos originales en su instantánea.";dao.insertEntity(e);
                    for(String name:p.aliases())if(!name.equals(e.name)){EntityAlias a=new EntityAlias();a.entityId=e.id;a.name=name;dao.insertAlias(a);}
                    for(JSONObject r:references.getOrDefault(p.original().getLong("id"),List.of())) {
                        EntityReference ref=new EntityReference();ref.entityId=e.id;ref.provider=r.getString("provider");ref.externalId=r.getString("external_id");dao.putEntityReference(ref);
                    }
                }
                for(MediaEntityLink link:current.links)dao.insertEntityLink(link);
                for(Affiliation a:current.affiliations)if(a.state().equals("Nueva")){AgencyStore.validate(a.row(),dao);dao.putMembership(a.row());}
                EntityStore.validateNames(dao);
                for(ListPlan p:current.lists)if(p.state().equals("Nueva")) {
                    Playlist list=new Playlist();list.id=p.id();list.name=p.original().getString("name").trim();list.createdAt=now;dao.insertPlaylist(list);int index=0;
                    for(String media:p.media()){PlaylistItem item=new PlaylistItem();item.playlistId=list.id;item.mediaId=media;item.position=index++;dao.insertPlaylistItem(item);}
                }
                PublicationCatalog.apply(dao,current.tracking);
                CatalogSnapshot snapshot=new CatalogSnapshot();snapshot.id=key(plan.options.source(),"snapshot","");snapshot.label=plan.options.source();snapshot.payload=plan.transfer.encoded();snapshot.importedAt=now;
                CatalogSnapshot old=dao.snapshot(snapshot.id);JSONObject bindings=old==null?new JSONObject():new JSONObject(old.bindings),kept=new JSONObject();
                for(Asset a:current.assets){if(!a.mediaId().isEmpty())kept.put(Long.toString(a.id()),a.mediaId());else if(bindings.has(Long.toString(a.id())))kept.put(Long.toString(a.id()),bindings.getString(Long.toString(a.id())));}
                snapshot.bindings=kept.toString();
                if(dao.snapshot(snapshot.id)==null && dao.snapshotCount()>=20)throw CatalogTransfer.invalid("Máximo 20 catálogos de origen.");dao.putSnapshot(snapshot);
                CatalogMetadata.sync(db.getOpenHelper().getWritableDatabase(),snapshot);
            }catch(JSONException e){throw new IllegalArgumentException("Catálogo inválido.",e);}
        });
    }
}
