package com.peach.local;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName="catalog_entities")
public class CatalogEntity {
    @PrimaryKey @NonNull public String id="";
    @NonNull public String kind="";
    @NonNull public String name="";
    @NonNull public String notes="";
    public boolean favorite;
    public long createdAt;
}
