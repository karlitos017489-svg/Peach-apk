package com.peach.local;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

/** Exact imported terms, not inferred canonical identities or automatic merges. */
public final class CatalogIndex {
    public record Facet(String key,String label) {}
    public record Term(String value,int count) {}
    public static final List<Facet> FACETS=List.of(
        new Facet("actors","Reparto"),new Facet("studio","Estudios"),new Facet("artists","Artistas musicales"),
        new Facet("directors","Dirección"),new Facet("series","Series"),new Facet("collection","Colecciones"),
        new Facet("tags","Etiquetas"),new Facet("genres","Géneros"),new Facet("year","Años"),new Facet("creators","Creadores"));
    private CatalogIndex() {}
    public static List<String> values(MediaEntry entry,String facet) {
        if(!FACETS.stream().anyMatch(f->f.key().equals(facet)))return List.of();
        Set<String> values=new LinkedHashSet<>(localValues(entry,facet));
        if(!facet.equals("tags") || entry.userTags==null)values.addAll(entry.catalog().values(facet));
        return List.copyOf(values);
    }
    public static List<String> localValues(MediaEntry entry,String facet) {
        if(!FACETS.stream().anyMatch(f->f.key().equals(facet)))return List.of();
        if(!facet.equals("tags") || entry.userTags==null) {
            List<String> terms=entry.importedTerms().get(facet);if(terms!=null)return terms;
        }
        String raw=switch(facet) {
            case "actors"->entry.actors;case "studio"->entry.studio;case "tags"->entry.userTags==null?entry.tags:entry.userTags;
            case "year"->entry.year;
            default->FACETS.stream().anyMatch(f->f.key().equals(facet))?entry.localDetails().getOrDefault(facet,""):"";
        };
        Set<String> values=new LinkedHashSet<>();
        // Series/collection are single NFO fields: punctuation is part of their name.
        for(String value:raw.split(Set.of("series","collection","year").contains(facet)?"\\n":",|\\r?\\n"))
            if(!value.trim().isEmpty())values.add(value.trim());
        return new ArrayList<>(values);
    }
    public static List<Term> terms(List<MediaEntry> media,String facet) {
        var counts=new TreeMap<String,Integer>();
        for(MediaEntry entry:media)for(String value:values(entry,facet))counts.merge(value,1,Integer::sum);
        List<Term> result=new ArrayList<>();counts.forEach((value,count)->result.add(new Term(value,count)));
        result.sort(java.util.Comparator.comparing(Term::value,String.CASE_INSENSITIVE_ORDER).thenComparing(Term::value));
        return result;
    }
    public static List<MediaEntry> select(List<MediaEntry> media,String facet,String value,String group,
            List<MediaGroupItem> membership) {
        Set<String> ids=new java.util.HashSet<>();
        if(!group.isEmpty())for(MediaGroupItem item:membership)if(item.groupId.equals(group))ids.add(item.mediaId);
        List<MediaEntry> result=new ArrayList<>();
        for(MediaEntry entry:media)if((facet.isEmpty() || values(entry,facet).contains(value)) &&
                (group.isEmpty() || ids.contains(entry.id)))result.add(entry);
        return result;
    }
    public static String label(String facet) {
        return FACETS.stream().filter(f->f.key().equals(facet)).map(Facet::label).findFirst().orElse("");
    }
}
