package com.peach.local;

import androidx.sqlite.db.SupportSQLiteDatabase;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;

/** Rebuildable display/search layer. Source snapshots, NFO and user edits remain independent. */
public final class CatalogMetadata {
    public static final int MAX_CACHE_BYTES=512*1024;
    public record Source(String id,String label,long asset,String path,Map<String,String> fields,Map<String,List<String>> terms,boolean partial) {}
    public static final class Projection {
        public final List<Source> sources;
        Projection(List<Source> sources){this.sources=List.copyOf(sources);}
        public boolean partial(){return sources.stream().anyMatch(Source::partial);}
        public String unique(String field){if(partial())return "";Set<String> values=new LinkedHashSet<>();for(Source s:sources){String v=s.fields().getOrDefault(field,"");if(!v.isBlank())values.add(v);}return values.size()==1?values.iterator().next():"";}
        public List<String> values(String facet){Set<String> values=new LinkedHashSet<>();for(Source s:sources)values.addAll(s.terms().getOrDefault(facet,List.of()));return List.copyOf(values);}
        public List<String> conflicts(){List<String> result=new ArrayList<>();for(String field:List.of("title","originalTitle","code","premiered","year","studio","series","region","catalogDurationSeconds","width","height")){Set<String> values=new HashSet<>();for(Source s:sources){String v=s.fields().getOrDefault(field,"");if(!v.isBlank())values.add(v);}if(values.size()>1)result.add(field);}return result;}
        public String search(){StringBuilder text=new StringBuilder();for(Source s:sources){text.append(s.label()).append(' ').append(s.path()).append(' ');for(String value:s.fields().values())text.append(value).append(' ');for(List<String> list:s.terms().values())for(String value:list)text.append(value).append(' ');}return text.toString();}
    }
    private CatalogMetadata() {}
    public static Projection decode(String encoded) {
        List<Source> sources=new ArrayList<>();
        try {JSONArray rows=new JSONArray(encoded);for(int i=0;i<rows.length();i++) {
            JSONObject row=rows.getJSONObject(i);Map<String,String> fields=new LinkedHashMap<>();JSONObject f=row.optJSONObject("fields");if(f!=null){var keys=f.keys();while(keys.hasNext()){String key=keys.next();Object value=f.opt(key);if(value instanceof String v)fields.put(key,v);}}
            Map<String,List<String>> terms=new LinkedHashMap<>();JSONObject t=row.optJSONObject("terms");if(t!=null){var keys=t.keys();while(keys.hasNext()){String key=keys.next();JSONArray a=t.optJSONArray(key);if(a==null)continue;LinkedHashSet<String> values=new LinkedHashSet<>();for(int j=0;j<a.length();j++)if(a.opt(j) instanceof String value && !value.isBlank())values.add(value);terms.put(key,List.copyOf(values));}}
            sources.add(new Source(row.getString("sourceId"),row.getString("sourceLabel"),row.getLong("assetId"),row.optString("path",""),Collections.unmodifiableMap(fields),Collections.unmodifiableMap(terms),row.optBoolean("partial")));
        }}catch(JSONException ignored){return new Projection(List.of());}return new Projection(sources);
    }
    private static void field(JSONObject fields,JSONObject asset,String original,String target)throws JSONException {Object v=asset.opt(original);if(v!=null && v!=JSONObject.NULL && !v.toString().isBlank())fields.put(target,v.toString().trim());}
    private static void term(JSONObject terms,String facet,String value)throws JSONException {if(value==null || value.isBlank())return;JSONArray a=terms.optJSONArray(facet);if(a==null){a=new JSONArray();terms.put(facet,a);}a.put(value.trim());}
    private static String year(String date){try{if(date.matches("\\d{4}"))return java.time.Year.parse(date).toString();if(date.matches("\\d{4}-\\d{2}"))return Integer.toString(java.time.YearMonth.parse(date).getYear());if(date.matches("\\d{4}-\\d{2}-\\d{2}"))return Integer.toString(java.time.LocalDate.parse(date).getYear());}catch(java.time.DateTimeException ignored){}return "";}
    static Map<String,List<JSONObject>> project(CatalogSnapshot snapshot)throws JSONException {
        JSONObject tables=new JSONObject(snapshot.payload).getJSONObject("tables"),bindings=new JSONObject(snapshot.bindings);Map<String,List<JSONObject>> result=new LinkedHashMap<>();Map<Long,JSONObject> records=new HashMap<>(),entities=new HashMap<>();
        for(JSONObject e:CatalogTransfer.rows(tables,"entity"))entities.put(e.getLong("id"),e);
        for(JSONObject asset:CatalogTransfer.rows(tables,"asset")) {
            String media=bindings.optString(Long.toString(asset.getLong("id")),"");if(media.isEmpty())continue;
            JSONObject fields=new JSONObject(),terms=new JSONObject();
            for(String[] pair:new String[][]{{"catalog_title","title"},{"original_title","originalTitle"},{"code","code"},{"studio","studio"},{"series","series"},{"creator","creator"},{"release_date","premiered"},{"duration","catalogDurationSeconds"},{"width","width"},{"height","height"},{"region","region"}})field(fields,asset,pair[0],pair[1]);
            String year=year(fields.optString("premiered",""));if(!year.isEmpty())fields.put("year",year);
            for(String[] pair:new String[][]{{"studio","studio"},{"series","series"},{"creator","creators"},{"year","year"}})term(terms,pair[1],fields.optString(pair[0],""));
            JSONObject row=new JSONObject().put("sourceId",snapshot.id).put("sourceLabel",snapshot.label).put("assetId",asset.getLong("id")).put("path",asset.getString("path")).put("fields",fields).put("terms",terms);
            records.put(asset.getLong("id"),row);result.computeIfAbsent(media,k->new ArrayList<>()).add(row);
        }
        for(JSONObject tag:CatalogTransfer.rows(tables,"asset_tag")){JSONObject r=records.get(tag.getLong("asset_id"));if(r!=null)term(r.getJSONObject("terms"),"tags",tag.getString("tag"));}
        for(JSONObject link:CatalogTransfer.rows(tables,"asset_entity")) {
            JSONObject r=records.get(link.getLong("asset_id")),e=entities.get(link.getLong("entity_id"));if(r==null || e==null)continue;
            String role=link.getString("role"),kind=e.getString("kind");
            if(EntityIndex.KINDS.stream().noneMatch(k->k.key().equals(kind)) || !EntityIndex.roles(kind).contains(role))continue;
            String facet=switch(role){case "performer"->"actors";case "creator"->"creators";case "director"->"directors";case "artist"->"artists";case "tag"->"tags";case "genre"->"genres";default->role;};
            term(r.getJSONObject("terms"),facet,e.getString("canonical_name"));
        }
        return result;
    }
    static String bounded(List<JSONObject> input)throws JSONException {
        input.sort(Comparator.comparing((JSONObject j)->j.optString("sourceId")).thenComparingLong(j->j.optLong("assetId")));JSONArray output=new JSONArray();int bytes=2;Set<String> partial=new HashSet<>();
        for(JSONObject row:input) {
            int count=row.toString().getBytes(StandardCharsets.UTF_8).length+1;
            if(bytes+count>MAX_CACHE_BYTES-16384){if(!partial.add(row.getString("sourceId")))continue;row=new JSONObject().put("sourceId",row.getString("sourceId")).put("sourceLabel",row.getString("sourceLabel")).put("assetId",row.getLong("assetId")).put("partial",true);}
            output.put(row);bytes+=row.toString().getBytes(StandardCharsets.UTF_8).length+1;
            if(bytes>MAX_CACHE_BYTES)throw new IllegalArgumentException("Demasiadas correspondencias para un documento.");
        }return output.toString();
    }
    /** Caller owns the Room transaction, including snapshot write/restore. */
    public static void sync(SupportSQLiteDatabase db,CatalogSnapshot snapshot)throws JSONException {
        Map<String,List<JSONObject>> additions=project(snapshot);Map<String,String> affected=new LinkedHashMap<>();
        try(var cursor=db.query("SELECT id,catalogMetadata FROM media WHERE catalogMetadata LIKE ?",new Object[]{"%"+snapshot.id+"%"})){while(cursor.moveToNext())affected.put(cursor.getString(0),cursor.getString(1));}
        for(String id:additions.keySet())if(!affected.containsKey(id))try(var cursor=db.query("SELECT catalogMetadata FROM media WHERE id=?",new Object[]{id})){if(cursor.moveToFirst())affected.put(id,cursor.getString(0));}
        for(var entry:affected.entrySet()) {
            List<JSONObject> rows=new ArrayList<>();JSONArray current=new JSONArray(entry.getValue());for(int i=0;i<current.length();i++){JSONObject row=current.getJSONObject(i);if(!snapshot.id.equals(row.optString("sourceId")))rows.add(row);}
            rows.addAll(additions.getOrDefault(entry.getKey(),List.of()));String encoded=bounded(rows);
            if(!entry.getValue().equals(encoded))db.execSQL("UPDATE media SET catalogMetadata=? WHERE id=?",new Object[]{encoded,entry.getKey()});
        }
    }
    public static void rebuild(SupportSQLiteDatabase db) {
        try {
            db.execSQL("UPDATE media SET catalogMetadata='[]' WHERE catalogMetadata!='[]'");
            List<String> ids=new ArrayList<>();try(var cursor=db.query("SELECT id FROM catalog_snapshots ORDER BY id")){while(cursor.moveToNext())ids.add(cursor.getString(0));}
            for(String id:ids)try(var cursor=db.query("SELECT id,label,payload,bindings FROM catalog_snapshots WHERE id=?",new Object[]{id})){if(cursor.moveToFirst()){CatalogSnapshot s=new CatalogSnapshot();s.id=cursor.getString(0);s.label=cursor.getString(1);s.payload=cursor.getString(2);s.bindings=cursor.getString(3);sync(db,s);}}
        }catch(JSONException e){throw new IllegalStateException("No se pudo reconstruir el índice del catálogo.",e);}
    }
}
