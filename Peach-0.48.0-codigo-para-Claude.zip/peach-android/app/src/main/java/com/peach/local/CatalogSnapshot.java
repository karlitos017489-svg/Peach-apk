package com.peach.local;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/** Selected original catalog fields, separate from document grants and playback state. */
@Entity(tableName="catalog_snapshots")
public class CatalogSnapshot {
    public static class Head {
        @NonNull public String id="";
        @NonNull public String label="";
        public long importedAt;
    }
    @PrimaryKey @NonNull public String id="";
    @NonNull public String label="";
    @NonNull public String payload="";
    @NonNull public String bindings="{}";
    public long importedAt;
}
