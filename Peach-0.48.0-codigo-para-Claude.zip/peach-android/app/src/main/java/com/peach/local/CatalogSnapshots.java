package com.peach.local;

import java.util.HashSet;
import org.json.*;

public final class CatalogSnapshots {
    private CatalogSnapshots() {}
    public static JSONArray backup(LibraryDao dao) throws JSONException {
        JSONArray rows=new JSONArray();if(dao.snapshotCount()>20)throw CatalogTransfer.invalid("Demasiados catálogos.");long bytes=0;
        for(CatalogSnapshot.Head head:dao.snapshotHeads()) {
            CatalogSnapshot s=dao.snapshot(head.id);bytes+=s.payload.getBytes(java.nio.charset.StandardCharsets.UTF_8).length+s.bindings.getBytes(java.nio.charset.StandardCharsets.UTF_8).length;
            if(bytes>8*1024*1024)throw CatalogTransfer.invalid("Copia demasiado grande.");
            rows.put(new JSONObject().put("id",s.id).put("label",s.label).put("payload",new JSONObject(s.payload)).put("bindings",new JSONObject(s.bindings)).put("importedAt",s.importedAt));
        }return rows;
    }
    public static void restore(LibraryDao dao,JSONObject backup) throws JSONException {
        JSONArray rows=backup.getJSONArray("catalogSnapshots");if(rows.length()>20)throw CatalogTransfer.invalid("Demasiados catálogos.");HashSet<String> ids=new HashSet<>();
        for(int i=0;i<rows.length();i++) {
            JSONObject row=rows.getJSONObject(i);CatalogSnapshot s=new CatalogSnapshot();s.label=PlaylistStore.validName(CatalogTransfer.string(row,"label",true,80),80);s.id=CatalogTransfer.string(row,"id",true,100);
            if(!s.id.equals(CatalogBridge.key(s.label,"snapshot","")) || !ids.add(s.id))throw CatalogTransfer.invalid("Catálogo duplicado o inválido.");
            s.importedAt=CatalogTransfer.integer(row,"importedAt");s.payload=CatalogTransfer.validate(row.getJSONObject("payload")).encoded();
            s.bindings=bindings(row.getJSONObject("bindings"),CatalogTransfer.validate(row.getJSONObject("payload"))).toString();
            if(dao.snapshot(s.id)==null && dao.snapshotCount()>=20)throw CatalogTransfer.invalid("Máximo 20 catálogos.");dao.putSnapshot(s);
        }
    }
    static JSONObject bindings(JSONObject raw,CatalogTransfer transfer)throws JSONException {
        HashSet<String> assets=new HashSet<>();for(JSONObject row:CatalogTransfer.rows(transfer.json().getJSONObject("tables"),"asset"))assets.add(Long.toString(row.getLong("id")));
        JSONObject clean=new JSONObject();var keys=raw.keys();while(keys.hasNext()){String id=keys.next();if(!assets.contains(id))throw CatalogTransfer.invalid("Correspondencia sin asset.");clean.put(id,CatalogTransfer.string(raw,id,true,32768));}return clean;
    }
}
