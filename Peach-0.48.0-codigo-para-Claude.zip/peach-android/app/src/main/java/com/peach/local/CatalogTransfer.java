package com.peach.local;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;

/** Explicit, bounded projection of the fixed upstream schema. No SQL or source credentials exported. */
public final class CatalogTransfer {
    public static final int MAX_BYTES=4*1024*1024;
    public static final long MAX_DATABASE=128L*1024*1024;
    static final Map<String,List<String>> COLUMNS=new LinkedHashMap<>();
    static {
        COLUMNS.put("asset",List.of("id","location","path","name","medium","size","creator","studio","series","code","duration","width","height","catalog_title","original_title","release_date","region"));
        COLUMNS.put("asset_tag",List.of("asset_id","tag","confidence","source"));
        COLUMNS.put("entity",List.of("id","kind","canonical_name"));
        COLUMNS.put("entity_alias",List.of("entity_id","alias","source","confidence"));
        COLUMNS.put("entity_external_ref",List.of("entity_id","provider","external_kind","external_id"));
        COLUMNS.put("asset_entity",List.of("asset_id","entity_id","role","source","confidence"));
        COLUMNS.put("playlist",List.of("id","profile_id","name","source_kind"));
        COLUMNS.put("playlist_item",List.of("playlist_id","asset_id","position"));
        COLUMNS.put("entity_membership",List.of("member_id","agency_id","source","confidence","checked_at"));
        COLUMNS.put("follow_source",List.of("id","entity_id","provider","ref","label","url","semantics"));
        COLUMNS.put("follow_item",List.of("id","source_id","external_id","title","url","published_at","published_precision","release_key","variant_kind","variant_label","status","asset_id","first_seen_at"));
        COLUMNS.put("want_item",List.of("id","code","code_key","follow_item_id","origin","title","link","release_date","state","search_count","last_search_at","last_search_outcome","last_search_note","acquired_asset_id","acquired_at","acquired_source","acquired_batch","created_at","updated_at"));
    }
    private final String encoded;
    private CatalogTransfer(JSONObject json) throws JSONException {encoded=json.toString();if(encoded.getBytes(StandardCharsets.UTF_8).length>MAX_BYTES)throw invalid("Catálogo mayor de 4 MiB; divide el catálogo de intercambio.");}
    public JSONObject json(){try{return new JSONObject(encoded);}catch(JSONException e){throw new AssertionError(e);}}
    public String encoded(){return encoded;}
    static IllegalArgumentException invalid(String text){return new IllegalArgumentException(text);}
    static String string(JSONObject row,String key,boolean required,int max) throws JSONException {
        Object value=row.opt(key);if(value==null || value==JSONObject.NULL){if(required)throw invalid("Falta "+key);return "";}
        if(!(value instanceof String s) || s.length()>max || (required && s.trim().isEmpty()) || s.indexOf('\0')>=0)throw invalid("Campo inválido: "+key);
        return s;
    }
    static long integer(JSONObject row,String key) {
        Object v=row.opt(key);if(!(v instanceof Number n) || !(v instanceof Integer || v instanceof Long) || n.longValue()<0)throw invalid("Entero inválido: "+key);return n.longValue();
    }
    public static CatalogTransfer parse(InputStream input) throws Exception {
        ByteArrayOutputStream data=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int n;
        while((n=input.read(buffer))!=-1){if(data.size()+n>MAX_BYTES)throw invalid("Catálogo mayor de 4 MiB.");data.write(buffer,0,n);}
        String text=StandardCharsets.UTF_8.newDecoder().onMalformedInput(java.nio.charset.CodingErrorAction.REPORT).onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT).decode(java.nio.ByteBuffer.wrap(data.toByteArray())).toString();
        return validate(new JSONObject(text));
    }
    public static CatalogTransfer validate(JSONObject input) throws JSONException {
        if(!"peach-catalog-transfer".equals(input.opt("format")) || integer(input,"version")!=1)throw invalid("Intercambio incompatible.");
        JSONObject tables=input.getJSONObject("tables"),clean=new JSONObject(),result=new JSONObject();
        Set<Long> assets=new HashSet<>(),entities=new HashSet<>(),lists=new HashSet<>();int total=0;
        for(var entry:COLUMNS.entrySet()) {
            String table=entry.getKey();JSONArray rows=tables.optJSONArray(table);if(rows==null && List.of("entity_membership","follow_source","follow_item","want_item").contains(table) && !tables.has(table))rows=new JSONArray();if(rows==null)throw invalid("Falta tabla: "+table);
            int max=table.equals("asset")?50000:List.of("entity","want_item","follow_source").contains(table)?5000:table.equals("follow_item")?10000:table.equals("playlist")?1000:50000;
            if(rows.length()>max)throw invalid("Demasiados registros: "+table);JSONArray output=new JSONArray();
            Set<String> keys=new HashSet<>();
            for(int i=0;i<rows.length();i++) {
                JSONObject row=rows.getJSONObject(i),copy=new JSONObject();total++;if(total>150000)throw invalid("Demasiados registros.");
                for(String column:entry.getValue()) {
                    Object value=row.opt(column);if(value==null || value==JSONObject.NULL){copy.put(column,JSONObject.NULL);continue;}
                    if(column.equals("id") || column.endsWith("_id") && !column.equals("profile_id") && !column.equals("external_id") || List.of("size","width","height","position","search_count").contains(column)) {
                        copy.put(column,integer(row,column));
                    }else if(column.equals("confidence") || column.equals("duration")) {
                        if(!(value instanceof Number n) || !Double.isFinite(n.doubleValue()) || n.doubleValue()<0 || column.equals("confidence") && n.doubleValue()>1)throw invalid("Número inválido: "+column);
                        copy.put(column,value);
                    }else copy.put(column,string(row,column,false,4096));
                }
                switch(table) {
                    case "asset" -> {long id=integer(copy,"id");if(!assets.add(id))throw invalid("Asset duplicado.");string(copy,"path",true,4096);string(copy,"location",true,4096);}
                    case "entity" -> {long id=integer(copy,"id");if(!entities.add(id))throw invalid("Identidad duplicada.");string(copy,"kind",true,80);EntityStore.name(string(copy,"canonical_name",true,300));}
                    case "playlist" -> {long id=integer(copy,"id");if(!lists.add(id))throw invalid("Lista duplicada.");PlaylistStore.validName(string(copy,"name",true,80),80);string(copy,"profile_id",true,300);}
                    case "asset_tag" -> {integer(copy,"asset_id");string(copy,"tag",true,300);}
                    case "entity_alias" -> {integer(copy,"entity_id");EntityStore.name(string(copy,"alias",true,300));}
                    case "entity_external_ref" -> {integer(copy,"entity_id");PlaylistStore.validName(string(copy,"provider",true,80),80);string(copy,"external_kind",true,80);EntityStore.name(string(copy,"external_id",true,300));}
                    case "asset_entity" -> {integer(copy,"asset_id");integer(copy,"entity_id");string(copy,"role",true,80);}
                    case "playlist_item" -> {integer(copy,"playlist_id");integer(copy,"asset_id");integer(copy,"position");}
                    case "follow_source" -> {integer(copy,"id");string(copy,"provider",true,300);string(copy,"ref",true,4096);string(copy,"label",true,4096);string(copy,"semantics",true,80);if(!keys.add("id:"+integer(copy,"id")))throw invalid("Fuente duplicada.");}
                    case "follow_item" -> {integer(copy,"id");integer(copy,"source_id");string(copy,"external_id",true,4096);string(copy,"title",true,4096);string(copy,"status",true,80);string(copy,"published_precision",true,80);if(!keys.add("id:"+integer(copy,"id")))throw invalid("Publicación duplicada.");}
                    case "want_item" -> {integer(copy,"id");string(copy,"origin",true,80);string(copy,"state",true,80);integer(copy,"search_count");if(!keys.add("id:"+integer(copy,"id")))throw invalid("Deseo duplicado.");}
                    case "entity_membership" -> {long member=integer(copy,"member_id");integer(copy,"agency_id");string(copy,"source",true,300);string(copy,"checked_at",true,100);if(!(copy.opt("confidence") instanceof Number))throw invalid("Falta confianza de afiliación.");if(!keys.add("member:"+member))throw invalid("Afiliación duplicada.");}
                }
                // Rows with multiple upstream evidence sources are retained; exact duplicates rejected.
                if(!keys.add(copy.toString()))throw invalid("Registro duplicado: "+table);output.put(copy);
            }
            clean.put(table,output);
        }
        for(String table:List.of("asset_tag","asset_entity","playlist_item"))for(JSONObject row:rows(clean,table))if(!assets.contains(integer(row,"asset_id")))throw invalid("Relación sin asset.");
        for(String table:List.of("entity_alias","entity_external_ref","asset_entity"))for(JSONObject row:rows(clean,table))if(!entities.contains(integer(row,"entity_id")))throw invalid("Relación sin identidad.");
        for(JSONObject row:rows(clean,"playlist_item"))if(!lists.contains(integer(row,"playlist_id")))throw invalid("Miembro sin lista.");
        for(JSONObject row:rows(clean,"entity_membership"))if(!entities.contains(integer(row,"member_id")) || !entities.contains(integer(row,"agency_id")))throw invalid("Afiliación sin identidad.");
        Set<Long> sources=new HashSet<>(),publications=new HashSet<>();
        for(JSONObject row:rows(clean,"follow_source")){sources.add(integer(row,"id"));if(!row.isNull("entity_id") && !entities.contains(integer(row,"entity_id")))throw invalid("Fuente sin identidad.");}
        Set<String> external=new HashSet<>();for(JSONObject row:rows(clean,"follow_item")){publications.add(integer(row,"id"));if(!sources.contains(integer(row,"source_id")))throw invalid("Publicación sin fuente.");if(!external.add(row.getLong("source_id")+"\0"+row.getString("external_id")))throw invalid("Publicación externa duplicada.");}
        for(JSONObject row:rows(clean,"want_item"))if(!row.isNull("follow_item_id") && !publications.contains(integer(row,"follow_item_id")))throw invalid("Deseo sin publicación.");
        result.put("format","peach-catalog-transfer");result.put("version",1);result.put("tables",clean);return new CatalogTransfer(result);
    }
    static List<JSONObject> rows(JSONObject tables,String table) throws JSONException {
        JSONArray a=tables.getJSONArray(table);List<JSONObject> result=new ArrayList<>();for(int i=0;i<a.length();i++)result.add(a.getJSONObject(i));return result;
    }
    public static CatalogTransfer fromDatabase(File file) throws Exception {
        if(file.length()>MAX_DATABASE)throw invalid("Base mayor de 128 MiB.");
        try(InputStream in=new FileInputStream(file)) {
            byte[] header=new byte[20];int offset=0,n;while(offset<header.length && (n=in.read(header,offset,header.length-offset))>0)offset+=n;
            if(offset!=20 || !Arrays.equals(Arrays.copyOf(header,16),"SQLite format 3\0".getBytes(StandardCharsets.US_ASCII)))throw invalid("No es una base SQLite.");
            if(header[18]!=1 || header[19]!=1)throw invalid("Se requiere una copia SQLite autónoma en modo DELETE; no una base activa que dependa de WAL.");
        }
        JSONObject tables=new JSONObject();int bytes=0;
        try(SQLiteDatabase db=SQLiteDatabase.openDatabase(file.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY|SQLiteDatabase.NO_LOCALIZED_COLLATORS)) {
            try(Cursor check=db.rawQuery("PRAGMA quick_check(1)",null)){if(!check.moveToFirst() || !"ok".equals(check.getString(0)))throw invalid("La base no pasó su comprobación de integridad.");}
            for(var entry:COLUMNS.entrySet()) {
                String table=entry.getKey();boolean exists=false;
                try(Cursor schema=db.rawQuery("SELECT type,sql FROM sqlite_master WHERE name=?",new String[]{table})) {
                    if(schema.moveToFirst()) {
                        if(!"table".equals(schema.getString(0)) || schema.getString(1)==null || !schema.getString(1).toUpperCase(Locale.ROOT).startsWith("CREATE TABLE"))throw invalid("Se requieren tablas ordinarias: "+table);
                        exists=true;
                    }
                }
                JSONArray rows=new JSONArray();tables.put(table,rows);
                if(!exists){if(table.equals("asset"))throw invalid("Falta la tabla asset original.");continue;}
                Set<String> present=new HashSet<>();try(Cursor columns=db.rawQuery("PRAGMA table_info(\""+table+"\")",null)){while(columns.moveToNext())present.add(columns.getString(1));}
                List<String> chosen=new ArrayList<>();for(String column:entry.getValue())if(present.contains(column))chosen.add(column);
                if(chosen.isEmpty())throw invalid("Esquema incompatible: "+table);
                String projection=String.join(",",chosen.stream().map(c->"\""+c+"\"").toArray(String[]::new));
                try(Cursor cursor=db.rawQuery("SELECT "+projection+" FROM \""+table+"\" LIMIT 50002",null)) {
                    while(cursor.moveToNext()) {
                        JSONObject row=new JSONObject();
                        for(int i=0;i<chosen.size();i++) {
                            Object value=switch(cursor.getType(i)){case Cursor.FIELD_TYPE_NULL->JSONObject.NULL;case Cursor.FIELD_TYPE_INTEGER->cursor.getLong(i);case Cursor.FIELD_TYPE_FLOAT->cursor.getDouble(i);case Cursor.FIELD_TYPE_STRING->cursor.getString(i);default->throw invalid("Campo binario incompatible.");};
                            if(value instanceof String s && s.length()>4096)throw invalid("Campo demasiado largo.");row.put(chosen.get(i),value);
                        }
                        bytes+=row.toString().getBytes(StandardCharsets.UTF_8).length;if(bytes>MAX_BYTES)throw invalid("Catálogo mayor de 4 MiB.");rows.put(row);
                    }
                }
            }
        }
        return validate(new JSONObject().put("format","peach-catalog-transfer").put("version",1).put("tables",tables));
    }
    public static CatalogTransfer open(android.content.Context context,android.net.Uri uri) throws Exception {
        File copy=File.createTempFile("peach-catalog-",".tmp",context.getCacheDir());
        try {
            try(InputStream in=context.getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(copy)) {
                if(in==null)throw new IOException("Archivo no disponible.");byte[] b=new byte[65536];long total=0;int n;
                while((n=in.read(b))!=-1){total+=n;if(total>MAX_DATABASE)throw invalid("Archivo mayor de 128 MiB.");out.write(b,0,n);if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();}
            }
            try(InputStream in=new BufferedInputStream(new FileInputStream(copy))){int first;do{first=in.read();}while(first>=0 && Character.isWhitespace(first));if(first=='{'){try(InputStream json=new FileInputStream(copy)){return parse(json);}}}
            return fromDatabase(copy);
        }finally{SQLiteDatabase.deleteDatabase(copy);}
    }
}
