package com.peach.local;

import android.media.*;
import android.os.SystemClock;
import java.io.*;

/** Decode a frame into a buffer from the app's own tiny fixture. No AudioTrack, surface or network. */
final class CheckMedia {
    static String decode(File file,String mime,DeviceChecks.Token token)throws Exception {
        MediaExtractor extractor=new MediaExtractor();MediaCodec codec=null;
        try{extractor.setDataSource(file.getAbsolutePath());int track=-1;MediaFormat format=null;
            for(int i=0;i<extractor.getTrackCount();i++){MediaFormat f=extractor.getTrackFormat(i);if(mime.equals(f.getString(MediaFormat.KEY_MIME))){track=i;format=f;break;}}
            if(track<0)throw new IOException("La muestra no contiene la pista esperada.");token.check();extractor.selectTrack(track);
            codec=MediaCodec.createDecoderByType(mime);String name=codec.getName();codec.configure(format,null,null,0);codec.start();
            MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();boolean eof=false;long deadline=SystemClock.elapsedRealtime()+20000;
            while(SystemClock.elapsedRealtime()<deadline){token.check();
                if(!eof){int input=codec.dequeueInputBuffer(10000);if(input>=0){var buffer=codec.getInputBuffer(input);if(buffer==null)throw new IOException("Buffer no disponible.");int size=extractor.readSampleData(buffer,0);if(size<0){codec.queueInputBuffer(input,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM);eof=true;}else{codec.queueInputBuffer(input,0,size,extractor.getSampleTime(),0);extractor.advance();}}}
                int output=codec.dequeueOutputBuffer(info,10000);if(output>=0){boolean decoded=info.size>0&&(info.flags&MediaCodec.BUFFER_FLAG_CODEC_CONFIG)==0;codec.releaseOutputBuffer(output,false);if(decoded){token.check();return name+" · una salida decodificada";}if((info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0)break;}
            }
            throw new java.util.concurrent.TimeoutException("No se comprobó una salida dentro del plazo.");
        }finally{try{if(codec!=null)codec.release();}finally{extractor.release();}}
    }
}
