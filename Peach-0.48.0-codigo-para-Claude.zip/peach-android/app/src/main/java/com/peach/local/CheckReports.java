package com.peach.local;

import android.content.Context;
import android.net.Uri;
import android.util.AtomicFile;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;

/** Private last result; user explicitly chooses whether and where to export its non-secret contents. */
final class CheckReports {
    private final AtomicFile last;
    CheckReports(Context context){last=new AtomicFile(new File(context.getNoBackupFilesDir(),"peach-device-check/last.json"));}
    synchronized void save(DeviceChecks.Report report)throws IOException {byte[] bytes=report.json().getBytes(StandardCharsets.UTF_8);if(bytes.length>DeviceChecks.MAX_REPORT)throw new IOException();FileOutputStream out=last.startWrite();try{out.write(bytes);last.finishWrite(out);}catch(Exception e){last.failWrite(out);throw new IOException("No se pudo conservar el informe.");}}
    synchronized DeviceChecks.Report load()throws IOException {
        try(InputStream in=last.openRead()){String json=new String(DeviceChecks.read(in,DeviceChecks.MAX_REPORT),StandardCharsets.UTF_8);JSONObject root=new JSONObject(json);if(!root.getString("format").equals("peach-device-check")||root.getInt("version")!=1)throw new IOException();JSONArray array=root.getJSONArray("checks");if(array.length()>8)throw new IOException();List<DeviceChecks.Row> rows=new ArrayList<>();for(int i=0;i<array.length();i++){JSONObject x=array.getJSONObject(i);rows.add(new DeviceChecks.Row(x.getString("key"),x.getString("label"),x.getString("state"),x.getString("detail")));}return new DeviceChecks.Report(json,rows,root.getBoolean("cancelled"));}
        catch(FileNotFoundException e){return null;}catch(JSONException e){throw new IOException("No se pudo leer el último informe.");}
    }
    static void export(Context context,Uri uri,DeviceChecks.Report report)throws Exception {
        ExchangeDocuments.selected(uri);byte[] expected=report.json().getBytes(StandardCharsets.UTF_8);if(expected.length>DeviceChecks.MAX_REPORT)throw new IOException();boolean done=false;
        try{try(OutputStream out=context.getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException();out.write(expected);}
            try(InputStream in=context.getContentResolver().openInputStream(uri)){if(!Arrays.equals(expected,DeviceChecks.read(in,DeviceChecks.MAX_REPORT)))throw new IOException("Informe incompleto.");}done=true;
        }finally{if(!done)SourcesActivity.Draft.discardCreated(context,uri);}
    }
}
