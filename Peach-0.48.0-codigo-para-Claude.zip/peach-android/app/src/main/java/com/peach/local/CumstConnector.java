package com.peach.local;

import java.io.*;
import java.time.*;
import java.util.*;
import org.json.*;

/** Independently implemented, bounded OnlyHaven API subset. No auth, DMs or media probes. */
public final class CumstConnector {
    private final SourceHttp.Transport http;
    public CumstConnector(SourceHttp.Transport http){this.http=http;}
    public SourcePage list(String ref,int index,String etag,String modified,SourceHttp.Token token)throws IOException {
        try {
            var response=http.get(CumstUrls.page(ref,index),etag,modified,token);token.check();
            if(response.status()==304)return new SourcePage(new JSONArray(),etag,modified,0,true);
            if(response.status()!=200)throw new IOException("Estado HTTP de lista cum.st no válido; caché conservada.");
            JSONObject data=object(response);JSONArray posts=data.getJSONArray("posts");if(posts.length()>50)throw new IOException("Más de50 publicaciones cum.st; página no guardada parcialmente.");
            JSONArray rows=new JSONArray();Set<String> ids=new HashSet<>();
            for(int i=0;i<posts.length();i++){
                JSONObject post=posts.getJSONObject(i);check(ref,post,null);String id=CumstUrls.id(post.opt("id"));if(!ids.add(id))throw new IOException("Publicación cum.st repetida.");
                JSONObject body=content(post,false);String title=caption(post).split("[\r\n]",2)[0].trim();if(title.isBlank())title="cum.st #"+id;
                String[] date=date(post.opt("published"));
                rows.put(new JSONObject().put("id",id).put("title",FanboxConnector.clipped(title,300)).put("date",date[0]).put("precision",date[1]).put("url",CumstUrls.postUrl(ref,id)).put("text",body.getString("text")).put("attachments",body.getJSONArray("attachments")).put("type","list").put("partial",true));
            }
            return new SourcePage(rows,SourceHttp.header(response.etag()),SourceHttp.header(response.modified()),0,false);
        }catch(JSONException | IllegalArgumentException e){throw new IOException("Formato o identidad cum.st no válido; caché conservada.",e);}
    }
    public JSONObject detail(String ref,String id,SourceHttp.Token token)throws IOException {
        try{var response=http.get(CumstUrls.detail(ref,id),"","",token);token.check();if(response.status()!=200)throw new IOException("Estado HTTP de cuerpo cum.st no válido.");JSONObject post=object(response);check(ref,post,id);return content(post,true);}catch(JSONException | IllegalArgumentException e){throw new IOException("Cuerpo cum.st con formato o identidad no válido.",e);}
    }
    static JSONObject object(SourceHttp.Response response)throws IOException{if(response.bytes().length>SourceHttp.JSON_LIMIT)throw new IOException("JSON cum.st mayor de2MiB.");try{JSONTokener parser=new JSONTokener(SourceHttp.utf8(response.bytes()));Object value=parser.nextValue();if(parser.nextClean()!=0 || !(value instanceof JSONObject))throw new JSONException("Objeto JSON requerido");return (JSONObject)value;}catch(JSONException e){throw new IOException("La fuente no devolvió JSON cum.st; caché conservada.",e);}}
    static void check(String ref,JSONObject post,String expected)throws IOException{String[] p=CumstUrls.creator(ref).split("/",2);String id=CumstUrls.id(post.opt("id"));if(!p[0].equals(post.opt("service")) || post.has("creatorId") && !post.isNull("creatorId") && !p[1].equals(CumstUrls.id(post.opt("creatorId"))) || expected!=null && !id.equals(expected))throw new IOException("Publicación cum.st de otro servicio, creador o ID.");}
    static String text(JSONObject post,String key)throws JSONException{if(!post.has(key) || post.isNull(key))return "";Object value=post.get(key);if(!(value instanceof String text))throw new JSONException("Texto requerido");return text.replace("\0","");}
    static String caption(JSONObject post)throws JSONException{String html=text(post,"captionHtml");return html.isBlank()?text(post,"caption"):PawchiveConnector.plain(html);}
    static String[] date(Object raw){String value=raw==null || raw==JSONObject.NULL?"":raw.toString();try{if(value.matches("[0-9]{1,12}")){long seconds=Long.parseLong(value);if(seconds>0 && seconds<=253402300799L)return new String[]{Instant.ofEpochSecond(seconds).toString(),"exact"};}else {try{return new String[]{OffsetDateTime.parse(value).toString(),"exact"};}catch(Exception ignored){try{return new String[]{LocalDateTime.parse(value).toString(),"approximate"};}catch(Exception ignored2){return new String[]{LocalDate.parse(value).toString(),"approximate"};}}}}catch(Exception ignored){}return new String[]{"","unknown"};}
    record Variant(String name,String url,String kind,long bytes,String role,int height) {}
    static String kind(String name){String ext=MediaRules.extension(name);return Set.of("jpg","jpeg","png","gif","bmp","webp").contains(ext)?"image":Set.of("mp4","webm","mov","m4v","mkv").contains(ext)?"video":"file";}
    static JSONObject content(JSONObject post,boolean detail)throws JSONException,IOException {
        JSONArray out=new JSONArray(),items=post.optJSONArray("attachments");if(post.has("attachments") && !post.isNull("attachments") && items==null)throw new IOException("Adjuntos cum.st no válidos.");if(items!=null && items.length()>100)throw new IOException("Más de100 adjuntos cum.st.");Set<String> seen=new HashSet<>();boolean omitted=false;List<JSONObject> extras=new ArrayList<>();
        if(items!=null)for(int i=0;i<items.length();i++){
            JSONObject file=items.getJSONObject(i);if(file.has("locked") && !(file.opt("locked") instanceof Boolean))throw new IOException("Estado de adjunto cum.st no válido.");
            if(file.optBoolean("locked",false)){omitted=true;continue;}
            JSONArray variants=file.optJSONArray("variants");if(variants==null || variants.length()==0){omitted=true;continue;}if(variants.length()>32)throw new IOException("Demasiadas variantes de un adjunto cum.st.");
            String original=text(file,"originalFilename"),storage=text(file,"storageKey"),group=PartialDownload.key(storage+"\0"+original);List<Variant> valid=new ArrayList<>();
            for(int n=0;n<variants.length();n++){JSONObject row=variants.getJSONObject(n);Object raw=row.opt("bytes");long bytes=0;if(raw!=null&&raw!=JSONObject.NULL){if(!(raw instanceof Number)||!raw.toString().matches("[0-9]{1,18}"))throw new IOException("Tamaño de variante cum.st no válido.");bytes=Long.parseLong(raw.toString());}
                if(row.has("locked")&&!(row.opt("locked") instanceof Boolean))throw new IOException("Estado de variante cum.st no válido.");if(row.optBoolean("locked",false)){omitted=true;continue;}String name;try{name=text(row,"name");String url=CumstUrls.media(storage,name);String kind=kind(name);if(kind.equals("file")&&(MediaRules.extension(name).isEmpty()||Set.of("bin","dat").contains(MediaRules.extension(name)))&&!kind(original).equals("file"))kind=kind(original);valid.add(new Variant(name,url,kind,bytes,VideoVariants.preview(name)?"preview":"unknown",VideoVariants.height(name)));}catch(IllegalArgumentException|JSONException e){omitted=true;}
            }
            if(valid.isEmpty()){omitted=true;continue;}List<Variant> video=valid.stream().filter(v->v.kind().equals("video")).toList();
            List<Variant> chosen;if(video.isEmpty())chosen=List.of(valid.stream().max(Comparator.comparingLong(Variant::bytes)).orElseThrow());else{chosen=new ArrayList<>(video);chosen.sort((x,y)->-VideoVariants.compare(new VideoVariants.Info(x.role(),x.height(),x.bytes(),group),new VideoVariants.Info(y.role(),y.height(),y.bytes(),group)));}
            for(int n=0;n<chosen.size();n++){Variant v=chosen.get(n);String base=original.isBlank()?v.name():original;String ext=MediaRules.extension(v.name());if(!SourceFiles.mime(v.name()).equals("application/octet-stream"))base=MediaRules.stem(base)+"."+ext;
                if(chosen.size()>1){String stem=FanboxConnector.clipped(MediaRules.stem(base),110);base=stem+" · v"+(n+1)+(ext.isEmpty()?"":"."+ext);}String name=FanboxConnector.clipped(base.replaceAll("[\\p{Cntrl}]","_"),140);
                JSONObject attachment=new JSONObject().put("name",name).put("url",v.url()).put("kind",v.kind()).put("downloadable",true);if(v.kind().equals("video")){VideoVariants.mark(attachment,v.role(),v.height(),v.bytes(),group);Variant cover=valid.stream().filter(t->t.kind().equals("image")).min(Comparator.comparingLong(Variant::bytes)).orElse(null);if(cover!=null)attachment.put("peachPreview",new JSONObject().put("url",cover.url()).put("name",FanboxConnector.clipped(cover.name(),140)));}
                if(n==0){if(seen.add(v.url()))out.put(attachment);}else extras.add(attachment);
            }
        }
        // Preserve one primary per original attachment before spending the existing100-item
        // budget on optional video alternatives. Images/files retain their previous one-file flow.
        for(JSONObject extra:extras){String url=extra.getString("url");if(seen.contains(url))continue;if(out.length()>=FanboxConnector.MAX_ATTACHMENTS){omitted=true;continue;}seen.add(url);out.put(extra);}
        String text=caption(post);int limit=detail?FanboxConnector.MAX_TEXT:4000;String notice=omitted?"\n[Hay adjuntos bloqueados, rutas no compatibles o variantes adicionales omitidas.]":"";if(text.length()+notice.length()>limit)notice="\n[Texto recortado por el límite local.]"+notice;
        return new JSONObject().put("text",FanboxConnector.clipped(text,limit-notice.length())+notice).put("attachments",out).put("type",detail?"cumst-detail":"list").put("partial",true);
    }
}
