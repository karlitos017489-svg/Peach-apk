package com.peach.local;

import java.net.URI;
import java.util.*;

/** OnlyHaven is a distinct provider, never an alias/fallback for another archive. */
public final class CumstUrls {
    private CumstUrls() {}
    static boolean site(String host){return "cum.st".equals(host);}
    static String segment(String value,int max){if(value==null || !value.matches("[A-Za-z0-9_.-]{1,"+max+"}") || value.equals(".") || value.equals(".."))throw new IllegalArgumentException("Identificador cum.st no válido.");return value;}
    static String id(Object value){if(value instanceof Number && !value.toString().matches("[0-9]+"))throw new IllegalArgumentException("ID cum.st no entero.");if(!(value instanceof String) && !(value instanceof Number))throw new IllegalArgumentException("Falta ID cum.st.");return segment(value.toString(),128);}
    public static String creator(String input){
        if(input==null)throw new IllegalArgumentException("Falta servicio/ID de cum.st.");String ref=input.trim();
        if(ref.startsWith("https://")){URI u=SourceHttp.https(ref);if(!site(u.getHost()) || u.getRawQuery()!=null || u.getPort()!=-1)throw new IllegalArgumentException("Usa la página HTTPS del creador cum.st sin parámetros.");String[] p=u.getRawPath().split("/",-1);if(p.length==5 && p[4].isEmpty())p=Arrays.copyOf(p,4);if(p.length!=4 || !p[1].equals("creators"))throw new IllegalArgumentException("Usa la página del creador cum.st.");ref=p[2]+"/"+p[3];}
        String[] p=ref.split("/",-1);if(p.length!=2 || !Set.of("patreon","onlyfans","fansly").contains(p[0]))throw new IllegalArgumentException("cum.st: escribe patreon/ID, onlyfans/ID o fansly/ID; también sirve la página del creador.");return p[0]+"/"+segment(p[1],64);
    }
    public static String page(String ref,int index){String[] p=creator(ref).split("/",2);if(index<0 || index>=5000)throw new IllegalArgumentException("Límite de páginas cum.st alcanzado.");return "https://cum.st/api/v1/"+p[0]+"/user/"+p[1]+"/posts?o="+(index*50)+"&n=50";}
    public static String detail(String ref,String id){String[] p=creator(ref).split("/",2);return "https://cum.st/api/v1/"+p[0]+"/user/"+p[1]+"/post/"+id(id);}
    public static String postUrl(String ref,String id){return "https://cum.st/creators/"+creator(ref)+"/post/"+id(id);}
    static void postUrl(String ref,String url,String id){if(!postUrl(ref,id).equals(url))throw new IllegalArgumentException("Publicación cum.st ajena.");}
    static void api(String raw){URI u=SourceHttp.https(raw);if(!site(u.getHost()))throw new IllegalArgumentException("Host cum.st no válido.");String[] p=u.getRawPath().split("/",-1);if(p.length<7 || !p[1].equals("api") || !p[2].equals("v1") || !p[4].equals("user"))throw new IllegalArgumentException("Ruta cum.st no admitida.");String ref=creator(p[3]+"/"+p[5]);if(p.length==7 && p[6].equals("posts")){String q=u.getRawQuery();if(q==null || !q.matches("o=(0|[1-9][0-9]{0,5})&n=50"))throw new IllegalArgumentException("Página cum.st no válida.");int offset=Integer.parseInt(q.substring(2,q.indexOf('&')));if(offset%50!=0 || !raw.equals(page(ref,offset/50)))throw new IllegalArgumentException("Offset cum.st no canónico.");}else if(p.length!=8 || !p[6].equals("post") || !raw.equals(detail(ref,p[7])))throw new IllegalArgumentException("API cum.st no admitida.");}
    static String media(String storage,String variant){if(storage==null || storage.length()>300)throw new IllegalArgumentException("Ruta de medio cum.st no válida.");String[] parts=storage.split("/",-1);if(parts.length>8)throw new IllegalArgumentException("Ruta de medio cum.st demasiado larga.");for(String part:parts)segment(part,128);segment(variant,160);return "https://e1.cum.st/media/"+storage+"/"+variant;}
    public static boolean downloadable(String raw){try{URI u=SourceHttp.https(raw);String prefix="/media/",path=u.getRawPath();if(!"e1.cum.st".equals(u.getHost()) || u.getRawQuery()!=null || !path.startsWith(prefix))return false;String relative=path.substring(prefix.length());int slash=relative.lastIndexOf('/');return slash>0 && raw.equals(media(relative.substring(0,slash),relative.substring(slash+1)));}catch(IllegalArgumentException e){return false;}}
}
