package com.peach.local;

import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.lifecycle.*;
import androidx.activity.result.contract.ActivityResultContracts;
import java.util.*;
import java.util.concurrent.*;

/** All tests and exports require a button press. Restoring a screen only reads its own previous report. */
public final class DeviceCheckActivity extends PeachActivity {
    interface Runner {DeviceChecks.Report run(Application app,DeviceChecks.Token token,DeviceChecks.Progress progress)throws Exception;}
    static Runner runner=(app,token,progress)->new DeviceChecks(app).run(token,progress);
    public static final class Draft extends AndroidViewModel {
        final ExecutorService worker=Executors.newSingleThreadExecutor();final MutableLiveData<Integer> updates=new MutableLiveData<>(0);final CheckReports reports;
        volatile boolean busy,checking;boolean picking,loaded;DeviceChecks.Token token=new DeviceChecks.Token();DeviceChecks.Report report;List<DeviceChecks.Row> rows=List.of();String status="Pulsa Iniciar comprobación cuando quieras probar esta instalación.";
        public Draft(Application app){super(app);reports=new CheckReports(app);}
        void load(){if(loaded)return;loaded=true;busy=true;worker.execute(()->{try{report=reports.load();if(report!=null){rows=report.rows();status="Último resultado guardado. No se ejecutaron pruebas al abrir esta pantalla.";}}catch(Exception e){status="No se pudo leer el último informe. Puedes iniciar una comprobación nueva.";}finally{busy=false;updates.postValue(1);}});}
        void start(){if(busy||picking)return;busy=true;checking=true;token=new DeviceChecks.Token();report=null;rows=List.of();status="Iniciando comprobación local…";updates.setValue(1);
            worker.execute(()->{try{report=runner.run(getApplication(),token,(done,current)->{rows=done;status=current.isEmpty()?"Comprobando…":"Comprobando: "+current;updates.postValue(1);});rows=report.rows();long passed=rows.stream().filter(r->r.state().equals("passed")).count();status=report.cancelled()?"Comprobación cancelada. Se conserva un resultado parcial.":passed+" de "+rows.size()+" comprobaciones correctas. Revisa el detalle; este resultado solo describe las muestras probadas.";try{reports.save(report);}catch(Exception e){status+=" No se pudo conservar el informe local; puedes intentar guardarlo antes de salir.";}}
                catch(Exception e){status=token.cancelled.get()?"Comprobación cancelada.":"No se pudo terminar la comprobación. Tus archivos se conservan.";}
                finally{busy=false;checking=false;updates.postValue(1);}
            });
        }
        void export(android.net.Uri uri){if(busy||report==null)return;DeviceChecks.Report chosen=report;busy=true;status="Guardando informe…";updates.setValue(1);worker.execute(()->{try{CheckReports.export(getApplication(),uri,chosen);status="Informe guardado y comprobado en el destino elegido.";}catch(Exception e){status="No se pudo verificar el guardado. El informe local se conserva. Si quedó un destino incompleto, revísalo en el proveedor.";}finally{busy=false;updates.postValue(1);}});}
        @Override protected void onCleared(){token.cancel();worker.shutdown();}
    }
    Draft draft;private TextView status;private Button start,cancel,save;private LinearLayout results;private ProgressBar progress;
    private final androidx.activity.result.ActivityResultLauncher<Intent> picker=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),result->{boolean expected=draft.picking;draft.picking=false;if(expected&&result.getResultCode()==RESULT_OK&&result.getData()!=null&&SourceFiles.local(result.getData().getData()))draft.export(result.getData().getData());else{draft.status="Guardado cancelado. El informe local se conserva.";render();}});
    @Override protected void onCreate(Bundle state){super.onCreate(state);draft=new ViewModelProvider(this).get(Draft.class);if(state!=null)draft.picking=state.getBoolean("checkPicking");LinearLayout root=UiAppearance.column(this,"Comprobar funcionamiento");
        TextView help=new TextView(this);help.setText("Comprueba esta instalación con muestras propias de Peach, sin consultar fuentes ni abrir tus archivos. No reproduce sonido. Puedes cancelar.\n\nEl informe incluye modelo, versión de Android y resultados. Tú eliges si quieres guardarlo. No certifica todos los formatos, cuentas o servicios de nube.");root.addView(help);
        start=new Button(this);start.setId(R.id.check_start);start.setText("Iniciar comprobación");start.setOnClickListener(v->draft.start());root.addView(start);
        cancel=new Button(this);cancel.setId(R.id.check_cancel);cancel.setText("Cancelar comprobación");cancel.setOnClickListener(v->{draft.token.cancel();draft.status="Cancelando…";render();});root.addView(cancel);
        progress=new ProgressBar(this);root.addView(progress);status=new TextView(this);status.setId(R.id.check_status);status.setTextIsSelectable(true);root.addView(status);results=new LinearLayout(this);results.setId(R.id.check_results);results.setOrientation(LinearLayout.VERTICAL);root.addView(results);
        save=new Button(this);save.setId(R.id.check_save);save.setText("Guardar informe");save.setOnClickListener(v->{if(draft.busy||draft.report==null||draft.picking)return;draft.picking=true;try{picker.launch(SourceFiles.create("Peach-comprobacion-"+BuildConfig.VERSION_NAME+".json").setType("application/json"));}catch(Exception e){draft.picking=false;draft.status="No se pudo abrir el selector de destino.";render();}});root.addView(save);
        draft.updates.observe(this,n->render());draft.load();render();
    }
    void render(){if(isDestroyed())return;start.setEnabled(!draft.busy&&!draft.picking);cancel.setEnabled(draft.busy&&draft.checking);save.setEnabled(!draft.busy&&!draft.picking&&draft.report!=null);progress.setVisibility(draft.busy?View.VISIBLE:View.GONE);status.setText(draft.status);results.removeAllViews();for(var row:draft.rows){TextView text=new TextView(this);String label=switch(row.state()){case "passed"->"Correcto";case "failed"->"Revisar";case "cancelled"->"Cancelado";default->"No comprobado";};text.setText(label+" · "+row.label()+"\n"+row.detail());text.setTextIsSelectable(true);text.setPadding(0,18,0,18);text.setTextColor(UiAppearance.text(this));results.addView(text);}}
    @Override protected void onStop(){if(!isChangingConfigurations()&&draft.checking)draft.token.cancel();super.onStop();}
    @Override protected void onSaveInstanceState(Bundle state){state.putBoolean("checkPicking",draft.picking);super.onSaveInstanceState(state);}
}
