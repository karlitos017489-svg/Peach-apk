package com.peach.local;

import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.pdf.*;
import android.os.*;
import androidx.room.Room;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Explicit, self-contained checks in fresh private storage and an isolated memory database. */
final class DeviceChecks {
    static final String CERT="9fc537c4c8d0461a8565414c7a30169e592120cd314b500bee7c707f8a748484";
    static final int MAX_REPORT=128*1024;
    static final class Token {final AtomicBoolean cancelled=new AtomicBoolean();volatile RarBook rar;void cancel(){cancelled.set(true);RarBook r=rar;if(r!=null)r.cancel();}void check()throws InterruptedIOException{if(cancelled.get()||Thread.currentThread().isInterrupted())throw new InterruptedIOException("Comprobación cancelada.");}}
    record Row(String key,String label,String state,String detail) {}
    record Report(String json,List<Row> rows,boolean cancelled) {Report{rows=List.copyOf(rows);}}
    interface MediaProbe {String decode(File file,String mime,Token token)throws Exception;}
    interface RarProbe {String read(Context context,File file,File directory,Token token)throws Exception;}
    interface Progress {void update(List<Row> rows,String current);}
    private final Context context;private final MediaProbe media;private final RarProbe rar;private final boolean injected;
    DeviceChecks(Context c){this(c,CheckMedia::decode,DeviceChecks::rar,false);}
    DeviceChecks(Context c,MediaProbe media,RarProbe rar){this(c,media,rar,true);}
    private DeviceChecks(Context c,MediaProbe media,RarProbe rar,boolean injected){this.context=c.getApplicationContext();this.media=media;this.rar=rar;this.injected=injected;}
    interface Check {String run()throws Exception;}
    Report run(Token token,Progress progress)throws Exception {
        File directory=java.nio.file.Files.createTempDirectory(context.getCacheDir().toPath(),"peach-check-").toFile();List<Row> rows=new ArrayList<>();long started=System.currentTimeMillis();
        try{
            step(rows,"installation","Instalación y firma",token,progress,()->installation());
            step(rows,"storage","Archivos temporales",token,progress,()->storage(directory));
            step(rows,"database","Biblioteca de prueba y recuperación",token,progress,()->database(token));
            step(rows,"image","Imagen de muestra",token,progress,()->image(directory));
            step(rows,"pdf","PDF de muestra",token,progress,()->pdf(directory));
            step(rows,"video","Video H.264 de muestra",token,progress,()->media.decode(asset(directory,"sample.mp4"),"video/avc",token));
            step(rows,"audio","Audio AAC de muestra",token,progress,()->media.decode(asset(directory,"sample.mp4"),"audio/mp4a-latm",token));
            step(rows,"rar","RAR5 comprimido de muestra",token,progress,()->rar.read(context,asset(directory,"sample.cbr"),directory,token));
            JSONObject result=new JSONObject().put("format","peach-device-check").put("version",1).put("app",BuildConfig.VERSION_NAME).put("versionCode",BuildConfig.VERSION_CODE).put("sdk",Build.VERSION.SDK_INT).put("android",Build.VERSION.RELEASE).put("manufacturer",Build.MANUFACTURER).put("model",Build.MODEL).put("abis",new JSONArray(Arrays.asList(Build.SUPPORTED_ABIS))).put("startedAt",started).put("finishedAt",System.currentTimeMillis()).put("cancelled",token.cancelled.get()).put("testProbesInjected",injected).put("scope","Muestras propias locales. No comprueba tus archivos, cuentas, red, nube, actualización ni batería. La decodificación a buffer no certifica todos los formatos o la salida física de audio/video.");
            JSONArray list=new JSONArray();for(Row r:rows)list.put(new JSONObject().put("key",r.key).put("label",r.label).put("state",r.state).put("detail",r.detail));result.put("checks",list);
            String json=result.toString(2);if(json.getBytes(StandardCharsets.UTF_8).length>MAX_REPORT)throw new IOException("Informe demasiado grande.");return new Report(json,rows,token.cancelled.get());
        }finally{removeOwn(directory);}
    }
    static void step(List<Row> rows,String key,String label,Token token,Progress progress,Check check){
        if(token.cancelled.get()){rows.add(new Row(key,label,"not_run","No ejecutada tras cancelar."));progress.update(List.copyOf(rows),"");return;}
        progress.update(List.copyOf(rows),label);Row row;
        try{token.check();String detail=check.run();token.check();row=new Row(key,label,"passed",detail);}
        catch(InterruptedIOException e){token.cancel();row=new Row(key,label,"cancelled","Comprobación cancelada.");}
        catch(Exception e){if(token.cancelled.get()||Thread.currentThread().isInterrupted()){token.cancel();row=new Row(key,label,"cancelled","Comprobación cancelada.");}else row=new Row(key,label,e instanceof java.util.concurrent.TimeoutException?"inconclusive":"failed","No se pudo completar esta muestra ("+e.getClass().getSimpleName()+"). No implica incompatibilidad con todos tus archivos.");}
        rows.add(row);progress.update(List.copyOf(rows),"");
    }
    String installation()throws Exception {
        var pm=context.getPackageManager();var info=pm.getPackageInfo(context.getPackageName(),Build.VERSION.SDK_INT>=28?PackageManager.GET_SIGNING_CERTIFICATES:PackageManager.GET_SIGNATURES);
        android.content.pm.Signature[] signatures=Build.VERSION.SDK_INT>=28&&info.signingInfo!=null?info.signingInfo.getApkContentsSigners():info.signatures;
        if(signatures==null||signatures.length!=1||!CERT.equals(GalleryCache.hex(MessageDigest.getInstance("SHA-256").digest(signatures[0].toByteArray()))))throw new IOException("Firma distinta.");
        long code=Build.VERSION.SDK_INT>=28?info.getLongVersionCode():info.versionCode;if(code!=BuildConfig.VERSION_CODE)throw new IOException("Versión distinta.");return "Versión "+BuildConfig.VERSION_NAME+" · certificado original comprobado";
    }
    static String storage(File directory)throws Exception {byte[] data="Peach: prueba local de escritura y recuperación.\n".getBytes(StandardCharsets.UTF_8);android.util.AtomicFile file=new android.util.AtomicFile(new File(directory,"own-state"));FileOutputStream out=file.startWrite();try{out.write(data);file.finishWrite(out);}catch(Exception e){file.failWrite(out);throw e;}try(InputStream in=file.openRead()){if(!Arrays.equals(data,read(in,1024)))throw new IOException();}file.delete();return "Escritura y lectura comprobadas en almacenamiento privado";}
    String database(Token token)throws Exception {
        LibraryDatabase db=Room.inMemoryDatabaseBuilder(context,LibraryDatabase.class).build();try{
            LibraryRoot root=new LibraryRoot();root.uri="content://peach.own/tree/check";root.label="Muestra";root.state=0;db.library().addRoot(root);MediaEntry row=new MediaEntry();row.root=root.uri;row.folder=root.label;row.id="own-check";row.uri="content://peach.own/check";row.name="own.mp4";row.title="Muestra propia";row.mediaType=MediaRules.VIDEO;db.library().insertMedia(row);db.library().toggleFavorite(row.id);db.library().progress(row.id,2500,10000,1,false);
            ByteArrayOutputStream copy=new ByteArrayOutputStream();BackupStore.write(db.library(),copy);db.library().toggleFavorite(row.id);BackupStore.read(db,new ByteArrayInputStream(copy.toByteArray()));token.check();if(!db.library().get(row.id).favorite||db.library().get(row.id).position!=2500)throw new IOException();
            var packet=PortableState.export(PortableState.capture(db),UUID.randomUUID().toString(),"Prueba local");new PortableState.Packet(new JSONObject(packet.encoded));PortableState.validate(context,packet);return "Room, copia y paquete de intercambio comprobados en una biblioteca temporal";
        }finally{db.close();}
    }
    static String image(File directory)throws Exception {File file=new File(directory,"own.png");Bitmap b=Bitmap.createBitmap(64,32,Bitmap.Config.ARGB_8888);b.eraseColor(Color.rgb(40,100,160));try(OutputStream out=new FileOutputStream(file)){if(!b.compress(Bitmap.CompressFormat.PNG,100,out))throw new IOException();}finally{b.recycle();}Bitmap decoded=ImageFiles.decode(file,128).bitmap();try{if(decoded.getWidth()!=64||decoded.getHeight()!=32||decoded.getPixel(0,0)!=Color.rgb(40,100,160))throw new IOException();}finally{decoded.recycle();}return "PNG propio abierto y comprobado";}
    static String pdf(File directory)throws Exception {File file=new File(directory,"own.pdf");PdfDocument pdf=new PdfDocument();try{var page=pdf.startPage(new PdfDocument.PageInfo.Builder(200,200,1).create());page.getCanvas().drawColor(Color.WHITE);Paint paint=new Paint();paint.setColor(Color.BLACK);page.getCanvas().drawText("Peach: prueba local",10,60,paint);pdf.finishPage(page);try(OutputStream out=new FileOutputStream(file)){pdf.writeTo(out);}}finally{pdf.close();}
        try(var descriptor=ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY);PdfRenderer renderer=new PdfRenderer(descriptor)){if(renderer.getPageCount()!=1)throw new IOException();try(var page=renderer.openPage(0)){Bitmap b=Bitmap.createBitmap(200,200,Bitmap.Config.ARGB_8888);try{page.render(b,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);}finally{b.recycle();}}}return "PDF propio creado y renderizado";
    }
    File asset(File directory,String name)throws Exception {File target=new File(directory,name);if(target.isFile())return target;JSONObject manifest;try(InputStream in=context.getAssets().open("check470/manifest.json")){manifest=new JSONObject(new String(read(in,8192),StandardCharsets.UTF_8));}JSONObject entry=manifest.getJSONObject(name);try(InputStream in=context.getAssets().open("check470/"+name);OutputStream out=new FileOutputStream(target)){out.write(read(in,65536));}if(target.length()!=entry.getLong("bytes")||!VideoCache.checksum(target,new SourceHttp.Token()).equals(entry.getString("sha256")))throw new IOException("Muestra dañada.");return target;}
    static String rar(Context context,File file,File directory,Token token)throws Exception {try(RarBook book=new RarBook(file,new RarClient(context))){token.rar=book;token.check();File read=book.read("01/notas-ñ.txt",directory);String text;try(InputStream in=new FileInputStream(read)){text=new String(read(in,100000),StandardCharsets.UTF_8);}if(!text.equals("Peach: estratos sedimentarios y minerales.\n".repeat(2000)))throw new IOException();return "RAR5 sólido leído mediante el motor aislado de Android";}finally{token.rar=null;}}
    static byte[] read(InputStream input,int max)throws IOException {if(input==null)throw new IOException();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[4096];int n;while((n=input.read(b))!=-1){if(out.size()+n>max)throw new IOException("Datos demasiado grandes.");out.write(b,0,n);}return out.toByteArray();}
    static void removeOwn(File directory){File[] files=directory.listFiles();if(files!=null)for(File file:files)if(file.isFile())file.delete();directory.delete();}
}
