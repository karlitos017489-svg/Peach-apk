package com.peach.local;

import android.app.Application;
import android.content.*;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.lifecycle.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** One explicit direct transfer to a new SAF document, local or cloud. */
public final class DirectSaveActivity extends PeachActivity {
    interface Fetcher {DirectTransfer.Result run(String url,String hash,DirectTransfer.Destination destination,SourceHttp.Token token,DirectTransfer.Progress progress)throws IOException;}
    static Fetcher fetcher=DirectTransfer::download;
    static Intent intent(Context context,String url,String name,String hash){return new Intent(context,DirectSaveActivity.class).putExtra("attachment",url).putExtra("name",SourceFiles.name(name,url)).putExtra("hash",hash);}
    public static final class Draft extends AndroidViewModel {
        static final AtomicBoolean ACTIVE=new AtomicBoolean();
        final ExecutorService worker=Executors.newSingleThreadExecutor();final MutableLiveData<Integer> updates=new MutableLiveData<>(0);
        final DirectSaveJournal journal;volatile boolean busy;volatile long bytes,expected=-1;volatile String status="Elige dónde guardar. La transferencia empieza después de elegir el destino.";
        SourceHttp.Token token=new SourceHttp.Token();boolean picking;String url="",name="Adjunto",hash="";
        public Draft(Application app){super(app);journal=new DirectSaveJournal(app);}
        void start(Uri uri){
            if(busy)return;
            if(!ACTIVE.compareAndSet(false,true)){busy=true;status="Ya hay una transferencia activa. Retirando el destino nuevo sin iniciar otra descarga…";updates.setValue(1);
                worker.execute(()->{DirectSaveJournal.Item pending=null;try{pending=journal.add(uri,name);boolean removed=cleanup(uri);if(removed)journal.remove(pending.id());status=removed?"Ya hay una transferencia activa. El segundo destino nuevo fue retirado.":"Ya hay una transferencia activa. Revisa el segundo destino nuevo en archivos interrumpidos.";}catch(Exception e){status="No se inició otra descarga. Revisa el destino nuevo en el proveedor; puede estar vacío.";}finally{busy=false;updates.postValue(1);}});return;}
            busy=true;bytes=0;expected=-1;token=new SourceHttp.Token();status="Conectando con la fuente…";updates.setValue(1);
            worker.execute(()->{
                DirectSaveJournal.Item item=null;boolean delivered=false;
                try{
                    item=journal.add(uri,name);token.check();
                    var result=fetcher.run(url,hash,()->getApplication().getContentResolver().openOutputStream(uri,"w"),token,(count,total)->{bytes=count;expected=total;updates.postValue(1);});
                    token.check();delivered=true;
                    status="Archivo entregado al proveedor: "+result.bytes()+" bytes.\nSHA-256 recibido: "+result.sha256()+"\nSi elegiste Drive, comprueba la subida en Drive; Android puede completarla después. Peach no conserva una copia completa ni confirma la sincronización del servidor.";
                    try{journal.remove(item.id());}catch(IOException e){status+="\nNo se pudo retirar el aviso de recuperación. El archivo ya fue entregado; no lo elimines desde la recuperación.";}
                }catch(Exception e){
                    if(!delivered){boolean removed=cleanup(uri);if(removed&&item!=null)try{journal.remove(item.id());}catch(IOException ignored){}
                        String detail=Objects.toString(e.getMessage(),"");if(detail.contains("://")||detail.length()>240)detail="No se pudo completar la transferencia.";
                        status=(token.cancelled?"Transferencia cancelada.":detail.isEmpty()?"No se pudo completar la transferencia.":detail)+(removed?" El destino nuevo incompleto fue retirado.":" No se pudo retirar el destino nuevo; puede quedar incompleto. Revísalo en el proveedor o en Recuperar.");
                    }
                }finally{busy=false;ACTIVE.set(false);updates.postValue(1);}
            });
        }
        boolean cleanup(Uri uri){return SourcesActivity.Draft.discardCreated(getApplication(),uri);}
        @Override protected void onCleared(){token.cancel();worker.shutdown();}
    }
    Draft draft;private TextView status;private ProgressBar progress;private Button choose,cancel,recover;
    private final androidx.activity.result.ActivityResultLauncher<Intent> picker=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),result->{
        boolean expected=draft.picking;draft.picking=false;
        if(result.getResultCode()!=RESULT_OK||result.getData()==null){draft.status="Guardado cancelado; no se consultó la fuente.";render();return;}
        Uri uri=result.getData().getData();if(!expected||!SourceFiles.local(uri)){draft.status="Resultado de destino no válido. Vuelve a elegirlo.";render();return;}
        try{int flags=result.getData().getFlags();if((flags&Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)!=0){
            boolean read=(flags&Intent.FLAG_GRANT_READ_URI_PERMISSION)!=0,write=(flags&Intent.FLAG_GRANT_WRITE_URI_PERMISSION)!=0;
            if(write)getContentResolver().takePersistableUriPermission(uri,read?Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION:Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            else if(read)getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);
        }}catch(Exception ignored){/* Session grant remains sufficient while open; recovery may need the provider's app. */}
        draft.start(uri);
    });
    @Override protected void onCreate(Bundle state){super.onCreate(state);draft=new ViewModelProvider(this).get(Draft.class);
        draft.url=Objects.toString(getIntent().getStringExtra("attachment"),"");draft.name=SourceFiles.name(getIntent().getStringExtra("name"),draft.url);draft.hash=Objects.toString(getIntent().getStringExtra("hash"),"");if(state!=null)draft.picking=state.getBoolean("picking");
        LinearLayout root=UiAppearance.column(this,"Guardar en nube o carpeta");
        TextView name=new TextView(this);name.setText(draft.name);name.setTextSize(20);root.addView(name);
        TextView help=new TextView(this);help.setText("En el selector, abre el menú lateral y elige Google Drive u otro destino disponible. Necesitas su app y tu cuenta configurada.\n\nPeach envía el archivo sin preparar una copia completa. El proveedor puede usar espacio temporal propio. Hasta 2 GiB; sin reanudación. Mantén esta pantalla abierta. Si se interrumpe, vuelve a empezar.");root.addView(help);
        choose=new Button(this);choose.setId(R.id.direct_choose);choose.setText("Elegir destino y guardar");choose.setOnClickListener(v->choose());root.addView(choose);
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(1000);root.addView(progress);
        status=new TextView(this);status.setId(R.id.direct_status);status.setTextIsSelectable(true);root.addView(status);
        cancel=new Button(this);cancel.setId(R.id.direct_cancel);cancel.setText("Cancelar transferencia");cancel.setOnClickListener(v->{draft.token.cancel();draft.status="Cancelando…";render();});root.addView(cancel);
        recover=new Button(this);recover.setId(R.id.direct_recover);recover.setText("Revisar archivos interrumpidos");recover.setOnClickListener(v->recover());root.addView(recover);
        if(!SourceHttp.downloadable(draft.url)){name.setVisibility(View.GONE);choose.setVisibility(View.GONE);draft.status="Revisa los destinos interrumpidos. Para guardar un archivo nuevo, elígelo desde una publicación o video de tus fuentes.";}
        draft.updates.observe(this,n->render());render();
    }
    void choose(){if(draft.busy||draft.picking||!SourceHttp.downloadable(draft.url))return;try{if(draft.journal.items().size()>=16)throw new IOException("Revisa primero las transferencias interrumpidas.");draft.picking=true;picker.launch(SourceFiles.create(draft.name));}catch(Exception e){draft.picking=false;draft.status="No se pudo abrir el destino. Revisa las transferencias interrumpidas o el proveedor de documentos.";render();}}
    void render(){if(isDestroyed())return;choose.setEnabled(!draft.busy&&!draft.picking&&SourceHttp.downloadable(draft.url));cancel.setEnabled(draft.busy);recover.setEnabled(!draft.busy);progress.setVisibility(draft.busy?View.VISIBLE:View.GONE);progress.setIndeterminate(draft.expected<=0);if(draft.expected>0)progress.setProgress((int)Math.min(1000,draft.bytes*1000/draft.expected));
        status.setText(draft.busy?"Enviando "+android.text.format.Formatter.formatShortFileSize(this,draft.bytes)+(draft.expected>0?" de "+android.text.format.Formatter.formatShortFileSize(this,draft.expected):"")+"\n"+draft.status:draft.status);}
    void recover(){try{List<DirectSaveJournal.Item> all=draft.journal.items();if(all.isEmpty()){new AlertDialog.Builder(this).setMessage("No hay transferencias interrumpidas pendientes.").setPositiveButton("Cerrar",null).show();return;}
        new AlertDialog.Builder(this).setTitle("Destinos de transferencias interrumpidas").setItems(all.stream().map(DirectSaveJournal.Item::name).toArray(String[]::new),(d,i)->{var item=all.get(i);new AlertDialog.Builder(this).setTitle(item.name()).setMessage("Comprueba primero el archivo en el proveedor. Retirar elimina exclusivamente este destino creado por una transferencia de Peach. Si ya está completo, elige Conservar archivo.").setPositiveButton("Retirar incompleto",(a,w)->{draft.busy=true;render();draft.worker.execute(()->{try{if(draft.cleanup(Uri.parse(item.uri()))){draft.journal.remove(item.id());draft.status="Destino incompleto retirado.";}else draft.status="El proveedor no permitió retirarlo. Revísalo directamente allí.";}catch(Exception e){draft.status="No se pudo actualizar la recuperación.";}finally{draft.busy=false;draft.updates.postValue(1);}});}).setNeutralButton("Conservar archivo",(a,w)->{try{draft.journal.remove(item.id());draft.status="Aviso retirado. Archivo conservado.";}catch(IOException e){draft.status=e.getMessage();}render();}).setNegativeButton("Cancelar",null).show();}).setNegativeButton("Cerrar",null).show();
        }catch(IOException e){draft.status=e.getMessage();render();}}
    @Override protected void onStop(){if(!isChangingConfigurations()&&draft.busy)draft.token.cancel();super.onStop();}
    @Override protected void onSaveInstanceState(Bundle state){state.putBoolean("picking",draft.picking);super.onSaveInstanceState(state);}
}
