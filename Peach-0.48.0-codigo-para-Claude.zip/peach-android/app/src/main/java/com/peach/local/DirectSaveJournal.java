package com.peach.local;

import android.content.Context;
import android.net.Uri;
import org.json.*;
import java.io.IOException;
import java.util.*;

/** Private recovery references only. Never resumes network or deletes on application startup. */
final class DirectSaveJournal {
    record Item(String id,String uri,String name) {}
    private static final Object LOCK=new Object();
    private final android.content.SharedPreferences prefs;
    DirectSaveJournal(Context context){prefs=context.getSharedPreferences("direct-save-recovery",Context.MODE_PRIVATE);}
    List<Item> items()throws IOException {synchronized(LOCK){
        try{JSONArray a=new JSONArray(prefs.getString("pending","[]"));if(a.length()>16)throw new JSONException("quota");List<Item> result=new ArrayList<>();
            for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);String u=x.getString("uri");if(!SourceFiles.local(Uri.parse(u)))throw new JSONException("uri");result.add(new Item(x.getString("id"),u,x.getString("name")));}return result;
        }catch(Exception e){throw new IOException("No se pudo leer la recuperación de transferencias.");}
    }}
    Item add(Uri uri,String name)throws IOException {synchronized(LOCK){
        List<Item> all=new ArrayList<>(items());if(all.size()>=16)throw new IOException("Revisa los archivos incompletos antes de iniciar otra transferencia.");
        if(!SourceFiles.local(uri))throw new IOException("Destino no válido.");
        Item item=new Item(UUID.randomUUID().toString(),uri.toString(),name);all.add(item);write(all);return item;
    }}
    void remove(String id)throws IOException {synchronized(LOCK){List<Item> all=new ArrayList<>(items());all.removeIf(x->x.id.equals(id));write(all);}}
    private void write(List<Item> all)throws IOException {
        try{JSONArray a=new JSONArray();for(Item x:all)a.put(new JSONObject().put("id",x.id).put("uri",x.uri).put("name",x.name));
            if(!prefs.edit().putString("pending",a.toString()).commit())throw new IOException("No se pudo conservar la recuperación del destino.");
        }catch(JSONException e){throw new IOException("No se pudo guardar la recuperación.");}
    }
}
