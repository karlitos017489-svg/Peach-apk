package com.peach.local;

import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.*;
import javax.net.ssl.HttpsURLConnection;

/** Streams a supported attachment to a caller-owned NEW document. No media file/cache. */
final class DirectTransfer {
    interface Destination { OutputStream open() throws IOException; }
    interface Progress { void bytes(long transferred,long expected); }
    record Result(long bytes,String sha256) {}
    static Result download(String url,String expectedHash,Destination destination,SourceHttp.Token token,Progress progress)throws IOException {
        return download(url,expectedHash,destination,token,progress,u->(HttpsURLConnection)new URL(u).openConnection(),InetAddress::getAllByName);
    }
    static Result download(String url,String expectedHash,Destination destination,SourceHttp.Token token,Progress progress,SourceHttp.ConnectionFactory factory,MediaRedirects.Resolver resolver)throws IOException {
        if(!SourceHttp.downloadable(url))throw new IOException("La fuente no admite descargar este enlace.");
        if(!expectedHash.isEmpty()&&!expectedHash.matches("[a-f0-9]{64}"))throw new IOException("Hash de origen no válido.");
        String required=PawchiveUrls.downloadable(url)?PawchiveUrls.expectedHash(url):expectedHash;
        if(!expectedHash.isEmpty()&&!required.equals(expectedHash))throw new IOException("Referencias SHA-256 incompatibles.");
        HttpsURLConnection connection=null;
        try {
            connection=SourceHttp.open(url,"","",token,false,factory,resolver);
            long expected=connection.getContentLengthLong();
            if(expected>SourceHttp.LARGE_DOWNLOAD_LIMIT)throw new IOException("El archivo supera el límite de 2 GiB.");
            String mime=Objects.toString(connection.getContentType(),"").toLowerCase(Locale.ROOT);
            if(mime.contains("text/html")||mime.contains("application/json"))throw new IOException("El servidor devolvió una página en lugar del archivo.");
            try(InputStream input=connection.getInputStream()){
                return copy(input,expected,required,MediaRedirects.videoSource(url),destination,token,progress,SourceHttp.LARGE_DOWNLOAD_LIMIT);
            }
        }finally{if(connection!=null)connection.disconnect();token.connection=null;}
    }
    static Result copy(InputStream input,long expected,String required,boolean recognized,Destination destination,SourceHttp.Token token,Progress progress,long limit)throws IOException {
        if(limit<1||limit>SourceHttp.LARGE_DOWNLOAD_LIMIT||expected>limit)throw new IOException("Archivo demasiado grande.");
        if(!required.isEmpty()&&!required.matches("[a-f0-9]{64}"))throw new IOException("Hash no válido.");
        token.check();byte[] prefix=new byte[4096];int used=0,n;
        while(used<prefix.length&&(n=input.read(prefix,used,prefix.length-used))!=-1){token.check();if(n==0)continue;used+=n;}
        LocalMedia.Format actual=LocalMedia.header(Arrays.copyOf(prefix,used));
        if(recognized&&actual.kind().isEmpty())throw new IOException("La fuente no devolvió un video o imagen reconocible.");
        if(used>limit||expected>=0&&used>expected)throw new IOException("El tamaño no coincide con la fuente.");
        MessageDigest digest;try{digest=MessageDigest.getInstance("SHA-256");}catch(Exception e){throw new AssertionError(e);}
        Result result;long total=used,deadline=System.nanoTime()+3_600_000_000_000L,next=0;
        try(OutputStream output=destination.open()){
            if(output==null)throw new IOException("No se pudo abrir el destino. Vuelve a elegirlo.");
            token.check();digest.update(prefix,0,used);output.write(prefix,0,used);progress.bytes(total,expected);
            byte[] buffer=new byte[65536];
            while((n=input.read(buffer))!=-1){token.check();if(n==0)continue;total+=n;
                if(total>limit||expected>=0&&total>expected||System.nanoTime()>deadline)throw new IOException("La transferencia excedió su tamaño o tiempo permitido.");
                digest.update(buffer,0,n);output.write(buffer,0,n);
                if(total>=next){progress.bytes(total,expected);next=total+256*1024;}
            }
            token.check();if(total==0||expected>=0&&total!=expected)throw new IOException("El archivo llegó incompleto.");
            String hash=GalleryCache.hex(digest.digest());
            if(!required.isEmpty()&&!required.equals(hash))throw new IOException("El archivo no coincide con el SHA-256 declarado por la fuente.");
            output.flush();token.check();
            // Success is returned only after the provider stream closes successfully.
            progress.bytes(total,expected);
            result=new Result(total,hash);
        }
        token.check();return result;
    }
}
