package com.peach.local;

import java.util.Set;

/** Reader support is independent of catalog classification. */
public final class DocumentRules {
    public static final String PDF="pdf",ZIP="zip",TEXT="text",IMAGE="image",TAR="tar",GZIP="gzip",SEVEN="7z",RAR="rar",EPUB="epub",CHAPTER="epub-text";
    private static final Set<String> TEXTS=Set.of("txt","md","csv","json","xml","log");
    private DocumentRules() {}
    public static String kind(String name) {
        String ext=MediaRules.extension(name);
        return ext.equals("epub")?EPUB:Set.of("rar","cbr").contains(ext)?RAR:ext.equals("7z")?SEVEN:ext.equals("tar")?TAR:Set.of("gz","tgz").contains(ext)?GZIP:ext.equals("pdf")?PDF:Set.of("zip","cbz").contains(ext)?ZIP:TEXTS.contains(ext)?TEXT:"";
    }
    public static boolean plain(String kind){return kind.equals(TEXT) || kind.equals(CHAPTER);}
    public static boolean readable(String name){return !kind(name).isEmpty();}
    public static String entryKind(String name){return MediaRules.isImage(name)?IMAGE:Set.of(PDF,TEXT).contains(kind(name))?kind(name):"";}
    public static String label(String name){return switch(kind(name)){case PDF->"PDF";case ZIP->"ZIP / CBZ";case RAR->"RAR / CBR · lectura parcial";case TEXT->"Texto";case TAR->"TAR";case SEVEN->"7z";case EPUB->"EPUB · texto";case GZIP->"GZIP / TAR.GZ";default->"";};}
    public static int naturalCompare(String left,String right) {
        int a=0,b=0;
        while(a<left.length() && b<right.length()) {
            char x=left.charAt(a),y=right.charAt(b);
            if(x>='0' && x<='9' && y>='0' && y<='9') {
                int endA=a,endB=b;while(endA<left.length() && left.charAt(endA)>='0' && left.charAt(endA)<='9')endA++;
                while(endB<right.length() && right.charAt(endB)>='0' && right.charAt(endB)<='9')endB++;
                int startA=a,startB=b;while(startA+1<endA && left.charAt(startA)=='0')startA++;
                while(startB+1<endB && right.charAt(startB)=='0')startB++;
                int order=Integer.compare(endA-startA,endB-startB);
                if(order==0)order=left.substring(startA,endA).compareTo(right.substring(startB,endB));
                if(order!=0)return order;a=endA;b=endB;
            }else{int order=Character.compare(Character.toLowerCase(x),Character.toLowerCase(y));if(order!=0)return order;a++;b++;}
        }
        int order=Integer.compare(left.length()-a,right.length()-b);return order!=0?order:left.compareTo(right);
    }
}
