package com.peach.local;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.CancellationSignal;
import android.provider.DocumentsContract;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

/** Lists each directory once; only reads from the source provider. */
public final class DocumentScanner {
    public record Entry(String id, Uri uri, String name, String mime, long size, long modified) {
        public boolean directory() { return DocumentsContract.Document.MIME_TYPE_DIR.equals(mime); }
    }
    public record Batch(List<MediaEntry> media, List<ScanDirectory> children, int warnings) {}
    private final ContentResolver resolver;
    public DocumentScanner(ContentResolver resolver) { this.resolver = resolver; }
    public Batch scan(LibraryRoot root, ScanDirectory directory, CancellationSignal signal) throws Exception {
        Uri parent = Uri.parse(directory.uri);
        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(parent,
            DocumentsContract.getDocumentId(parent));
        List<Entry> entries = new ArrayList<>();
        String[] projection = {DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE, DocumentsContract.Document.COLUMN_LAST_MODIFIED};
        try (Cursor cursor = resolver.query(childrenUri, projection, null, null, null, signal)) {
            if (cursor == null) throw new IOException("No se pudo leer la carpeta");
            while (cursor.moveToNext()) {
                signal.throwIfCanceled();
                String id=cursor.getString(0), name=cursor.getString(1), mime=cursor.getString(2);
                if (id == null || name == null) continue;
                entries.add(new Entry(id, DocumentsContract.buildDocumentUriUsingTree(parent,id),
                    name,mime,cursor.isNull(3)?0:cursor.getLong(3),cursor.isNull(4)?0:cursor.getLong(4)));
            }
            if (cursor.getExtras().getBoolean(DocumentsContract.EXTRA_LOADING, false))
                throw new IOException("El proveedor todavía está cargando la carpeta");
        }
        Map<String, Entry> files = new HashMap<>();
        int videoCount = 0;
        for (Entry entry : entries) {
            if (!entry.directory()) files.put(entry.name.toLowerCase(Locale.ROOT),entry);
            if (!entry.directory() && MediaRules.isVideo(entry.name)) videoCount++;
        }
        List<ScanDirectory> children = new ArrayList<>();
        List<MediaEntry> videos = new ArrayList<>();
        Set<String> artworkIds=new HashSet<>();
        int warnings = 0;
        for (Entry entry : entries) {
            signal.throwIfCanceled();
            if (entry.directory()) {
                children.add(new ScanDirectory(root.uri,entry.uri.toString(),
                    directory.folder.isEmpty()?entry.name:directory.folder+" / "+entry.name));
                continue;
            }
            String type=MediaRules.type(entry.name);
            if (!MediaRules.VIDEO.equals(type) && !MediaRules.AUDIO.equals(type)) continue;
            MediaEntry media=base(entry,root,directory);media.mediaType=type;
            String stem = MediaRules.stem(entry.name).toLowerCase(Locale.ROOT);
            Entry nfo = files.get(stem+".nfo");
            if (nfo == null && MediaRules.VIDEO.equals(type) && videoCount == 1) nfo=files.get("movie.nfo");
            if (nfo != null) {
                try (InputStream in = resolver.openInputStream(nfo.uri)) {
                    if (in == null) throw new IOException("NFO inaccesible");
                    NfoReader.Metadata metadata = NfoReader.read(in);
                    if (!metadata.title().isEmpty()) media.title=metadata.title();
                    media.plot=metadata.plot(); media.year=metadata.year(); media.studio=metadata.studio();
                    media.actors=metadata.actors(); media.tags=metadata.tags();
                    media.nfoDetails=NfoDetails.encode(metadata.details(),metadata.terms());
                } catch (Exception error) { warnings++; }
            }
            List<String> posterNames = new ArrayList<>(List.of(stem+"-poster",stem));
            if (MediaRules.AUDIO.equals(type) || videoCount==1) posterNames.addAll(List.of("poster","folder","cover"));
            findPoster: for (String name : posterNames) for (String ext : List.of(".jpg",".jpeg",".png",".webp",".tbn")) {
                Entry poster=files.get(name+ext);
                if (poster!=null) { media.poster=poster.uri.toString();artworkIds.add(poster.id); break findPoster; }
            }
            JSONArray tracks = new JSONArray();
            for (Entry candidate : MediaRules.VIDEO.equals(type)?entries:List.<Entry>of()) {
                if (!candidate.directory() && MediaRules.subtitleMatches(entry.name,candidate.name)) {
                    JSONObject track = new JSONObject();
                    track.put("uri",candidate.uri.toString()); track.put("name",candidate.name);
                    tracks.put(track);
                }
            }
            media.subtitles=tracks.toString(); videos.add(media);
        }
        for (Entry entry:entries) {
            signal.throwIfCanceled();
            String type=MediaRules.type(entry.name);
            if (!entry.directory() && !MediaRules.sidecar(entry.name) && !artworkIds.contains(entry.id) &&
                    !MediaRules.VIDEO.equals(type) && !MediaRules.AUDIO.equals(type)) {
                MediaEntry image=base(entry,root,directory);image.mediaType=type;videos.add(image);
            }
        }
        return new Batch(videos,children,warnings);
    }
    private static MediaEntry base(Entry entry,LibraryRoot root,ScanDirectory directory) {
        MediaEntry media=new MediaEntry();
        media.id=DocumentsContract.buildDocumentUri(entry.uri.getAuthority(),entry.id).toString();
        media.uri=entry.uri.toString();media.root=root.uri;media.name=entry.name;media.folder=directory.folder;
        media.title=MediaRules.stem(entry.name);media.bytes=entry.size;media.modified=entry.modified;media.generation=root.generation;
        return media;
    }
}
