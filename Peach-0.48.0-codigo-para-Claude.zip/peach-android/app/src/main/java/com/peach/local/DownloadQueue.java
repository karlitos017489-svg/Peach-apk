package com.peach.local;

import android.content.Context;
import android.net.Uri;
import android.util.AtomicFile;
import androidx.lifecycle.MutableLiveData;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import org.json.*;

/** Durable operational queue, deliberately outside the catalog and personal backup. */
final class DownloadQueue {
    static final int MAX_JOBS=128;
    static final long BUDGET=4L*1024*1024*1024;
    static final Map<File,DownloadQueue> STORES=new ConcurrentHashMap<>();
    static final Set<String> STATES=Set.of("queued","running","paused","verifying","ready","error","removing");
    static DownloadQueue get(Context context)throws IOException {
        File root=new File(context.getNoBackupFilesDir(),"peach-download-queue");synchronized(STORES){DownloadQueue existing=STORES.get(root);if(existing!=null)return existing;DownloadQueue created=new DownloadQueue(root);STORES.put(root,created);return created;}
    }
    static final class Job {
        String id,publication,key,name,kind,state="queued",message="",sha="",exported="",pending="";
        long bytes,total=-1,retryAt;PartialDownload.Mark mark=PartialDownload.Mark.empty();
        Job copy(){Job j=new Job();j.id=id;j.publication=publication;j.key=key;j.name=name;j.kind=kind;j.state=state;j.message=message;j.sha=sha;j.exported=exported;j.pending=pending;j.bytes=bytes;j.total=total;j.retryAt=retryAt;j.mark=mark;return j;}
    }
    interface Fetcher {SourceHttp.Download get(String url,File part,PartialDownload.Mark mark,SourceHttp.Token token,long limit,PartialDownload.Updates updates)throws IOException;}
    final File root;final AtomicFile manifest;final LinkedHashMap<String,Job> jobs=new LinkedHashMap<>();final Map<String,Integer> pins=new HashMap<>();
    final MutableLiveData<Integer> changes=new MutableLiveData<>(0);int revision;String folder="",active="";SourceHttp.Token activeToken;boolean exporting,holding;volatile String backgroundOwner="";
    DownloadQueue(File root)throws IOException {this.root=root;manifest=new AtomicFile(new File(root,"queue.json"));if(!root.isDirectory()&&!root.mkdirs())throw new IOException("No se pudo abrir la cola.");read();recover();}
    static boolean id(String id){try{return id!=null&&UUID.fromString(id).toString().equals(id);}catch(IllegalArgumentException e){return false;}}
    File part(String id)throws IOException{if(!id(id))throw new IOException("Descarga no válida.");return new File(root,id+".part");}
    File ready(String id)throws IOException{if(!id(id))throw new IOException("Descarga no válida.");return new File(root,id+".ready");}
    static String bounded(JSONObject j,String key,int max)throws JSONException {String s=j.getString(key);if(s.length()>max)throw new JSONException("Campo demasiado grande.");return s;}
    void read()throws IOException {
        if(!manifest.getBaseFile().exists()&&!new File(root,"queue.json.bak").exists())return;
        try(InputStream in=manifest.openRead()){
            byte[] data=SourceHttp.bounded(in,2*1024*1024,new SourceHttp.Token());JSONObject doc=new JSONObject(new String(data,StandardCharsets.UTF_8));if(doc.getInt("version")!=1)throw new IOException();
            folder=bounded(doc,"folder",4096);if(!folder.isEmpty()&&!SourceFiles.local(Uri.parse(folder)))throw new IOException();JSONArray all=doc.getJSONArray("jobs");if(all.length()>MAX_JOBS)throw new IOException();
            for(int i=0;i<all.length();i++){JSONObject a=all.getJSONObject(i);Job j=new Job();j.id=bounded(a,"id",36);j.publication=bounded(a,"publication",1000);j.key=bounded(a,"key",64);j.name=bounded(a,"name",300);j.kind=bounded(a,"kind",10);j.state=bounded(a,"state",12);j.message=bounded(a,"message",500);j.sha=bounded(a,"sha",64);j.exported=bounded(a,"exported",4096);j.pending=bounded(a,"pending",4096);j.bytes=a.getLong("bytes");j.total=a.getLong("total");j.retryAt=a.getLong("retryAt");JSONObject m=a.getJSONObject("mark");j.mark=new PartialDownload.Mark(m.getLong("offset"),m.getLong("total"),bounded(m,"etag",512),bounded(m,"target",64),bounded(m,"sha",64));
                if(!id(j.id)||!SourceVideos.id(j.publication)||!VideoCache.key(j.key)||!Set.of("image","video","file").contains(j.kind)||!STATES.contains(j.state)||j.bytes<0||j.bytes>SourceHttp.LARGE_DOWNLOAD_LIMIT||j.total< -1||j.total>SourceHttp.LARGE_DOWNLOAD_LIMIT||j.mark.offset()<0||j.mark.offset()>SourceHttp.LARGE_DOWNLOAD_LIMIT||j.mark.total()< -1||j.mark.total()>SourceHttp.LARGE_DOWNLOAD_LIMIT||!j.mark.etag().isEmpty()&&!PartialDownload.strong(j.mark.etag())||!j.mark.target().isEmpty()&&!VideoCache.key(j.mark.target())||!j.mark.sha().isEmpty()&&!VideoCache.key(j.mark.sha())||!j.sha.isEmpty()&&!VideoCache.key(j.sha)||!j.exported.isEmpty()&&!SourceFiles.local(Uri.parse(j.exported))||!j.pending.isEmpty()&&!SourceFiles.local(Uri.parse(j.pending))||jobs.put(j.id,j)!=null)throw new IOException();
            }
        }catch(IOException|JSONException|RuntimeException e){throw new IOException("No se pudo leer la cola guardada. Sus archivos se conservan.");}
    }
    synchronized void recover()throws IOException {
        boolean changed=false;for(var it=jobs.values().iterator();it.hasNext();){Job j=it.next();if(j.state.equals("removing")){part(j.id).delete();ready(j.id).delete();it.remove();changed=true;continue;}
            if(j.state.equals("verifying")&&ready(j.id).isFile()&&j.mark.offset()>0&&j.mark.offset()==j.mark.total()&&ready(j.id).length()==j.mark.offset()&&PartialDownload.checksum(ready(j.id),new SourceHttp.Token()).equals(j.mark.sha())){j.state="ready";j.bytes=j.mark.offset();j.total=j.bytes;j.sha=j.mark.sha();LocalMedia.Format f=LocalMedia.inspect(ready(j.id));j.name=LocalMedia.name(j.name,f);if(!f.kind().isEmpty())j.kind=f.kind();j.message="Copia completa recuperada y verificada.";changed=true;}
            else if(Set.of("running","verifying").contains(j.state)){j.state="paused";j.bytes=j.mark.offset();j.total=j.mark.total();j.message="Interrumpida. Puedes continuar desde el último punto comprobado.";changed=true;}
            if(j.state.equals("ready")&&(!ready(j.id).isFile()||ready(j.id).length()!=j.bytes||!VideoCache.key(j.sha))){j.state="error";j.message="La copia privada está ausente o incompleta.";changed=true;}
            if(Set.of("paused","error","queued").contains(j.state)){long durable=part(j.id).length()>=j.mark.offset()?j.mark.offset():0;if(j.bytes!=durable||j.total!=j.mark.total()){j.bytes=durable;j.total=j.mark.total();changed=true;}}
        }if(changed)save();
    }
    synchronized void save()throws IOException {
        try{JSONArray all=new JSONArray();for(Job j:jobs.values())all.put(new JSONObject().put("id",j.id).put("publication",j.publication).put("key",j.key).put("name",j.name).put("kind",j.kind).put("state",j.state).put("message",j.message).put("sha",j.sha).put("exported",j.exported).put("pending",j.pending).put("bytes",j.bytes).put("total",j.total).put("retryAt",j.retryAt).put("mark",new JSONObject().put("offset",j.mark.offset()).put("total",j.mark.total()).put("etag",j.mark.etag()).put("target",j.mark.target()).put("sha",j.mark.sha())));
            byte[] bytes=new JSONObject().put("version",1).put("folder",folder).put("jobs",all).toString().getBytes(StandardCharsets.UTF_8);FileOutputStream out=null;try{out=manifest.startWrite();out.write(bytes);manifest.finishWrite(out);}catch(IOException e){if(out!=null)manifest.failWrite(out);throw e;}notifyChanged();
        }catch(JSONException e){throw new IOException("No se pudo guardar la cola.");}
    }
    synchronized void notifyChanged(){changes.postValue(++revision);}
    synchronized List<Job> snapshot(){return jobs.values().stream().map(Job::copy).toList();}
    synchronized Job job(String id)throws IOException{Job j=jobs.get(id);if(j==null)throw new IOException("La descarga ya no está en la cola.");return j;}
    synchronized int enqueue(String publication,List<SourceAttachments.Item> selected)throws IOException {
        if(!SourceVideos.id(publication))throw new IOException("Publicación no válida.");int count=0;
        long additions=selected.stream().map(SourceAttachments.Item::key).distinct().filter(k->jobs.values().stream().noneMatch(j->j.publication.equals(publication)&&j.key.equals(k))).count();if(jobs.size()+additions>MAX_JOBS)throw new IOException("La cola admite hasta128 adjuntos. Retira descargas anteriores.");
        for(var item:selected){if(!Set.of("image","video","file").contains(item.kind())||!SourceVideos.admitted(item.provider(),item.url(),true)||jobs.values().stream().anyMatch(j->j.publication.equals(publication)&&j.key.equals(item.key())))continue;Job j=new Job();j.id=UUID.randomUUID().toString();j.publication=publication;j.key=item.key();j.name=SourceFiles.name(item.name(),item.url());j.kind=item.kind();jobs.put(j.id,j);count++;}save();return count;
    }
    synchronized void folder(Uri uri)throws IOException{if(!SourceFiles.local(uri))throw new IOException("Carpeta no válida.");folder=uri.toString();save();}
    synchronized String claimBackground()throws IOException{if(exporting||!backgroundOwner.isEmpty()||activeToken!=null)throw new IOException("La cola ya tiene un trabajo activo. Espera a que se pause antes de cambiar de modo.");backgroundOwner=UUID.randomUUID().toString();notifyChanged();return backgroundOwner;}
    synchronized boolean background(){return !backgroundOwner.isEmpty();}
    synchronized boolean ownsBackground(String owner){return owner!=null&&!owner.isEmpty()&&owner.equals(backgroundOwner);}
    synchronized void releaseBackground(String owner){if(ownsBackground(owner)){backgroundOwner="";notifyChanged();}}
    synchronized boolean running(){return activeToken!=null;}
    synchronized void signalPause(){holding=true;if(activeToken!=null)activeToken.cancel();}
    synchronized void pauseAll()throws IOException{signalPause();for(Job j:jobs.values())if(Set.of("queued","running","verifying").contains(j.state)){j.state="paused";j.message="Pausada.";}save();}
    synchronized void pause(String id)throws IOException{Job j=job(id);if(Set.of("queued","running","verifying").contains(j.state)){j.state="paused";j.message="Pausada.";if(active.equals(id)&&activeToken!=null)activeToken.cancel();save();}}
    synchronized void continueAll()throws IOException{holding=false;for(Job j:jobs.values())if(Set.of("paused","error").contains(j.state)&&j.retryAt<=System.currentTimeMillis()&&pins.getOrDefault(j.id,0)==0){j.state="queued";j.message="En cola.";}save();}
    synchronized void retry(String id)throws IOException{Job j=job(id);if(j.state.equals("ready"))return;if(active.equals(id))throw new IOException("Espera a que termine de pausarse esta descarga.");if(pins.getOrDefault(id,0)>0)throw new IOException("Cierra el archivo antes de reintentar su descarga.");if(j.retryAt>System.currentTimeMillis())throw new IOException("La fuente pidió esperar antes de reintentar esta descarga.");j.state="queued";j.message="En cola.";save();}
    synchronized void remove(String id)throws IOException{Job j=job(id);if(pins.getOrDefault(id,0)>0)throw new IOException("Cierra el archivo antes de retirar su copia privada.");if(exporting)throw new IOException("Espera a que termine el guardado en carpeta.");
        if(active.equals(id)){j.state="removing";if(activeToken!=null)activeToken.cancel();save();}else{part(id).delete();ready(id).delete();jobs.remove(id);save();}}
    synchronized long limit(String id)throws IOException {long occupied=0;for(Job j:jobs.values()){occupied+=ready(j.id).length();if(!j.id.equals(id))occupied+=part(j.id).length();}long remaining=Math.min(SourceHttp.LARGE_DOWNLOAD_LIMIT,BUDGET-occupied);if(remaining<1||job(id).mark.total()>remaining)throw new PartialDownload.Problem("La cola no tiene espacio disponible. Retira copias privadas de otras descargas.");return remaining;}
    synchronized File checked(String id)throws IOException{Job j=job(id);File f=ready(id);if(!j.state.equals("ready")||j.bytes<1||f.length()!=j.bytes||!VideoCache.key(j.sha))throw new IOException("Esta descarga todavía no tiene una copia completa disponible.");return f;}
    File verify(String id,SourceHttp.Token token)throws IOException{File file;String expected;synchronized(this){file=checked(id);expected=job(id).sha;pins.merge(id,1,Integer::sum);}try{if(!PartialDownload.checksum(file,token).equals(expected)){synchronized(this){Job j=job(id);j.state="error";j.message="La copia privada no supera la comprobación de integridad.";save();}throw new IOException("La copia privada no supera la comprobación de integridad.");}return file;}finally{unpin(id);}}
    synchronized void unpin(String id){int count=pins.getOrDefault(id,0);if(count<=1)pins.remove(id);else pins.put(id,count-1);}
    boolean run(LibraryDatabase db,Fetcher fetcher)throws IOException {
        synchronized(this){if(activeToken!=null)return false;activeToken=new SourceHttp.Token();active="";}
        try{while(true){Job current;SourceHttp.Token token;
                synchronized(this){if(holding)return true;current=jobs.values().stream().filter(j->j.state.equals("queued")&&j.retryAt<=System.currentTimeMillis()).findFirst().orElse(null);if(current==null)return true;active=current.id;activeToken=new SourceHttp.Token();token=activeToken;current.state="running";current.message="Descargando…";save();}
                try{Job copy=current.copy();var selected=SourceAttachments.load(db,copy.publication).stream().filter(a->a.key().equals(copy.key)).findFirst().orElseThrow(()->new PartialDownload.Problem("El adjunto ya no figura en el cuerpo importado. Consulta y revisa su publicación."));
                    long limit=limit(copy.id);PartialDownload.Updates updates=new PartialDownload.Updates(){public void checkpoint(PartialDownload.Mark mark)throws IOException{synchronized(DownloadQueue.this){Job j=job(copy.id);j.mark=mark;j.bytes=mark.offset();j.total=mark.total();save();}}
                        public void progress(long bytes,long total){synchronized(DownloadQueue.this){Job j=jobs.get(copy.id);if(j==null)return;j.bytes=bytes;j.total=total;if(copy.mark.offset()>0&&bytes==0)j.message="Reiniciando desde el principio: el servidor no confirmó el fragmento.";notifyChanged();}}};
                    var result=fetcher.get(selected.url(),part(copy.id),copy.mark,token,limit,updates);token.check();synchronized(this){if(!current.state.equals("running"))throw new InterruptedIOException();current.state="verifying";current.message="Comprobando archivo…";save();}
                    File file=part(copy.id);if(file.length()!=result.bytes()||!PartialDownload.checksum(file,token).equals(result.sha256()))throw new PartialDownload.Problem("El archivo no superó la comprobación de integridad.");
                    if(!selected.expectedHash().isEmpty()&&!selected.expectedHash().equals(result.sha256())){PartialDownload.truncate(file,0);updates.checkpoint(PartialDownload.Mark.empty());throw new PartialDownload.Problem("El archivo no coincide con el SHA-256 de Pixeldrain.");}
                    if(PawchiveUrls.downloadable(selected.url())&&!result.sha256().equals(PawchiveUrls.expectedHash(selected.url()))){PartialDownload.truncate(file,0);updates.checkpoint(PartialDownload.Mark.empty());throw new PartialDownload.Problem("El archivo no coincide con el SHA-256 esperado de Pawchive.");}
                    LocalMedia.Format format=LocalMedia.inspect(file);if(MediaRedirects.videoSource(selected.url())&&format.kind().isEmpty())throw new PartialDownload.Problem("La fuente no devolvió un video o imagen reconocible.");
                    synchronized(this){token.check();if(!current.state.equals("verifying"))throw new InterruptedIOException();if(pins.getOrDefault(copy.id,0)>0)throw new PartialDownload.Problem("Cierra el archivo antes de sustituir su copia privada.");if(!file.renameTo(ready(copy.id)))throw new IOException();current.name=LocalMedia.name(selected.name(),format);current.kind=format.kind().isEmpty()?selected.kind():format.kind();current.sha=result.sha256();current.bytes=result.bytes();current.total=current.bytes;current.state="ready";current.message="Descarga completa y verificada.";save();}
                }catch(Exception e){synchronized(this){if(!current.state.equals("removing")){if(token.cancelled||current.state.equals("paused")){current.state="paused";current.message="Pausada. El fragmento comprobado se conserva.";}else{current.state="error";current.message=e instanceof PartialDownload.Problem?e.getMessage():e instanceof SourceHttp.Failure f?"La fuente respondió HTTP "+f.status+".":"No se pudo completar. Revisa la conexión y el espacio; puedes reintentar.";if(e instanceof SourceHttp.Failure f&&f.status==429){current.retryAt=System.currentTimeMillis()+Math.min(86400,Math.max(1,f.retrySeconds))*1000L;current.message="La fuente pidió esperar antes de reintentar.";}}save();}}}
                finally{synchronized(this){if(current.state.equals("removing")){part(current.id).delete();ready(current.id).delete();jobs.remove(current.id);save();}active="";}}
            }
        }finally{synchronized(this){Job interrupted=jobs.get(active);if(interrupted!=null&&Set.of("running","verifying").contains(interrupted.state)){interrupted.state="paused";interrupted.message="Interrumpida. Puedes continuar.";try{save();}catch(IOException ignored){}}active="";activeToken=null;notifyChanged();}}
    }
    void recoverExports(Context app)throws IOException{for(Job copy:snapshot())if(!copy.pending.isEmpty()){boolean removed=SourcesActivity.Draft.discardCreated(app,Uri.parse(copy.pending));if(!removed)try(var c=app.getContentResolver().query(Uri.parse(copy.pending),new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null)){removed=c!=null&&!c.moveToFirst();}catch(Exception ignored){}if(!removed)throw new IOException("No se pudo retirar un destino incompleto anterior. Revisa el acceso a su carpeta.");synchronized(this){job(copy.id).pending="";save();}}}
    int export(Context app,SourceHttp.Token token)throws IOException {
        Uri tree;synchronized(this){if(exporting)throw new IOException("Ya se están guardando archivos.");if(folder.isEmpty())throw new IOException("Elige primero una carpeta de destino.");tree=Uri.parse(folder);exporting=true;}
        int count=0;try{recoverExports(app);String parent=android.provider.DocumentsContract.getTreeDocumentId(tree);Uri directory=android.provider.DocumentsContract.buildDocumentUriUsingTree(tree,parent);
            for(Job copy:snapshot())if(copy.state.equals("ready")&&copy.exported.isEmpty()){token.check();File file=verify(copy.id,token);String ext=MediaRules.extension(copy.name),name=(ext.isEmpty()?copy.name:MediaRules.stem(copy.name))+"-peach-"+copy.id+(ext.isEmpty()?"":"."+ext);Uri created=android.provider.DocumentsContract.createDocument(app.getContentResolver(),directory,SourceFiles.mime(copy.name),name);if(created==null)throw new IOException("No se pudo crear el archivo en esa carpeta.");
                try{synchronized(this){job(copy.id).pending=created.toString();save();}}catch(IOException e){SourcesActivity.Draft.discardCreated(app,created);throw e;}boolean done=false;
                try{SourcesActivity.Draft.copyToDocument(app,created,file,token);SourcesActivity.Draft.verifyDocumentSize(app,created,copy.bytes);token.check();synchronized(this){Job j=job(copy.id);j.exported=created.toString();j.pending="";try{save();}catch(IOException e){j.exported="";j.pending=created.toString();throw e;}}done=true;count++;}
                finally{if(!done&&SourcesActivity.Draft.discardCreated(app,created))synchronized(this){job(copy.id).pending="";save();}}
            }return count;
        }catch(IllegalArgumentException|SecurityException e){throw new IOException("Android ya no permite guardar en esa carpeta. Elígela otra vez.");}
        finally{synchronized(this){exporting=false;notifyChanged();}}
    }
    static String label(Job j){String status=switch(j.state){case "queued"->"En cola";case "running"->"Descargando";case "verifying"->"Comprobando";case "paused"->"Pausada";case "ready"->j.exported.isEmpty()?"Lista":"Guardada en carpeta";case "removing"->"Retirando";default->"Pendiente de reintento";};
        String bytes=String.format(Locale.ROOT,"%.1f",j.bytes/1048576.0)+" MiB";if(j.total>0)bytes=(Math.min(100,(j.bytes*100L)/j.total))+"% · "+bytes+" / "+String.format(Locale.ROOT,"%.1f",j.total/1048576.0)+" MiB";return j.name+"\n"+status+" · "+bytes;
    }
}
