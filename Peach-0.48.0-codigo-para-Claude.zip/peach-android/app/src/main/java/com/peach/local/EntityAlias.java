package com.peach.local;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;

@Entity(tableName="entity_aliases",primaryKeys={"entityId","name"},foreignKeys={
    @ForeignKey(entity=CatalogEntity.class,parentColumns="id",childColumns="entityId",onDelete=ForeignKey.CASCADE)})
public class EntityAlias {
    @NonNull public String entityId="";
    @NonNull public String name="";
}
