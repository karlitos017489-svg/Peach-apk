package com.peach.local;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Read projection: imported names and explicit user links remain distinguishable. */
public final class EntityIndex {
    public record Kind(String key,String label,List<String> facets) {}
    public record Relation(String mediaId,String role,String source,String term) {}
    public static final List<Kind> KINDS=List.of(
        new Kind("performer","Reparto",List.of("actors")),new Kind("studio","Estudio",List.of("studio")),
        new Kind("creator","Creadores / dirección / música",List.of("directors","artists","creators")),
        new Kind("series","Serie / colección",List.of("series","collection")),
        new Kind("tag","Etiqueta / género",List.of("tags","genres")),new Kind("agency","Agencias",List.of()));
    private EntityIndex() {}
    public static Kind kind(String key) {
        return KINDS.stream().filter(k->k.key().equals(key)).findFirst().orElseThrow(()->new IllegalArgumentException("Tipo de identidad inválido"));
    }
    public static String role(String facet) {
        return switch(facet) {case "actors"->"performer";case "directors"->"director";case "artists"->"artist";
            case "tags"->"tag";case "genres"->"genre";case "creators"->"creator";default->facet;};
    }
    public static List<String> roles(String kind) {
        if(kind.equals("agency"))return List.of();
        List<String> result=new ArrayList<>();result.add(kind);
        for(String facet:kind(kind).facets())if(!result.contains(role(facet)))result.add(role(facet));
        return result;
    }
    public static String roleLabel(String role) {
        return switch(role) {case "performer"->"Reparto";case "studio"->"Estudio";case "creator"->"Creación";
            case "director"->"Dirección";case "artist"->"Artista musical";case "series"->"Serie";
            case "collection"->"Colección";case "tag"->"Etiqueta";case "genre"->"Género";default->role;};
    }
    public static Set<String> names(CatalogEntity entity,List<EntityAlias> aliases) {
        Set<String> names=new LinkedHashSet<>();names.add(entity.name);
        for(EntityAlias alias:aliases)if(alias.entityId.equals(entity.id))names.add(alias.name);
        return names;
    }
    public static List<Relation> relations(CatalogEntity entity,List<MediaEntry> media,List<EntityAlias> aliases,List<MediaEntityLink> links) {
        List<Relation> result=new ArrayList<>();Set<String> names=names(entity,aliases),available=new HashSet<>();
        for(MediaEntry m:media) {
            available.add(m.id);
            for(String facet:kind(entity.kind).facets()) {
                for(String term:CatalogIndex.localValues(m,facet))if(names.contains(term))result.add(new Relation(m.id,role(facet),facet.equals("tags") && m.userTags!=null?"user-tags":"nfo",term));
                if(!facet.equals("tags") || m.userTags==null)for(String term:m.catalog().values(facet))if(names.contains(term))result.add(new Relation(m.id,role(facet),"catalog",term));
            }
        }
        for(MediaEntityLink link:links)if(link.entityId.equals(entity.id) && available.contains(link.mediaId))
            result.add(new Relation(link.mediaId,link.role,"manual",""));
        return result;
    }
    public static List<MediaEntry> select(List<MediaEntry> media,String id,List<CatalogEntity> entities,List<EntityAlias> aliases,List<MediaEntityLink> links) {
        return select(media,id,entities,aliases,links,List.of());
    }
    public static List<MediaEntry> select(List<MediaEntry> media,String id,List<CatalogEntity> entities,List<EntityAlias> aliases,List<MediaEntityLink> links,List<EntityMembership> memberships) {
        if(id.isEmpty())return media;
        CatalogEntity entity=entities.stream().filter(e->e.id.equals(id)).findFirst().orElse(null);if(entity==null)return List.of();
        Set<String> ids=new HashSet<>();for(Relation r:entity.kind.equals("agency")?AgencyStore.relations(entity,media,entities,aliases,links,memberships):relations(entity,media,aliases,links))ids.add(r.mediaId());
        List<MediaEntry> result=new ArrayList<>();for(MediaEntry m:media)if(ids.contains(m.id))result.add(m);return result;
    }
    public static List<MediaEntry> select(LibraryDao dao,List<MediaEntry> media,String id) {
        return id.isEmpty()?media:select(media,id,dao.entities(),dao.aliases(),dao.entityLinks(),dao.memberships());
    }
}
