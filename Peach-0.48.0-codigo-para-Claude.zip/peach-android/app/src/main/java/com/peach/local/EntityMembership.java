package com.peach.local;

import androidx.annotation.NonNull;
import androidx.room.*;

/** Current affiliation only; an agency is never a media file owner by implication. */
@Entity(tableName="entity_memberships",foreignKeys={
    @ForeignKey(entity=CatalogEntity.class,parentColumns="id",childColumns="memberId",onDelete=ForeignKey.CASCADE),
    @ForeignKey(entity=CatalogEntity.class,parentColumns="id",childColumns="agencyId",onDelete=ForeignKey.CASCADE)},indices={@Index("agencyId")})
public class EntityMembership {
    @PrimaryKey @NonNull public String memberId="";
    @NonNull public String agencyId="";
    @NonNull public String source="manual";
    @NonNull public String origin="manual";
    @NonNull public String checkedAt="";
    public double confidence=1;
}
