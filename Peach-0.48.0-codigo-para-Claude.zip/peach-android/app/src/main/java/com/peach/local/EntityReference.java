package com.peach.local;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;

@Entity(tableName="entity_references",primaryKeys={"entityId","provider","externalId"},foreignKeys={
    @ForeignKey(entity=CatalogEntity.class,parentColumns="id",childColumns="entityId",onDelete=ForeignKey.CASCADE)})
public class EntityReference {
    @NonNull public String entityId="";
    @NonNull public String provider="";
    @NonNull public String externalId="";
    @NonNull public String url="";
}
