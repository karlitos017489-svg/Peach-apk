package com.peach.local;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class EntityStore {
    private final LibraryDatabase db;
    public EntityStore(LibraryDatabase db){this.db=db;}
    public static String name(String value){return PlaylistStore.validName(value,300);}
    public static String notes(String value){if(value.length()>4000)throw new IllegalArgumentException("Usa hasta 4000 caracteres en las notas.");return value.trim();}
    public String create(String kind,String name,String notes) {
        CatalogEntity entity=new CatalogEntity();entity.id=UUID.randomUUID().toString();entity.kind=EntityIndex.kind(kind).key();
        entity.name=name(name);entity.notes=notes(notes);entity.createdAt=System.currentTimeMillis();
        db.runInTransaction(()->{db.library().insertEntity(entity);validateNames(db.library());});return entity.id;
    }
    public void edit(String id,String name,String notes) {
        db.runInTransaction(()-> {
            CatalogEntity entity=require(id);String old=entity.name;entity.name=name(name);entity.notes=notes(notes);
            db.library().updateEntity(entity);db.library().removeAlias(id,entity.name);
            if(!old.equals(entity.name))putAlias(id,old);
            validateNames(db.library());
        });
    }
    public void alias(String id,String value) {
        db.runInTransaction(()-> {CatalogEntity entity=require(id);String alias=name(value);
            if(!alias.equals(entity.name))putAlias(id,alias);validateNames(db.library());});
    }
    private void putAlias(String id,String value) {EntityAlias alias=new EntityAlias();alias.entityId=id;alias.name=value;db.library().insertAlias(alias);}
    public void link(String id,String mediaId,String role) {
        db.runInTransaction(()-> {
            CatalogEntity entity=require(id);
            if(db.library().get(mediaId)==null || !EntityIndex.roles(entity.kind).contains(role))throw new IllegalArgumentException("Archivo o función inválidos.");
            MediaEntityLink link=new MediaEntityLink();link.entityId=id;link.mediaId=mediaId;link.role=role;db.library().insertEntityLink(link);
        });
    }
    public void reference(String id,String provider,String externalId,String url) {
        EntityReference ref=new EntityReference();ref.entityId=id;ref.provider=PlaylistStore.validName(provider,80);
        ref.externalId=name(externalId);ref.url=validUrl(url);
        db.runInTransaction(()->{require(id);db.library().putEntityReference(ref);});
    }
    public static String validUrl(String value) {
        String url=value.trim();if(url.isEmpty())return url;
        try {java.net.URI uri=new java.net.URI(url);
            if(url.length()>2048 || !"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost()==null || uri.getUserInfo()!=null)
                throw new IllegalArgumentException("Usa una URL HTTPS sin credenciales, o deja el campo vacío.");
        }catch(java.net.URISyntaxException e){throw new IllegalArgumentException("URL inválida.");}return url;
    }
    private CatalogEntity require(String id) {CatalogEntity entity=db.library().entity(id);if(entity==null)throw new IllegalArgumentException("Identidad no disponible.");return entity;}
    public static void validateNames(LibraryDao dao) {
        Map<String,Map<String,String>> owners=new HashMap<>();Map<String,CatalogEntity> byId=new HashMap<>();
        for(CatalogEntity entity:dao.entities()) {
            EntityIndex.kind(entity.kind);name(entity.name);byId.put(entity.id,entity);
            claim(owners,entity.kind,entity.name,entity.id);
        }
        for(EntityAlias alias:dao.aliases()) {
            CatalogEntity entity=byId.get(alias.entityId);if(entity==null)throw new IllegalArgumentException("Alias sin identidad.");
            name(alias.name);claim(owners,entity.kind,alias.name,alias.entityId);
        }
    }
    private static void claim(Map<String,Map<String,String>> owners,String kind,String name,String id) {
        String old=owners.computeIfAbsent(kind,k->new HashMap<>()).putIfAbsent(name,id);
        if(old!=null && !old.equals(id))throw new IllegalArgumentException("Ese nombre o alias pertenece a otra identidad del mismo tipo.");
    }
}
