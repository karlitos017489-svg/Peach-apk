package com.peach.local;

import java.io.*;
import java.net.URI;
import java.nio.charset.*;
import java.nio.file.Files;
import java.util.*;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.*;
import org.xml.sax.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.TextNode;

/** Offline EPUB text subset. Package spine is authoritative; no HTML execution or remote resources. */
public final class EpubBook implements ArchiveBook {
    static final int MAX_METADATA=1024*1024,MAX_CHAPTER=2*1024*1024,MAX_CHAPTERS=1000;
    private static final String OPF="http://www.idpf.org/2007/opf",OCF="urn:oasis:names:tc:opendocument:xmlns:container";
    private final ZipBook zip;private final List<Item> items;private final List<String> chapters;
    public record Contents(String label,String path,String fragment,int depth) {}
    public record Chapter(TextPreview.Result preview,int anchor) {}
    private List<Contents> contents=List.of();private String navigationIssue="";
    private record Resource(String path,String mime,String properties){}
    private record Visit(org.jsoup.nodes.Node node,boolean tail){}
    public EpubBook(File source,File directory)throws IOException {
        zip=new ZipBook(source);
        try {
            if(!"application/epub+zip".equals(decode(metadata("mimetype",directory,100))))throw new IOException("No es un contenedor EPUB reconocido.");
            Element container=xml(metadata("META-INF/container.xml",directory,MAX_METADATA)).getDocumentElement();
            if(!matches(container,OCF,"container"))throw new IOException("Contenedor EPUB no válido.");
            Element rootfiles=child(container,OCF,"rootfiles"),rootfile=child(rootfiles,OCF,"rootfile");
            if(rootfile==null || !rootfile.getAttribute("media-type").equals("application/oebps-package+xml"))throw new IOException("Falta el paquete principal del EPUB.");
            String packagePath=resolve("",rootfile.getAttribute("full-path"));Element pkg=xml(metadata(packagePath,directory,MAX_METADATA)).getDocumentElement();
            if(!matches(pkg,OPF,"package") || !(pkg.getAttribute("version").startsWith("2.") || pkg.getAttribute("version").startsWith("3.")))throw new IOException("Versión o paquete EPUB no compatible.");
            Element manifest=child(pkg,OPF,"manifest"),spine=child(pkg,OPF,"spine");if(manifest==null || spine==null)throw new IOException("EPUB sin manifiesto o secuencia de lectura.");
            for(Element e:List.of(pkg,manifest,spine))if(e.hasAttributeNS("http://www.w3.org/XML/1998/namespace","base"))throw new IOException("EPUB con xml:base no admitido.");
            Map<String,Resource> resources=new LinkedHashMap<>();
            for(Element item:children(manifest,OPF,"item")) {
                if(resources.size()>=10000)throw new IOException("Manifiesto EPUB demasiado grande.");if(item.hasAttributeNS("http://www.w3.org/XML/1998/namespace","base"))throw new IOException("EPUB con xml:base no admitido.");String id=item.getAttribute("id");if(id.isBlank() || id.length()>300 || resources.containsKey(id))throw new IOException("Identificadores EPUB vacíos o duplicados.");
                String path;try{path=resolve(packagePath,item.getAttribute("href"));}catch(IOException e){path="";}resources.put(id,new Resource(path,item.getAttribute("media-type"),item.getAttribute("properties")));
            }
            List<String> order=new ArrayList<>();List<Item> found=new ArrayList<>();Set<String> used=new HashSet<>();int refs=0;
            for(Element ref:children(spine,OPF,"itemref")) {
                if(++refs>MAX_CHAPTERS)throw new IOException("EPUB con más de 1.000 referencias de capítulo.");if(ref.getAttribute("linear").equals("no"))continue;
                Resource resource=resources.get(ref.getAttribute("idref"));if(resource==null || !resource.mime.equals("application/xhtml+xml") || resource.path.isEmpty() || zip.item(resource.path)==null)throw new IOException("Capítulo EPUB ausente, externo o sin lector XHTML.");
                if(!used.add(resource.path))throw new IOException("EPUB con capítulos repetidos por ruta.");order.add(resource.path);found.add(new Item(resource.path,zip.item(resource.path).bytes(),DocumentRules.CHAPTER));
            }
            if(order.isEmpty())throw new IOException("EPUB sin capítulos XHTML de lectura principal.");
            List<Item> pictures=new ArrayList<>();for(Resource resource:resources.values())if(!resource.path.isEmpty() && resource.mime.startsWith("image/") && used.add(resource.path)) {
                Item item=zip.item(resource.path);if(item!=null && DocumentRules.entryKind(item.name()).equals(DocumentRules.IMAGE))pictures.add(new Item(item.name(),item.bytes(),DocumentRules.IMAGE));
            }
            pictures.sort((a,b)->DocumentRules.naturalCompare(a.name(),b.name()));found.addAll(pictures);items=List.copyOf(found);chapters=List.copyOf(order);
            encryption(resources,directory);
            try{contents=navigation(resources,spine,directory);}catch(IOException e){navigationIssue="Índice EPUB no compatible; se conserva el orden de capítulos del libro.";}
        }catch(IOException|RuntimeException|Error error){zip.close();throw error;}
    }
    public List<Item> items(){return items;}
    public List<String> chapters(){return chapters;}
    public List<Contents> contents(){return contents;}
    public String navigationIssue(){return navigationIssue;}
    private void encryption(Map<String,Resource> resources,File directory)throws IOException {
        if(zip.item("META-INF/encryption.xml")==null)return;
        Element root=xml(metadata("META-INF/encryption.xml",directory,MAX_METADATA)).getDocumentElement();
        if(!matches(root,OCF,"encryption"))throw new IOException("EPUB cifrado no compatible.");
        List<Element> entries=children(root,"http://www.w3.org/2001/04/xmlenc#","EncryptedData");
        if(entries.isEmpty() || entries.size()>1000)throw new IOException("EPUB cifrado no compatible.");
        for(Element entry:entries) {
            String ns="http://www.w3.org/2001/04/xmlenc#";Element method=child(entry,ns,"EncryptionMethod"),data=child(entry,ns,"CipherData"),reference=child(data,ns,"CipherReference");
            if(method==null || reference==null || !Set.of("http://www.idpf.org/2008/embedding","http://ns.adobe.com/pdf/enc#RC").contains(method.getAttribute("Algorithm")))throw new IOException("EPUB con DRM o contenido cifrado no admitido.");
            String path=resolve("",reference.getAttribute("URI"));
            boolean font=resources.values().stream().anyMatch(r->r.path.equals(path) && Set.of("font/otf","font/ttf","application/vnd.ms-opentype","application/x-font-ttf","application/x-font-opentype","application/font-sfnt").contains(r.mime));
            if(!font || zip.item(path)==null)throw new IOException("EPUB: solo se omite ofuscación estándar de fuentes; el texto y las imágenes deben estar sin cifrar.");
        }
    }
    private List<Contents> navigation(Map<String,Resource> resources,Element spine,File directory)throws IOException {
        List<Resource> navs=resources.values().stream().filter(r->Arrays.asList(r.properties.split("\\s+")).contains("nav")).toList();
        List<Contents> rows=new ArrayList<>();
        if(!navs.isEmpty()) {
            if(navs.size()!=1)throw new IOException();Resource r=navs.get(0);if(!r.mime.equals("application/xhtml+xml"))throw new IOException();
            Element doc=xml(metadata(r.path,directory,MAX_METADATA)).getDocumentElement();
            NodeList nodes=doc.getElementsByTagNameNS("http://www.w3.org/1999/xhtml","nav");Element toc=null;
            for(int i=0;i<nodes.getLength();i++){Element e=(Element)nodes.item(i);if(Arrays.asList(e.getAttributeNS("http://www.idpf.org/2007/ops","type").split("\\s+")).contains("toc")){if(toc!=null)throw new IOException();toc=e;}}
            if(toc==null)throw new IOException();NodeList links=toc.getElementsByTagNameNS("http://www.w3.org/1999/xhtml","a");
            for(int i=0;i<links.getLength();i++){Element a=(Element)links.item(i);int depth=-1;for(Node n=a;n!=toc;n=n.getParentNode()){if(n==null)throw new IOException();if(n instanceof Element e && "ol".equals(e.getLocalName()))depth++;}addContents(rows,r.path,a.getAttribute("href"),a.getTextContent(),Math.max(0,depth));}
        }else {
            Resource r=resources.get(spine.getAttribute("toc"));if(r==null)return List.of();if(!r.mime.equals("application/x-dtbncx+xml"))throw new IOException();
            String ns="http://www.daisy.org/z3986/2005/ncx/";Element doc=xml(metadata(r.path,directory,MAX_METADATA)).getDocumentElement();if(!matches(doc,ns,"ncx"))throw new IOException();
            Element map=child(doc,ns,"navMap");if(map==null)throw new IOException();NodeList points=map.getElementsByTagNameNS(ns,"navPoint");
            for(int i=0;i<points.getLength();i++){Element p=(Element)points.item(i),label=child(child(p,ns,"navLabel"),ns,"text"),content=child(p,ns,"content");if(label==null || content==null)throw new IOException();int depth=0;for(Node n=p.getParentNode();n!=map;n=n.getParentNode()){if(n==null)throw new IOException();depth++;}addContents(rows,r.path,content.getAttribute("src"),label.getTextContent(),depth);}
        }
        return List.copyOf(rows);
    }
    private void addContents(List<Contents> rows,String base,String href,String label,int depth)throws IOException {
        if(rows.size()>=1000 || depth>32)throw new IOException();String path=resolve(base,href);if(!chapters.contains(path))throw new IOException();
        String fragment;try{fragment=Objects.toString(new URI(href).getFragment(),"");}catch(Exception e){throw new IOException(e);}
        if(fragment.length()>300 || fragment.chars().anyMatch(c->c<32))throw new IOException();
        label=label.replaceAll("\\s+"," ").trim();if(label.isEmpty() || label.length()>300)throw new IOException();
        rows.add(new Contents(label,path,fragment,depth));
    }
    private byte[] metadata(String name,File directory,int max)throws IOException {
        Item item=zip.item(name);if(item==null || item.bytes()<0 || item.bytes()>max)throw new IOException("Recurso de metadatos EPUB ausente o fuera del límite.");
        // ZipBook only exposes document/image extensions. Metadata is read through a bounded raw path.
        return zip.bytes(name,max);
    }
    public File read(String name,File directory)throws IOException {
        Item item=item(name);if(item==null)throw new IOException("Entrada EPUB no disponible.");
        if(item.kind().equals(DocumentRules.CHAPTER) && item.bytes()>MAX_CHAPTER)throw new IOException("Capítulo EPUB mayor de 2 MiB.");
        return item.kind().equals(DocumentRules.CHAPTER)?zip.readRaw(name,directory,MAX_CHAPTER):zip.read(name,directory);
    }
    static String resolve(String base,String href)throws IOException {
        try {
            if(href.isEmpty() || href.length()>4096)throw new IllegalArgumentException();URI reference=new URI(href);if(reference.isAbsolute() || reference.getRawAuthority()!=null || reference.getRawQuery()!=null || reference.getPath()==null || reference.getPath().isEmpty() || reference.getPath().startsWith("/"))throw new IllegalArgumentException();
            String path=reference.getPath();if(path.indexOf('\\')>=0 || path.chars().anyMatch(c->c<32))throw new IllegalArgumentException();
            String parent=base.contains("/")?base.substring(0,base.lastIndexOf('/')+1):"";Deque<String> parts=new ArrayDeque<>();
            for(String part:(parent+path).split("/")){if(part.isEmpty() || part.equals("."))continue;if(part.equals("..")){if(parts.isEmpty())throw new IllegalArgumentException();parts.removeLast();}else parts.addLast(part);}
            String name=String.join("/",parts);ZipBook.safeName(name);return name;
        }catch(Exception e){throw new IOException("Referencia EPUB externa o fuera del contenedor.",e);}
    }
    static String decode(byte[] raw)throws IOException {
        int offset=0;Charset charset=StandardCharsets.UTF_8;if(raw.length>=3 && (raw[0]&255)==239 && (raw[1]&255)==187 && (raw[2]&255)==191)offset=3;
        else if(raw.length>=2 && (raw[0]&255)==255 && (raw[1]&255)==254){offset=2;charset=StandardCharsets.UTF_16LE;}
        else if(raw.length>=2 && (raw[0]&255)==254 && (raw[1]&255)==255){offset=2;charset=StandardCharsets.UTF_16BE;}
        try{return charset.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(java.nio.ByteBuffer.wrap(raw,offset,raw.length-offset)).toString();}
        catch(CharacterCodingException e){throw new IOException("EPUB: usa texto UTF-8 o UTF-16 con BOM.",e);}
    }
    private static org.w3c.dom.Document xml(byte[] raw)throws IOException {
        String value=decode(raw),upper=value.toUpperCase(Locale.ROOT);if(upper.contains("<!DOCTYPE") || upper.contains("<!ENTITY"))throw new IOException("Metadatos EPUB con DTD o entidades no admitidos.");
        try {
            DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance();factory.setNamespaceAware(true);factory.setExpandEntityReferences(false);var builder=factory.newDocumentBuilder();
            builder.setEntityResolver((p,s)->{throw new SAXException("Referencia externa no admitida.");});builder.setErrorHandler(new org.xml.sax.helpers.DefaultHandler(){public void error(org.xml.sax.SAXParseException e)throws SAXException{throw e;}public void fatalError(org.xml.sax.SAXParseException e)throws SAXException{throw e;}});
            return builder.parse(new InputSource(new StringReader(value)));
        }catch(Exception e){throw new IOException("Metadatos EPUB XML no válidos.",e);}
    }
    private static boolean matches(Element e,String ns,String tag){return e!=null && ns.equals(e.getNamespaceURI()) && tag.equals(e.getLocalName());}
    private static List<Element> children(Element parent,String ns,String tag){List<Element> found=new ArrayList<>();if(parent!=null)for(Node n=parent.getFirstChild();n!=null;n=n.getNextSibling())if(n instanceof Element e && matches(e,ns,tag))found.add(e);return found;}
    private static Element child(Element parent,String ns,String tag){return children(parent,ns,tag).stream().findFirst().orElse(null);}
    private static String localTag(org.jsoup.nodes.Element element){String name=element.normalName();return name.substring(name.lastIndexOf(':')+1);}
    public static TextPreview.Result preview(File file)throws IOException {return chapter(file,"").preview();}
    public static Chapter chapter(File file,String fragment)throws IOException {
        if(file.length()>MAX_CHAPTER)throw new IOException("Capítulo EPUB mayor de 2 MiB.");var document=Jsoup.parse(decode(Files.readAllBytes(file.toPath())));
        Set<String> excluded=Set.of("head","script","style","noscript","template","iframe","object","embed","svg","math","video","audio");
        for(var element:document.getAllElements())if(excluded.contains(localTag(element)) || element.hasAttr("hidden") || element.attr("aria-hidden").equalsIgnoreCase("true"))element.remove();
        StringBuilder text=new StringBuilder();Set<String> blocks=Set.of("p","div","section","article","h1","h2","h3","h4","h5","h6","li","tr","blockquote","pre","br","hr");
        Deque<Visit> nodes=new ArrayDeque<>();nodes.push(new Visit(document.body(),false));int count=0,anchor=-1;boolean truncated=false;
        while(!nodes.isEmpty()) {
            if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();Visit visit=nodes.pop();var node=visit.node();if(visit.tail()){text.append('\n');continue;}if(++count>50000)throw new IOException("Capítulo EPUB con demasiados nodos.");
            if(node instanceof TextNode value)text.append(value.getWholeText());
            else if(node instanceof org.jsoup.nodes.Element element){if(anchor<0 && !fragment.isEmpty() && (element.id().equals(fragment) || localTag(element).equals("a") && element.attr("name").equals(fragment)))anchor=normalize(text.toString()).length();if(blocks.contains(localTag(element))){text.append('\n');if(element.childNodeSize()>0)nodes.push(new Visit(element,true));}if(localTag(element).equals("img"))text.append("[Imagen").append(element.attr("alt").isBlank()?"":": "+element.attr("alt")).append("] ");for(int i=element.childNodeSize()-1;i>=0;i--)nodes.push(new Visit(element.childNode(i),false));}
            if(text.length()>TextPreview.MAX_CHARS){truncated=true;break;}
        }
        String value=normalize(text.toString());if(value.length()>TextPreview.MAX_CHARS)value=value.substring(0,TextPreview.MAX_CHARS);if(!value.isEmpty() && Character.isHighSurrogate(value.charAt(value.length()-1))){value=value.substring(0,value.length()-1);truncated=true;}
        return new Chapter(new TextPreview.Result(value,truncated),anchor<0?-1:Math.min(anchor,value.length()));
    }
    private static String normalize(String value){return value.replaceAll("[\\t\\x0B\\f\\r ]+"," ").replaceAll(" *\n *","\n").replaceAll("\n{3,}","\n\n").trim();}
    @Override public void close()throws IOException{zip.close();}
}
