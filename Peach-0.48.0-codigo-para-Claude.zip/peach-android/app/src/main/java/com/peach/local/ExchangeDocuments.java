package com.peach.local;

import android.content.Context;
import android.net.Uri;
import android.provider.DocumentsContract;
import java.io.*;
import java.nio.charset.StandardCharsets;

/** Only user-picked documents. A new version is created; a shared file is never overwritten. */
final class ExchangeDocuments {
    private ExchangeDocuments(){}
    static void selected(Uri uri)throws IOException{if(uri==null || !"content".equals(uri.getScheme()))throw new IOException("Elige un documento con el selector de Android.");}
    static void writeNew(Context context,Uri uri,PortableState.Packet packet)throws Exception {
        selected(uri);boolean complete=false;
        try{
            try(OutputStream out=context.getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException("Destino no disponible.");byte[] data=packet.encoded.getBytes(StandardCharsets.UTF_8);for(int offset=0;offset<data.length;){ExchangeJson.check();int n=Math.min(16384,data.length-offset);out.write(data,offset,n);offset+=n;}}
            try(InputStream in=context.getContentResolver().openInputStream(uri)){PortableState.Packet actual=new PortableState.Packet(ExchangeJson.read(in));if(!actual.encoded.equals(packet.encoded))throw new IOException("El proveedor no conservó el documento completo.");}
            complete=true;
        }finally{if(!complete)try{DocumentsContract.deleteDocument(context.getContentResolver(),uri);}catch(Exception ignored){/* Only this newly created destination; never older user files. */}}
    }
}
