package com.peach.local;

import java.io.*;
import java.nio.*;
import java.nio.charset.*;
import java.security.*;
import java.util.*;
import org.json.*;

/** Bounded deterministic JSON. The digest detects changes, not who authored a file. */
final class ExchangeJson {
    static final int MAX=16*1024*1024;
    private ExchangeJson(){}
    static void check()throws InterruptedIOException{if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("Intercambio cancelado.");}
    static JSONObject read(InputStream input)throws Exception {
        if(input==null)throw new IOException("Documento no disponible.");ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[16384];int n;
        while((n=input.read(b))!=-1){check();if(n==0 || n>MAX-out.size())throw new IOException("Intercambio fuera del límite de 16 MiB.");out.write(b,0,n);}
        String s=StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(out.toByteArray())).toString();
        depth(s);JSONTokener tokener=new JSONTokener(s);Object value=tokener.nextValue();if(!(value instanceof JSONObject object) || tokener.nextClean()!=0)throw new IOException("Se requiere un único objeto JSON.");canonical(object);return object;
    }
    static void depth(String s)throws IOException {
        int depth=0,tokens=0;boolean string=false,escape=false;
        for(int i=0;i<s.length();i++){char c=s.charAt(i);if(string){if(escape)escape=false;else if(c=='\\')escape=true;else if(c=='"')string=false;}else if(c=='"'){string=true;if(++tokens>600000)throw new IOException("Demasiados campos de intercambio.");}else if(c=='{' || c=='['){if(++depth>40)throw new IOException("JSON demasiado anidado.");}else if(c=='}' || c==']'){if(--depth<0)throw new IOException("JSON inválido.");}}
        if(string || depth!=0)throw new IOException("JSON incompleto.");
    }
    static String canonical(Object o)throws JSONException {
        if(o==null || o==JSONObject.NULL)return "null";
        if(o instanceof JSONObject j){List<String> keys=new ArrayList<>();j.keys().forEachRemaining(keys::add);Collections.sort(keys);List<String> pairs=new ArrayList<>();for(String k:keys)pairs.add(quote(k)+":"+canonical(j.get(k)));return "{"+String.join(",",pairs)+"}";}
        if(o instanceof JSONArray a){List<String> rows=new ArrayList<>();for(int i=0;i<a.length();i++)rows.add(canonical(a.get(i)));return "["+String.join(",",rows)+"]";}
        if(o instanceof String s)return quote(s);
        if(o instanceof Boolean)return o.toString();
        if(o instanceof Number n && Double.isFinite(n.doubleValue()))return JSONObject.numberToString(n);
        throw new JSONException("Valor JSON no compatible.");
    }
    private static String quote(String s)throws JSONException {
        StringBuilder out=new StringBuilder("\"");char[] hex="0123456789abcdef".toCharArray();
        for(int i=0;i<s.length();i++){char c=s.charAt(i);switch(c){case '\"'->out.append("\\\"");case '\\'->out.append("\\\\");case '\b'->out.append("\\b");case '\f'->out.append("\\f");case '\n'->out.append("\\n");case '\r'->out.append("\\r");case '\t'->out.append("\\t");default->{if(c<32)out.append("\\u00").append(hex[c>>>4]).append(hex[c&15]);else if(Character.isHighSurrogate(c)){if(i+1>=s.length() || !Character.isLowSurrogate(s.charAt(i+1)))throw new JSONException("Unicode incompleto.");out.append(c).append(s.charAt(++i));}else if(Character.isLowSurrogate(c))throw new JSONException("Unicode incompleto.");else out.append(c);}}}return out.append('\"').toString();
    }
    static String hash(String s){try{byte[] bytes=MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8));char[] hex=new char[64],digits="0123456789abcdef".toCharArray();for(int i=0;i<bytes.length;i++){hex[2*i]=digits[(bytes[i]&255)>>>4];hex[2*i+1]=digits[bytes[i]&15];}return new String(hex);}catch(Exception e){throw new AssertionError(e);}}
    static boolean same(Object a,Object b){try{return canonical(a).equals(canonical(b));}catch(JSONException e){throw new IllegalArgumentException(e);}}
    static JSONObject copy(JSONObject j)throws JSONException{return new JSONObject(j.toString());}
    static void keys(JSONObject j,Set<String> expected)throws IOException{Set<String> actual=new HashSet<>();j.keys().forEachRemaining(actual::add);if(!actual.equals(expected))throw new IOException("Campos de intercambio ausentes o desconocidos.");}
    static String text(JSONObject j,String key,int max)throws Exception{Object v=j.opt(key);if(!(v instanceof String s) || s.length()>max || s.indexOf('\0')>=0)throw new IOException("Texto de intercambio inválido: "+key);return s;}
    static long integer(JSONObject j,String key)throws Exception{Object v=j.opt(key);if(!(v instanceof Integer || v instanceof Long) || ((Number)v).longValue()<0)throw new IOException("Entero de intercambio inválido: "+key);return ((Number)v).longValue();}
}
