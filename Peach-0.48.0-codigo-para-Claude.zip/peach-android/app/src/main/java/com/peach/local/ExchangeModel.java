package com.peach.local;

import android.app.Application;
import android.net.Uri;
import androidx.lifecycle.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

/** Retained draft. Opening or rotating this screen does not read a cloud document or apply data. */
public final class ExchangeModel extends AndroidViewModel {
    final ExecutorService worker=Executors.newSingleThreadExecutor();final MutableLiveData<Integer> updates=new MutableLiveData<>(0);
    final ExchangeStore store;volatile boolean busy,launchExport;volatile String message="Exporta una versión o elige un intercambio para revisar. No se transfieren archivos multimedia, permisos ni sesiones.";
    volatile PortableState.Packet packet;volatile ExchangeStore.Review review;volatile Uri selected;
    volatile List<LibraryRoot> roots=List.of();volatile List<MediaEntry> media=List.of();volatile Map<String,String> labels=Map.of();
    final Map<String,String> rootBindings=new HashMap<>(),manualBindings=new HashMap<>();final Map<String,Boolean> choices=new HashMap<>();
    private Future<?> pending;private volatile InputStream active;private volatile boolean closed;
    public ExchangeModel(Application app){super(app);store=new ExchangeStore(app,LibraryDatabase.get(app));}
    private void publish(){if(!closed)updates.postValue(updates.getValue()==null?1:updates.getValue()+1);}
    interface Job{void run()throws Exception;}
    private void run(Job job){if(busy)return;busy=true;publish();pending=worker.submit(()->{try{job.run();}catch(Exception e){message=e instanceof IOException || e instanceof IllegalArgumentException?Objects.toString(e.getMessage(),"No se pudo completar el intercambio."):"Datos o vínculos no válidos. Conserva la biblioteca actual y revisa los campos elegidos.";}finally{busy=false;publish();}});}
    void prepare(String label){run(()->{var out=store.export(label);ExchangeStore.write(new File(store.directory,"prepared.json"),out.encoded,ExchangeJson.MAX);message="Intercambio preparado. Elige dónde guardar una nueva versión.";launchExport=true;});}
    void save(Uri uri){run(()->{ExchangeDocuments.selected(uri);PortableState.Packet p;try(var in=new android.util.AtomicFile(new File(store.directory,"prepared.json")).openRead()){p=new PortableState.Packet(ExchangeJson.read(in));}ExchangeDocuments.writeNew(getApplication(),uri,p);message="Nueva versión guardada y comprobada. Puedes llevar este archivo al otro dispositivo o guardarlo con un proveedor de nube.";});}
    private PortableState.Packet read(Uri uri)throws Exception{ExchangeDocuments.selected(uri);try(InputStream in=getApplication().getContentResolver().openInputStream(uri)){active=in;return store.parse(in);}finally{active=null;}}
    void load(Uri uri){run(()->{PortableState.Packet incoming=read(uri);packet=incoming;selected=uri;review=null;rootBindings.clear();manualBindings.clear();choices.clear();loadLocal();
        if(incoming.peer.equals(store.peer()))for(int i=0;i<incoming.data.getJSONArray("roots").length();i++){var r=incoming.data.getJSONArray("roots").getJSONObject(i);for(LibraryRoot local:roots)if(r.getString("id").equals("r-"+ExchangeJson.hash(local.uri)))rootBindings.put(r.getString("id"),local.uri);}
        review=store.review(packet,rootBindings,manualBindings);message=summary();});}
    private void loadLocal(){roots=store.db.library().roots();media=store.db.library().allMedia();Map<String,String> names=new HashMap<>();for(MediaEntry m:media)names.put(m.id,m.folder+" / "+m.name);for(CatalogEntity e:store.db.library().entities())names.put(e.id,e.name);for(Publication p:store.db.library().publications())names.put(p.id,p.title);labels=Map.copyOf(names);}
    void refresh(){Map<String,String> rootsCopy=Map.copyOf(rootBindings),manualCopy=Map.copyOf(manualBindings);run(()->{if(packet==null)return;loadLocal();review=store.review(packet,rootsCopy,manualCopy);choices.clear();message=summary();});}
    String summary(){if(review==null)return message;long matched=review.mapping.stream().filter(m->!m.local().isEmpty()).count(),conflicts=review.fields.changes.stream().filter(FieldMerge.Change::conflict).count();return packet.label+" · archivos vinculados "+matched+" / "+review.mapping.size()+"\nCambios revisables: "+review.fields.changes.size()+" · conflictos: "+conflicts+"\nGrupos de vínculos protegidos por correspondencias incompletas: "+review.blocked.size()+"\nRuta y tamaño son una propuesta; no prueban que los bytes sean idénticos. Lo no vinculado permanece en el archivo de intercambio. No se borran registros por faltar en el archivo.";}
    void apply(){Map<String,Boolean> selectedChoices=Map.copyOf(choices);run(()->{if(review==null || selected==null)throw new IOException("Primero elige y revisa un intercambio.");PortableState.Packet current=read(selected);if(!current.encoded.equals(packet.encoded))throw new IOException("El archivo de intercambio cambió. Vuelve a elegirlo antes de aplicar.");int changes=store.apply(review,selectedChoices);message="Aplicados "+changes+" cambios elegidos. Se conserva la última importación para Deshacer mientras la biblioteca no cambie.";review=null;choices.clear();});}
    void undo(){run(()->{store.undo();review=null;message="Última importación deshecha. Se conservan los originales y las sesiones de cuenta.";});}
    void forget(String peer){run(()->{store.forget(peer);message="Base de sincronización olvidada; la próxima revisión pedirá resolver diferencias otra vez.";review=null;});}
    void cancel(){if(pending!=null)pending.cancel(true);InputStream in=active;if(in!=null)try{in.close();}catch(IOException ignored){}message="Cancelación solicitada. Si ya se aplicó, usa Deshacer.";publish();}
    @Override protected void onCleared(){closed=true;cancel();worker.shutdownNow();}
}
