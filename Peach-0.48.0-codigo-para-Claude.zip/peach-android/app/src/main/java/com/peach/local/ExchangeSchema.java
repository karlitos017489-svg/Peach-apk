package com.peach.local;
import java.io.*;
import java.util.*;
import org.json.*;
/** Exact fields for the v19 state carried by exchange v1; unknown fields are never silently applied. */
final class ExchangeSchema {
    static final Map<String,Set<String>> FIELDS=new LinkedHashMap<>();
    static {add("items","id favorite watched position duration lastPlayed playCount userTitle userTags");add("playlists","id name createdAt items");add("groups","id name createdAt items");add("entities","id kind name notes favorite createdAt");add("aliases","entityId name");add("entityLinks","entityId mediaId role");add("entityReferences","entityId provider externalId url");add("wants","id title code notes entityId mediaId createdAt");add("readerProgress","mediaId entry page scroll updatedAt");add("catalogSnapshots","id label payload bindings importedAt");add("memberships","memberId agencyId source origin checkedAt confidence");add("wantTracking","id state releaseDate origin source lastSearchAt lastSearchOutcome lastSearchNote acquiredAt acquiredBatch priorState publicationId searchCount updatedAt");add("publications","id title provider sourceRef sourceLabel externalId url publishedAt precision semantics releaseKey variant variantLabel status origin notes entityId mediaId createdAt");add("sources","id provider ref label cachedPage pageUrls lastError etag modified revision nextPage cachePage checkedAt cooldownUntil paused entityId");add("publicationContent","publicationId sourceId text attachments type partial checkedAt");add("usageSessions","id mediaId kind title startedAt updatedAt position duration entry page scroll status completed");}
    private static void add(String section,String fields){FIELDS.put(section,Set.of(fields.split(" ")));}
    static void validate(JSONObject state)throws Exception {
        Set<String> nullable=Set.of("entityId","mediaId","publicationId","sourceId","userTitle","userTags"),bool=Set.of("favorite","watched","paused","partial","completed"),numbers=Set.of("position","duration","lastPlayed","playCount","createdAt","page","scroll","updatedAt","importedAt","searchCount","revision","nextPage","cachePage","checkedAt","cooldownUntil","startedAt");
        int total=0;for(String section:PortableState.SECTIONS){JSONArray rows=state.getJSONArray(section);if(rows.length()>50000 || (total+=rows.length())>180000)throw new IOException("Demasiados registros de intercambio.");for(int i=0;i<rows.length();i++){JSONObject row=rows.getJSONObject(i);ExchangeJson.keys(row,FIELDS.get(section));for(String key:FIELDS.get(section)){
            Object v=row.get(key);if(v==JSONObject.NULL){if(!nullable.contains(key))throw new IOException("Campo obligatorio sin valor: "+key);continue;}
            if(bool.contains(key)){if(!(v instanceof Boolean))throw new IOException("Estado booleano inválido.");}
            else if(key.equals("confidence")){if(!(v instanceof Number n) || !Double.isFinite(n.doubleValue()) || n.doubleValue()<0 || n.doubleValue()>1)throw new IOException("Confianza inválida.");}
            else if(numbers.contains(key) && !(key.equals("checkedAt") && section.equals("memberships")))ExchangeJson.integer(row,key);
            else if(Set.of("payload","bindings").contains(key)){if(!(v instanceof JSONObject))throw new IOException("Catálogo inválido.");}
            else if(Set.of("items","attachments").contains(key)){if(!(v instanceof JSONArray a))throw new IOException("Miembros inválidos.");if(key.equals("items"))for(int j=0;j<a.length();j++)if(!(a.get(j) instanceof String))throw new IOException("Referencia de lista inválida.");}
            else if(!(v instanceof String s) || s.indexOf('\0')>=0 || s.length()>1024*1024)throw new IOException("Campo textual inválido: "+key);
        }}}
    }
}
