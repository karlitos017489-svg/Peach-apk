package com.peach.local;

import android.content.Context;
import android.util.AtomicFile;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;

/** Explicit exchange, detached validation and exact-state local undo; no network or scheduler. */
final class ExchangeStore {
    private static final Object LOCK=new Object();
    final Context context;final LibraryDatabase db;final File directory;
    record Mapping(String remote,String local,String path,String state){}
    static final class Review {
        final PortableState.Packet packet;final FieldMerge.Plan fields;final Map<String,String> bindings;final Map<String,String> roots;final List<Mapping> mapping;final Set<String> blocked;final String baselineStamp;
        Review(PortableState.Packet packet,FieldMerge.Plan fields,Map<String,String> bindings,Map<String,String> roots,List<Mapping> mapping,Set<String> blocked,String baselineStamp){this.packet=packet;this.fields=fields;this.bindings=Map.copyOf(bindings);this.roots=Map.copyOf(roots);this.mapping=List.copyOf(mapping);this.blocked=Set.copyOf(blocked);this.baselineStamp=baselineStamp;}
    }
    ExchangeStore(Context context,LibraryDatabase db){this.context=context.getApplicationContext();this.db=db;directory=new File(context.getNoBackupFilesDir(),"peach-exchange");}
    String peer(){var p=context.getSharedPreferences("exchange-identity",Context.MODE_PRIVATE);String id=p.getString("id","");if(!id.isEmpty())return id;id=UUID.randomUUID().toString();if(!p.edit().putString("id",id).commit())throw new IllegalStateException("No se pudo guardar la identidad de intercambio.");return id;}
    PortableState.Packet export(String label)throws Exception{synchronized(LOCK){PortableState.Snapshot snapshot=PortableState.capture(db);String id=peer();var preferences=context.getSharedPreferences("exchange-identity",Context.MODE_PRIVATE);long sequence=preferences.getLong("sequence",0)+1;if(sequence<1 || sequence>9000000000000000L || !preferences.edit().putLong("sequence",sequence).commit())throw new IOException("No se pudo guardar la versión de origen.");return PortableState.export(snapshot,id,label,sequence);}}
    PortableState.Packet parse(InputStream in)throws Exception{PortableState.Packet p=new PortableState.Packet(ExchangeJson.read(in));PortableState.validate(context,p);return p;}
    private File peerFile(String peer){UsageStore.uuid(peer);return new File(directory,"peer-"+peer+".json");}
    private PortableState.Packet baseline(String peer)throws Exception{File f=peerFile(peer);if(!f.exists())return null;try(var in=new AtomicFile(f).openRead()){return new PortableState.Packet(ExchangeJson.read(in));}}
    Review review(PortableState.Packet packet,Map<String,String> roots,Map<String,String> manual)throws Exception {
        PortableState.Snapshot local=PortableState.capture(db);Map<String,JSONObject> localMedia=PortableState.rows(local.media(),"id");Set<String> completeRoots=new HashSet<>();for(LibraryRoot root:db.library().roots())if(root.state==0)completeRoots.add(root.uri);
        Map<String,List<JSONObject>> paths=new HashMap<>();for(JSONObject m:localMedia.values())if(!m.getBoolean("missing") && completeRoots.contains(m.getString("root")))paths.computeIfAbsent(m.getString("root")+"\0"+m.getString("path"),k->new ArrayList<>()).add(m);
        Map<String,String> ids=new HashMap<>();List<Mapping> mappings=new ArrayList<>();Map<String,Integer> uses=new HashMap<>();
        JSONArray rows=packet.data.getJSONArray("media");for(int i=0;i<rows.length();i++){
            ExchangeJson.check();JSONObject m=rows.getJSONObject(i);String id=m.getString("id"),target="",why="Sin vincular",root=roots.getOrDefault(m.getString("root"),"");
            if(manual.containsKey(id)){JSONObject candidate=localMedia.get(manual.get(id));if(candidate!=null && !candidate.getBoolean("missing") && completeRoots.contains(candidate.getString("root")) && candidate.getLong("bytes")==m.getLong("bytes") && PortableState.family(candidate.getString("name")).equals(PortableState.family(m.getString("name")))){target=candidate.getString("id");why="Vínculo elegido";}else why="Vínculo elegido no válido";}
            else if(!root.isEmpty()){
                if(!completeRoots.contains(root))why="Carpeta aún sin escaneo completo";
                else {List<JSONObject> candidates=paths.getOrDefault(root+"\0"+m.getString("path"),List.of());if(candidates.size()>1)why="Ruta local ambigua";else if(candidates.size()==1){JSONObject c=candidates.get(0);if(c.getLong("bytes")==m.getLong("bytes") && PortableState.family(c.getString("name")).equals(PortableState.family(m.getString("name")))){target=c.getString("id");why="Ruta y tamaño coinciden";}else why="Tamaño o familia diferente";}else why="Ruta no encontrada";}
            }
            if(!target.isEmpty()){ids.put(id,target);uses.merge(target,1,Integer::sum);}mappings.add(new Mapping(id,target,m.getString("path"),why));
        }
        for(int i=0;i<mappings.size();i++){Mapping m=mappings.get(i);if(!m.local.isEmpty() && uses.get(m.local)>1){ids.remove(m.remote);mappings.set(i,new Mapping(m.remote,"",m.path,"Varios documentos para un archivo local"));}}
        Set<String> blocked=new HashSet<>();PortableState.Snapshot incoming=PortableState.mapped(packet,ids);protectPartial(packet,ids,incoming,local,blocked);
        PortableState.Packet previous=baseline(packet.peer);if(previous!=null){if(packet.sequence<previous.sequence)throw new IOException("El intercambio es una versión anterior de este origen. Exporta una nueva versión o, si deseas restaurar una antigua, olvida explícitamente su base.");if(packet.sequence==previous.sequence && !packet.digest.equals(previous.digest))throw new IOException("El origen tiene dos contenidos con la misma versión. Conserva el original y exporta una versión nueva.");}PortableState.Snapshot base=previous==null?null:PortableState.mapped(previous,ids);
        return new Review(packet,FieldMerge.plan(local,incoming,base,blocked),ids,roots,mappings,blocked,previous==null?"":ExchangeJson.hash(previous.encoded));
    }
    private void protectPartial(PortableState.Packet p,Map<String,String> ids,PortableState.Snapshot incoming,PortableState.Snapshot local,Set<String> blocked)throws Exception {
        JSONObject original=p.data.getJSONObject("state");
        for(String section:List.of("playlists","groups")){JSONArray rows=original.getJSONArray(section);Map<String,JSONObject> current=PortableState.rows(local.state().getJSONArray(section),"id");for(int i=0;i<rows.length();i++){JSONObject row=rows.getJSONObject(i);JSONArray members=row.getJSONArray("items");boolean partial=false;for(int j=0;j<members.length();j++)partial|=!ids.containsKey(members.getString(j));if(partial)blocked.add(FieldMerge.key(section,row.getString("id"))+(current.containsKey(row.getString("id"))?"\0items":""));}}
        for(String section:List.of("wants","publications")){JSONArray rows=original.getJSONArray(section);for(int i=0;i<rows.length();i++){JSONObject row=rows.getJSONObject(i);if(!row.isNull("mediaId") && !ids.containsKey(row.getString("mediaId")))blocked.add(FieldMerge.key(section,row.getString("id"))+"\0mediaId");}}
        Map<String,JSONObject> localCatalogs=PortableState.rows(local.state().getJSONArray("catalogSnapshots"),"id"),mappedCatalogs=PortableState.rows(incoming.state().getJSONArray("catalogSnapshots"),"id");
        JSONArray catalogs=original.getJSONArray("catalogSnapshots");for(int i=0;i<catalogs.length();i++){JSONObject source=catalogs.getJSONObject(i),current=localCatalogs.get(source.getString("id")),target=mappedCatalogs.get(source.getString("id"));if(current==null)continue;JSONObject rawBindings=source.getJSONObject("bindings"),localBindings=current.getJSONObject("bindings"),bindings=target.getJSONObject("bindings");var keys=rawBindings.keys();while(keys.hasNext()){String asset=keys.next();if(!ids.containsKey(rawBindings.getString(asset)) && localBindings.has(asset)){bindings.put(asset,localBindings.getString(asset));blocked.add(FieldMerge.key("catalogSnapshots",source.getString("id"))+"\0unresolvedBindings");}}}
        // Links outside mapped media belong to the local library, not to a remote deletion.
        JSONArray links=incoming.state().getJSONArray("entityLinks"),old=local.state().getJSONArray("entityLinks");Set<String> mapped=new HashSet<>(ids.values()),entities=new HashSet<>();JSONArray e=incoming.state().getJSONArray("entities");for(int i=0;i<e.length();i++)entities.add(e.getJSONObject(i).getString("id"));for(int i=0;i<old.length();i++){JSONObject link=old.getJSONObject(i);if(entities.contains(link.getString("entityId")) && !mapped.contains(link.getString("mediaId")))links.put(ExchangeJson.copy(link));}
    }
    PortableState.Snapshot resolved(Review review,Map<String,Boolean> choices)throws Exception{return review.fields.resolve(choices);}
    private void validateResolved(PortableState.Snapshot before,PortableState.Snapshot after)throws Exception {
        var staging=androidx.room.Room.inMemoryDatabaseBuilder(context,LibraryDatabase.class).build();try{
            staging.runInTransaction(()->{for(int i=0;i<before.media().length();i++){JSONObject row=before.media().optJSONObject(i);MediaEntry m=new MediaEntry();m.id=row.optString("id");m.name=row.optString("name");m.mediaType=MediaRules.type(m.name);staging.library().insertMedia(m);}});
            PortableState.restore(staging,before,false);PortableState.restore(staging,after,true);
            // Backup restore clamps invalid AV positions. Never claim an unrepresentable value applied.
            JSONArray items=after.state().getJSONArray("items");for(int i=0;i<items.length();i++){JSONObject row=items.getJSONObject(i);long position=ExchangeJson.integer(row,"position"),duration=ExchangeJson.integer(row,"duration");if(duration>0 && position>duration)throw new IOException("La posición supera la duración; conserva el conjunto de progreso de una sola versión.");}
        }finally{staging.close();}
    }
    int apply(Review review,Map<String,Boolean> choices)throws Exception {synchronized(LOCK){
        PortableState.Packet previousBase=baseline(review.packet.peer);if(!review.baselineStamp.equals(previousBase==null?"":ExchangeJson.hash(previousBase.encoded)))throw new IOException("La base de sincronización cambió. Genera una revisión nueva.");
        ExchangeJson.check();PortableState.Snapshot selected=resolved(review,choices);validateResolved(review.fields.local,selected);
        File peerFile=peerFile(review.packet.peer);if(!peerFile.exists() && peerCount()>=4)throw new IOException("Máximo cuatro orígenes de sincronización. Puedes olvidar uno desde esta pantalla.");
        String previous=peerFile.exists()?readText(peerFile):"";int[] applied={0};Exception[] error={null};
        try{db.runInTransaction(()->{try{
            PortableState.Snapshot before=PortableState.capture(db);if(!before.stamp().equals(review.fields.stamp))throw new IOException("La biblioteca cambió después de revisar. Genera una revisión nueva.");
            ExchangeJson.check();PortableState.restore(db,selected,true);PortableState.Snapshot after=PortableState.capture(db);
            for(FieldMerge.Change c:review.fields.changes)if(choices.getOrDefault(c.key(),c.incomingDefault()))applied[0]++;
            JSONObject undo=new JSONObject().put("version",1).put("before",snapshot(before)).put("after",after.stamp()).put("peer",review.packet.peer).put("previous",previous).put("changes",applied[0]);ExchangeJson.check();if(!after.stamp().equals(before.stamp()))write(new File(directory,"undo.json"),undo.toString(),64*1024*1024);ExchangeJson.check();
        }catch(Exception e){error[0]=e;throw new Abort();}});}catch(Abort e){throw error[0];}
        if(error[0]!=null)throw error[0];
        try{write(peerFile,review.packet.encoded,ExchangeJson.MAX);}catch(Exception e){throw new IOException("Los datos se aplicaron y se conserva Deshacer; no se pudo actualizar la base de sincronización. Revisa el espacio y vuelve a importar el archivo.",e);}
        context.getSharedPreferences("exchange-identity",Context.MODE_PRIVATE).edit().putString("label:"+review.packet.peer,review.packet.label).apply();
        return applied[0];
    }}
    static final class Abort extends RuntimeException{}
    private int peerCount(){File[] files=directory.listFiles((d,n)->n.matches("peer-[a-f0-9-]{36}\\.json"));return files==null?0:files.length;}
    List<String> peers(){File[] files=directory.listFiles((d,n)->n.matches("peer-[a-f0-9-]{36}\\.json"));if(files==null)return List.of();return Arrays.stream(files).map(f->f.getName().substring(5,41)).sorted().toList();}
    void forget(String peer){synchronized(LOCK){new AtomicFile(peerFile(peer)).delete();context.getSharedPreferences("exchange-identity",Context.MODE_PRIVATE).edit().remove("label:"+peer).apply();}}
    boolean hasUndo(){return new File(directory,"undo.json").exists();}
    void undo()throws Exception {synchronized(LOCK){
        JSONObject undo=readLarge(new File(directory,"undo.json"),64*1024*1024);if(undo.getInt("version")!=1)throw new IOException("Registro de recuperación no compatible.");PortableState.Snapshot before=fromSnapshot(undo.getJSONObject("before"));String expected=undo.getString("after");
        Exception[] error={null};try{db.runInTransaction(()->{try{if(!PortableState.capture(db).stamp().equals(expected))throw new IOException("La biblioteca cambió; no se deshace sobre cambios nuevos.");
            for(String table:List.of("usage_sessions","reader_progress","publication_content","follow_sources","want_items","publications","entity_memberships","entity_aliases","media_entity_links","entity_references","playlist_items","playlists","media_group_items","media_groups","catalog_snapshots","catalog_entities"))db.getOpenHelper().getWritableDatabase().execSQL("DELETE FROM "+table);
            PortableState.restore(db,before,false);
        }catch(Exception e){error[0]=e;throw new Abort();}});}catch(Abort e){throw error[0];}
        String previous=undo.getString("previous");if(previous.isEmpty())forget(undo.getString("peer"));else write(peerFile(undo.getString("peer")),previous,ExchangeJson.MAX);new AtomicFile(new File(directory,"undo.json")).delete();
    }}
    private static JSONObject snapshot(PortableState.Snapshot s)throws Exception{return new JSONObject().put("state",s.state()).put("metadata",s.metadata()).put("media",s.media()).put("roots",s.roots()).put("guard",s.guard());}
    private static PortableState.Snapshot fromSnapshot(JSONObject j)throws Exception{return new PortableState.Snapshot(j.getJSONObject("state"),j.getJSONArray("metadata"),j.getJSONArray("media"),j.getJSONArray("roots"),j.getString("guard"));}
    static void write(File file,String body,int max)throws Exception{byte[] bytes=body.getBytes(StandardCharsets.UTF_8);if(bytes.length>max)throw new IOException("Registro local demasiado grande.");File parent=file.getParentFile();if(!parent.exists() && !parent.mkdirs())throw new IOException("No se pudo preparar el registro local.");AtomicFile atomic=new AtomicFile(file);FileOutputStream out=atomic.startWrite();try{out.write(bytes);atomic.finishWrite(out);}catch(Exception e){atomic.failWrite(out);throw e;}}
    private static String readText(File f)throws Exception{return readLarge(f,ExchangeJson.MAX).toString();}
    private static JSONObject readLarge(File f,int max)throws Exception{try(var in=new AtomicFile(f).openRead();var out=new ByteArrayOutputStream()){byte[] b=new byte[16384];int n;while((n=in.read(b))!=-1){if(n==0 || n>max-out.size())throw new IOException("Registro local fuera de límites.");out.write(b,0,n);}String s=out.toString("UTF-8");ExchangeJson.depth(s);return new JSONObject(s);}}
}
