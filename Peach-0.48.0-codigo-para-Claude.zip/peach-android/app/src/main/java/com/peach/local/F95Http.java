package com.peach.local;
import javax.net.ssl.HttpsURLConnection;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Session is confined to exact f95zone.to routes. POST resolves one masked reference; no target fetch. */
final class F95Http {
    interface Transport{SourceHttp.Response request(String url,boolean masked,F95Session session,String etag,String modified,SourceHttp.Token token)throws IOException;}
    static Transport direct(){return direct(u->(HttpsURLConnection)new URL(u).openConnection(),InetAddress::getAllByName);}
    static Transport direct(SourceHttp.ConnectionFactory factory,MediaRedirects.Resolver dns){return(original,masked,session,etag,modified,token)->{
        try{if(masked)F95Urls.masked(original);else F95Urls.thread(original);}catch(IllegalArgumentException e){throw new IOException("Ruta F95 no admitida.");}if(session==null)throw new IOException("Configura tu sesión F95 propia en la tablet.");String current=original;
        for(int redirects=0;redirects<=3;redirects++){token.check();GofileUrls.publicHost(current,dns,token);HttpsURLConnection c=null;try{c=factory.open(current);token.connection=c;c.setInstanceFollowRedirects(false);c.setUseCaches(false);c.setConnectTimeout(15000);c.setReadTimeout(15000);c.setRequestProperty("User-Agent","PeachLocal-Android/0.37.0");c.setRequestProperty("Accept",masked?"application/json":"text/html");c.setRequestProperty("Accept-Encoding","identity");c.setRequestProperty("Cookie",session.value());c.setRequestMethod(masked?"POST":"GET");
            if(masked){c.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");c.setRequestProperty("X-Requested-With","XMLHttpRequest");c.setDoOutput(true);byte[] body="xhr=1&download=1".getBytes(StandardCharsets.US_ASCII);c.setFixedLengthStreamingMode(body.length);try(OutputStream out=c.getOutputStream()){token.check();out.write(body);}}
            else{if(!SourceHttp.header(etag).isEmpty()&&!session.containsSecret(etag))c.setRequestProperty("If-None-Match",etag);if(!SourceHttp.header(modified).isEmpty()&&!session.containsSecret(modified))c.setRequestProperty("If-Modified-Since",modified);}
            token.check();int status=c.getResponseCode();token.check();if(status==429)throw new SourceHttp.Failure("F95 pidió esperar antes de consultar de nuevo (HTTP429).",429,SourceHttp.retry(c.getHeaderField("Retry-After")));
            if(Set.of(301,302,303,307,308).contains(status)){if(masked||redirects==3)throw new IOException("Redirección F95 no admitida.");String location=c.getHeaderField("Location");if(location==null)throw new IOException("Redirección F95 sin destino.");try{String next=WebSourceUrls.cleanRedirect(original,URI.create(current).resolve(location).toString());WebSourceUrls.redirect(original,next);if(session.containsSecret(next))throw new IllegalArgumentException();current=next;}catch(IllegalArgumentException e){throw new IOException("F95 redirigió fuera del hilo admitido.");}continue;}
            if(status!=200&&!(status==304&&!masked))throw new SourceHttp.Failure(status==401||status==403?"F95 rechazó el acceso; la sesión puede haber caducado o requerir verificación en el sitio.":"F95 respondió HTTP "+status+".",status,0);
            if(status==304)return new SourceHttp.Response(status,new byte[0],SourceHttp.header(session.redact(c.getHeaderField("ETag"))),SourceHttp.header(session.redact(c.getHeaderField("Last-Modified"))));String mime=Objects.toString(c.getContentType(),"").toLowerCase(Locale.ROOT),encoding=Objects.toString(c.getHeaderField("Content-Encoding"),"");if(masked?!mime.startsWith("application/json"):!mime.startsWith("text/html")&&!mime.startsWith("application/xhtml+xml"))throw new IOException("F95 no devolvió el formato esperado.");if(!encoding.isEmpty()&&!encoding.equalsIgnoreCase("identity")||c.getContentLengthLong()>SourceHttp.JSON_LIMIT)throw new IOException("Respuesta F95 fuera del formato o límite admitido.");byte[] raw;try(InputStream in=c.getInputStream()){raw=SourceHttp.bounded(in,SourceHttp.JSON_LIMIT,token);}String text=SourceHttp.utf8(raw);if(!masked)text=session.redact(text);return new SourceHttp.Response(status,text.getBytes(StandardCharsets.UTF_8),SourceHttp.header(session.redact(c.getHeaderField("ETag"))),SourceHttp.header(session.redact(c.getHeaderField("Last-Modified"))));
        }catch(SourceHttp.Failure e){throw e;}catch(InterruptedIOException e){throw new InterruptedIOException("Consulta F95 cancelada o agotada.");}catch(IOException|IllegalArgumentException e){throw new IOException("No se pudo consultar F95. Sesión oculta y contenido actual conservado.");}finally{if(c!=null)c.disconnect();token.connection=null;}}
        throw new IOException("Demasiadas redirecciones F95.");
    };}
}
