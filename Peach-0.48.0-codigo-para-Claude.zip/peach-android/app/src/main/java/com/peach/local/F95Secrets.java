package com.peach.local;
import android.content.Context;
import android.util.AtomicFile;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

/** Separate bounded AES-GCM session vault and durable site wait; no plaintext fallback. */
final class F95Secrets implements F95MaskedReview.Access {
    static final Object LOCK=new Object();final File file,wait;final SourceSecrets.KeyProvider keys;
    F95Secrets(Context app){this(new File(app.getNoBackupFilesDir(),"source-f95-session.bin"),new File(app.getNoBackupFilesDir(),"source-f95-wait.txt"),()->SourceSecrets.key("PeachF95SessionV1"));}
    F95Secrets(File file,File wait,SourceSecrets.KeyProvider keys){this.file=file;this.wait=wait;this.keys=keys;}
    void write(F95Session session)throws IOException{synchronized(LOCK){byte[] clear=session.value().getBytes(StandardCharsets.UTF_8);try{Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,keys.get());byte[] iv=cipher.getIV(),sealed=cipher.doFinal(clear);if(iv.length!=12)throw new GeneralSecurityException();AtomicFile target=new AtomicFile(file);FileOutputStream out=null;try{out=target.startWrite();out.write(1);out.write(iv);out.write(sealed);target.finishWrite(out);}catch(IOException e){if(out!=null)target.failWrite(out);throw e;}}catch(GeneralSecurityException e){throw new IOException("No se pudo cifrar la sesión F95; no se guardó en texto plano.");}finally{Arrays.fill(clear,(byte)0);}}}
    public F95Session read()throws IOException{synchronized(LOCK){if(!file.exists()&&!new File(file+".bak").exists())return null;try(InputStream in=new AtomicFile(file).openRead()){byte[] encoded=SourceHttp.bounded(in,16384,new SourceHttp.Token());if(encoded.length<30||encoded[0]!=1)throw new GeneralSecurityException();Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,keys.get(),new GCMParameterSpec(128,Arrays.copyOfRange(encoded,1,13)));byte[] clear=cipher.doFinal(encoded,13,encoded.length-13);try{return new F95Session(SourceHttp.utf8(clear));}finally{Arrays.fill(clear,(byte)0);}}catch(GeneralSecurityException|IllegalArgumentException e){throw new IOException("No se pudo descifrar la sesión F95. Vuelve a configurarla en la tablet.");}}}
    void clear(){synchronized(LOCK){new AtomicFile(file).delete();}}
    public long waitUntil()throws IOException{synchronized(LOCK){if(!wait.exists()&&!new File(wait+".bak").exists())return 0;try(InputStream in=new AtomicFile(wait).openRead()){String value=new String(SourceHttp.bounded(in,64,new SourceHttp.Token()),StandardCharsets.US_ASCII);if(!value.matches("[0-9]{1,16}"))throw new IOException("Espera F95 no válida.");return Long.parseLong(value);}catch(NumberFormatException e){throw new IOException("Espera F95 no válida.");}}}
    public void waitUntil(long end)throws IOException{synchronized(LOCK){long until=Math.max(waitUntil(),Math.min(System.currentTimeMillis()+86400000L,end));AtomicFile target=new AtomicFile(wait);FileOutputStream out=null;try{out=target.startWrite();out.write(Long.toString(until).getBytes(StandardCharsets.US_ASCII));target.finishWrite(out);}catch(IOException e){if(out!=null)target.failWrite(out);throw e;}}}
}
