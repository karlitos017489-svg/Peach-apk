package com.peach.local;
import java.util.*;

/** User-supplied session, never a browser-cookie reader or an embedded account. */
record F95Session(String value) {
    F95Session {
        if(value==null||value.isBlank()||value.length()>8192||value.chars().anyMatch(c->c<32||c>126))throw new IllegalArgumentException("Sesión F95 no válida: usa solo su cabecera Cookie, sin saltos de línea.");
        if(value.regionMatches(true,0,"Cookie:",0,7))value=value.substring(7).trim();
        Set<String> names=new HashSet<>();List<String> pairs=new ArrayList<>();boolean session=false;
        for(String raw:value.split(";",-1)){String pair=raw.trim();int equal=pair.indexOf('=');if(equal<1)throw new IllegalArgumentException("Formato de sesión F95 no válido.");String name=pair.substring(0,equal),v=pair.substring(equal+1);
            if(!name.matches("[!#$%&'*+.^_`|~0-9A-Za-z-]{1,100}")||!names.add(name)||names.size()>64||v.chars().anyMatch(c->!(c==33||c>=35&&c<=43||c>=45&&c<=58||c>=60&&c<=91||c>=93&&c<=126)))throw new IllegalArgumentException("Formato de sesión F95 no válido.");
            if(Set.of("xf_user","xf_session").contains(name)&&!v.isEmpty())session=true;pairs.add(name+"="+v);
        }
        if(!session)throw new IllegalArgumentException("Falta una cookie de tu sesión F95 (xf_user o xf_session).");value=String.join("; ",pairs);if(value.length()>8192)throw new IllegalArgumentException("Sesión F95 mayor de8KiB.");
    }
    List<String> secrets(){List<String> out=new ArrayList<>();out.add(value);for(String pair:value.split("; ")){int equal=pair.indexOf('=');String name=pair.substring(0,equal),v=pair.substring(equal+1);if(!v.isEmpty()&&(Set.of("xf_user","xf_session","cf_clearance").contains(name)||v.length()>=8))out.add(v);}return out;}
    String redact(String text){String out=Objects.toString(text,"");for(String secret:secrets()){out=out.replace(secret,"[oculto]").replace(WebSourceUrls.enc(secret),"[oculto]");}return out;}
    boolean containsSecret(String text){return !Objects.toString(text,"").equals(redact(text));}
    String fingerprint(){return PartialDownload.key(value);}
    @Override public String toString(){return "F95Session[oculta]";}
}
