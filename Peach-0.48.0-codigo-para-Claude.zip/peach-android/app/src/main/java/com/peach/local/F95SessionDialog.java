package com.peach.local;
import android.app.Activity;
import android.view.WindowManager;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import java.util.function.Consumer;

/** Advanced optional import only. It cannot read another browser's private cookies. */
final class F95SessionDialog {
    static void show(Activity owner,Consumer<F95Session> save,Runnable clear){LinearLayout form=new LinearLayout(owner);form.setOrientation(LinearLayout.VERTICAL);TextView note=new TextView(owner);note.setText("Opcional avanzado: pega la cabecera Cookie de tu propia sesión F95 si ya la tienes. No es tu contraseña. Peach no extrae sesiones de Chrome ni inicia sesión o resuelve CAPTCHA. Se cifra solo en esta tablet y se envía únicamente a f95zone.to, nunca Gofile u otros archivos. No la envíes por chat.");form.addView(note);EditText input=new EditText(owner);input.setHint("Cookie de sesión F95");input.setContentDescription("Sesión F95 propia");input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);input.setSaveEnabled(false);input.setSingleLine(true);form.addView(input);AlertDialog dialog=new AlertDialog.Builder(owner).setTitle("Sesión F95 · opcional").setView(form).setPositiveButton("Guardar sesión",null).setNeutralButton("Borrar sesión",(d,w)->{input.setText("");clear.run();}).setNegativeButton("Cancelar",null).create();dialog.setOnShowListener(d->{dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{F95Session session=new F95Session(input.getText().toString().trim());input.setText("");save.accept(session);dialog.dismiss();}catch(IllegalArgumentException e){Toast.makeText(owner,e.getMessage(),Toast.LENGTH_LONG).show();}});});dialog.setOnDismissListener(d->input.setText(""));dialog.show();}
    static void invalidate(LibraryDatabase db){db.runInTransaction(()->{for(FollowSource s:db.library().sources())if(s.provider.equals("f95zone")){s.etag="";s.modified="";s.checkedAt=0;s.revision++;db.library().updateSource(s);}});}
}
