package com.peach.local;
import java.net.URI;

final class F95Urls {
    static String masked(String raw){URI u=WebSourceUrls.url(raw);if(!"f95zone.to".equals(u.getHost())||u.getRawQuery()!=null||!u.getRawPath().matches("/masked/[A-Za-z0-9_-]{1,512}/?"))throw new IllegalArgumentException("Enlace masked F95 no admitido.");return raw;}
    static boolean isMasked(String raw){try{masked(raw);return true;}catch(IllegalArgumentException e){return false;}}
    static void thread(String raw){WebSourceUrls.validateHtml(raw);if(!"f95zone.to".equals(WebSourceUrls.url(raw).getHost()))throw new IllegalArgumentException("Página de otra fuente.");}
    static String target(String raw){try{String folder=GofileUrls.share(raw);return "https://gofile.io/d/"+folder;}catch(IllegalArgumentException ignored){}URI u=WebSourceUrls.url(raw);if(u.getRawQuery()!=null)throw new IllegalArgumentException("Destino con parámetros no incorporado.");if(WebSourceUrls.downloadable(raw)&&"attachments.f95zone.to".equals(u.getHost()))return raw;if("pixeldrain.com".equals(u.getHost())&&u.getRawPath().matches("/u/[A-Za-z0-9_-]{6,64}/?"))return raw;throw new IllegalArgumentException("Destino externo todavía no incorporado.");}
}
