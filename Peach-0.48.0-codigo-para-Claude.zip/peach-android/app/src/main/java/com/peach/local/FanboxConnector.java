package com.peach.local;

import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;

/** FANBOX public/free list, real cursor pages, and plain native content. */
public final class FanboxConnector {
    public static final int MAX_TEXT=200000,MAX_ATTACHMENTS=100;
    private final SourceHttp.Transport http;private final boolean account;
    public FanboxConnector(SourceHttp.Transport http){this(http,false);}
    FanboxConnector(SourceHttp.Transport http,boolean account){this.http=http;this.account=account;}
    boolean accessible(JSONObject p){return free(p)||account&&Boolean.FALSE.equals(p.opt("isRestricted"))&&p.opt("feeRequired") instanceof Number n&&n.doubleValue()>=0;}
    public static String creator(String input){String ref=input.trim();if(ref.startsWith("https://")){URI u=SourceHttp.https(ref);String host=u.getHost().toLowerCase(Locale.ROOT);if(host.endsWith(".fanbox.cc") && !Set.of("www.fanbox.cc","api.fanbox.cc","downloads.fanbox.cc").contains(host))ref=host.substring(0,host.length()-10);else if(Set.of("fanbox.cc","www.fanbox.cc").contains(host) && u.getPath().startsWith("/@"))ref=u.getPath().substring(2).split("/")[0];else throw new IllegalArgumentException("Usa el identificador o la página de un creador de FANBOX.");}
        if(!ref.matches("[A-Za-z0-9_-]{1,64}") || Set.of("www","api","downloads").contains(ref.toLowerCase(Locale.ROOT)))throw new IllegalArgumentException("Identificador de creador FANBOX no válido.");return ref.toLowerCase(Locale.ROOT);}
    static String id(Object v)throws IOException{String s=String.valueOf(v);if(!s.matches("[0-9]{1,30}"))throw new IOException("Identificador de publicación no válido.");return s;}
    static String text(JSONObject row,String key){Object v=row.opt(key);return v instanceof String s?s:"";}
    static boolean free(JSONObject p){return Boolean.FALSE.equals(p.opt("isRestricted")) && p.opt("feeRequired") instanceof Number n && n.doubleValue()==0;}
    static String clipped(String text,int max){if(text.length()<=max)return text;int end=max;if(end>0 && Character.isHighSurrogate(text.charAt(end-1)))end--;return text.substring(0,end);}
    static String plain(String raw){return raw.replaceAll("(?is)<(script|style)\\b[^>]*>.*?</\\1\\s*>","").replaceAll("(?s)<[^>]{0,10000}>"," ").replace("&amp;","&").replace("&lt;","<").replace("&gt;",">").replace("&quot;","\"").replace("&#39;","'").trim();}
    static JSONObject payload(SourceHttp.Response r)throws IOException {if(r.bytes().length>SourceHttp.JSON_LIMIT)throw new IOException("Respuesta demasiado grande.");try{JSONObject json=new JSONObject(SourceHttp.utf8(r.bytes()));if(json.has("error") && !json.isNull("error"))throw new IOException("La fuente devolvió un error de API.");return json.getJSONObject("body");}catch(JSONException e){throw new IOException("La fuente cambió su formato JSON.",e);}}
    public SourcePage newest(String ref,String etag,String modified,SourceHttp.Token token)throws IOException{return list(ref,"https://api.fanbox.cc/post.listCreator?creatorId="+creator(ref)+"&limit=10",etag,modified,token);}
    public SourcePage list(String ref,String url,String etag,String modified,SourceHttp.Token token)throws IOException {
        cursor(url,ref);SourceHttp.Response response=http.get(url,etag,modified,token);if(response.status()==304)return new SourcePage(new JSONArray(),etag,modified,0,true);if(response.status()!=200)throw new IOException("Estado HTTP de fuente no válido.");
        try{JSONArray posts=payload(response).getJSONArray("posts");if(posts.length()>100)throw new IOException("Demasiadas publicaciones en una página.");JSONArray result=new JSONArray();Set<String> ids=new HashSet<>();int skipped=0;
            for(int i=0;i<posts.length();i++){JSONObject p=posts.getJSONObject(i);String post=id(p.opt("id"));if(!ids.add(post))throw new IOException("Publicación duplicada en la página.");if(!accessible(p)){skipped++;continue;}String owner=text(p,"creatorId");if(!owner.isEmpty() && !owner.equals(ref))throw new IOException("La publicación pertenece a otro creador.");String title=clipped(plain(text(p,"title")),300);if(title.isBlank())title="FANBOX #"+post;String date=text(p,"publishedDatetime");String precision=date.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}.*")?"exact":"unknown";
                result.put(new JSONObject().put("id",post).put("title",title).put("date",date).put("precision",precision).put("text",clipped(plain(text(p,"excerpt")),MAX_TEXT)).put("attachments",new JSONArray()).put("partial",true).put("type","list"));}
            return new SourcePage(result,SourceHttp.header(response.etag()),SourceHttp.header(response.modified()),skipped,false);
        }catch(JSONException e){throw new IOException("Lista de publicaciones no válida.",e);}
    }
    public JSONArray pages(String ref,SourceHttp.Token token)throws IOException {
        try{JSONArray pages=payload(http.get("https://api.fanbox.cc/post.paginateCreator?creatorId="+creator(ref),"","",token)).getJSONArray("pageUrls");if(pages.length()>5000)throw new IOException("Demasiadas páginas históricas.");for(int i=0;i<pages.length();i++)cursor(pages.getString(i),ref);return pages;}catch(JSONException e){throw new IOException("Índice de páginas no válido.",e);}
    }
    static void cursor(String url,String ref)throws IOException {
        try{SourceHttp.api(url);URI u=SourceHttp.https(url);if(!u.getPath().equals("/post.listCreator"))throw new IllegalArgumentException();Map<String,String> query=new HashMap<>();for(String part:Objects.toString(u.getRawQuery(),"").split("&")){String[] p=part.split("=",2);String key=URLDecoder.decode(p[0],"UTF-8");if(query.put(key,p.length==2?URLDecoder.decode(p[1],"UTF-8"):"")!=null)throw new IllegalArgumentException();}if(!creator(ref).equals(query.get("creatorId")) || !query.containsKey("limit") || Integer.parseInt(query.get("limit"))>100 || Integer.parseInt(query.get("limit"))<1)throw new IllegalArgumentException();for(String key:query.keySet())if(!Set.of("creatorId","limit","firstPublishedDatetime","firstId","sort","withPinned").contains(key))throw new IllegalArgumentException();}catch(Exception e){throw new IOException("Cursor de FANBOX no válido para este creador.",e);}
    }
    public JSONObject detail(String ref,String postId,SourceHttp.Token token)throws IOException {
        try{JSONObject post=payload(http.get("https://api.fanbox.cc/post.info?postId="+id(postId),"","",token)).getJSONObject("post");if(!id(post.opt("id")).equals(postId) || !text(post,"creatorId").equals(creator(ref)) || !accessible(post))throw new IOException("La fuente no devolvió acceso al cuerpo de este creador.");return content(post);}catch(JSONException e){throw new IOException("Detalle de publicación no válido.",e);}
    }
    static JSONObject content(JSONObject post)throws IOException,JSONException {
        JSONObject body=post.optJSONObject("body");if(body==null)throw new IOException("La publicación no incluye cuerpo público.");String type=text(post,"type");boolean partial=!Set.of("article","image","text","file","entry","video").contains(type);StringBuilder text=new StringBuilder();JSONArray attachments=new JSONArray();Set<String> urls=new HashSet<>();
        append(text,text(body,"text"));if(!text(body,"html").isBlank()){append(text,plain(text(body,"html")));partial=true;}
        JSONObject images=body.optJSONObject("imageMap"),files=body.optJSONObject("fileMap");JSONArray blocks=body.optJSONArray("blocks");Set<String> usedImages=new HashSet<>(),usedFiles=new HashSet<>();
        if(blocks!=null){if(blocks.length()>10000)throw new IOException("Demasiados bloques en la publicación.");for(int i=0;i<blocks.length();i++){JSONObject b=blocks.getJSONObject(i);String kind=text(b,"type");switch(kind){case "p","header"->append(text,text(b,"text"));case "image"->{String id=text(b,"imageId");usedImages.add(id);attachment(images==null?null:images.optJSONObject(id),"image",attachments,urls);}case "file"->{String id=text(b,"fileId");usedFiles.add(id);attachment(files==null?null:files.optJSONObject(id),"file",attachments,urls);}case "url_embed","embed"->{String key=kind.equals("embed")?"embedMap":"urlEmbedMap",idkey=kind.equals("embed")?"embedId":"urlEmbedId";JSONObject map=body.optJSONObject(key),node=map==null?null:map.optJSONObject(text(b,idkey));if(node!=null)append(text,text(node,"url"));partial=true;}default->partial=true;}}}
        if(images!=null){var keys=images.keys();while(keys.hasNext()){String id=keys.next();if(!usedImages.contains(id))attachment(images.optJSONObject(id),"image",attachments,urls);}}
        if(files!=null){var keys=files.keys();while(keys.hasNext()){String id=keys.next();if(!usedFiles.contains(id))attachment(files.optJSONObject(id),"file",attachments,urls);}}
        for(String key:List.of("images","files")){JSONArray rows=body.optJSONArray(key);if(rows!=null){if(rows.length()>1000)throw new IOException("Demasiados adjuntos.");for(int i=0;i<rows.length();i++)attachment(rows.optJSONObject(i),key.equals("images")?"image":"file",attachments,urls);}}
        if(type.equals("video")){JSONObject video=body.optJSONObject("video");if(video!=null){append(text,text(video,"url"));String service=text(video,"serviceProvider"),id=text(video,"videoId");if(!id.isBlank())append(text,"Video externo · "+service+" · "+id);}partial=true;}
        if(text.length()>MAX_TEXT)partial=true;
        return new JSONObject().put("text",clipped(text.toString().trim(),MAX_TEXT)).put("attachments",attachments).put("partial",partial).put("type",type);
    }
    static void append(StringBuilder out,String value){if(!value.isBlank() && out.length()<=MAX_TEXT+8192){if(out.length()>0)out.append('\n');out.append(clipped(value,MAX_TEXT+8192));}}
    static void attachment(JSONObject node,String kind,JSONArray out,Set<String> seen)throws JSONException,IOException {
        if(node==null)return;String url=text(node,"originalUrl");if(url.isEmpty())url=text(node,"url");try{SourceHttp.https(url);}catch(IllegalArgumentException e){return;}if(!seen.add(url))return;if(out.length()>=MAX_ATTACHMENTS)throw new IOException("Más de 100 adjuntos; la publicación no se guardó parcialmente.");
        String name=text(node,"name"),extension=text(node,"extension");if(name.isBlank()){String path=SourceHttp.https(url).getPath();name=path.substring(path.lastIndexOf('/')+1);}if(name.isBlank())name="adjunto";name=name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]","_");name=clipped(name,120);if(extension.matches("[A-Za-z0-9]{1,12}") && !name.toLowerCase(Locale.ROOT).endsWith("."+extension.toLowerCase(Locale.ROOT)))name+="."+extension;
        if(kind.equals("file")&&Set.of("mp4","webm","mkv","mov","m4v").contains(MediaRules.extension(name).toLowerCase(Locale.ROOT)))kind="video";
        out.put(new JSONObject().put("name",name).put("kind",kind).put("url",url).put("downloadable",SourceHttp.downloadable(url)));
    }
}
