package com.peach.local;

import java.io.*;
import java.util.*;
import org.json.*;

/** Three-way per-field review. Absence of a remote record is never a deletion instruction. */
final class FieldMerge {
    record Row(String section,String id,JSONObject fields){}
    record Change(String key,String section,String id,String field,Object local,Object incoming,boolean conflict,boolean incomingDefault){}
    static final class Plan {
        final PortableState.Snapshot local,incoming;final LinkedHashMap<String,Row> localRows,remoteRows;final List<Change> changes;final String stamp;
        Plan(PortableState.Snapshot local,PortableState.Snapshot incoming,LinkedHashMap<String,Row> a,LinkedHashMap<String,Row> b,List<Change> changes)throws Exception{this.local=local;this.incoming=incoming;localRows=a;remoteRows=b;this.changes=List.copyOf(changes);stamp=local.stamp();}
        PortableState.Snapshot resolve(Map<String,Boolean> choices)throws Exception {
            Map<String,Change> byField=new HashMap<>();for(Change c:changes)byField.put(c.section+"\0"+c.id+"\0"+c.field,c);
            LinkedHashMap<String,Row> result=new LinkedHashMap<>();for(var e:localRows.entrySet())result.put(e.getKey(),new Row(e.getValue().section,e.getValue().id,ExchangeJson.copy(e.getValue().fields)));
            for(Row remote:remoteRows.values()) {
                String key=key(remote.section,remote.id);Row current=result.get(key);
                if(current==null){Change c=byField.get(key+"\0$record");if(c!=null && choices.getOrDefault(c.key,c.incomingDefault))result.put(key,new Row(remote.section,remote.id,ExchangeJson.copy(remote.fields)));continue;}
                for(String field:fields(remote.fields)){Change c=byField.get(key+"\0"+field);if(c!=null && choices.getOrDefault(c.key,c.incomingDefault))current.fields.put(field,remote.fields.get(field));}
            }
            return inflate(result);
        }
    }
    static Plan plan(PortableState.Snapshot local,PortableState.Snapshot incoming,PortableState.Snapshot base,Set<String> blocked)throws Exception {
        LinkedHashMap<String,Row> a=flatten(local),b=flatten(incoming),old=base==null?new LinkedHashMap<>():flatten(base);List<Change> changes=new ArrayList<>();
        for(Row remote:b.values()) {
            ExchangeJson.check();String rowKey=key(remote.section,remote.id);Row current=a.get(rowKey),prior=old.get(rowKey);
            if(current==null){if(!blocked.contains(rowKey))changes.add(change(remote,"$record",JSONObject.NULL,remote.fields,prior!=null,prior==null));}
            else for(String field:fields(remote.fields)) {
                if(blocked.contains(rowKey+"\0"+field) || blocked.contains(rowKey))continue;
                if(Set.of("playlists","groups").contains(remote.section) && field.equals("createdAt"))continue;
                if(remote.section.equals("sources") && !Set.of("label","paused","entityId").contains(field))continue; // local transport state is not remotely mutable
                if(remote.section.equals("usageSessions") && remote.fields.getJSONObject("visit").optLong("updatedAt")<=current.fields.getJSONObject("visit").optLong("updatedAt"))continue; // same history identity uses its latest update
                Object l=current.fields.opt(field),r=remote.fields.get(field);if(ExchangeJson.same(l,r))continue;
                Object previous=prior==null?null:prior.fields.opt(field);if(prior!=null && ExchangeJson.same(r,previous))continue;
                boolean localUnchanged=prior!=null && ExchangeJson.same(l,previous);
                changes.add(change(remote,field,l,r,!localUnchanged,localUnchanged));
            }
            if(changes.size()>20000)throw new IOException("La revisión supera 20.000 cambios. Usa un intercambio más pequeño.");
        }
        return new Plan(local,incoming,a,b,changes);
    }
    private static Change change(Row row,String field,Object local,Object incoming,boolean conflict,boolean automatic)throws Exception {
        String id=ExchangeJson.hash(key(row.section,row.id)+"\0"+field+"\0"+ExchangeJson.canonical(local)+"\0"+ExchangeJson.canonical(incoming));
        return new Change(id,row.section,row.id,field,local==null?JSONObject.NULL:local,incoming,conflict,automatic);
    }
    static String key(String section,String id){return section+"\0"+id;}
    static List<String> fields(JSONObject o){List<String> out=new ArrayList<>();o.keys().forEachRemaining(out::add);Collections.sort(out);return out;}
    static String identity(String section){return switch(section){case "readerProgress","mediaMetadata"->"mediaId";case "memberships"->"memberId";case "publicationContent"->"publicationId";default->"id";};}
    static LinkedHashMap<String,Row> flatten(PortableState.Snapshot s)throws Exception {
        LinkedHashMap<String,Row> rows=new LinkedHashMap<>();
        for(String section:PortableState.SECTIONS){if(Set.of("aliases","entityLinks","entityReferences").contains(section))continue;add(rows,section,s.state().getJSONArray(section));}
        add(rows,"mediaMetadata",s.metadata());
        for(String section:List.of("aliases","entityLinks","entityReferences")){
            Map<String,JSONArray> groups=new LinkedHashMap<>();JSONArray entities=s.state().getJSONArray("entities");for(int i=0;i<entities.length();i++)groups.put(entities.getJSONObject(i).getString("id"),new JSONArray());
            JSONArray array=s.state().getJSONArray(section);for(int i=0;i<array.length();i++){JSONObject row=array.getJSONObject(i);JSONArray group=groups.get(row.getString("entityId"));if(group==null)throw new IOException("Relación sin identidad.");group.put(row);}
            for(var e:groups.entrySet()){List<String> sorted=new ArrayList<>();for(int i=0;i<e.getValue().length();i++)sorted.add(ExchangeJson.canonical(e.getValue().get(i)));Collections.sort(sorted);JSONArray values=new JSONArray();for(String json:sorted)values.put(new JSONObject(json));rows.put(key(section,e.getKey()),new Row(section,e.getKey(),new JSONObject().put("values",values)));}
        }
        return rows;
    }
    private static void add(Map<String,Row> out,String section,JSONArray array)throws Exception {
        String pk=identity(section);for(int i=0;i<array.length();i++){JSONObject raw=ExchangeJson.copy(array.getJSONObject(i));String id=raw.getString(pk);raw.remove(pk);
            if(section.equals("items")){raw.put("playback",new JSONObject().put("position",raw.get("position")).put("duration",raw.get("duration")));raw.remove("position");raw.remove("duration");}
            if(section.equals("readerProgress")){JSONObject reading=ExchangeJson.copy(raw);raw=new JSONObject().put("reading",reading);}
            if(section.equals("usageSessions") || section.equals("catalogSnapshots")){JSONObject all=ExchangeJson.copy(raw);raw=new JSONObject().put(section.equals("usageSessions")?"visit":"catalog",all);}
            String key=key(section,id);if(out.put(key,new Row(section,id,raw))!=null)throw new IOException("Registro duplicado.");}
    }
    static PortableState.Snapshot inflate(Map<String,Row> rows)throws Exception {
        JSONObject state=new JSONObject().put("format","peach-local-state").put("version",19);for(String s:PortableState.SECTIONS)state.put(s,new JSONArray());JSONArray metadata=new JSONArray();
        for(Row row:rows.values()) {
            if(Set.of("aliases","entityLinks","entityReferences").contains(row.section)){JSONArray values=row.fields.getJSONArray("values");for(int i=0;i<values.length();i++)state.getJSONArray(row.section).put(values.getJSONObject(i));}
            else {JSONObject raw=ExchangeJson.copy(row.fields);
                if(row.section.equals("items")){JSONObject p=raw.getJSONObject("playback");raw.remove("playback");raw.put("position",p.get("position")).put("duration",p.get("duration"));}
                if(row.section.equals("readerProgress"))raw=ExchangeJson.copy(raw.getJSONObject("reading"));
                if(row.section.equals("usageSessions") || row.section.equals("catalogSnapshots"))raw=ExchangeJson.copy(raw.getJSONObject(row.section.equals("usageSessions")?"visit":"catalog"));
                raw.put(identity(row.section),row.id);if(row.section.equals("mediaMetadata"))metadata.put(raw);else state.getJSONArray(row.section).put(raw);}
        }
        return new PortableState.Snapshot(state,metadata,new JSONArray(),new JSONArray());
    }
}
