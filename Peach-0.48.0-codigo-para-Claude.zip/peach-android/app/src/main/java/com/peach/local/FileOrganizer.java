package com.peach.local;

import android.content.*;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.util.AtomicFile;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import org.json.*;

/** Explicit SAF operations with a write-ahead journal. No operation runs on opening this class. */
final class FileOrganizer {
 static final Object MUTEX=new Object();
 static final long MAX_BYTES=16L*1024*1024*1024;
 static final int JOURNAL_LIMIT=16*1024*1024;
 record Doc(String uri,String name,String mime,long size,long modified,int flags){boolean dir(){return DocumentsContract.Document.MIME_TYPE_DIR.equals(mime);}}
 interface Fs {
  Doc stat(String uri)throws Exception;List<Doc> children(String parent)throws Exception;
  String rename(String uri,String name)throws Exception;String move(String uri,String parent,String target)throws Exception;
  String create(String parent,String mime,String name)throws Exception;InputStream read(String uri)throws Exception;
  void write(String uri,byte[] bytes)throws Exception;void delete(String uri)throws Exception;void permit(String root)throws Exception;
 }
 static final class Saf implements Fs {
  final ContentResolver resolver;Saf(Context c){resolver=c.getContentResolver();}
  static final String[] COL={"document_id","_display_name","mime_type","_size","last_modified","flags"};
  List<Doc> query(String uri,boolean children)throws Exception{
   Uri u=Uri.parse(uri),q=children?DocumentsContract.buildChildDocumentsUriUsingTree(u,DocumentsContract.getDocumentId(u)):u;List<Doc> out=new ArrayList<>();
   try(var c=resolver.query(q,COL,null,null,null)){
    if(c==null)throw new IOException("El proveedor no devolvió una respuesta verificable.");
    while(c.moveToNext()){
     if(out.size()>=10000)throw new IOException("Carpeta con más de 10.000 elementos.");
     String id=c.getString(0),name=c.getString(1),mime=c.getString(2);if(id==null||name==null)throw new IOException("Metadatos de documento incompletos.");
     out.add(new Doc(DocumentsContract.buildDocumentUriUsingTree(u,id).toString(),name,mime,c.isNull(3)?-1:c.getLong(3),c.isNull(4)?0:c.getLong(4),c.isNull(5)?0:c.getInt(5)));
    }
    if(c.getExtras().getBoolean(DocumentsContract.EXTRA_LOADING,false))throw new IOException("La carpeta todavía se está cargando.");
   }return out;
  }
  public Doc stat(String u)throws Exception{var l=query(u,false);return l.isEmpty()?null:l.get(0);}
  public List<Doc> children(String p)throws Exception{return query(p,true);}
  public String rename(String u,String n)throws Exception{Uri v=DocumentsContract.renameDocument(resolver,Uri.parse(u),n);if(v==null)throw new IOException("El proveedor no confirmó el nombre nuevo.");return v.toString();}
  public String move(String u,String p,String t)throws Exception{Uri v=DocumentsContract.moveDocument(resolver,Uri.parse(u),Uri.parse(p),Uri.parse(t));if(v==null)throw new IOException("El proveedor no confirmó el movimiento.");return DocumentsContract.buildDocumentUriUsingTree(Uri.parse(t),DocumentsContract.getDocumentId(v)).toString();}
  public String create(String p,String m,String n)throws Exception{Uri v=DocumentsContract.createDocument(resolver,Uri.parse(p),m,n);if(v==null)throw new IOException("No se pudo crear el documento.");return v.toString();}
  public InputStream read(String u)throws Exception{InputStream in=resolver.openInputStream(Uri.parse(u));if(in==null)throw new IOException("Documento inaccesible.");return in;}
  public void write(String u,byte[] b)throws Exception{try(OutputStream out=resolver.openOutputStream(Uri.parse(u),"wt")){if(out==null)throw new IOException("Documento sin escritura.");out.write(b);}}
  public void delete(String u)throws Exception{if(!DocumentsContract.deleteDocument(resolver,Uri.parse(u)))throw new IOException("El proveedor no confirmó la eliminación.");}
  public void permit(String root)throws IOException{for(var p:resolver.getPersistedUriPermissions())if(p.getUri().toString().equals(root)&&p.isReadPermission()&&p.isWritePermission())return;throw new IOException("Autoriza lectura y escritura de esta carpeta desde el selector de Android.");}
 }
 record Plan(String mode,MediaEntry media,Doc source,String parent,String target,String targetRoot,String targetFolder,String name,byte[] nfo,String nfoUri,byte[] before){
  String description(){return switch(mode){case "nfo"->"Escribir "+name+(nfoUri.isEmpty()?" (nuevo)":" (actualizar con respaldo)")+"\n\n"+new String(nfo,StandardCharsets.UTF_8);case "trash"->"Enviar a una papelera privada de Peach dentro de la misma raíz: "+source.name()+"\nSe conserva el original en esa carpeta hasta restaurarlo. No se borrará definitivamente.";default->source.name()+" → "+name+"\nDestino: "+targetFolder+"\n\nSe comprueban los bytes y se conserva el identificador, favoritos, listas y progreso. Los archivos auxiliares no se trasladan automáticamente.";};}
 }
 volatile boolean cancelRequested,mutating;
 final Fs fs;final LibraryDatabase db;final AtomicFile journal;
 FileOrganizer(Context c,LibraryDatabase db){this(new Saf(c),db,new File(c.getNoBackupFilesDir(),"file-organization.json"));}
 FileOrganizer(Fs fs,LibraryDatabase db,File file){this.fs=fs;this.db=db;this.journal=new AtomicFile(file);}
 static String key(String uri){try{Uri u=Uri.parse(uri);return DocumentsContract.buildDocumentUri(u.getAuthority(),DocumentsContract.getDocumentId(u)).toString();}catch(RuntimeException e){return uri;}}
 static String treeDoc(String root){Uri u=Uri.parse(root);if(!"content".equals(u.getScheme())||!DocumentsContract.isTreeUri(u))throw new IllegalArgumentException("Elige una carpeta con el selector de Android.");return DocumentsContract.buildDocumentUriUsingTree(u,DocumentsContract.getTreeDocumentId(u)).toString();}
 static String name(String s){if(s==null||!s.equals(s.trim())||s.isBlank()||s.equals(".")||s.equals("..")||s.getBytes(StandardCharsets.UTF_8).length>240)throw new IllegalArgumentException("Nombre vacío o mayor de 240 bytes.");for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c<32||c==127||"/\\:".indexOf(c)>=0||Character.isSurrogate(c)&&(!Character.isHighSurrogate(c)||i+1==s.length()||!Character.isLowSurrogate(s.charAt(++i))))throw new IllegalArgumentException("Nombre de archivo no válido.");}return s;}
 Doc required(String u)throws Exception{Doc d=fs.stat(u);if(d==null)throw new IOException("El documento ya no está disponible.");return d;}
 void idle()throws IOException{if(ScanWorker.RUNNING.get()!=0)throw new IOException("Pausa el escaneo y espera a que termine antes de organizar archivos.");}
 void flag(Doc d,int f)throws IOException{if((d.flags()&f)==0)throw new IOException("El proveedor no permite esta operación reversible.");}
 List<JSONObject> history()throws Exception{synchronized(MUTEX){return load();}}
 private List<JSONObject> load()throws Exception{
  if(!journal.getBaseFile().exists()&&!new File(journal.getBaseFile()+".bak").exists())return new ArrayList<>();
  try(var in=journal.openRead()){byte[] b=bounded(in,JOURNAL_LIMIT);if(b.length>JOURNAL_LIMIT)throw new IOException("Historial operativo demasiado grande.");var root=new JSONObject(new String(b,StandardCharsets.UTF_8));if(root.getInt("version")!=1)throw new IOException("Historial operativo de otra versión.");var a=root.getJSONArray("operations");if(a.length()>500)throw new IOException("Demasiadas operaciones.");List<JSONObject> out=new ArrayList<>();for(int i=0;i<a.length();i++)out.add(a.getJSONObject(i));return out;}
 }
 private void save(List<JSONObject> rows)throws Exception{
  if(rows.size()>500)throw new IOException("Límite de 500 operaciones. Archiva registros que ya no necesites deshacer.");byte[] b=new JSONObject().put("version",1).put("operations",new JSONArray(rows)).toString().getBytes(StandardCharsets.UTF_8);if(b.length>JOURNAL_LIMIT)throw new IOException("Historial lleno; archiva respaldos que ya no necesites.");FileOutputStream out=null;
  try{out=journal.startWrite();out.write(b);journal.finishWrite(out);}catch(Exception e){if(out!=null)journal.failWrite(out);throw e;}
 }
 private JSONObject entry(List<JSONObject> rows,String id)throws Exception{for(var r:rows)if(r.getString("id").equals(id))return r;throw new IOException("Operación no encontrada.");}
 private Doc child(String parent,String name)throws Exception{Doc result=null;for(Doc d:fs.children(parent))if(d.name().equalsIgnoreCase(name)){if(result!=null)throw new IOException("Nombres ambiguos en el destino.");result=d;}return result;}
 private void vacant(String parent,String name)throws Exception{if(child(parent,name)!=null)throw new IOException("El destino ya contiene ese nombre. No se sobrescribirá.");}
 String parent(MediaEntry m)throws Exception{
  var known=db.library().directoryForFolder(m.root,m.folder);if(known!=null&&fs.children(known.uri).stream().anyMatch(d->key(d.uri()).equals(key(m.uri))))return known.uri;
  ArrayDeque<String> q=new ArrayDeque<>();Set<String> seen=new HashSet<>();q.add(treeDoc(m.root));long until=System.nanoTime()+15_000_000_000L;
  while(!q.isEmpty()){if(seen.size()>=2000||System.nanoTime()>until)throw new IOException("No se localizó la carpeta de origen; actualiza el escaneo.");String p=q.remove();if(!seen.add(key(p)))continue;for(Doc d:fs.children(p)){if(key(d.uri()).equals(key(m.uri)))return p;if(d.dir())q.add(d.uri());}}
  throw new IOException("El archivo no aparece dentro de su raíz autorizada.");
 }
 Plan plan(String mediaId,String mode,String newName,String targetRoot)throws Exception{synchronized(MUTEX){idle();MediaEntry m=db.library().get(mediaId);if(m==null||m.missing)throw new IOException("Selecciona un archivo disponible de la biblioteca.");Doc source=required(m.uri);if(source.dir()||source.size()<0||source.size()>MAX_BYTES)throw new IOException("Se requiere un archivo regular con tamaño conocido de hasta 16 GiB.");if(!m.name.equals(source.name))throw new IOException("El nombre cambió fuera de Peach; actualiza el escaneo.");String p=parent(m),target=p,root=m.root,folder=m.folder,n=source.name();byte[] nfo=new byte[0],before=new byte[0];String nfoUri="";
  fs.permit(m.root);
  if(mode.equals("rename")){n=name(newName);if(!MediaRules.extension(n).equalsIgnoreCase(MediaRules.extension(source.name())))throw new IOException("Conserva la extensión del archivo.");if(n.equals(source.name()))throw new IOException("El nombre no cambió.");flag(source,DocumentsContract.Document.FLAG_SUPPORTS_RENAME);vacant(p,n);}
  else if(mode.equals("move")){target=treeDoc(targetRoot);if(!Uri.parse(target).getAuthority().equals(Uri.parse(p).getAuthority()))throw new IOException("Este movimiento requiere carpetas del mismo proveedor. No se hará una copia y borrado entre proveedores.");if(key(target).equals(key(p)))throw new IOException("El archivo ya está en esa carpeta.");fs.permit(targetRoot);Doc dir=required(target);if(!dir.dir())throw new IOException("El destino debe ser una carpeta.");flag(source,DocumentsContract.Document.FLAG_SUPPORTS_MOVE);flag(required(p),DocumentsContract.Document.FLAG_DIR_SUPPORTS_CREATE);flag(dir,DocumentsContract.Document.FLAG_DIR_SUPPORTS_CREATE);vacant(target,n);root=targetRoot;folder=dir.name();}
  else if(mode.equals("trash")){flag(source,DocumentsContract.Document.FLAG_SUPPORTS_MOVE);target=treeDoc(m.root);flag(required(target),DocumentsContract.Document.FLAG_DIR_SUPPORTS_CREATE);flag(required(p),DocumentsContract.Document.FLAG_DIR_SUPPORTS_CREATE);}
  else if(mode.equals("nfo")){if(!Set.of(MediaRules.VIDEO,MediaRules.AUDIO).contains(m.mediaType))throw new IOException("La escritura NFO se aplica a audio y video.");n=name(MediaRules.stem(m.name)+".nfo");nfo=NfoWriter.encode(m);Doc existing=child(p,n);if(existing!=null){if(existing.dir())throw new IOException("El nombre NFO pertenece a una carpeta.");flag(existing,DocumentsContract.Document.FLAG_SUPPORTS_WRITE);before=readSmall(existing.uri());nfo=NfoWriter.merge(before,nfo);nfoUri=existing.uri();}else flag(required(p),DocumentsContract.Document.FLAG_DIR_SUPPORTS_CREATE);}
  else throw new IllegalArgumentException("Acción no válida.");return new Plan(mode,m,source,p,target,root,folder,n,nfo,nfoUri,before);
 }}
 byte[] readSmall(String u)throws Exception{try(var in=fs.read(u)){byte[] b=bounded(in,NfoReader.MAX_BYTES);if(b.length>NfoReader.MAX_BYTES)throw new IOException("El NFO previo supera 1 MiB.");return b;}}
 String digest(String uri,long expected)throws Exception{if(cancelRequested&&!mutating)throw new InterruptedIOException("Comprobación cancelada.");if(expected<0||expected>MAX_BYTES)throw new IOException("Tamaño no verificable.");MessageDigest hash=MessageDigest.getInstance("SHA-256");long bytes=0,until=System.nanoTime()+3_600_000_000_000L;try(var in=fs.read(uri)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1){if(cancelRequested&&!mutating)throw new InterruptedIOException("Comprobación cancelada.");if(n==0||Thread.currentThread().isInterrupted()||System.nanoTime()>until)throw new IOException("Verificación cancelada o fuera de plazo.");bytes+=n;if(bytes>expected)throw new IOException("El contenido cambió de tamaño.");hash.update(b,0,n);}}if(bytes!=expected)throw new IOException("Archivo incompleto o modificado.");return hex(hash.digest());}
 static byte[] bounded(InputStream in,int limit)throws IOException{var out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b,0,Math.min(b.length,limit+1-out.size())))>0){out.write(b,0,n);if(out.size()>limit)break;}return out.toByteArray();}
 static String hash(byte[] b)throws Exception{return hex(MessageDigest.getInstance("SHA-256").digest(b));}
 private static String hex(byte[] b){StringBuilder s=new StringBuilder();for(byte v:b)s.append(String.format(Locale.ROOT,"%02x",v&255));return s.toString();}
 String apply(Plan plan)throws Exception{synchronized(MUTEX){idle();MediaEntry fresh=db.library().get(plan.media.id);if(fresh==null||!fresh.uri.equals(plan.media.uri)||!fresh.name.equals(plan.media.name))throw new IOException("La biblioteca cambió; vuelve a revisar.");if(!required(fresh.uri).equals(plan.source))throw new IOException("El archivo cambió desde la vista previa.");Plan checked=plan(fresh.id,plan.mode,plan.name,plan.targetRoot);if(!checked.parent.equals(plan.parent)||!checked.target.equals(plan.target)||!Arrays.equals(checked.before,plan.before)||!Arrays.equals(checked.nfo,plan.nfo))throw new IOException("El destino o los metadatos cambiaron; revisa otra vez.");
  List<JSONObject> rows=load();for(var old:rows)if(old.optString("mediaId").equals(fresh.id)&&Set.of("PREPARED","CHANGED","REVIEW","UNDOING","RESTORING_NFO").contains(old.optString("state")))throw new IOException("Revisa primero la operación pendiente de este archivo.");
  String id=UUID.randomUUID().toString(),sha=plan.mode.equals("nfo")?hash(plan.nfo):digest(fresh.uri,plan.source.size);
  JSONObject r=new JSONObject().put("id",id).put("mediaId",fresh.id).put("mode",plan.mode).put("state","PREPARED").put("oldUri",fresh.uri).put("oldParent",plan.parent).put("oldRoot",fresh.root).put("oldFolder",fresh.folder).put("oldName",fresh.name).put("target",plan.target).put("newRoot",plan.targetRoot).put("newFolder",plan.targetFolder).put("newName",plan.name).put("sha",sha).put("bytes",plan.source.size).put("createdAt",System.currentTimeMillis());
  if(plan.mode.equals("nfo"))r.put("nfoUri",plan.nfoUri).put("before",android.util.Base64.encodeToString(plan.before,android.util.Base64.NO_WRAP)).put("after",android.util.Base64.encodeToString(plan.nfo,android.util.Base64.NO_WRAP)).put("existed",!plan.nfoUri.isEmpty());
  if(plan.mode.equals("trash"))r.put("trashName",".PeachPapelera-"+id);
  rows.add(r);save(rows);
  try{
   if(cancelRequested)throw new InterruptedIOException("Preparación cancelada antes de modificar el archivo.");mutating=true;
   if(plan.mode.equals("nfo")){String u=plan.nfoUri;if(u.isEmpty()){vacant(plan.parent,plan.name);u=fs.create(plan.parent,"application/xml",plan.name);r.put("nfoUri",u);save(rows);if(!required(u).name.equals(plan.name))throw new IOException("El proveedor cambió el nombre NFO; revisa el registro.");flag(required(u),DocumentsContract.Document.FLAG_SUPPORTS_DELETE);}fs.write(u,plan.nfo);if(!Arrays.equals(readSmall(u),plan.nfo))throw new IOException("El proveedor no conservó el NFO completo.");r.put("state","DONE");save(rows);return id;}
   String target=plan.target;if(plan.mode.equals("trash")){vacant(target,r.getString("trashName"));target=fs.create(target,DocumentsContract.Document.MIME_TYPE_DIR,r.getString("trashName"));r.put("target",target).put("trashUri",target).put("newFolder",plan.media.folder+" / Papelera Peach");save(rows);}
   String result=plan.mode.equals("rename")?fs.rename(fresh.uri,plan.name):fs.move(fresh.uri,plan.parent,target);r.put("newUri",result).put("state","CHANGED");save(rows);verifyLocation(r);relocate(r,false);r.put("state","DONE");save(rows);return id;
  }catch(Exception error){r.put("state","REVIEW");save(rows);throw new IOException("La operación necesita revisión en Historial / papelera. No se repetirá automáticamente.",error);}finally{mutating=false;}
 }}
 private void verifyLocation(JSONObject r)throws Exception{
  Doc d=child(r.getString("target"),r.getString("newName"));if(d==null||d.dir()||d.size()!=r.getLong("bytes")||!digest(d.uri,d.size).equals(r.getString("sha")))throw new IOException("El destino no coincide con el original.");
  Doc old=child(r.getString("oldParent"),r.getString("oldName"));if(old!=null&&!(r.getString("mode").equals("rename")&&r.getString("oldName").equals(r.getString("newName"))))throw new IOException("El origen todavía aparece; revisa ambas ubicaciones.");r.put("newUri",d.uri);
 }
 private void relocate(JSONObject r,boolean undo)throws Exception{
  String uri=r.getString(undo?"oldUri":"newUri"),root=r.getString(undo?"oldRoot":"newRoot"),folder=r.getString(undo?"oldFolder":"newFolder");Doc d=required(uri);MediaEntry m=db.library().get(r.getString("mediaId"));if(m==null)throw new IOException("El registro de biblioteca ya no existe; revisa el archivo manualmente.");
  for(MediaEntry other:db.library().allMedia())if(!other.id.equals(m.id)&&key(other.uri).equals(key(uri)))throw new IOException("La ubicación ya pertenece a otro registro; no se fusionarán identidades.");
  LibraryRoot entry=db.library().roots().stream().filter(x->x.uri.equals(root)).findFirst().orElse(null);if(entry==null){entry=new LibraryRoot();entry.uri=root;entry.label=folder;entry.state=0;db.library().addRoot(entry);}
  String title=m.nfoDetails.equals("{}")&&m.title.equals(MediaRules.stem(m.name))?MediaRules.stem(d.name):m.title;
  db.library().relocate(m.id,uri,root,d.name,folder,title,d.size,d.modified,entry.generation,!undo&&r.getString("mode").equals("trash"));
 }
 void recover(String id)throws Exception{synchronized(MUTEX){idle();var rows=load();var r=entry(rows,id);if(!Set.of("REVIEW","PREPARED","CHANGED","UNDOING","RESTORING_NFO").contains(r.getString("state")))throw new IOException("Esta operación no requiere reconciliación.");fs.permit(r.getString("oldRoot"));
  if(Set.of("UNDOING","RESTORING_NFO").contains(r.getString("state"))){
   if(r.getString("mode").equals("nfo")){
    Doc n=child(r.getString("target"),r.getString("newName"));byte[] before=android.util.Base64.decode(r.getString("before"),android.util.Base64.DEFAULT);
    if(n==null&&!r.getBoolean("existed")||n!=null&&r.getBoolean("existed")&&Arrays.equals(readSmall(n.uri),before))r.put("state","UNDONE");
    else if(n!=null&&hash(readSmall(n.uri)).equals(r.getString("sha")))r.put("state","DONE");else throw new IOException("Restauración NFO incompleta; exporta el respaldo para revisarlo.");
   }else{
    Doc old=child(r.getString("oldParent"),r.getString("oldName")),dest=child(r.getString("target"),r.getString("newName"));
    if(old!=null&&dest==null&&digest(old.uri,old.size).equals(r.getString("sha"))){r.put("oldUri",old.uri);relocate(r,true);r.put("state","UNDONE");}
    else if(old==null&&dest!=null&&digest(dest.uri,dest.size).equals(r.getString("sha")))r.put("state","DONE");else throw new IOException("Restauración ambigua: revisa ambas carpetas.");
   }save(rows);return;
  }
  if(r.getString("mode").equals("trash")&&!r.has("trashUri")){Doc folder=child(treeDoc(r.getString("oldRoot")),r.getString("trashName"));if(folder==null){Doc original=child(r.getString("oldParent"),r.getString("oldName"));if(original!=null&&digest(original.uri,original.size).equals(r.getString("sha"))){r.put("oldUri",original.uri);relocate(r,true);r.put("state","CANCELLED");save(rows);return;}throw new IOException("No se pudo localizar la papelera ni confirmar el origen.");}if(!folder.dir())throw new IOException("El destino de papelera no es una carpeta.");r.put("target",folder.uri).put("trashUri",folder.uri);save(rows);}
  if(r.getString("mode").equals("nfo")){Doc d=child(r.getString("target"),r.getString("newName"));if(d!=null&&!r.optString("nfoUri").equals(d.uri)){r.put("nfoUri",d.uri);save(rows);}if(d!=null&&hash(readSmall(d.uri)).equals(r.getString("sha"))){r.put("nfoUri",d.uri).put("state","DONE");}else if(d==null&&!r.getBoolean("existed")||d!=null&&r.getBoolean("existed")&&Arrays.equals(readSmall(d.uri),android.util.Base64.decode(r.getString("before"),android.util.Base64.DEFAULT))){r.put("state","CANCELLED");}else throw new IOException("NFO con contenido distinto; exporta el respaldo antes de decidir cómo restaurarlo.");}
  else{fs.permit(r.getString("newRoot"));Doc old=child(r.getString("oldParent"),r.getString("oldName")),target=child(r.getString("target"),r.getString("newName"));if(old!=null&&target==null&&digest(old.uri,old.size).equals(r.getString("sha"))){r.put("oldUri",old.uri);relocate(r,true);r.put("state","CANCELLED");}else{verifyLocation(r);relocate(r,false);r.put("state","DONE");}}
  save(rows);
 }}
 void undo(String id)throws Exception{synchronized(MUTEX){try{idle();var rows=load();var r=entry(rows,id);if(!r.getString("state").equals("DONE"))throw new IOException("Solo se pueden deshacer operaciones confirmadas.");for(int i=rows.indexOf(r)+1;i<rows.size();i++)if(rows.get(i).optString("mediaId").equals(r.getString("mediaId"))&&!Set.of("UNDONE","CANCELLED").contains(rows.get(i).optString("state")))throw new IOException("Deshaz primero las operaciones posteriores de este archivo.");fs.permit(r.getString("oldRoot"));
  if(r.getString("mode").equals("nfo")){String u=r.getString("nfoUri");if(!hash(readSmall(u)).equals(r.getString("sha")))throw new IOException("El NFO cambió después; no se sobrescribirá.");r.put("state","UNDOING");save(rows);if(cancelRequested)throw new InterruptedIOException("Deshacer cancelado antes del cambio.");mutating=true;if(r.getBoolean("existed")){byte[] b=android.util.Base64.decode(r.getString("before"),android.util.Base64.DEFAULT);fs.write(u,b);if(!Arrays.equals(readSmall(u),b))throw new IOException("No se pudo verificar el respaldo restaurado.");}else{fs.delete(u);if(child(r.getString("target"),r.getString("newName"))!=null)throw new IOException("El proveedor todavía muestra el NFO eliminado.");}}
  else{fs.permit(r.getString("newRoot"));verifyLocation(r);vacant(r.getString("oldParent"),r.getString("oldName"));r.put("state","UNDOING");save(rows);if(cancelRequested)throw new InterruptedIOException("Deshacer cancelado antes del cambio.");mutating=true;String u=r.getString("newUri");if(r.getString("mode").equals("rename"))u=fs.rename(u,r.getString("oldName"));else u=fs.move(u,r.getString("target"),r.getString("oldParent"));r.put("oldUri",u);save(rows);Doc d=child(r.getString("oldParent"),r.getString("oldName"));if(d==null||!digest(d.uri,d.size).equals(r.getString("sha")))throw new IOException("La restauración necesita revisión.");r.put("oldUri",d.uri);relocate(r,true);}
  r.put("state","UNDONE");save(rows);
 }finally{mutating=false;}}}
 String nfoCurrentHash(String id)throws Exception{synchronized(MUTEX){var r=entry(load(),id);if(!r.getString("mode").equals("nfo")||r.optString("nfoUri").isEmpty())throw new IOException("No se localizó el NFO de esta operación.");return hash(readSmall(r.getString("nfoUri")));}}
 void restoreNfo(String id,String expectedCurrent)throws Exception{synchronized(MUTEX){idle();var rows=load();var r=entry(rows,id);if(!r.getString("mode").equals("nfo")||!Set.of("REVIEW","RESTORING_NFO","UNDOING").contains(r.getString("state")))throw new IOException("Este NFO no requiere restauración de respaldo.");fs.permit(r.getString("oldRoot"));String uri=r.getString("nfoUri");if(!hash(readSmall(uri)).equals(expectedCurrent))throw new IOException("El NFO cambió desde la revisión; no se sobrescribirá.");byte[] before=android.util.Base64.decode(r.getString("before"),android.util.Base64.DEFAULT);r.put("state","RESTORING_NFO");save(rows);mutating=true;try{if(r.getBoolean("existed")){fs.write(uri,before);if(!Arrays.equals(readSmall(uri),before))throw new IOException("Restauración NFO incompleta. El respaldo sigue conservado.");}else{flag(required(uri),DocumentsContract.Document.FLAG_SUPPORTS_DELETE);fs.delete(uri);if(child(r.getString("target"),r.getString("newName"))!=null)throw new IOException("El NFO nuevo todavía aparece en la carpeta.");}r.put("state","UNDONE");save(rows);}finally{mutating=false;}}}
 void archive(String id)throws Exception{synchronized(MUTEX){var rows=load();var r=entry(rows,id);if(!Set.of("DONE","UNDONE","CANCELLED").contains(r.getString("state"))||r.getString("mode").equals("trash")&&r.getString("state").equals("DONE"))throw new IOException("Restaura o reconcilia este archivo antes de archivar.");r.remove("before");r.remove("after");r.put("state","ARCHIVED");save(rows);}}
 byte[] nfoBackup(String id)throws Exception{synchronized(MUTEX){var r=entry(load(),id);if(!r.getString("mode").equals("nfo"))throw new IOException("No hay respaldo NFO.");return android.util.Base64.decode(r.getString("before"),android.util.Base64.DEFAULT);}}
 Set<String> trashDirectories()throws Exception{Set<String> out=new HashSet<>();for(var r:history())if(r.has("trashUri"))out.add(key(r.getString("trashUri")));return out;}
 static void preserveIds(LibraryDao dao,List<MediaEntry> scanned){Map<String,String> ids=new HashMap<>();for(MediaEntry old:dao.allMedia())ids.putIfAbsent(key(old.uri),old.id);for(MediaEntry m:scanned)m.id=ids.getOrDefault(key(m.uri),m.id);}
}
