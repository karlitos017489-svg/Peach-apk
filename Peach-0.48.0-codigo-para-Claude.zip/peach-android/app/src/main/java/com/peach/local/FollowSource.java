package com.peach.local;

import androidx.annotation.*;
import androidx.room.*;

@Entity(tableName="follow_sources",foreignKeys=@ForeignKey(entity=CatalogEntity.class,parentColumns="id",childColumns="entityId",onDelete=ForeignKey.SET_NULL),indices=@Index("entityId"))
public class FollowSource {
    @PrimaryKey @NonNull public String id="";
    @NonNull public String provider="fanbox";
    @NonNull public String ref="";
    @NonNull public String label="";
    @Nullable public String entityId;
    public boolean paused;
    public long revision;
    @NonNull public String cachedPage="[]";
    @NonNull public String pageUrls="[]";
    public int nextPage=1;
    public int cachePage;
    public long checkedAt;
    public long cooldownUntil;
    @NonNull public String lastError="";
    @NonNull public String etag="";
    @NonNull public String modified="";
}
