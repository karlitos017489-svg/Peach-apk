package com.peach.local;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.*;

/** Private disposable cache. Only selected images are fetched; no HTML, cookies or caller paths. */
public final class GalleryCache {
    public static final long BUDGET=64L*1024*1024;
    static final int MAX_FILES=128;
    private static final Object LOCK=new Object();
    private static final Map<String,Long> WAITS=new LinkedHashMap<>();
    public interface Fetcher {SourceHttp.Download fetch(String url,File file,SourceHttp.Token token)throws IOException;}
    public record Frame(ImageFiles.Decoded image,boolean cached,android.graphics.drawable.Drawable animation) {
        Frame(ImageFiles.Decoded image,boolean cached){this(image,cached,null);}
        void release(){AnimatedImages.stop(animation);if(image!=null)image.bitmap().recycle();}
    }
    final File root;
    public GalleryCache(File cacheDir){root=new File(cacheDir,"peach-source-gallery");}
    static String key(String url){return hex(digest(url.getBytes(StandardCharsets.UTF_8)));}
    static byte[] digest(byte[] bytes){try{return MessageDigest.getInstance("SHA-256").digest(bytes);}catch(Exception e){throw new AssertionError(e);}}
    static String hex(byte[] bytes){StringBuilder b=new StringBuilder();for(byte v:bytes)b.append(String.format(Locale.ROOT,"%02x",v&255));return b.toString();}
    static String checksum(File f)throws IOException{try{MessageDigest d=MessageDigest.getInstance("SHA-256");try(InputStream in=new FileInputStream(f)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)d.update(b,0,n);}return hex(d.digest());}catch(java.security.NoSuchAlgorithmException e){throw new AssertionError(e);}}
    private File sha(File file){return new File(root,file.getName().replace(".image",".sha"));}
    private void remove(File file){file.delete();sha(file).delete();}
    private List<File> images(){File[] files=root.listFiles((d,n)->n.matches("[a-f0-9]{64}\\.image"));return new ArrayList<>(files==null?List.of():Arrays.asList(files));}
    private void clean(){File[] files=root.listFiles();if(files==null)return;for(File f:files){String n=f.getName();if(n.startsWith("selected-") && n.endsWith(".part"))f.delete();else if(n.matches("[a-f0-9]{64}\\.sha") && !new File(root,n.replace(".sha",".image")).exists())f.delete();}}
    private void trim(long budget,int count,File keep){List<File> files=images();files.sort(Comparator.comparingLong(File::lastModified).thenComparing(File::getName));long bytes=0;for(File f:files)bytes+=f.length();int size=files.size();for(File f:files)if(!f.equals(keep) && (bytes>budget || size>count)){bytes-=f.length();size--;remove(f);}}
    int clearUnused(){synchronized(LOCK){int count=0;for(File file:images()){remove(file);if(!file.exists())count++;}return count;}}
    private static boolean expected(String url,String sha){return !PawchiveUrls.downloadable(url)||PawchiveUrls.expectedHash(url).equals(sha);}
    private static Frame decode(File file,boolean cached,boolean preview)throws IOException {
        if(preview)return new Frame(ImageFiles.decode(file,512),cached);
        String ext=LocalMedia.inspect(file).extension();
        if(android.os.Build.VERSION.SDK_INT>=28 && (ext.equals("gif")||ext.equals("webp")))return new Frame(null,cached,AnimatedImages.decode(file));
        return new Frame(ImageFiles.decode(file,2048),cached);
    }
    public Frame acquire(SourceGallery.Image image,boolean offline,SourceHttp.Token token,Fetcher fetcher)throws IOException {return acquire(image,offline,token,fetcher,false);}
    Frame acquirePreview(SourceGallery.Image image,boolean offline,SourceHttp.Token token,Fetcher fetcher)throws IOException {return acquire(image,offline,token,fetcher,true);}
    private Frame acquire(SourceGallery.Image image,boolean offline,SourceHttp.Token token,Fetcher fetcher,boolean preview)throws IOException {
        synchronized(LOCK) {
            token.check();if(!SourceHttp.downloadable(image.url()))throw new IOException("Servidor de imagen no admitido.");
            if(!root.isDirectory() && !root.mkdirs())throw new IOException("No se pudo abrir la caché.");clean();
            String key=key(image.url());File file=new File(root,key+".image"),meta=sha(file);
            if(file.exists())try {
                if(file.length()<1 || file.length()>SourceHttp.IMAGE_LIMIT || meta.length()!=64)throw new IOException("Imagen dañada.");
                String hash=checksum(file);
                if(!new String(Files.readAllBytes(meta.toPath()),StandardCharsets.US_ASCII).equals(hash) || !expected(image.url(),hash) || !image.expectedHash().isEmpty()&&!image.expectedHash().equals(hash))throw new IOException("Imagen dañada.");
                Frame frame=decode(file,true,preview);
                try{token.check();}catch(IOException e){frame.release();throw e;}
                file.setLastModified(System.currentTimeMillis());trim(BUDGET,MAX_FILES,file);return frame;
            }catch(InterruptedIOException e){throw e;}catch(IOException | RuntimeException e){remove(file);}
            if(offline)throw new IOException("Esta imagen no está en caché. Desactiva Sin conexión para consultarla.");
            String waitKey=root.getAbsolutePath()+key;Long until=WAITS.get(waitKey);if(until!=null && until>System.nanoTime())throw new SourceHttp.Failure("La fuente pidió esperar antes de consultar de nuevo.",429,Math.max(1,(until-System.nanoTime())/1000000000L));
            trim(BUDGET-SourceHttp.IMAGE_LIMIT,MAX_FILES-1,null);
            if(root.getUsableSpace()<SourceHttp.IMAGE_LIMIT+8L*1024*1024)throw new IOException("No hay espacio suficiente para la imagen.");
            File part=File.createTempFile("selected-",".part",root),stamp=File.createTempFile("selected-",".part",root);Frame frame=null;boolean done=false;
            try {
                SourceHttp.Download result=fetcher.fetch(image.url(),part,token);token.check();
                if(part.length()<1 || part.length()>SourceHttp.IMAGE_LIMIT || part.length()!=result.bytes() || !checksum(part).equals(result.sha256()) || !expected(image.url(),result.sha256()) || !image.expectedHash().isEmpty()&&!image.expectedHash().equals(result.sha256()))throw new IOException("La imagen descargada no superó la verificación.");
                frame=decode(part,false,preview);token.check();Files.write(stamp.toPath(),result.sha256().getBytes(StandardCharsets.US_ASCII));
                if(!part.renameTo(file) || !stamp.renameTo(meta))throw new IOException("No se pudo conservar la imagen.");
                token.check();file.setLastModified(System.currentTimeMillis());trim(BUDGET,MAX_FILES,file);WAITS.remove(waitKey);done=true;return frame;
            }catch(SourceHttp.Failure e){if(e.status==429){if(WAITS.size()>=128)WAITS.remove(WAITS.keySet().iterator().next());WAITS.put(waitKey,System.nanoTime()+Math.min(86400,Math.max(1,e.retrySeconds))*1000000000L);}throw e;}
            finally{part.delete();stamp.delete();if(!done){remove(file);if(frame!=null)frame.release();}}
        }
    }
}
