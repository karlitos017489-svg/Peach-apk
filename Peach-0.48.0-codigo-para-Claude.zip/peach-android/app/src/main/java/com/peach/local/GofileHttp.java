package com.peach.local;

import java.io.*;
import java.net.*;
import javax.net.ssl.HttpsURLConnection;
import java.util.*;

/** Read-only API transport. Only its own bearer header, exact API origin, no redirects or cookie input. */
final class GofileHttp {
    record Response(int status,byte[] bytes,long retrySeconds){}
    interface Transport{Response get(String folder,int page,String key,SourceHttp.Token token)throws IOException;}
    static Transport direct(){return direct(u->(HttpsURLConnection)new URL(u).openConnection(),InetAddress::getAllByName);}
    static Transport direct(SourceHttp.ConnectionFactory factory,MediaRedirects.Resolver resolver){return(folder,page,key,token)->{
        String url=GofileUrls.page(folder,page);GofileSecrets.valid(key);token.check();GofileUrls.publicHost(url,resolver,token);HttpsURLConnection c=null;
        try{c=factory.open(url);token.connection=c;c.setConnectTimeout(15000);c.setReadTimeout(15000);c.setInstanceFollowRedirects(false);c.setUseCaches(false);c.setRequestMethod("GET");c.setRequestProperty("Authorization","Bearer "+key);c.setRequestProperty("Accept","application/json");c.setRequestProperty("Accept-Encoding","identity");c.setRequestProperty("User-Agent","PeachLocal-Android/0.37.0");token.check();int status=c.getResponseCode();token.check();if(status>=300&&status<400)throw new IOException("Gofile devolvió una redirección API no admitida.");long retry=status==429?SourceHttp.retry(c.getHeaderField("Retry-After")):0;if(status==429)return new Response(status,new byte[0],retry);
            String mime=Objects.toString(c.getContentType(),"").toLowerCase(Locale.ROOT),encoding=Objects.toString(c.getHeaderField("Content-Encoding"),"");if(!encoding.isEmpty()&&!encoding.equalsIgnoreCase("identity"))throw new IOException("Respuesta Gofile comprimida no admitida.");if(!mime.startsWith("application/json")){if(status!=200)return new Response(status,new byte[0],retry);throw new IOException("Gofile no devolvió JSON.");}if(c.getContentLengthLong()>SourceHttp.JSON_LIMIT)throw new IOException("Respuesta Gofile mayor de 2 MiB.");InputStream stream=status>=400?c.getErrorStream():c.getInputStream();if(stream==null)return new Response(status,new byte[0],retry);try(InputStream in=stream){return new Response(status,SourceHttp.bounded(in,SourceHttp.JSON_LIMIT,token),retry);}
        }catch(InterruptedIOException e){throw new InterruptedIOException("Consulta Gofile cancelada o agotada.");}catch(IOException|IllegalArgumentException e){throw new IOException("No se pudo consultar Gofile. Clave y contenido actual conservados.");}finally{if(c!=null)c.disconnect();token.connection=null;}
    };}
}
