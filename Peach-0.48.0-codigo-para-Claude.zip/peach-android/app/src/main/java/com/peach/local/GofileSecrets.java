package com.peach.local;

import android.content.Context;
import android.util.AtomicFile;
import java.io.*;
import java.nio.charset.StandardCharsets;

/** Independent encrypted account token; the API wait survives token changes and process death. */
final class GofileSecrets implements GofileReview.Access {
    private static final Object LOCK=new Object();final SourceSecrets vault;final File wait;
    GofileSecrets(Context app){this(new SourceSecrets(new File(app.getNoBackupFilesDir(),"source-gofile-api.bin"),()->SourceSecrets.key("PeachGofileApiV1")),new File(app.getNoBackupFilesDir(),"source-gofile-wait.txt"));}
    GofileSecrets(SourceSecrets vault,File wait){this.vault=vault;this.wait=wait;}
    static String valid(String token){if(token==null||token.isEmpty()||token.length()>512||token.chars().anyMatch(c->c<33||c>126))throw new IllegalArgumentException("Clave Gofile no válida.");return token;}
    public String token()throws IOException{synchronized(LOCK){var key=vault.read();return key==null?null:key.key();}}
    void write(String token)throws IOException{synchronized(LOCK){vault.write(new SourceCredentials.ApiKey("1",valid(token)));}}
    void clear(){synchronized(LOCK){vault.clear();}}
    public long waitUntil()throws IOException{synchronized(LOCK){if(!wait.exists()&&!new File(wait+".bak").exists())return 0;try(InputStream in=new AtomicFile(wait).openRead()){ByteArrayOutputStream buffer=new ByteArrayOutputStream();int b;while((b=in.read())!=-1){if(buffer.size()>=64)throw new IOException("Estado de espera Gofile fuera de límite.");buffer.write(b);}byte[] raw=buffer.toByteArray();String s=new String(raw,StandardCharsets.US_ASCII);if(!s.matches("[0-9]{1,16}"))throw new IOException("Estado de espera Gofile no válido.");return Long.parseLong(s);}catch(NumberFormatException e){throw new IOException("Estado de espera Gofile no válido.");}}}
    public void waitUntil(long value)throws IOException{synchronized(LOCK){long end=Math.max(waitUntil(),Math.min(System.currentTimeMillis()+86400000L,value));AtomicFile file=new AtomicFile(wait);FileOutputStream out=null;try{out=file.startWrite();out.write(Long.toString(end).getBytes(StandardCharsets.US_ASCII));file.finishWrite(out);}catch(IOException e){if(out!=null)file.failWrite(out);throw e;}}}
}
