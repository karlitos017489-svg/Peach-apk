package com.peach.local;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

/** Share references and a separate, bounded Gofile download contract. No credentials in URLs. */
final class GofileUrls {
    static String id(String value){if(value==null||!value.matches("(?:[A-Za-z0-9_-]{6}|[A-Za-z0-9_-]{8}|[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12})"))throw new IllegalArgumentException("Referencia Gofile no admitida.");return value;}
    static String share(String value){URI u=SourceHttp.https(value);if(!Set.of("gofile.io","www.gofile.io").contains(u.getHost().toLowerCase(Locale.ROOT))||u.getPort()!=-1||u.getRawQuery()!=null||!u.getRawPath().matches("/d/[^/%]+/?"))throw new IllegalArgumentException("Enlace de carpeta Gofile no admitido.");return id(u.getPath().replaceFirst("^/d/","").replaceFirst("/$",""));}
    static String page(String id,int page){id(id);if(page<1||page>5000)throw new IllegalArgumentException("Página Gofile fuera de límite.");return "https://api.gofile.io/contents/"+id+"?page="+page+"&pageSize=100";}
    static boolean downloadable(String raw){try{URI u=SourceHttp.https(raw);String path=u.getPath(),encoded=u.getRawPath();return u.getPort()==-1&&u.getRawQuery()==null&&u.getHost().toLowerCase(Locale.ROOT).matches("store[a-z0-9-]{0,60}\\.gofile\\.io")&&encoded.matches("/download/(?:web/)?[A-Za-z0-9_-]{1,100}/[^/]+")&&!encoded.toLowerCase(Locale.ROOT).matches(".*%(?:00|0[ad]|2f|5c|25).*" )&&!path.contains("\\")&&Arrays.stream(path.split("/",-1)).noneMatch(s->s.equals(".")||s.equals("..")||s.chars().anyMatch(c->c<32||c==127));}catch(IllegalArgumentException e){return false;}}
    static void publicHost(String url,MediaRedirects.Resolver resolver,SourceHttp.Token token)throws IOException{token.check();String host=SourceHttp.https(url).getHost();InetAddress[] addresses;try{addresses=resolver.resolve(host);}catch(IOException e){throw new IOException("No se pudo resolver Gofile.");}token.check();if(addresses==null||addresses.length==0)throw new IOException("Gofile no tiene dirección pública.");for(var a:addresses)if(!MediaRedirects.publicAddress(a))throw new IOException("Se bloqueó un destino Gofile local o reservado.");}
    static List<String> folders(PublicationContent c)throws IOException{try{LinkedHashSet<String> ids=new LinkedHashSet<>();if(c==null)return List.of();if(c.text.length()>FanboxConnector.MAX_TEXT||c.attachments.length()>512*1024)throw new IOException("Contenido demasiado grande.");Matcher m=Pattern.compile("https://[^\\s<>\"']{1,4096}").matcher(c.text);while(m.find()){try{ids.add(share(m.group().replaceAll("[),.;]+$","")));}catch(IllegalArgumentException ignored){}}
        JSONArray a=new JSONArray(c.attachments);if(a.length()>100)throw new IOException("Demasiados adjuntos.");for(int i=0;i<a.length();i++){JSONObject j=a.getJSONObject(i);try{ids.add(share(j.optString("url","")));}catch(IllegalArgumentException ignored){}if("gofile".equals(j.optString("resourceProvider"))&&downloadable(j.optString("url")))ids.add(id(j.getString("gofileRoot")));}if(ids.size()>100)throw new IOException("Demasiados enlaces Gofile.");return List.copyOf(ids);}catch(JSONException|IllegalArgumentException e){throw new IOException("Referencias Gofile no válidas.");}}
}
