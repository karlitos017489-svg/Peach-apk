package com.peach.local;

import java.util.UUID;

public final class GroupStore {
    private final LibraryDatabase db;
    public GroupStore(LibraryDatabase db) {this.db=db;}
    public String create(String name) {
        MediaGroup group=new MediaGroup();group.id=UUID.randomUUID().toString();
        group.name=PlaylistStore.validName(name,80);group.createdAt=System.currentTimeMillis();
        db.library().insertGroup(group);return group.id;
    }
    public void rename(String id,String name) {db.library().renameGroup(id,PlaylistStore.validName(name,80));}
    public void add(String groupId,String mediaId) {
        db.runInTransaction(()-> {
            if(db.library().group(groupId)==null || db.library().get(mediaId)==null)
                throw new IllegalArgumentException("Grupo o documento no disponible");
            MediaGroupItem item=new MediaGroupItem();item.groupId=groupId;item.mediaId=mediaId;
            db.library().insertGroupItem(item);
        });
    }
}
