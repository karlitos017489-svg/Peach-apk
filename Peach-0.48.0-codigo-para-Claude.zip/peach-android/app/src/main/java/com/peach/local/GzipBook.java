package com.peach.local;

import java.io.*;
import java.util.*;
import java.util.zip.GZIPInputStream;

/** One bounded local expansion; GZIP header filenames are never trusted or used. */
public final class GzipBook implements ArchiveBook {
    private final File unpacked;private final List<Item> items;
    private GzipBook(File unpacked,String entry){this.unpacked=unpacked;items=List.of(new Item(entry,unpacked.length(),DocumentRules.entryKind(entry)));}
    static ArchiveBook open(File source,String name,File directory)throws IOException {
        String base=name.replace('\\','/');base=base.substring(base.lastIndexOf('/')+1);boolean isTar=base.toLowerCase(Locale.ROOT).endsWith(".tar.gz") || base.toLowerCase(Locale.ROOT).endsWith(".tgz");
        String entry=MediaRules.stem(base);ZipBook.safeName(entry);
        File unpacked;try(InputStream raw=new BufferedInputStream(new FileInputStream(source))){unpacked=ArchiveFiles.copy(new GZIPInputStream(raw),directory,"unpacked",isTar?ReaderSession.MAX_SOURCE_BYTES:ZipBook.MAX_ENTRY_BYTES,-1);}
        try{return isTar?new TarBook(unpacked):new GzipBook(unpacked,entry);}catch(IOException|RuntimeException|Error error){unpacked.delete();throw error;}
    }
    public List<Item> items(){return items;}
    public File read(String name,File directory)throws IOException {
        Item item=item(name);if(item==null || item.kind().isEmpty())throw new IOException("Entrada catalogada sin lector integrado.");
        return ArchiveFiles.copy(new FileInputStream(unpacked),directory,"entry",ZipBook.MAX_ENTRY_BYTES,item.bytes());
    }
    @Override public void close(){}
}
