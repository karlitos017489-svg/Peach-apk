package com.peach.local;

import android.content.Intent;
import android.os.*;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** Paged local chronology. Status labels describe the last checkpoint, never live presence. */
public final class HistoryActivity extends PeachActivity {
    public static class Draft extends ViewModel {
        final MutableLiveData<Integer> updates=new MutableLiveData<>(0);
        UsageStore.Page page=new UsageStore.Page(List.of(),new UsageStore.Summary(),0);
        String query="",error="";int kind,date,offset;volatile int generation;volatile boolean busy;
    }
    private LibraryDatabase db;private Draft draft;private TextView status;private Button older,newer;
    private ArrayAdapter<String> adapter;private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable search=()->reload(true);
    @Override protected void onCreate(Bundle saved){
        super.onCreate(saved);db=LibraryDatabase.get(this);draft=new ViewModelProvider(this).get(Draft.class);
        LinearLayout column=new LinearLayout(this);column.setOrientation(LinearLayout.VERTICAL);int pad=(int)(12*getResources().getDisplayMetrics().density);column.setPadding(pad,pad,pad,pad);setContentView(column);
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(column,(view,insets)->{var bars=insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars()|androidx.core.view.WindowInsetsCompat.Type.displayCutout()|androidx.core.view.WindowInsetsCompat.Type.ime());view.setPadding(pad+bars.left,pad+bars.top,pad+bars.right,pad+bars.bottom);return insets;});
        LinearLayout toolbar=new LinearLayout(this);column.addView(toolbar);button(toolbar,"Volver",v->finish());TextView title=new TextView(this);title.setText(R.string.history_title);title.setTextSize(20);toolbar.addView(title,new LinearLayout.LayoutParams(0,-2,1));button(toolbar,"Vaciar historial",v->clear()).setId(R.id.history_clear);
        LinearLayout filters=new LinearLayout(this);column.addView(filters);
        Spinner kind=spinner(filters,new String[]{"Todos los medios","Video","Audio","Imagen","Lectura"},draft.kind);kind.setId(R.id.history_kind);kind.setContentDescription("Tipo de sesión");
        Spinner date=spinner(filters,new String[]{"Todo el historial","Hoy","Últimos 7 días","Últimos 30 días"},draft.date);date.setId(R.id.history_date);date.setContentDescription("Intervalo del historial");
        kind.setOnItemSelectedListener(select(i->{if(draft.kind!=i){draft.kind=i;reload(true);}}));date.setOnItemSelectedListener(select(i->{if(draft.date!=i){draft.date=i;reload(true);}}));
        EditText input=new EditText(this);input.setId(R.id.history_search);input.setSingleLine(true);input.setHint("Buscar títulos registrados");input.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(300)});input.setText(draft.query);column.addView(input);
        input.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){draft.query=s.toString();handler.removeCallbacks(search);handler.postDelayed(search,200);}public void afterTextChanged(android.text.Editable e){}});
        status=new TextView(this);status.setId(R.id.history_status);status.setTextIsSelectable(true);column.addView(status);
        ListView list=new ListView(this);list.setId(R.id.history_list);column.addView(list,new LinearLayout.LayoutParams(-1,0,1));adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,new ArrayList<>());list.setAdapter(adapter);list.setOnItemClickListener((p,v,index,id)->details(draft.page.rows().get(index)));
        LinearLayout pages=new LinearLayout(this);column.addView(pages);newer=button(pages,"Más recientes",v->{draft.offset=Math.max(0,draft.offset-UsageStore.PAGE);reload(false);});newer.setId(R.id.history_newer);older=button(pages,"Más antiguos",v->{draft.offset+=UsageStore.PAGE;reload(false);});older.setId(R.id.history_older);
        draft.updates.observe(this,n->render());db.library().observeUsageCount().observe(this,n->reload(false));
    }
    private Button button(LinearLayout parent,String label,View.OnClickListener click){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setOnClickListener(click);parent.addView(b);return b;}
    private Spinner spinner(LinearLayout parent,String[] labels,int selected){Spinner s=new Spinner(this);s.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels));s.setSelection(selected);parent.addView(s,new LinearLayout.LayoutParams(0,-2,1));return s;}
    private AdapterView.OnItemSelectedListener select(java.util.function.IntConsumer change){return new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> p){}public void onItemSelected(AdapterView<?> p,View v,int index,long id){change.accept(index);}};}
    static long since(int date,LocalDate today,ZoneId zone){return date==0?0:today.minusDays(date==1?0:date==2?6:29).atStartOfDay(zone).toInstant().toEpochMilli();}
    private void reload(boolean reset){if(reset)draft.offset=0;int token=++draft.generation;draft.busy=true;String query=draft.query,kind=switch(draft.kind){case 1->"video";case 2->"audio";case 3->"image";case 4->"reading";default->"";};int offset=draft.offset;long since=since(draft.date,LocalDate.now(),ZoneId.systemDefault());Draft retained=draft;render();
        LibraryDatabase.IO.execute(()->{
            UsageStore.Page loaded=null;String error="";try{loaded=new UsageStore(db).page(since,kind,query,offset);}catch(Exception e){error="No se pudo consultar el historial.";}
            UsageStore.Page result=loaded;String failure=error;
            handler.post(()->{if(token!=retained.generation)return;if(result!=null){retained.page=result;retained.offset=result.offset();}retained.error=failure;retained.busy=false;retained.updates.setValue(1);});
        });
    }
    private void render(){if(isDestroyed()||status==null)return;var p=draft.page;
        status.setText(draft.error.isEmpty()?getString(R.string.history_summary,p.summary().sessions,p.summary().documents,p.summary().finals,p.offset()+1,p.offset()+p.rows().size()):draft.error);
        if(p.rows().isEmpty()&&draft.error.isEmpty())status.setText(R.string.history_empty);
        older.setEnabled(!draft.busy&&p.offset()+p.rows().size()<p.summary().sessions);newer.setEnabled(!draft.busy&&p.offset()>0);
        adapter.clear();adapter.addAll(p.rows().stream().map(s->date(s.startedAt)+" · "+UsageStore.kindLabel(s.kind)+"\n"+s.title+"\n"+UsageStore.statusLabel(s.status)).toList());
    }
    static String date(long millis){return DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm",Locale.getDefault()).format(Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()));}
    static String describe(UsageSession s){return s.title+"\n"+UsageStore.kindLabel(s.kind)+"\nInicio: "+date(s.startedAt)+"\nÚltimo registro: "+date(s.updatedAt)+"\n"+UsageStore.statusLabel(s.status)+
        "\nPosición guardada: "+s.position/1000+" s · Duración guardada: "+s.duration/1000+" s"+(s.entry.isEmpty()?"":"\nEntrada: "+s.entry)+
        (s.kind.equals("reading")?"\nPágina/capítulo: "+(s.page+1)+" · Desplazamiento: "+s.scroll:"")+"\n\nEl estado describe el último registro. No confirma reproducción actual ni tiempo total visto o escuchado.";}
    private void details(UsageSession snapshot){LibraryDatabase.IO.execute(()->{MediaEntry media=db.library().get(snapshot.mediaId);UsageSession current=db.library().usage(snapshot.id);runOnUiThread(()->{
        if(isDestroyed()||isFinishing())return;if(current==null)return;TextView text=new TextView(this);text.setText(describe(current));text.setTextIsSelectable(true);text.setPadding(20,12,20,12);ScrollView scroll=new ScrollView(this);scroll.addView(text);
        var builder=new AlertDialog.Builder(this).setTitle(R.string.history_title).setView(scroll).setNegativeButton("Cerrar",null).setNeutralButton("Borrar registro",(d,w)->LibraryDatabase.IO.execute(()->db.library().deleteUsage(current.id)));
        if(media!=null&&!media.missing&&(DocumentRules.readable(media.name)||MediaRules.playable(media)||MediaRules.IMAGE.equals(media.mediaType)))builder.setPositiveButton("Abrir documento",(d,w)->open(media));builder.show();
    });});}
    private void open(MediaEntry media){Class<?> screen=DocumentRules.readable(media.name)?ReaderActivity.class:MediaRules.IMAGE.equals(media.mediaType)?ImageViewerActivity.class:MediaRules.AUDIO.equals(media.mediaType)?AudioActivity.class:PlayerActivity.class;startActivity(new Intent(this,screen).putExtra("mediaId",media.id));}
    private void clear(){new AlertDialog.Builder(this).setTitle("Vaciar historial").setMessage("Borra las visitas registradas. Los archivos, favoritos, contadores y el progreso se conservan. Una copia guardada puede recuperar registros. Se conservan hasta 10.000 visitas recientes.")
        .setNegativeButton("Cancelar",null).setPositiveButton("Vaciar",(d,w)->LibraryDatabase.IO.execute(()->db.library().clearUsage())).show();}
    @Override protected void onDestroy(){handler.removeCallbacks(search);super.onDestroy();}
}
