package com.peach.local;

import android.content.ContentResolver;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import java.io.IOException;
import java.io.InputStream;

/** Bounds-first decoding from granted documents. No full-file byte array or network URL. */
public final class ImageFiles {
    public record Decoded(Bitmap bitmap,int originalWidth,int originalHeight) {}
    private ImageFiles() {}
    private interface Input {InputStream open() throws IOException;}
    public static int sampleSize(int width,int height,int edge) {
        if (width<=0 || height<=0 || width>1000000 || height>1000000 || edge<1 || edge>4096) throw new IllegalArgumentException("Dimensiones no válidas");
        int sample=1;
        while ((width+(long)sample-1)/sample>edge || (height+(long)sample-1)/sample>edge) sample*=2;
        return sample;
    }
    public static Decoded decode(ContentResolver resolver,Uri uri,int edge) throws IOException {
        if (!"content".equals(uri.getScheme())) throw new IOException("Documento no válido");
        return decode(()->resolver.openInputStream(uri),edge);
    }
    static Decoded decode(java.io.File file,int edge) throws IOException {
        return decode(()->new java.io.FileInputStream(file),edge);
    }
    private static Decoded decode(Input source,int edge) throws IOException {
        BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;
        try (InputStream in=source.open()) {if(in==null) throw new IOException("Imagen inaccesible");BitmapFactory.decodeStream(in,null,bounds);}
        if (bounds.outWidth<=0 || bounds.outHeight<=0) throw new IOException("Formato de imagen no compatible");
        BitmapFactory.Options options=new BitmapFactory.Options();options.inSampleSize=sampleSize(bounds.outWidth,bounds.outHeight,edge);
        options.inPreferredConfig=Bitmap.Config.ARGB_8888;
        Bitmap bitmap;
        try (InputStream in=source.open()) {if(in==null) throw new IOException("Imagen inaccesible");bitmap=BitmapFactory.decodeStream(in,null,options);}
        if (bitmap==null) throw new IOException("No se pudo decodificar la imagen");
        int orientation=1;
        try (InputStream in=source.open()) {
            if (in!=null) orientation=new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION,1);
        } catch (IOException | RuntimeException ignored) { /* Formats without EXIF use their encoded orientation. */ }
        Matrix matrix=orientation(orientation);
        if (!matrix.isIdentity()) {
            Bitmap rotated=Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,false);
            if (rotated!=bitmap) bitmap.recycle();bitmap=rotated;
        }
        boolean swap=orientation>=5 && orientation<=8;
        return new Decoded(bitmap,swap?bounds.outHeight:bounds.outWidth,swap?bounds.outWidth:bounds.outHeight);
    }
    static Matrix orientation(int value) {
        float[] entries=switch(value) {
            case 2->new float[]{-1,0,0,0,1,0,0,0,1};
            case 3->new float[]{-1,0,0,0,-1,0,0,0,1};
            case 4->new float[]{1,0,0,0,-1,0,0,0,1};
            case 5->new float[]{0,1,0,1,0,0,0,0,1};
            case 6->new float[]{0,-1,0,1,0,0,0,0,1};
            case 7->new float[]{0,-1,0,-1,0,0,0,0,1};
            case 8->new float[]{0,1,0,-1,0,0,0,0,1};
            default->new float[]{1,0,0,0,1,0,0,0,1};
        };
        Matrix matrix=new Matrix();matrix.setValues(entries);return matrix;
    }
}
