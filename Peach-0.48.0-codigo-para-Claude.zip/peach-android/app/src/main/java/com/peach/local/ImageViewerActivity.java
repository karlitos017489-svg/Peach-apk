package com.peach.local;

import android.os.Bundle;
import android.net.Uri;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public final class ImageViewerActivity extends PeachActivity {
    private final ExecutorService decoder=Executors.newSingleThreadExecutor();
    private Future<?> pending;
    private LibraryDatabase db;
    private ZoomImageView canvas;
    private List<MediaEntry> images=List.of();
    private int index,request;private boolean localImage,resumed;
    private String recordedId="";
    private UsageTracker history;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);setContentView(R.layout.activity_image);db=LibraryDatabase.get(this);
        history=new UsageTracker(db,state);
        canvas=findViewById(R.id.imageCanvas);WindowCompat.setDecorFitsSystemWindows(getWindow(),false);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.imageRoot),(view,insets)-> {
            Insets bars=insets.getInsets(WindowInsetsCompat.Type.systemBars()|WindowInsetsCompat.Type.displayCutout());
            view.setPadding(bars.left,bars.top,bars.right,bars.bottom);return insets;
        });
        findViewById(R.id.imageBack).setOnClickListener(v->finish());
        findViewById(R.id.imagePrevious).setOnClickListener(v->{if(index>0){index--;showImage();}});
        findViewById(R.id.imageNext).setOnClickListener(v->{if(index+1<images.size()){index++;showImage();}});
        findViewById(R.id.imageZoomIn).setOnClickListener(v->canvas.zoomBy(1.5f));
        findViewById(R.id.imageZoomOut).setOnClickListener(v->canvas.zoomBy(1/1.5f));
        findViewById(R.id.imageFit).setOnClickListener(v->canvas.resetZoom());
        findViewById(R.id.imageFavorite).setOnClickListener(v->favorite());
        findViewById(R.id.imageDetails).setOnClickListener(v->{
            if (!images.isEmpty()) {MediaEntry m=images.get(index);new AlertDialog.Builder(this).setTitle(m.displayTitle())
                .setView(MediaDetailsView.create(this,m)).setPositiveButton("Cerrar",null).show();}
        });
        if(getIntent().getBooleanExtra("localImage",false)){
            Uri local=getIntent().getData();if(!SourceFiles.local(local)){finish();return;}
            MediaEntry image=new MediaEntry();image.id=local.toString();image.uri=image.id;image.name=getIntent().getStringExtra("localImageName");if(image.name==null)image.name="Imagen local";image.title=image.name;image.mediaType=MediaRules.IMAGE;
            localImage=true;images=List.of(image);findViewById(R.id.imageFavorite).setVisibility(android.view.View.GONE);showImage();return;
        }
        String id=state==null?getIntent().getStringExtra("mediaId"):state.getString("currentId",getIntent().getStringExtra("mediaId"));
        if(state!=null)recordedId=state.getString("recordedId","");
        if(id==null){finish();return;}
        history.prepare(id);
        LibraryDatabase.IO.execute(()-> {
            MediaEntry selected=db.library().get(id);
            if(selected==null || !MediaRules.IMAGE.equals(selected.mediaType)) {runOnUiThread(this::finish);return;}
            String playlist=extra("playlistId");
            List<MediaEntry> scope=LibraryView.select(EntityIndex.select(db.library(),CatalogIndex.select(db.library().allMedia(),extra("facet"),extra("term"),extra("group"),db.library().groupItems()),extra("entityId")),extra("query"),getIntent().getIntExtra("filter",0),
                extra("root"),extra("folder"),playlist,playlist.isEmpty()?List.of():db.library().playlistItems(playlist),
                getIntent().getIntExtra("order",0),MediaRules.IMAGE);
            List<MediaEntry> loaded=MediaQueues.select(scope,selected,true);
            runOnUiThread(()-> {
                if(isFinishing() || isDestroyed())return;images=loaded;
                for(int i=0;i<images.size();i++)if(images.get(i).id.equals(id))index=i;
                showImage();
            });
        });
    }
    private String extra(String key) {String value=getIntent().getStringExtra(key);return value==null?"":value;}
    private void showImage() {
        if(images.isEmpty())return;
        MediaEntry media=images.get(index);int token=++request;
        if(!localImage)history.prepare(media.id);
        if(pending!=null)pending.cancel(true);AnimatedImages.stop(canvas.getDrawable());canvas.setImageDrawable(null);
        ((TextView)findViewById(R.id.imageTitle)).setText(media.displayTitle());
        canvas.setContentDescription(media.displayTitle()+". Pellizca o usa los botones para ampliar.");
        findViewById(R.id.imagePrevious).setEnabled(index>0);findViewById(R.id.imageNext).setEnabled(index+1<images.size());
        favoriteLabel();status((index+1)+" / "+images.size()+" · Cargando…");
        pending=decoder.submit(()-> {
            try {
                if(android.os.Build.VERSION.SDK_INT>=28 && (MediaRules.extension(media.name).equals("gif")||MediaRules.extension(media.name).equals("webp"))){
                    android.graphics.drawable.Drawable drawable=AnimatedImages.decode(getContentResolver(),Uri.parse(media.uri));
                    runOnUiThread(()->{if(token!=request||isDestroyed()||isFinishing()){AnimatedImages.stop(drawable);return;}canvas.setImageDrawable(drawable);canvas.resetZoom();if(resumed)AnimatedImages.start(drawable);recordImage(media);status("Imagen/GIF local · Vista ajustada hasta 1024 px");});return;
                }
                ImageFiles.Decoded decoded=ImageFiles.decode(getContentResolver(),Uri.parse(media.uri),2048);
                runOnUiThread(()-> {
                    if(token!=request || isDestroyed() || isFinishing()){decoded.bitmap().recycle();return;}
                    canvas.setImageBitmap(decoded.bitmap());
                    recordImage(media);
                    status((index+1)+" / "+images.size()+" · "+decoded.originalWidth()+" × "+decoded.originalHeight()+" px · Vista ajustada hasta 2048 px");
                });
            } catch(Exception | OutOfMemoryError error) {runOnUiThread(()-> {
                if(token==request && !isDestroyed())status("No se pudo abrir. Revisa el permiso, la carpeta o el formato de imagen.");
            });}
        });
    }
    private void recordImage(MediaEntry media){if(localImage)return;history.open(media,"image");history.touch("active");if(!recordedId.equals(media.id)){recordedId=media.id;LibraryDatabase.IO.execute(()->db.library().recordPlay(media.id,System.currentTimeMillis()));}}
    private void favorite() {
        if(images.isEmpty()||localImage)return;MediaEntry media=images.get(index);
        LibraryDatabase.IO.execute(()-> {
            try {
                db.library().toggleFavorite(media.id);MediaEntry updated=db.library().get(media.id);
                if(updated!=null)runOnUiThread(()->{media.favorite=updated.favorite;if(!isDestroyed() && images.get(index).id.equals(media.id))favoriteLabel();});
            } catch(Exception error) {runOnUiThread(()->Toast.makeText(this,"No se pudo guardar el favorito.",Toast.LENGTH_SHORT).show());}
        });
    }
    private void favoriteLabel() {
        boolean favorite=images.get(index).favorite;findViewById(R.id.imageFavorite).setSelected(favorite);
        ((TextView)findViewById(R.id.imageFavorite)).setText(favorite?"★":"☆");
        findViewById(R.id.imageFavorite).setContentDescription(favorite?"Quitar favorito":"Marcar favorito");
    }
    private void status(String text) {((TextView)findViewById(R.id.imageStatus)).setText(text);}
    @Override protected void onSaveInstanceState(Bundle state) {
        if(!images.isEmpty())state.putString("currentId",images.get(index).id);state.putString("recordedId",recordedId);history.save(state);super.onSaveInstanceState(state);
    }
    @Override protected void onResume(){super.onResume();resumed=true;AnimatedImages.start(canvas.getDrawable());history.touch("active");}
    @Override protected void onPause(){resumed=false;AnimatedImages.stop(canvas.getDrawable());history.touch("paused");super.onPause();}
    @Override protected void onDestroy() {if(!isChangingConfigurations())history.finish();request++;if(pending!=null)pending.cancel(true);decoder.shutdownNow();AnimatedImages.stop(canvas.getDrawable());canvas.setImageDrawable(null);super.onDestroy();}
}
