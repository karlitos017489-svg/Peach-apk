package com.peach.local;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import java.util.List;

@Dao
public interface LibraryDao {
    @Query("SELECT * FROM media ORDER BY title COLLATE NOCASE")
    LiveData<List<MediaEntry>> observeMedia();
    @Query("SELECT * FROM media ORDER BY title COLLATE NOCASE") List<MediaEntry> allMedia();
    @Query("SELECT * FROM media WHERE mediaType='video' AND missing=0 AND (:root='' OR root=:root) AND (:folder='' OR folder=:folder OR substr(folder,1,length(:folder)+3)=:folder || ' / ') ORDER BY root,folder,name,id LIMIT :limit")
    List<MediaEntry> reviewMedia(String root,String folder,int limit);
    @Query("SELECT * FROM scan_queue WHERE root=:root AND folder=:folder LIMIT 1") ScanDirectory directoryForFolder(String root,String folder);
    @Query("UPDATE media SET uri=:uri,root=:root,name=:name,folder=:folder,title=:title,bytes=:bytes,modified=:modified,generation=:generation,missing=:missing WHERE id=:id")
    void relocate(String id,String uri,String root,String name,String folder,String title,long bytes,long modified,long generation,boolean missing);
    @Query("SELECT * FROM media WHERE id=:id") MediaEntry get(String id);
    @Insert(onConflict = OnConflictStrategy.IGNORE) long insertMedia(MediaEntry media);
    @Query("UPDATE media SET uri=:uri,root=:root,name=:name,folder=:folder,title=:title,tags=:tags," +
        "actors=:actors,studio=:studio,plot=:plot,year=:year,poster=:poster,subtitles=:subtitles,nfoDetails=:nfoDetails,mediaType=:mediaType," +
        "bytes=:bytes,modified=:modified,generation=:generation,missing=0 WHERE id=:id")
    void updateScan(String id, String uri, String root, String name, String folder, String title,
        String tags, String actors, String studio, String plot, String year, String poster,
        String subtitles, String nfoDetails, String mediaType, long bytes, long modified, long generation);
    @Query("UPDATE media SET favorite=NOT favorite WHERE id=:id") void toggleFavorite(String id);
    @Query("UPDATE media SET watched=NOT watched WHERE id=:id") void toggleWatched(String id);
    @Query("UPDATE media SET position=:position,duration=:duration,lastPlayed=:now," +
        "watched=CASE WHEN :ended THEN 1 ELSE watched END WHERE id=:id")
    void progress(String id, long position, long duration, long now, boolean ended);
    @Query("UPDATE media SET playCount=playCount+1,lastPlayed=:now WHERE id=:id")
    void recordPlay(String id, long now);
    @Query("UPDATE media SET favorite=:favorite,watched=:watched,position=:position," +
        "duration=:duration,lastPlayed=:lastPlayed,playCount=:playCount WHERE id=:id")
    void restoreState(String id, boolean favorite, boolean watched, long position, long duration,
        long lastPlayed, long playCount);
    @Query("UPDATE media SET missing=1 WHERE root=:root AND generation<:generation")
    void markMissing(String root, long generation);
    @Query("SELECT * FROM roots ORDER BY label") List<LibraryRoot> roots();
    @Query("SELECT * FROM scan_queue WHERE root=:root AND uri=:uri LIMIT 1") ScanDirectory scanDirectory(String root,String uri);
    @Query("SELECT * FROM roots ORDER BY label") LiveData<List<LibraryRoot>> observeRoots();
    @Insert(onConflict = OnConflictStrategy.IGNORE) long addRoot(LibraryRoot root);
    @Query("UPDATE roots SET state=:state WHERE uri=:root") void rootState(String root, int state);
    @Query("UPDATE roots SET generation=generation+1,state=1,directories=0,warnings=0 WHERE uri=:root")
    void nextGeneration(String root);
    @Query("UPDATE roots SET directories=directories+1,warnings=warnings+:warnings WHERE uri=:root")
    void directoryComplete(String root, int warnings);
    @Query("DELETE FROM scan_queue WHERE root=:root") void clearQueue(String root);
    @Insert(onConflict = OnConflictStrategy.IGNORE) void enqueue(ScanDirectory directory);
    @Query("SELECT * FROM scan_queue WHERE root=:root AND done=0 LIMIT 1") ScanDirectory next(String root);
    @Query("UPDATE scan_queue SET done=1 WHERE root=:root AND uri=:uri") void done(String root, String uri);
    @Query("DELETE FROM media WHERE root=:root") void forgetMedia(String root);
    @Query("DELETE FROM roots WHERE uri=:root") void forgetRoot(String root);
    @Query("UPDATE media SET userTitle=:title,userTags=:tags WHERE id=:id")
    void editMetadata(String id, String title, String tags);
    @Query("SELECT * FROM playlists ORDER BY name COLLATE NOCASE,id") LiveData<List<Playlist>> observePlaylists();
    @Query("SELECT * FROM playlists ORDER BY name COLLATE NOCASE,id") List<Playlist> playlists();
    @Query("SELECT * FROM playlists WHERE id=:id") Playlist playlist(String id);
    @Insert(onConflict=OnConflictStrategy.IGNORE) long insertPlaylist(Playlist playlist);
    @Query("UPDATE playlists SET name=:name WHERE id=:id") void renamePlaylist(String id,String name);
    @Query("DELETE FROM playlists WHERE id=:id") void deletePlaylist(String id);
    @Query("SELECT * FROM playlist_items ORDER BY playlistId,position,mediaId") LiveData<List<PlaylistItem>> observePlaylistItems();
    @Query("SELECT * FROM playlist_items WHERE playlistId=:id ORDER BY position,mediaId") List<PlaylistItem> playlistItems(String id);
    @Query("SELECT COALESCE(MAX(position),-1)+1 FROM playlist_items WHERE playlistId=:id") int nextPlaylistPosition(String id);
    @Query("SELECT media.* FROM media INNER JOIN playlist_items ON media.id=playlist_items.mediaId WHERE playlist_items.playlistId=:id ORDER BY playlist_items.position,media.id")
    List<MediaEntry> playlistMedia(String id);
    @Insert(onConflict=OnConflictStrategy.IGNORE) long insertPlaylistItem(PlaylistItem item);
    @Query("UPDATE playlist_items SET position=:position WHERE playlistId=:playlistId AND mediaId=:mediaId")
    void playlistPosition(String playlistId,String mediaId,int position);
    @Query("DELETE FROM playlist_items WHERE playlistId=:playlistId AND mediaId=:mediaId")
    void removePlaylistItem(String playlistId,String mediaId);
    @Query("DELETE FROM playlist_items WHERE playlistId=:id") void clearPlaylist(String id);
    @Query("SELECT * FROM media_groups ORDER BY name COLLATE NOCASE,id") LiveData<List<MediaGroup>> observeGroups();
    @Query("SELECT * FROM media_groups ORDER BY name COLLATE NOCASE,id") List<MediaGroup> groups();
    @Query("SELECT * FROM media_groups WHERE id=:id") MediaGroup group(String id);
    @Insert(onConflict=OnConflictStrategy.IGNORE) long insertGroup(MediaGroup group);
    @Query("UPDATE media_groups SET name=:name WHERE id=:id") void renameGroup(String id,String name);
    @Query("DELETE FROM media_groups WHERE id=:id") void deleteGroup(String id);
    @Query("SELECT * FROM media_group_items ORDER BY groupId,mediaId") LiveData<List<MediaGroupItem>> observeGroupItems();
    @Query("SELECT * FROM media_group_items ORDER BY groupId,mediaId") List<MediaGroupItem> groupItems();
    @Query("SELECT * FROM media_group_items WHERE groupId=:id ORDER BY mediaId") List<MediaGroupItem> groupItems(String id);
    @Insert(onConflict=OnConflictStrategy.IGNORE) long insertGroupItem(MediaGroupItem item);
    @Query("DELETE FROM media_group_items WHERE groupId=:groupId AND mediaId=:mediaId") void removeGroupItem(String groupId,String mediaId);
    @Query("DELETE FROM media_group_items WHERE groupId=:id") void clearGroup(String id);
    @Query("SELECT * FROM catalog_entities ORDER BY name COLLATE NOCASE,id") List<CatalogEntity> entities();
    @Query("SELECT * FROM catalog_entities ORDER BY name COLLATE NOCASE,id") LiveData<List<CatalogEntity>> observeEntities();
    @Query("SELECT * FROM catalog_entities WHERE id=:id") CatalogEntity entity(String id);
    @Insert(onConflict=OnConflictStrategy.ABORT) void insertEntity(CatalogEntity entity);
    @androidx.room.Update void updateEntity(CatalogEntity entity);
    @Query("DELETE FROM catalog_entities WHERE id=:id") void deleteEntity(String id);
    @Query("UPDATE catalog_entities SET favorite=NOT favorite WHERE id=:id") void favoriteEntity(String id);
    @Query("SELECT * FROM entity_aliases ORDER BY entityId,name") List<EntityAlias> aliases();
    @Query("SELECT * FROM entity_aliases ORDER BY entityId,name") LiveData<List<EntityAlias>> observeAliases();
    @Insert(onConflict=OnConflictStrategy.IGNORE) void insertAlias(EntityAlias alias);
    @Query("DELETE FROM entity_aliases WHERE entityId=:id AND name=:name") void removeAlias(String id,String name);
    @Query("DELETE FROM entity_aliases WHERE entityId=:id") void clearAliases(String id);
    @Query("SELECT * FROM media_entity_links ORDER BY entityId,mediaId,role") List<MediaEntityLink> entityLinks();
    @Query("SELECT * FROM media_entity_links ORDER BY entityId,mediaId,role") LiveData<List<MediaEntityLink>> observeEntityLinks();
    @Insert(onConflict=OnConflictStrategy.IGNORE) void insertEntityLink(MediaEntityLink link);
    @Query("DELETE FROM media_entity_links WHERE entityId=:id AND mediaId=:mediaId AND role=:role") void removeEntityLink(String id,String mediaId,String role);
    @Query("DELETE FROM media_entity_links WHERE entityId=:id") void clearEntityLinks(String id);
    @Query("SELECT * FROM entity_references ORDER BY entityId,provider,externalId") List<EntityReference> entityReferences();
    @Query("SELECT * FROM entity_references ORDER BY entityId,provider,externalId") LiveData<List<EntityReference>> observeEntityReferences();
    @Insert(onConflict=OnConflictStrategy.REPLACE) void putEntityReference(EntityReference reference);
    @Query("DELETE FROM entity_references WHERE entityId=:id AND provider=:provider AND externalId=:externalId") void removeEntityReference(String id,String provider,String externalId);
    @Query("DELETE FROM entity_references WHERE entityId=:id") void clearEntityReferences(String id);
    @Query("SELECT * FROM want_items ORDER BY createdAt DESC,id") List<WantItem> wants();
    @Query("SELECT * FROM want_items ORDER BY createdAt DESC,id") LiveData<List<WantItem>> observeWants();
    @Query("SELECT * FROM want_items WHERE id=:id") WantItem want(String id);
    @Insert(onConflict=OnConflictStrategy.ABORT) void insertWant(WantItem item);
    @androidx.room.Update void updateWant(WantItem item);
    @Query("DELETE FROM want_items WHERE id=:id") void deleteWant(String id);
    @Query("SELECT * FROM reader_progress ORDER BY mediaId") List<ReaderProgress> readerProgress();
    @Query("SELECT * FROM reader_progress ORDER BY mediaId") LiveData<List<ReaderProgress>> observeReaderProgress();
    @Query("SELECT * FROM reader_progress WHERE mediaId=:id") ReaderProgress readerProgress(String id);
    @Insert(onConflict=OnConflictStrategy.REPLACE) void putReaderProgress(ReaderProgress state);
    @Query("SELECT * FROM catalog_snapshots ORDER BY label,id") List<CatalogSnapshot> snapshots();
    @Query("SELECT id,label,importedAt FROM catalog_snapshots ORDER BY label,id") List<CatalogSnapshot.Head> snapshotHeads();
    @Query("SELECT COUNT(*) FROM catalog_snapshots") int snapshotCount();
    @Query("SELECT * FROM catalog_snapshots WHERE id=:id") CatalogSnapshot snapshot(String id);
    @Insert(onConflict=OnConflictStrategy.REPLACE) void putSnapshot(CatalogSnapshot snapshot);
    @Query("SELECT * FROM entity_memberships ORDER BY memberId") List<EntityMembership> memberships();
    @Query("SELECT * FROM entity_memberships ORDER BY memberId") LiveData<List<EntityMembership>> observeMemberships();
    @Query("SELECT * FROM entity_memberships WHERE memberId=:id") EntityMembership membership(String id);
    @Insert(onConflict=OnConflictStrategy.REPLACE) void putMembership(EntityMembership membership);
    @Query("DELETE FROM entity_memberships WHERE memberId=:id") void removeMembership(String id);
    @Query("SELECT * FROM publications ORDER BY publishedAt DESC,createdAt DESC,id") List<Publication> publications();
    @Query("SELECT * FROM publications WHERE id=:id") Publication publication(String id);
    @Insert(onConflict=OnConflictStrategy.ABORT) void insertPublication(Publication row);
    @androidx.room.Update void updatePublication(Publication row);
    @Query("DELETE FROM publications WHERE id=:id") void deletePublication(String id);
    @Query("UPDATE want_items SET publicationId=NULL WHERE publicationId=:id") void detachPublicationWants(String id);
    @Query("SELECT * FROM follow_sources ORDER BY label,id") List<FollowSource> sources();
    @Query("SELECT * FROM follow_sources WHERE id=:id") FollowSource source(String id);
    @Insert(onConflict=OnConflictStrategy.ABORT) void insertSource(FollowSource source);
    @androidx.room.Update void updateSource(FollowSource source);
    @Query("DELETE FROM follow_sources WHERE id=:id") void deleteSource(String id);
    @Query("SELECT * FROM publication_content ORDER BY publicationId") List<PublicationContent> publicationContents();
    @Query("SELECT * FROM publication_content WHERE publicationId=:id") PublicationContent publicationContent(String id);
    @Query("DELETE FROM publication_content WHERE publicationId=:id") void deletePublicationContent(String id);
    @Insert(onConflict=OnConflictStrategy.REPLACE) void putPublicationContent(PublicationContent content);
    @Query("SELECT * FROM usage_sessions WHERE id=:id") UsageSession usage(String id);
    @Insert(onConflict=OnConflictStrategy.ABORT) void insertUsage(UsageSession row);
    @androidx.room.Update void updateUsage(UsageSession row);
    @Query("SELECT COUNT(*) FROM usage_sessions") LiveData<Long> observeUsageCount();
    @Query("SELECT COUNT(*) FROM usage_sessions") long usageCount();
    @Query("SELECT * FROM usage_sessions ORDER BY startedAt DESC,id DESC LIMIT :limit") List<UsageSession> usageBackup(int limit);
    @Query("SELECT * FROM usage_sessions WHERE startedAt>=:since AND (:kind='' OR kind=:kind) AND instr(searchTitle,:query)>0 ORDER BY startedAt DESC,id DESC LIMIT :limit OFFSET :offset")
    List<UsageSession> usagePage(long since,String kind,String query,int limit,int offset);
    @Query("SELECT COUNT(*) AS sessions,COUNT(DISTINCT mediaId) AS documents,COALESCE(SUM(CASE WHEN completed=1 AND kind IN ('audio','video') THEN 1 ELSE 0 END),0) AS finals FROM usage_sessions WHERE startedAt>=:since AND (:kind='' OR kind=:kind) AND instr(searchTitle,:query)>0")
    UsageStore.Summary usageSummary(long since,String kind,String query);
    @Query("UPDATE usage_sessions SET position=:position,duration=:duration,entry=:entry,page=:page,scroll=:scroll,updatedAt=MAX(updatedAt,:now),completed=CASE WHEN :completed THEN 1 ELSE completed END,status=CASE WHEN :completed THEN 'ended' WHEN completed=1 AND :status IN ('closed','paused') THEN 'ended' WHEN status='error' AND :status IN ('closed','paused') THEN status ELSE :status END WHERE id=:id")
    void checkpointUsage(String id,long position,long duration,String entry,int page,int scroll,String status,boolean completed,long now);
    @Query("UPDATE usage_sessions SET updatedAt=MAX(updatedAt,:now),status=CASE WHEN completed=1 AND :status IN ('closed','paused') THEN 'ended' WHEN status='error' AND :status IN ('closed','paused') THEN status WHEN status='ended' AND :status='closed' THEN status ELSE :status END WHERE id=:id")
    void touchUsage(String id,String status,long now);
    @Query("DELETE FROM usage_sessions WHERE id NOT IN (SELECT id FROM usage_sessions ORDER BY startedAt DESC,id DESC LIMIT :keep)") void pruneUsage(int keep);
    @Query("DELETE FROM usage_sessions WHERE id=:id") void deleteUsage(String id);
    @Query("DELETE FROM usage_sessions") void clearUsage();
}
