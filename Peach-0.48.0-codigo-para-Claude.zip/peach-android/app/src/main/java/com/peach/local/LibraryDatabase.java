package com.peach.local;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {MediaEntry.class, LibraryRoot.class, ScanDirectory.class, Playlist.class, PlaylistItem.class,
    MediaGroup.class,MediaGroupItem.class,CatalogEntity.class,EntityAlias.class,MediaEntityLink.class,
    EntityReference.class,WantItem.class,ReaderProgress.class,CatalogSnapshot.class,EntityMembership.class,Publication.class,FollowSource.class,PublicationContent.class,UsageSession.class}, version = 13,
    exportSchema = true)
public abstract class LibraryDatabase extends RoomDatabase {
    private static volatile LibraryDatabase instance;
    public static final ExecutorService IO = Executors.newSingleThreadExecutor();
    public abstract LibraryDao library();
    public static final androidx.room.migration.Migration MIGRATION_1_2 = new androidx.room.migration.Migration(1,2) {
        @Override public void migrate(androidx.sqlite.db.SupportSQLiteDatabase db) {
            db.execSQL("ALTER TABLE media ADD COLUMN userTitle TEXT");
            db.execSQL("ALTER TABLE media ADD COLUMN userTags TEXT");
            db.execSQL("ALTER TABLE media ADD COLUMN addedAt INTEGER NOT NULL DEFAULT 0");
            db.execSQL("CREATE TABLE IF NOT EXISTS playlists (id TEXT NOT NULL, name TEXT NOT NULL, createdAt INTEGER NOT NULL, PRIMARY KEY(id))");
            db.execSQL("CREATE TABLE IF NOT EXISTS playlist_items (playlistId TEXT NOT NULL, mediaId TEXT NOT NULL, position INTEGER NOT NULL, PRIMARY KEY(playlistId,mediaId), FOREIGN KEY(playlistId) REFERENCES playlists(id) ON UPDATE NO ACTION ON DELETE CASCADE, FOREIGN KEY(mediaId) REFERENCES media(id) ON UPDATE NO ACTION ON DELETE CASCADE)");
            db.execSQL("CREATE INDEX IF NOT EXISTS index_playlist_items_mediaId ON playlist_items(mediaId)");
        }
    };
    public static final androidx.room.migration.Migration MIGRATION_2_3 = new androidx.room.migration.Migration(2,3) {
        @Override public void migrate(androidx.sqlite.db.SupportSQLiteDatabase db) {
            db.execSQL("ALTER TABLE media ADD COLUMN nfoDetails TEXT NOT NULL DEFAULT '{}'");
        }
    };
    public static final androidx.room.migration.Migration MIGRATION_3_4 = new androidx.room.migration.Migration(3,4) {
        @Override public void migrate(androidx.sqlite.db.SupportSQLiteDatabase db) {
            db.execSQL("ALTER TABLE media ADD COLUMN mediaType TEXT NOT NULL DEFAULT 'video'");
        }
    };
    public static final androidx.room.migration.Migration MIGRATION_4_5 = new androidx.room.migration.Migration(4,5) {
        @Override public void migrate(androidx.sqlite.db.SupportSQLiteDatabase db) {
            db.execSQL("CREATE TABLE IF NOT EXISTS media_groups (id TEXT NOT NULL, name TEXT NOT NULL, createdAt INTEGER NOT NULL, PRIMARY KEY(id))");
            db.execSQL("CREATE TABLE IF NOT EXISTS media_group_items (groupId TEXT NOT NULL, mediaId TEXT NOT NULL, PRIMARY KEY(groupId,mediaId), FOREIGN KEY(groupId) REFERENCES media_groups(id) ON UPDATE NO ACTION ON DELETE CASCADE, FOREIGN KEY(mediaId) REFERENCES media(id) ON UPDATE NO ACTION ON DELETE CASCADE)");
            db.execSQL("CREATE INDEX IF NOT EXISTS index_media_group_items_mediaId ON media_group_items(mediaId)");
        }
    };
    public static final androidx.room.migration.Migration MIGRATION_5_6 = new androidx.room.migration.Migration(5,6) {
        @Override public void migrate(androidx.sqlite.db.SupportSQLiteDatabase db) {
            db.execSQL("CREATE TABLE IF NOT EXISTS catalog_entities (id TEXT NOT NULL, kind TEXT NOT NULL, name TEXT NOT NULL, notes TEXT NOT NULL, favorite INTEGER NOT NULL, createdAt INTEGER NOT NULL, PRIMARY KEY(id))");
            db.execSQL("CREATE TABLE IF NOT EXISTS entity_aliases (entityId TEXT NOT NULL, name TEXT NOT NULL, PRIMARY KEY(entityId,name), FOREIGN KEY(entityId) REFERENCES catalog_entities(id) ON UPDATE NO ACTION ON DELETE CASCADE)");
            db.execSQL("CREATE TABLE IF NOT EXISTS media_entity_links (entityId TEXT NOT NULL, mediaId TEXT NOT NULL, role TEXT NOT NULL, PRIMARY KEY(entityId,mediaId,role), FOREIGN KEY(entityId) REFERENCES catalog_entities(id) ON UPDATE NO ACTION ON DELETE CASCADE, FOREIGN KEY(mediaId) REFERENCES media(id) ON UPDATE NO ACTION ON DELETE CASCADE)");
            db.execSQL("CREATE INDEX IF NOT EXISTS index_media_entity_links_mediaId ON media_entity_links(mediaId)");
            db.execSQL("CREATE TABLE IF NOT EXISTS entity_references (entityId TEXT NOT NULL, provider TEXT NOT NULL, externalId TEXT NOT NULL, url TEXT NOT NULL, PRIMARY KEY(entityId,provider,externalId), FOREIGN KEY(entityId) REFERENCES catalog_entities(id) ON UPDATE NO ACTION ON DELETE CASCADE)");
            db.execSQL("CREATE TABLE IF NOT EXISTS want_items (id TEXT NOT NULL, title TEXT NOT NULL, code TEXT NOT NULL, notes TEXT NOT NULL, entityId TEXT, mediaId TEXT, createdAt INTEGER NOT NULL, PRIMARY KEY(id), FOREIGN KEY(entityId) REFERENCES catalog_entities(id) ON UPDATE NO ACTION ON DELETE SET NULL, FOREIGN KEY(mediaId) REFERENCES media(id) ON UPDATE NO ACTION ON DELETE SET NULL)");
            db.execSQL("CREATE INDEX IF NOT EXISTS index_want_items_entityId ON want_items(entityId)");
            db.execSQL("CREATE INDEX IF NOT EXISTS index_want_items_mediaId ON want_items(mediaId)");
        }
    };
    public static final androidx.room.migration.Migration MIGRATION_6_7 = new androidx.room.migration.Migration(6,7) {
        @Override public void migrate(androidx.sqlite.db.SupportSQLiteDatabase db) {
            db.execSQL("CREATE TABLE IF NOT EXISTS reader_progress (mediaId TEXT NOT NULL, entry TEXT NOT NULL, page INTEGER NOT NULL, scroll INTEGER NOT NULL, updatedAt INTEGER NOT NULL, PRIMARY KEY(mediaId), FOREIGN KEY(mediaId) REFERENCES media(id) ON UPDATE NO ACTION ON DELETE CASCADE)");
        }
    };
    public static final androidx.room.migration.Migration MIGRATION_7_8 = new androidx.room.migration.Migration(7,8) {
        @Override public void migrate(androidx.sqlite.db.SupportSQLiteDatabase db) {
            db.execSQL("CREATE TABLE IF NOT EXISTS catalog_snapshots (id TEXT NOT NULL, label TEXT NOT NULL, payload TEXT NOT NULL, bindings TEXT NOT NULL, importedAt INTEGER NOT NULL, PRIMARY KEY(id))");
        }
    };
    public static final androidx.room.migration.Migration MIGRATION_8_9 = new androidx.room.migration.Migration(8,9) {
        @Override public void migrate(androidx.sqlite.db.SupportSQLiteDatabase db) {
            db.execSQL("ALTER TABLE media ADD COLUMN catalogMetadata TEXT NOT NULL DEFAULT '[]'");
            CatalogMetadata.rebuild(db);
        }
    };
    public static final androidx.room.migration.Migration MIGRATION_9_10 = new androidx.room.migration.Migration(9,10) {
        @Override public void migrate(androidx.sqlite.db.SupportSQLiteDatabase db) {
            db.execSQL("CREATE TABLE IF NOT EXISTS entity_memberships (memberId TEXT NOT NULL, agencyId TEXT NOT NULL, source TEXT NOT NULL, origin TEXT NOT NULL, checkedAt TEXT NOT NULL, confidence REAL NOT NULL, PRIMARY KEY(memberId), FOREIGN KEY(memberId) REFERENCES catalog_entities(id) ON UPDATE NO ACTION ON DELETE CASCADE, FOREIGN KEY(agencyId) REFERENCES catalog_entities(id) ON UPDATE NO ACTION ON DELETE CASCADE)");
            db.execSQL("CREATE INDEX IF NOT EXISTS index_entity_memberships_agencyId ON entity_memberships(agencyId)");
        }
    };
    public static final androidx.room.migration.Migration MIGRATION_10_11 = new androidx.room.migration.Migration(10,11) {
        @Override public void migrate(androidx.sqlite.db.SupportSQLiteDatabase db) {
            db.execSQL("ALTER TABLE want_items ADD COLUMN state TEXT NOT NULL DEFAULT 'wanted'");
            db.execSQL("ALTER TABLE want_items ADD COLUMN releaseDate TEXT NOT NULL DEFAULT ''");
            db.execSQL("ALTER TABLE want_items ADD COLUMN origin TEXT NOT NULL DEFAULT 'manual'");
            db.execSQL("ALTER TABLE want_items ADD COLUMN source TEXT NOT NULL DEFAULT ''");
            db.execSQL("ALTER TABLE want_items ADD COLUMN publicationId TEXT");
            db.execSQL("ALTER TABLE want_items ADD COLUMN searchCount INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE want_items ADD COLUMN lastSearchAt TEXT NOT NULL DEFAULT ''");
            db.execSQL("ALTER TABLE want_items ADD COLUMN lastSearchOutcome TEXT NOT NULL DEFAULT ''");
            db.execSQL("ALTER TABLE want_items ADD COLUMN lastSearchNote TEXT NOT NULL DEFAULT ''");
            db.execSQL("ALTER TABLE want_items ADD COLUMN acquiredAt TEXT NOT NULL DEFAULT ''");
            db.execSQL("ALTER TABLE want_items ADD COLUMN acquiredBatch TEXT NOT NULL DEFAULT ''");
            db.execSQL("ALTER TABLE want_items ADD COLUMN priorState TEXT NOT NULL DEFAULT 'wanted'");
            db.execSQL("ALTER TABLE want_items ADD COLUMN updatedAt INTEGER NOT NULL DEFAULT 0");
            db.execSQL("UPDATE want_items SET state=CASE WHEN mediaId IS NULL THEN 'wanted' ELSE 'acquired' END, updatedAt=createdAt");
            db.execSQL("CREATE TABLE IF NOT EXISTS publications (id TEXT NOT NULL, title TEXT NOT NULL, provider TEXT NOT NULL, sourceRef TEXT NOT NULL, sourceLabel TEXT NOT NULL, externalId TEXT NOT NULL, url TEXT NOT NULL, publishedAt TEXT NOT NULL, precision TEXT NOT NULL, semantics TEXT NOT NULL, releaseKey TEXT NOT NULL, variant TEXT NOT NULL, variantLabel TEXT NOT NULL, status TEXT NOT NULL, origin TEXT NOT NULL, notes TEXT NOT NULL, entityId TEXT, mediaId TEXT, createdAt INTEGER NOT NULL, PRIMARY KEY(id), FOREIGN KEY(entityId) REFERENCES catalog_entities(id) ON UPDATE NO ACTION ON DELETE SET NULL, FOREIGN KEY(mediaId) REFERENCES media(id) ON UPDATE NO ACTION ON DELETE SET NULL)");
            db.execSQL("CREATE INDEX IF NOT EXISTS index_publications_entityId ON publications(entityId)");
            db.execSQL("CREATE INDEX IF NOT EXISTS index_publications_mediaId ON publications(mediaId)");
        }
    };
    public static final androidx.room.migration.Migration MIGRATION_11_12 = new androidx.room.migration.Migration(11,12) {
        @Override public void migrate(androidx.sqlite.db.SupportSQLiteDatabase db) {
            db.execSQL("CREATE TABLE IF NOT EXISTS follow_sources (id TEXT NOT NULL, provider TEXT NOT NULL, ref TEXT NOT NULL, label TEXT NOT NULL, cachedPage TEXT NOT NULL, pageUrls TEXT NOT NULL, lastError TEXT NOT NULL, etag TEXT NOT NULL, modified TEXT NOT NULL, entityId TEXT, paused INTEGER NOT NULL, revision INTEGER NOT NULL, nextPage INTEGER NOT NULL, cachePage INTEGER NOT NULL, checkedAt INTEGER NOT NULL, cooldownUntil INTEGER NOT NULL, PRIMARY KEY(id), FOREIGN KEY(entityId) REFERENCES catalog_entities(id) ON UPDATE NO ACTION ON DELETE SET NULL)");
            db.execSQL("CREATE INDEX IF NOT EXISTS index_follow_sources_entityId ON follow_sources(entityId)");
            db.execSQL("CREATE TABLE IF NOT EXISTS publication_content (publicationId TEXT NOT NULL, sourceId TEXT, text TEXT NOT NULL, attachments TEXT NOT NULL, type TEXT NOT NULL, partial INTEGER NOT NULL, checkedAt INTEGER NOT NULL, PRIMARY KEY(publicationId), FOREIGN KEY(publicationId) REFERENCES publications(id) ON UPDATE NO ACTION ON DELETE CASCADE, FOREIGN KEY(sourceId) REFERENCES follow_sources(id) ON UPDATE NO ACTION ON DELETE SET NULL)");
            db.execSQL("CREATE INDEX IF NOT EXISTS index_publication_content_sourceId ON publication_content(sourceId)");
        }
    };
    public static final androidx.room.migration.Migration MIGRATION_12_13 = new androidx.room.migration.Migration(12,13) {
        @Override public void migrate(androidx.sqlite.db.SupportSQLiteDatabase db) {
            db.execSQL("CREATE TABLE IF NOT EXISTS usage_sessions (id TEXT NOT NULL, mediaId TEXT NOT NULL, kind TEXT NOT NULL, title TEXT NOT NULL, searchTitle TEXT NOT NULL, startedAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL, position INTEGER NOT NULL, duration INTEGER NOT NULL, entry TEXT NOT NULL, page INTEGER NOT NULL, scroll INTEGER NOT NULL, status TEXT NOT NULL, completed INTEGER NOT NULL, PRIMARY KEY(id), FOREIGN KEY(mediaId) REFERENCES media(id) ON UPDATE NO ACTION ON DELETE CASCADE)");
            db.execSQL("CREATE INDEX IF NOT EXISTS index_usage_sessions_mediaId ON usage_sessions(mediaId)");
            db.execSQL("CREATE INDEX IF NOT EXISTS index_usage_sessions_startedAt_id ON usage_sessions(startedAt,id)");
        }
    };
    public static LibraryDatabase get(Context context) {
        if (instance == null) synchronized (LibraryDatabase.class) {
            if (instance == null) instance = Room.databaseBuilder(context.getApplicationContext(),
                LibraryDatabase.class, "peach-local.db").addMigrations(MIGRATION_1_2,MIGRATION_2_3,MIGRATION_3_4,MIGRATION_4_5,MIGRATION_5_6,MIGRATION_6_7,MIGRATION_7_8,MIGRATION_8_9,MIGRATION_9_10,MIGRATION_10_11,MIGRATION_11_12,MIGRATION_12_13).build();
        }
        return instance;
    }
}
