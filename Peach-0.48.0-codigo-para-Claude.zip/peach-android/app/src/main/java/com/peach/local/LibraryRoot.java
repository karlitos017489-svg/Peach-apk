package com.peach.local;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "roots")
public class LibraryRoot {
    @PrimaryKey @NonNull public String uri = "";
    @NonNull public String label = "";
    public long generation = 1;
    public int state = 1; // 0 complete, 1 pending, 2 provider error.
    public int directories;
    public int warnings;
}
