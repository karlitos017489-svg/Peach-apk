package com.peach.local;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

public final class LibraryView {
    private LibraryView() {}
    public static boolean inFolder(MediaEntry entry,String root,String folder) {
        return root.isEmpty() || entry.root.equals(root) &&
            (folder.isEmpty() || entry.folder.equals(folder) || entry.folder.startsWith(folder+" / "));
    }
    public static List<String> children(List<MediaEntry> entries,String root,String folder) {
        var names=new TreeSet<String>(String.CASE_INSENSITIVE_ORDER.thenComparing(Comparator.naturalOrder()));
        String prefix=folder.isEmpty()?"":folder+" / ";
        for (MediaEntry entry:entries) if (entry.root.equals(root) && entry.folder.startsWith(prefix)) {
            String rest=entry.folder.substring(prefix.length());
            if (!rest.isEmpty()) names.add(rest.split(" / ",2)[0]);
        }
        return new ArrayList<>(names);
    }
    public static List<MediaEntry> select(List<MediaEntry> entries,String query,int filter,String root,
            String folder,String playlist,List<PlaylistItem> membership,int order) {
        return select(entries,query,filter,root,folder,playlist,membership,order,"");
    }
    public static List<MediaEntry> select(List<MediaEntry> entries,String query,int filter,String root,
            String folder,String playlist,List<PlaylistItem> membership,int order,String type) {
        return select(entries,query,filter,root,folder,playlist,membership,order,type,java.util.Set.of());
    }
    public static List<MediaEntry> select(List<MediaEntry> entries,String query,int filter,String root,
            String folder,String playlist,List<PlaylistItem> membership,int order,String type,java.util.Set<String> reading) {
        Map<String,Integer> positions=new HashMap<>();
        for (PlaylistItem item:membership) if (item.playlistId.equals(playlist)) positions.put(item.mediaId,item.position);
        List<MediaEntry> result=new ArrayList<>();
        for (MediaEntry entry:entries) if ((type.isEmpty() || type.equals(entry.mediaType)) && MediaRules.matches(entry,query,filter==3?0:filter) &&
                (filter!=3 || entry.position>0 || reading.contains(entry.id)) && inFolder(entry,root,folder)
                && (playlist.isEmpty() || positions.containsKey(entry.id))) result.add(entry);
        Comparator<MediaEntry> title=Comparator.comparing(MediaEntry::displayTitle,String.CASE_INSENSITIVE_ORDER)
            .thenComparing(m->m.id);
        Comparator<MediaEntry> comparator=switch(order) {
            case 1 -> title.reversed();
            case 2 -> Comparator.comparingLong((MediaEntry m)->m.addedAt).reversed().thenComparing(title);
            case 3 -> Comparator.comparingLong((MediaEntry m)->m.lastPlayed).reversed().thenComparing(title);
            case 4 -> playlist.isEmpty()?title:Comparator.comparingInt((MediaEntry m)->positions.get(m.id)).thenComparing(title);
            default -> title;
        };
        result.sort(comparator);return result;
    }
}
