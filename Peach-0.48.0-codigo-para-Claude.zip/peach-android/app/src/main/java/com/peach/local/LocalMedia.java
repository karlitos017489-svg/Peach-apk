package com.peach.local;

import android.content.ContentResolver;
import android.net.Uri;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Small bounded header check. An extension is not a codec or integrity check. */
final class LocalMedia {
    record Format(String extension,String kind) {}
    private LocalMedia() {}
    static Format inspect(InputStream stream)throws IOException {
        try(InputStream in=stream){if(in==null)throw new IOException("Archivo inaccesible.");byte[] b=new byte[4096];int total=0,n;while(total<b.length && (n=in.read(b,total,b.length-total))>0)total+=n;return header(Arrays.copyOf(b,total));}
    }
    static Format inspect(File file)throws IOException{return inspect(new FileInputStream(file));}
    static Format inspect(ContentResolver resolver,Uri uri)throws IOException {
        if(!SourceFiles.local(uri))throw new IOException("Elige un archivo local autorizado.");
        return inspect(resolver.openInputStream(uri));
    }
    static Format header(byte[] b)throws IOException {
        if(b.length==0)throw new IOException("El archivo está vacío (0 bytes). Debe descargarse de nuevo; no contiene video o imagen.");
        if(starts(b,"GIF87a")||starts(b,"GIF89a"))return new Format("gif","image");
        if(b.length>=8&&(b[0]&255)==137&&starts(Arrays.copyOfRange(b,1,b.length),"PNG\r\n\032\n"))return new Format("png","image");
        if(b.length>=3&&(b[0]&255)==255&&(b[1]&255)==216&&(b[2]&255)==255)return new Format("jpg","image");
        if(b.length>=12&&starts(b,"RIFF")&&new String(b,8,4,StandardCharsets.US_ASCII).equals("WEBP"))return new Format("webp","image");
        if(b.length>=12&&new String(b,4,4,StandardCharsets.US_ASCII).equals("ftyp"))return new Format(new String(b,8,4,StandardCharsets.US_ASCII).equals("qt  ")?"mov":"mp4","video");
        if(b.length>=4&&(b[0]&255)==26&&(b[1]&255)==69&&(b[2]&255)==223&&(b[3]&255)==163)return new Format(new String(b,StandardCharsets.ISO_8859_1).contains("webm")?"webm":"mkv","video");
        String text=new String(b,StandardCharsets.UTF_8).stripLeading().toLowerCase(java.util.Locale.ROOT);
        if(text.startsWith("<!doctype html")||text.startsWith("<html")||text.startsWith("<head")||text.startsWith("<body"))throw new IOException("Se recibió una página web, no un archivo multimedia. No se guardó como video.");
        return new Format("","");
    }
    static boolean starts(byte[] b,String s){byte[] p=s.getBytes(StandardCharsets.US_ASCII);if(b.length<p.length)return false;for(int i=0;i<p.length;i++)if(b[i]!=p[i])return false;return true;}
    static String name(String original,Format actual){
        if(actual.extension().isEmpty())return original;
        return (MediaRules.extension(original).isEmpty()?original:MediaRules.stem(original))+"."+actual.extension();
    }
}
