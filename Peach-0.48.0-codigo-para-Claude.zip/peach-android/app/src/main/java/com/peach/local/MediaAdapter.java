package com.peach.local;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import java.util.function.Consumer;

public final class MediaAdapter extends ListAdapter<MediaEntry,MediaAdapter.Holder> {
    private final Consumer<MediaEntry> play, detail;
    public MediaAdapter(Consumer<MediaEntry> play,Consumer<MediaEntry> detail) {
        super(new DiffUtil.ItemCallback<>() {
            @Override public boolean areItemsTheSame(@NonNull MediaEntry a,@NonNull MediaEntry b) { return a.id.equals(b.id); }
            @Override public boolean areContentsTheSame(@NonNull MediaEntry a,@NonNull MediaEntry b) {
                return a.displayTitle().equals(b.displayTitle()) && a.displayTags().equals(b.displayTags()) && a.position==b.position && a.duration==b.duration &&
                    a.favorite==b.favorite && a.watched==b.watched && a.missing==b.missing &&
                    a.modified==b.modified && a.poster.equals(b.poster) && a.bytes==b.bytes &&
                    a.nfoDetails.equals(b.nfoDetails) && a.catalogMetadata.equals(b.catalogMetadata) && a.plot.equals(b.plot) && a.year.equals(b.year) &&
                    a.studio.equals(b.studio) && a.actors.equals(b.actors) && a.folder.equals(b.folder) && a.name.equals(b.name) && a.mediaType.equals(b.mediaType);
            }
        });
        this.play=play; this.detail=detail;
        setStateRestorationPolicy(RecyclerView.Adapter.StateRestorationPolicy.PREVENT_WHEN_EMPTY);
    }
    @Override public int getItemViewType(int position){return 0;}
    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent,int type) {
        return new Holder(LayoutInflater.from(parent.getContext()).inflate(UiAppearance.prefs(parent.getContext()).getInt("density",1)==3?R.layout.media_row:R.layout.media_card,parent,false));
    }
    @Override public void onBindViewHolder(@NonNull Holder holder,int position) {
        MediaEntry m=getItem(position);
        android.content.Context context=holder.itemView.getContext();boolean list=UiAppearance.prefs(context).getInt("density",1)==3;
        holder.image.getLayoutParams().height=UiAppearance.dp(context,list?76:UiAppearance.prefs(context).getInt("density",1)==0?124:180);
        holder.itemView.setBackgroundColor(android.graphics.Color.TRANSPARENT);UiAppearance.polish(holder.itemView);holder.image.setBackground(UiAppearance.rounded(context,UiAppearance.surface(context),16));holder.image.setClipToOutline(true);holder.info.setTextColor(UiAppearance.secondary(context));PeachDesign.iconButton((android.widget.Button)holder.details,R.drawable.ic_ui_more,"Detalles de "+m.displayTitle());
        holder.title.setText(m.favorite?holder.itemView.getContext().getString(R.string.favorite_title,m.displayTitle()):m.displayTitle());
        String size=android.text.format.Formatter.formatShortFileSize(holder.itemView.getContext(),m.bytes);
        holder.info.setText(m.missing?"Archivo no disponible":
            (DocumentRules.readable(m.name)?DocumentRules.label(m.name):MediaRules.label(m.mediaType))+" · "+size+" · "+(DocumentRules.readable(m.name)?m.watched?"Leído":"Abrir lectura":!MediaRules.catalogNotice(m).isEmpty()?"Solo catálogo":
                m.watched?"Visto / escuchado":m.position>0?"Continuar":"Sin ver / escuchar")+(!m.displayYear().isEmpty()?" · "+m.displayYear():""));
        holder.progress.setProgress(m.duration>0?(int)Math.min(1000,m.position*1000/m.duration):0);
        Thumbnails.load(holder.itemView.getContext(),m,holder.image);
        holder.itemView.setContentDescription(m.displayTitle()+". "+holder.info.getText()+". Mantén pulsado para ver detalles.");
        holder.itemView.setOnClickListener(v -> play.accept(m));
        holder.itemView.setOnLongClickListener(v -> { detail.accept(m); return true; });
        holder.details.setContentDescription("Detalles de "+m.displayTitle());
        holder.details.setOnClickListener(v->detail.accept(m));
    }
    static final class Holder extends RecyclerView.ViewHolder {
        final TextView title,info; final ImageView image; final ProgressBar progress;final View details;
        Holder(View view) {
            super(view); title=view.findViewById(R.id.title); info=view.findViewById(R.id.info);
            image=view.findViewById(R.id.thumbnail); progress=view.findViewById(R.id.progress);
            details=view.findViewById(R.id.details_button);
        }
    }
}
