package com.peach.local;

import android.content.Context;
import android.graphics.Typeface;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.StyleSpan;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.Locale;

/** Native, selectable and scrollable facts; NFO runtime never replaces measured playback duration. */
public final class MediaDetailsView {
    private MediaDetailsView() {}
    public static View create(Context context,MediaEntry media) {
        ScrollView scroll=new ScrollView(context);
        TextView text=new TextView(context);text.setId(R.id.detail_text);
        int padding=(int)(24*context.getResources().getDisplayMetrics().density);
        text.setPadding(padding,padding,padding,padding);text.setTextSize(16);
        text.setTextIsSelectable(true);
        text.setText(describe(media,android.text.format.Formatter.formatShortFileSize(context,media.bytes)));
        scroll.addView(text);return scroll;
    }
    static CharSequence describe(MediaEntry media,String size) {
        SpannableStringBuilder text=new SpannableStringBuilder();
        append(text,"Título",media.displayTitle());
        append(text,"Medio",MediaRules.label(media.mediaType));
        append(text,"Compatibilidad",MediaRules.catalogNotice(media));
        append(text,"Año",media.displayYear());append(text,"Estudio",media.displayStudio());
        for (NfoDetails.Field field:NfoDetails.FIELDS) append(text,field.label(),media.details().getOrDefault(field.key(),""));
        append(text,"Reparto",media.displayActors());append(text,"Etiquetas",media.displayTags());
        append(text,"Sinopsis",media.plot);
        if (media.userTitle!=null) append(text,"Título de origen",media.title);
        if (media.userTags!=null) append(text,"Etiquetas de origen",media.tags);
        if(!media.catalog().sources.isEmpty()) {
            append(text,"Datos del catálogo","Campos de consulta independientes de los NFO y tus ediciones. Los nombres de los filtros reúnen ambos orígenes; las etiquetas personales tienen prioridad en el filtro de etiquetas.");
            if(!media.catalog().conflicts().isEmpty())append(text,"Diferencias entre catálogos",String.join(", ",media.catalog().conflicts().stream().map(MediaDetailsView::catalogLabel).toList())+". No se elige una fuente automáticamente para completar esos campos.");
            for(CatalogMetadata.Source source:media.catalog().sources) {
                append(text,"Catálogo · "+source.label(),"Asset "+source.asset()+"\n"+source.path());
                if(source.partial()){append(text,"Índice resumido","Este registro excede el índice de consulta. Revisa sus datos completos en Catálogo de Peach original.");continue;}
                for(var field:source.fields().entrySet())append(text,catalogLabel(field.getKey()),field.getValue());
                for(var terms:source.terms().entrySet())append(text,CatalogIndex.label(terms.getKey()),String.join(" · ",terms.getValue()));
            }
        }
        append(text,"Archivo",media.name);append(text,"Carpeta",media.folder);append(text,"Tamaño",size);
        if(MediaRules.VIDEO.equals(media.mediaType))append(text,"Versiones y partes",VersionIndex.describe(media));
        if (media.duration>0) append(text,"Duración de reproducción",time(media.duration));
        if (media.position>0) append(text,"Continuar desde",time(media.position));
        append(text,"Estado",(media.missing?"No disponible · revisa la carpeta":"En biblioteca")+
            (media.favorite?" · Favorito":"")+(media.watched?" · Visto":" · Sin ver"));
        return text;
    }
    private static void append(SpannableStringBuilder text,String label,String value) {
        if (value.isEmpty()) return;
        int start=text.length();text.append(label).append('\n');
        text.setSpan(new StyleSpan(Typeface.BOLD),start,start+label.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        text.append(value).append("\n\n");
    }
    private static String catalogLabel(String key){return switch(key){case "title"->"Título de catálogo";case "originalTitle"->"Título original";case "code"->"Código";case "studio"->"Estudio";case "series"->"Serie";case "creator"->"Creador";case "premiered"->"Fecha de publicación";case "year"->"Año";case "catalogDurationSeconds"->"Duración del catálogo (segundos)";case "region"->"Región";case "width"->"Ancho registrado";case "height"->"Alto registrado";default->key;};}
    private static String time(long millis) {
        long seconds=Math.max(0,millis/1000),hours=seconds/3600;
        return hours>0?String.format(Locale.ROOT,"%d:%02d:%02d",hours,seconds/60%60,seconds%60):
            String.format(Locale.ROOT,"%d:%02d",seconds/60,seconds%60);
    }
}
