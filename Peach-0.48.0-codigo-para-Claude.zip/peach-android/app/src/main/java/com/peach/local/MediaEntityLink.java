package com.peach.local;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;

/** Explicit user links; imported assertions are derived separately from NFO terms. */
@Entity(tableName="media_entity_links",primaryKeys={"entityId","mediaId","role"},foreignKeys={
    @ForeignKey(entity=CatalogEntity.class,parentColumns="id",childColumns="entityId",onDelete=ForeignKey.CASCADE),
    @ForeignKey(entity=MediaEntry.class,parentColumns="id",childColumns="mediaId",onDelete=ForeignKey.CASCADE)},indices={@Index("mediaId")})
public class MediaEntityLink {
    @NonNull public String entityId="";
    @NonNull public String mediaId="";
    @NonNull public String role="";
}
