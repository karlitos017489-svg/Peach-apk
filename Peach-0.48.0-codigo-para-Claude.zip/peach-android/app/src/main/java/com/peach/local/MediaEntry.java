package com.peach.local;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "media")
public class MediaEntry {
    @PrimaryKey @NonNull public String id = "";
    @NonNull public String uri = "";
    @NonNull public String root = "";
    @NonNull public String name = "";
    @NonNull public String folder = "";
    @NonNull public String title = "";
    @NonNull public String tags = "";
    @NonNull public String actors = "";
    @NonNull public String studio = "";
    @NonNull public String plot = "";
    @NonNull public String year = "";
    @NonNull public String poster = "";
    @NonNull public String subtitles = "[]";
    public long bytes;
    public long modified;
    public long generation;
    public long position;
    public long duration;
    public long lastPlayed;
    public long playCount;
    public boolean favorite;
    public boolean watched;
    public boolean missing;
    @androidx.annotation.Nullable public String userTitle;
    @androidx.annotation.Nullable public String userTags;
    @androidx.room.ColumnInfo(defaultValue = "0") public long addedAt = System.currentTimeMillis();
    @NonNull @androidx.room.ColumnInfo(defaultValue = "'{}'") public String nfoDetails = "{}";
    @NonNull @androidx.room.ColumnInfo(defaultValue = "'video'") public String mediaType = MediaRules.VIDEO;
    @NonNull @androidx.room.ColumnInfo(defaultValue = "'[]'") public String catalogMetadata="[]";
    @androidx.room.Ignore private String cachedNfo;
    @androidx.room.Ignore private String cachedCatalog;
    @androidx.room.Ignore private CatalogMetadata.Projection catalog=CatalogMetadata.decode("[]");
    @androidx.room.Ignore private java.util.Map<String,String> localDetails=java.util.Map.of();
    @androidx.room.Ignore private java.util.Map<String,String> cachedDetails = java.util.Map.of();
    @androidx.room.Ignore private String cachedSearch = "";
    @androidx.room.Ignore private java.util.Map<String,java.util.List<String>> cachedTerms=java.util.Map.of();

    public java.util.Map<String,String> details() {
        if (!nfoDetails.equals(cachedNfo) || !catalogMetadata.equals(cachedCatalog)) {
            localDetails=NfoDetails.decode(nfoDetails);catalog=CatalogMetadata.decode(catalogMetadata);
            java.util.Map<String,String> merged=new java.util.LinkedHashMap<>(localDetails);
            for(NfoDetails.Field field:NfoDetails.FIELDS){String value=catalog.unique(field.key());if(!value.isEmpty())merged.putIfAbsent(field.key(),value);}
            cachedDetails=java.util.Collections.unmodifiableMap(merged);
            cachedTerms=NfoDetails.terms(nfoDetails);
            cachedSearch=String.join(" ",localDetails.values())+" "+catalog.search();
            cachedNfo=nfoDetails;cachedCatalog=catalogMetadata;
        }
        return cachedDetails;
    }
    public String metadataSearch() { details();return cachedSearch; }
    public java.util.Map<String,java.util.List<String>> importedTerms() {details();return cachedTerms;}
    public java.util.Map<String,String> localDetails(){details();return localDetails;}
    public CatalogMetadata.Projection catalog(){details();return catalog;}

    public String displayTitle() {
        if(userTitle!=null)return userTitle;String imported=catalog().unique("title");
        return !imported.isEmpty() && (title.isBlank() || title.equals(MediaRules.stem(name)) && nfoDetails.equals("{}"))?imported:title;
    }
    public String displayTags() { return userTags==null ? String.join(", ",CatalogIndex.values(this,"tags")) : userTags; }
    public String displayYear(){return year.isBlank()?catalog().unique("year"):year;}
    public String displayStudio(){return studio.isBlank()?catalog().unique("studio"):studio;}
    public String displayActors(){return actors.isBlank()?String.join(", ",catalog().values("actors")):actors;}
}
