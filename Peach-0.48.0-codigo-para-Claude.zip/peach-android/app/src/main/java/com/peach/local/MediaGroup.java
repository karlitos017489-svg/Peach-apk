package com.peach.local;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/** Explicit user organization; never used as a document identity. */
@Entity(tableName="media_groups")
public class MediaGroup {
    @PrimaryKey @NonNull public String id="";
    @NonNull public String name="";
    public long createdAt;
}
