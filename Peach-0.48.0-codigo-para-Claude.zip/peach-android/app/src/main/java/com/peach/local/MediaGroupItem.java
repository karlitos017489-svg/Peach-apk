package com.peach.local;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;

@Entity(tableName="media_group_items",primaryKeys={"groupId","mediaId"},
    foreignKeys={
        @ForeignKey(entity=MediaGroup.class,parentColumns="id",childColumns="groupId",onDelete=ForeignKey.CASCADE),
        @ForeignKey(entity=MediaEntry.class,parentColumns="id",childColumns="mediaId",onDelete=ForeignKey.CASCADE)
    },indices={@Index("mediaId")})
public class MediaGroupItem {
    @NonNull public String groupId="";
    @NonNull public String mediaId="";
}
