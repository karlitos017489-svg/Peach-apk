package com.peach.local;

import java.util.ArrayList;
import java.util.List;

/** AV playback and image viewing use separate queues, preserving membership order and global IDs. */
public final class MediaQueues {
    private MediaQueues() {}
    public static List<MediaEntry> select(List<MediaEntry> candidates,MediaEntry selected,boolean images) {
        if(images?!MediaRules.IMAGE.equals(selected.mediaType):!MediaRules.playable(selected))return List.of();
        List<MediaEntry> result=new ArrayList<>();
        for (MediaEntry m:candidates) if ((images?MediaRules.IMAGE.equals(m.mediaType):MediaRules.playable(m)) && (!m.missing || m.id.equals(selected.id))) result.add(m);
        if (images==MediaRules.IMAGE.equals(selected.mediaType) && result.stream().noneMatch(m->m.id.equals(selected.id))) result.add(selected);
        return result;
    }
}
