package com.peach.local;

import java.io.IOException;
import java.net.*;
import java.util.Locale;
import java.util.Set;

/** Transient HTTPS delivery handoff. It never admits a new stored source/media URL. */
final class MediaRedirects {
    interface Resolver {InetAddress[] resolve(String host)throws IOException;}
    private MediaRedirects() {}
    static boolean videoSource(String raw){try{return Set.of("rule34video.com","boomio-cdn.com").contains(SourceHttp.https(raw).getHost().toLowerCase(Locale.ROOT))&&WebSourceUrls.downloadable(raw);}catch(IllegalArgumentException e){return false;}}
    static String host(String raw){try{return SourceHttp.https(raw).getHost().toLowerCase(Locale.ROOT);}catch(Exception e){return "destino no válido";}}
    static void check(String original,String next,Resolver resolver,SourceHttp.Token token)throws IOException {
        token.check();if(!videoSource(original))throw new IOException("El origen no admite este traspaso de descarga.");
        URI uri;try{uri=SourceHttp.https(next);}catch(IllegalArgumentException e){throw new IOException("La descarga se redirigió a una dirección que no es HTTPS válido.");}
        String host=uri.getHost().toLowerCase(Locale.ROOT);
        if(host.length()>253||!host.matches("[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?")||!host.contains(".")||host.equals("localhost")||host.endsWith(".localhost")||host.endsWith(".local")||host.endsWith(".internal"))throw new IOException("Destino de descarga no público: "+host+".");
        InetAddress[] addresses;try{addresses=resolver.resolve(host);}catch(IOException e){throw new IOException("No se pudo resolver el servidor de descarga: "+host+".");}
        token.check();if(addresses==null||addresses.length==0)throw new IOException("El servidor de descarga no tiene una dirección pública: "+host+".");
        for(InetAddress address:addresses)if(!publicAddress(address))throw new IOException("Se bloqueó un destino de descarga local o reservado: "+host+".");
    }
    static boolean publicAddress(InetAddress address){
        if(address==null||address.isAnyLocalAddress()||address.isLoopbackAddress()||address.isLinkLocalAddress()||address.isSiteLocalAddress()||address.isMulticastAddress())return false;
        byte[] b=address.getAddress();
        if(b.length==4){int a=b[0]&255,c=b[1]&255,d=b[2]&255;
            return a!=0&&a!=10&&a!=127&&a<224&&!(a==100&&(c&192)==64)&&!(a==169&&c==254)&&!(a==172&&c>=16&&c<=31)&&!(a==192&&(c==168||c==0&&(d==0||d==2)))&&!(a==198&&(c==18||c==19||c==51&&d==100))&&!(a==203&&c==0&&d==113);
        }
        if(b.length==16){if((b[0]&254)==252)return false;if((b[0]&255)==32&&(b[1]&255)==1&&(b[2]&255)==13&&(b[3]&255)==184)return false;
            // The standard NAT64 prefix may encode IPv4; apply the same IPv4 checks.
            boolean nat64=(b[0]&255)==0&&(b[1]&255)==100&&(b[2]&255)==255&&(b[3]&255)==155;for(int i=4;i<12;i++)nat64&=b[i]==0;
            if(nat64)try{return publicAddress(InetAddress.getByAddress(java.util.Arrays.copyOfRange(b,12,16)));}catch(UnknownHostException impossible){return false;}
            // Current global unicast only; exclude IETF protocol/transition and documentation ranges.
            if((b[0]&224)!=32)return false;
            int first=b[0]&255,second=b[1]&255,third=b[2]&255;
            if(first==32&&second==1&&third<2||first==32&&second==2||first==63&&(second==254||second==255))return false;
            return true;
        }return false;
    }
}
