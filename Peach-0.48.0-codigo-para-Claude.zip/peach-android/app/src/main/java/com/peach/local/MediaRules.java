package com.peach.local;

import java.util.Locale;
import java.util.Set;

/** Local filename rules. Media3 and device codecs decide actual playback support. */
public final class MediaRules {
    public static final String VIDEO="video",IMAGE="image",AUDIO="audio",ARCHIVE="archive",OTHER="other";
    private static final Set<String> VIDEOS = Set.of("mp4", "m4v", "mkv", "webm", "mov",
        "avi", "ts", "m2ts", "mpg", "mpeg", "wmv", "flv", "3gp");
    private static final Set<String> SUBTITLES = Set.of("srt", "vtt", "ass", "ssa");
    private static final Set<String> IMAGES=Set.of("jpg","jpeg","png","webp","bmp","gif","heic","heif");
    private static final Set<String> AUDIO_FILES=Set.of("mp3","m4a","aac","wav","flac","ogg","oga","opus","amr");
    private static final Set<String> ARCHIVES=Set.of("zip","rar","7z","tar","gz","tgz","cbz","cbr");
    private static final Set<String> VIDEO_REFERENCES=Set.of("iso","strm","rmvb");
    private static final Set<String> TOKENS = Set.of("es", "spa", "es-mx", "es-419", "en", "eng",
        "ja", "jpn", "zh", "chs", "cht", "forced", "sdh", "default", "lat", "latino");
    private MediaRules() {}
    public static String extension(String name) {
        int dot = name.lastIndexOf('.');
        return dot < 0 ? "" : name.substring(dot + 1).toLowerCase(Locale.ROOT);
    }
    public static String stem(String name) {
        int dot = name.lastIndexOf('.');
        return dot <= 0 ? name : name.substring(0, dot);
    }
    public static boolean isVideo(String name) { return VIDEOS.contains(extension(name)) || VIDEO_REFERENCES.contains(extension(name)); }
    public static boolean isImage(String name) { return IMAGES.contains(extension(name)); }
    public static boolean isAudio(String name) { return AUDIO_FILES.contains(extension(name)); }
    public static String type(String name) {return isVideo(name)?VIDEO:isImage(name)?IMAGE:isAudio(name)?AUDIO:ARCHIVES.contains(extension(name))?ARCHIVE:OTHER;}
    public static String label(String type) {return switch(type) {case IMAGE->"Imagen";case AUDIO->"Audio";case ARCHIVE->"Comprimido";case OTHER->"Otro archivo";default->"Video";};}
    public static boolean playable(MediaEntry media) {
        return AUDIO.equals(media.mediaType) || VIDEO.equals(media.mediaType) && !VIDEO_REFERENCES.contains(extension(media.name));
    }
    public static boolean sidecar(String name) {
        return Set.of("nfo","tbn","srt","vtt","ass","ssa","sub","idx").contains(extension(name)) ||
            name.toLowerCase(Locale.ROOT).matches("peach-purge-[a-f0-9]{32}\\.peach-quarantine");
    }
    public static String catalogNotice(MediaEntry media) {
        if(DocumentRules.readable(media.name))return "";
        if(IMAGE.equals(media.mediaType) || playable(media))return "";
        return switch(extension(media.name)) {
            case "strm"->"Referencia STRM catalogada. No se abren sus enlaces ni se requiere un servidor.";
            case "iso"->"Imagen de disco catalogada. El montaje y la reproducción de ISO están pendientes.";
            case "rmvb"->"Video catalogado. La reproducción RMVB no está implementada.";
            default->ARCHIVE.equals(media.mediaType)?"Archivo comprimido catalogado. Este formato todavía no tiene lector integrado; ZIP/CBZ, TAR, GZIP, 7z y RAR/CBR compatibles disponen de lectura local compatible.":
                "Documento catalogado. Este tipo de archivo no tiene visor integrado.";
        };
    }
    public static boolean isSubtitle(String name) { return SUBTITLES.contains(extension(name)); }
    public static boolean subtitleMatches(String video, String subtitle) {
        if (!isSubtitle(subtitle)) return false;
        String v = stem(video).toLowerCase(Locale.ROOT), s = stem(subtitle).toLowerCase(Locale.ROOT);
        for (int i = 0; i <= 3; i++) {
            if (v.equals(s)) return true;
            int cut = Math.max(s.lastIndexOf('.'), s.lastIndexOf('_'));
            if (cut < 1 || !TOKENS.contains(s.substring(cut + 1))) return false;
            s = s.substring(0, cut);
        }
        return false;
    }
    public static String subtitleMime(String name) {
        return switch (extension(name)) {
            case "srt" -> "application/x-subrip";
            case "ass", "ssa" -> "text/x-ssa";
            default -> "text/vtt";
        };
    }
    public static boolean watchedByProgress(long position, long duration) {
        return duration > 0 && position >= duration * 0.95;
    }
    public static boolean matches(MediaEntry entry, String search, int filter) {
        if (filter == 1 && !entry.favorite || filter == 2 && entry.watched ||
            filter == 3 && entry.position <= 0 || filter == 4 && !entry.watched) return false;
        String haystack = String.join(" ",entry.displayTitle(),entry.name,entry.displayTags(),entry.actors,entry.studio,entry.folder,
            entry.year,entry.metadataSearch())
            .toLowerCase(Locale.ROOT);
        return haystack.contains(search.trim().toLowerCase(Locale.ROOT));
    }
}
