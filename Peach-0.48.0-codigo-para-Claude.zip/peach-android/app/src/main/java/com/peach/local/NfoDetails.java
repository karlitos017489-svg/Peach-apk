package com.peach.local;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;

/** Imported display/search fields only. Never contains grants or personal playback state. */
public final class NfoDetails {
    public record Field(String key,String label) {}
    public static final List<Field> FIELDS=List.of(
        new Field("kind","Tipo"),new Field("originalTitle","Título original"),
        new Field("tagline","Frase"),new Field("directors","Dirección"),
        new Field("writers","Guion"),new Field("countries","País"),
        new Field("genres","Géneros"),new Field("premiered","Fecha de estreno / emisión"),
        new Field("runtimeMinutes","Duración NFO (minutos)"),new Field("contentRating","Clasificación"),
        new Field("collection","Colección"),new Field("code","Código"),
        new Field("identifiers","Identificadores"),new Field("series","Serie"),
        new Field("season","Temporada"),new Field("episode","Episodio"),
        new Field("artists","Artistas musicales"),new Field("actorRoles","Reparto y personajes"),
        new Field("rating","Valoración NFO"));
    private NfoDetails() {}
    public static String encode(Map<String,String> fields) {
        return encode(fields,Map.of());
    }
    public static String encode(Map<String,String> fields,Map<String,List<String>> terms) {
        JSONObject json=new JSONObject();
        try {
            for (Field field:FIELDS) {
                String value=fields.getOrDefault(field.key(),"");
                if (!value.isBlank()) json.put(field.key(),value);
            }
            if(!terms.isEmpty()) {
                JSONObject catalog=new JSONObject();
                for(var entry:terms.entrySet())catalog.put(entry.getKey(),new org.json.JSONArray(entry.getValue()));
                json.put("_catalog",catalog);
            }
        } catch (org.json.JSONException error) { throw new IllegalArgumentException("Metadatos no válidos",error); }
        return json.toString();
    }
    public static Map<String,String> decode(String raw) {
        Map<String,String> fields=new LinkedHashMap<>();
        try {
            JSONObject json=new JSONObject(raw);
            for (Field field:FIELDS) {
                Object value=json.opt(field.key());
                if (value instanceof String text && !text.isBlank()) fields.put(field.key(),text);
            }
        } catch (org.json.JSONException ignored) { /* Older or malformed cached metadata stays optional. */ }
        return Collections.unmodifiableMap(fields);
    }
    public static Map<String,List<String>> terms(String raw) {
        Map<String,List<String>> result=new LinkedHashMap<>();
        try {
            JSONObject catalog=new JSONObject(raw).optJSONObject("_catalog");
            if(catalog!=null)for(CatalogIndex.Facet facet:CatalogIndex.FACETS) {
                org.json.JSONArray array=catalog.optJSONArray(facet.key());if(array==null)continue;
                java.util.Set<String> values=new java.util.LinkedHashSet<>();
                for(int i=0;i<array.length();i++)if(array.opt(i) instanceof String value && !value.trim().isEmpty())values.add(value.trim());
                result.put(facet.key(),List.copyOf(values));
            }
        } catch(org.json.JSONException ignored) { /* Structured terms are optional in legacy cached rows. */ }
        return Collections.unmodifiableMap(result);
    }
}
