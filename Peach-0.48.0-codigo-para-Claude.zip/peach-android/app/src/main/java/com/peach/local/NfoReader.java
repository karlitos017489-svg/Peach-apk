package com.peach.local;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashSet;
import java.util.LinkedHashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.math.BigDecimal;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

/** Bounded local NFO reader. Never resolves external entities or fetches poster URLs. */
public final class NfoReader {
    public static final int MAX_BYTES = 1024 * 1024;
    private static final int MAX_FIELD_CHARS=16384;
    public record Metadata(String title, String plot, String year, String studio, String actors, String tags,
                           Map<String,String> details,Map<String,List<String>> terms) {}
    private NfoReader() {}
    public static Metadata read(InputStream input) throws Exception {
        var buffer = new java.io.ByteArrayOutputStream();
        byte[] chunk = new byte[8192];
        int count;
        while ((count = input.read(chunk, 0, Math.min(chunk.length, MAX_BYTES + 1 - buffer.size()))) > 0) {
            buffer.write(chunk, 0, count);
            if (buffer.size() > MAX_BYTES) break;
        }
        byte[] raw = buffer.toByteArray();
        if (raw.length > MAX_BYTES) throw new IOException("NFO demasiado grande");
        String declarations = new String(raw, StandardCharsets.ISO_8859_1).replace("\0", "")
            .toUpperCase(java.util.Locale.ROOT);
        if (declarations.contains("<!DOCTYPE") || declarations.contains("<!ENTITY"))
            throw new IOException("NFO con declaraciones no permitidas");
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setExpandEntityReferences(false);
        var builder = factory.newDocumentBuilder();
        builder.setEntityResolver((publicId, systemId) -> { throw new SAXException("Referencia externa"); });
        builder.setErrorHandler(new org.xml.sax.helpers.DefaultHandler() {
            @Override public void fatalError(org.xml.sax.SAXParseException e) throws SAXException { throw e; }
            @Override public void error(org.xml.sax.SAXParseException e) throws SAXException { throw e; }
        });
        Document document = builder.parse(new ByteArrayInputStream(raw));
        Element root = document.getDocumentElement();
        if (!Set.of("movie", "episodedetails", "musicvideo").contains(root.getTagName()))
            throw new IOException("Tipo NFO incompatible");
        Set<String> tags = new LinkedHashSet<>(), actors = new LinkedHashSet<>(), roles=new LinkedHashSet<>();
        for (Element node:children(root,"tag","genre")) tags.add(value(node));
        for (Element actor:children(root,"actor")) {
            String name=text(actor,"name"),role=join(actor,"role");
            if (!name.isEmpty()) {
                actors.add(name);
                if (!role.isEmpty()) roles.add(name+" — "+role);
            }
        }
        tags.remove("");
        Map<String,String> details=new LinkedHashMap<>();
        details.put("kind",switch(root.getTagName()) {case "episodedetails"->"Episodio";case "musicvideo"->"Video musical";default->"Película / video";});
        details.put("originalTitle",text(root,"originaltitle"));
        details.put("tagline",text(root,"tagline"));
        details.put("directors",join(root,"director"));
        details.put("writers",join(root,"credits"));
        details.put("countries",join(root,"country"));
        details.put("genres",join(root,"genre"));
        String premiered=text(root,"premiered","releasedate","aired");
        details.put("premiered",premiered);
        details.put("runtimeMinutes",positiveNumber(text(root,"runtime")));
        details.put("contentRating",text(root,"mpaa"));
        String collection="";
        for (Element set:children(root,"set")) {
            collection=text(set,"name");
            if (collection.isEmpty() && children(set).isEmpty()) collection=value(set);
            if (!collection.isEmpty()) break;
        }
        details.put("collection",collection);
        details.put("code",text(root,"code","num"));
        Set<String> identifiers=new LinkedHashSet<>();
        for (Element id:children(root,"uniqueid")) {
            String identifier=value(id),type=id.getAttribute("type").trim();
            if (identifier.isEmpty()) continue;
            identifiers.add((type.isEmpty()?"ID":type)+": "+identifier);
            if (details.get("code").isEmpty() && Set.of("javboss","jav","javid","dvdid","num","code")
                .contains(type.toLowerCase(java.util.Locale.ROOT))) details.put("code",identifier);
        }
        if (identifiers.isEmpty() && !text(root,"id").isEmpty()) identifiers.add("ID: "+text(root,"id"));
        details.put("identifiers",bounded(String.join(", ",identifiers)));
        details.put("series",text(root,"showtitle"));
        details.put("season",nonNegativeInteger(text(root,"season")));
        details.put("episode",nonNegativeInteger(text(root,"episode")));
        details.put("artists",join(root,"artist"));
        details.put("actorRoles",bounded(String.join(", ",roles)));
        details.put("rating",rating(root));
        details.values().removeIf(String::isEmpty);
        String year=text(root,"year");
        if (year.isEmpty() && premiered.matches("\\d{4}(?:-\\d{2}(?:-\\d{2})?)?")) year=premiered.substring(0,4);
        Map<String,List<String>> terms=new LinkedHashMap<>();
        terms.put("actors",List.copyOf(actors));terms.put("tags",List.copyOf(tags));
        for(String[] field:new String[][]{{"studio","studio"},{"artists","artist"},{"directors","director"},{"genres","genre"}}) {
            Set<String> values=new LinkedHashSet<>();
            for(Element node:children(root,field[1]))if(!value(node).isEmpty())values.add(value(node));
            terms.put(field[0],List.copyOf(values));
        }
        return new Metadata(text(root,"title","localtitle","name"),text(root,"plot","outline"),year,
            join(root,"studio"),bounded(String.join(", ",actors)),bounded(String.join(", ",tags)),
            java.util.Collections.unmodifiableMap(details),java.util.Collections.unmodifiableMap(terms));
    }
    /** Direct children prevent names/plots from actor, set and fileinfo leaking into the movie. */
    private static List<Element> children(Element parent,String... names) {
        List<Element> result=new ArrayList<>();
        Set<String> accepted=new LinkedHashSet<>(List.of(names));
        for (var node=parent.getFirstChild();node!=null;node=node.getNextSibling())
            if (node instanceof Element element && (accepted.isEmpty() || accepted.contains(element.getTagName()))) result.add(element);
        return result;
    }
    private static String bounded(String text) {
        text=text.trim();return text.length()>MAX_FIELD_CHARS?text.substring(0,MAX_FIELD_CHARS)+"…":text;
    }
    private static String value(Element element) { return bounded(element.getTextContent()); }
    private static String text(Element element,String... names) {
        for (String name:names) for (Element child:children(element,name)) {
            String result=value(child);if (!result.isEmpty()) return result;
        }
        return "";
    }
    private static String join(Element element,String... names) {
        Set<String> values=new LinkedHashSet<>();
        for (Element child:children(element,names)) {String v=value(child);if (!v.isEmpty()) values.add(v);}
        return bounded(String.join(", ",values));
    }
    private static String nonNegativeInteger(String raw) {
        try {int value=Integer.parseInt(raw);return value<0?"":Integer.toString(value);}
        catch (NumberFormatException ignored) {return "";}
    }
    private static String positiveNumber(String raw) {
        if (!raw.matches("\\d{1,6}(?:\\.\\d{1,4})?")) return "";
        try {BigDecimal number=new BigDecimal(raw);return number.signum()>0 && number.compareTo(BigDecimal.valueOf(100000))<=0?
            number.stripTrailingZeros().toPlainString():"";}
        catch (NumberFormatException ignored) {return "";}
    }
    private static String rating(Element root) {
        String first="",preferred="";
        for (Element ratings:children(root,"ratings")) for (Element rating:children(ratings,"rating")) {
            String max=rating.getAttribute("max").trim();if (max.isEmpty()) max="10";
            String number=ratingNumber(text(rating,"value"),max);if (number.isEmpty()) continue;
            String name=bounded(rating.getAttribute("name"));
            String label=number+" / "+positiveNumber(max)+(name.isEmpty()?"":" ("+name+")");
            if (first.isEmpty()) first=label;
            if (preferred.isEmpty() && rating.getAttribute("default").equalsIgnoreCase("true")) preferred=label;
        }
        if (!preferred.isEmpty()) return preferred;
        if (!first.isEmpty()) return first;
        String legacy=ratingNumber(text(root,"rating"),"10");
        return legacy.isEmpty()?"":legacy+" / 10";
    }
    private static String ratingNumber(String raw,String max) {
        String ceiling=positiveNumber(max);
        if (!raw.matches("\\d{1,6}(?:\\.\\d{1,4})?") || ceiling.isEmpty()) return "";
        try {BigDecimal number=new BigDecimal(raw);return number.signum()>=0 && number.compareTo(new BigDecimal(ceiling))<=0?
            number.stripTrailingZeros().toPlainString():"";}
        catch (NumberFormatException ignored) {return "";}
    }
}
