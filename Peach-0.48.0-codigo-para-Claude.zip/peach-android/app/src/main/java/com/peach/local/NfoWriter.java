package com.peach.local;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Explicit metadata export; never exports playback state, session keys or source credentials. */
final class NfoWriter {
 private NfoWriter(){}
 static byte[] merge(byte[] old,byte[] fresh)throws Exception{
  NfoReader.read(new ByteArrayInputStream(old));NfoReader.read(new ByteArrayInputStream(fresh));
  var factory=javax.xml.parsers.DocumentBuilderFactory.newInstance();factory.setExpandEntityReferences(false);var builder=factory.newDocumentBuilder();builder.setEntityResolver((p,s)->{throw new org.xml.sax.SAXException("Referencia externa no permitida.");});
  var original=builder.parse(new ByteArrayInputStream(old));var incoming=builder.parse(new ByteArrayInputStream(fresh));var root=original.getDocumentElement();
  if(!root.getTagName().equals(incoming.getDocumentElement().getTagName()))throw new IOException("El tipo NFO cambió. Exporta una copia antes de sustituirlo.");
  Map<String,List<org.w3c.dom.Node>> actors=new HashMap<>();for(var node=root.getFirstChild();node!=null;node=node.getNextSibling())if(node instanceof org.w3c.dom.Element e&&e.getTagName().equals("actor")){var names=e.getElementsByTagName("name");if(names.getLength()>0)actors.computeIfAbsent(names.item(0).getTextContent(),k->new ArrayList<>()).add(node);}
  Set<String> modeled=Set.of("title","plot","year","studio","actor","tag","originaltitle","tagline","premiered","runtime","mpaa","code","showtitle","season","episode","director","credits","country","genre","artist","set");
  for(var node=root.getFirstChild();node!=null;){var next=node.getNextSibling();if(node instanceof org.w3c.dom.Element e&&modeled.contains(e.getTagName()))root.removeChild(node);node=next;}
  for(var node=incoming.getDocumentElement().getFirstChild();node!=null;node=node.getNextSibling()){if(node instanceof org.w3c.dom.Element e&&e.getTagName().equals("actor")){var names=e.getElementsByTagName("name");if(names.getLength()>0&&actors.containsKey(names.item(0).getTextContent())){for(var actor:actors.get(names.item(0).getTextContent()))root.appendChild(actor);continue;}}root.appendChild(original.importNode(node,true));}
  var out=new ByteArrayOutputStream();var transform=javax.xml.transform.TransformerFactory.newInstance().newTransformer();transform.setOutputProperty(javax.xml.transform.OutputKeys.ENCODING,"UTF-8");transform.transform(new javax.xml.transform.dom.DOMSource(original),new javax.xml.transform.stream.StreamResult(out));
  byte[] result=out.toByteArray();if(result.length>NfoReader.MAX_BYTES)throw new IOException("El NFO combinado supera 1 MiB.");return result;
 }
 static byte[] encode(MediaEntry m)throws IOException{
  var d=m.details();String kind=d.getOrDefault("kind","");String root=kind.equals("Episodio")?"episodedetails":kind.equals("Video musical")?"musicvideo":"movie";
  StringBuilder s=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<"+root+">\n");
  tag(s,"title",m.displayTitle());tag(s,"plot",m.plot);tag(s,"year",m.displayYear());
  for(String v:CatalogIndex.values(m,"studio"))tag(s,"studio",v);
  for(String v:CatalogIndex.values(m,"actors")){s.append("<actor>");tag(s,"name",v);s.append("</actor>\n");}
  List<String> tags=m.userTags==null?CatalogIndex.values(m,"tags"):Arrays.asList(m.userTags.split("[,\\n]"));for(String v:tags)tag(s,"tag",v.trim());
  for(String[] pair:new String[][]{{"originalTitle","originaltitle"},{"tagline","tagline"},{"premiered","premiered"},{"runtimeMinutes","runtime"},{"contentRating","mpaa"},{"code","code"},{"series","showtitle"},{"season","season"},{"episode","episode"}})tag(s,pair[1],d.getOrDefault(pair[0],""));
  for(String[] pair:new String[][]{{"directors","director"},{"writers","credits"},{"countries","country"},{"genres","genre"},{"artists","artist"}}){List<String> terms=CatalogIndex.values(m,pair[0]);if(terms.isEmpty())tag(s,pair[1],d.getOrDefault(pair[0],""));else for(String v:terms)tag(s,pair[1],v);}
  if(!d.getOrDefault("collection","").isEmpty()){s.append("<set>");tag(s,"name",d.get("collection"));s.append("</set>\n");}
  s.append("</").append(root).append(">\n");byte[] b=s.toString().getBytes(StandardCharsets.UTF_8);if(b.length>NfoReader.MAX_BYTES)throw new IOException("Los metadatos exceden 1 MiB.");return b;
 }
 private static void tag(StringBuilder s,String tag,String value)throws IOException{if(value==null||value.isEmpty())return;if(value.length()>16384)throw new IOException("Campo NFO demasiado largo.");s.append('<').append(tag).append('>');
  for(int at=0;at<value.length();){int cp=value.codePointAt(at);at+=Character.charCount(cp);if(!(cp==9||cp==10||cp==13||cp>=32&&cp<=0xd7ff||cp>=0xe000&&cp<=0xfffd||cp>=0x10000&&cp<=0x10ffff))throw new IOException("Carácter no compatible con XML.");switch(cp){case '&'->s.append("&amp;");case '<'->s.append("&lt;");case '>'->s.append("&gt;");default->s.appendCodePoint(cp);}}
  s.append("</").append(tag).append(">\n");
 }
}
