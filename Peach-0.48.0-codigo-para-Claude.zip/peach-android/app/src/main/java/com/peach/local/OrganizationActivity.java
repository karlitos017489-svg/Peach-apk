package com.peach.local;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Local identity profiles and works that do not require a media document. */
public final class OrganizationActivity extends PeachActivity {
    private record Data(List<CatalogEntity> entities,List<EntityAlias> aliases,List<MediaEntityLink> links,
            List<EntityReference> references,List<WantItem> wants,List<MediaEntry> media,List<EntityMembership> memberships,List<Publication> publications) {}
    private LibraryDatabase db;
    private Data data=new Data(List.of(),List.of(),List.of(),List.of(),List.of(),List.of(),List.of(),List.of());
    private Spinner section,trackingFilter;private int filterSection=-1,restoredTracking=-1;private EditText search;private ArrayAdapter<String> rows;
    private final List<String> visible=new ArrayList<>();
    private int generation;private String target="";
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);setContentView(R.layout.activity_organization);db=LibraryDatabase.get(this);restoredTracking=state==null?-1:state.getInt("trackingFilter",0);
        WindowCompat.setDecorFitsSystemWindows(getWindow(),false);
        View root=findViewById(R.id.organizationRoot);int padding=(int)(16*getResources().getDisplayMetrics().density);
        ViewCompat.setOnApplyWindowInsetsListener(root,(view,insets)->{
            var bars=insets.getInsets(WindowInsetsCompat.Type.systemBars()|WindowInsetsCompat.Type.displayCutout());
            view.setPadding(padding+bars.left,padding+bars.top,padding+bars.right,padding+bars.bottom);return insets;
        });
        target=getIntent().getStringExtra("targetMediaId");if(target==null)target="";
        section=findViewById(R.id.organizationSection);search=findViewById(R.id.organizationSearch);
        List<String> sections=new ArrayList<>(List.of("Todas las identidades","Lista de deseos"));
        for(EntityIndex.Kind kind:EntityIndex.KINDS)if(target.isEmpty() || !kind.key().equals("agency"))sections.add(kind.label());
        if(target.isEmpty())sections.add("Publicaciones");
        section.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,sections));
        section.setSelection(state==null?getIntent().getIntExtra("section",0):state.getInt("section",0));
        search.setText(state==null?"":state.getString("query",""));
        rows=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,new ArrayList<>());
        ListView list=findViewById(R.id.organizationList);list.setAdapter(rows);list.setEmptyView(findViewById(R.id.organizationEmpty));
        list.setOnItemClickListener((parent,view,position,id)->{
            String key=visible.get(position);
            if(section.getSelectedItemPosition()==1)wantProfile(key);
            else if(section.getSelectedItemPosition()==8)publicationProfile(key);
            else if(!target.isEmpty())chooseRole(key,target,()->finish());else entityProfile(key);
        });
        findViewById(R.id.organizationBack).setOnClickListener(v->finish());
        findViewById(R.id.organizationCreate).setOnClickListener(v->{if(section.getSelectedItemPosition()==1)editWant(null,null);else if(section.getSelectedItemPosition()==8)editPublication(null);else editEntity(null);});
        trackingFilter=findViewById(R.id.organizationTrackingFilter);
        trackingFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> p,View v,int position,long id){showRows();}public void onNothingSelected(AdapterView<?> p){}});
        findViewById(R.id.organizationReconcile).setOnClickListener(v->reviewWants());
        section.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(AdapterView<?> p,View v,int position,long id){showRows();}
            @Override public void onNothingSelected(AdapterView<?> p){}
        });
        search.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){showRows();}
            @Override public void afterTextChanged(Editable text){}
        });
        if(!target.isEmpty())((TextView)findViewById(R.id.organizationHelp)).setText("Elige o crea la identidad que quieres vincular al archivo.");
    }
    @Override protected void onResume(){super.onResume();reload(null);}
    private void reload(Runnable done) {
        int token=++generation;
        LibraryDatabase.IO.execute(()->{
            Data loaded=db.runInTransaction(()->new Data(db.library().entities(),db.library().aliases(),db.library().entityLinks(),
                db.library().entityReferences(),db.library().wants(),db.library().allMedia(),db.library().memberships(),db.library().publications()));
            runOnUiThread(()->{if(isFinishing() || isDestroyed() || token!=generation)return;data=loaded;showRows();String focus=getIntent().getStringExtra("focusPublication");if(focus!=null){getIntent().removeExtra("focusPublication");publicationProfile(focus);}if(done!=null)done.run();});
        });
    }
    private void showRows() {
        if(rows==null)return;rows.setNotifyOnChange(false);rows.clear();visible.clear();
        String query=search.getText().toString().trim().toLowerCase(Locale.ROOT);int selected=section.getSelectedItemPosition();
        if(trackingFilter!=null){boolean tracking=selected==1 || selected==8;trackingFilter.setVisibility(tracking?View.VISIBLE:View.GONE);findViewById(R.id.organizationReconcile).setVisibility(selected==1?View.VISIBLE:View.GONE);
            if(filterSection!=selected){filterSection=selected;trackingFilter.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,selected==1?new String[]{"Todos los deseos","Pendientes","Sin publicar","Pausadas","Conseguidas"}:new String[]{"Todas las publicaciones","Nuevas","Vistas","Guardadas","Ignoradas"}));if(restoredTracking>=0){trackingFilter.setSelection(Math.min(4,restoredTracking));restoredTracking=-1;}}}
        int filter=trackingFilter==null?0:Math.max(0,trackingFilter.getSelectedItemPosition());
        if(selected==1)for(WantItem item:data.wants()) {
            String phase=WantStore.phase(item,java.time.LocalDate.now());if(filter>0 && !phase.equals(new String[]{"","searching","unreleased","given_up","acquired"}[filter]))continue;
            CatalogEntity entity=entity(item.entityId);String context=entity==null?"":entity.name;
            if((item.title+" "+item.code+" "+item.notes+" "+WantStore.label(item)+" "+item.source+" "+context).toLowerCase(Locale.ROOT).contains(query)) {
                visible.add(item.id);rows.add(item.title+(item.code.isEmpty()?"":" · "+item.code)+"\n"+WantStore.label(item)+(item.mediaId==null?"":" · Archivo vinculado")+(context.isEmpty()?"":" · "+context));
            }
        } else if(selected==8)for(Publication p:data.publications()) {
            if(filter>0 && !p.status.equals(new String[]{"","new","seen","saved","ignored"}[filter]))continue;
            if((p.title+" "+p.provider+" "+p.sourceLabel+" "+p.notes+" "+p.releaseKey).toLowerCase(Locale.ROOT).contains(query)){visible.add(p.id);rows.add(p.title+"\n"+PublicationStore.statusLabel(p.status)+" · "+p.sourceLabel+" · "+p.publishedAt+" ("+p.precision+")");}
        } else for(CatalogEntity entity:data.entities()) {
            if(!target.isEmpty() && entity.kind.equals("agency"))continue;
            if(selected>=2 && !entity.kind.equals(EntityIndex.KINDS.get(selected-2).key()))continue;
            String names=String.join(" · ",EntityIndex.names(entity,data.aliases()));
            if((names+" "+entity.notes).toLowerCase(Locale.ROOT).contains(query)) {
                visible.add(entity.id);rows.add((entity.favorite?"★ ":"")+entity.name+"\n"+EntityIndex.kind(entity.kind).label()+(names.equals(entity.name)?"":" · "+names));
            }
        }
        rows.notifyDataSetChanged();((Button)findViewById(R.id.organizationCreate)).setText(selected==1?R.string.create_want:selected==8?R.string.create_publication:R.string.create_entity);
    }
    private CatalogEntity entity(String id){return data.entities().stream().filter(e->e.id.equals(id)).findFirst().orElse(null);}
    private WantItem want(String id){return data.wants().stream().filter(w->w.id.equals(id)).findFirst().orElse(null);}
    private MediaEntry media(String id){return data.media().stream().filter(m->m.id.equals(id)).findFirst().orElse(null);}
    private void save(Runnable action,Runnable done) {
        LibraryDatabase.IO.execute(()->{
            try{action.run();runOnUiThread(()->{if(!isFinishing() && !isDestroyed())reload(done);});}
            catch(Exception error){runOnUiThread(()->Toast.makeText(this,error instanceof IllegalArgumentException?error.getMessage():"No se pudo guardar el cambio.",Toast.LENGTH_LONG).show());}
        });
    }
    private LinearLayout fields(){LinearLayout fields=new LinearLayout(this);fields.setOrientation(LinearLayout.VERTICAL);int p=(int)(20*getResources().getDisplayMetrics().density);fields.setPadding(p,0,p,0);return fields;}
    private EditText input(LinearLayout fields,String label,String initial,boolean multiline) {
        TextView text=new TextView(this);text.setText(label);fields.addView(text);
        EditText input=new EditText(this);input.setContentDescription(label);input.setText(initial);input.setSingleLine(!multiline);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|(multiline?android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE:0));
        if(multiline)input.setMaxLines(4);fields.addView(input);return input;
    }
    private void form(String title,LinearLayout fields,Runnable submit) {
        ScrollView scroll=new ScrollView(this);scroll.addView(fields);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(title).setView(scroll).setPositiveButton("Guardar",null).setNegativeButton("Cancelar",null).create();
        dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            try{submit.run();dialog.dismiss();}catch(IllegalArgumentException error){Toast.makeText(this,error.getMessage(),Toast.LENGTH_LONG).show();}
        }));dialog.show();
    }
    private void editEntity(CatalogEntity existing) {
        LinearLayout fields=fields();Spinner kinds=new Spinner(this);
        List<EntityIndex.Kind> allowed=EntityIndex.KINDS.stream().filter(k->target.isEmpty() || !k.key().equals("agency")).toList();
        kinds.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,allowed.stream().map(EntityIndex.Kind::label).toArray(String[]::new)));
        int selected=0;String suggested=getIntent().getStringExtra("suggestKind");
        if(existing==null && section.getSelectedItemPosition()>=2)suggested=EntityIndex.KINDS.get(section.getSelectedItemPosition()-2).key();
        for(int i=0;i<allowed.size();i++)if(allowed.get(i).key().equals(existing==null?suggested:existing.kind))selected=i;
        kinds.setSelection(selected);kinds.setEnabled(existing==null);fields.addView(kinds);
        String initial=getIntent().getStringExtra("suggestName");
        EditText name=input(fields,"Nombre principal",existing==null?(initial==null?"":initial):existing.name,false);
        EditText notes=input(fields,"Notas",existing==null?"":existing.notes,true);
        form(existing==null?"Crear identidad":"Editar identidad",fields,()->{
            String value=EntityStore.name(name.getText().toString()),note=EntityStore.notes(notes.getText().toString());
            String kind=allowed.get(kinds.getSelectedItemPosition()).key();
            if(existing==null)save(()->db.runInTransaction(()->{
                String id=new EntityStore(db).create(kind,value,note);
                if(!target.isEmpty())new EntityStore(db).link(id,target,kind);
            }),target.isEmpty()?null:this::finish);
            else save(()->new EntityStore(db).edit(existing.id,value,note),()->entityProfile(existing.id));
        });
    }
    private void entityProfile(String id) {
        CatalogEntity e=entity(id);if(e==null)return;
        StringBuilder text=new StringBuilder(EntityIndex.kind(e.kind).label()).append("\n\n").append(e.notes).append("\n\nNombres y alias\n").append(String.join("\n",EntityIndex.names(e,data.aliases())));
        List<EntityIndex.Relation> relations=e.kind.equals("agency")?AgencyStore.relations(e,data.media(),data.entities(),data.aliases(),data.links(),data.memberships()):EntityIndex.relations(e,data.media(),data.aliases(),data.links());
        if(e.kind.equals("agency")){List<CatalogEntity> members=members(id);text.append("\n\nMiembros actuales: ").append(members.size());for(CatalogEntity member:members.subList(0,Math.min(100,members.size())))text.append("\n").append(member.name);}
        else {EntityMembership membership=membership(id);CatalogEntity agency=membership==null?null:entity(membership.agencyId);if(agency!=null)text.append("\n\nAgencia actual · ").append(agency.name);}
        text.append("\n\nArchivos relacionados: ").append(relations.stream().map(EntityIndex.Relation::mediaId).distinct().count());
        for(EntityReference ref:data.references())if(ref.entityId.equals(id))text.append("\n\nReferencia · ").append(ref.provider).append("\n").append(ref.externalId).append("\n").append(ref.url);
        for(EntityIndex.Relation relation:relations.subList(0,Math.min(100,relations.size()))) {
            MediaEntry m=media(relation.mediaId());if(m==null)continue;
            text.append("\n\n").append(m.displayTitle()).append(" · ").append(EntityIndex.roleLabel(relation.role())).append("\n");
            text.append(switch(relation.source()){case "manual"->"Vínculo manual";case "user-tags"->"Etiqueta personal";case "catalog"->"Catálogo importado";case "agency-nfo"->"Por miembro · NFO";case "agency-catalog"->"Por miembro · catálogo";case "agency-manual"->"Por miembro · vínculo manual";default->"Metadatos NFO";});
            if(!relation.term().isEmpty())text.append(" · ").append(relation.term());
            if(m.missing)text.append(" · No disponible");
        }
        if(relations.size()>100)text.append("\n\nSe muestran los primeros 100 vínculos. Ver archivos abre todos los archivos relacionados.");
        new AlertDialog.Builder(this).setTitle(e.name).setView(readable(text.toString()))
            .setPositiveButton("Ver archivos",(d,w)->openEntity(id)).setNeutralButton("Organizar",(d,w)->entityActions(id)).setNegativeButton("Cerrar",null).show();
    }
    private View readable(String value){ScrollView scroll=new ScrollView(this);TextView text=new TextView(this);text.setText(value);text.setTextSize(16);text.setTextIsSelectable(true);int p=(int)(20*getResources().getDisplayMetrics().density);text.setPadding(p,p,p,p);scroll.addView(text);return scroll;}
    private void openEntity(String id){startActivity(new Intent(this,MainActivity.class).putExtra("entityId",id).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP));finish();}
    private void entityActions(String id) {
        CatalogEntity e=entity(id);if(e==null)return;
        List<String> actions=new ArrayList<>(List.of("Cambiar nombre y notas",e.favorite?"Quitar favorito":"Marcar favorito","Añadir alias","Quitar alias",
            "Vincular archivo","Quitar vínculo manual","Referencias externas","Añadir obra a deseos","Eliminar identidad"));
        if(e.kind.equals("agency") || AgencyStore.memberKind(e.kind))actions.add(e.kind.equals("agency")?"Miembros de la agencia":"Afiliación a agencia");
        new AlertDialog.Builder(this).setTitle(e.name).setItems(actions.toArray(String[]::new),(d,index)->{
            switch(index){
                case 0->editEntity(e);
                case 1->save(()->db.library().favoriteEntity(id),()->entityProfile(id));
                case 2->{LinearLayout f=fields();EditText alias=input(f,"Alias exacto","",false);form("Añadir alias",f,()->{String name=EntityStore.name(alias.getText().toString());save(()->new EntityStore(db).alias(id,name),()->entityProfile(id));});}
                case 3->{List<EntityAlias> aliases=data.aliases().stream().filter(a->a.entityId.equals(id)).toList();choices("Quitar alias",aliases.stream().map(a->a.name).toList(),i->save(()->db.library().removeAlias(id,aliases.get(i).name),()->entityProfile(id)));}
                case 4->{if(e.kind.equals("agency"))Toast.makeText(this,"Los archivos de la agencia se obtienen por sus miembros.",Toast.LENGTH_LONG).show();else chooseMedia(mediaId->chooseRole(id,mediaId,()->entityProfile(id)));}
                case 5->{List<MediaEntityLink> links=data.links().stream().filter(l->l.entityId.equals(id)).toList();choices("Quitar vínculo manual",links.stream().map(l->(media(l.mediaId)==null?l.mediaId:media(l.mediaId).displayTitle())+" · "+EntityIndex.roleLabel(l.role)).toList(),i->{MediaEntityLink l=links.get(i);save(()->db.library().removeEntityLink(id,l.mediaId,l.role),()->entityProfile(id));});}
                case 6->references(id);
                case 7->editWant(null,id);
                case 8->new AlertDialog.Builder(this).setTitle("Eliminar identidad").setMessage("Se eliminarán la ficha, sus alias, referencias y vínculos. Se conservan archivos, progreso, listas, grupos y obras deseadas.")
                    .setPositiveButton("Eliminar",(dialog,w)->save(()->db.library().deleteEntity(id),null)).setNegativeButton("Conservar",null).show();
                case 9->{if(e.kind.equals("agency"))agencyMembers(id);else affiliation(id);}
                default->{}
            }
        }).setNegativeButton("Cerrar",null).show();
    }
    private EntityMembership membership(String member){return data.memberships().stream().filter(m->m.memberId.equals(member)).findFirst().orElse(null);}
    private List<CatalogEntity> members(String agency){java.util.Set<String> ids=new java.util.HashSet<>();for(EntityMembership m:data.memberships())if(m.agencyId.equals(agency))ids.add(m.memberId);return data.entities().stream().filter(e->ids.contains(e.id)).toList();}
    private void affiliation(String member) {
        CatalogEntity e=entity(member);if(e==null)return;EntityMembership current=membership(member);CatalogEntity agency=current==null?null:entity(current.agencyId);
        String info=agency==null?"Sin agencia asignada.":"Agencia actual · "+agency.name+"\nFuente: "+current.source+"\nConfianza registrada: "+current.confidence+"\nComprobado: "+current.checkedAt;
        AlertDialog.Builder dialog=new AlertDialog.Builder(this).setTitle("Afiliación · "+e.name).setView(readable(info)).setPositiveButton("Elegir agencia",(d,w)->{
            List<CatalogEntity> agencies=data.entities().stream().filter(a->a.kind.equals("agency")).toList();choices("Elegir agencia",agencies.stream().map(a->String.join(" · ",EntityIndex.names(a,data.aliases()))).toList(),i->assign(member,agencies.get(i).id,()->entityProfile(member)));
        }).setNegativeButton("Cerrar",null);
        if(current!=null)dialog.setNeutralButton("Quitar afiliación",(d,w)->save(()->new AgencyStore(db).remove(member),()->entityProfile(member)));dialog.show();
    }
    private void assign(String member,String agency,Runnable done) {
        EntityMembership old=membership(member);CatalogEntity person=entity(member),next=entity(agency);if(person==null || next==null)return;
        if(old!=null && !old.agencyId.equals(agency)){CatalogEntity previous=entity(old.agencyId);new AlertDialog.Builder(this).setTitle("Cambiar afiliación").setMessage(person.name+" pasará de "+(previous==null?"su agencia actual":previous.name)+" a "+next.name+". Se conserva una sola afiliación vigente; los archivos y su progreso permanecen.").setPositiveButton("Cambiar",(d,w)->save(()->new AgencyStore(db).assign(member,agency),done)).setNegativeButton("Conservar",null).show();}
        else save(()->new AgencyStore(db).assign(member,agency),done);
    }
    private void agencyMembers(String id) {
        CatalogEntity agency=entity(id);if(agency==null)return;List<CatalogEntity> members=members(id);
        new AlertDialog.Builder(this).setTitle("Miembros · "+agency.name).setItems(members.stream().map(e->e.name).toArray(String[]::new),(d,index)->entityProfile(members.get(index).id)).setPositiveButton("Añadir miembro",(d,w)->{
            List<CatalogEntity> choices=data.entities().stream().filter(e->AgencyStore.memberKind(e.kind) && members.stream().noneMatch(m->m.id.equals(e.id))).toList();choices("Elegir persona o creador",choices.stream().map(e->e.name+" · "+EntityIndex.kind(e.kind).label()).toList(),i->assign(choices.get(i).id,id,()->agencyMembers(id)));
        }).setNeutralButton("Retirar miembro",(d,w)->choices("Retirar miembro",members.stream().map(e->e.name).toList(),i->save(()->new AgencyStore(db).remove(members.get(i).id),()->agencyMembers(id)))).setNegativeButton("Cerrar",null).show();
    }
    private void chooseRole(String id,String mediaId,Runnable done) {
        CatalogEntity e=entity(id);if(e==null)return;List<String> roles=EntityIndex.roles(e.kind);
        choices("Función del vínculo",roles.stream().map(EntityIndex::roleLabel).toList(),i->save(()->new EntityStore(db).link(id,mediaId,roles.get(i)),done));
    }
    private void chooseMedia(java.util.function.Consumer<String> onSelect){choices("Elegir archivo",data.media().stream().map(m->m.displayTitle()+" · "+m.name+" · "+m.folder+(m.missing?" · No disponible":"")).toList(),i->onSelect.accept(data.media().get(i).id));}
    private void choices(String title,List<String> labels,java.util.function.IntConsumer select) {
        LinearLayout body=fields();EditText query=input(body,"Buscar","",false);ListView list=new ListView(this);
        int height=(int)(Math.min(340,getResources().getConfiguration().screenHeightDp/2)*getResources().getDisplayMetrics().density);body.addView(list,new LinearLayout.LayoutParams(-1,height));
        TextView empty=new TextView(this);empty.setText("No hay elementos coincidentes.");body.addView(empty);list.setEmptyView(empty);
        List<Integer> indexes=new ArrayList<>();ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,new ArrayList<>());list.setAdapter(adapter);
        Runnable update=()->{adapter.setNotifyOnChange(false);adapter.clear();indexes.clear();String needle=query.getText().toString().trim().toLowerCase(Locale.ROOT);
            for(int i=0;i<labels.size();i++)if(labels.get(i).toLowerCase(Locale.ROOT).contains(needle)){indexes.add(i);adapter.add(labels.get(i));}adapter.notifyDataSetChanged();};
        query.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){update.run();}public void afterTextChanged(Editable s){}});update.run();
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(title).setView(body).setNegativeButton("Cerrar",null).create();
        list.setOnItemClickListener((p,v,index,itemId)->{int original=indexes.get(index);dialog.dismiss();select.accept(original);});dialog.show();
    }
    private void references(String id) {
        List<EntityReference> refs=data.references().stream().filter(r->r.entityId.equals(id)).toList();
        new AlertDialog.Builder(this).setTitle("Referencias externas · sin conexión")
            .setItems(refs.stream().map(r->r.provider+" · "+r.externalId).toArray(String[]::new),(d,index)->{
                EntityReference ref=refs.get(index);new AlertDialog.Builder(this).setTitle(ref.provider).setView(readable(ref.externalId+"\n\n"+ref.url))
                    .setPositiveButton("Editar",(dialog,w)->editReference(id,ref)).setNeutralButton("Eliminar",(dialog,w)->save(()->db.library().removeEntityReference(id,ref.provider,ref.externalId),()->references(id)))
                    .setNegativeButton("Cerrar",null).show();
            }).setPositiveButton("Añadir referencia",(d,w)->editReference(id,null)).setNegativeButton("Cerrar",null).show();
    }
    private void editReference(String id,EntityReference old) {
        LinearLayout f=fields();EditText provider=input(f,"Proveedor",old==null?"":old.provider,false),external=input(f,"Identificador externo",old==null?"":old.externalId,false),url=input(f,"URL HTTPS (opcional)",old==null?"":old.url,false);
        form("Referencia externa",f,()->{
            String p=PlaylistStore.validName(provider.getText().toString(),80),key=EntityStore.name(external.getText().toString()),address=EntityStore.validUrl(url.getText().toString());
            save(()->db.runInTransaction(()->{if(old!=null)db.library().removeEntityReference(id,old.provider,old.externalId);new EntityStore(db).reference(id,p,key,address);}),()->references(id));
        });
    }
    private void editWant(WantItem old,String entityId) {
        LinearLayout f=fields();EditText title=input(f,"Título de la obra",old==null?"":old.title,false),code=input(f,"Código (opcional)",old==null?"":old.code,false),notes=input(f,"Notas",old==null?"":old.notes,true);
        form(old==null?"Añadir obra a deseos":"Editar obra deseada",f,()->{
            String t=EntityStore.name(title.getText().toString()),c=WantStore.code(code.getText().toString()),n=EntityStore.notes(notes.getText().toString());
            save(()->{if(old==null)new WantStore(db).create(t,c,n,entityId);else new WantStore(db).edit(old.id,t,c,n);},()->{section.setSelection(1);showRows();});
        });
    }
    private void wantProfile(String id) {
        WantItem item=want(id);if(item==null)return;CatalogEntity e=entity(item.entityId);MediaEntry m=media(item.mediaId);
        String text=WantStore.label(item)+"\nFecha de publicación: "+item.releaseDate+"\nOrigen: "+item.origin+" · "+item.source+"\nBúsquedas sin resultado: "+item.searchCount+"\nÚltimo resultado: "+item.lastSearchOutcome+" · "+item.lastSearchAt+"\n"+item.lastSearchNote+"\nConseguida: "+item.acquiredAt+"\nLote: "+item.acquiredBatch+"\n\n"+item.code+"\n\n"+item.notes+(e==null?"":"\n\nIdentidad · "+e.name)+"\n\n"+(m==null?"Pendiente de conseguir":("Archivo vinculado · "+m.displayTitle()+"\n"+m.name+(m.missing?"\nNo disponible":"")));
        new AlertDialog.Builder(this).setTitle(item.title).setView(readable(text)).setPositiveButton("Organizar",(d,w)->{
            new AlertDialog.Builder(this).setTitle(item.title).setItems(new String[]{"Editar título, código y notas","Vincular archivo de la biblioteca","Retirar vínculo al archivo","Eliminar obra deseada","Fecha y estado","Registrar resultado de búsqueda","Reiniciar búsquedas","Ver publicación de origen","Abrir archivo vinculado"},(dialog,index)->{
                switch(index){case 0->editWant(item,null);case 1->chooseMedia(mediaId->save(()->new WantStore(db).attach(id,mediaId),()->wantProfile(id)));
                    case 2->save(()->new WantStore(db).attach(id,null),()->wantProfile(id));
                    case 3->new AlertDialog.Builder(this).setTitle("Eliminar obra deseada").setMessage("Se eliminará esta entrada de deseos. Los archivos y sus datos se conservan.")
                        .setPositiveButton("Eliminar",(confirm,w2)->save(()->db.library().deleteWant(id),null)).setNegativeButton("Conservar",null).show();
                    case 4->trackWant(item);case 5->searchWant(item);case 6->save(()->new WantStore(db).reset(id),()->wantProfile(id));case 7->{if(item.publicationId!=null)publicationProfile(item.publicationId);else Toast.makeText(this,"Esta obra no tiene publicación vinculada.",Toast.LENGTH_LONG).show();}case 8->openDocument(item.mediaId);default->{}}
            }).setNegativeButton("Cerrar",null).show();
        }).setNegativeButton("Cerrar",null).show();
    }
    private void openDocument(String id){MediaEntry m=media(id);if(m==null || m.missing){Toast.makeText(this,"No hay un archivo local disponible vinculado.",Toast.LENGTH_LONG).show();return;}Class<?> activity=DocumentRules.readable(m.name)?ReaderActivity.class:MediaRules.IMAGE.equals(m.mediaType)?ImageViewerActivity.class:MediaRules.playable(m)?PlayerActivity.class:null;if(activity==null){new AlertDialog.Builder(this).setTitle(m.displayTitle()).setView(MediaDetailsView.create(this,m)).setPositiveButton("Cerrar",null).show();return;}startActivity(new Intent(this,activity).putExtra("mediaId",m.id));}
    private Spinner select(LinearLayout parent,String label,String[] labels,int selected){TextView text=new TextView(this);text.setText(label);parent.addView(text);Spinner choice=new Spinner(this);choice.setContentDescription(label);choice.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels));choice.setSelection(selected);parent.addView(choice);return choice;}
    private void trackWant(WantItem w){LinearLayout f=fields();EditText date=input(f,"Fecha de publicación AAAA-MM-DD (opcional)",w.releaseDate,false);String[] states={"wanted","given_up","acquired"};Spinner state=select(f,"Estado",new String[]{"Pendiente","Pausada","Conseguida"},java.util.Arrays.asList(states).indexOf(w.state));form("Fecha y estado",f,()->{String value=date.getText().toString().trim(),next=states[state.getSelectedItemPosition()];if(!value.isEmpty() && WantStore.day(value)==null)throw new IllegalArgumentException("Fecha inválida.");save(()->new WantStore(db).track(w.id,value,next),()->wantProfile(w.id));});}
    private void searchWant(WantItem w){LinearLayout f=fields();String[] outcomes={"found","none","error"};Spinner outcome=select(f,"Resultado",new String[]{"Recurso encontrado","Sin resultados","Error de búsqueda"},0);EditText note=input(f,"Nota de la búsqueda","",true);form("Registrar búsqueda realizada",f,()->{String n=EntityStore.notes(note.getText().toString());String value=outcomes[outcome.getSelectedItemPosition()];save(()->new WantStore(db).search(w.id,value,n,java.time.LocalDate.now()),()->wantProfile(w.id));});}
    private void reviewWants(){LibraryDatabase.IO.execute(()->{WantStore.Review plan=new WantStore(db).review();runOnUiThread(()->{if(isFinishing() || isDestroyed())return;StringBuilder text=new StringBuilder("Se comparan códigos declarados en NFO o catálogo, ignorando mayúsculas y espacios exteriores. No se usan títulos ni nombres de archivo. Solo se marcarán coincidencias únicas; revisa sus documentos.\n");for(WantStore.Match row:plan.matches()){text.append("\n").append(row.title()).append(" · ").append(row.state());for(String id:row.media()){MediaEntry m=media(id);text.append("\n  ").append(m==null?id:m.name+" · "+m.folder);}}
        new AlertDialog.Builder(this).setTitle("Revisar deseos y archivos").setView(readable(text.toString())).setPositiveButton("Marcar coincidencias únicas",(d,w)->save(()->new WantStore(db).acquire(plan),null)).setNeutralButton("Deshacer un lote",(d,w)->revertWants()).setNegativeButton("Cancelar",null).show();});});}
    private void revertWants(){List<String> batches=data.wants().stream().map(w->w.acquiredBatch).filter(b->b.startsWith("local-review:")).distinct().toList();choices("Deshacer lote de coincidencias",batches,i->new AlertDialog.Builder(this).setTitle("Deshacer lote").setMessage("Las obras que aún pertenecen a este lote volverán a su estado anterior. Los archivos y su progreso se conservan.").setPositiveButton("Deshacer",(d,w)->save(()->new WantStore(db).revert(batches.get(i)),null)).setNegativeButton("Conservar",null).show());}
    private Publication publication(String id){return data.publications().stream().filter(p->p.id.equals(id)).findFirst().orElse(null);}
    private void editPublication(Publication old){LinearLayout f=fields();EditText title=input(f,"Título de la publicación",old==null?"":old.title,false);EditText provider=old==null?input(f,"Proveedor (solo referencia)","",false):null,label=old==null?input(f,"Nombre de la fuente","",false):null;EditText date=input(f,"Fecha o texto original",old==null?"":old.publishedAt,false);String[] precisions={"unknown","exact","approximate"};Spinner precision=select(f,"Precisión de fecha",new String[]{"Desconocida","Exacta","Aproximada"},old==null?0:java.util.Arrays.asList(precisions).indexOf(old.precision));Spinner semantics=old==null?select(f,"Clase de publicación",new String[]{"Obra","Publicación o entrega"},0):null;EditText notes=input(f,"Notas",old==null?"":old.notes,true);
        form(old==null?"Añadir publicación":"Editar publicación",f,()->{String t=EntityStore.name(title.getText().toString()),d=date.getText().toString(),pr=precisions[precision.getSelectedItemPosition()],n=EntityStore.notes(notes.getText().toString());Publication check=new Publication();check.id="validar";check.title=t;check.publishedAt=d;check.precision=pr;PublicationStore.validate(check);String source=label==null?"":label.getText().toString(),prov=provider==null?"":provider.getText().toString(),kind=semantics!=null && semantics.getSelectedItemPosition()==1?"release":"work";
            save(()->{if(old==null)new PublicationStore(db).create(t,prov,source,d,pr,kind,n);else new PublicationStore(db).edit(old.id,t,d,pr,n);},()->{section.setSelection(8);showRows();});});}
    private void publicationProfile(String id){Publication p=publication(id);if(p==null)return;MediaEntry m=media(p.mediaId);CatalogEntity e=entity(p.entityId);String info=PublicationStore.statusLabel(p.status)+"\n\nFecha: "+p.publishedAt+" ("+p.precision+")\nClase: "+p.semantics+" · variante: "+p.variant+" · "+p.variantLabel+"\nClave de publicación: "+p.releaseKey+"\n\nFuente: "+p.sourceLabel+"\nProveedor: "+p.provider+"\nReferencia: "+p.sourceRef+"\nID externo: "+p.externalId+"\nOrigen: "+p.origin+"\nURL de referencia: "+p.url+(e==null?"":"\nIdentidad: "+e.name)+"\n\n"+(m==null?"Sin documento local vinculado.":"Archivo: "+m.name+" · "+m.folder+(m.missing?" · No disponible":""))+"\n\n"+p.notes;
        new AlertDialog.Builder(this).setTitle(p.title).setView(readable(info)).setPositiveButton("Organizar",(d,w)->new AlertDialog.Builder(this).setTitle(p.title).setItems(new String[]{"Editar publicación","Cambiar estado","Añadir a deseos","Vincular archivo local","Retirar vínculo al archivo","Eliminar publicación","Abrir archivo vinculado","Leer contenido consultado"},(dialog,index)->{switch(index){case 0->editPublication(p);case 1->{String[] states={"new","seen","saved","ignored"};choices("Estado de publicación",java.util.Arrays.stream(states).map(PublicationStore::statusLabel).toList(),i->save(()->new PublicationStore(db).status(id,states[i]),()->publicationProfile(id)));}case 2->save(()->new WantStore(db).fromPublication(id),()->{section.setSelection(1);showRows();});case 3->chooseMedia(mediaId->save(()->new PublicationStore(db).attach(id,mediaId),()->publicationProfile(id)));case 4->save(()->new PublicationStore(db).attach(id,null),()->publicationProfile(id));case 5->new AlertDialog.Builder(this).setTitle("Eliminar publicación").setMessage("Se conserva la obra deseada, el archivo y su progreso. Se retira su referencia a esta publicación.").setPositiveButton("Eliminar",(confirm,a)->save(()->new PublicationStore(db).delete(id),null)).setNegativeButton("Conservar",null).show();case 6->openDocument(p.mediaId);case 7->startActivity(new Intent(this,SourceBrowserActivity.class).putExtra("publicationId",p.id));default->{}}}).setNegativeButton("Cerrar",null).show()).setNegativeButton("Cerrar",null).show();
    }
    @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);out.putInt("section",section.getSelectedItemPosition());out.putString("query",search.getText().toString());out.putInt("trackingFilter",Math.max(0,trackingFilter.getSelectedItemPosition()));}
    @Override protected void onDestroy(){generation++;super.onDestroy();}
}
