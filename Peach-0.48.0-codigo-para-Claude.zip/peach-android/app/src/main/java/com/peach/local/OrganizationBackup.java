package com.peach.local;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

/** Version-four personal organization. Called inside the state import transaction. */
public final class OrganizationBackup {
    private OrganizationBackup() {}
    public static void write(LibraryDao dao,JSONObject backup) throws Exception {
        JSONArray entities=new JSONArray(),aliases=new JSONArray(),links=new JSONArray(),references=new JSONArray(),wants=new JSONArray();
        for(CatalogEntity e:dao.entities())entities.put(new JSONObject().put("id",e.id).put("kind",e.kind).put("name",e.name)
            .put("notes",e.notes).put("favorite",e.favorite).put("createdAt",e.createdAt));
        for(EntityAlias a:dao.aliases())aliases.put(new JSONObject().put("entityId",a.entityId).put("name",a.name));
        for(MediaEntityLink l:dao.entityLinks())links.put(new JSONObject().put("entityId",l.entityId).put("mediaId",l.mediaId).put("role",l.role));
        for(EntityReference r:dao.entityReferences())references.put(new JSONObject().put("entityId",r.entityId).put("provider",r.provider).put("externalId",r.externalId).put("url",r.url));
        for(WantItem w:dao.wants())wants.put(new JSONObject().put("id",w.id).put("title",w.title).put("code",w.code).put("notes",w.notes)
            .put("entityId",w.entityId==null?JSONObject.NULL:w.entityId).put("mediaId",w.mediaId==null?JSONObject.NULL:w.mediaId).put("createdAt",w.createdAt));
        backup.put("entities",entities).put("aliases",aliases).put("entityLinks",links).put("entityReferences",references).put("wants",wants);
        arrays(backup);
    }
    private static JSONArray[] arrays(JSONObject backup) {
        String[] keys={"entities","aliases","entityLinks","entityReferences","wants"};int[] limits={5000,20000,50000,20000,5000};
        JSONArray[] result=new JSONArray[keys.length];
        for(int i=0;i<keys.length;i++) {
            result[i]=backup.optJSONArray(keys[i]);if(result[i]==null || result[i].length()>limits[i])throw new IllegalArgumentException("Organización inválida o demasiado grande.");
        }
        return result;
    }
    public static void read(LibraryDatabase db,JSONObject backup) {
        JSONArray[] arrays=arrays(backup);LibraryDao dao=db.library();Map<String,CatalogEntity> incoming=new HashMap<>();
        for(int i=0;i<arrays[0].length();i++) {
            JSONObject row=row(arrays[0],i);CatalogEntity e=new CatalogEntity();e.id=id(row,"id");e.kind=EntityIndex.kind(text(row,"kind")).key();
            e.name=EntityStore.name(text(row,"name"));e.notes=EntityStore.notes(text(row,"notes"));
            if(!(row.opt("favorite") instanceof Boolean favorite))throw new IllegalArgumentException("Favorito inválido.");
            e.favorite=favorite;e.createdAt=time(row);
            if(incoming.put(e.id,e)!=null)throw new IllegalArgumentException("Identidad duplicada.");
        }
        for(CatalogEntity e:incoming.values()) {
            if(dao.entity(e.id)==null)dao.insertEntity(e);else dao.updateEntity(e);
            dao.clearAliases(e.id);dao.clearEntityLinks(e.id);dao.clearEntityReferences(e.id);
        }
        Set<java.util.List<String>> seen=new HashSet<>();
        for(int i=0;i<arrays[1].length();i++) {
            JSONObject row=row(arrays[1],i);EntityAlias a=new EntityAlias();a.entityId=entity(row,incoming).id;a.name=EntityStore.name(text(row,"name"));
            unique(seen,a.entityId,a.name);dao.insertAlias(a);
        }
        EntityStore.validateNames(dao);seen.clear();
        for(int i=0;i<arrays[2].length();i++) {
            JSONObject row=row(arrays[2],i);CatalogEntity e=entity(row,incoming);MediaEntityLink link=new MediaEntityLink();
            link.entityId=e.id;link.mediaId=id(row,"mediaId");link.role=text(row,"role");
            if(!EntityIndex.roles(e.kind).contains(link.role))throw new IllegalArgumentException("Función incompatible con la identidad.");
            unique(seen,link.entityId,link.mediaId,link.role);if(dao.get(link.mediaId)!=null)dao.insertEntityLink(link);
        }
        seen.clear();
        for(int i=0;i<arrays[3].length();i++) {
            JSONObject row=row(arrays[3],i);EntityReference ref=new EntityReference();ref.entityId=entity(row,incoming).id;
            ref.provider=PlaylistStore.validName(text(row,"provider"),80);ref.externalId=EntityStore.name(text(row,"externalId"));ref.url=EntityStore.validUrl(text(row,"url"));
            unique(seen,ref.entityId,ref.provider,ref.externalId);dao.putEntityReference(ref);
        }
        seen.clear();
        for(int i=0;i<arrays[4].length();i++) {
            JSONObject row=row(arrays[4],i);WantItem w=new WantItem();w.id=id(row,"id");w.title=EntityStore.name(text(row,"title"));
            w.code=WantStore.code(text(row,"code"));w.notes=EntityStore.notes(text(row,"notes"));w.createdAt=time(row);
            w.entityId=optionalId(row,"entityId");w.mediaId=optionalId(row,"mediaId");
            if(w.entityId!=null && !incoming.containsKey(w.entityId))throw new IllegalArgumentException("Obra con identidad ajena a la copia.");
            if(w.mediaId!=null && dao.get(w.mediaId)==null)w.mediaId=null;
            TrackingBackup.preserve(dao.want(w.id),w);unique(seen,w.id);if(dao.want(w.id)==null)dao.insertWant(w);else dao.updateWant(w);
        }
    }
    private static CatalogEntity entity(JSONObject row,Map<String,CatalogEntity> incoming) {
        CatalogEntity e=incoming.get(id(row,"entityId"));if(e==null)throw new IllegalArgumentException("Referencia a identidad ausente.");return e;
    }
    private static JSONObject row(JSONArray array,int i){JSONObject row=array.optJSONObject(i);if(row==null)throw new IllegalArgumentException("Registro inválido.");return row;}
    private static String text(JSONObject row,String key){if(!(row.opt(key) instanceof String value))throw new IllegalArgumentException("Campo inválido: "+key);return value;}
    private static String id(JSONObject row,String key){String value=text(row,key);if(value.isBlank() || !key.equals("mediaId") && value.length()>1000)throw new IllegalArgumentException("Identificador inválido.");return value;}
    private static String optionalId(JSONObject row,String key){if(!row.has(key))throw new IllegalArgumentException("Campo ausente.");return row.isNull(key)?null:id(row,key);}
    private static long time(JSONObject row){Object value=row.opt("createdAt");if(!(value instanceof Number n) || n.longValue()<0 || n.doubleValue()!=n.longValue())throw new IllegalArgumentException("Fecha inválida.");return n.longValue();}
    private static void unique(Set<java.util.List<String>> seen,String... parts){if(!seen.add(java.util.List.of(parts)))throw new IllegalArgumentException("Registro duplicado.");}
}
