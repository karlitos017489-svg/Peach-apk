package com.peach.local;
import java.io.*;
import java.util.*;

/** Evidence is proposed, reviewed, and rechecked; never deletes or merges media identities. */
final class OrganizationReview {
 record Item(String id,String uri,String name,long bytes,long modified,String code){}
 record Match(String kind,String value,List<Item> members){String label(){return (kind.equals("hash")?"Contenido idéntico SHA-256":"Indicio: mismo código NFO")+" · "+members.size()+" archivos\n"+value;}}
 record Result(List<Match> matches,int checked,int skipped,boolean partial){}
 static Item item(MediaEntry m){return new Item(m.id,m.uri,m.name,m.bytes,m.modified,m.details().getOrDefault("code","").trim());}
 static Result scan(FileOrganizer store,boolean exact)throws Exception{
  List<MediaEntry> all=store.db.library().allMedia();if(all.size()>20000)throw new IOException("Selecciona una biblioteca de hasta 20.000 registros para esta revisión.");
  Map<Long,Integer> sizes=new HashMap<>();for(var m:all)if(!m.missing)sizes.merge(m.bytes,1,Integer::sum);
  Map<String,List<Item>> groups=new TreeMap<>();long bytes=0;int checked=0,skipped=0;boolean partial=false;
  for(MediaEntry m:all){if(store.cancelRequested)throw new InterruptedIOException("Revisión cancelada.");if(m.missing)continue;String code=item(m).code();if(!exact){if(!code.isEmpty())groups.computeIfAbsent(code,k->new ArrayList<>()).add(item(m));continue;}
   if(m.bytes<0||sizes.getOrDefault(m.bytes,0)<2)continue;
   if(m.bytes>FileOrganizer.MAX_BYTES-bytes){partial=true;skipped++;continue;}
   bytes+=m.bytes;try{FileOrganizer.Doc before=store.required(m.uri);if(before.size()!=m.bytes||before.dir())throw new IOException();String sha=store.digest(m.uri,m.bytes);if(!before.equals(store.required(m.uri)))throw new IOException();groups.computeIfAbsent(sha,k->new ArrayList<>()).add(item(m));checked++;}catch(InterruptedIOException e){throw e;}catch(Exception e){skipped++;}
  }
  List<Match> out=new ArrayList<>();for(var g:groups.entrySet())if(g.getValue().size()>1){if(out.size()>=500){partial=true;break;}if(g.getValue().size()>200){partial=true;continue;}out.add(new Match(exact?"hash":"code",g.getKey(),List.copyOf(g.getValue())));}
  return new Result(List.copyOf(out),checked,skipped,partial);
 }
 static String save(FileOrganizer store,Match proposal,List<String> chosen,String label)throws Exception{synchronized(FileOrganizer.MUTEX){store.idle();if(chosen.size()<2||new HashSet<>(chosen).size()!=chosen.size())throw new IOException("Elige al menos dos archivos distintos.");
  Set<String> selected=new HashSet<>(chosen);Map<String,Item> preview=new HashMap<>();for(Item i:proposal.members)preview.put(i.id,i);
  for(String id:chosen){MediaEntry m=store.db.library().get(id);if(m==null||m.missing||!item(m).equals(preview.get(id)))throw new IOException("La biblioteca cambió; vuelve a buscar coincidencias.");if(proposal.kind.equals("hash")){if(!store.digest(m.uri,m.bytes).equals(proposal.value))throw new IOException("El contenido cambió desde la revisión.");}else if(!item(m).code.equals(proposal.value))throw new IOException("El código NFO cambió.");}
  String[] result={null};store.db.runInTransaction(()->{for(MediaGroup g:store.db.library().groups())if(new HashSet<>(store.db.library().groupItems(g.id).stream().map(x->x.mediaId).toList()).equals(selected)){result[0]=g.id;return;}GroupStore groups=new GroupStore(store.db);String group=groups.create(label);for(String id:chosen)groups.add(group,id);result[0]=group;});return result[0];
 }}
 static String saveParts(FileOrganizer store,Match proposal,List<String> chosen,String label)throws Exception{synchronized(FileOrganizer.MUTEX){
  store.idle();if(!proposal.kind.equals("code")||chosen.size()<2||chosen.size()>200||new HashSet<>(chosen).size()!=chosen.size())throw new IOException("Las partes requieren una selección por código NFO.");
  Map<String,Item> preview=new HashMap<>();for(Item i:proposal.members)preview.put(i.id,i);List<VersionIndex.Evidence> parts=new ArrayList<>();
  for(String id:chosen){MediaEntry m=store.db.library().get(id);if(m==null||m.missing||!m.mediaType.equals(MediaRules.VIDEO)||!item(m).equals(preview.get(id))||!item(m).code.equals(proposal.value))throw new IOException("La selección cambió o no corresponde al código revisado.");parts.add(VersionIndex.inspect(m));}
  parts.sort(Comparator.comparingInt(VersionIndex.Evidence::part));var first=parts.get(0);int total=0;
  for(int i=0;i<parts.size();i++){var e=parts.get(i);if(!e.safe()||e.part()!=i+1||!e.signature().equals(first.signature()))throw new IOException("Se necesitan partes explícitas consecutivas desde 1 y una única versión.");if(e.total()>0){if(total>0&&total!=e.total())throw new IOException("Totales de partes contradictorios.");total=e.total();}}
  if(total>0&&total!=parts.size())throw new IOException("Faltan partes declaradas.");List<String> ids=parts.stream().map(VersionIndex.Evidence::id).toList();String[] result={null};String name=PlaylistStore.validName(label,80);
  store.db.runInTransaction(()->{for(Playlist list:store.db.library().playlists())if(store.db.library().playlistItems(list.id).stream().map(x->x.mediaId).toList().equals(ids)){result[0]=list.id;return;}PlaylistStore lists=new PlaylistStore(store.db);String id=lists.create(name);for(String m:ids)lists.add(id,m);result[0]=id;});return result[0];
 }}
}
