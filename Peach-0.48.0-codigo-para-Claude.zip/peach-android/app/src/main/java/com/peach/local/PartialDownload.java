package com.peach.local;

import javax.net.ssl.HttpsURLConnection;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

/** RFC9110 single-range transfer; no caller URL/credentials reach the native player. */
final class PartialDownload {
    record Mark(long offset,long total,String etag,String target,String sha) {
        static Mark empty(){return new Mark(0,-1,"","","");}
    }
    interface Updates {void checkpoint(Mark mark)throws IOException;void progress(long bytes,long total);}
    static class Problem extends IOException {Problem(String message){super(message);}}
    record Range(long start,long end,long total) {}
    static MessageDigest digest(){try{return MessageDigest.getInstance("SHA-256");}catch(Exception e){throw new AssertionError(e);}}
    static String hex(byte[] bytes){StringBuilder out=new StringBuilder();for(byte b:bytes)out.append(String.format(Locale.ROOT,"%02x",b&255));return out.toString();}
    static String key(String text){return hex(digest().digest(text.getBytes(StandardCharsets.UTF_8)));}
    static boolean strong(String raw){return raw!=null&&raw.matches("\"[\\x21\\x23-\\x7E]{0,480}\"");}
    static String snapshot(MessageDigest hash){try{return hex(((MessageDigest)hash.clone()).digest());}catch(CloneNotSupportedException e){return null;}}
    static Range range(String raw,long limit){try{var m=java.util.regex.Pattern.compile("bytes ([0-9]{1,19})-([0-9]{1,19})/([0-9]{1,19})").matcher(Objects.toString(raw,""));if(!m.matches())return null;
        long a=Long.parseLong(m.group(1)),b=Long.parseLong(m.group(2)),n=Long.parseLong(m.group(3));return a<=b&&b<n&&n<=limit?new Range(a,b,n):null;
    }catch(NumberFormatException e){return null;}}
    static void truncate(File part,long length)throws IOException{try(RandomAccessFile f=new RandomAccessFile(part,"rw")){f.setLength(length);f.getFD().sync();}}
    static String checksum(File file,SourceHttp.Token token)throws IOException{MessageDigest d=digest();try(InputStream in=new FileInputStream(file)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1){token.check();d.update(b,0,n);}}token.check();return hex(d.digest());}
    static SourceHttp.Download get(String url,File part,Mark saved,SourceHttp.Token token,long limit,Updates updates)throws IOException {
        return get(url,part,saved,token,limit,updates,u->(HttpsURLConnection)new URL(u).openConnection(),InetAddress::getAllByName);
    }
    static SourceHttp.Download get(String url,File part,Mark saved,SourceHttp.Token token,long limit,Updates updates,SourceHttp.ConnectionFactory factory,MediaRedirects.Resolver resolver)throws IOException {
        if(!SourceHttp.downloadable(url)||limit<1||limit>SourceHttp.LARGE_DOWNLOAD_LIMIT)throw new Problem("Referencia o límite de descarga no admitido.");token.check();
        Mark mark=saved;MessageDigest hash=digest();boolean valid=mark.offset()>0&&mark.offset()<=limit&&part.length()>=mark.offset()&&mark.sha().matches("[a-f0-9]{64}")&&(mark.total()<0||mark.offset()<=mark.total()&&mark.total()<=limit);
        if(valid){MessageDigest proof=digest();try(InputStream in=new FileInputStream(part)){byte[] b=new byte[65536];long remaining=mark.offset();while(remaining>0){token.check();int n=in.read(b,0,(int)Math.min(b.length,remaining));if(n<0){valid=false;break;}hash.update(b,0,n);proof.update(b,0,n);remaining-=n;}}valid&=hex(proof.digest()).equals(mark.sha());}
        if(valid&&mark.offset()==mark.total()){truncate(part,mark.offset());String sha=hex(hash.digest());verifyExpected(url,part,sha,updates);updates.progress(mark.offset(),mark.total());return new SourceHttp.Download(mark.offset(),sha);}
        boolean immutable=PawchiveUrls.downloadable(url);
        if(!valid||!immutable&&!strong(mark.etag())){truncate(part,0);mark=Mark.empty();hash=digest();updates.checkpoint(mark);}else truncate(part,mark.offset());
        for(int attempt=0;attempt<2;attempt++){
            token.check();long offset=mark.offset();HttpsURLConnection c=null;
            try{c=SourceHttp.open(url,"","",token,false,factory,resolver,offset,strong(mark.etag())?mark.etag():"");int status=c.getResponseCode();String target=key(c.getURL().toString()),etag=SourceHttp.header(c.getHeaderField("ETag"));if(!strong(etag))etag="";
                long length=c.getContentLengthLong(),total=length,expectedBody=length;Range r=range(c.getHeaderField("Content-Range"),limit);
                if(offset>0&&status!=200){boolean matches=status==206&&r!=null&&r.start()==offset&&(mark.total()<0||r.total()==mark.total())&&(length<0||length==r.end()-r.start()+1)&&(immutable||mark.target().equals(target)&&!etag.isEmpty()&&etag.equals(mark.etag()));
                    if(!matches){c.disconnect();c=null;token.connection=null;truncate(part,0);mark=Mark.empty();hash=digest();updates.checkpoint(mark);updates.progress(0,-1);continue;}
                    total=r.total();expectedBody=r.end()-r.start()+1;
                }else if(status!=200)throw new Problem("El servidor no devolvió un archivo completo compatible.");
                if(total==0||total>limit)throw new Problem("El archivo está vacío o supera el límite disponible de la cola.");
                String mime=Objects.toString(c.getContentType(),"").toLowerCase(Locale.ROOT),encoding=Objects.toString(c.getHeaderField("Content-Encoding"),"").trim();
                if(mime.contains("text/html")||mime.contains("application/json")||mime.startsWith("multipart/")||!encoding.isEmpty()&&!encoding.equalsIgnoreCase("identity"))throw new Problem("El servidor devolvió una página o codificación incompatible, no el adjunto esperado.");
                if(status==200){offset=0;hash=digest();truncate(part,0);mark=new Mark(0,total,etag,target,"");updates.checkpoint(mark);}
                long space=part.getParentFile().getUsableSpace();if(space>0&&(space<64L*1024*1024||total>0&&total-offset>space-64L*1024*1024))throw new Problem("No hay espacio suficiente para continuar la descarga.");
                return body(url,c,part,offset,total,expectedBody,etag,target,hash,token,limit,updates);
            }finally{if(c!=null)c.disconnect();token.connection=null;}
        }throw new Problem("El servidor no permite continuar este fragmento; vuelve a intentar la descarga completa.");
    }
    static SourceHttp.Download body(String url,HttpsURLConnection c,File part,long offset,long total,long bodyLength,String etag,String target,MessageDigest hash,SourceHttp.Token token,long limit,Updates updates)throws IOException {
        long written=offset,lastCheckpoint=offset,lastSpace=offset,deadline=System.nanoTime()+3_600_000_000_000L,lastProgress=0;String sha=null;
        try(InputStream in=c.getInputStream();FileOutputStream out=new FileOutputStream(part,offset>0)){
            try{updates.progress(written,total);byte[] buffer=new byte[65536];int n;
                while((n=in.read(buffer))!=-1){token.check();if(written+n>limit||bodyLength>=0&&written-offset+n>bodyLength||System.nanoTime()>deadline)throw new Problem("La descarga supera su tamaño o tiempo permitido.");
                    if(written-lastSpace>=8L*1024*1024){lastSpace=written;long free=part.getParentFile().getUsableSpace();if(free>0&&free<64L*1024*1024)throw new Problem("No hay espacio suficiente para continuar la descarga.");}
                    out.write(buffer,0,n);hash.update(buffer,0,n);written+=n;
                    long now=System.nanoTime();if(now-lastProgress>250_000_000L){updates.progress(written,total);lastProgress=now;}
                    if(written-lastCheckpoint>=4L*1024*1024){String prefix=snapshot(hash);if(prefix!=null){out.getFD().sync();updates.checkpoint(new Mark(written,total,etag,target,prefix));lastCheckpoint=written;}}
                }
                token.check();if(written==0||bodyLength>=0&&written-offset!=bodyLength||total>=0&&written!=total)throw new Problem("La conexión terminó antes de completar el archivo. Puedes reanudarlo.");
                out.getFD().sync();sha=hex(hash.digest());updates.checkpoint(new Mark(written,written,etag,target,sha));
            }catch(IOException e){try{out.flush();if(part.length()!=written)truncate(part,written);out.getFD().sync();String prefix=sha==null?hex(hash.digest()):sha;updates.checkpoint(new Mark(written,total,etag,target,prefix));}catch(IOException ignored){/* A failed metadata write retains the older durable checkpoint. */}throw e;}
        }
        verifyExpected(url,part,sha,updates);updates.progress(written,written);return new SourceHttp.Download(written,sha);
    }
    static void verifyExpected(String url,File part,String sha,Updates updates)throws IOException {
        if(PawchiveUrls.downloadable(url)&&!PawchiveUrls.expectedHash(url).equals(sha)){truncate(part,0);updates.checkpoint(Mark.empty());throw new Problem("El archivo no coincide con el SHA-256 esperado de Pawchive; se descartó el fragmento.");}
    }
}
