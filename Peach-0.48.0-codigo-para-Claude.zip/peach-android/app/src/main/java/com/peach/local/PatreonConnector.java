package com.peach.local;

import java.io.*;
import java.net.*;
import java.time.LocalDate;
import java.util.*;
import java.util.regex.*;
import org.json.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.*;

/** Public HTML/SSR cards only. Does not execute script/bootstrap state or use private/OAuth APIs. */
public final class PatreonConnector {
    private static final Pattern POST=PatreonUrls.POST;
    private final SourceHttp.Transport http;
    public PatreonConnector(SourceHttp.Transport http){this.http=http;}
    public static String creator(String input){return PatreonUrls.creator(input);}
    public static String url(String ref){return PatreonUrls.url(ref);}
    static void creatorPage(String url,String expected){PatreonUrls.creatorPage(url,expected);}
    public static String postUrl(String ref,String raw,String id){return PatreonUrls.postUrl(ref,raw,id);}
    public SourcePage newest(String ref,String etag,String modified,SourceHttp.Token token)throws IOException {
        SourceHttp.Response response=http.get(url(ref),etag,modified,token);token.check();if(response.status()==304)return new SourcePage(new JSONArray(),etag,modified,0,true);if(response.status()!=200)throw new IOException("Estado HTTP de Patreon no válido.");if(response.bytes().length>SourceHttp.JSON_LIMIT)throw new IOException("Página pública mayor de 2 MiB.");return parse(ref,SourceHttp.utf8(response.bytes()),response.etag(),response.modified());
    }
    public static SourcePage parse(String ref,String html,String etag,String modified)throws IOException {
        if(html.getBytes(java.nio.charset.StandardCharsets.UTF_8).length>SourceHttp.JSON_LIMIT)throw new IOException("Página pública mayor de 2 MiB.");String creator=creator(ref);Document page=Jsoup.parse(html,url(creator));
        Element canonical=page.selectFirst("link[rel=canonical]");if(canonical==null)canonical=page.selectFirst("meta[property=og:url]");if(canonical==null)throw new IOException("Patreon no devolvió una página pública reconocible; se conserva la consulta anterior.");
        try{creatorPage(canonical.hasAttr("href")?canonical.absUrl("href"):canonical.attr("content"),creator);}catch(IllegalArgumentException e){throw new IOException("La página no corresponde al creador consultado.",e);}
        // React sends public card HTML in inert streaming containers. Read those card
        // fragments without running their scripts; ordinary hidden nodes remain excluded.
        for(Element fragment:page.select("div[hidden][id]"))if(fragment.id().matches("S:[A-Za-z0-9]+"))fragment.removeAttr("hidden");
        // No script/bootstrap JSON or session state enters the cache.
        page.select("script,style,noscript,template,[hidden],[aria-hidden=true]").remove();
        LinkedHashMap<String,JSONObject> found=new LinkedHashMap<>();Map<String,Integer> scores=new HashMap<>();int inspected=0;
        for(Element a:page.select("a[href*='/posts/']")) {
            if(++inspected>5000)throw new IOException("Demasiados enlaces en la página pública.");String raw=a.absUrl("href");URI u;Matcher match;
            try{u=SourceHttp.https(raw);match=POST.matcher(u.getPath());if(!match.matches())continue;String id=match.group(2);raw=postUrl(creator,raw,id);}catch(IllegalArgumentException e){continue;}
            String id=match.group(2);Element node=a,card=null;int score=0;
            for(int level=0;level<8 && node!=null;level++,node=node.parent()){if(node.select("h3").size()==1 && node.text().length()<=20000){card=node;score=10;break;}}
            String title="",summary="",date="",precision="unknown";if(card!=null){Element heading=card.selectFirst("h3");title=heading==null?"":heading.text();Element copy=card.clone();copy.select("button,input,svg,nav").remove();summary=copy.text();Element time=card.selectFirst("time[datetime]");if(time!=null){String candidate=time.attr("datetime");try{LocalDate.parse(candidate.substring(0,10));if(candidate.length()<=100){date=candidate;precision="exact";}}catch(Exception ignored){}}}
            if(title.isBlank()){String path=u.getPath(),slug=path.substring(path.lastIndexOf('/')+1).replaceFirst("-?"+Pattern.quote(id)+"$","").replace('-',' ').replace('_',' ').trim();title=slug.isEmpty()?"Patreon #"+id:slug;}
            title=FanboxConnector.clipped(title,300);summary=FanboxConnector.clipped(summary,4000);if(found.containsKey(id) && scores.get(id)>=score)continue;
            try{JSONObject candidate=new JSONObject().put("id",id).put("title",title).put("date",date).put("precision",precision).put("url",raw).put("text","Tarjeta pública; puede ser un adelanto. El cuerpo completo no se obtuvo.\n\n"+summary).put("attachments",new JSONArray()).put("type","public-card").put("partial",true);found.put(id,candidate);scores.put(id,score);}catch(JSONException e){throw new IOException("Tarjeta pública no válida.",e);}
            if(found.size()>100)throw new IOException("Más de 100 tarjetas públicas en la página.");
        }
        if(found.isEmpty())throw new IOException("No hay tarjetas públicas reconocibles. Puede no haber publicaciones visibles o haber cambiado la página; se conserva la consulta anterior.");JSONArray rows=new JSONArray();for(JSONObject row:found.values())rows.put(row);return new SourcePage(rows,SourceHttp.header(etag),SourceHttp.header(modified),0,false);
    }
}
