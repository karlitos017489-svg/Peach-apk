package com.peach.local;

import java.net.*;
import java.util.*;
import java.util.regex.*;

/** URL boundary shared by transport and the public-card parser. */
public final class PatreonUrls {
    private static final Set<String> HOSTS=Set.of("patreon.com","www.patreon.com");
    private static final Set<String> RESERVED=Set.of("posts","join","login","signup","home","explore","api","settings","checkout","messages","search","cw","user");
    static final Pattern POST=Pattern.compile("^(?:(?:/cw)?/([A-Za-z0-9_-]{1,80}))?/posts/(?:[^/?#]*-)?([0-9]{4,30})/?$");
    private PatreonUrls() {}
    public static String creator(String input){String value=input.trim();if(value.startsWith("https://")){URI u=SourceHttp.https(value);if(!HOSTS.contains(u.getHost().toLowerCase(Locale.ROOT)))throw new IllegalArgumentException("Usa una página pública de Patreon.");String path=u.getPath();if(path.equals("/user") || path.equals("/user/")){String query=Objects.toString(u.getRawQuery(),"");if(!query.matches("u=[0-9]{1,20}"))throw new IllegalArgumentException("El enlace de usuario requiere u=ID numérico.");value="user/"+query.substring(2);}else{String[] parts=path.split("/");int start=parts.length>1 && parts[1].equalsIgnoreCase("cw")?2:1;if(parts.length<=start)throw new IllegalArgumentException("Falta el creador de Patreon.");value=parts[start];if(parts.length>start+1 && !(parts.length==start+2 && parts[start+1].equals("posts")))throw new IllegalArgumentException("Usa la página del creador, no una publicación o pantalla de cuenta.");}}
        value=value.toLowerCase(Locale.ROOT);if(value.matches("user/[0-9]{1,20}"))return value;if(!value.matches("[a-z0-9_-]{1,80}") || RESERVED.contains(value))throw new IllegalArgumentException("Identificador de creador Patreon no válido.");return value;}
    public static String url(String ref){String value=creator(ref);return value.startsWith("user/")?"https://www.patreon.com/user?u="+value.substring(5):"https://www.patreon.com/cw/"+value;}
    static void creatorPage(String url,String expected){String found=creator(url),wanted=creator(expected);if(!wanted.startsWith("user/") && !found.equals(wanted))throw new IllegalArgumentException("La redirección corresponde a otro creador.");}
    public static String postUrl(String ref,String raw,String expectedId){try{URI u=SourceHttp.https(raw);if(!HOSTS.contains(u.getHost().toLowerCase(Locale.ROOT)) || u.getRawQuery()!=null)throw new IllegalArgumentException();Matcher m=POST.matcher(u.getPath());if(!m.matches() || !m.group(2).equals(expectedId) || m.group(1)!=null && !creator(ref).startsWith("user/") && !m.group(1).equalsIgnoreCase(creator(ref)))throw new IllegalArgumentException();return "https://www.patreon.com"+u.getRawPath();}catch(Exception e){throw new IllegalArgumentException("Referencia de publicación Patreon no válida.");}}
}
