package com.peach.local;

import java.net.URI;
import java.util.*;

/** Pawchive only; user and service are explicit, with no fallback to another archive. */
public final class PawchiveUrls {
    private PawchiveUrls() {}
    static boolean site(String host){return "pawchive.pw".equalsIgnoreCase(host);}
    static String part(String raw,int max){if(raw==null || !raw.matches("[A-Za-z0-9_.-]{1,"+max+"}") || raw.equals(".") || raw.equals(".."))throw new IllegalArgumentException("Identificador Pawchive no válido.");return raw;}
    static String postId(Object raw){if(!(raw instanceof String) && !(raw instanceof Number))throw new IllegalArgumentException("ID de publicación Pawchive no válido.");return part(String.valueOf(raw),128);}
    public static String creator(String input){
        if(input==null)throw new IllegalArgumentException("Falta servicio/ID de creador Pawchive.");String value=input.trim();
        if(value.startsWith("https://")){URI u=SourceHttp.https(value);if(!site(u.getHost()) || u.getRawQuery()!=null)throw new IllegalArgumentException("Usa la página de un creador Pawchive sin parámetros.");String[] p=u.getRawPath().split("/",-1);if(p.length==5 && p[4].isEmpty())p=Arrays.copyOf(p,4);if(p.length!=4 || !p[2].equals("user"))throw new IllegalArgumentException("Usa la página del creador Pawchive.");value=p[1]+"/"+p[3];}
        String[] p=value.split("/",-1);if(p.length!=2 || !p[0].matches("[a-z0-9_-]{1,32}"))throw new IllegalArgumentException("Escribe servicio/ID, por ejemplo patreon/12345, o la página del creador.");return p[0]+"/"+part(p[1],64);
    }
    public static String page(String ref,int index){String[] p=creator(ref).split("/",2);if(index<0 || index>=5000)throw new IllegalArgumentException("Límite de páginas Pawchive alcanzado.");return "https://pawchive.pw/api/v1/"+p[0]+"/user/"+p[1]+"/posts"+(index==0?"":"?o="+(index*50));}
    public static String detail(String ref,String id){String[] p=creator(ref).split("/",2);return "https://pawchive.pw/api/v1/"+p[0]+"/user/"+p[1]+"/post/"+postId(id);}
    public static String postUrl(String ref,String id){String[] p=creator(ref).split("/",2);return "https://pawchive.pw/"+p[0]+"/user/"+p[1]+"/post/"+postId(id);}
    static void postUrl(String ref,String raw,String id){if(!postUrl(ref,id).equals(raw))throw new IllegalArgumentException("Referencia de publicación Pawchive ajena.");}
    static void api(String raw){URI u=SourceHttp.https(raw);if(!site(u.getHost()))throw new IllegalArgumentException("Host de API Pawchive no válido.");String[] p=u.getRawPath().split("/",-1);if(p.length<7 || !p[1].equals("api") || !p[2].equals("v1") || !p[4].equals("user"))throw new IllegalArgumentException("Ruta de API Pawchive no válida.");String ref=creator(p[3]+"/"+p[5]);if(p.length==7 && p[6].equals("posts")){String q=u.getRawQuery();int index=0;if(q!=null){if(!q.matches("o=[1-9][0-9]{0,5}"))throw new IllegalArgumentException("Página Pawchive no válida.");int offset=Integer.parseInt(q.substring(2));if(offset%50!=0)throw new IllegalArgumentException("Offset Pawchive no válido.");index=offset/50;}if(!page(ref,index).equals(raw))throw new IllegalArgumentException("Página Pawchive no canónica.");}
        else if(p.length==8 && p[6].equals("post") && u.getRawQuery()==null && detail(ref,p[7]).equals(raw))return;else throw new IllegalArgumentException("API Pawchive no admitida.");}
    static String media(String raw){if(raw==null || raw.length()>1000)throw new IllegalArgumentException("Ruta de adjunto Pawchive no válida.");String path=raw.startsWith("/data/")?raw.substring(5):raw;var m=java.util.regex.Pattern.compile("^/([a-f0-9]{2})/([a-f0-9]{2})/([a-f0-9]{64})(?:\\.[A-Za-z0-9]{1,12})?$").matcher(path);if(!m.matches() || !m.group(3).startsWith(m.group(1)+m.group(2)))throw new IllegalArgumentException("Ruta de adjunto Pawchive no válida.");return "https://file.pawchive.pw/data"+path;}
    public static boolean downloadable(String raw){try{URI u=SourceHttp.https(raw);return "file.pawchive.pw".equals(u.getHost()) && u.getRawQuery()==null && raw.equals(media(u.getRawPath()));}catch(IllegalArgumentException e){return false;}}
    static String expectedHash(String url){if(!downloadable(url))throw new IllegalArgumentException("Adjunto Pawchive no admitido.");String path=SourceHttp.https(url).getRawPath(),name=path.substring(path.lastIndexOf('/')+1);return name.substring(0,64);}
    static boolean sameMedia(String original,String next){return downloadable(original) && downloadable(next) && expectedHash(original).equals(expectedHash(next));}

}
