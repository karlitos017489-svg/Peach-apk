package com.peach.local;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import java.io.File;
import java.io.IOException;

/** One worker owns the framework renderer, pages and its seekable descriptor. */
public final class PdfPages implements ReaderSession.Pages {
    private final PdfRenderer renderer;
    public PdfPages(File file) throws IOException {this(file,null);}
    public PdfPages(File file,char[] password) throws IOException {
        ParcelFileDescriptor descriptor=ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY);
        try {if(password!=null){if(android.os.Build.VERSION.SDK_INT<35)throw new IOException("PDF con contraseña requiere Android 15 o posterior.");renderer=Api35.open(descriptor,password);}else renderer=new PdfRenderer(descriptor);}
        catch(IOException|RuntimeException error){descriptor.close();throw error;}
    }
    @Override public int count(){return renderer.getPageCount();}
    @Override public boolean searchable(){return android.os.Build.VERSION.SDK_INT>=35;}
    @Override public int search(int index,String query)throws IOException {
        if(!searchable())throw new IOException("Buscar dentro del PDF requiere Android 15 o posterior.");
        try(PdfRenderer.Page page=renderer.openPage(index)){return Api35.matches(page,query);}
    }
    @androidx.annotation.RequiresApi(35)
    private static final class Api35 {
        static PdfRenderer open(ParcelFileDescriptor fd,char[] password)throws IOException{return new PdfRenderer(fd,new android.graphics.pdf.LoadParams.Builder().setPassword(new String(password)).build());}
        static int matches(PdfRenderer.Page page,String query){return page.searchText(query).size();}
    }
    @Override public Bitmap render(int index,int edge) throws IOException {
        PdfRenderer.Page page=renderer.openPage(index);
        try {
            int width=page.getWidth(),height=page.getHeight();
            if(width<=0 || height<=0 || width>1000000 || height>1000000 || edge<1 || edge>2048)throw new IOException("Dimensiones PDF no compatibles.");
            double scale=(double)edge/Math.max(width,height);Bitmap bitmap=Bitmap.createBitmap(Math.max(1,(int)Math.round(width*scale)),Math.max(1,(int)Math.round(height*scale)),Bitmap.Config.ARGB_8888);
            try {bitmap.eraseColor(Color.WHITE);page.render(bitmap,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);return bitmap;}
            catch(RuntimeException|Error error){bitmap.recycle();throw error;}
        }finally{page.close();}
    }
    @Override public void close(){renderer.close();}
}
