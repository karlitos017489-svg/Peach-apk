package com.peach.local;
/** Binds a reader only. No startup network, session loading or automatic work. */
public final class PeachApplication extends android.app.Application {
 @Override public void onCreate(){super.onCreate();SourceHttp.mediaSessions=site->new SiteSessions(this).read(site);}
 @Override public void onTrimMemory(int level){super.onTrimMemory(level);if(level>=android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW){Thumbnails.clearMemory();UiAppearance.clearWallpaperMemory();}}
}
