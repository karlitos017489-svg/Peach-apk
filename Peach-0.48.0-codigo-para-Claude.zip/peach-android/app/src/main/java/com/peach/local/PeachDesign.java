package com.peach.local;

import android.app.Activity;
import android.content.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import androidx.core.view.*;

/** Shared native design system. Icons always have spoken labels and 48 dp touch targets. */
final class PeachDesign {
    static int dp(Context c,int n){return UiAppearance.dp(c,n);}
    static <T extends View> T role(T view,String role){view.setTag(R.id.design_role,role);finish(view);return view;}
    static Drawable icon(Context c,int id,int color){Drawable d=androidx.appcompat.content.res.AppCompatResources.getDrawable(c,id).mutate();d.setTint(color);d.setBounds(0,0,dp(c,22),dp(c,22));return d;}
    static void finish(View v){
        Context c=v.getContext();String role=String.valueOf(v.getTag(R.id.design_role));
        if(v instanceof TextView t){
            t.setTextColor(role.equals("muted")?UiAppearance.secondary(c):role.equals("accent")||role.equals("nav-on")?UiAppearance.accent(c):UiAppearance.text(c));
            if(role.equals("heading")){t.setTextSize(30);t.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));}
            if(role.equals("section")){t.setTextSize(20);t.setTypeface(null,Typeface.BOLD);}
        }
        if(v instanceof Button b){
            b.setAllCaps(false);b.setMinWidth(dp(c,48));b.setMinHeight(dp(c,48));b.setMinimumWidth(dp(c,48));b.setMinimumHeight(dp(c,48));b.setTextSize(role.startsWith("nav")?11:14);
            b.setGravity(Gravity.CENTER);b.setStateListAnimator(null);b.setBackgroundTintList(null);
            int color=role.equals("primary")?UiAppearance.accent(c):role.equals("nav-on")?(UiAppearance.accent(c)&0x00ffffff)|0x24000000:role.equals("quiet")||role.equals("icon")||role.startsWith("nav")?android.graphics.Color.TRANSPARENT:UiAppearance.surface(c);
            b.setBackground(new RippleDrawable(android.content.res.ColorStateList.valueOf((UiAppearance.accent(c)&0xffffff)|0x33000000),UiAppearance.rounded(c,color,role.startsWith("nav")?22:14),null));
            if(role.equals("primary")){b.setTextColor(UiAppearance.dark(c)?0xff171318:0xffffffff);b.setTypeface(null,Typeface.BOLD);}
            b.setPadding(dp(c,role.equals("icon")?12:14),dp(c,6),dp(c,role.equals("icon")?12:14),dp(c,6));
        }
    }
    static TextView text(Context c,String value,int size,String role){TextView t=new TextView(c);t.setText(value);t.setTextSize(size);role(t,role);return t;}
    static Button action(Context c,String label,String role,View.OnClickListener click){Button b=new Button(c);b.setText(label);role(b,role);b.setOnClickListener(click);return b;}
    static Button iconButton(Context c,int id,String label,View.OnClickListener click){Button b=action(c,"","icon",click);b.setContentDescription(label);b.setCompoundDrawables(icon(c,id,UiAppearance.text(c)),null,null,null);b.setLayoutParams(new LinearLayout.LayoutParams(dp(c,48),dp(c,48)));return b;}
    static void iconButton(Button b,int id,String label){b.setText("");b.setContentDescription(label);role(b,"icon");b.setCompoundDrawables(icon(b.getContext(),id,UiAppearance.text(b.getContext())),null,null,null);}
    static LinearLayout row(Context c){LinearLayout l=new LinearLayout(c);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    static LinearLayout column(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);return l;}
    static void gap(LinearLayout root,int height){View v=new View(root.getContext());root.addView(v,new LinearLayout.LayoutParams(1,dp(root.getContext(),height)));}
    static void insets(Activity a,View root,int padding){WindowCompat.setDecorFitsSystemWindows(a.getWindow(),false);ViewCompat.setOnApplyWindowInsetsListener(root,(v,i)->{var b=i.getInsets(WindowInsetsCompat.Type.systemBars()|WindowInsetsCompat.Type.displayCutout()|WindowInsetsCompat.Type.ime());int p=dp(a,padding);v.setPadding(b.left+p,b.top,b.right+p,b.bottom);return i;});}
    static void navButton(Button b,int icon,String text,boolean active){b.setText(text);role(b,active?"nav-on":"nav");b.setCompoundDrawablePadding(dp(b.getContext(),4));b.setCompoundDrawables(null,icon(b.getContext(),icon,active?UiAppearance.accent(b.getContext()):UiAppearance.secondary(b.getContext())),null,null);b.setContentDescription(text+(active?", sección actual":""));}
    static LinearLayout nav(Activity a,int active){
        LinearLayout bar=row(a);bar.setPadding(dp(a,6),dp(a,5),dp(a,6),dp(a,5));bar.setBackground(UiAppearance.rounded(a,UiAppearance.surface(a),28));
        int[] icons={R.drawable.ic_ui_library,R.drawable.ic_ui_sources,R.drawable.ic_ui_download,R.drawable.ic_ui_settings};String[] names={"Biblioteca","Fuentes","Descargas","Ajustes"};
        Class<?>[] screens={MainActivity.class,SourceBrowserActivity.class,DownloadQueueActivity.class,SettingsActivity.class};
        for(int i=0;i<4;i++){final int n=i;Button b=new Button(a);navButton(b,icons[i],names[i],i==active);bar.addView(b,new LinearLayout.LayoutParams(0,dp(a,60),1));b.setOnClickListener(v->{if(n==active)return;if(n==0){a.startActivity(new Intent(a,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP));a.finish();}else{a.startActivity(new Intent(a,screens[n]));if(!(a instanceof MainActivity))a.finish();}});}
        return bar;
    }
    static void main(Activity a){
        int[] ids={R.id.navLibrary,R.id.navSources,R.id.navDownloads,R.id.navSettings};int[] icons={R.drawable.ic_ui_library,R.drawable.ic_ui_sources,R.drawable.ic_ui_download,R.drawable.ic_ui_settings};String[] names={"Biblioteca","Fuentes","Descargas","Ajustes"};
        for(int i=0;i<4;i++)navButton(a.findViewById(ids[i]),icons[i],names[i],i==0);
        View nav=a.findViewById(R.id.mainNav);nav.setBackground(UiAppearance.rounded(a,UiAppearance.surface(a),28));
        iconButton(a.findViewById(R.id.more),R.drawable.ic_ui_more,"Más opciones de biblioteca");
        iconButton(a.findViewById(R.id.addFolder),R.drawable.ic_ui_plus,"Añadir carpeta");
        Button filters=a.findViewById(R.id.toggleFilters);filters.setText("");filters.setContentDescription("Filtrar biblioteca");role(filters,"icon");filters.setCompoundDrawables(icon(a,R.drawable.ic_ui_filter,UiAppearance.secondary(a)),null,null,null);
        EditText search=a.findViewById(R.id.search);searchBox(search);
    }
    static void searchBox(EditText search){Context c=search.getContext();role(search,"search");search.setTextColor(UiAppearance.text(c));search.setHintTextColor(UiAppearance.secondary(c));search.setBackgroundTintList(null);search.setBackground(UiAppearance.rounded(c,UiAppearance.surface(c),16));search.setPadding(dp(c,16),dp(c,10),dp(c,12),dp(c,10));search.setCompoundDrawables(icon(c,R.drawable.ic_ui_search,UiAppearance.secondary(c)),null,null,null);search.setCompoundDrawablePadding(dp(c,12));search.setTextSize(15);}
    static void player(Activity a,boolean audio){
        View root=a.findViewById(R.id.playerRoot);root.setBackgroundColor(audio?0xff0d0f18:0xff000000);
        iconButton(a.findViewById(R.id.back),R.drawable.ic_ui_back,"Volver");iconButton(a.findViewById(R.id.subtitle),R.drawable.ic_ui_subtitle,"Añadir subtítulo");iconButton(a.findViewById(R.id.fullscreen),R.drawable.ic_ui_fullscreen,"Pantalla completa");iconButton(a.findViewById(R.id.playerFormats),R.drawable.ic_ui_info,"Pistas y compatibilidad");
        iconButton(a.findViewById(R.id.player_volume),R.drawable.ic_ui_volume,"Volumen");
        role(a.findViewById(R.id.playerTitle),"section");role(a.findViewById(R.id.audioInfo),"muted");Button stop=a.findViewById(R.id.audioStop);role(stop,"quiet");
    }
}
