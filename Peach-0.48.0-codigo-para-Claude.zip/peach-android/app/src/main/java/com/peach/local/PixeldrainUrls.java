package com.peach.local;
import java.util.*;
import org.json.*;
/** Official single-file API, never a generic download host or alternate-domain fallback. */
final class PixeldrainUrls {
 static String id(String id){if(id==null||!id.matches("[A-Za-z0-9_-]{6,64}"))throw new IllegalArgumentException("ID Pixeldrain no válido.");return id;}
 static String share(String url){var u=SourceHttp.https(url);if(!u.getHost().equals("pixeldrain.com")||u.getRawQuery()!=null||!u.getRawPath().matches("/u/[A-Za-z0-9_-]{6,64}/?"))throw new IllegalArgumentException("Enlace individual Pixeldrain no admitido.");return id(u.getRawPath().substring(3).replaceFirst("/$",""));}
 static String file(String id){return "https://pixeldrain.com/api/file/"+id(id);}
 static boolean downloadable(String url){try{var u=SourceHttp.https(url);return u.getHost().equals("pixeldrain.com")&&u.getRawQuery()==null&&u.getRawPath().matches("/api/file/[A-Za-z0-9_-]{6,64}");}catch(IllegalArgumentException e){return false;}}
 static List<String> references(PublicationContent c)throws JSONException{Set<String> out=new LinkedHashSet<>();var m=java.util.regex.Pattern.compile("https://pixeldrain\\.com/u/([A-Za-z0-9_-]{6,64})/?(?=$|[\\s<>()\\[\\]{}.,;:!])").matcher(c.text);while(m.find())out.add(id(m.group(1)));JSONArray a=new JSONArray(c.attachments);for(int i=0;i<a.length();i++)try{out.add(share(a.getJSONObject(i).getString("url")));}catch(IllegalArgumentException ignored){}return List.copyOf(out);}
 static String expected(JSONObject a)throws JSONException{String hash=a.optString("expectedSha256","");if(!hash.isEmpty()&&!hash.matches("[a-f0-9]{64}"))throw new JSONException("SHA-256 no válido.");return hash;}
 static void validate(JSONObject a)throws JSONException{String id=id(a.getString("pixeldrainId"));if(!a.getString("url").equals(file(id))||!a.getString("resourceProvider").equals("pixeldrain")||!expected(a).matches("[a-f0-9]{64}"))throw new IllegalArgumentException("Adjunto Pixeldrain no válido.");}
}
