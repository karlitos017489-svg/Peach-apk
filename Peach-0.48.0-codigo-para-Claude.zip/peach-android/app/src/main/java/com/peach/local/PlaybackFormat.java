package com.peach.local;

import androidx.media3.common.*;
import java.util.*;

@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
final class PlaybackFormat {
    private PlaybackFormat() {}
    static String describe(Tracks tracks) {
        List<String> rows=new ArrayList<>();
        for(Tracks.Group group:tracks.getGroups())for(int i=0;i<group.length && rows.size()<64;i++) {
            Format f=group.getTrackFormat(i);String kind=switch(group.getType()){case C.TRACK_TYPE_VIDEO->"Video";case C.TRACK_TYPE_AUDIO->"Audio";case C.TRACK_TYPE_TEXT->"Subtítulos";default->"Otra pista";};
            String row=kind+" · "+safe(f.sampleMimeType);
            if(f.width>0 && f.height>0)row+=" · "+f.width+"×"+f.height;
            if(f.channelCount>0)row+=" · "+f.channelCount+" canales";
            if(f.sampleRate>0)row+=" · "+f.sampleRate+" Hz";
            if(f.codecs!=null)row+=" · "+safe(f.codecs);
            row+=group.isTrackSelected(i)?" · seleccionada":group.isTrackSupported(i)?" · disponible":" · no compatible con el decodificador";
            rows.add(row);
        }
        return (rows.isEmpty()?"Todavía no hay pistas reconocidas. Inicia la reproducción para leerlas.":String.join("\n\n",rows))+"\n\nEl contenedor y el códec son distintos. MP4, MOV, MKV/WebM, AVI, FLV, TS y MPEG compatibles se leen con Media3; la tablet decide qué pistas puede decodificar. WMV/ASF, RMVB e ISO no tienen lector integrado. No hay transcodificación, DRM ni garantía de todos los perfiles. SRT, VTT y ASS/SSA locales; estilos y efectos ASS limitados.";
    }
    private static String safe(String value){if(value==null)return "formato sin declarar";String cleaned=value.replaceAll("[^A-Za-z0-9._/+ ,:-]","");return cleaned.substring(0,Math.min(cleaned.length(),100));}
}
