package com.peach.local;

import androidx.media3.common.PlaybackException;

/** Diagnostics contain no URI, source URL, credential or private filename. */
final class PlaybackMessages {
    private PlaybackMessages() {}
    static String error(PlaybackException error) {
        String explanation=switch(error.errorCode) {
            case PlaybackException.ERROR_CODE_IO_NO_PERMISSION -> "Android no permite leer este archivo. Vuelve a seleccionarlo con Abrir video local o autoriza su carpeta.";
            case PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND -> "El archivo fue movido, borrado o su proveedor no está disponible. Vuelve a seleccionarlo.";
            case PlaybackException.ERROR_CODE_IO_READ_POSITION_OUT_OF_RANGE -> "No se pudo leer la posición solicitada. El archivo puede estar incompleto o su proveedor no admite esa lectura.";
            case PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED -> "El contenedor del video no se pudo interpretar. Puede estar incompleto o dañado.";
            case PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED -> "El archivo no contiene un formato de video reconocido por el reproductor.";
            case PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES -> "El códec o sus características no son compatibles con el decodificador de esta tablet.";
            case PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED,PlaybackException.ERROR_CODE_DECODING_FAILED -> "No se pudo iniciar o mantener el decodificador de video/audio. El formato puede superar sus capacidades.";
            default -> "No se pudo reproducir el archivo. Comprueba que sea local, esté completo y siga accesible.";
        };
        return explanation+"\nCódigo: "+error.getErrorCodeName()+" ("+error.errorCode+").";
    }
}
