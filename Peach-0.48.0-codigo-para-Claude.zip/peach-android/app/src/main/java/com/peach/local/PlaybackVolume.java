package com.peach.local;

import android.content.Context;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.media3.common.Player;
import java.util.function.Supplier;

/** Per-player attenuation, independent of system/hardware volume and other apps. */
final class PlaybackVolume {
    static float saved(Context c){return Math.max(0,Math.min(1,c.getSharedPreferences("playback-volume",Context.MODE_PRIVATE).getFloat("level",1)));}
    static AlertDialog show(Context context,Supplier<Player> source){
        return show(context,source,null);
    }
    static AlertDialog show(Context context,Supplier<Player> source,android.view.View anchor){
        Player player=source.get();if(player==null||!player.isCommandAvailable(Player.COMMAND_SET_VOLUME)){Toast.makeText(context,"El control de volumen estará disponible al iniciar el reproductor.",Toast.LENGTH_SHORT).show();return null;}
        LinearLayout root=new LinearLayout(context);root.setOrientation(LinearLayout.VERTICAL);int pad=UiAppearance.dp(context,20);root.setPadding(pad,pad,pad,pad);
        TextView value=new TextView(context);root.addView(value);SeekBar seek=new SeekBar(context);seek.setId(R.id.volume_level);seek.setMax(100);seek.setContentDescription("Volumen del reproductor, de 0 a 100 por ciento");root.addView(seek);
        Button mute=new Button(context);mute.setId(R.id.volume_mute);root.addView(mute);float[] previous={Math.max(.1f,context.getSharedPreferences("playback-volume",Context.MODE_PRIVATE).getFloat("unmuted",1))};
        Runnable update=()->{float level=player.getVolume();seek.setProgress(Math.round(level*100));value.setText("Volumen: "+Math.round(level*100)+" %");mute.setText(level==0?"Restaurar sonido":"Silenciar");};
        java.util.function.Consumer<Float> apply=level->{if(source.get()!=player)return;float v=Math.max(0,Math.min(1,level));if(v>0)previous[0]=v;player.setVolume(v);var prefs=context.getSharedPreferences("playback-volume",Context.MODE_PRIVATE).edit().putFloat("level",v);if(v>0)prefs.putFloat("unmuted",v);prefs.apply();update.run();};
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}public void onProgressChanged(SeekBar s,int p,boolean user){if(user)apply.accept(p/100f);}});
        mute.setOnClickListener(v->apply.accept(player.getVolume()==0?previous[0]:0));
        Player.Listener listener=new Player.Listener(){@Override public void onVolumeChanged(float v){update.run();}};
        AlertDialog dialog=new AlertDialog.Builder(context).setView(root).create();dialog.setOnDismissListener(d->player.removeListener(listener));player.addListener(listener);update.run();dialog.show();UiAppearance.polish(root);
        android.view.Window window=dialog.getWindow();if(window!=null){window.setBackgroundDrawable(UiAppearance.rounded(context,UiAppearance.surface(context),22));window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);window.setLayout(Math.min(UiAppearance.dp(context,280),context.getResources().getDisplayMetrics().widthPixels-UiAppearance.dp(context,32)),-2);if(anchor!=null){int[] xy=new int[2];anchor.getLocationOnScreen(xy);android.view.WindowManager.LayoutParams params=window.getAttributes();params.gravity=android.view.Gravity.TOP|android.view.Gravity.END;params.x=UiAppearance.dp(context,16);params.y=xy[1]+anchor.getHeight()+UiAppearance.dp(context,6);window.setAttributes(params);}}
        return dialog;
    }
}
