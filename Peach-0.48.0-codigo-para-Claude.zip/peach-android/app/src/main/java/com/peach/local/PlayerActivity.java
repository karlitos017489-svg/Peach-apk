package com.peach.local;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public final class PlayerActivity extends PeachActivity {
    private androidx.appcompat.app.AlertDialog volumeDialog;
    private ExoPlayer player;private SubtitleSources subtitleSources;
    private PlayerView playerView;
    private LibraryDatabase db;
    private MediaEntry media;
    private boolean started,fullscreen,ready=true,recorded,localVideo;
    private long resume=-1;
    private String extra="[]";
    private UsageTracker history;
    private SourceVideoStream stream;
    private int streamWidth,streamHeight;
    private List<MediaEntry> queue=List.of();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable checkpoint=new Runnable() {
        @Override public void run() {
            saveProgress(player!=null && player.getPlaybackState()==Player.STATE_ENDED);
            handler.postDelayed(this,5000);
        }
    };
    private final ActivityResultLauncher<Intent> subtitlePicker=registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(),result -> {
            if (result.getResultCode()!=RESULT_OK || result.getData()==null || media==null) return;
            Intent data=result.getData(); Uri uri=data.getData();
            if (uri==null || !"content".equals(uri.getScheme())) return;
            try {
                String name="";
                try (var cursor=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE},null,null,null)) {
                    if (cursor!=null && cursor.moveToFirst()) {
                        name=cursor.getString(0);
                        if (!cursor.isNull(1) && cursor.getLong(1)>8*1024*1024)
                            throw new IllegalArgumentException();
                    }
                }
                if (name==null || !MediaRules.isSubtitle(name)) { error("Elige un subtítulo SRT, VTT, ASS o SSA."); return; }
                if ((data.getFlags()&Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)!=0)
                    getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);
                String selectedName=name;
                new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Codificación del subtítulo")
                    .setItems(new String[]{"Unicode: UTF-8 / UTF-16 con BOM", "Windows-1252 (español antiguo)"},(dialog,which)->{
                        try{JSONArray array=new JSONArray();JSONObject track=new JSONObject();track.put("uri",uri.toString());track.put("name",selectedName);track.put("encoding",which==0?"auto":"windows-1252");array.put(track);extra=array.toString();
                            getSharedPreferences("subtitles",MODE_PRIVATE).edit().putString(media.id,extra).apply();
                            if(player!=null){resume=player.getCurrentPosition();ready=player.getPlayWhenReady();release();initialize();}
                        }catch(Exception e){error("No se pudo añadir el subtítulo.");}
                    }).setNegativeButton("Cancelar",null).show();
            } catch (Exception e) { error("No se pudo abrir ese subtítulo. Elige un archivo local de hasta 8 MB."); }
        });
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_player);PeachDesign.player(this,false);
        findViewById(R.id.player_volume).setOnClickListener(v->volumeDialog=PlaybackVolume.show(this,()->player,v));
        db=LibraryDatabase.get(this); playerView=findViewById(R.id.player);
        history=new UsageTracker(db,state);
        playerView.setUseArtwork(true);playerView.setControllerShowTimeoutMs(3000);
        playerView.setControllerVisibilityListener((androidx.media3.ui.PlayerView.ControllerVisibilityListener)visibility->{findViewById(R.id.player_volume).setVisibility(visibility);if(!fullscreen)findViewById(R.id.playerBar).setVisibility(visibility);});
        playerView.setDefaultArtwork(androidx.appcompat.content.res.AppCompatResources.getDrawable(this,R.drawable.ic_peach));
        playerView.setShowSubtitleButton(true);
        playerView.setShowNextButton(true);playerView.setShowPreviousButton(true);
        WindowCompat.setDecorFitsSystemWindows(getWindow(),false);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.playerRoot),(v,insets)-> {
            Insets bars=insets.getInsets(WindowInsetsCompat.Type.systemBars()|WindowInsetsCompat.Type.displayCutout());
            v.setPadding(bars.left,bars.top,bars.right,bars.bottom); return insets;
        });
        if (state!=null) {
            resume=state.getLong("position",-1); ready=state.getBoolean("ready",true);
            fullscreen=state.getBoolean("fullscreen"); recorded=state.getBoolean("recorded");
        }
        findViewById(R.id.back).setOnClickListener(v->finish());
        findViewById(R.id.playerFormats).setOnClickListener(v->new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Pistas y compatibilidad").setMessage(PlaybackFormat.describe(player==null?androidx.media3.common.Tracks.EMPTY:player.getCurrentTracks())).setPositiveButton("Cerrar",null).show());
        findViewById(R.id.fullscreen).setOnClickListener(v->{ fullscreen=!fullscreen; applyFullscreen(); });
        playerView.setFullscreenButtonClickListener(value->{ fullscreen=value; applyFullscreen(); });
        findViewById(R.id.subtitle).setOnClickListener(v->subtitlePicker.launch(new Intent(Intent.ACTION_OPEN_DOCUMENT)
            .setType("*/*").addCategory(Intent.CATEGORY_OPENABLE)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)));
        if(SourceVideoStream.requested(getIntent())) {
            localVideo=true;((TextView)findViewById(R.id.playerTitle)).setText("Preparando reproducción en línea…");
            stream=new androidx.lifecycle.ViewModelProvider(this).get(SourceVideoStream.class);
            stream.updates.observe(this,value->{if(isDestroyed()||isFinishing())return;if(stream.media!=null){media=stream.media;queue=List.of(media);showCurrent();if(resume<0)resume=0;if(started)initialize();}else if(!stream.busy&&!stream.error.isEmpty())error(stream.error);});
            stream.load(getIntent().getStringExtra(SourceVideoStream.PUBLICATION),getIntent().getStringExtra(SourceVideoStream.KEY));return;
        }
        if(SourceVideoPlayback.requested(getIntent())) {
            localVideo=true;
            ((TextView)findViewById(R.id.playerTitle)).setText("Comprobando video preparado…");
            SourceVideoPlayback prepared=new androidx.lifecycle.ViewModelProvider(this).get(SourceVideoPlayback.class);
            prepared.updates.observe(this,value->{
                if(isDestroyed()||isFinishing())return;
                if(prepared.media!=null){media=prepared.media;queue=List.of(media);showCurrent();if(resume<0)resume=0;if(started)initialize();}
                else if(!prepared.busy&&!prepared.error.isEmpty())error(prepared.error);
            });
            prepared.load(getIntent().getStringExtra(SourceVideoPlayback.PUBLICATION),getIntent().getStringExtra(SourceVideoPlayback.KEY));return;
        }
        MediaEntry local=SourceFiles.localVideo(getIntent());
        if(getIntent().getBooleanExtra("localVideo",false)) {
            if(local==null){error("Elige un archivo local autorizado.");return;}
            localVideo=true;media=local;queue=List.of(media);showCurrent();if(resume<0)resume=0;return;
        }
        String id=state==null?getIntent().getStringExtra("mediaId"):state.getString("currentId",getIntent().getStringExtra("mediaId"));
        if (id==null) { finish(); return; }
        history.prepare(id);
        LibraryDatabase.IO.execute(()-> {
            MediaEntry loaded=db.library().get(id);
            String listId=getIntent().getStringExtra("playlistId");
            List<MediaEntry> members=listId==null || listId.isEmpty()?new ArrayList<>():db.library().playlistMedia(listId);
            if(loaded!=null && MediaRules.AUDIO.equals(loaded.mediaType) && (listId==null || listId.isEmpty()) && extra("group").isEmpty())
                members=LibraryView.select(EntityIndex.select(db.library(),CatalogIndex.select(db.library().allMedia(),extra("facet"),extra("term"),"",List.of()),extra("entityId")),extra("query"),getIntent().getIntExtra("filter",0),extra("root"),
                    extra("folder"),"",List.of(),getIntent().getIntExtra("order",0),MediaRules.AUDIO);
            List<MediaEntry> playable=loaded==null?List.of():MediaQueues.select(members,loaded,false);
            runOnUiThread(()-> {
                if (isFinishing() || isDestroyed()) return;
                if (loaded==null || playable.isEmpty()) { error("Ese archivo no se puede abrir en el reproductor."); return; }
                queue=playable;media=playable.stream().filter(m->m.id.equals(id)).findFirst().orElse(loaded);
                extra=getSharedPreferences("subtitles",MODE_PRIVATE).getString(media.id,"[]");
                showCurrent();
                if (resume<0) resume=media.position;
                if (started) initialize();
            });
        });
    }
    private String extra(String key) {String value=getIntent().getStringExtra(key);return value==null?"":value;}
    private void showCurrent() {
        if(media==null)return;
        boolean audio=MediaRules.AUDIO.equals(media.mediaType);
        ((TextView)findViewById(R.id.playerTitle)).setText(media.displayTitle());
        findViewById(R.id.subtitle).setVisibility(audio||stream!=null?View.GONE:View.VISIBLE);
        TextView info=findViewById(R.id.audioInfo);info.setVisibility(audio||stream!=null?View.VISIBLE:View.GONE);
        info.setText(stream==null?"Audio · "+media.name:"En línea · "+(player==null||player.getPlaybackState()==Player.STATE_BUFFERING?"Cargando…":player.getPlaybackState()==Player.STATE_ENDED?"Finalizado":player.getPlayWhenReady()?"Listo":"Pausado")+(streamWidth>0&&streamHeight>0?" · "+streamWidth+"×"+streamHeight:""));
        if(player!=null && player.isPlaying() && !audio)getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
    private void initialize() {
        if (media==null || player!=null) return;
        try {
            subtitleSources=new SubtitleSources(this);
            ExoPlayer.Builder builder=new ExoPlayer.Builder(this,new androidx.media3.exoplayer.DefaultRenderersFactory(this).setEnableDecoderFallback(true));
            if(stream!=null){playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS);builder.setLoadControl(new androidx.media3.exoplayer.DefaultLoadControl.Builder().setBufferDurationsMs(5000,15000,1000,2000).setTargetBufferBytes(32*1024*1024).setPrioritizeTimeOverSizeThresholds(false).setBackBuffer(0,false).build());}
            if(stream==null)builder.setMediaSourceFactory(new androidx.media3.exoplayer.source.DefaultMediaSourceFactory(subtitleSources));
            player=builder.build();
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                .setContentType(MediaRules.AUDIO.equals(media.mediaType)?C.AUDIO_CONTENT_TYPE_MUSIC:C.AUDIO_CONTENT_TYPE_MOVIE).build(),true);
            player.setHandleAudioBecomingNoisy(true);
            player.setVolume(PlaybackVolume.saved(this));playerView.setPlayer(player);
            ExoPlayer attached=player;
            player.addListener(new Player.Listener() {
                @Override public void onPlayerError(PlaybackException e) {
                    if(player!=attached)return;
                    history.touch("error");
                    error(stream==null?PlaybackMessages.error(e):SourceVideoStream.message(e));
                }
                @Override public void onPlaybackStateChanged(int state) {
                    if(player!=attached)return;
                    if(stream!=null)showCurrent();
                    if (state==Player.STATE_READY) {
                        findViewById(R.id.playerError).setVisibility(View.GONE);
                        if (player.getDuration()>0) media.duration=player.getDuration();recordCurrent();
                    }
                    if (state==Player.STATE_ENDED) saveProgress(true);
                }
                @Override public void onIsPlayingChanged(boolean playing) {
                    if(player!=attached)return;
                    if(stream!=null)showCurrent();
                    if (playing) recordCurrent();
                    if (playing && !MediaRules.AUDIO.equals(media.mediaType)) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                }
                @Override public void onVideoSizeChanged(androidx.media3.common.VideoSize size){if(player!=attached||stream==null)return;streamWidth=size.width;streamHeight=size.height;showCurrent();}
                @Override public void onMediaItemTransition(MediaItem item,int reason) {
                    if(player!=attached)return;
                    if (item==null) return;
                    for (MediaEntry candidate:queue) if (candidate.id.equals(item.mediaId)) {
                        if (!media.id.equals(candidate.id)) {history.finish();recorded=false;resume=0;}
                        media=candidate;if (player.getDuration()>0) media.duration=player.getDuration();
                        showCurrent();
                        if (player.getPlaybackState()==Player.STATE_READY) recordCurrent();
                        break;
                    }
                }
                @Override public void onPositionDiscontinuity(Player.PositionInfo oldPosition,Player.PositionInfo newPosition,int reason) {
                    if(player!=attached)return;
                    if (oldPosition.mediaItem==null) return;
                    for (MediaEntry previous:queue) if (previous.id.equals(oldPosition.mediaItem.mediaId)) {
                        boolean ended=reason==Player.DISCONTINUITY_REASON_AUTO_TRANSITION;
                        long position=ended?0:Math.max(0,oldPosition.positionMs),duration=previous.duration;
                        boolean watched=ended || MediaRules.watchedByProgress(position,duration);
                        String previousId=previous.id;
                        if(!localVideo)LibraryDatabase.IO.execute(()->db.library().progress(previousId,position,duration,System.currentTimeMillis(),watched));
                        if(history.matches(previousId)){history.checkpoint(position,duration,"",0,0,ended?"ended":"paused",ended);if(newPosition.mediaItem==null||!previousId.equals(newPosition.mediaItem.mediaId))history.finish();}
                        break;
                    }
                }
            });
            if(stream!=null){stream.session.resume();var source=new androidx.media3.exoplayer.source.ProgressiveMediaSource.Factory(()->new StreamDataSource(stream.session)).setLoadErrorHandlingPolicy(new SourceVideoStream.NoRetry()).createMediaSource(new MediaItem.Builder().setMediaId(media.id).setUri(Uri.parse(media.uri)).build());
                player.setMediaSource(source,Math.max(0,resume));player.prepare();player.setPlayWhenReady(ready);handler.postDelayed(checkpoint,5000);applyFullscreen();return;}
            List<MediaItem> items=new ArrayList<>();int start=0;
            for (MediaEntry candidate:queue) {
                if (candidate.id.equals(media.id)) start=items.size();
                List<MediaItem.SubtitleConfiguration> subtitles=new ArrayList<>();
                String manual=getSharedPreferences("subtitles",MODE_PRIVATE).getString(candidate.id,"[]");
                if(MediaRules.VIDEO.equals(candidate.mediaType)) {
                    appendSubtitles(subtitles,manual,true);appendSubtitles(subtitles,candidate.subtitles,subtitles.isEmpty());
                }
                items.add(new MediaItem.Builder().setMediaId(candidate.id).setUri(Uri.parse(candidate.uri))
                    .setMediaMetadata(new androidx.media3.common.MediaMetadata.Builder().setTitle(candidate.displayTitle()).build())
                    .setSubtitleConfigurations(subtitles).build());
            }
            player.setMediaItems(items,start,Math.max(0,resume)); player.prepare(); player.setPlayWhenReady(ready);
            handler.postDelayed(checkpoint,5000); applyFullscreen();
        } catch (Exception e) { release(); error("No se pudo iniciar el reproductor."); }
    }
    private void recordCurrent() {
        if (media==null || localVideo) return;
        history.open(media,MediaRules.AUDIO.equals(media.mediaType)?"audio":"video");
        if(recorded)return;
        recorded=true;String id=media.id;
        LibraryDatabase.IO.execute(()->db.library().recordPlay(id,System.currentTimeMillis()));
    }
    private void appendSubtitles(List<MediaItem.SubtitleConfiguration> target,String json,boolean defaultFirst) {
        try {
            JSONArray tracks=new JSONArray(json);
            for (int i=0;i<tracks.length();i++) {
                JSONObject track=tracks.getJSONObject(i); Uri uri=Uri.parse(track.getString("uri"));
                if (!"content".equals(uri.getScheme())) continue;
                String name=track.getString("name");
                target.add(new MediaItem.SubtitleConfiguration.Builder(subtitleSources.register(uri,track.optString("encoding","auto"))).setMimeType(MediaRules.subtitleMime(name))
                    .setLabel(name).setSelectionFlags(defaultFirst && i==0?C.SELECTION_FLAG_DEFAULT:0).build());
            }
        } catch (Exception ignored) { /* Invalid saved track metadata does not prevent video playback. */ }
    }
    private void saveProgress(boolean ended) {
        if (player==null || media==null) return;
        long position=Math.max(0,player.getCurrentPosition()),duration=player.getDuration()>0?player.getDuration():media.duration;
        boolean watched=ended || MediaRules.watchedByProgress(position,duration);
        if (ended) position=0;
        resume=position; media.position=position; media.duration=duration;
        String id=media.id; long savedPosition=position;
        if(!localVideo)LibraryDatabase.IO.execute(()->db.library().progress(id,savedPosition,duration,System.currentTimeMillis(),watched));
        if(history.matches(id))history.checkpoint(savedPosition,duration,"",0,0,ended?"ended":player.isPlaying()?"active":"paused",ended);
    }
    private void release() {
        handler.removeCallbacks(checkpoint);
        if (player!=null) {
            ready=player.getPlayWhenReady(); saveProgress(player.getPlaybackState()==Player.STATE_ENDED);
            playerView.setPlayer(null); player.release(); player=null;
        }
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
    private void applyFullscreen() {
        WindowInsetsControllerCompat controller=WindowCompat.getInsetsController(getWindow(),getWindow().getDecorView());
        controller.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        if (fullscreen) controller.hide(WindowInsetsCompat.Type.systemBars()); else controller.show(WindowInsetsCompat.Type.systemBars());
        findViewById(R.id.playerBar).setVisibility(fullscreen?View.GONE:View.VISIBLE);
    }
    private void error(String message) {
        TextView error=findViewById(R.id.playerError); error.setText(message); error.setVisibility(View.VISIBLE);
    }
    @Override protected void onStart() { super.onStart(); started=true; initialize(); }
    @Override protected void onStop() { if(volumeDialog!=null){volumeDialog.dismiss();volumeDialog=null;}started=false;if(stream!=null)stream.pause();release();history.touch("paused"); super.onStop(); }
    @Override protected void onDestroy(){if(!isChangingConfigurations())history.finish();super.onDestroy();}
    @Override protected void onSaveInstanceState(Bundle state) {
        state.putLong("position",player==null?resume:player.getCurrentPosition());
        state.putBoolean("ready",player==null?ready:player.getPlayWhenReady());
        state.putBoolean("fullscreen",fullscreen); state.putBoolean("recorded",recorded);history.save(state); super.onSaveInstanceState(state);
        if (media!=null) state.putString("currentId",media.id);
    }
}
