package com.peach.local;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "playlists")
public class Playlist {
    @PrimaryKey @NonNull public String id = "";
    @NonNull public String name = "";
    public long createdAt;
}
