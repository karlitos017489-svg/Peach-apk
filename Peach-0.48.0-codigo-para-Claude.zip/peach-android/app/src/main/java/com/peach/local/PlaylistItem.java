package com.peach.local;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;

@Entity(tableName = "playlist_items", primaryKeys = {"playlistId", "mediaId"},
    foreignKeys = {
        @ForeignKey(entity=Playlist.class,parentColumns="id",childColumns="playlistId",onDelete=ForeignKey.CASCADE),
        @ForeignKey(entity=MediaEntry.class,parentColumns="id",childColumns="mediaId",onDelete=ForeignKey.CASCADE)
    }, indices={@Index("mediaId")})
public class PlaylistItem {
    @NonNull public String playlistId = "";
    @NonNull public String mediaId = "";
    public int position;
}
