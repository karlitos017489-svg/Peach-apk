package com.peach.local;

import java.util.Collections;
import java.util.List;
import java.util.UUID;

public final class PlaylistStore {
    private final LibraryDatabase db;
    public PlaylistStore(LibraryDatabase db) { this.db=db; }
    public static String validName(String input,int maximum) {
        String name=input.trim();
        if (name.isEmpty() || name.length()>maximum) throw new IllegalArgumentException("Nombre vacío o demasiado largo");
        return name;
    }
    public String create(String name) {
        Playlist list=new Playlist();list.id=UUID.randomUUID().toString();
        list.name=validName(name,80);list.createdAt=System.currentTimeMillis();
        db.library().insertPlaylist(list);return list.id;
    }
    public void rename(String id,String name) { db.library().renamePlaylist(id,validName(name,80)); }
    public void add(String playlistId,String mediaId) {
        db.runInTransaction(()-> {
            if (db.library().playlist(playlistId)==null || db.library().get(mediaId)==null)
                throw new IllegalArgumentException("Lista o video no disponible");
            PlaylistItem item=new PlaylistItem();item.playlistId=playlistId;item.mediaId=mediaId;
            item.position=db.library().nextPlaylistPosition(playlistId);
            db.library().insertPlaylistItem(item);
        });
    }
    public void move(String playlistId,String mediaId,int direction) {
        if (direction!=-1 && direction!=1) throw new IllegalArgumentException("Dirección inválida");
        db.runInTransaction(()-> {
            List<PlaylistItem> items=db.library().playlistItems(playlistId);
            int index=-1;
            for (int i=0;i<items.size();i++) if (items.get(i).mediaId.equals(mediaId)) index=i;
            if (index<0 || index+direction<0 || index+direction>=items.size()) return;
            Collections.swap(items,index,index+direction);
            for (int i=0;i<items.size();i++) db.library().playlistPosition(playlistId,items.get(i).mediaId,i);
        });
    }
}
