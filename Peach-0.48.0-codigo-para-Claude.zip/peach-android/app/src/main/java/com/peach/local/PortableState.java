package com.peach.local;

import android.content.Context;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;

/** Metadata exchange. Android URI grants, credentials, files and operational journals never travel. */
final class PortableState {
    static final List<String> SECTIONS=List.of("items","playlists","groups","entities","aliases","entityLinks","entityReferences","wants","readerProgress","catalogSnapshots","memberships","wantTracking","publications","sources","publicationContent","usageSessions");
    static final Set<String> METADATA=Set.of("mediaId","title","tags","actors","studio","plot","year","nfoDetails","addedAt");
    record Snapshot(JSONObject state,JSONArray metadata,JSONArray media,JSONArray roots,String guard){Snapshot(JSONObject state,JSONArray metadata,JSONArray media,JSONArray roots){this(state,metadata,media,roots,"");}String stamp()throws Exception{return ExchangeJson.hash(ExchangeJson.canonical(new JSONObject().put("state",state).put("metadata",metadata).put("media",media).put("roots",roots).put("guard",guard)));}}
    static final class Packet {
        final String peer,label,digest,encoded;final long sequence;final JSONObject data;
        Packet(JSONObject object)throws Exception {
            ExchangeJson.keys(object,Set.of("format","version","peer","label","packet","createdAt","sequence","data","sha256"));
            if(!"peach-local-exchange".equals(object.opt("format")) || ExchangeJson.integer(object,"version")!=1)throw new IOException("Formato de intercambio incompatible.");
            sequence=ExchangeJson.integer(object,"sequence");if(sequence<1 || sequence>9000000000000000L)throw new IOException("Versión de origen inválida.");
            peer=ExchangeJson.text(object,"peer",36);UsageStore.uuid(peer);UsageStore.uuid(ExchangeJson.text(object,"packet",36));ExchangeJson.integer(object,"createdAt");label=PlaylistStore.validName(ExchangeJson.text(object,"label",80),80);
            data=ExchangeJson.copy(object.getJSONObject("data"));ExchangeJson.keys(data,Set.of("state","metadata","media","roots"));digest=ExchangeJson.text(object,"sha256",64);
            if(!digest.equals(ExchangeJson.hash(ExchangeJson.canonical(data))))throw new IOException("El intercambio cambió o está incompleto (SHA-256).");
            encoded=ExchangeJson.canonical(object);if(encoded.getBytes(StandardCharsets.UTF_8).length>ExchangeJson.MAX)throw new IOException("Intercambio mayor de 16 MiB.");validateShape();
        }
        private void validateShape()throws Exception {
            JSONObject state=data.getJSONObject("state");Set<String> keys=new HashSet<>(SECTIONS);keys.addAll(Set.of("format","version"));ExchangeJson.keys(state,keys);
            ExchangeSchema.validate(state);
            if(!"peach-local-state".equals(state.opt("format")) || ExchangeJson.integer(state,"version")!=19)throw new IOException("Esta entrega intercambia el estado de copia 19.");
            JSONArray media=data.getJSONArray("media"),roots=data.getJSONArray("roots"),metadata=data.getJSONArray("metadata");if(media.length()>50000 || roots.length()>1000 || metadata.length()!=media.length())throw new IOException("Inventario de intercambio fuera de límites.");
            Set<String> rootIds=new HashSet<>(),ids=new HashSet<>(),metaIds=new HashSet<>();
            for(int i=0;i<roots.length();i++){JSONObject r=roots.getJSONObject(i);ExchangeJson.keys(r,Set.of("id","label"));String id=ExchangeJson.text(r,"id",66);if(!id.matches("r-[a-f0-9]{64}") || !rootIds.add(id))throw new IOException("Carpeta de intercambio inválida.");ExchangeJson.text(r,"label",300);}
            for(int i=0;i<media.length();i++){JSONObject m=media.getJSONObject(i);ExchangeJson.keys(m,Set.of("id","root","path","name","bytes","missing"));String id=ExchangeJson.text(m,"id",66);if(!id.matches("m-[a-f0-9]{64}") || !ids.add(id) || !rootIds.contains(m.getString("root")) || !(m.opt("missing") instanceof Boolean))throw new IOException("Documento de intercambio inválido.");safePath(ExchangeJson.text(m,"path",4096));String name=ExchangeJson.text(m,"name",4096);if(name.contains("/") || name.contains("\\") || name.isBlank())throw new IOException("Nombre de documento inválido.");ExchangeJson.integer(m,"bytes");}
            for(int i=0;i<metadata.length();i++){JSONObject m=metadata.getJSONObject(i);validateMetadata(m);if(!ids.contains(m.getString("mediaId")) || !metaIds.add(m.getString("mediaId")))throw new IOException("Metadatos duplicados o sin documento.");}
            Map<String,String> names=new HashMap<>();for(int i=0;i<media.length();i++)names.put(media.getJSONObject(i).getString("id"),media.getJSONObject(i).getString("name"));
            for(String section:List.of("readerProgress","usageSessions")){JSONArray rows=state.getJSONArray(section);for(int i=0;i<rows.length();i++){JSONObject row=rows.getJSONObject(i);String name=names.get(row.getString("mediaId"));if(name==null || section.equals("readerProgress") && !DocumentRules.readable(name) || section.equals("usageSessions") && (row.getString("kind").equals("reading")?!DocumentRules.readable(name):!row.getString("kind").equals(MediaRules.type(name))))throw new IOException("Estado de uso sin documento de su familia.");}}
            Set<String> stateIds=new HashSet<>();JSONArray items=state.getJSONArray("items");for(int i=0;i<items.length();i++){String id=items.getJSONObject(i).getString("id");if(!ids.contains(id) || !stateIds.add(id))throw new IOException("Estado sin documento o duplicado.");}if(!stateIds.equals(ids))throw new IOException("Falta estado de un documento.");
            if(ExchangeJson.canonical(state).getBytes(StandardCharsets.UTF_8).length>8*1024*1024)throw new IOException("Estado de intercambio mayor de 8 MiB.");
        }
    }
    static Snapshot capture(LibraryDatabase db)throws Exception {
        Snapshot[] result={null};Exception[] error={null};db.runInTransaction(()->{try{
            var out=new ByteArrayOutputStream();BackupStore.write(db.library(),out);JSONObject state=new JSONObject(out.toString("UTF-8"));JSONArray metadata=new JSONArray(),media=new JSONArray(),roots=new JSONArray(),inventory=new JSONArray();Map<String,String> bases=new HashMap<>();Set<String> rootIds=new HashSet<>();
            for(LibraryRoot r:db.library().roots()){inventory.put(new JSONObject().put("id","root:"+r.uri).put("root",r.uri).put("generation",r.generation).put("state",r.state));roots.put(new JSONObject().put("id",r.uri).put("label",r.label));rootIds.add(r.uri);String base=CatalogBridge.scanBase(db.library(),r.uri);bases.put(r.uri,base.isEmpty()?r.label:base);}
            for(MediaEntry m:db.library().allMedia()){
                ExchangeJson.check();inventory.put(new JSONObject().put("id",m.id).put("uri",m.uri).put("poster",m.poster).put("subtitles",m.subtitles).put("modified",m.modified).put("generation",m.generation));if(rootIds.add(m.root))roots.put(new JSONObject().put("id",m.root).put("label","Carpeta sin registro"));
                String path=CatalogBridge.relative(m,bases.getOrDefault(m.root,""));if(path.isEmpty())path=m.name;safePath(path);
                media.put(new JSONObject().put("id",m.id).put("root",m.root).put("path",path).put("name",m.name).put("bytes",Math.max(0,m.bytes)).put("missing",m.missing));
                metadata.put(new JSONObject().put("mediaId",m.id).put("title",m.title).put("tags",m.tags).put("actors",m.actors).put("studio",m.studio).put("plot",m.plot).put("year",m.year).put("nfoDetails",m.nfoDetails).put("addedAt",m.addedAt));
            }
            sort(media,"id");sort(metadata,"mediaId");sort(roots,"id");sort(inventory,"id");result[0]=new Snapshot(state,metadata,media,roots,ExchangeJson.hash(ExchangeJson.canonical(inventory)));
        }catch(Exception e){error[0]=e;}});if(error[0]!=null)throw error[0];return result[0];
    }
    static Packet export(Snapshot raw,String peer,String label)throws Exception {return export(raw,peer,label,1);}
    static Packet export(Snapshot raw,String peer,String label,long sequence)throws Exception {
        Map<String,String> ids=new HashMap<>(),roots=new HashMap<>();for(int i=0;i<raw.media.length();i++){String id=raw.media.getJSONObject(i).getString("id");ids.put(id,"m-"+ExchangeJson.hash(id));}for(int i=0;i<raw.roots.length();i++){String id=raw.roots.getJSONObject(i).getString("id");roots.put(id,"r-"+ExchangeJson.hash(id));}
        JSONObject state=remap(raw.state,ids);JSONArray metadata=copyArray(raw.metadata),media=copyArray(raw.media),rootRows=copyArray(raw.roots);
        for(int i=0;i<metadata.length();i++){JSONObject m=metadata.getJSONObject(i);m.put("mediaId",ids.get(m.getString("mediaId")));}
        for(int i=0;i<media.length();i++){JSONObject m=media.getJSONObject(i);m.put("id",ids.get(m.getString("id"))).put("root",roots.get(m.getString("root")));}
        for(int i=0;i<rootRows.length();i++){JSONObject r=rootRows.getJSONObject(i);r.put("id",roots.get(r.getString("id")));}
        return packet(peer,label,state,metadata,media,rootRows,sequence);
    }
    static Packet packet(String peer,String label,JSONObject state,JSONArray metadata,JSONArray media,JSONArray roots,long sequence)throws Exception {
        JSONObject data=new JSONObject().put("state",state).put("metadata",metadata).put("media",media).put("roots",roots);
        return new Packet(new JSONObject().put("format","peach-local-exchange").put("version",1).put("peer",peer).put("label",label).put("packet",UUID.randomUUID().toString()).put("createdAt",System.currentTimeMillis()).put("sequence",sequence).put("data",data).put("sha256",ExchangeJson.hash(ExchangeJson.canonical(data))));
    }
    static String family(String name){String kind=DocumentRules.kind(name);return kind.isEmpty()?MediaRules.type(name):"document/"+kind;}
    static void safePath(String path)throws Exception{ZipBook.safeName(path);if(path.indexOf('\\')>=0 || path.endsWith("/"))throw new IOException("Ruta relativa no compatible.");}
    static void validateMetadata(JSONObject m)throws Exception{ExchangeJson.keys(m,METADATA);for(String key:METADATA){if(key.equals("addedAt")){ExchangeJson.integer(m,key);continue;}String s=ExchangeJson.text(m,key,key.equals("nfoDetails")?65536:key.equals("mediaId")?32768:16000);if(key.equals("nfoDetails")){ExchangeJson.depth(s);new JSONObject(s);}}}
    static JSONArray copyArray(JSONArray a)throws JSONException{return new JSONArray(a.toString());}
    static void sort(JSONArray array,String key)throws Exception{List<JSONObject> rows=new ArrayList<>();for(int i=0;i<array.length();i++)rows.add(array.getJSONObject(i));rows.sort(Comparator.comparing(o->o.optString(key)));for(int i=0;i<rows.size();i++)array.put(i,rows.get(i));}
    /** Remaps only typed document references, never arbitrary strings, URIs or titles. Missing mappings are removed. */
    static JSONObject remap(JSONObject original,Map<String,String> ids)throws Exception {
        JSONObject state=ExchangeJson.copy(original);
        for(String section:List.of("items","readerProgress","usageSessions","entityLinks")){
            JSONArray clean=new JSONArray(),rows=state.getJSONArray(section);String key=section.equals("items")?"id":"mediaId";
            for(int i=0;i<rows.length();i++){JSONObject row=rows.getJSONObject(i);String mapped=ids.get(row.getString(key));if(mapped!=null){row.put(key,mapped);clean.put(row);}}state.put(section,clean);
        }
        for(String section:List.of("playlists","groups")){JSONArray rows=state.getJSONArray(section);for(int i=0;i<rows.length();i++){JSONObject row=rows.getJSONObject(i);JSONArray members=new JSONArray(),old=row.getJSONArray("items");for(int j=0;j<old.length();j++){String id=ids.get(old.getString(j));if(id!=null)members.put(id);}row.put("items",members);}}
        for(String section:List.of("wants","publications")){JSONArray rows=state.getJSONArray(section);for(int i=0;i<rows.length();i++){JSONObject row=rows.getJSONObject(i);if(!row.isNull("mediaId"))row.put("mediaId",ids.getOrDefault(row.getString("mediaId"),"").isEmpty()?JSONObject.NULL:ids.get(row.getString("mediaId")));}}
        JSONArray snapshots=state.getJSONArray("catalogSnapshots");for(int i=0;i<snapshots.length();i++){JSONObject row=snapshots.getJSONObject(i),bindings=row.getJSONObject("bindings"),clean=new JSONObject();var keys=bindings.keys();while(keys.hasNext()){String key=keys.next(),id=ids.get(bindings.getString(key));if(id!=null)clean.put(key,id);}row.put("bindings",clean);}
        return state;
    }
    static Snapshot mapped(Packet packet,Map<String,String> ids)throws Exception {
        JSONArray metadata=new JSONArray();for(int i=0;i<packet.data.getJSONArray("metadata").length();i++){JSONObject m=ExchangeJson.copy(packet.data.getJSONArray("metadata").getJSONObject(i));String id=ids.get(m.getString("mediaId"));if(id!=null){m.put("mediaId",id);metadata.put(m);}}
        return new Snapshot(remap(packet.data.getJSONObject("state"),ids),metadata,new JSONArray(),new JSONArray());
    }
    static void validate(Context context,Packet packet)throws Exception {
        var staging=androidx.room.Room.inMemoryDatabaseBuilder(context,LibraryDatabase.class).build();try{
            JSONArray rows=packet.data.getJSONArray("media");staging.runInTransaction(()->{for(int i=0;i<rows.length();i++){JSONObject row=rows.optJSONObject(i);MediaEntry m=new MediaEntry();m.id=row.optString("id");m.name=row.optString("name");m.mediaType=MediaRules.type(m.name);staging.library().insertMedia(m);}});
            restore(staging,new Snapshot(packet.data.getJSONObject("state"),packet.data.getJSONArray("metadata"),new JSONArray(),new JSONArray()),false);
        }finally{staging.close();}
    }
    static void restore(LibraryDatabase db,Snapshot snapshot,boolean preserveSources)throws Exception {
        List<FollowSource> oldSources=preserveSources?db.library().sources():List.of();JSONObject before=preserveSources?capture(db).state:new JSONObject();
        BackupStore.read(db,new ByteArrayInputStream(snapshot.state.toString().getBytes(StandardCharsets.UTF_8)));
        if(preserveSources){Map<String,JSONObject> a=rows(before.getJSONArray("sources"),"id"),b=rows(snapshot.state.getJSONArray("sources"),"id");for(FollowSource old:oldSources)if(ExchangeJson.same(a.get(old.id),b.get(old.id)))db.library().updateSource(old);}
        for(int i=0;i<snapshot.metadata.length();i++){JSONObject m=snapshot.metadata.getJSONObject(i);validateMetadata(m);if(db.library().get(m.getString("mediaId"))!=null)db.getOpenHelper().getWritableDatabase().execSQL("UPDATE media SET title=?,tags=?,actors=?,studio=?,plot=?,year=?,nfoDetails=?,addedAt=? WHERE id=?",new Object[]{m.getString("title"),m.getString("tags"),m.getString("actors"),m.getString("studio"),m.getString("plot"),m.getString("year"),m.getString("nfoDetails"),m.getLong("addedAt"),m.getString("mediaId")});}
    }
    static Map<String,JSONObject> rows(JSONArray rows,String key)throws Exception{Map<String,JSONObject> found=new LinkedHashMap<>();for(int i=0;i<rows.length();i++){JSONObject row=rows.getJSONObject(i);if(found.put(row.getString(key),row)!=null)throw new IOException("Registro duplicado de intercambio.");}return found;}
}
