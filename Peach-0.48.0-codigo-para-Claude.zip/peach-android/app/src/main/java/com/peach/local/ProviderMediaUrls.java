package com.peach.local;
import java.util.*;

/** Audited first-party media paths, never a general external URL fetcher. */
final class ProviderMediaUrls {
 static String provider(String url){try{var u=SourceHttp.https(url);String h=u.getHost().toLowerCase(Locale.ROOT),p=u.getRawPath();if(p==null||p.length()>3000||p.matches("(?i).*(%2e|%2f|%5c).*" )||p.contains("\\")||Arrays.asList(p.split("/",-1)).contains(".."))return "";if(h.matches("c[0-9]{1,3}\\.patreonusercontent\\.com")&&p.startsWith("/4/patreon-media/p/post/")&&p.length()>30)return "patreon";if(Set.of("d3ts7pb9ldoin4.cloudfront.net","star-uploads.s3-us-west-2.amazonaws.com").contains(h)&&p.startsWith("/uploads/posts/")&&p.length()>20&&u.getRawQuery()==null)return "subscribestar";if(Set.of("subscribestar.com","subscribestar.adult").contains(h)&&p.startsWith("/uploads/")&&p.length()>15&&u.getRawQuery()==null)return "subscribestar";}catch(IllegalArgumentException ignored){}return "";}
 static boolean downloadable(String url){return !provider(url).isEmpty();}
 static void redirect(String original,String next){if(!downloadable(original)||!original.equals(next))throw new IllegalArgumentException("Redirección de medio fuera del contrato.");}
}
