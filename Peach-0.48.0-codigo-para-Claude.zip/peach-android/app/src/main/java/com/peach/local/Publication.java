package com.peach.local;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ForeignKey;
import androidx.room.Index;

/** A publication is catalog metadata; it does not create a playable document. */
@Entity(tableName="publications",foreignKeys={
    @ForeignKey(entity=CatalogEntity.class,parentColumns="id",childColumns="entityId",onDelete=ForeignKey.SET_NULL),
    @ForeignKey(entity=MediaEntry.class,parentColumns="id",childColumns="mediaId",onDelete=ForeignKey.SET_NULL)},
    indices={@Index("entityId"),@Index("mediaId")})
public class Publication {
    @PrimaryKey @NonNull public String id="";
    @NonNull public String title="";
    @NonNull public String provider="";
    @NonNull public String sourceRef="";
    @NonNull public String sourceLabel="";
    @NonNull public String externalId="";
    @NonNull public String url="";
    @NonNull public String publishedAt="";
    @NonNull public String precision="unknown";
    @NonNull public String semantics="work";
    @NonNull public String releaseKey="";
    @NonNull public String variant="main";
    @NonNull public String variantLabel="";
    @NonNull public String status="new";
    @NonNull public String origin="manual";
    @NonNull public String notes="";
    @Nullable public String entityId;
    @Nullable public String mediaId;
    public long createdAt;
}
