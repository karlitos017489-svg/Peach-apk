package com.peach.local;

import java.time.Instant;
import java.util.*;
import org.json.*;

/** Optional selected upstream tables. Existing local records always win on reimport. */
public final class PublicationCatalog {
    public record Item(Publication publication,WantItem want,String state) {}
    public record Plan(List<Item> items,List<String> review,String stamp,int publications,int wants,int conflicts) {}
    private PublicationCatalog() {}
    static String text(JSONObject row,String key){Object value=row.opt(key);return value==null || value==JSONObject.NULL?"":value.toString();}
    static String key(String source,String type,long id){return CatalogBridge.key(source,type,Long.toString(id));}
    static long time(String raw){try{return Instant.parse(raw).toEpochMilli();}catch(Exception e){return 0;}}
    static Plan preview(LibraryDao dao,CatalogTransfer transfer,String source,boolean enabled,Map<Long,String> media,Map<Long,String> entities) throws JSONException {
        JSONObject tables=transfer.json().getJSONObject("tables");Map<Long,JSONObject> sources=new HashMap<>();for(JSONObject s:CatalogTransfer.rows(tables,"follow_source"))sources.put(s.getLong("id"),s);
        List<Item> items=new ArrayList<>();List<String> review=new ArrayList<>();StringBuilder stamp=new StringBuilder();Set<String> supported=new HashSet<>();String origin="catalog:"+CatalogBridge.key(source,"snapshot","");int pc=0,wc=0,cc=0;
        for(JSONObject row:CatalogTransfer.rows(tables,"follow_item")) {
            JSONObject s=sources.get(row.getLong("source_id"));Publication p=new Publication();p.id=key(source,"publication",row.getLong("id"));p.title=text(row,"title");p.provider=text(s,"provider");p.sourceRef=text(s,"ref");p.sourceLabel=text(s,"label");p.externalId=text(row,"external_id");p.url=text(row,"url");p.publishedAt=text(row,"published_at");p.precision=text(row,"published_precision");if(p.publishedAt.isBlank())p.precision="unknown";p.semantics=text(s,"semantics");p.releaseKey=text(row,"release_key");p.variant=text(row,"variant_kind");if(p.variant.isEmpty())p.variant="main";p.variantLabel=text(row,"variant_label");p.status=text(row,"status");p.origin=origin;p.createdAt=time(text(row,"first_seen_at"));
            if(!s.isNull("entity_id"))p.entityId=entities.get(s.getLong("entity_id"));if(!row.isNull("asset_id"))p.mediaId=media.get(row.getLong("asset_id"));
            String state=dao.publication(p.id)==null?"Nueva":"Existente, se conserva";
            try{PublicationStore.validate(p);supported.add(p.id);}catch(IllegalArgumentException e){state="No compatible: "+e.getMessage();}
            if(!enabled)state="Solo catálogo";if(state.equals("Nueva"))pc++;
            Publication old=dao.publication(p.id);stamp.append(p.id).append(state);if(old!=null)stamp.append(TrackingBackup.publication(old));
            items.add(new Item(p,null,state));review.add(state+" · Publicación: "+p.title+"\nFuente: "+p.sourceLabel+" · "+p.provider+" · "+p.sourceRef+"\nFecha: "+p.publishedAt+" ("+p.precision+") · "+p.semantics+" · "+p.variant+" · "+p.status+"\nArchivo local: "+(p.mediaId==null?"sin correspondencia":p.mediaId));
        }
        Map<String,List<WantItem>> byCode=new HashMap<>();for(WantItem w:dao.wants())if(!w.code.isBlank())byCode.computeIfAbsent(WantStore.codeKey(w.code),k->new ArrayList<>()).add(w);
        Set<String> incomingCodes=new HashSet<>(),duplicatedCodes=new HashSet<>();for(JSONObject row:CatalogTransfer.rows(tables,"want_item")){String code=WantStore.codeKey(text(row,"code"));if(!code.isEmpty() && !incomingCodes.add(code))duplicatedCodes.add(code);}
        for(JSONObject row:CatalogTransfer.rows(tables,"want_item")) {
            WantItem w=new WantItem();w.id=key(source,"want",row.getLong("id"));w.title=text(row,"title");w.code=text(row,"code");if(w.title.isBlank())w.title=w.code.isBlank()?"Obra importada #"+row.getLong("id"):w.code;w.releaseDate=text(row,"release_date");w.state=text(row,"state");w.origin=text(row,"origin");w.source=origin;w.createdAt=time(text(row,"created_at"));w.updatedAt=time(text(row,"updated_at"));w.lastSearchAt=text(row,"last_search_at");w.lastSearchOutcome=text(row,"last_search_outcome");w.lastSearchNote=text(row,"last_search_note");w.acquiredAt=text(row,"acquired_at");w.acquiredBatch=text(row,"acquired_batch").isEmpty()?"":"upstream:"+text(row,"acquired_batch");long count=row.getLong("search_count");w.searchCount=(int)Math.min(count,1000000);
            if(!row.isNull("follow_item_id")){String id=key(source,"publication",row.getLong("follow_item_id"));if(supported.contains(id) || dao.publication(id)!=null)w.publicationId=id;}
            if(!row.isNull("acquired_asset_id"))w.mediaId=media.get(row.getLong("acquired_asset_id"));
            String state=dao.want(w.id)==null?"Nueva":"Existente, se conserva";
            String code=WantStore.codeKey(w.code);if(!code.isEmpty() && (duplicatedCodes.contains(code) || byCode.getOrDefault(code,List.of()).stream().anyMatch(old->!old.id.equals(w.id))))state="Conflicto de código; se conserva local";
            try{EntityStore.name(w.title);WantStore.code(w.code);WantStore.state(w.state);EntityStore.notes(w.lastSearchNote);if(count>1000000 || !List.of("code","feed","follow").contains(w.origin) || !List.of("","found","none","error").contains(w.lastSearchOutcome))throw new IllegalArgumentException("Seguimiento no compatible.");}catch(IllegalArgumentException e){state="No compatible: "+e.getMessage();}
            if(!enabled)state="Solo catálogo";if(state.equals("Nueva"))wc++;if(state.startsWith("Conflicto"))cc++;
            WantItem old=dao.want(w.id);stamp.append(w.id).append(state);if(old!=null)stamp.append(TrackingBackup.fingerprint(old));items.add(new Item(null,w,state));review.add(state+" · Deseo: "+w.title+" · "+w.code+"\nEstado original: "+w.state+" · fecha: "+w.releaseDate+" · origen: "+w.origin+" · intentos: "+w.searchCount+"\nArchivo local: "+(w.mediaId==null?"sin correspondencia":w.mediaId));
        }
        if(pc+dao.publications().size()>10000 || wc+dao.wants().size()>5000)throw new IllegalArgumentException("La importación supera 10.000 publicaciones o 5.000 deseos locales.");
        return new Plan(List.copyOf(items),List.copyOf(review),stamp.toString(),pc,wc,cc);
    }
    static void apply(LibraryDao dao,Plan plan){for(Item item:plan.items())if(item.state().equals("Nueva")){if(item.publication()!=null)dao.insertPublication(item.publication());else dao.insertWant(item.want());}}
}
