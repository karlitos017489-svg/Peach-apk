package com.peach.local;

import androidx.annotation.*;
import androidx.room.*;

@Entity(tableName="publication_content",foreignKeys={
    @ForeignKey(entity=Publication.class,parentColumns="id",childColumns="publicationId",onDelete=ForeignKey.CASCADE),
    @ForeignKey(entity=FollowSource.class,parentColumns="id",childColumns="sourceId",onDelete=ForeignKey.SET_NULL)},indices=@Index("sourceId"))
public class PublicationContent {
    @PrimaryKey @NonNull public String publicationId="";
    @Nullable public String sourceId;
    @NonNull public String text="";
    @NonNull public String attachments="[]";
    @NonNull public String type="";
    public boolean partial=true;
    public long checkedAt;
}
