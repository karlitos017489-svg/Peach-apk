package com.peach.local;

import java.util.*;

public final class PublicationStore {
    private final LibraryDatabase db;
    public PublicationStore(LibraryDatabase db){this.db=db;}
    public String create(String title,String provider,String label,String date,String precision,String semantics,String notes){
        Publication p=new Publication();p.id=UUID.randomUUID().toString();p.createdAt=System.currentTimeMillis();p.title=EntityStore.name(title);p.provider=provider.trim();p.sourceLabel=label.trim();p.publishedAt=date.trim();p.precision=precision;p.semantics=semantics;p.notes=EntityStore.notes(notes);
        validate(p);db.runInTransaction(()->db.library().insertPublication(p));return p.id;
    }
    public void edit(String id,String title,String date,String precision,String notes){db.runInTransaction(()->{Publication p=require(id);p.title=EntityStore.name(title);p.publishedAt=date.trim();p.precision=precision;p.notes=EntityStore.notes(notes);validate(p);db.library().updatePublication(p);});}
    public void status(String id,String status){db.runInTransaction(()->{Publication p=require(id);p.status=status;validate(p);if(status.equals("ignored") && db.library().wants().stream().anyMatch(w->id.equals(w.publicationId)))throw new IllegalArgumentException("Retira primero la obra de deseos para ignorar su publicación.");db.library().updatePublication(p);});}
    public void attach(String id,String media){db.runInTransaction(()->{Publication p=require(id);if(media!=null && db.library().get(media)==null)throw new IllegalArgumentException("Archivo no disponible.");p.mediaId=media;if(media!=null)p.status="saved";else if(p.status.equals("saved"))p.status="seen";db.library().updatePublication(p);});}
    public void delete(String id){db.runInTransaction(()->{db.library().detachPublicationWants(id);db.library().deletePublication(id);});}
    private Publication require(String id){Publication p=db.library().publication(id);if(p==null)throw new IllegalArgumentException("Publicación no disponible.");return p;}
    public static String statusLabel(String s){return switch(s){case "new"->"Nueva";case "seen"->"Vista";case "saved"->"Guardada";case "ignored"->"Ignorada";default->s;};}
    static void validate(Publication p){
        EntityStore.name(p.title);EntityStore.notes(p.notes);if(p.id.isBlank() || p.id.length()>1000 || p.createdAt<0)throw new IllegalArgumentException("Publicación inválida.");
        for(String v:List.of(p.provider,p.sourceRef,p.sourceLabel,p.externalId,p.url,p.publishedAt,p.releaseKey,p.variantLabel,p.origin))if(v.length()>4096 || v.indexOf('\0')>=0)throw new IllegalArgumentException("Campo de publicación demasiado largo o inválido.");
        if(!List.of("exact","approximate","unknown").contains(p.precision) || !List.of("work","release").contains(p.semantics) || !List.of("main","wip","alt").contains(p.variant) || !List.of("new","seen","saved","ignored").contains(p.status))throw new IllegalArgumentException("Tipo o estado de publicación inválido.");
        if(p.precision.equals("exact") && WantStore.day(p.publishedAt)==null)throw new IllegalArgumentException("Una fecha exacta requiere al menos AAAA-MM-DD válido.");
    }
}
