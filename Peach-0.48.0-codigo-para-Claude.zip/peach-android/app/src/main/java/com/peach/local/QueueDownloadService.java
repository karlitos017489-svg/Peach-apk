package com.peach.local;
import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.os.*;
import androidx.core.app.NotificationCompat;
import androidx.lifecycle.Observer;
import java.util.*;
import java.util.concurrent.*;

/** User-started foreground owner, no sticky restart, boot receiver or scheduled network. */
public final class QueueDownloadService extends Service {
 static final String START="com.peach.local.QUEUE_START",PAUSE="com.peach.local.QUEUE_PAUSE",CHANNEL="peach-downloads";static final int NOTICE=4301;
 static DownloadQueue.Fetcher fetcher=PartialDownload::get;final ExecutorService worker=Executors.newSingleThreadExecutor();DownloadQueue queue;String owner="";PowerManager.WakeLock wake;boolean started;volatile boolean stopping;Observer<Integer> observer;
 static void start(Context c,DownloadQueue q)throws java.io.IOException{String owner=q.claimBackground();try{androidx.core.content.ContextCompat.startForegroundService(c,new Intent(c,QueueDownloadService.class).setAction(START).putExtra("owner",owner));}catch(RuntimeException e){q.releaseBackground(owner);throw e;}}
 @Override public IBinder onBind(Intent i){return null;}
 @Override public int onStartCommand(Intent intent,int flags,int startId){String action=intent==null?"":Objects.toString(intent.getAction(),"");if(PAUSE.equals(action)){pause();return START_NOT_STICKY;}if(!START.equals(action)){if(!started)stopSelf();return START_NOT_STICKY;}if(started)return START_NOT_STICKY;
  try{queue=DownloadQueue.get(this);owner=Objects.toString(intent.getStringExtra("owner"),"");if(!queue.ownsBackground(owner)){stopSelf();return START_NOT_STICKY;}started=true;NotificationManager manager=getSystemService(NotificationManager.class);manager.createNotificationChannel(new NotificationChannel(CHANNEL,"Descargas de Peach",NotificationManager.IMPORTANCE_LOW));if(Build.VERSION.SDK_INT>=29)startForeground(NOTICE,notification(),ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);else startForeground(NOTICE,notification());PowerManager pm=getSystemService(PowerManager.class);wake=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"Peach:Downloads");wake.acquire(6*60*60*1000L);observer=n->{if(!stopping&&queue.ownsBackground(owner))getSystemService(NotificationManager.class).notify(NOTICE,notification());};queue.changes.observeForever(observer);
   worker.execute(()->{try{synchronized(queue){if(stopping)return;queue.continueAll();}queue.run(LibraryDatabase.get(this),fetcher);}catch(Exception e){try{queue.pauseAll();}catch(Exception ignored){}}finally{new Handler(Looper.getMainLooper()).post(()->{stopping=true;stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();});}});
  }catch(Exception e){if(started&&queue!=null)queue.signalPause();stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();}return START_NOT_STICKY;
 }
 Notification notification(){List<DownloadQueue.Job> rows=queue==null?List.of():queue.snapshot();long ready=rows.stream().filter(j->j.state.equals("ready")).count();DownloadQueue.Job active=rows.stream().filter(j->Set.of("running","verifying").contains(j.state)).findFirst().orElse(null);String summary=active==null?ready+" completas de "+rows.size():DownloadQueue.label(active);PendingIntent open=PendingIntent.getActivity(this,4301,new Intent(this,DownloadQueueActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);PendingIntent pause=PendingIntent.getService(this,4302,new Intent(this,QueueDownloadService.class).setAction(PAUSE),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);var b=new NotificationCompat.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle("Peach · descargas en segundo plano").setContentText(summary).setStyle(new NotificationCompat.BigTextStyle().bigText(summary)).setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true).addAction(android.R.drawable.ic_media_pause,"Pausar",pause);if(active!=null&&active.total>0)b.setProgress(100,(int)Math.min(100,active.bytes*100/active.total),false);else b.setProgress(0,0,true);return b.build();}
 void pause(){stopping=true;if(started&&queue!=null)queue.signalPause();stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();}
 @Override public void onTimeout(int startId,int type){pause();}
 @Override public void onTaskRemoved(Intent root){/* Explicit background mode continues, subject to Android battery/time limits. */}
 @Override public void onDestroy(){stopping=true;if(started&&queue!=null){if(observer!=null)queue.changes.removeObserver(observer);queue.signalPause();worker.execute(()->{try{if(queue.ownsBackground(owner))queue.pauseAll();}catch(Exception ignored){}finally{queue.releaseBackground(owner);}});}if(wake!=null&&wake.isHeld())wake.release();worker.shutdown();super.onDestroy();}
}
