package com.peach.local;
import android.content.*;
import android.database.*;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import java.io.*;

/** Own-UID read-only provider: only completed opaque job IDs, never arbitrary paths. */
public final class QueueFilesProvider extends ContentProvider {
    static Uri uri(Context context,String id){if(!DownloadQueue.id(id))throw new IllegalArgumentException();return new Uri.Builder().scheme("content").authority(context.getPackageName()+".queue").appendPath(id).build();}
    String id(Uri uri)throws FileNotFoundException{if(!"content".equals(uri.getScheme())||!getContext().getPackageName().concat(".queue").equals(uri.getAuthority())||uri.getQuery()!=null||uri.getFragment()!=null||uri.getPathSegments().size()!=1||!DownloadQueue.id(uri.getLastPathSegment()))throw new FileNotFoundException("Descarga no válida.");return uri.getLastPathSegment();}
    @Override public boolean onCreate(){return true;}
    @Override public String getType(Uri uri){try{var q=DownloadQueue.get(getContext());synchronized(q){return SourceFiles.mime(q.job(id(uri)).name);}}catch(IOException e){return "application/octet-stream";}}
    @Override public Cursor query(Uri uri,String[] projection,String selection,String[] args,String order){try{var q=DownloadQueue.get(getContext());DownloadQueue.Job j;synchronized(q){j=q.job(id(uri)).copy();q.checked(j.id);}String[] columns=projection==null?new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}:projection;MatrixCursor c=new MatrixCursor(columns);Object[] row=new Object[columns.length];for(int i=0;i<columns.length;i++)row[i]=columns[i].equals(OpenableColumns.DISPLAY_NAME)?j.name:columns[i].equals(OpenableColumns.SIZE)?j.bytes:null;c.addRow(row);return c;}catch(IOException e){return null;}}
    @Override public ParcelFileDescriptor openFile(Uri uri,String mode)throws FileNotFoundException {
        if(!"r".equals(mode))throw new FileNotFoundException("Solo lectura.");String id=id(uri);DownloadQueue q;try{q=DownloadQueue.get(getContext());}catch(IOException e){throw new FileNotFoundException("Cola no disponible.");}
        synchronized(q){try{File file=q.checked(id);q.pins.merge(id,1,Integer::sum);try{return ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY,new Handler(Looper.getMainLooper()),error->q.unpin(id));}catch(IOException e){q.unpin(id);throw e;}}catch(IOException e){throw new FileNotFoundException("Copia completa no disponible.");}}
    }
    @Override public Uri insert(Uri u,ContentValues v){throw new UnsupportedOperationException("Solo lectura.");}
    @Override public int update(Uri u,ContentValues v,String s,String[] a){throw new UnsupportedOperationException("Solo lectura.");}
    @Override public int delete(Uri u,String s,String[] a){throw new UnsupportedOperationException("Solo lectura.");}
}
