package com.peach.local;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;

/** RAR4 filename field only. No locale guess, fallback name or filesystem extraction.
 * Legacy UTF-16 operations checked against the pinned BSD libarchive RAR reader;
 * data compression remains entirely in that existing isolated decoder. */
final class Rar4Names {
    private static final int LIMIT=4096;
    private Rar4Names() {}

    static String decode(byte[] raw,boolean unicode)throws IOException {
        if(raw.length==0 || raw.length>LIMIT)throw damaged();
        if(!unicode) {
            for(byte b:raw)if(b<0)throw new IOException("Nombre RAR4 sin codificación portable; usa nombres ASCII o RAR5 UTF-8.");
            return new String(raw,StandardCharsets.US_ASCII);
        }
        int prefix=0;while(prefix<raw.length && raw[prefix]!=0)prefix++;
        if(prefix==raw.length) {
            try{return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(raw)).toString();}
            catch(CharacterCodingException e){throw damaged();}
        }
        if(prefix==0 || raw.length-prefix<4)throw damaged();
        int at=prefix+1,high=raw[at++]&255,flags=0,bits=0,count=0;
        char[] decoded=new char[LIMIT];
        while(at<raw.length) {
            if(bits==0){flags=raw[at++]&255;bits=8;}
            bits-=2;int operation=(flags>>>bits)&3;
            if(at>=raw.length)throw damaged();
            int low=raw[at++]&255;
            if(operation==3) {
                int length=(low&127)+2,correction=0,upper=0;
                if((low&128)!=0) {
                    if(at>=raw.length)throw damaged();
                    correction=raw[at++]&255;upper=high<<8;
                }
                // Copy operations address the original prefix by UTF-16 output position.
                // Never let an invalid run read the NUL or the encoded instruction bytes.
                if(length>prefix-count || length>LIMIT-count)throw damaged();
                for(int i=0;i<length;i++) {
                    decoded[count]=(char)(upper|(((raw[count]&255)+correction)&255));count++;
                }
            }else {
                if(count==LIMIT)throw damaged();
                int value=low;
                if(operation==1)value|=high<<8;
                if(operation==2){if(at>=raw.length)throw damaged();value|=(raw[at++]&255)<<8;}
                decoded[count++]=(char)value;
            }
        }
        if(count==0)throw damaged();
        // Reject unpaired UTF-16 surrogates instead of replacing them with '?' in IPC.
        int utf8=0;
        for(int i=0;i<count;i++) {
            char c=decoded[i];
            if(Character.isHighSurrogate(c)) {
                if(i+1==count || !Character.isLowSurrogate(decoded[++i]))throw damaged();utf8+=4;
            }else if(Character.isLowSurrogate(c))throw damaged();
            else utf8+=c<128?1:c<2048?2:3;
            if(utf8>LIMIT)throw damaged();
        }
        return new String(decoded,0,count);
    }
    private static IOException damaged(){return new IOException("Nombre Unicode RAR4 dañado o fuera del límite de 4096 bytes UTF-8.");}
}
