package com.peach.local;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.*;
import java.util.*;
import java.util.zip.CRC32;

/** Bounded RAR headers and stored reader; optional isolated decoder for selected compressed entries. */
public final class RarBook implements ArchiveBook {
    static final int MAX_HEADER=2*1024*1024,MAX_HEADERS=8*1024*1024;
    static final long MAX_SOLID_BYTES=128L*1024*1024;
    public interface Decoder {File decode(File source,String name,long expected,long crc,File directory)throws IOException;default void cancel(){}}
    private record Entry(String name,long bytes,long packed,long offset,long crc,String issue,boolean compressed) {}
    private record Index(long length,List<Entry> entries,boolean solid) {}
    private final File source;private final Index index;private final List<Item> items;private final Decoder decoder;
    public RarBook(File source)throws IOException {this(source,null);}
    public RarBook(File source,Decoder decoder)throws IOException {
        this.source=source;this.decoder=decoder;index=index(source,decoder!=null);List<Item> found=new ArrayList<>();
        for(Entry e:index.entries())found.add(new Item(e.name(),e.bytes(),e.issue().isEmpty()?DocumentRules.entryKind(e.name()):""));
        found.sort((a,b)->DocumentRules.naturalCompare(a.name(),b.name()));items=List.copyOf(found);
    }
    public List<Item> items(){return items;}
    public String explanation(String name){
        Entry e=index.entries().stream().filter(v->v.name().equals(name)).findFirst().orElse(null);
        return e==null || e.issue().isEmpty()?ArchiveBook.super.explanation(name):e.issue();
    }
    public File read(String name,File directory)throws IOException {
        Item item=item(name);if(item==null || item.kind().isEmpty())throw new IOException(explanation(name));
        if(item.bytes()>ZipBook.MAX_ENTRY_BYTES)throw new IOException("Entrada RAR mayor de 64 MiB.");
        try(RandomAccessFile in=new RandomAccessFile(source,"r")) {
            if(!index.equals(index(in,decoder!=null)))throw new IOException("El índice RAR cambió. Vuelve a abrirlo.");
            Entry e=index.entries().stream().filter(v->v.name().equals(name)).findFirst().orElseThrow();
            if(e.compressed())return decoder.decode(source,name,e.bytes(),e.crc(),directory);
            in.seek(e.offset());
            InputStream checked=new InputStream(){
                long remaining=e.bytes();final CRC32 crc=new CRC32();
                public int read()throws IOException{byte[] b=new byte[1];return read(b,0,1)<0?-1:b[0]&255;}
                public int read(byte[] b,int off,int len)throws IOException {
                    if(off<0 || len<0 || off>b.length-len)throw new IndexOutOfBoundsException();if(len==0)return 0;
                    if(remaining==0){if(crc.getValue()!=e.crc())throw new IOException("Entrada RAR dañada (CRC).");return -1;}
                    int n=in.read(b,off,(int)Math.min(len,remaining));if(n<=0)throw new EOFException("Entrada RAR truncada.");
                    remaining-=n;crc.update(b,off,n);return n;
                }
            };
            return ArchiveFiles.copy(checked,directory,"entry",ZipBook.MAX_ENTRY_BYTES,e.bytes());
        }
    }
    public void cancel(){if(decoder!=null)decoder.cancel();}
    public void close(){} // Each operation owns its file descriptor.
    private static Index index(File source,boolean nativeSupport)throws IOException{try(RandomAccessFile in=new RandomAccessFile(source,"r")){return index(in,nativeSupport);}}
    private static Index index(RandomAccessFile in,boolean nativeSupport)throws IOException {
        long length=in.length(),deadline=System.nanoTime()+90_000_000_000L;
        if(length<14 || length>ReaderSession.MAX_SOURCE_BYTES)throw new IOException("Tamaño RAR incompatible o truncado; máximo 512 MiB.");
        ArchiveFiles.check(deadline);byte[] magic=new byte[7];in.readFully(magic);
        if(!Arrays.equals(Arrays.copyOf(magic,6),new byte[]{82,97,114,33,26,7}))throw new IOException("Firma RAR no compatible; no se admiten ejecutables SFX.");
        int version=magic[6]&255;if(version==1){if(in.read()!=0)throw unsupported();}else if(version!=0)throw unsupported();
        List<Entry> entries=new ArrayList<>();Set<String> names=new HashSet<>();long total=0;int headers=0,budget=0;boolean main=false,end=false,archiveSolid=false;int solidDictionary=-1;boolean solidReady=false;
        while(in.getFilePointer()<length) {
            ArchiveFiles.check(deadline);if(++headers>ZipBook.MAX_ENTRIES)throw new IOException("RAR con más de 10.000 cabeceras.");
            byte[] h;int type,flags;long packed=0;Cursor c;int extra=0;
            if(version==0) {
                byte[] fixed=new byte[7];in.readFully(fixed);int size=u16(fixed,5);
                if(size<7 || size>length-in.getFilePointer()+7)throw damaged();
                h=Arrays.copyOf(fixed,size);in.readFully(h,7,size-7);CRC32 crc=new CRC32();crc.update(h,2,h.length-2);if((crc.getValue()&65535)!=u16(h,0))throw damaged();
                type=h[2]&255;flags=u16(h,3);c=new Cursor(h,7,h.length);
                if(type==0x74 || (flags&0x8000)!=0)packed=c.u32();
            }else {
                byte[] crcBytes=new byte[4];in.readFully(crcBytes);ByteArrayOutputStream sizeBytes=new ByteArrayOutputStream();long size=0;int shift=0;
                for(int i=0;;i++){if(i==3)throw damaged();int b=in.read();if(b<0)throw damaged();sizeBytes.write(b);size|=(long)(b&127)<<shift;if((b&128)==0)break;shift+=7;}
                if(size<2 || size>MAX_HEADER || size>length-in.getFilePointer())throw damaged();
                h=new byte[(int)size];in.readFully(h);CRC32 crc=new CRC32();crc.update(sizeBytes.toByteArray());crc.update(h);if(crc.getValue()!=u32(crcBytes,0))throw damaged();
                c=new Cursor(h,0,h.length);type=c.integer();flags=c.integer();
                if((flags&~0x7f)!=0)throw unsupported();if((flags&0x18)!=0)throw volumes();
                if((flags&1)!=0)extra=c.integer();if((flags&2)!=0)packed=c.number();
                if(extra>c.remaining())throw damaged();c.limit=h.length-extra;
            }
            budget+=h.length;if(budget>MAX_HEADERS)throw new IOException("Índice RAR mayor de 8 MiB.");
            long offset=in.getFilePointer();if(packed>length-offset)throw damaged();
            if(!main) {
                if(version==1 && type==4)throw new IOException("Cabeceras RAR cifradas; contraseñas pendientes.");
                if(type!=(version==0?0x73:1))throw damaged();main=true;
                if(version==0){if(c.remaining()<6)throw damaged();if((flags&0x181)!=0)throw new IOException("RAR multivolumen o cifrado no compatible.");if((flags&8)!=0)throw solid();}
                else {long archiveFlags=c.number();if((archiveFlags&~0x1f)!=0)throw unsupported();if((archiveFlags&3)!=0)throw volumes();archiveSolid=(archiveFlags&4)!=0;if(archiveSolid && !nativeSupport)throw new IOException("RAR5 sólido requiere el lector con motor aislado.");if(c.remaining()!=0)throw damaged();}
                if(packed!=0)throw damaged();
            }else if(type==(version==0?0x74:2)) {
                String name,issue="";long size,crc,attr;int host,method;
                boolean directory,compressed=false,linked=false;int dictionary=-1;
                if(version==0) {
                    size=c.u32();host=c.byteValue();crc=c.u32();c.u32();int unpack=c.byteValue();method=c.byteValue();int nameSize=c.u16();attr=c.u32();
                    if((flags&0x100)!=0){long highPacked=c.u32(),highSize=c.u32();if(highPacked!=0 || highSize!=0)throw unsupported();}
                    byte[] raw=c.bytes(nameSize);boolean unicode=(flags&0x200)!=0;
                    name=Rar4Names.decode(raw,unicode);directory=(flags&0xe0)==0xe0 || (host!=3 && (attr&16)!=0) || (host==3 && (attr&0170000)==0040000);
                    if((flags&3)!=0)throw volumes();if((flags&0x404)!=0)issue="Entrada RAR cifrada; contraseñas pendientes.";
                    else if((flags&0x10)!=0)issue="Entrada RAR sólida todavía sin descompresor integrado.";
                    else if(unpack>29 || (flags&0x6808)!=0 || host>5)issue="Variante de entrada RAR4 todavía no compatible.";
                    else if(method!=0x30){compressed=true;if(!nativeSupport || method<0x31 || method>0x35)issue="Entrada RAR comprimida sin método compatible disponible.";}
                    if(host==3 && (attr&0170000)!=0100000 && !directory)issue="Enlace o archivo especial RAR: no se sigue ni se abre.";
                }else {
                    int fileFlags=c.integer();size=c.number();attr=c.number();if((fileFlags&2)!=0)c.u32();crc=(fileFlags&4)!=0?c.u32():-1;
                    long compression=c.number();method=(int)((compression>>>7)&7);dictionary=(int)((compression>>>10)&31);linked=(compression&64)!=0;host=c.integer();name=decode(c.bytes(c.integer()),true);directory=(fileFlags&1)!=0;
                    if(c.remaining()!=0)throw damaged();
                    if((fileFlags&~15)!=0 || (fileFlags&8)!=0)issue="RAR con tamaño desconocido o flags nuevos todavía no compatible.";
                    else if((flags&32)!=0 || (linked && !archiveSolid))issue="Dependencia RAR5 sin contenedor sólido compatible.";
                    else if((compression&63)>1 || (compression&~0x1fffffL)!=0 || host>1)issue="Variante de entrada RAR5/7 todavía no compatible.";
                    else if(crc<0)issue="Entrada RAR sin CRC32 verificable; lectura todavía no compatible.";
                    else if(method!=0){compressed=true;if(!nativeSupport)issue="Entrada RAR comprimida; este bloque solo lee el método almacenar (sin compresión).";
                        else if((compression&63)!=0 || method>5 || ((compression>>>10)&31)>9)issue="Compresión RAR7 o diccionario RAR5 mayor de 64 MiB todavía no compatible.";}
                    if(host==1 && (attr&0170000)!=0100000 && !directory)issue="Enlace o archivo especial RAR: no se sigue ni se abre.";
                    Cursor extras=new Cursor(h,h.length-extra,h.length);Set<Long> types=new HashSet<>();
                    while(extras.remaining()>0){long n=extras.number();if(n<1 || n>extras.remaining())throw damaged();int stop=extras.at+(int)n;long t=extras.number();if(!types.add(t) || extras.at>stop)throw damaged();
                        if(t==1)issue="Entrada RAR cifrada; contraseñas pendientes.";
                        else if(t==5)issue="Enlace o redirección RAR: no se sigue ni se abre.";
                        else if(t!=3 && t!=6)issue="Metadatos extra RAR todavía no compatibles con lectura verificada.";
                        extras.at=stop;
                    }
                }
                name=name.replace('\\','/');ZipBook.safeName(name);if(name.indexOf(':')>=0 || name.indexOf('\ufffe')>=0 || name.indexOf('\uffff')>=0)throw damaged();
                if(!names.add(name))throw new IOException("RAR con nombres duplicados.");
                if(size>ReaderSession.MAX_SOURCE_BYTES-total)throw new IOException("RAR con más de 512 MiB descomprimidos declarados.");total+=size;
                if(archiveSolid){
                    if(total>MAX_SOLID_BYTES)throw new IOException("RAR5 sólido con más de 128 MiB descomprimidos declarados.");
                    if(directory){if(linked)throw damaged();}
                    else {
                        // Automatic solid skipping reconstructs previous dictionaries. Admit only
                        // fully bounded, understood regular entries, even if their extension has no viewer.
                        if(!issue.isEmpty())throw new IOException("RAR5 sólido contiene una entrada no compatible; no se inicia el motor.");
                        if(size==0 || size>ZipBook.MAX_ENTRY_BYTES || !compressed || dictionary>9)
                            throw new IOException("RAR5 sólido requiere entradas comprimidas de 1 byte a 64 MiB y diccionario hasta 64 MiB.");
                        if(linked && !solidReady)throw new IOException("RAR5 sólido sin entrada inicial independiente.");
                        if(solidDictionary!=-1 && solidDictionary!=dictionary)throw new IOException("RAR5 sólido con diccionarios distintos todavía no compatible.");
                        solidDictionary=dictionary;solidReady=true;
                    }
                }
                if(directory){if(size!=0 || packed!=0)throw damaged();}
                else {if(name.endsWith("/"))throw damaged();if(issue.isEmpty() && !compressed && size!=packed)throw damaged();entries.add(new Entry(name,size,packed,offset,crc,issue,compressed));}
            }else if(type==(version==0?0x7b:5)) {
                if(packed!=0)throw damaged();if(version==0){if((flags&1)!=0)throw volumes();}
                else {if(c.number()!=0)throw volumes();if(c.remaining()!=0)throw damaged();}
                end=true;if(offset!=length)throw new IOException("RAR con datos adicionales después del final no compatible.");break;
            }else {
                // A solid dictionary must not depend on opaque service data.
                if(archiveSolid)throw new IOException("RAR5 sólido con bloques de servicio todavía no compatible.");
                // Bounded supplementary blocks are ignored; their bytes are never executed/read as files.
                if(version==0?type<0x75 || type>0x7a:type!=3)throw unsupported();
            }
            in.seek(offset+packed);
        }
        if(!main || !end)throw new IOException("RAR truncado o sin marcador final compatible.");
        return new Index(length,List.copyOf(entries),archiveSolid);
    }
    private static String decode(byte[] b,boolean utf8)throws IOException {
        if(b.length==0 || b.length>4096)throw damaged();
        if(!utf8)for(byte v:b)if(v<0)throw new IOException("Nombre RAR4 sin codificación portable; usa nombres ASCII o RAR5 UTF-8.");
        try{return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(b)).toString();}
        catch(CharacterCodingException e){throw new IOException("Nombre RAR con UTF-8 no válido.",e);}
    }
    private static IOException damaged(){return new IOException("Cabecera o tamaño RAR dañado/no compatible.");}
    private static IOException unsupported(){return new IOException("Variante RAR todavía no compatible con este lector.");}
    private static IOException volumes(){return new IOException("RAR dividido en volúmenes todavía no compatible.");}
    private static IOException solid(){return new IOException("RAR sólido todavía sin descompresor integrado.");}
    private static int u16(byte[] b,int p){return (b[p]&255)|((b[p+1]&255)<<8);}
    private static long u32(byte[] b,int p){return Integer.toUnsignedLong((b[p]&255)|((b[p+1]&255)<<8)|((b[p+2]&255)<<16)|((b[p+3]&255)<<24));}
    private static final class Cursor {
        final byte[] b;int at,limit;Cursor(byte[] b,int at,int limit){this.b=b;this.at=at;this.limit=limit;}
        int remaining(){return limit-at;}
        int byteValue()throws IOException{if(at>=limit)throw damaged();return b[at++]&255;}
        byte[] bytes(int n)throws IOException{if(n<0 || n>remaining())throw damaged();byte[] v=Arrays.copyOfRange(b,at,at+n);at+=n;return v;}
        int u16()throws IOException{int a=byteValue();return a|(byteValue()<<8);}
        long u32()throws IOException{return Integer.toUnsignedLong(byteValue()|(byteValue()<<8)|(byteValue()<<16)|(byteValue()<<24));}
        long number()throws IOException{long v=0;for(int i=0;i<9;i++){int x=byteValue();v|=(long)(x&127)<<(i*7);if((x&128)==0)return v;}throw damaged();}
        int integer()throws IOException{long n=number();if(n>Integer.MAX_VALUE)throw damaged();return (int)n;}
    }
}
