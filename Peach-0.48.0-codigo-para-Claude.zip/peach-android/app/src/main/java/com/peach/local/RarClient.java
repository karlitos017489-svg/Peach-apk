package com.peach.local;
import android.content.*;
import android.os.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;
import java.util.zip.CRC32;

/** One isolated native request at a time, descriptor-only IPC, bounded publication. */
final class RarClient implements RarBook.Decoder {
    static final long TIMEOUT_SECONDS=90;private static final ReentrantLock SLOT=new ReentrantLock();
    private static final AtomicLong IDS=new AtomicLong(Math.max(1,System.nanoTime()&Long.MAX_VALUE));
    private static final ScheduledThreadPoolExecutor TIMER=new ScheduledThreadPoolExecutor(1,r->{Thread t=new Thread(r,"rar-watchdog");t.setDaemon(true);return t;});
    static {TIMER.setRemoveOnCancelPolicy(true);}
    private final Context context;private final long timeoutSeconds;private volatile boolean cancelled;private volatile IRarEngine active;private volatile long job;
    RarClient(Context c){this(c,TIMEOUT_SECONDS);}
    RarClient(Context c,long seconds){if(seconds<1 || seconds>TIMEOUT_SECONDS)throw new IllegalArgumentException();context=c.getApplicationContext();timeoutSeconds=seconds;}
    @Override public void cancel(){cancelled=true;IRarEngine engine=active;long id=job;if(engine!=null)TIMER.execute(()->stop(engine,id));}
    private static void stop(IRarEngine engine,long id){try{engine.cancel(id);}catch(RemoteException|RuntimeException ignored){}}
    private void check()throws InterruptedIOException{if(cancelled || Thread.currentThread().isInterrupted())throw new InterruptedIOException("Lectura RAR cancelada.");}
    @Override public File decode(File source,String name,long expected,long crc,File directory)throws IOException{
        check();boolean held=false,bound=false,done=false;ScheduledFuture<?> timeout=null;File part=new File(directory,"entry-part"),target=new File(directory,"entry");
        AtomicBoolean timedOut=new AtomicBoolean();CountDownLatch connected=new CountDownLatch(1);IRarEngine[] service={null};
        ServiceConnection connection=new ServiceConnection(){
            public void onServiceConnected(ComponentName n,IBinder b){service[0]=IRarEngine.Stub.asInterface(b);connected.countDown();}
            public void onServiceDisconnected(ComponentName n){connected.countDown();}
            public void onBindingDied(ComponentName n){connected.countDown();}
            public void onNullBinding(ComponentName n){connected.countDown();}
        };
        try {
            SLOT.lockInterruptibly();held=true;check();job=IDS.incrementAndGet();
            if(directory.getUsableSpace()<expected+ArchiveFiles.RESERVE)throw new IOException("No hay espacio suficiente para la vista RAR temporal.");
            bound=context.bindService(new Intent(context,RarService.class),connection,Context.BIND_AUTO_CREATE);
            if(!bound || !connected.await(10,TimeUnit.SECONDS) || service[0]==null)throw new IOException("No se pudo iniciar el descompresor RAR aislado.");
            IRarEngine engine=service[0];active=engine;check();long id=job;timeout=TIMER.schedule(()->{timedOut.set(true);stop(engine,id);},timeoutSeconds,TimeUnit.SECONDS);
            try(var input=ParcelFileDescriptor.open(source,ParcelFileDescriptor.MODE_READ_ONLY);var output=ParcelFileDescriptor.open(part,ParcelFileDescriptor.MODE_CREATE|ParcelFileDescriptor.MODE_TRUNCATE|ParcelFileDescriptor.MODE_WRITE_ONLY)){
                long[] result=engine.decode(id,input,output,name.getBytes(StandardCharsets.UTF_8),expected,crc);check();if(timedOut.get())throw new IOException("La descompresión RAR excedió el plazo permitido.");validate(result);
            }
            verify(part,expected,crc);check();
            if(target.exists() && !target.delete())throw new IOException("No se pudo renovar la vista RAR.");
            if(!part.renameTo(target))throw new IOException("No se pudo publicar la vista RAR.");done=true;return target;
        }catch(InterruptedException error){Thread.currentThread().interrupt();throw new InterruptedIOException("Lectura RAR cancelada.");}
        catch(RemoteException error){throw new IOException("El descompresor RAR se interrumpió; el archivo original se conserva.");}
        catch(SecurityException error){throw new IOException("No se pudo acceder al descompresor RAR aislado.");}
        finally{if(timeout!=null)timeout.cancel(false);IRarEngine engine=active;if(!done && engine!=null)stop(engine,job);active=null;try{if(bound)context.unbindService(connection);}finally{if(!done)part.delete();if(held)SLOT.unlock();}}
    }
    static void validate(long[] result)throws IOException{
        if(result==null || result.length!=3 || result[1]<0 || result[1]>RarNative.MAX_HEAP || result[2]!=0)throw new IOException("El descompresor RAR devolvió un resultado no válido.");
        if(result[0]==0)return;
        throw new IOException(switch((int)result[0]){case 3->"Entrada RAR dañada (tamaño o CRC).";case 4->"Este RAR excede el límite de memoria del descompresor.";case 5->"La descompresión RAR excedió el plazo permitido.";case 7->"Lectura RAR cancelada.";case 9->"Motor RAR no disponible para esta instalación.";default->"No se pudo descomprimir esta variante RAR o su contenido está dañado.";});
    }
    static void verify(File file,long expected,long crc)throws IOException{
        if(file.length()!=expected || expected<0 || expected>ZipBook.MAX_ENTRY_BYTES)throw new IOException("Entrada RAR con tamaño no válido.");
        CRC32 sum=new CRC32();long deadline=System.nanoTime()+90_000_000_000L;
        try(var in=new FileInputStream(file)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1){ArchiveFiles.check(deadline);sum.update(b,0,n);}}
        if(sum.getValue()!=crc)throw new IOException("Entrada RAR dañada (CRC).");
    }
}
