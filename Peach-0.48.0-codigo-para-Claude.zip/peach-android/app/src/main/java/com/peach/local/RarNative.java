package com.peach.local;
/** Loaded only by the isolated decoder service (host tests load their own build). */
final class RarNative {
    static final long MAX_HEAP=160L*1024*1024;
    private static boolean loaded;
    static synchronized void load(){if(!loaded){System.loadLibrary("peach_rar");loaded=true;}}
    static native long[] decode(int source,int output,byte[] name,long expected,long crc,long limit);
    private RarNative(){}
}
