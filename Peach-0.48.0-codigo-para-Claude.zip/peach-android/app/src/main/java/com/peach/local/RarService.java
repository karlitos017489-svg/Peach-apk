package com.peach.local;
import android.app.Service;
import android.content.Intent;
import android.os.*;
import java.util.LinkedHashSet;

/** No exported endpoint, app paths, database access, network or persistent state. */
public class RarService extends Service {
    private final Object guard=new Object();private final LinkedHashSet<Long> cancelled=new LinkedHashSet<>();private long active;
    private void owner(){if(Binder.getCallingUid()!=getApplicationInfo().uid)throw new SecurityException("RAR caller");}
    protected long[] decodeNative(int source,int output,byte[] name,long size,long crc){RarNative.load();return RarNative.decode(source,output,name,size,crc,RarNative.MAX_HEAP);}
    protected void stopDecoder(){android.os.Process.killProcess(android.os.Process.myPid());}
    private final IRarEngine.Stub binder=new IRarEngine.Stub(){
        public long[] decode(long job,ParcelFileDescriptor source,ParcelFileDescriptor output,byte[] name,long size,long crc){
            owner();try(source;output){
                if(job<=0 || source==null || output==null || name==null || name.length<1 || name.length>4096 || size<0 || size>ZipBook.MAX_ENTRY_BYTES || crc<0 || crc>0xffffffffL)return new long[]{1,0,0};
                synchronized(guard){if(cancelled.contains(job))return new long[]{7,0,0};if(active!=0)return new long[]{8,0,0};active=job;}
                try{long[] result=decodeNative(source.getFd(),output.getFd(),name,size,crc);if(result!=null && result.length==3 && result[2]!=0)stopDecoder();return result;}
                catch(LinkageError|RuntimeException error){return new long[]{9,0,0};}
                finally{synchronized(guard){if(active==job)active=0;}}
            }catch(java.io.IOException error){return new long[]{6,0,0};}
        }
        public void cancel(long job){owner();boolean stop;synchronized(guard){cancelled.add(job);while(cancelled.size()>64)cancelled.remove(cancelled.iterator().next());stop=active==job;}if(stop)stopDecoder();}
    };
    @Override public IBinder onBind(Intent intent){return binder;}
    @Override public void onDestroy(){boolean stop;synchronized(guard){stop=active!=0;}if(stop)stopDecoder();super.onDestroy();}
}
