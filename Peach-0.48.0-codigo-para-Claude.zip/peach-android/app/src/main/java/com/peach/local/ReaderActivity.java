package com.peach.local;

import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ReaderActivity extends PeachActivity {
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private Future<?> pending;private ReaderSession session;private ReaderSession.Frame shown;
    private List<ArchiveBook.Item> entries=List.of();private LibraryDatabase db;private MediaEntry media;
    private ZoomImageView canvas;private ScrollView scroll;private TextView text;
    private int request;private boolean recorded;private float font=16;
    private UsageTracker history;
    private int searchNext;private String searchQuery="";
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);setContentView(R.layout.activity_reader);db=LibraryDatabase.get(this);
        history=new UsageTracker(db,state);
        WindowCompat.setDecorFitsSystemWindows(getWindow(),false);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.readerRoot),(view,insets)->{
            var bars=insets.getInsets(WindowInsetsCompat.Type.systemBars()|WindowInsetsCompat.Type.displayCutout());view.setPadding(bars.left,bars.top,bars.right,bars.bottom);return insets;
        });
        canvas=findViewById(R.id.readerCanvas);scroll=findViewById(R.id.readerScroll);text=findViewById(R.id.readerText);
        recorded=state!=null && state.getBoolean("recorded");if(state!=null)font=state.getFloat("font",16);text.setTextSize(font);
        findViewById(R.id.readerBack).setOnClickListener(v->finish());findViewById(R.id.readerContents).setOnClickListener(v->contents());
        findViewById(R.id.readerOptions).setOnClickListener(v->options());
        findViewById(R.id.readerPrevious).setOnClickListener(v->move(-1));findViewById(R.id.readerNext).setOnClickListener(v->move(1));
        findViewById(R.id.readerPage).setOnClickListener(v->page());
        findViewById(R.id.readerZoomIn).setOnClickListener(v->zoom(1.4f));findViewById(R.id.readerZoomOut).setOnClickListener(v->zoom(1/1.4f));
        findViewById(R.id.readerFit).setOnClickListener(v->{canvas.resetZoom();font=16;text.setTextSize(font);});
        findViewById(R.id.readerFavorite).setOnClickListener(v->personal(false));findViewById(R.id.readerWatched).setOnClickListener(v->personal(true));
        controls(false);findViewById(R.id.readerContents).setEnabled(false);
        String id=getIntent().getStringExtra("mediaId");if(id==null){finish();return;}
        history.prepare(id);
        LibraryDatabase.IO.execute(()->{
            MediaEntry loaded=db.library().get(id);ReaderProgress saved=db.library().readerProgress(id);
            runOnUiThread(()->{
                if(isFinishing() || isDestroyed())return;
                if(loaded==null || !DocumentRules.readable(loaded.name)){status("Documento no disponible o sin lector integrado.");return;}
                media=loaded;labels();((TextView)findViewById(R.id.readerTitle)).setText(media.displayTitle());
                String entry=state==null?(saved==null?"":saved.entry):state.getString("entry","");
                int page=state==null?(saved==null?0:saved.page):state.getInt("page",0),position=state==null?(saved==null?0:saved.scroll):state.getInt("scroll",0);
                session=createSession(media);load(entry,page,position,true);
            });
        });
    }
    protected ReaderSession createSession(MediaEntry media){return new ReaderSession(this,Uri.parse(media.uri),media.name);}
    private void controls(boolean ready){for(int id:new int[]{R.id.readerPrevious,R.id.readerNext,R.id.readerPage,R.id.readerZoomIn,R.id.readerZoomOut,R.id.readerFit,R.id.readerFavorite,R.id.readerWatched})findViewById(id).setEnabled(ready);}
    private void load(String entry,int page,int position,boolean opening) {
        ReaderSession activeSession=session;int token=++request;if(pending!=null)pending.cancel(true);controls(false);canvas.setImageBitmap(null);status("Preparando lectura local…");
        pending=worker.submit(()->{
            try {
                if(opening){activeSession.open();List<ArchiveBook.Item> index=activeSession.items();runOnUiThread(()->{if(token==request && !isDestroyed()){entries=index;findViewById(R.id.readerContents).setEnabled(activeSession.archive());}});}
                ReaderSession.Frame frame=activeSession.show(entry,page);
                runOnUiThread(()->{
                    if(token!=request || isFinishing() || isDestroyed()){if(frame.bitmap()!=null)frame.bitmap().recycle();return;}
                    shown=frame;boolean plain=DocumentRules.plain(frame.kind());
                    canvas.setVisibility(plain?View.GONE:View.VISIBLE);scroll.setVisibility(plain?View.VISIBLE:View.GONE);
                    if(plain){text.setText(frame.text());scroll.post(()->{if(shown==frame)scroll.scrollTo(0,position);});}else canvas.setImageBitmap(frame.bitmap());
                    navigation();
                    String label=plain?(frame.kind().equals(DocumentRules.CHAPTER)?"Capítulo "+(frame.page()+1)+" / "+frame.count()+" · Texto sin maquetación · ":"Texto · ")+(frame.truncated()?(frame.kind().equals(DocumentRules.CHAPTER)?"Vista parcial: hasta 200.000 caracteres":"Vista parcial: hasta 1 MiB / 200.000 caracteres"):"Vista completa"):
                        (frame.page()+1)+" / "+frame.count()+" · "+(frame.kind().equals(DocumentRules.PDF)?"PDF":"Álbum")+" · Vista hasta 2048 px";
                    status((frame.entry().isEmpty()?"":frame.entry()+"\n")+label);history.open(media,"reading");persist(position);
                    if(!recorded){recorded=true;LibraryDatabase.IO.execute(()->db.library().recordPlay(media.id,System.currentTimeMillis()));}
                });
            }catch(Exception|OutOfMemoryError error){runOnUiThread(()->{
                if(token!=request || isDestroyed())return;
                String message=error instanceof SecurityException?"PDF protegido o contraseña incorrecta. Abre Opciones para introducirla (Android 15+); también revisa el permiso del archivo.":
                    error instanceof java.io.IOException && error.getMessage()!=null?error.getMessage():"No se pudo abrir este contenido. Revisa formato, permiso y espacio libre.";
                status(message+(shown==null?"":"\nSe conserva la última vista válida."));
                if(shown!=null){if(shown.bitmap()!=null)canvas.setImageBitmap(shown.bitmap());navigation();}
            });}
        });
    }
    private void navigation() {
        if(shown==null)return;boolean plain=shown.kind().equals(DocumentRules.TEXT);controls(true);
        ((TextView)findViewById(R.id.readerPage)).setText(shown.kind().equals(DocumentRules.CHAPTER)?"Capítulo":getString(R.string.reader_page));
        findViewById(R.id.readerPrevious).setEnabled(shown.page()>0 && !plain);
        findViewById(R.id.readerNext).setEnabled(shown.page()+1<shown.count() && !plain);
        findViewById(R.id.readerPage).setEnabled(!plain);
    }
    private void move(int direction) {
        if(shown==null)return;
        if(shown.kind().equals(DocumentRules.PDF)){int page=shown.page()+direction;if(page>=0 && page<shown.count())load(shown.entry(),page,0,false);}
        else if(shown.kind().equals(DocumentRules.IMAGE) || shown.kind().equals(DocumentRules.CHAPTER)){String next=session.adjacent(shown.entry(),direction);if(!next.isEmpty())load(next,0,0,false);}
    }
    private void zoom(float factor){if(shown!=null && DocumentRules.plain(shown.kind())){font=Math.max(12,Math.min(32,font*factor));text.setTextSize(font);}else canvas.zoomBy(factor);}
    private void page() {
        if(shown==null || shown.kind().equals(DocumentRules.TEXT))return;
        EditText input=new EditText(this);input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);input.setText(Integer.toString(shown.page()+1));
        var dialog=new AlertDialog.Builder(this).setTitle((shown.kind().equals(DocumentRules.CHAPTER)?"Ir a capítulo · 1–":"Ir a página · 1–")+shown.count()).setView(input).setPositiveButton("Abrir",null).setNegativeButton("Cancelar",null).create();
        dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            try{int at=Integer.parseInt(input.getText().toString())-1;if(at<0 || at>=shown.count())throw new NumberFormatException();
                String entry=shown.entry();if(shown.kind().equals(DocumentRules.IMAGE) || shown.kind().equals(DocumentRules.CHAPTER))entry=entries.stream().filter(i->i.kind().equals(shown.kind())).toList().get(at).name();
                load(entry,at,0,false);dialog.dismiss();
            }catch(NumberFormatException error){input.setError(shown.kind().equals(DocumentRules.CHAPTER)?"Elige un capítulo dentro del libro.":"Elige una página dentro del documento.");}
        }));dialog.show();
    }
    private void contents() {
        if(entries.isEmpty()){new AlertDialog.Builder(this).setMessage("El archivo no contiene entradas.").setPositiveButton("Cerrar",null).show();return;}
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);EditText query=new EditText(this);query.setHint(session.epub()?"Buscar capítulo o imagen del EPUB":"Buscar archivo dentro del comprimido");query.setSingleLine(true);body.addView(query);
        ListView list=new ListView(this);body.addView(list,new LinearLayout.LayoutParams(-1,(int)(320*getResources().getDisplayMetrics().density)));
        List<Integer> indexes=new ArrayList<>();ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,new ArrayList<>());list.setAdapter(adapter);
        Runnable update=()->{adapter.setNotifyOnChange(false);adapter.clear();indexes.clear();String needle=query.getText().toString().toLowerCase(Locale.ROOT);
            for(int i=0;i<entries.size();i++){ArchiveBook.Item item=entries.get(i);if(item.name().toLowerCase(Locale.ROOT).contains(needle)){indexes.add(i);adapter.add(item.name()+(item.kind().isEmpty()?" · "+session.entryExplanation(item.name()):""));}}adapter.notifyDataSetChanged();};
        query.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){update.run();}public void afterTextChanged(Editable s){}});update.run();
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(session.epub()?"Capítulos e imágenes del EPUB":"Contenido del comprimido").setView(body).setNegativeButton("Cerrar",null).create();
        list.setOnItemClickListener((p,v,at,id)->{ArchiveBook.Item item=entries.get(indexes.get(at));dialog.dismiss();load(item.name(),0,0,false);});dialog.show();
    }
    private void options() {
        if(media==null || session==null)return;
        List<String> labels=new ArrayList<>();List<Runnable> actions=new ArrayList<>();
        if(!session.contents().isEmpty()){labels.add("Índice del libro");actions.add(this::bookContents);}
        if(shown!=null && DocumentRules.plain(shown.kind())){labels.add("Buscar en el texto visible");actions.add(this::findText);}
        if(shown!=null && shown.kind().equals(DocumentRules.PDF)){labels.add("Buscar dentro del PDF (Android 15+)");actions.add(this::findPdf);}
        if(java.util.Set.of(DocumentRules.PDF,DocumentRules.SEVEN).contains(DocumentRules.kind(media.name))){labels.add("Contraseña de PDF / 7z");actions.add(this::password);}
        labels.add("Formatos y límites");actions.add(()->new AlertDialog.Builder(this).setMessage("ZIP/ZIP64: 512 MiB de origen, 64 MiB por entrada; almacenar/Deflate, sin cifrado o volúmenes. 7z: contraseña solo con cabecera sin compresión/cifrado. PDF protegido y búsqueda: Android 15+. EPUB: texto, índice NAV/NCX e imágenes aparte; sin CSS, DRM o contenido remoto. RAR4 sólido, contraseñas RAR, volúmenes y RAR7 comprimido no admitidos. RAR5 sólido compatible: hasta 128 MiB declarados y diccionario de 64 MiB.").setPositiveButton("Cerrar",null).show());
        new AlertDialog.Builder(this).setTitle("Opciones de lectura").setItems(labels.toArray(new String[0]),(d,n)->actions.get(n).run()).setNegativeButton("Cerrar",null).show();
    }
    private void bookContents() {
        List<EpubBook.Contents> rows=session.contents();String[] labels=rows.stream().map(r->"  ".repeat(Math.min(8,r.depth()))+r.label()).toArray(String[]::new);
        new AlertDialog.Builder(this).setTitle("Índice del libro").setItems(labels,(d,n)->{
            var row=rows.get(n);load(row.path(),0,0,false);int token=request;ReaderSession selected=session;
            worker.execute(()->{try{int offset=selected.anchor(row.fragment());runOnUiThread(()->{if(token==request && !isDestroyed() && offset>=0)scrollToCharacter(offset);});}catch(java.io.IOException ignored){}});
        }).setNegativeButton("Cerrar",null).show();
    }
    private void scrollToCharacter(int offset) {
        ReaderSession.Frame target=shown;text.post(()->{if(isDestroyed() || target!=shown || text.getLayout()==null)return;int at=Math.max(0,Math.min(text.length(),offset));int line=text.getLayout().getLineForOffset(at);scroll.scrollTo(0,text.getLayout().getLineTop(line));});
    }
    private void findText() {
        if(shown==null)return;EditText input=new EditText(this);input.setSingleLine(true);input.setHint("Texto a buscar");
        var dialog=new AlertDialog.Builder(this).setTitle("Buscar en el texto visible").setView(input).setPositiveButton("Buscar",null).setNegativeButton("Cerrar",null).create();
        dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String needle=input.getText().toString();if(needle.isEmpty() || needle.length()>128){input.setError("Usa entre 1 y 128 caracteres.");return;}String body=text.getText().toString();int at=body.indexOf(needle);if(at<0){input.setError("No aparece en el texto visible; otro capítulo puede contenerlo.");return;}android.text.SpannableString mark=new android.text.SpannableString(body);mark.setSpan(new android.text.style.BackgroundColorSpan(android.graphics.Color.rgb(120,80,0)),at,at+needle.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);text.setText(mark);scrollToCharacter(at);dialog.dismiss();}));dialog.show();
    }
    private void findPdf() {
        if(!session.searchablePdf()){new AlertDialog.Builder(this).setMessage("Buscar texto PDF requiere Android 15 o posterior. Un PDF escaneado puede necesitar OCR, que no está incluido.").setPositiveButton("Cerrar",null).show();return;}
        EditText input=new EditText(this);input.setSingleLine(true);input.setText(searchQuery);
        var dialog=new AlertDialog.Builder(this).setTitle("Buscar PDF · 16 páginas por consulta").setView(input).setPositiveButton("Buscar",null).setNegativeButton("Cancelar",null).create();
        dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String q=input.getText().toString().trim();if(q.length()<2 || q.length()>128){input.setError("Usa entre 2 y 128 caracteres.");return;}searchQuery=q;searchNext=0;dialog.dismiss();searchPdf();}));dialog.show();
    }
    private void searchPdf() {
        int token=++request;controls(false);ReaderSession selected=session;String query=searchQuery;int start=searchNext;status("Buscando texto PDF…");
        pending=worker.submit(()->{try{ReaderSession.Search result=selected.searchPdf(query,start);runOnUiThread(()->{
            if(token!=request || isDestroyed() || isFinishing())return;navigation();searchNext=result.next();
            String[] labels=result.hits().stream().map(h->"Página "+(h.page()+1)+" · "+h.matches()+" coincidencias").toArray(String[]::new);
            var builder=new AlertDialog.Builder(this).setTitle("PDF · páginas "+(start+1)+"–"+result.next()+" de "+result.total());
            if(labels.length==0)builder.setMessage("Sin coincidencias en estas páginas. Los PDF de imágenes necesitan OCR, que no está incluido.");else builder.setItems(labels,(d,n)->load(shown.entry(),result.hits().get(n).page(),0,false));
            if(result.next()<result.total())builder.setPositiveButton("Siguientes 16",(d,n)->searchPdf());builder.setNegativeButton("Cerrar",null).show();
        });}catch(Exception e){runOnUiThread(()->{if(token==request && !isDestroyed()){navigation();status("No se pudo buscar en este PDF. Conserva la página actual.");}});}});
    }
    private void password() {
        EditText input=new EditText(this);input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);input.setSaveEnabled(false);input.setSingleLine(true);input.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(256)});
        var dialog=new AlertDialog.Builder(this).setTitle("Contraseña solo para esta apertura").setMessage("PDF: Android 15+. 7z: cabecera sin compresión/cifrado. No se guarda y se pedirá otra vez al rotar o reabrir.").setView(input).setPositiveButton("Abrir",null).setNegativeButton("Cancelar",null).create();
        dialog.setOnShowListener(d->{dialog.getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{if(input.length()==0){input.setError("Introduce la contraseña.");return;}char[] secret=new char[input.length()];input.getText().getChars(0,input.length(),secret,0);input.setText("");
            String entry=shown==null?"":shown.entry();int page=shown==null?0:shown.page();if(pending!=null)pending.cancel(true);ReaderSession old=session;old.cancel();worker.execute(old::close);session=createSession(media);session.password(secret);java.util.Arrays.fill(secret,'\0');shown=null;text.setText("");load(entry,page,0,true);dialog.dismiss();});});
        dialog.setOnDismissListener(d->input.setText(""));dialog.show();
    }
    private void personal(boolean watched) {
        if(media==null)return;LibraryDatabase.IO.execute(()->{
            if(watched)db.library().toggleWatched(media.id);else db.library().toggleFavorite(media.id);MediaEntry updated=db.library().get(media.id);
            if(updated!=null)runOnUiThread(()->{if(!isDestroyed()){media=updated;labels();}});
        });
    }
    private void labels(){((TextView)findViewById(R.id.readerFavorite)).setText(media.favorite?"★ Favorito":"☆ Favorito");((TextView)findViewById(R.id.readerWatched)).setText(media.watched?R.string.reader_unread:R.string.reader_read);}
    private void status(String value){((TextView)findViewById(R.id.readerStatus)).setText(value);}
    private void persist(int scroll) {
        if(shown==null || media==null)return;ReaderProgress p=new ReaderProgress();p.mediaId=media.id;p.entry=shown.entry();p.page=shown.page();p.scroll=Math.max(0,Math.min(10000000,scroll));p.updatedAt=System.currentTimeMillis();
        LibraryDatabase.IO.execute(()->{try{ReaderStore.save(db,p);}catch(Exception error){runOnUiThread(()->Toast.makeText(this,"No se pudo guardar la posición de lectura.",Toast.LENGTH_SHORT).show());}});
        history.checkpoint(0,0,p.entry,p.page,p.scroll,"active",false);
    }
    @Override protected void onResume(){super.onResume();if(shown!=null)history.touch("active");}
    @Override protected void onPause(){if(shown!=null)persist(DocumentRules.plain(shown.kind())?scroll.getScrollY():0);history.touch("paused");super.onPause();}
    @Override protected void onSaveInstanceState(Bundle state){if(shown!=null){state.putString("entry",shown.entry());state.putInt("page",shown.page());state.putInt("scroll",scroll.getScrollY());}history.save(state);state.putBoolean("recorded",recorded);state.putFloat("font",font);super.onSaveInstanceState(state);}
    @Override protected void onDestroy(){if(!isChangingConfigurations())history.finish();request++;if(pending!=null)pending.cancel(true);if(session!=null){session.cancel();worker.execute(session::close);}worker.shutdown();canvas.setImageBitmap(null);super.onDestroy();}
}
