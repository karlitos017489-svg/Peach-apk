package com.peach.local;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(tableName="reader_progress",foreignKeys={
    @ForeignKey(entity=MediaEntry.class,parentColumns="id",childColumns="mediaId",onDelete=ForeignKey.CASCADE)})
public class ReaderProgress {
    @PrimaryKey @NonNull public String mediaId="";
    @NonNull public String entry="";
    public int page;
    public int scroll;
    public long updatedAt;
}
