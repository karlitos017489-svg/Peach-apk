package com.peach.local;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileLock;
import java.util.List;

/** Worker-confined local document session with private, disposable storage. */
public final class ReaderSession implements AutoCloseable {
    public interface Pages extends AutoCloseable {int count();Bitmap render(int page,int edge) throws IOException;default boolean searchable(){return false;}default int search(int page,String query)throws IOException{throw new IOException("Búsqueda PDF no disponible en esta versión de Android.");}@Override void close();}
    public interface PdfFactory {Pages open(File file) throws IOException;}
    public record Frame(String entry,String kind,int page,int count,Bitmap bitmap,String text,boolean truncated) {}
    public record Hit(int page,int matches) {}
    public record Search(List<Hit> hits,int next,int total) {}
    public static final long MAX_SOURCE_BYTES=512L*1024*1024;
    private final Context context;private final Uri uri;private final String name;private final PdfFactory pdfFactory;
    private volatile InputStream copying;private volatile boolean cancelled;
    private File directory,source;private RandomAccessFile lockFile;private FileLock lock;
    private volatile ArchiveBook zip;private Pages pdf;private String loaded="";private TextPreview.Result text;
    private boolean opened;private char[] password;private File chapterFile;
    public ReaderSession(Context context,Uri uri,String name){this(context,uri,name,null);}
    ReaderSession(Context context,Uri uri,String name,PdfFactory factory){this.context=context.getApplicationContext();this.uri=uri;this.name=name;this.pdfFactory=factory;}
    public void open() throws IOException {
        if(!"content".equals(uri.getScheme()) || !DocumentRules.readable(name))throw new IOException("Documento no compatible con el lector.");
        try {
            File root=new File(context.getCacheDir(),"peach-reader");if(!root.exists() && !root.mkdirs())throw new IOException("No se pudo preparar la caché de lectura.");
            prune(root);directory=java.nio.file.Files.createTempDirectory(root.toPath(),"session-").toFile();
            lockFile=new RandomAccessFile(new File(directory,"owner.lock"),"rw");lock=lockFile.getChannel().lock();
            check();
            try(InputStream input=context.getContentResolver().openInputStream(uri)) {
                if(input==null)throw new IOException("Documento inaccesible.");copying=input;check();
                if(DocumentRules.kind(name).equals(DocumentRules.TEXT))text=TextPreview.read(input);
                else {
                    source=new File(directory,"source");try(FileOutputStream output=new FileOutputStream(source)) {
                        long bytes=0;byte[] buffer=new byte[65536];int count;
                        while((count=input.read(buffer))!=-1){check();if(count==0)throw new IOException("El documento no devolvió datos.");bytes+=count;
                            if(bytes>MAX_SOURCE_BYTES)throw new IOException("El lector admite documentos y comprimidos de hasta 512 MiB.");
                            if(directory.getUsableSpace()<count+64L*1024*1024)throw new IOException("No hay espacio suficiente para la copia temporal.");output.write(buffer,0,count);}
                    }
                }
            }finally{copying=null;}
            check();if(java.util.Set.of(DocumentRules.ZIP,DocumentRules.TAR,DocumentRules.GZIP,DocumentRules.SEVEN,DocumentRules.EPUB,DocumentRules.RAR).contains(DocumentRules.kind(name)))zip=DocumentRules.kind(name).equals(DocumentRules.RAR)?new RarBook(source,new RarClient(context)):DocumentRules.kind(name).equals(DocumentRules.SEVEN)?new SevenZipBook(source,password):ArchiveBook.open(source,name,directory);
            else if(DocumentRules.kind(name).equals(DocumentRules.PDF))pdf=openPdf(source);
            opened=true;
        }catch(IOException|RuntimeException|Error error){close();throw error;}
    }
    private Pages openPdf(File file) throws IOException {
        Pages pages=pdfFactory==null?new PdfPages(file,password):pdfFactory.open(file);int count=pages.count();
        if(count<1 || count>100000){pages.close();throw new IOException("Número de páginas PDF no compatible.");}return pages;
    }
    private void check() throws InterruptedIOException {if(cancelled || Thread.currentThread().isInterrupted())throw new InterruptedIOException();}
    public boolean epub(){return zip instanceof EpubBook;}
    public List<EpubBook.Contents> contents(){return zip instanceof EpubBook b?b.contents():List.of();}
    public String navigationIssue(){return zip instanceof EpubBook b?b.navigationIssue():"";}
    public void password(char[] value){if(opened || directory!=null)throw new IllegalStateException("Abre una nueva sesión para cambiar la contraseña.");if(value!=null && (value.length<1 || value.length>256))throw new IllegalArgumentException("Usa entre 1 y 256 caracteres.");password=value==null?null:value.clone();}
    public int anchor(String fragment)throws IOException{check();return chapterFile==null?-1:EpubBook.chapter(chapterFile,fragment).anchor();}
    public boolean searchablePdf(){return pdf!=null && pdf.searchable();}
    public Search searchPdf(String query,int start)throws IOException {
        check();if(!opened || pdf==null || !pdf.searchable())throw new IOException("Buscar PDF requiere Android 15 o posterior.");
        query=query.trim();if(query.length()<2 || query.length()>128 || query.chars().anyMatch(c->c<32))throw new IOException("Busca entre 2 y 128 caracteres.");
        int end=Math.min(pdf.count(),Math.max(0,start)+16);List<Hit> found=new java.util.ArrayList<>();int at=Math.max(0,start);
        for(;at<end;at++){check();int matches=pdf.search(at,query);if(matches>0)found.add(new Hit(at,matches));}
        return new Search(List.copyOf(found),at,pdf.count());
    }
    public boolean archive(){return zip!=null;}
    public List<ArchiveBook.Item> items(){return zip==null?List.of():zip.items();}
    public String entryExplanation(String name){return zip instanceof RarBook?zip.explanation(name):"Sin lector integrado";}
    public String firstEntry(){
        if(zip==null)return "";
        if(zip instanceof EpubBook book)return book.chapters().get(0);
        ArchiveBook.Item first=items().stream().filter(i->i.kind().equals(DocumentRules.IMAGE)).findFirst()
            .orElseGet(()->items().stream().filter(i->!i.kind().isEmpty()).findFirst().orElse(null));return first==null?"":first.name();
    }
    public String adjacent(String entry,int direction) {
        String kind=zip!=null && zip.item(entry)!=null?zip.item(entry).kind():DocumentRules.IMAGE;
        List<String> sequence=items().stream().filter(i->i.kind().equals(kind.equals(DocumentRules.CHAPTER)?DocumentRules.CHAPTER:DocumentRules.IMAGE)).map(ArchiveBook.Item::name).toList();
        int at=sequence.indexOf(entry),next=at+direction;return at>=0 && next>=0 && next<sequence.size()?sequence.get(next):"";
    }
    public Frame show(String requested,int page) throws IOException {
        check();if(!opened)throw new IOException("Documento cerrado.");String kind=DocumentRules.kind(name),entry="";
        if(zip!=null) {
            entry=zip.item(requested)==null?firstEntry():requested;ArchiveBook.Item item=zip.item(entry);
            if(item==null){if(zip instanceof RarBook && !items().isEmpty())throw new IOException(zip.explanation(items().get(0).name())+" Puedes consultar su índice.");throw new IOException("El archivo no contiene imágenes o documentos compatibles. Puedes consultar su índice.");}
            kind=item.kind();if(kind.isEmpty())throw new IOException(zip.explanation(entry));
            if(!loaded.equals(entry)) {
                if(pdf!=null){pdf.close();pdf=null;}text=null;chapterFile=null;loaded="";
                File file=zip.read(entry,directory);check();
                if(kind.equals(DocumentRules.PDF))pdf=openPdf(file);
                else if(kind.equals(DocumentRules.CHAPTER)){text=EpubBook.preview(file);chapterFile=file;}
                else if(kind.equals(DocumentRules.TEXT))try(var input=new FileInputStream(file)){text=TextPreview.read(input);}
                loaded=entry;
            }
        }
        if(kind.equals(DocumentRules.PDF)) {
            int index=Math.max(0,Math.min(pdf.count()-1,page));Bitmap bitmap=pdf.render(index,2048);return new Frame(entry,kind,index,pdf.count(),bitmap,"",false);
        }
        if(kind.equals(DocumentRules.IMAGE)) {
            Bitmap bitmap=ImageFiles.decode(new File(directory,"entry"),2048).bitmap();
            List<String> images=items().stream().filter(i->i.kind().equals(DocumentRules.IMAGE)).map(ArchiveBook.Item::name).toList();
            return new Frame(entry,kind,images.indexOf(entry),images.size(),bitmap,"",false);
        }
        if(kind.equals(DocumentRules.CHAPTER)){List<String> chapters=((EpubBook)zip).chapters();return new Frame(entry,kind,chapters.indexOf(entry),chapters.size(),null,text.text(),text.truncated());}
        return new Frame(entry,kind,0,1,null,text.text(),text.truncated());
    }
    public void cancel(){cancelled=true;ArchiveBook book=zip;if(book!=null)book.cancel();InputStream input=copying;if(input!=null)try{input.close();}catch(IOException ignored){}}
    @Override public void close() {
        if(password!=null){java.util.Arrays.fill(password,'\0');password=null;}chapterFile=null;
        opened=false;if(pdf!=null){try{pdf.close();}catch(RuntimeException ignored){}pdf=null;}
        if(zip!=null){try{zip.close();}catch(IOException ignored){}zip=null;}
        if(lock!=null){try{lock.release();}catch(IOException ignored){}lock=null;}
        if(lockFile!=null){try{lockFile.close();}catch(IOException ignored){}lockFile=null;}
        if(directory!=null){remove(directory);directory=null;}
    }
    private static void remove(File directory){File[] children=directory.listFiles();if(children!=null)for(File child:children)if(child.isFile())child.delete();directory.delete();}
    private static void prune(File root) {
        File[] children=root.listFiles();if(children==null)return;
        for(File dir:children)if(dir.isDirectory() && dir.getName().startsWith("session-")) {
            try(RandomAccessFile owner=new RandomAccessFile(new File(dir,"owner.lock"),"rw")) {
                try(FileLock held=owner.getChannel().tryLock()){if(held!=null)remove(dir);}
            }catch(IOException|java.nio.channels.OverlappingFileLockException ignored){ /* Active sessions retain their own cache. */ }
        }
    }
}
