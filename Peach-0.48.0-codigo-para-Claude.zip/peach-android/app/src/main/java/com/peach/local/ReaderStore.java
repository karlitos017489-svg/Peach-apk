package com.peach.local;

import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

public final class ReaderStore {
    private ReaderStore() {}
    public static void save(LibraryDatabase db,ReaderProgress state) {
        validate(state);db.runInTransaction(()->{
            MediaEntry media=db.library().get(state.mediaId);
            if(media!=null && DocumentRules.readable(media.name))db.library().putReaderProgress(state);
        });
    }
    private static void validate(ReaderProgress state) {
        if(state.mediaId.isBlank() || state.entry.length()>4096 || state.page<0 || state.page>100000 || state.scroll<0 || state.scroll>10000000 || state.updatedAt<0)
            throw new IllegalArgumentException("Posición de lectura inválida.");
    }
    public static JSONArray backup(LibraryDao dao) throws Exception {
        JSONArray array=new JSONArray();for(ReaderProgress p:dao.readerProgress())array.put(new JSONObject().put("mediaId",p.mediaId).put("entry",p.entry).put("page",p.page).put("scroll",p.scroll).put("updatedAt",p.updatedAt));
        if(array.length()>50000)throw new IllegalArgumentException("Copia demasiado grande.");return array;
    }
    public static void restore(LibraryDatabase db,JSONObject backup) {
        JSONArray array=backup.optJSONArray("readerProgress");if(array==null || array.length()>50000)throw new IllegalArgumentException("Posiciones de lectura inválidas.");
        Set<String> seen=new HashSet<>();
        for(int i=0;i<array.length();i++) {
            JSONObject row=array.optJSONObject(i);if(row==null || !(row.opt("mediaId") instanceof String id) || !(row.opt("entry") instanceof String entry))throw new IllegalArgumentException("Posición inválida.");
            ReaderProgress p=new ReaderProgress();p.mediaId=id;p.entry=entry;
            long page=integer(row,"page"),scroll=integer(row,"scroll");
            if(page>100000 || scroll>10000000)throw new IllegalArgumentException("Posición inválida.");
            p.page=(int)page;p.scroll=(int)scroll;p.updatedAt=integer(row,"updatedAt");validate(p);
            if(!seen.add(id))throw new IllegalArgumentException("Posición duplicada.");save(db,p);
        }
    }
    private static long integer(JSONObject row,String key) {
        if(!(row.opt(key) instanceof Number value) || value.longValue()<0 || value.doubleValue()!=value.longValue())throw new IllegalArgumentException("Posición inválida.");return value.longValue();
    }
}
