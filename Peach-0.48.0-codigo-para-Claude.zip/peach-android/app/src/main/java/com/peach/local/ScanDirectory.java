package com.peach.local;

import androidx.annotation.NonNull;
import androidx.room.Entity;

@Entity(tableName = "scan_queue", primaryKeys = {"root", "uri"})
public class ScanDirectory {
    @NonNull public String root = "";
    @NonNull public String uri = "";
    @NonNull public String folder = "";
    public boolean done;
    public ScanDirectory() {}
    @androidx.room.Ignore public ScanDirectory(String root, String uri, String folder) {
        this.root = root; this.uri = uri; this.folder = folder;
    }
}
