package com.peach.local;

import android.content.Context;
import android.net.Uri;
import android.os.CancellationSignal;
import android.provider.DocumentsContract;
import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import java.util.concurrent.TimeUnit;

/** Durable directory checkpoints commit atomically with their media and child queue. */
public final class ScanWorker extends Worker {
    static final java.util.concurrent.atomic.AtomicInteger RUNNING=new java.util.concurrent.atomic.AtomicInteger();
    public static final String UNIQUE = "peach-local-scan";
    private final CancellationSignal cancellation = new CancellationSignal();
    public ScanWorker(@NonNull Context context, @NonNull WorkerParameters parameters) { super(context,parameters); }
    public static void enqueue(Context context) {
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(ScanWorker.class)
            .setBackoffCriteria(androidx.work.BackoffPolicy.EXPONENTIAL,15,TimeUnit.SECONDS).build();
        WorkManager.getInstance(context).enqueueUniqueWork(UNIQUE,ExistingWorkPolicy.APPEND_OR_REPLACE,request);
    }
    public static void prepareRefresh(Context context) {
        LibraryDatabase db = LibraryDatabase.get(context);
        db.runInTransaction(() -> {
            for (LibraryRoot root : db.library().roots()) {
                if (root.state==0) {
                    db.library().nextGeneration(root.uri);
                    db.library().clearQueue(root.uri);
                    Uri tree=Uri.parse(root.uri);
                    Uri doc=DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));
                    db.library().enqueue(new ScanDirectory(root.uri,doc.toString(),root.label));
                } else db.library().rootState(root.uri,1);
            }
        });
        enqueue(context);
    }
    @NonNull @Override public Result doWork() { synchronized(FileOrganizer.MUTEX){RUNNING.incrementAndGet();}try{return scanWork();}finally{RUNNING.decrementAndGet();}}
    private Result scanWork() {
        LibraryDatabase db = LibraryDatabase.get(getApplicationContext());
        LibraryDao dao = db.library();
        DocumentScanner scanner=new DocumentScanner(getApplicationContext().getContentResolver());
        java.util.Set<String> trash;
        try{trash=new FileOrganizer(getApplicationContext(),db).trashDirectories();}catch(Exception e){for(LibraryRoot root:dao.roots())dao.rootState(root.uri,2);return Result.failure(new Data.Builder().putString("message","No se pudo verificar el historial de organización. Revisa Historial / papelera.").build());}
        boolean failed=false;
        java.util.Map<String,String> knownIds=new java.util.HashMap<>();for(MediaEntry old:dao.allMedia())knownIds.putIfAbsent(FileOrganizer.key(old.uri),old.id);
        for (LibraryRoot root : dao.roots()) {
            if (root.state==0) continue;
            dao.rootState(root.uri,1);
            try {
                ScanDirectory directory;
                while (!isStopped() && (directory=dao.next(root.uri))!=null) {
                    DocumentScanner.Batch batch=scanner.scan(root,directory,cancellation);
                    if (isStopped()) return Result.failure();
                    ScanDirectory completed=directory;
                    db.runInTransaction(() -> {
                        for(MediaEntry row:batch.media()){String key=FileOrganizer.key(row.uri);row.id=knownIds.getOrDefault(key,row.id);knownIds.putIfAbsent(key,row.id);}
                        for (MediaEntry m : batch.media()) {
                            if (dao.insertMedia(m)==-1) dao.updateScan(m.id,m.uri,m.root,m.name,m.folder,m.title,
                                m.tags,m.actors,m.studio,m.plot,m.year,m.poster,m.subtitles,m.nfoDetails,m.mediaType,m.bytes,m.modified,m.generation);
                        }
                        for (ScanDirectory child : batch.children()) if(!trash.contains(FileOrganizer.key(child.uri)))dao.enqueue(child);
                        dao.done(root.uri,completed.uri);
                        dao.directoryComplete(root.uri,batch.warnings());
                    });
                    setProgressAsync(new Data.Builder().putString("message","Indexando carpetas locales…").build());
                }
                if (isStopped()) return Result.failure();
                db.runInTransaction(() -> { dao.markMissing(root.uri,root.generation);CatalogMetadata.rebuild(db.getOpenHelper().getWritableDatabase());dao.rootState(root.uri,0); });
            } catch (Exception error) {
                if (isStopped()) return Result.failure();
                dao.rootState(root.uri,2); failed=true;
            }
        }
        if (failed && getRunAttemptCount()<2) return Result.retry();
        return failed ? Result.failure(new Data.Builder().putString("message",
            "No se pudo leer una carpeta. Revisa la tarjeta o vuelve a autorizarla.").build()) : Result.success();
    }
    @Override public void onStopped() { cancellation.cancel(); }
}
