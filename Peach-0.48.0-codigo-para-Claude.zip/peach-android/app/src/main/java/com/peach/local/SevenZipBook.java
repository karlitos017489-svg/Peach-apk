package com.peach.local;

import java.io.*;
import java.nio.*;
import java.nio.channels.SeekableByteChannel;
import java.nio.file.*;
import java.util.*;
import java.util.zip.CRC32;
import org.apache.commons.compress.archivers.sevenz.*;

/** Bounded, read-only local 7z. Fresh decoder per selection isolates failed reads. */
public final class SevenZipBook implements ArchiveBook {
    static final int MAX_HEADER=4*1024*1024,MAX_MEMORY_KIB=64*1024;
    private final File source;private final List<Item> items;private final char[] password;
    public SevenZipBook(File source)throws IOException {this(source,null);}
    public SevenZipBook(File source,char[] secret)throws IOException {
        this.source=source;password=secret==null?null:secret.clone();if(password!=null && (password.length<1 || password.length>256))throw new IOException("Contraseña 7z: usa entre 1 y 256 caracteres.");preflight(source);if(password!=null)SevenZipPasswordPolicy.check(source);List<Item> found=new ArrayList<>();Set<String> seen=new HashSet<>();long total=0;
        try(SevenZFile archive=open()) {
            int count=0;for(SevenZArchiveEntry e:archive.getEntries()) {
                if(++count>ZipBook.MAX_ENTRIES)throw new IOException("7z con más de 10.000 entradas.");
                String name=name(e);if(!seen.add(name))throw new IOException("7z con nombres duplicados.");
                if(e.getSize()<0 || e.getSize()>ReaderSession.MAX_SOURCE_BYTES-total)throw new IOException("7z con más de 512 MiB descomprimidos declarados.");total+=e.getSize();
                if(!e.isDirectory())found.add(new Item(name,e.getSize(),regular(e)?DocumentRules.entryKind(name):""));
            }
        }
        found.sort((a,b)->DocumentRules.naturalCompare(a.name(),b.name()));items=List.copyOf(found);
    }
    public List<Item> items(){return items;}
    private SevenZFile open()throws IOException {
        BudgetChannel channel=new BudgetChannel(source);try{return SevenZFile.builder().setSeekableByteChannel(channel).setPassword(password).setMaxMemoryLimitKiB(MAX_MEMORY_KIB).setUseDefaultNameForUnnamedEntries(false).setTryToRecoverBrokenArchives(false).get();}
        catch(org.apache.commons.compress.MemoryLimitException e){channel.close();throw new IOException("Este 7z requiere más memoria que el límite de 64 MiB del lector.",e);}
        catch(IOException|RuntimeException|Error e){channel.close();throw e;}
    }
    private static String name(SevenZArchiveEntry e)throws IOException {
        String name=e.getName();if(name==null)throw new IOException("7z con entrada sin nombre.");ZipBook.safeName(name);return name;
    }
    static boolean regular(SevenZArchiveEntry e) {
        if(e.isDirectory() || e.isAntiItem())return false;
        if(e.getHasWindowsAttributes()) {
            int attributes=e.getWindowsAttributes();if((attributes&0x400)!=0)return false; // reparse point
            if((attributes&0x8000)!=0 && ((attributes>>>16)&0170000)!=0100000)return false; // Unix type
        }
        return true;
    }
    public File read(String name,File directory)throws IOException {
        Item item=item(name);if(item==null || item.kind().isEmpty())throw new IOException("Entrada catalogada sin lector integrado; no se siguen enlaces.");
        if(item.bytes()>ZipBook.MAX_ENTRY_BYTES)throw new IOException("Entrada 7z mayor de 64 MiB.");
        preflight(source);if(password!=null)SevenZipPasswordPolicy.check(source);
        try(SevenZFile archive=open()) {
            for(SevenZArchiveEntry e:archive.getEntries())if(name.equals(name(e))) {
                if(e.getSize()!=item.bytes() || !regular(e))throw new IOException("La entrada 7z cambió.");
                // Empty entries have no decoder/folder. Never ask the library for a stale stream.
                if(e.getSize()==0 && e.getHasCrc() && e.getCrcValue()!=0)throw new IOException("Entrada 7z vacía con CRC no válido.");
                InputStream input=e.getSize()==0?new ByteArrayInputStream(new byte[0]):archive.getInputStream(e);
                return ArchiveFiles.copy(input,directory,"entry",ZipBook.MAX_ENTRY_BYTES,item.bytes());
            }
        }catch(org.apache.commons.compress.MemoryLimitException e){throw new IOException("Este 7z requiere más memoria que el límite de 64 MiB del lector.",e);}
        catch(org.apache.commons.compress.PasswordRequiredException e){throw new IOException("Entrada 7z cifrada: abre Opciones de lectura e introduce su contraseña. Solo cabeceras sin cifrar.",e);}
        throw new IOException("La entrada 7z ya no está disponible.");
    }
    @Override public void close(){if(password!=null)Arrays.fill(password,'\0');} // Active resources live in per-operation try blocks.

    /** Raw and decoded headers are capped before Commons can allocate their buffers. */
    static void preflight(File source)throws IOException {
        long length=source.length();if(length<34 || length>ReaderSession.MAX_SOURCE_BYTES)throw new IOException("Tamaño 7z incompatible o truncado.");
        ArchiveFiles.check(System.nanoTime()+90_000_000_000L);
        try(RandomAccessFile in=new RandomAccessFile(source,"r")) {
            byte[] signature=new byte[32];in.readFully(signature);byte[] magic={0x37,0x7a,(byte)0xbc,(byte)0xaf,0x27,0x1c};
            if(!Arrays.equals(Arrays.copyOf(signature,6),magic) || signature[6]!=0)throw new IOException("Firma o versión 7z no compatible.");
            ByteBuffer start=ByteBuffer.wrap(signature).order(ByteOrder.LITTLE_ENDIAN);long startCrc=Integer.toUnsignedLong(start.getInt(8));
            CRC32 crc=new CRC32();crc.update(signature,12,20);if(crc.getValue()!=startCrc)throw new IOException("Cabecera inicial 7z dañada.");
            long offset=start.getLong(12),size=start.getLong(20),expected=Integer.toUnsignedLong(start.getInt(28));
            if(offset<0 || size<2 || size>MAX_HEADER || size>length-32 || offset!=length-32-size)throw new IOException("Índice 7z truncado, fuera de límite o con datos adicionales.");
            byte[] header=new byte[(int)size];in.seek(32+offset);in.readFully(header);crc.reset();crc.update(header);if(crc.getValue()!=expected)throw new IOException("Índice 7z dañado (CRC).");
            Cursor c=new Cursor(header);int tag=c.byteValue();if(tag==1)return;if(tag!=0x17)throw new IOException("Cabecera 7z no compatible.");
            // Conservative encoded-header subset: one packed stream, one single-input coder.
            c.expect(6);long packPosition=c.number();if(c.number()!=1)throw unsupported();c.expect(9);long packed=c.number();
            if(packPosition>offset || packed>offset-packPosition)throw new IOException("Cabecera comprimida 7z fuera del archivo.");
            tag=c.byteValue();if(tag==10){c.crc();tag=c.byteValue();}if(tag!=0)throw unsupported();
            c.expect(7);c.expect(11);if(c.number()!=1 || c.byteValue()!=0 || c.number()!=1)throw unsupported();
            int flags=c.byteValue(),idLength=flags&15;if((flags&~0x2f)!=0 || idLength<1 || idLength>8)throw unsupported();
            byte[] method=c.bytes(idLength);if(!Arrays.equals(method,new byte[]{0}) && !Arrays.equals(method,new byte[]{0x21}) && !Arrays.equals(method,new byte[]{3,1,1}))throw unsupported();
            if((flags&0x20)!=0){long properties=c.number();if(properties>16)throw unsupported();c.bytes((int)properties);}
            c.expect(12);long unpacked=c.number();if(unpacked<2 || unpacked>MAX_HEADER)throw new IOException("Cabecera 7z expandida mayor de 4 MiB.");
            tag=c.byteValue();if(tag==10){c.crc();tag=c.byteValue();}if(tag!=0)throw unsupported();
            tag=c.byteValue();if(tag==8){tag=c.byteValue();if(tag==13){if(c.number()!=1)throw unsupported();tag=c.byteValue();}if(tag==10){c.crc();tag=c.byteValue();}if(tag!=0)throw unsupported();tag=c.byteValue();}
            if(tag!=0 || !c.ended())throw unsupported();
        }
    }
    static IOException unsupported(){return new IOException("Cabecera 7z comprimida/cifrada no compatible con el lector acotado.");}
    private static final class Cursor {
        final byte[] bytes;int at;
        Cursor(byte[] bytes){this.bytes=bytes;}
        int byteValue()throws IOException{if(at>=bytes.length)throw new EOFException("Cabecera 7z incompleta.");return bytes[at++]&255;}
        byte[] bytes(int n)throws IOException{if(n<0 || n>bytes.length-at)throw new EOFException("Cabecera 7z incompleta.");byte[] value=Arrays.copyOfRange(bytes,at,at+n);at+=n;return value;}
        void expect(int value)throws IOException{if(byteValue()!=value)throw unsupported();}
        long number()throws IOException{int first=byteValue(),mask=128;long value=0;for(int i=0;i<8;i++){if((first&mask)==0){value|=(long)(first&(mask-1))<<(8*i);if(value<0)throw unsupported();return value;}value|=(long)byteValue()<<(8*i);mask>>=1;}if(value<0)throw unsupported();return value;}
        void crc()throws IOException{int all=byteValue();if(all==1)bytes(4);else if(all==0){int defined=byteValue();if((defined&128)!=0)bytes(4);}else throw unsupported();}
        boolean ended(){return at==bytes.length;}
    }
    private static final class BudgetChannel implements SeekableByteChannel {
        final SeekableByteChannel channel;final long deadline=System.nanoTime()+90_000_000_000L;long bytes;
        BudgetChannel(File file)throws IOException{channel=Files.newByteChannel(file.toPath(),StandardOpenOption.READ);}
        public int read(ByteBuffer buffer)throws IOException{ArchiveFiles.check(deadline);int n=channel.read(buffer);if(n>0 && (bytes+=n)>ReaderSession.MAX_SOURCE_BYTES+16L*1024*1024)throw new IOException("Lectura 7z fuera del límite.");return n;}
        public int write(ByteBuffer b)throws IOException{throw new java.nio.channels.NonWritableChannelException();}
        public long position()throws IOException{ArchiveFiles.check(deadline);return channel.position();}
        public SeekableByteChannel position(long p)throws IOException{ArchiveFiles.check(deadline);if(p<0 || p>channel.size())throw new IOException("Posición 7z fuera del archivo.");channel.position(p);return this;}
        public long size()throws IOException{return channel.size();}
        public SeekableByteChannel truncate(long n)throws IOException{throw new java.nio.channels.NonWritableChannelException();}
        public boolean isOpen(){return channel.isOpen();}
        public void close()throws IOException{channel.close();}
    }
}
