package com.peach.local;

import java.io.*;

/** Admit passwords only after bounding actual coder properties in a plain 7z header.
 * Encoded/encrypted headers and additional streams are deliberately outside this subset. */
final class SevenZipPasswordPolicy {
    private SevenZipPasswordPolicy() {}
    static void check(File source)throws IOException {
        try(RandomAccessFile f=new RandomAccessFile(source,"r")) {
            byte[] start=new byte[32];f.readFully(start);
            long offset=le64(start,12),size=le64(start,20);
            if(size<2 || size>SevenZipBook.MAX_HEADER || offset<0 || offset>f.length()-32-size)throw bad();
            byte[] header=new byte[(int)size];f.seek(32+offset);f.readFully(header);checkHeader(header);
        }
    }
    static void checkHeader(byte[] header)throws IOException {
        Cursor c=new Cursor(header);if(c.b()!=1)throw bad();int tag=c.b();
        if(tag==2){while((tag=c.b())!=0)c.skip(c.n());tag=c.b();}
        if(tag==5 || tag==0)return; // no stream coders
        if(tag!=4)throw bad(); // no AdditionalStreamsInfo
        tag=c.b();
        if(tag==6) {
            c.n();int packed=c.count();c.expect(9);for(int i=0;i<packed;i++)c.n();
            tag=c.b();if(tag==10){c.crc(packed);tag=c.b();}if(tag!=0)throw bad();tag=c.b();
        }
        if(tag!=7)throw bad();c.expect(11);int folders=c.count();if(c.b()!=0)throw bad();
        int totalOutputs=0;
        for(int i=0;i<folders;i++) {
            int coders=c.count();if(coders<1 || coders>16)throw bad();int outputs=0;
            for(int j=0;j<coders;j++) {
                int flags=c.b(),idLength=flags&15;if((flags&~0x2f)!=0 || idLength<1 || idLength>8)throw bad();
                byte[] id=c.bytes(idLength); // one input and one output only
                int properties=(flags&32)!=0?c.count():0;if(properties>64)throw bad();byte[] props=c.bytes(properties);
                if(java.util.Arrays.equals(id,new byte[]{6,(byte)0xf1,7,1})) {
                    if(props.length<2)throw bad();int rounds=props[0]&63;
                    if(rounds>20 && rounds!=63)throw new IOException("7z cifrado fuera del límite: derivación de contraseña superior a 2²⁰ rondas.");
                    int salt=((props[0]>>>7)&1)+((props[1]&255)>>>4),iv=((props[0]>>>6)&1)+(props[1]&15);
                    if(props.length!=2+salt+iv)throw bad();
                }
                outputs++;
            }
            for(int j=1;j<outputs;j++){if(c.n()>=outputs || c.n()>=outputs)throw bad();}
            totalOutputs+=outputs;
        }
        c.expect(12);for(int i=0;i<totalOutputs;i++)if(c.n()>ReaderSession.MAX_SOURCE_BYTES)throw bad();
        // All data-stream coders are now checked. Commons validates the remaining
        // substream sizes, checksums and file table; this policy never decodes data.
    }
    private static long le64(byte[] b,int p)throws IOException{long v=0;for(int i=0;i<8;i++)v|=(b[p+i]&255L)<<(8*i);if(v<0)throw bad();return v;}
    private static IOException bad(){return new IOException("Contraseña 7z: requiere cabecera sin compresión/cifrado y métodos acotados; no se guarda la contraseña.");}
    private static final class Cursor {
        final byte[] data;int at;
        Cursor(byte[] data){this.data=data;}
        int b()throws IOException{if(at>=data.length)throw bad();return data[at++]&255;}
        void expect(int x)throws IOException{if(b()!=x)throw bad();}
        long n()throws IOException{int first=b(),mask=128;long v=0;for(int i=0;i<8;i++){if((first&mask)==0){v|=(long)(first&(mask-1))<<(8*i);if(v<0)throw bad();return v;}v|=(long)b()<<(8*i);mask>>=1;}if(v<0)throw bad();return v;}
        int count()throws IOException{long n=n();if(n>10000)throw bad();return (int)n;}
        void skip(long n)throws IOException{if(n<0 || n>data.length-at)throw bad();at+=(int)n;}
        byte[] bytes(int n)throws IOException{int start=at;skip(n);return java.util.Arrays.copyOfRange(data,start,at);}
        void crc(int n)throws IOException{int all=b(),count=n;if(all==0){count=0;for(int i=0;i<n;i+=8){int bits=b();for(int j=0;j<Math.min(8,n-i);j++)if((bits&(128>>>j))!=0)count++;}}else if(all!=1)throw bad();skip(4L*count);}
    }
}
