package com.peach.local;
import java.util.*;

/** Explicitly supplied first-party cookie, never a password or another app's cookie store. */
record SiteSession(String site,String value) {
 static final Set<String> SITES=Set.of("fanbox","patreon","subscribestar.com","subscribestar.adult");
 SiteSession {
  if(!SITES.contains(site)||value==null||value.isBlank()||value.length()>8192||value.chars().anyMatch(c->c<32||c>126))throw new IllegalArgumentException("Sesión no válida; usa solo la cabecera Cookie del sitio, sin saltos de línea.");
  if(value.regionMatches(true,0,"Cookie:",0,7))value=value.substring(7).trim();Set<String> names=new HashSet<>();List<String> pairs=new ArrayList<>();boolean token=false;
  for(String raw:value.split(";",-1)){String pair=raw.trim();int eq=pair.indexOf('=');if(eq<1)throw new IllegalArgumentException("Cabecera Cookie no válida.");String name=pair.substring(0,eq),v=pair.substring(eq+1);if(!name.matches("[!#$%&'*+.^_`|~0-9A-Za-z-]{1,100}")||!names.add(name)||names.size()>64||v.isEmpty()||v.chars().anyMatch(c->!(c==33||c>=35&&c<=43||c>=45&&c<=58||c>=60&&c<=91||c>=93&&c<=126)))throw new IllegalArgumentException("Cabecera Cookie no válida.");token|=v.length()>=16;pairs.add(name+"="+v);}
  if(!token)throw new IllegalArgumentException("No se reconoce un valor de sesión suficiente; completa el acceso oficial.");value=String.join("; ",pairs);
 }
 String redact(String text){String out=Objects.toString(text,"").replace(value,"[oculto]");for(String p:value.split("; ")){String v=p.substring(p.indexOf('=')+1);if(v.length()>=8)out=out.replace(v,"[oculto]").replace(WebSourceUrls.enc(v),"[oculto]");}return out;}
 String fingerprint(){return PartialDownload.key(site+"\0"+value);}
 @Override public String toString(){return "SiteSession[oculta]";}
 static String site(String provider,String ref){return switch(provider){case "fanbox","patreon"->provider;case "subscribestar"->SubscribeStarUrls.creator(ref).split("/",2)[0];default->"";};}
 static String origin(String site){return switch(site){case "fanbox"->"https://www.fanbox.cc";case "patreon"->"https://www.patreon.com";case "subscribestar.com","subscribestar.adult"->"https://"+site;default->throw new IllegalArgumentException("Sitio no admitido.");};}
}
