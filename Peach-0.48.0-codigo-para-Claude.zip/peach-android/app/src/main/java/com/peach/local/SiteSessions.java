package com.peach.local;
import android.content.Context;
import android.util.AtomicFile;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

/** Site-bound authenticated encryption outside backups. Logout does not reset server waits. */
final class SiteSessions {
 static final Object LOCK=new Object();final File directory;final SourceSecrets.KeyProvider keys;
 SiteSessions(Context c){this(c.getNoBackupFilesDir(),()->SourceSecrets.key("PeachSiteSessionsV1"));}
 SiteSessions(File directory,SourceSecrets.KeyProvider keys){this.directory=directory;this.keys=keys;}
 File path(String site){if(!SiteSession.SITES.contains(site))throw new IllegalArgumentException("Sitio no admitido.");return new File(directory,"site-session-"+site+".bin");}
 void write(SiteSession s)throws IOException{synchronized(LOCK){byte[] clear=s.value().getBytes(StandardCharsets.UTF_8);try{Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,keys.get());c.updateAAD(s.site().getBytes(StandardCharsets.US_ASCII));byte[] iv=c.getIV(),sealed=c.doFinal(clear);if(iv.length!=12)throw new GeneralSecurityException();AtomicFile a=new AtomicFile(path(s.site()));FileOutputStream out=null;try{out=a.startWrite();out.write(1);out.write(iv);out.write(sealed);a.finishWrite(out);}catch(IOException e){if(out!=null)a.failWrite(out);throw e;}}catch(GeneralSecurityException e){throw new IOException("No se pudo cifrar la sesión; no se guardó en texto plano.");}finally{Arrays.fill(clear,(byte)0);}}}
 SiteSession read(String site)throws IOException{synchronized(LOCK){File f=path(site);if(!f.exists()&&!new File(f+".bak").exists())return null;try(var in=new AtomicFile(f).openRead()){byte[] raw=SourceHttp.bounded(in,16384,new SourceHttp.Token());if(raw.length<30||raw[0]!=1)throw new GeneralSecurityException();Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,keys.get(),new GCMParameterSpec(128,Arrays.copyOfRange(raw,1,13)));c.updateAAD(site.getBytes(StandardCharsets.US_ASCII));byte[] clear=c.doFinal(raw,13,raw.length-13);try{return new SiteSession(site,SourceHttp.utf8(clear));}finally{Arrays.fill(clear,(byte)0);}}catch(GeneralSecurityException|IllegalArgumentException e){throw new IOException("No se pudo abrir la sesión; vuelve a configurarla para este sitio.");}}}
 void clear(String site){synchronized(LOCK){new AtomicFile(path(site)).delete();}}
 long waitUntil(String site)throws IOException{synchronized(LOCK){File f=new File(path(site)+".wait");if(!f.exists()&&!new File(f+".bak").exists())return 0;try(var in=new AtomicFile(f).openRead()){String s=new String(SourceHttp.bounded(in,32,new SourceHttp.Token()),StandardCharsets.US_ASCII);if(!s.matches("[0-9]{1,16}"))throw new IOException("Espera de cuenta no válida.");return Long.parseLong(s);}}}
 void waitUntil(String site,long until)throws IOException{synchronized(LOCK){long value=Math.max(waitUntil(site),Math.min(System.currentTimeMillis()+86400000L,until));AtomicFile a=new AtomicFile(new File(path(site)+".wait"));FileOutputStream out=null;try{out=a.startWrite();out.write(Long.toString(value).getBytes(StandardCharsets.US_ASCII));a.finishWrite(out);}catch(IOException e){if(out!=null)a.failWrite(out);throw e;}}}
 static void invalidate(LibraryDatabase db,String site){db.runInTransaction(()->{for(FollowSource s:db.library().sources())if(site.equals("f95zone")?s.provider.equals("f95zone"):SiteSession.site(s.provider,s.ref).equals(site)){s.etag="";s.modified="";s.revision++;db.library().updateSource(s);}});}
}
