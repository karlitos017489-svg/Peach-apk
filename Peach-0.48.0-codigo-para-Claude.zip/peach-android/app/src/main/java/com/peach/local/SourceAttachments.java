package com.peach.local;
import java.io.IOException;
import java.util.*;
import org.json.*;

/** An imported attachment identity, never a caller-provided download URL. */
final class SourceAttachments {
    record Item(String name,String url,String kind,String provider,String expectedHash){Item(String name,String url,String kind,String provider){this(name,url,kind,provider,"");}String key(){return PartialDownload.key(url);}}
    static List<Item> load(LibraryDatabase db,String id)throws IOException {
        if(!SourceVideos.id(id))throw new IOException("Publicación no válida.");List<Item> result=new ArrayList<>();IOException[] error={null};
        db.runInTransaction(()->{try{result.addAll(select(db.library().publication(id),db.library().publicationContent(id)));}catch(IOException e){error[0]=e;}});if(error[0]!=null)throw error[0];return List.copyOf(result);
    }
    static List<Item> select(Publication p,PublicationContent c)throws IOException {
        if(p==null||c==null||p.id==null||!p.id.equals(c.publicationId)||p.provider==null||!SourceProviders.KEYS.contains(p.provider))throw new IOException("La publicación no tiene adjuntos importados.");
        if(c.attachments==null||c.attachments.length()>2*1024*1024)throw new IOException("Lista de adjuntos demasiado grande.");
        try{JSONArray a=new JSONArray(c.attachments);if(a.length()>1000)throw new IOException("Demasiados adjuntos.");List<Item> out=new ArrayList<>();Set<String> seen=new HashSet<>();
            for(int i=0;i<a.length();i++){JSONObject j=a.getJSONObject(i);Object n=j.get("name"),u=j.get("url"),d=j.get("downloadable"),k=j.get("kind");
                if(!(n instanceof String name)||name.isBlank()||name.length()>300||!(u instanceof String url)||!(d instanceof Boolean declared)||!(k instanceof String kind))throw new IOException("Adjunto no válido.");
                if(!Set.of("image","video","file").contains(kind)||!SourceVideos.admitted(p.provider,url,declared))continue;
                if(seen.add(url))out.add(new Item(SourceFiles.name(name,url),url,kind,p.provider,PixeldrainUrls.expected(j)));
            }return List.copyOf(out);
        }catch(JSONException e){throw new IOException("Lista de adjuntos no válida.");}
    }
}
