package com.peach.local;

import org.json.*;
import java.util.*;

/** Backup v9: source configuration and public cached content, never credentials or media bytes. */
public final class SourceBackup {
    private SourceBackup() {}
    static JSONObject source(FollowSource s)throws JSONException {
        JSONObject row=new JSONObject();
        row.put("id",s.id);
        row.put("provider",s.provider);
        row.put("ref",s.ref);
        row.put("label",s.label);
        row.put("cachedPage",s.cachedPage);
        row.put("pageUrls",s.pageUrls);
        row.put("lastError",s.lastError);
        row.put("etag",s.etag);
        row.put("modified",s.modified);
        row.put("revision",s.revision);
        row.put("nextPage",s.nextPage);
        row.put("cachePage",s.cachePage);
        row.put("checkedAt",s.checkedAt);
        row.put("cooldownUntil",s.cooldownUntil);
        row.put("paused",s.paused);
        row.put("entityId",s.entityId==null?JSONObject.NULL:s.entityId);
        return row;
    }
    static FollowSource source(JSONObject row)throws Exception {
        FollowSource s=new FollowSource();
        s.id=TrackingBackup.text(row,"id",4096);
        s.provider=TrackingBackup.text(row,"provider",4096);
        s.ref=TrackingBackup.text(row,"ref",4096);
        s.label=TrackingBackup.text(row,"label",4096);
        s.cachedPage=TrackingBackup.text(row,"cachedPage",1024*1024);
        s.pageUrls=TrackingBackup.text(row,"pageUrls",1024*1024);
        s.lastError=TrackingBackup.text(row,"lastError",4096);
        s.etag=TrackingBackup.text(row,"etag",4096);
        s.modified=TrackingBackup.text(row,"modified",4096);
        s.revision=number(row,"revision",9000000000000000L);
        s.nextPage=(int)number(row,"nextPage",5000);
        s.cachePage=(int)number(row,"cachePage",5000);
        s.checkedAt=number(row,"checkedAt",9000000000000000L);
        s.cooldownUntil=number(row,"cooldownUntil",9000000000000000L);
        Object paused=row.opt("paused");if(!(paused instanceof Boolean b))throw new IllegalArgumentException("Pausa de fuente no válida.");s.paused=b;s.entityId=TrackingBackup.nullable(row,"entityId");validateSource(s);return s;
    }
    static long number(JSONObject row,String key,long max){long n=TrackingBackup.number(row,key);if(n>max)throw new IllegalArgumentException("Número de fuente fuera de límite.");return n;}
    static JSONObject content(PublicationContent c)throws JSONException{return new JSONObject().put("publicationId",c.publicationId).put("sourceId",c.sourceId==null?JSONObject.NULL:c.sourceId).put("text",c.text).put("attachments",new JSONArray(c.attachments)).put("type",c.type).put("partial",c.partial).put("checkedAt",c.checkedAt);}
    static void validateAttachments(JSONArray items)throws JSONException {
        if(items.length()>FanboxConnector.MAX_ATTACHMENTS)throw new IllegalArgumentException("Demasiados adjuntos.");Set<String> seen=new HashSet<>();
        for(int i=0;i<items.length();i++){JSONObject a=items.getJSONObject(i);SourceThumbs.validate(a);String url=TrackingBackup.text(a,"url",4096);SourceHttp.https(url);if(!seen.add(url))throw new IllegalArgumentException("Adjunto duplicado.");String kind=TrackingBackup.text(a,"kind",20);if(!List.of("image","file","video").contains(kind) || TrackingBackup.text(a,"name",140).isBlank() || !(a.opt("downloadable") instanceof Boolean b) || b && !SourceHttp.downloadable(url))throw new IllegalArgumentException("Adjunto no válido.");if(b&&PixeldrainUrls.downloadable(url))PixeldrainUrls.validate(a);if(b&&GofileUrls.downloadable(url))GofileReview.validateAsset(a);if(a.has("f95MaskedOriginal"))F95MaskedReview.validateAsset(a);}
    }
    static void validateContent(PublicationContent c){try{if(c.publicationId.isBlank() || c.publicationId.length()>1000 || c.text.length()>FanboxConnector.MAX_TEXT || c.text.indexOf('\0')>=0 || c.type.length()>80 || c.checkedAt<0)throw new IllegalArgumentException("Cuerpo de publicación no válido.");validateAttachments(new JSONArray(c.attachments));SourceStore.bounded(c.attachments,512*1024);}catch(JSONException e){throw new IllegalArgumentException("Adjuntos no válidos.",e);}}
    static void validateSource(FollowSource s)throws Exception {
        if(!SourceProviders.KEYS.contains(s.provider) || !s.ref.equals(SourceProviders.ref(s.provider,s.ref)) || !s.id.equals(SourceProviders.key(s.provider,s.ref)) || !s.label.equals(PlaylistStore.validName(s.label,80)) || s.revision<0 || s.cachePage<0 || s.cachePage>5000 || s.nextPage<0 || s.nextPage>5000 || s.checkedAt<0 || s.cooldownUntil<0 || !s.etag.equals(SourceHttp.header(s.etag)) || !s.modified.equals(SourceHttp.header(s.modified)))throw new IllegalArgumentException("Fuente no válida.");
        SourceStore.bounded(s.cachedPage,1024*1024);SourceStore.bounded(s.pageUrls,1024*1024);JSONArray rows=new JSONArray(s.cachedPage),pages=new JSONArray(s.pageUrls);if(rows.length()>100 || pages.length()>5000)throw new IllegalArgumentException("Caché de fuente demasiado grande.");if(!SourceProviders.history(s.provider) && (pages.length()!=0 || s.cachePage!=0 || s.nextPage!=1))throw new IllegalArgumentException("Este proveedor no admite cursores históricos.");if(SourceProviders.manifested(s.provider)){if(s.cachePage>=5000 || s.nextPage!=s.cachePage+1 || pages.length()>1 || pages.length()==1 && !pages.getString(0).equals(SourceProviders.pageUrl(s.provider,s.ref,s.nextPage)))throw new IllegalArgumentException("Página Pawchive no válida.");}else for(int i=0;i<pages.length();i++)FanboxConnector.cursor(pages.getString(i),s.ref);Set<String> ids=new HashSet<>();
        for(int i=0;i<rows.length();i++){JSONObject row=rows.getJSONObject(i);String id=s.provider.equals("cumst")?CumstUrls.id(row.opt("id")):s.provider.equals("pawchive")?PawchiveUrls.postId(row.opt("id")):FanboxConnector.id(row.opt("id"));if(!ids.add(id))throw new IllegalArgumentException("Publicación repetida en caché.");String title=TrackingBackup.text(row,"title",300),date=TrackingBackup.text(row,"date",4096),precision=TrackingBackup.text(row,"precision",80);Publication p=new Publication();p.id=id;p.title=title;p.publishedAt=date;p.precision=precision;PublicationStore.validate(p);PublicationContent c=new PublicationContent();c.publicationId=id;c.text=TrackingBackup.text(row,"text",FanboxConnector.MAX_TEXT);c.attachments=row.getJSONArray("attachments").toString();c.type=TrackingBackup.text(row,"type",80);if(!(row.opt("partial") instanceof Boolean b))throw new IllegalArgumentException("Estado de cuerpo no válido.");c.partial=b;validateContent(c);if(SourceProviders.web(s.provider)){if(!row.getString("url").equals(WebSourceUrls.post(s.provider,s.ref,id,row.getString("url"))) || !c.partial || !List.of("list",s.provider.equals("rule34paheal")?"paheal-detail":s.provider.equals("rule34video")?"rule34video-detail":"list").contains(c.type))throw new IllegalArgumentException("Caché de fuente no válida.");}if(s.provider.equals("cumst")){CumstUrls.postUrl(s.ref,row.getString("url"),id);if(!List.of("list","cumst-detail").contains(c.type) || !c.partial)throw new IllegalArgumentException("Cuerpo cum.st no válido.");JSONArray attachments=new JSONArray(c.attachments);for(int a=0;a<attachments.length();a++)if(!CumstUrls.downloadable(attachments.getJSONObject(a).getString("url")))throw new IllegalArgumentException("Adjunto de otra fuente en caché cum.st.");}if(s.provider.equals("pawchive")){PawchiveUrls.postUrl(s.ref,row.getString("url"),id);if(!List.of("list","pawchive-detail").contains(c.type) || !c.partial)throw new IllegalArgumentException("Cuerpo Pawchive no válido.");}
        if(s.provider.equals("patreon") || s.provider.equals("subscribestar")){SourceProviders.postUrl(s.provider,s.ref,id,row.getString("url"));if(!c.partial || !(c.type.equals(s.provider+"-visible-detail") || c.type.equals("public-card")&&new JSONArray(c.attachments).length()==0))throw new IllegalArgumentException("Tarjeta pública de fuente no válida.");if(c.type.equals(s.provider+"-visible-detail")){JSONArray a=new JSONArray(c.attachments);for(int n=0;n<a.length();n++)if(!s.provider.equals(ProviderMediaUrls.provider(a.getJSONObject(n).getString("url"))))throw new IllegalArgumentException("Adjunto de otro proveedor en cuerpo visible.");}}}
    }
    public static void write(LibraryDao dao,JSONObject backup)throws Exception {
        JSONArray sources=new JSONArray(),contents=new JSONArray();if(dao.sources().size()>100 || dao.publicationContents().size()>10000)throw new IllegalArgumentException("Demasiadas fuentes o cuerpos.");
        for(FollowSource s:dao.sources()){validateSource(s);sources.put(source(s));}for(PublicationContent c:dao.publicationContents()){validateContent(c);contents.put(content(c));}backup.put("sources",sources).put("publicationContent",contents);
    }
    public static void restore(LibraryDao dao,JSONObject backup)throws Exception {
        JSONArray sources=backup.getJSONArray("sources"),contents=backup.getJSONArray("publicationContent"),entities=backup.getJSONArray("entities"),publications=backup.getJSONArray("publications");if(sources.length()>100 || contents.length()>10000)throw new IllegalArgumentException("Demasiadas fuentes o cuerpos.");Set<String> ids=new HashSet<>(),entityIds=new HashSet<>(),publicationIds=new HashSet<>(),seen=new HashSet<>();
        for(int i=0;i<entities.length();i++)entityIds.add(entities.getJSONObject(i).getString("id"));for(int i=0;i<publications.length();i++)publicationIds.add(publications.getJSONObject(i).getString("id"));
        for(int i=0;i<sources.length();i++){FollowSource s=source(sources.getJSONObject(i));if(!ids.add(s.id) || s.entityId!=null && !entityIds.contains(s.entityId))throw new IllegalArgumentException("Fuente duplicada o identidad ajena.");FollowSource old=dao.source(s.id);if(old==null){if(dao.sources().size()>=100)throw new IllegalArgumentException("Máximo 100 fuentes.");dao.insertSource(s);}else{s.revision=Math.max(s.revision,old.revision)+1;dao.updateSource(s);}}
        for(String id:publicationIds)dao.deletePublicationContent(id);
        for(int i=0;i<contents.length();i++){JSONObject row=contents.getJSONObject(i);PublicationContent c=new PublicationContent();c.publicationId=TrackingBackup.text(row,"publicationId",1000);c.sourceId=TrackingBackup.nullable(row,"sourceId");c.text=TrackingBackup.text(row,"text",FanboxConnector.MAX_TEXT);c.attachments=row.getJSONArray("attachments").toString();c.type=TrackingBackup.text(row,"type",80);if(!(row.opt("partial") instanceof Boolean b))throw new IllegalArgumentException("Estado de cuerpo no válido.");c.partial=b;c.checkedAt=TrackingBackup.number(row,"checkedAt");validateContent(c);if(!seen.add(c.publicationId) || !publicationIds.contains(c.publicationId) || c.sourceId!=null && !ids.contains(c.sourceId))throw new IllegalArgumentException("Cuerpo duplicado o referencia ajena.");dao.putPublicationContent(c);}
    }
}
