package com.peach.local;
import java.util.*;

/** Pure presentation of cached source results and imported posts; never merges different creators. */
final class SourceBrowserItems {
    record Item(Publication publication,PublicationContent content,boolean pending,String state){}
    static String name(String provider){if(!SourceProviders.KEYS.contains(provider))return provider==null||provider.isBlank()?"Publicación guardada":FanboxConnector.clipped(provider.replaceAll("[\\p{Cntrl}]"," "),50);String s=SourceProviders.label(provider);int dot=s.indexOf(" · ");return dot<0?s:s.substring(0,dot);}
    static List<Item> select(List<Item> items,String query,int type,int order){String q=query.trim().toLowerCase(Locale.ROOT);List<Item> out=new ArrayList<>();for(Item item:items){Publication p=item.publication;PublicationContent c=item.content;if(!q.isEmpty()&&!(p.title+" "+p.sourceLabel+" "+(c==null?"":c.text)).toLowerCase(Locale.ROOT).contains(q))continue;
        boolean image=false,video=false;try{if(c!=null){image=!SourceGallery.select(p,c).images().isEmpty();video=!SourceVideos.select(p,c).videos().isEmpty();}}catch(Exception ignored){}
        if(type==1&&!image||type==2&&!video||type==3&&(image||video))continue;out.add(item);
    }Comparator<Item> cmp=order==2?Comparator.comparing(i->i.publication.title.toLowerCase(Locale.ROOT)):Comparator.comparing(i->i.publication.publishedAt==null?"":i.publication.publishedAt);if(order==0)cmp=cmp.reversed();out.sort(cmp);return List.copyOf(out);}
    static List<Item> combine(FollowSource source,SourceStore.Review review,List<Publication> saved,List<PublicationContent> contents,boolean savedOnly){
        Map<String,PublicationContent> bodies=new HashMap<>();for(var c:contents)bodies.put(c.publicationId,c);LinkedHashMap<String,Item> result=new LinkedHashMap<>();
        for(var p:saved)if(savedOnly||source!=null&&p.provider.equals(source.provider)&&SourceStore.sameRef(p.provider,p.sourceRef,source.ref))result.put(p.id,new Item(p,bodies.get(p.id),false,"Guardada"));
        if(!savedOnly&&review!=null)for(var row:review.rows())result.put(row.publication().id,new Item(row.publication(),row.content(),true,row.state()));return List.copyOf(result.values());
    }
    static String summary(Item item){PublicationContent c=item.content;if(c==null)return "Sin contenido guardado";int images=0,videos=0,files=0;try{var a=new org.json.JSONArray(c.attachments);for(int n=0;n<a.length();n++){if(a.getJSONObject(n).optBoolean("peachThumbnailOnly",false))continue;String kind=a.getJSONObject(n).optString("kind");if(kind.equals("image"))images++;else if(kind.equals("video"))videos++;else files++;}}catch(Exception ignored){}List<String> parts=new ArrayList<>();if(images>0)parts.add(images+(images==1?" imagen":" imágenes"));if(videos>0)parts.add(videos+(videos==1?" video":" videos"));if(files>0)parts.add(files+(files==1?" archivo":" archivos"));return parts.isEmpty()?"Publicación de texto":String.join(" · ",parts);}
}
