package com.peach.local;
import java.io.IOException;
public interface SourceCredentials {
    record ApiKey(String userId,String key){
        public ApiKey{if(userId==null || !userId.matches("[1-9][0-9]{0,19}") || key==null || key.isEmpty() || key.length()>512 || key.chars().anyMatch(c->c<33||c>126))throw new IllegalArgumentException("Usuario o clave API no válidos.");}
        @Override public String toString(){return "ApiKey[oculta]";}
    }
    default SiteSession siteSession(String site)throws IOException{return null;}
    default long siteWaitUntil(String site)throws IOException{return 0;}
    default void siteWaitUntil(String site,long end)throws IOException{}
    ApiKey rule34()throws IOException;
    default F95Session f95()throws IOException{return null;}
    default long f95WaitUntil()throws IOException{return 0;}
    default void f95WaitUntil(long end)throws IOException{}
    static SourceCredentials local(android.content.Context app){return new SourceCredentials(){
        public SiteSession siteSession(String site)throws IOException{return new SiteSessions(app).read(site);}
        public long siteWaitUntil(String site)throws IOException{return new SiteSessions(app).waitUntil(site);}
        public void siteWaitUntil(String site,long end)throws IOException{new SiteSessions(app).waitUntil(site,end);}
        public ApiKey rule34()throws IOException{return new SourceSecrets(app).read();}
        public F95Session f95()throws IOException{return new F95Secrets(app).read();}
        public long f95WaitUntil()throws IOException{return new F95Secrets(app).waitUntil();}
        public void f95WaitUntil(long end)throws IOException{new F95Secrets(app).waitUntil(end);}
    };}
}
