package com.peach.local;

import android.content.Intent;
import android.net.Uri;
import java.net.URI;
import java.util.Locale;

/** Local document metadata only; never fetches a URL or turns a reference into a download. */
final class SourceFiles {
    private SourceFiles() {}
    static String name(String original,String url) {
        String name=original==null?"":original.replaceAll("[\\p{Cntrl}/\\\\]","_").trim();
        if(name.isBlank())name="Adjunto";
        if(name.length()>140)name=name.substring(0,140);
        String ext=MediaRules.extension(name);
        if(ext.isEmpty() || ext.equals("bin"))try{
            String path=new URI(url).getPath(),candidate=path.substring(path.lastIndexOf('/')+1);
            String from=MediaRules.extension(candidate);
            if(!mime(candidate).equals("application/octet-stream"))
                name=(ext.equals("bin")?MediaRules.stem(name):name)+"."+from;
        }catch(Exception ignored) { /* Unknown formats keep their original identity. */ }
        return name;
    }
    static String mime(String name) {
        return switch(MediaRules.extension(name).toLowerCase(Locale.ROOT)) {
            case "mp4","m4v"->"video/mp4";case "webm"->"video/webm";case "mkv"->"video/x-matroska";
            case "mov"->"video/quicktime";case "avi"->"video/x-msvideo";case "ts","m2ts"->"video/mp2t";
            case "mpg","mpeg"->"video/mpeg";case "3gp"->"video/3gpp";case "flv"->"video/x-flv";
            case "wmv"->"video/x-ms-wmv";
            case "jpg","jpeg"->"image/jpeg";case "png"->"image/png";case "gif"->"image/gif";
            case "webp"->"image/webp";case "bmp"->"image/bmp";case "heic"->"image/heic";case "heif"->"image/heif";
            case "mp3"->"audio/mpeg";case "m4a"->"audio/mp4";case "aac"->"audio/aac";
            case "wav"->"audio/wav";case "flac"->"audio/flac";case "ogg","oga","opus"->"audio/ogg";
            case "pdf"->"application/pdf";case "epub"->"application/epub+zip";
            case "txt"->"text/plain";case "zip","cbz"->"application/zip";
            case "rar","cbr"->"application/vnd.rar";case "7z"->"application/x-7z-compressed";
            case "gz","tgz"->"application/gzip";case "tar"->"application/x-tar";
            default->"application/octet-stream";
        };
    }
    static Intent create(String name) {
        return new Intent(Intent.ACTION_CREATE_DOCUMENT).setType(mime(name)).addCategory(Intent.CATEGORY_OPENABLE)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            .putExtra(Intent.EXTRA_TITLE,name);
    }
    static Intent pickVideo() {
        // Previously saved octet-stream documents must remain selectable too.
        return new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
    }
    static boolean local(Uri uri) {return uri!=null && "content".equals(uri.getScheme()) && uri.getAuthority()!=null && !uri.getAuthority().isEmpty();}
    static Intent play(android.content.Context context,Uri uri,String name) {
        if(!local(uri))throw new IllegalArgumentException("Elige un archivo local autorizado.");
        return new Intent(context,PlayerActivity.class).setData(uri).putExtra("localVideo",true)
            .putExtra("localVideoName",name==null?"Video local":name);
    }
    static Intent openMedia(android.content.Context context,Uri uri,String name,String kind) {
        if(!local(uri))throw new IllegalArgumentException("Elige un archivo local autorizado.");
        if("image".equals(kind))return new Intent(context,ImageViewerActivity.class).setData(uri).putExtra("localImage",true).putExtra("localImageName",name);
        return play(context,uri,name);
    }
    static MediaEntry localVideo(Intent intent) {
        if(!intent.getBooleanExtra("localVideo",false) || !local(intent.getData()))return null;
        MediaEntry media=new MediaEntry();media.id=intent.getData().toString();media.uri=media.id;
        String name=intent.getStringExtra("localVideoName");media.name=name==null?"Video local":name;
        media.title=media.name;media.mediaType=MediaRules.VIDEO;return media;
    }
}
