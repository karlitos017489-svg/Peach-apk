package com.peach.local;

import java.io.IOException;
import java.util.*;
import org.json.*;

/** Resolves only imported metadata. Opening a gallery never queries a creator or stores media rows. */
public final class SourceGallery {
    public record Image(String name,String url,String expectedHash) {public Image(String name,String url){this(name,url,"");}}
    public record Selection(String publicationId,String title,String source,List<Image> images,boolean partial,int omitted) {
        public Selection { images=List.copyOf(images); }
    }
    private SourceGallery() {}
    /** A saved image stays inside its provider's existing attachment contract. */
    static boolean admitted(String provider,String url,boolean declared) {
        if(!SourceHttp.canSave(url,declared))return false;
        if(SourceProviders.KEYS.contains(provider)&&(GofileUrls.downloadable(url)||PixeldrainUrls.downloadable(url)))return true;
        String host=SourceHttp.https(url).getHost().toLowerCase(Locale.ROOT);
        return switch(provider) {
            case "patreon","subscribestar"->provider.equals(ProviderMediaUrls.provider(url));
            case "fanbox"->Set.of("downloads.fanbox.cc","pixivfanbox.akamaized.net").contains(host);
            case "pawchive"->PawchiveUrls.downloadable(url);
            case "cumst"->CumstUrls.downloadable(url);
            case "rule34paheal"->host.equals("r34i.paheal-cdn.net");
            case "rule34xxx"->host.equals("api-cdn.rule34.xxx");
            case "f95zone"->host.equals("attachments.f95zone.to");
            default->false;
        };
    }
    public static Selection load(LibraryDatabase db,String id) throws IOException {
        Selection[] result={null};IOException[] error={null};
        db.runInTransaction(()->{try{result[0]=select(db.library().publication(id),db.library().publicationContent(id));}catch(IOException e){error[0]=e;}});
        if(error[0]!=null)throw error[0];return result[0];
    }
    public static Selection select(Publication p,PublicationContent c)throws IOException {
        if(p==null || c==null || p.id==null || !p.id.equals(c.publicationId) || p.provider==null || !SourceProviders.KEYS.contains(p.provider))throw new IOException("Esta publicación no tiene imágenes compatibles consultadas e importadas.");
        if(c.attachments==null || c.attachments.length()>2*1024*1024)throw new IOException("Lista de imágenes demasiado grande.");
        try {
            JSONArray items=new JSONArray(c.attachments);if(items.length()>1000)throw new IOException("Demasiados adjuntos.");
            List<Image> images=new ArrayList<>();Set<String> seen=new HashSet<>();int omitted=0;
            for(int i=0;i<items.length();i++) {
                JSONObject item=items.getJSONObject(i);String kind=item.getString("kind");
                if(!"image".equals(kind)){omitted++;continue;}
                Object n=item.get("name"),u=item.get("url"),d=item.get("downloadable");
                if(!(n instanceof String name) || name.isBlank() || name.length()>300 || !(u instanceof String url) || !(d instanceof Boolean allowed))throw new IOException("Metadatos de imagen no válidos.");
                if(!admitted(p.provider,url,allowed)){omitted++;continue;}
                if(seen.add(url))images.add(new Image(name,url,PixeldrainUrls.expected(item)));
            }
            return new Selection(p.id,p.title,p.sourceLabel+" · "+p.sourceRef,images,c.partial,omitted);
        }catch(JSONException e){throw new IOException("Lista de imágenes no válida.",e);}
    }
}
