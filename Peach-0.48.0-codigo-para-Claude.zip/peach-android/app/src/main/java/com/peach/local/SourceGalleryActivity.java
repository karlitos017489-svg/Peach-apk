package com.peach.local;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;
import java.util.concurrent.*;

/** Native image canvas. Its only input is a saved publication ID, never a caller URL. */
public final class SourceGalleryActivity extends PeachActivity {
    static GalleryCache.Fetcher fetcher=SourceHttp::image;
    final ExecutorService worker=Executors.newSingleThreadExecutor();
    SourceGallery.Selection selection;
    SourceHttp.Token token;
    Future<?> pending;
    ZoomImageView canvas;
    CheckBox offline;
    int index,generation;
    boolean started,shown,resumed;
    GalleryCache.Frame displayed;
    String restoredKey="";
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);setContentView(R.layout.activity_image);androidx.core.view.WindowCompat.setDecorFitsSystemWindows(getWindow(),false);
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.imageRoot),(view,insets)->{var bars=insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars()|androidx.core.view.WindowInsetsCompat.Type.displayCutout());view.setPadding(bars.left,bars.top,bars.right,bars.bottom);return insets;});
        canvas=findViewById(R.id.imageCanvas);findViewById(R.id.imageFavorite).setVisibility(View.GONE);
        LinearLayout tools=new LinearLayout(this);offline=new CheckBox(this);offline.setId(R.id.gallery_offline);offline.setText(R.string.gallery_offline);
        offline.setChecked(state==null?getSharedPreferences("source-gallery",MODE_PRIVATE).getBoolean("offline",false):state.getBoolean("offline"));tools.addView(offline);
        Button retry=new Button(this);retry.setId(R.id.gallery_retry);retry.setText(R.string.gallery_retry);tools.addView(retry);((LinearLayout)findViewById(R.id.imageRoot)).addView(tools,2);
        if(state!=null)restoredKey=state.getString("imageKey","");
        findViewById(R.id.imageBack).setOnClickListener(v->finish());
        findViewById(R.id.imagePrevious).setOnClickListener(v->{if(index>0){index--;showImage();}});
        findViewById(R.id.imageNext).setOnClickListener(v->{if(selection!=null && index+1<selection.images().size()){index++;showImage();}});
        findViewById(R.id.imageZoomIn).setOnClickListener(v->canvas.zoomBy(1.5f));findViewById(R.id.imageZoomOut).setOnClickListener(v->canvas.zoomBy(1/1.5f));findViewById(R.id.imageFit).setOnClickListener(v->canvas.resetZoom());
        findViewById(R.id.imageDetails).setOnClickListener(v->{if(selection!=null && !selection.images().isEmpty()){var im=selection.images().get(index);TextView text=new TextView(this);text.setPadding(24,24,24,24);text.setTextIsSelectable(true);text.setText(getString(R.string.gallery_details,selection.source(),im.name(),im.url(),selection.omitted(),selection.partial()?getString(R.string.gallery_partial):"")+"\n\n"+getString(R.string.gallery_scope));new AlertDialog.Builder(this).setTitle(selection.title()).setView(text).setPositiveButton("Cerrar",null).show();}});
        retry.setOnClickListener(v->showImage());offline.setOnCheckedChangeListener((b,value)->{getSharedPreferences("source-gallery",MODE_PRIVATE).edit().putBoolean("offline",value).apply();if(selection!=null)showImage();});controls(false);status(getString(R.string.gallery_loading));
        String id=getIntent().getStringExtra("publicationId");if(id==null || id.isBlank() || id.length()>1000){unavailable();return;}
        LibraryDatabase.IO.execute(()->{try{var loaded=SourceGallery.load(LibraryDatabase.get(this),id);runOnUiThread(()->{if(isDestroyed() || isFinishing())return;selection=loaded;for(int i=0;i<loaded.images().size();i++)if(GalleryCache.key(loaded.images().get(i).url()).equals(restoredKey))index=i;if(loaded.images().isEmpty()){unavailable();return;}if(started)showImage();});}catch(Exception e){runOnUiThread(()->{if(!isDestroyed())unavailable();});}});
    }
    void unavailable(){selection=null;controls(false);status(getString(R.string.gallery_unavailable));}
    void status(String text){((TextView)findViewById(R.id.imageStatus)).setText(text);}
    void controls(boolean image){for(int id:new int[]{R.id.imageZoomIn,R.id.imageZoomOut,R.id.imageFit})findViewById(id).setEnabled(image);findViewById(R.id.imagePrevious).setEnabled(selection!=null && index>0);findViewById(R.id.imageNext).setEnabled(selection!=null && index+1<selection.images().size());findViewById(R.id.gallery_retry).setEnabled(selection!=null);findViewById(R.id.imageDetails).setEnabled(selection!=null);}
    void cancel(){generation++;if(token!=null)token.cancel();if(pending!=null)pending.cancel(true);}
    void clearImage(){AnimatedImages.stop(canvas.getDrawable());canvas.setImageDrawable(null);if(displayed!=null){displayed.release();displayed=null;}}
    void showImage(){
        if(!started || selection==null || selection.images().isEmpty())return;cancel();int request=generation;token=new SourceHttp.Token();SourceHttp.Token current=token;var image=selection.images().get(index);boolean cachedOnly=offline.isChecked();shown=false;clearImage();controls(false);
        ((TextView)findViewById(R.id.imageTitle)).setText(selection.title());canvas.setContentDescription(image.name());status(getString(R.string.gallery_request,index+1,selection.images().size()));
        pending=worker.submit(()->{try{GalleryCache.Frame frame=new GalleryCache(getCacheDir()).acquire(image,cachedOnly,current,fetcher);runOnUiThread(()->{if(request!=generation || !started || isDestroyed() || isFinishing()){frame.release();return;}displayed=frame;if(frame.animation()!=null){canvas.setImageDrawable(frame.animation());canvas.resetZoom();if(resumed)AnimatedImages.start(frame.animation());}else canvas.setImageBitmap(frame.image().bitmap());shown=true;controls(true);status(getString(R.string.gallery_ready,index+1,selection.images().size(),getString(frame.cached()?R.string.gallery_cache_hit:R.string.gallery_downloaded))+(frame.animation() instanceof android.graphics.drawable.Animatable?getString(R.string.gallery_animated):""));});}
            catch(Exception | OutOfMemoryError e){String message=e instanceof OutOfMemoryError?getString(R.string.gallery_memory):e.getMessage();runOnUiThread(()->{if(request!=generation || !started || isDestroyed() || isFinishing())return;controls(false);status(message==null?getString(R.string.gallery_unavailable):message);});}});
    }
    @Override protected void onStart(){super.onStart();started=true;if(selection!=null && !shown)showImage();}
    @Override protected void onResume(){super.onResume();resumed=true;AnimatedImages.start(canvas.getDrawable());}
    @Override protected void onPause(){resumed=false;AnimatedImages.stop(canvas.getDrawable());super.onPause();}
    @Override protected void onStop(){started=false;cancel();super.onStop();}
    @Override protected void onDestroy(){cancel();worker.shutdownNow();clearImage();super.onDestroy();}
    @Override protected void onSaveInstanceState(Bundle state){super.onSaveInstanceState(state);state.putBoolean("offline",offline.isChecked());if(selection!=null && !selection.images().isEmpty())state.putString("imageKey",GalleryCache.key(selection.images().get(index).url()));}
}
