package com.peach.local;

import javax.net.ssl.HttpsURLConnection;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

/** Bounded direct HTTPS. No browser, cookie jar, credential input or automatic retry. */
public final class SourceHttp {
    public static final int JSON_LIMIT=2*1024*1024;
    public static final long IMAGE_LIMIT=16L*1024*1024;
    public static final long DOWNLOAD_LIMIT=128L*1024*1024;
    public static final long LARGE_DOWNLOAD_LIMIT=2L*1024*1024*1024;
    public static final class Token {
        volatile boolean cancelled;volatile HttpsURLConnection connection;
        public void cancel(){cancelled=true;HttpsURLConnection c=connection;if(c!=null)c.disconnect();}
        void check()throws InterruptedIOException{if(cancelled || Thread.currentThread().isInterrupted())throw new InterruptedIOException("Consulta cancelada.");}
    }
    public record Response(int status,byte[] bytes,String etag,String modified) {}
    public interface Transport {Response get(String url,String etag,String modified,Token token)throws IOException;}
    public static class Failure extends IOException {
        public final int status;public final long retrySeconds;
        Failure(String text,int status,long retrySeconds){super(text);this.status=status;this.retrySeconds=retrySeconds;}
    }
    interface MediaSessions{SiteSession read(String site)throws IOException;}
    static volatile MediaSessions mediaSessions=site->null;
    private SourceHttp() {}
    static URI https(String url) {
        try {URI u=new URI(url);if(url.length()>4096 || !"https".equalsIgnoreCase(u.getScheme()) || u.getHost()==null || u.getRawUserInfo()!=null || u.getFragment()!=null || u.getPort()!=-1 && u.getPort()!=443 || url.chars().anyMatch(c->c<32))throw new IllegalArgumentException();return u;}
        catch(Exception e){throw new IllegalArgumentException("URL HTTPS no válida.");}
    }
    static void api(String url){URI u=https(url);if(!u.getHost().equalsIgnoreCase("api.fanbox.cc") || !Set.of("/post.listCreator","/post.paginateCreator","/post.info").contains(u.getPath()))throw new IllegalArgumentException("Dirección de API no admitida.");}
    public static boolean downloadable(String url){try{String host=https(url).getHost().toLowerCase(Locale.ROOT);return Set.of("downloads.fanbox.cc","pixivfanbox.akamaized.net").contains(host) || PawchiveUrls.downloadable(url) || CumstUrls.downloadable(url) || WebSourceUrls.downloadable(url) || GofileUrls.downloadable(url) || ProviderMediaUrls.downloadable(url) || PixeldrainUrls.downloadable(url);}catch(IllegalArgumentException e){return false;}}
    public static boolean canSave(String url,boolean declared){return downloadable(url) && (declared || PawchiveUrls.downloadable(url));}
    static void attachmentRedirect(String original,String next)throws IOException{if(PixeldrainUrls.downloadable(original)||PixeldrainUrls.downloadable(next)){if(!original.equals(next))throw new IOException("Redirección Pixeldrain no admitida.");return;}if(ProviderMediaUrls.downloadable(original)||ProviderMediaUrls.downloadable(next)){try{ProviderMediaUrls.redirect(original,next);return;}catch(IllegalArgumentException e){throw new IOException(e.getMessage());}}if(!downloadable(next) || GofileUrls.downloadable(original)!=GofileUrls.downloadable(next) || GofileUrls.downloadable(original)&&!original.equals(next) || WebSourceUrls.downloadable(original)!=WebSourceUrls.downloadable(next) || WebSourceUrls.downloadable(original) && !original.equals(next) || CumstUrls.downloadable(original)!=CumstUrls.downloadable(next) || CumstUrls.downloadable(original) && !original.equals(next) || PawchiveUrls.downloadable(original)!=PawchiveUrls.downloadable(next) || PawchiveUrls.downloadable(original) && !PawchiveUrls.sameMedia(original,next))throw new IOException("Redirección de adjunto fuera de su origen o hash admitido.");}
    static String header(String value){return value!=null && value.length()<=1000 && value.chars().noneMatch(c->c<32 || c==127)?value:"";}
    static long retry(String raw){try{return Math.max(1,Math.min(86400,Long.parseLong(raw)));}catch(Exception e){try{return Math.max(1,Math.min(86400,java.time.Duration.between(java.time.Instant.now(),java.time.ZonedDateTime.parse(raw,java.time.format.DateTimeFormatter.RFC_1123_DATE_TIME).toInstant()).getSeconds()));}catch(Exception ignored){return 300;}}}
    interface ConnectionFactory {HttpsURLConnection open(String url)throws IOException;}
    static HttpsURLConnection open(String url,String etag,String modified,Token token,boolean json)throws IOException {
        return open(url,etag,modified,token,json,u->(HttpsURLConnection)new URL(u).openConnection(),InetAddress::getAllByName);
    }
    static HttpsURLConnection open(String url,String etag,String modified,Token token,boolean json,ConnectionFactory factory,MediaRedirects.Resolver resolver)throws IOException {
        return open(url,etag,modified,token,json,factory,resolver,-1,"");
    }
    static HttpsURLConnection open(String url,String etag,String modified,Token token,boolean json,ConnectionFactory factory,MediaRedirects.Resolver resolver,long range,String ifRange)throws IOException {
        return openFrom(url,url,etag,modified,token,json,factory,resolver,range,ifRange);
    }
    static HttpsURLConnection openDelivery(String original,String delivery,Token token,ConnectionFactory factory,MediaRedirects.Resolver resolver,long range,String ifRange)throws IOException {
        if(!MediaRedirects.videoSource(original))throw new IOException("El origen no admite reutilizar un destino de entrega.");
        return openFrom(original,delivery,"","",token,false,factory,resolver,range,ifRange);
    }
    private static HttpsURLConnection openFrom(String url,String first,String etag,String modified,Token token,boolean json,ConnectionFactory factory,MediaRedirects.Resolver resolver,long range,String ifRange)throws IOException {
        if(json&&range>=0)throw new IOException("Las consultas de contenido no admiten rangos de descarga.");
        if(!first.equals(url)&&(json||!MediaRedirects.videoSource(url)))throw new IOException("Destino de entrega no admitido para este origen.");
        String current=first;boolean handoff=!json&&MediaRedirects.videoSource(url);boolean extra=json && WebSourceUrls.html(url);boolean html=json && (extra || Set.of("www.patreon.com","patreon.com").contains(https(url).getHost().toLowerCase(Locale.ROOT)) || SubscribeStarUrls.site(https(url).getHost()));boolean star=html && SubscribeStarUrls.site(https(url).getHost());boolean post=html&&!extra&&(star?https(url).getPath().matches("/posts/[0-9]{1,30}/?"):PatreonUrls.POST.matcher(https(url).getPath()).matches());String creator=html && !extra&&!post?(star?SubscribeStarUrls.creator(url):PatreonUrls.creator(url)):"";
        for(int redirects=0;redirects<=3;redirects++) {
            token.check();try{if(html){if(extra)WebSourceUrls.redirect(url,current);else if(post)AccountHttp.same(url,current);else if(star)SubscribeStarUrls.creatorPage(current,creator);else PatreonUrls.creatorPage(current,creator);}else if(json){if(PawchiveUrls.site(https(url).getHost())){PawchiveUrls.api(current);if(!current.equals(url))throw new IllegalArgumentException("Redirección de API Pawchive no admitida.");}else if(CumstUrls.site(https(url).getHost())){CumstUrls.api(current);if(!current.equals(url))throw new IllegalArgumentException("Redirección de API cum.st no admitida.");}else if("api.rule34.xxx".equals(https(url).getHost())){WebSourceUrls.api(current);if(!url.equals(current))throw new IllegalArgumentException("Redirección API no admitida.");}else api(current);}else {if(handoff&&!current.equals(url))MediaRedirects.check(url,current,resolver,token);else {if(!downloadable(current))throw new IllegalArgumentException("Dirección de adjunto no admitida.");attachmentRedirect(url,current);}}}catch(IllegalArgumentException e){throw new IOException(e.getMessage(),e);}
            if(!json&&(GofileUrls.downloadable(current)||ProviderMediaUrls.downloadable(current)||PixeldrainUrls.downloadable(current)))GofileUrls.publicHost(current,resolver,token);
            HttpsURLConnection c=factory.open(current);token.connection=c;c.setConnectTimeout(15000);c.setReadTimeout(15000);c.setInstanceFollowRedirects(false);c.setUseCaches(false);
            c.setRequestProperty("User-Agent","PeachLocal-Android/0.37.0");c.setRequestProperty("Accept",html?"text/html":json?(PawchiveUrls.site(https(url).getHost())?"text/css":"application/json"):"*/*");c.setRequestProperty("Accept-Encoding","identity");if(Set.of("api.fanbox.cc","downloads.fanbox.cc","pixivfanbox.akamaized.net").contains(https(url).getHost().toLowerCase(Locale.ROOT))){c.setRequestProperty("Origin","https://www.fanbox.cc");c.setRequestProperty("Referer","https://www.fanbox.cc/");}
            if(!json){String h=https(current).getHost().toLowerCase(Locale.ROOT);String site=h.equals("downloads.fanbox.cc")?"fanbox":Set.of("subscribestar.com","subscribestar.adult").contains(h)&&ProviderMediaUrls.downloadable(current)?h:"";if(!site.isEmpty()){try{SiteSession session=mediaSessions.read(site);if(session!=null)c.setRequestProperty("Cookie",session.value());}catch(IOException e){c.disconnect();token.connection=null;throw new IOException("No se pudo abrir la sesión del sitio para este adjunto; vuelve a configurarla.");}}}
            if(!header(etag).isEmpty())c.setRequestProperty("If-None-Match",etag);if(!header(modified).isEmpty())c.setRequestProperty("If-Modified-Since",modified);
            if(range>0){c.setRequestProperty("Range","bytes="+range+"-");if(!header(ifRange).isEmpty())c.setRequestProperty("If-Range",ifRange);}
            int status;
            try{token.check();status=c.getResponseCode();token.check();}catch(IOException e){c.disconnect();token.connection=null;if(handoff&&!current.equals(url)&&!token.cancelled)throw new IOException("No se pudo conectar con el servidor de descarga: "+MediaRedirects.host(current)+".");throw e;}
            if(Set.of(301,302,303,307,308).contains(status)){String next=c.getHeaderField("Location");c.disconnect();token.connection=null;if(next==null || redirects==3)throw new IOException("Redirección de fuente no admitida.");try{current=URI.create(current).resolve(next).toString();}catch(IllegalArgumentException e){throw new IOException("El servidor devolvió un destino de descarga inválido.");}if(extra)current=WebSourceUrls.cleanRedirect(url,current);continue;}
            if(status==429){long seconds=retry(c.getHeaderField("Retry-After"));c.disconnect();token.connection=null;throw new Failure("La fuente pidió esperar antes de consultar de nuevo.",429,seconds);}
            if(status!=200 && !(range>=0&&Set.of(206,416).contains(status)) && !(json && status==304) && !(json && (PawchiveUrls.site(https(url).getHost()) && Set.of(400,404).contains(status) || WebSourceUrls.html(url) && status==404))){c.disconnect();token.connection=null;if(handoff&&!current.equals(url))throw new Failure("Servidor de descarga "+MediaRedirects.host(current)+" respondió HTTP "+status+".",status,0);throw new Failure(status==401 || status==403?"La fuente denegó la consulta (HTTP "+status+"). Puede requerir sesión o verificación en el sitio; este conector no las completa. Caché conservada.":"La fuente respondió HTTP "+status+".",status,0);}
            return c;
        }throw new IOException("Demasiadas redirecciones.");
    }
    public static Transport direct(){return (url,etag,modified,token)->{
        HttpsURLConnection c;try{c=open(url,etag,modified,token,true);}catch(Failure e){throw e;}catch(InterruptedIOException e){throw e;}catch(IOException|IllegalArgumentException e){if(url.startsWith("https://api.rule34.xxx/"))throw new IOException("No se pudo consultar la API; credenciales ocultas.");throw e;}
        try {
            int status=c.getResponseCode();if(status==400 || status==404)return new Response(status,new byte[0],"","");if(status==304)return new Response(status,new byte[0],header(c.getHeaderField("ETag")),header(c.getHeaderField("Last-Modified")));
            String mime=Objects.toString(c.getContentType(),"").toLowerCase(Locale.ROOT);boolean html=WebSourceUrls.html(url) || Set.of("www.patreon.com","patreon.com").contains(https(url).getHost().toLowerCase(Locale.ROOT)) || SubscribeStarUrls.site(https(url).getHost());if(html?!mime.startsWith("text/html") && !mime.startsWith("application/xhtml+xml"):!mime.startsWith("application/json"))throw new IOException("La fuente no devolvió el formato esperado; conserva la consulta anterior.");
            if(c.getContentLengthLong()>JSON_LIMIT)throw new IOException("Respuesta mayor de 2 MiB.");
            try(InputStream in=c.getInputStream()){return new Response(status,bounded(in,JSON_LIMIT,token),header(c.getHeaderField("ETag")),header(c.getHeaderField("Last-Modified")));}
        }catch(InterruptedIOException e){throw e;}catch(IOException e){if(url.startsWith("https://api.rule34.xxx/"))throw new IOException("No se pudo leer la API; credenciales ocultas.");throw e;}finally{c.disconnect();token.connection=null;}
    };}
    static byte[] bounded(InputStream input,int max,Token token)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[16384];int n;long deadline=System.nanoTime()+60_000_000_000L;while((n=input.read(b))!=-1){token.check();if(out.size()+n>max)throw new IOException("Respuesta demasiado grande.");if(System.nanoTime()>deadline)throw new IOException("La consulta excedió su tiempo máximo.");out.write(b,0,n);}token.check();return out.toByteArray();}
    public record Download(long bytes,String sha256) {}
    public static Download download(String url,File target,Token token)throws IOException {return download(url,target,token,DOWNLOAD_LIMIT);}
    public static Download downloadLarge(String url,File target,Token token)throws IOException {return download(url,target,token,LARGE_DOWNLOAD_LIMIT);}
    static Download download(String url,File target,Token token,long limit)throws IOException {
        return download(url,target,token,limit,u->(HttpsURLConnection)new URL(u).openConnection(),InetAddress::getAllByName);
    }
    static Download download(String url,File target,Token token,long limit,ConnectionFactory factory,MediaRedirects.Resolver resolver)throws IOException {
        HttpsURLConnection c=null;boolean done=false;
        try {
            c=open(url,"","",token,false,factory,resolver);
            long expected=c.getContentLengthLong();if(expected>limit)throw new IOException("El adjunto supera el límite de "+(limit/(1024*1024))+" MiB; no se creó un archivo de destino.");long space=target.getParentFile().getUsableSpace();if(expected>0 && space>0 && expected>(space-64L*1024*1024)/2)throw new IOException("No hay espacio temporal suficiente para esta descarga.");String mime=Objects.toString(c.getContentType(),"").toLowerCase(Locale.ROOT);if(mime.contains("text/html") || mime.contains("application/json"))throw new IOException("El servidor devolvió una página en lugar del adjunto.");
            InputStream input;try{input=c.getInputStream();}catch(IOException e){if(MediaRedirects.videoSource(url))throw new IOException("No se pudo abrir el archivo en el servidor de descarga: "+MediaRedirects.host(c.getURL().toString())+".");throw e;}Download result=copyAttachment(url,input,target,expected,token,limit);done=true;return result;
        }finally{if(c!=null)c.disconnect();token.connection=null;if(!done)target.delete();}
    }
    static Download copyAttachment(String url,InputStream input,File target,long expected,Token token)throws IOException {return copyAttachment(url,input,target,expected,token,DOWNLOAD_LIMIT);}
    static Download copyAttachment(String url,InputStream input,File target,long expected,Token token,long limit)throws IOException {
        boolean done=false;try{if(!downloadable(url))throw new IOException("Dirección de adjunto no admitida.");Download result=copy(input,target,expected,token,limit);if(PawchiveUrls.downloadable(url) && !result.sha256().equals(PawchiveUrls.expectedHash(url)))throw new IOException("El archivo no coincide con el SHA-256 de su referencia Pawchive; no se guardó.");done=true;return result;}finally{try{input.close();}finally{if(!done)target.delete();}}
    }
    static Download copy(InputStream input,File target,long expected,Token token)throws IOException {
        return copy(input,target,expected,token,DOWNLOAD_LIMIT);
    }
    static Download copy(InputStream input,File target,long expected,Token token,long limit)throws IOException {
        boolean done=false;
        try {
            if(limit<1 || limit>LARGE_DOWNLOAD_LIMIT)throw new IOException("Límite no válido.");
            if(expected>limit)throw new IOException("El adjunto supera el límite permitido.");
            MessageDigest digest;try{digest=MessageDigest.getInstance("SHA-256");}catch(Exception e){throw new AssertionError(e);}long nextSpaceCheck=8L*1024*1024,total=0,deadline=System.nanoTime()+(limit>DOWNLOAD_LIMIT?3_600_000_000_000L:120_000_000_000L);
            try(InputStream in=input;OutputStream out=new FileOutputStream(target)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1){token.check();total+=n;if(total>limit || System.nanoTime()>deadline)throw new IOException("El adjunto excede el límite de tamaño o tiempo.");if(limit>DOWNLOAD_LIMIT && total>=nextSpaceCheck){long space=target.getParentFile().getUsableSpace();if(space>0 && space<total+64L*1024*1024)throw new IOException("No hay espacio suficiente para preparar y guardar la descarga.");nextSpaceCheck=total+8L*1024*1024;}digest.update(b,0,n);out.write(b,0,n);}}
            token.check();if(total==0 || expected>=0 && expected!=total)throw new IOException("Descarga incompleta.");StringBuilder hex=new StringBuilder();for(byte b:digest.digest())hex.append(String.format(Locale.ROOT,"%02x",b&255));done=true;return new Download(total,hex.toString());
        }finally{try{input.close();}finally{if(!done)target.delete();}}
    }
    public static Download image(String url,File target,Token token)throws IOException {
        return image(url,target,token,u->(HttpsURLConnection)new URL(u).openConnection(),InetAddress::getAllByName);
    }
    static Download image(String url,File target,Token token,ConnectionFactory factory,MediaRedirects.Resolver resolver)throws IOException {
        HttpsURLConnection c=open(url,"","",token,false,factory,resolver);boolean done=false;
        try {
            String mime=Objects.toString(c.getContentType(),"").split(";",2)[0].trim().toLowerCase(Locale.ROOT);
            if(!(mime.isEmpty() || mime.equals("application/octet-stream") || mime.startsWith("image/") && !mime.equals("image/svg+xml")))throw new IOException("La fuente no devolvió una imagen compatible.");
            Download result=copyAttachment(url,c.getInputStream(),target,c.getContentLengthLong(),token,IMAGE_LIMIT);done=true;return result;
        }finally{c.disconnect();token.connection=null;if(!done)target.delete();}
    }
    static String utf8(byte[] raw)throws IOException{try{return StandardCharsets.UTF_8.newDecoder().onMalformedInput(java.nio.charset.CodingErrorAction.REPORT).decode(java.nio.ByteBuffer.wrap(raw)).toString();}catch(java.nio.charset.CharacterCodingException e){throw new IOException("JSON con codificación no válida.",e);}}
}
