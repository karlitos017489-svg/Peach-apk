package com.peach.local;

import org.json.JSONArray;

/** Normalized pending page shared by implemented source adapters. */
public record SourcePage(JSONArray candidates,String etag,String modified,int skipped,boolean unchanged) {}
