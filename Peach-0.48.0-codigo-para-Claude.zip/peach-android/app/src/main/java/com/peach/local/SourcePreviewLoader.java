package com.peach.local;
import android.content.Context;
import android.graphics.Bitmap;
import android.util.LruCache;
import android.widget.ImageView;
import java.util.*;
import java.util.concurrent.*;

/** Only visible result cards request images, after an explicit search/refresh. Never fetches videos. */
final class SourcePreviewLoader {
    static GalleryCache.Fetcher fetcher=SourceHttp::image;
    private static final LruCache<String,Bitmap> memory=new LruCache<>(8*1024*1024){@Override protected int sizeOf(String k,Bitmap b){return b.getAllocationByteCount();}};
    private final ThreadPoolExecutor worker=new ThreadPoolExecutor(2,2,20,TimeUnit.SECONDS,new ArrayBlockingQueue<>(24),new ThreadPoolExecutor.AbortPolicy());
    private final Set<SourceHttp.Token> tokens=ConcurrentHashMap.newKeySet();private final Set<String> failed=ConcurrentHashMap.newKeySet();private final Context app;private volatile int epoch;private volatile boolean active=true;
    SourcePreviewLoader(Context c){app=c.getApplicationContext();}
    static void clearMemory(){memory.evictAll();}
    static SourceGallery.Image image(Publication p,PublicationContent c){if(p==null||c==null)return null;try{
        var images=SourceGallery.select(p,c).images();if(!images.isEmpty())return images.get(0);
        var a=new org.json.JSONArray(c.attachments);for(int i=0;i<a.length();i++){var preview=a.getJSONObject(i).optJSONObject("peachPreview");if(preview!=null){String url=preview.getString("url"),name=preview.getString("name");if(name.length()<=140&&SourceThumbs.admitted(p.provider,url))return new SourceGallery.Image(name,url);}}
    }catch(Exception ignored){}return null;}
    void bind(ImageView view,Publication p,PublicationContent c,boolean online){
        SourceGallery.Image image=image(p,c);String key=image==null?"":GalleryCache.key(image.url())+"|"+image.expectedHash();view.setTag(key);view.setScaleType(ImageView.ScaleType.CENTER_INSIDE);view.setImageDrawable(PeachDesign.icon(app,image==null?R.drawable.ic_ui_file:R.drawable.ic_ui_image,UiAppearance.secondary(app)));if(image==null)return;
        Bitmap cached=memory.get(key);if(cached!=null){view.setScaleType(ImageView.ScaleType.CENTER_CROP);view.setImageBitmap(cached);return;}if(!active||failed.contains(key))return;int generation=epoch;SourceHttp.Token token=new SourceHttp.Token();tokens.add(token);
        try{worker.execute(()->{GalleryCache.Frame frame=null;try{token.check();Bitmap result;if(SourceThumbs.special(p.provider,image.url()))result=SourceThumbs.acquire(app.getCacheDir(),p.provider,image,!online,token);else{frame=new GalleryCache(app.getCacheDir()).acquirePreview(image,!online,token,fetcher);result=frame.image().bitmap();}token.check();memory.put(key,result);frame=null;view.post(()->{if(active&&epoch==generation&&key.equals(view.getTag())){view.setScaleType(ImageView.ScaleType.CENTER_CROP);view.setImageBitmap(result);}});}catch(Exception|OutOfMemoryError ignored){if(!token.cancelled)failed.add(key);}finally{if(frame!=null)frame.release();tokens.remove(token);}});}catch(RejectedExecutionException ignored){tokens.remove(token);}
    }
    void resume(){active=true;failed.clear();}
    void cancel(){active=false;epoch++;tokens.forEach(SourceHttp.Token::cancel);worker.getQueue().clear();tokens.clear();}
    void reset(){cancel();resume();}
    void close(){cancel();worker.shutdownNow();}
}
