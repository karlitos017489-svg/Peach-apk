package com.peach.local;

import java.nio.charset.StandardCharsets;
import java.util.*;

/** Only implemented providers are offered. Provider keys also namespace local identities. */
public final class SourceProviders {
    public static final List<String> KEYS=List.of("fanbox","patreon","subscribestar","pawchive","cumst","rule34paheal","rule34xxx","rule34video","f95zone");
    private SourceProviders() {}
    public static String label(String provider){return switch(provider){case "fanbox"->"FANBOX · público / sesión opcional";case "patreon"->"Patreon · tarjetas y cuerpo visible";case "subscribestar"->"SubscribeStar · tarjetas y cuerpo visible";case "pawchive"->"Pawchive · API pública";case "cumst"->"cum.st (OnlyHaven) · API pública";case "rule34paheal"->"Rule34 Paheal · etiquetas";case "rule34xxx"->"Rule34.xxx · API con clave";case "rule34video"->"Rule34Video · autores";case "f95zone"->"F95zone · respuestas públicas";default->throw new IllegalArgumentException("Proveedor no incorporado.");};}
    public static String ref(String provider,String input){return switch(provider){case "fanbox"->FanboxConnector.creator(input);case "patreon"->PatreonConnector.creator(input);case "subscribestar"->SubscribeStarUrls.creator(input);case "pawchive"->PawchiveUrls.creator(input);case "cumst"->CumstUrls.creator(input);case "rule34paheal","rule34xxx","rule34video","f95zone"->WebSourceUrls.creator(provider,input);default->throw new IllegalArgumentException("Proveedor no incorporado.");};}
    public static String key(String provider,String input){return UUID.nameUUIDFromBytes(("peach-source\0"+provider+"\0"+ref(provider,input)).getBytes(StandardCharsets.UTF_8)).toString();}
    public static boolean history(String provider){return provider.equals("fanbox") || offset(provider) || pagedWeb(provider);}
    public static boolean detail(String provider){return provider.equals("fanbox") || provider.equals("patreon") || provider.equals("subscribestar") || offset(provider) || provider.equals("rule34paheal") || provider.equals("rule34video");}
    public static boolean web(String provider){return WebSourceUrls.PROVIDERS.contains(provider);}
    public static boolean pagedWeb(String provider){return web(provider) && !provider.equals("f95zone");}
    public static boolean manifested(String provider){return offset(provider) || pagedWeb(provider);}
    public static boolean offset(String provider){return provider.equals("pawchive") || provider.equals("cumst");}
    static String pageUrl(String provider,String ref,int index){return web(provider)?WebSourceUrls.page(provider,ref,index):provider.equals("cumst")?CumstUrls.page(ref,index):PawchiveUrls.page(ref,index);}
    public static String contentLabel(PublicationContent c){return c.type.equals("public-card")?"Tarjeta pública (adelanto)":c.partial?"Resumen o cuerpo parcial":"Cuerpo consultado";}
    public static String precisionLabel(String value){return switch(value){case "exact"->"exacta";case "approximate"->"aproximada";default->"desconocida";};}
    public static boolean summary(String type){return type.equals("list") || type.equals("public-card");}
    public static String postUrl(String provider,String ref,String id,String candidate){if(web(provider))return WebSourceUrls.post(provider,ref,id,candidate);if(provider.equals("cumst"))return CumstUrls.postUrl(ref,id);if(provider.equals("pawchive"))return PawchiveUrls.postUrl(ref,id);if(provider.equals("fanbox"))return "https://"+ref+".fanbox.cc/posts/"+id;if(provider.equals("subscribestar"))return SubscribeStarUrls.postUrl(ref,candidate,id);return PatreonConnector.postUrl(ref,candidate,id);}
}
