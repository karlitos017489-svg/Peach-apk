package com.peach.local;
import android.content.Context;
import android.security.keystore.*;
import android.util.AtomicFile;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.Arrays;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

/** A single site key; ciphertext outside backups, no plaintext fallback. */
public final class SourceSecrets {
    interface KeyProvider{SecretKey get()throws GeneralSecurityException,IOException;}
    private static final Object LOCK=new Object();
    private final File path;private final KeyProvider keys;
    public SourceSecrets(Context app){this(new File(app.getNoBackupFilesDir(),"source-rule34-api.bin"),()->key("PeachSourceApiV1"));}
    SourceSecrets(File path,KeyProvider keys){this.path=path;this.keys=keys;}
    static SecretKey key(String alias)throws GeneralSecurityException,IOException{
        KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
        if(store.containsAlias(alias))return (SecretKey)store.getKey(alias,null);
        KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        gen.init(new KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build());
        return gen.generateKey();
    }
    void write(SourceCredentials.ApiKey value)throws IOException{synchronized(LOCK){
        byte[] clear=(value.userId()+"\n"+value.key()).getBytes(StandardCharsets.UTF_8);
        try{
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,keys.get());byte[] sealed=cipher.doFinal(clear),iv=cipher.getIV();if(iv.length!=12)throw new GeneralSecurityException();
            AtomicFile file=new AtomicFile(path);FileOutputStream out=null;
            try{out=file.startWrite();out.write(1);out.write(iv);out.write(sealed);file.finishWrite(out);}catch(IOException e){if(out!=null)file.failWrite(out);throw e;}
        }catch(GeneralSecurityException e){throw new IOException("No se pudo cifrar la clave API; no se guardó en texto plano.");}finally{Arrays.fill(clear,(byte)0);}
    }}
    SourceCredentials.ApiKey read()throws IOException{synchronized(LOCK){
        if(!path.exists()&&!new File(path+".bak").exists())return null;
        try(InputStream in=new AtomicFile(path).openRead()){
            ByteArrayOutputStream buffer=new ByteArrayOutputStream();byte[] chunk=new byte[256];int n;
            while((n=in.read(chunk))!=-1){if(buffer.size()+n>1024)throw new IOException("Archivo de clave fuera de límite.");buffer.write(chunk,0,n);}
            byte[] encoded=buffer.toByteArray();if(encoded.length<30||encoded[0]!=1)throw new GeneralSecurityException();
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,keys.get(),new GCMParameterSpec(128,Arrays.copyOfRange(encoded,1,13)));
            byte[] clear=cipher.doFinal(encoded,13,encoded.length-13);
            try{String[] parts=new String(clear,StandardCharsets.UTF_8).split("\n",-1);if(parts.length!=2)throw new GeneralSecurityException();return new SourceCredentials.ApiKey(parts[0],parts[1]);}finally{Arrays.fill(clear,(byte)0);}
        }catch(GeneralSecurityException|IllegalArgumentException e){throw new IOException("La clave API guardada no se puede descifrar. Vuelve a configurarla en la tablet.");}
    }}
    void clear(){synchronized(LOCK){new AtomicFile(path).delete();}}
}
