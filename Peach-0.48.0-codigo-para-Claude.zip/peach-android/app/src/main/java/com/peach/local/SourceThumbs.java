package com.peach.local;
import android.graphics.Bitmap;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.net.ssl.HttpsURLConnection;
import org.json.*;

/** Thumbnail-only routes. They never become download/stream URLs or receive account headers. */
final class SourceThumbs {
    static final long LIMIT=2L*1024*1024,BUDGET=24L*1024*1024;private static final Object LOCK=new Object();private static final Map<String,Long> waits=new HashMap<>();
    static boolean special(String provider,String raw){try{URI u=SourceHttp.https(raw);if(u.getRawQuery()!=null||u.getRawFragment()!=null)return false;String p=u.getRawPath();return provider.equals("rule34video")&&u.getHost().equals("rule34video.com")&&p.matches("/contents/videos_screenshots/[0-9]{1,12}/[0-9]{1,12}/(?:preview|[0-9]{1,5})\\.(?:jpg|webp)")||provider.equals("rule34xxx")&&u.getHost().equals("api-cdn.rule34.xxx")&&p.matches("/(?:thumbnails/[0-9]{1,12}/thumbnail_|samples/[0-9]{1,12}/sample_)[a-f0-9]{32}\\.(?:jpg|jpeg|png|webp)");}catch(Exception e){return false;}}
    static boolean admitted(String provider,String url){return special(provider,url)||SourceGallery.admitted(provider,url,true);}
    static void mark(JSONObject attachment,String provider,String url)throws JSONException{if(attachment!=null&&admitted(provider,url))attachment.put("peachPreview",new JSONObject().put("url",url).put("name","Vista previa"));}
    static void validate(JSONObject attachment)throws JSONException{if(!attachment.has("peachPreview"))return;JSONObject p=attachment.getJSONObject("peachPreview");String u=TrackingBackup.text(p,"url",4096),name=TrackingBackup.text(p,"name",140);SourceHttp.https(u);if(name.isBlank())throw new IllegalArgumentException("Vista previa sin nombre.");}
    static int clear(java.io.File cache){synchronized(LOCK){File root=new File(cache,"peach-source-thumbs");File[] files=root.listFiles();int count=0;if(files!=null)for(File f:files)if(f.isFile()&&f.getName().matches("[a-f0-9]{64}\\.image")&&f.delete())count++;return count;}}
    static Bitmap acquire(File cache,String provider,SourceGallery.Image image,boolean offline,SourceHttp.Token token)throws IOException{
        synchronized(LOCK){token.check();if(!special(provider,image.url()))throw new IOException("Miniatura no compatible.");File root=new File(cache,"peach-source-thumbs");if(!root.isDirectory()&&!root.mkdirs())throw new IOException("No se pudo preparar la vista previa.");File file=new File(root,GalleryCache.key(image.url())+".image");if(file.exists())try{if(file.length()<1||file.length()>LIMIT)throw new IOException();Bitmap b=ImageFiles.decode(file,512).bitmap();token.check();file.setLastModified(System.currentTimeMillis());return b;}catch(IOException|RuntimeException e){file.delete();}if(offline)throw new IOException("Vista previa sin caché.");
            String host=SourceHttp.https(image.url()).getHost();Long until=waits.get(host);if(until!=null&&until>System.nanoTime())throw new IOException("La fuente pidió esperar para sus vistas previas.");
            File part=File.createTempFile("thumb-",".part",root);Bitmap bitmap=null;boolean done=false;try{fetch(image.url(),part,token);bitmap=ImageFiles.decode(part,512).bitmap();token.check();trim(root,LIMIT);if(!part.renameTo(file))throw new IOException("No se pudo guardar la vista previa.");done=true;waits.remove(host);return bitmap;}catch(SourceHttp.Failure e){if(e.status==429)waits.put(host,System.nanoTime()+Math.min(86400,Math.max(1,e.retrySeconds))*1000000000L);throw e;}finally{part.delete();if(!done&&bitmap!=null)bitmap.recycle();}
        }
    }
    static void trim(File root,long reserve){File[] list=root.listFiles((d,n)->n.matches("[a-f0-9]{64}\\.image"));if(list==null)return;Arrays.sort(list,Comparator.comparingLong(File::lastModified));long bytes=0;for(File f:list)bytes+=f.length();int count=list.length;for(File f:list)if(bytes>BUDGET-reserve||count>=128){bytes-=f.length();count--;f.delete();}}
    static SourceHttp.Download fetch(String url,File file,SourceHttp.Token token)throws IOException{return fetch(url,file,token,u->(HttpsURLConnection)new URL(u).openConnection(),InetAddress::getAllByName);}
    static SourceHttp.Download fetch(String url,File file,SourceHttp.Token token,SourceHttp.ConnectionFactory factory,MediaRedirects.Resolver dns)throws IOException{
        if(!special("rule34video",url)&&!special("rule34xxx",url))throw new IOException("Ruta de miniatura no admitida.");GofileUrls.publicHost(url,dns,token);HttpsURLConnection c=factory.open(url);token.connection=c;boolean done=false;try{c.setConnectTimeout(10000);c.setReadTimeout(10000);c.setInstanceFollowRedirects(false);c.setUseCaches(false);c.setRequestProperty("User-Agent","PeachLocal-Android/0.48.0");c.setRequestProperty("Accept","image/jpeg,image/png,image/webp,image/gif");c.setRequestProperty("Accept-Encoding","identity");token.check();int status=c.getResponseCode();token.check();if(status==429)throw new SourceHttp.Failure("La fuente pidió esperar para sus vistas previas.",429,SourceHttp.retry(c.getHeaderField("Retry-After")));if(status!=200)throw new IOException("Vista previa no disponible.");String mime=Objects.toString(c.getContentType(),"").split(";",2)[0].toLowerCase(Locale.ROOT);if(!Set.of("image/jpeg","image/png","image/webp","image/gif").contains(mime))throw new IOException("La vista previa no es una imagen.");try(InputStream in=c.getInputStream()){var result=SourceHttp.copy(in,file,c.getContentLengthLong(),token,LIMIT);done=true;return result;}}finally{c.disconnect();token.connection=null;if(!done)file.delete();}
    }
}
