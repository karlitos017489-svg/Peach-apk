package com.peach.local;

import android.app.Application;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.*;
import androidx.activity.result.*;
import androidx.activity.result.contract.ActivityResultContracts;
import java.util.*;
import java.util.concurrent.*;

/** Explicit selected-video preparation. No SAF destination, URL extras or auto-prefetch. */
public final class SourceVideoActivity extends PeachActivity {
    static VideoCache.Fetcher fetcher=(url,file,token,limit)->SourceHttp.download(url,file,token,limit);
    public static final class Draft extends AndroidViewModel {
        final ExecutorService worker=Executors.newSingleThreadExecutor();final MutableLiveData<Integer> updates=new MutableLiveData<>(0);
        final VideoCache cache;volatile SourceHttp.Token token=new SourceHttp.Token();volatile boolean busy;
        SourceVideos.Selection selection;VideoCache.Lease ready;int index;boolean loaded,autoplay,playerOpen;
        boolean canRefresh,querying,reviewOpen;VideoVersionReview.Review versionReview;
        String publication="",restoredKey="",status="Leyendo videos importados…";
        public Draft(Application app){super(app);cache=new VideoCache(app.getCacheDir());}
        void load(String id){if(loaded)return;loaded=true;publication=id;work(()->{
            LibraryDatabase db=LibraryDatabase.get(getApplication());canRefresh=VideoVersionReview.canQuery(db.library().publication(id));selection=SourceVideos.load(db,id);index=VideoVariants.best(selection.videos());
            for(int i=0;i<selection.videos().size();i++)if(VideoCache.keyFor(selection.videos().get(i).url()).equals(restoredKey))index=i;
            status=selection.videos().isEmpty()?"No hay videos compatibles en este contenido importado.":"Elige Ver en línea para empezar mientras llegan los datos, o Preparar y reproducir para comprobar una copia completa.";
        });}
        interface Job {void run()throws Exception;}
        void work(Job job){if(busy)return;busy=true;token=new SourceHttp.Token();updates.setValue(1);worker.execute(()->{
            try{job.run();}catch(Exception e){autoplay=false;status=querying?(token.cancelled?"Consulta cancelada; contenido actual conservado.":e instanceof java.io.IOException?e.getMessage():"No se pudieron actualizar las versiones."):VideoCache.message(e,token);}finally{querying=false;busy=false;updates.postValue(1);}
        });}
        synchronized void clearReady(){if(ready!=null){ready.close();ready=null;}}
        void select(int selected){if(busy||selection==null||selected<0||selected>=selection.videos().size())return;autoplay=false;clearReady();index=selected;status="Video seleccionado. Elige Ver en línea o Preparar y reproducir.";updates.setValue(1);}
        void prepare(boolean offline){if(busy||selection==null||selection.videos().isEmpty())return;
            autoplay=true;if(ready!=null){updates.setValue(1);return;}
            var selected=selection.videos().get(index);status=offline?"Comprobando copia sin conexión…":"Preparando video completo… Mantén esta pantalla abierta; puedes cancelar.";
            work(()->{var result=cache.acquire(selected,offline,token,fetcher);boolean keep=false;
                try{synchronized(this){token.check();ready=result;keep=true;}status=(result.cached?"Copia privada comprobada: ":"Video preparado: ")+result.stamp.bytes()+" bytes.";}
                finally{if(!keep)result.close();}
            });
        }
        void cancel(){autoplay=false;token.cancel();}
        void discard(){if(busy||selection==null||selection.videos().isEmpty())return;autoplay=false;clearReady();String key=VideoCache.keyFor(selection.videos().get(index).url());work(()->{cache.discard(key);status="Copia temporal retirada. Tus archivos guardados y publicaciones se conservan.";});}
        void findVersions(boolean offline){if(busy||playerOpen||!canRefresh||offline)return;autoplay=false;clearReady();querying=true;status="Consultando versiones de esta publicación… No se descargan videos.";work(()->{var found=VideoVersionReview.query(LibraryDatabase.get(getApplication()),publication,SourcesActivity.transport,token);token.check();versionReview=found;status="Versiones consultadas. Revisa antes de usarlas.";});}
        void acceptVersions(){if(busy||versionReview==null)return;var found=versionReview;versionReview=null;querying=true;work(()->{VideoVersionReview.apply(LibraryDatabase.get(getApplication()),found,token);selection=SourceVideos.load(LibraryDatabase.get(getApplication()),publication);index=VideoVariants.best(selection.videos());status="Versiones actualizadas. Se preseleccionó la mejor calidad declarada del primer video disponible.";});}
        void rejectVersions(){versionReview=null;status="Se conservaron las versiones actuales.";updates.setValue(1);}
        @Override protected synchronized void onCleared(){cancel();worker.shutdownNow();clearReady();}
    }
    Draft draft;ListView list;TextView status,title;Button prepare,cancel,discard,online,versions;ProgressBar progress;CheckBox offline;boolean resumed;androidx.appcompat.app.AlertDialog reviewDialog;
    final ActivityResultLauncher<android.content.Intent> player=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),result->{draft.playerOpen=false;draft.autoplay=false;draft.clearReady();render();});
    @Override protected void onCreate(Bundle state){super.onCreate(state);draft=new ViewModelProvider(this).get(Draft.class);
        if(state!=null&&!draft.loaded){draft.restoredKey=state.getString("selectedKey","");draft.playerOpen=state.getBoolean("playerOpen");}
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);int pad=(int)(12*getResources().getDisplayMetrics().density);root.setPadding(pad,pad,pad,pad);setContentView(root);
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root,(v,insets)->{var bars=insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars()|androidx.core.view.WindowInsetsCompat.Type.displayCutout());v.setPadding(pad+bars.left,pad+bars.top,pad+bars.right,pad+bars.bottom);return insets;});
        Button back=new Button(this);back.setText("Volver");back.setOnClickListener(v->finish());root.addView(back);
        title=new TextView(this);title.setText("Videos de la publicación");title.setTextSize(22);root.addView(title);
        TextView note=new TextView(this);note.setText("Ver en línea usa internet y memoria temporal, sin guardar una copia completa. La fuente decide si permite adelantar. Preparar y reproducir comprueba primero una copia privada de hasta 2 GiB; Guardar adjunto conserva el original en una carpeta.");root.addView(note);
        offline=new CheckBox(this);offline.setId(R.id.source_video_offline);offline.setText("Sin conexión");offline.setChecked(getSharedPreferences("source-video",MODE_PRIVATE).getBoolean("offline",false));offline.setOnCheckedChangeListener((b,value)->{getSharedPreferences("source-video",MODE_PRIVATE).edit().putBoolean("offline",value).apply();if(online!=null)render();});root.addView(offline);
        status=new TextView(this);status.setId(R.id.source_video_status);status.setTextIsSelectable(true);root.addView(status);
        progress=new ProgressBar(this);root.addView(progress);
        LinearLayout actions=new LinearLayout(this);root.addView(actions);
        prepare=button(actions,"Preparar y reproducir",R.id.source_video_prepare,v->draft.prepare(offline.isChecked()));
        cancel=button(actions,"Cancelar preparación",R.id.source_video_cancel,v->{draft.cancel();render();});
        discard=button(actions,"Retirar copia temporal",R.id.source_video_discard,v->draft.discard());
        LinearLayout network=new LinearLayout(this);root.addView(network);online=button(network,"Ver en línea",R.id.source_video_online,v->stream());
        versions=button(network,"Consultar versiones",R.id.source_video_versions,v->draft.findVersions(offline.isChecked()));
        Button cloud=new Button(this);cloud.setId(R.id.source_video_cloud);cloud.setText("Guardar directo en nube o carpeta");cloud.setOnClickListener(v->{if(draft.busy||draft.playerOpen||offline.isChecked()||draft.selection==null||draft.selection.videos().isEmpty())return;var selected=draft.selection.videos().get(draft.index);startActivity(DirectSaveActivity.intent(this,selected.url(),selected.name(),selected.expectedHash()));});root.addView(cloud);
        list=new ListView(this);list.setChoiceMode(ListView.CHOICE_MODE_SINGLE);root.addView(list,new LinearLayout.LayoutParams(-1,0,1));list.setOnItemClickListener((p,v,i,id)->draft.select(i));
        draft.updates.observe(this,value->{render();offerPlayer();offerVersions();});draft.load(getIntent().getStringExtra("publicationId"));render();
    }
    Button button(LinearLayout row,String text,int id,View.OnClickListener listener){Button b=new Button(this);b.setId(id);b.setText(text);b.setOnClickListener(listener);row.addView(b,new LinearLayout.LayoutParams(0,-2,1));return b;}
    void render(){if(isDestroyed())return;boolean available=draft.selection!=null&&!draft.selection.videos().isEmpty();
        findViewById(R.id.source_video_cloud).setEnabled(available&&!draft.busy&&!draft.playerOpen&&!offline.isChecked());
        boolean preview=available&&draft.selection.videos().get(draft.index).variant().role().equals("preview");status.setText(draft.status+(preview?"\nLa opción seleccionada es una vista previa. Consultar versiones busca otros enlaces publicados; no garantiza un original disponible.":"")+(draft.selection!=null&&draft.selection.partial()?"\nCuerpo parcial; puede faltar contenido.":""));progress.setVisibility(draft.busy?View.VISIBLE:View.GONE);
        prepare.setEnabled(available&&!draft.busy&&!draft.playerOpen);prepare.setText(draft.ready==null?(preview?"Preparar vista previa":"Preparar y reproducir"):"Reproducir copia preparada");online.setText(preview?"Ver vista previa en línea":"Ver en línea");online.setEnabled(available&&!draft.busy&&!draft.playerOpen&&!offline.isChecked());versions.setEnabled(draft.canRefresh&&!draft.busy&&!draft.playerOpen&&!offline.isChecked()&&draft.versionReview==null);cancel.setText(draft.querying?"Cancelar consulta":"Cancelar preparación");cancel.setEnabled(draft.busy);discard.setEnabled(available&&!draft.busy&&!draft.playerOpen);offline.setEnabled(!draft.busy);list.setEnabled(!draft.busy);
        if(draft.selection!=null){title.setText(draft.selection.title());list.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_single_choice,draft.selection.videos().stream().map(VideoVariants::label).toList()));if(available)list.setItemChecked(draft.index,true);}
    }
    void stream(){if(draft.busy||draft.playerOpen||offline.isChecked()||draft.selection==null||draft.selection.videos().isEmpty())return;draft.autoplay=false;draft.clearReady();draft.playerOpen=true;
        try{var selected=draft.selection.videos().get(draft.index);player.launch(SourceVideoStream.intent(this,draft.publication,VideoCache.keyFor(selected.url())));}catch(Exception e){draft.playerOpen=false;draft.status="No se pudo abrir el video en línea.";}render();}
    void offerPlayer(){if(!resumed||draft.busy||!draft.autoplay||draft.playerOpen||draft.ready==null||isFinishing()||isDestroyed())return;
        draft.autoplay=false;draft.playerOpen=true;try{player.launch(SourceVideoPlayback.intent(this,draft.publication,draft.ready.key));}catch(Exception e){draft.playerOpen=false;draft.status="No se pudo abrir el reproductor. Puedes reintentar la copia preparada.";}render();
    }
    void offerVersions(){if(!resumed||draft.busy||draft.reviewOpen||draft.versionReview==null||isFinishing()||isDestroyed())return;draft.reviewOpen=true;var found=draft.versionReview;String lines=found.selection().videos().stream().map(VideoVariants::label).collect(java.util.stream.Collectors.joining("\n\n"));if(lines.isEmpty())lines="No se encontraron versiones de video compatibles. Se conserva el contenido actual.";
        TextView text=new TextView(this);text.setText(lines+"\n\nUsar versiones actualizará el contenido consultado de esta publicación. Tus archivos guardados y la ficha personal se conservan.");text.setPadding(20,12,20,12);ScrollView scroll=new ScrollView(this);scroll.addView(text);reviewDialog=new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Versiones consultadas").setView(scroll).setPositiveButton("Usar versiones",(d,w)->draft.acceptVersions()).setNegativeButton("Conservar actuales",(d,w)->draft.rejectVersions()).create();reviewDialog.setOnCancelListener(d->draft.rejectVersions());reviewDialog.setOnDismissListener(d->{draft.reviewOpen=false;reviewDialog=null;});reviewDialog.show();reviewDialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setEnabled(!found.selection().videos().isEmpty());
    }
    @Override protected void onResume(){super.onResume();resumed=true;offerPlayer();offerVersions();}
    @Override protected void onPause(){resumed=false;super.onPause();}
    @Override protected void onStop(){if(!isChangingConfigurations()&&draft.busy)draft.cancel();super.onStop();}
    @Override protected void onDestroy(){if(reviewDialog!=null)reviewDialog.dismiss();super.onDestroy();}
    @Override protected void onSaveInstanceState(Bundle state){if(draft.selection!=null&&!draft.selection.videos().isEmpty())state.putString("selectedKey",VideoCache.keyFor(draft.selection.videos().get(draft.index).url()));state.putBoolean("playerOpen",draft.playerOpen);super.onSaveInstanceState(state);}
}
