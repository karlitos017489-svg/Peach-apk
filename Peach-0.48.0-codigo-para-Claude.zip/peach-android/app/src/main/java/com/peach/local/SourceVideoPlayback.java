package com.peach.local;

import android.app.Application;
import android.content.*;
import android.net.Uri;
import androidx.lifecycle.*;
import java.io.IOException;
import java.util.concurrent.*;

/** Retains a private-file pin across player rotation; restoration never downloads. */
public final class SourceVideoPlayback extends AndroidViewModel {
    static final String PUBLICATION="sourceVideoPublication",KEY="sourceVideoKey";
    final MutableLiveData<Integer> updates=new MutableLiveData<>(0);
    final ExecutorService worker=Executors.newSingleThreadExecutor();
    final SourceHttp.Token token=new SourceHttp.Token();
    volatile boolean requested,busy;VideoCache.Lease lease;MediaEntry media;String error="";
    public SourceVideoPlayback(Application app){super(app);}
    static boolean requested(Intent intent){return intent.hasExtra(PUBLICATION)||intent.hasExtra(KEY);}
    static Intent intent(Context context,String publication,String key){
        if(!SourceVideos.id(publication)||!VideoCache.key(key))throw new IllegalArgumentException("Video importado no válido.");
        return new Intent(context,PlayerActivity.class).putExtra(PUBLICATION,publication).putExtra(KEY,key);
    }
    void load(String publication,String key){
        if(requested)return;requested=true;busy=true;
        worker.execute(()->{VideoCache.Lease acquired=null;boolean keep=false;
            try{if(!SourceVideos.id(publication)||!VideoCache.key(key))throw new VideoCache.Problem("Elige un video desde una publicación importada.");
                var selection=SourceVideos.load(LibraryDatabase.get(getApplication()),publication);
                var video=selection.videos().stream().filter(v->VideoCache.keyFor(v.url()).equals(key)).findFirst().orElseThrow(()->new VideoCache.Problem("Este video ya no figura en el contenido importado. Vuelve a su publicación."));
                acquired=new VideoCache(getApplication().getCacheDir()).acquire(video,true,token,(u,f,t,limit)->{throw new IOException("El reproductor no descarga archivos.");});
                MediaEntry loaded=new MediaEntry();loaded.id="private-video:"+key;loaded.uri=Uri.fromFile(acquired.file).toString();
                loaded.name=LocalMedia.name(SourceFiles.name(video.name(),video.url()),new LocalMedia.Format(acquired.stamp.extension(),"video"));loaded.title=loaded.name;loaded.mediaType=MediaRules.VIDEO;loaded.bytes=acquired.stamp.bytes();
                synchronized(this){token.check();lease=acquired;media=loaded;keep=true;}
            }catch(Exception e){error=VideoCache.message(e,token);}
            finally{if(!keep&&acquired!=null)acquired.close();busy=false;updates.postValue(1);}
        });
    }
    @Override protected synchronized void onCleared(){token.cancel();worker.shutdownNow();if(lease!=null){lease.close();lease=null;}}
}
