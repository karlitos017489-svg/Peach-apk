package com.peach.local;

import android.app.Application;
import android.content.*;
import androidx.lifecycle.*;
import androidx.media3.common.*;
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy;
import java.util.concurrent.*;

/** Re-resolves imported identity. Only explicit online playback may open a progressive source. */
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public final class SourceVideoStream extends AndroidViewModel {
    static final String PUBLICATION="streamPublication",KEY="streamKey";
    interface Sessions {VideoStream.Session create(SourceVideos.Video video,Application app);}
    static Sessions sessions=(video,app)->new VideoStream.Session(video.url(),()->!app.getSharedPreferences("source-video",0).getBoolean("offline",false));
    final MutableLiveData<Integer> updates=new MutableLiveData<>(0);final ExecutorService worker=Executors.newSingleThreadExecutor();
    volatile boolean requested,busy,closed;VideoStream.Session session;MediaEntry media;String error="";
    public SourceVideoStream(Application app){super(app);}
    static boolean requested(Intent i){return i.hasExtra(PUBLICATION)||i.hasExtra(KEY);}
    static Intent intent(Context context,String publication,String key){if(!SourceVideos.id(publication)||!VideoCache.key(key))throw new IllegalArgumentException();return new Intent(context,PlayerActivity.class).putExtra(PUBLICATION,publication).putExtra(KEY,key);}
    void load(String publication,String key){if(requested)return;requested=true;busy=true;worker.execute(()->{
        try{if(!SourceVideos.id(publication)||!VideoCache.key(key))throw new java.io.IOException();
            if(getApplication().getSharedPreferences("source-video",0).getBoolean("offline",false))throw new VideoStream.Problem(VideoStream.Reason.OFFLINE);
            var video=SourceVideos.load(LibraryDatabase.get(getApplication()),publication).videos().stream().filter(v->VideoCache.keyFor(v.url()).equals(key)).findFirst().orElseThrow(java.io.IOException::new);
            VideoStream.Session selected=sessions.create(video,getApplication());MediaEntry entry=new MediaEntry();entry.id="stream-video:"+key;entry.uri=StreamDataSource.uri(key).toString();entry.name=SourceFiles.name(video.name(),video.url());entry.title=entry.name+" · En línea";entry.mediaType=MediaRules.VIDEO;
            synchronized(this){if(closed){selected.close();return;}session=selected;media=entry;}
        }catch(Exception e){error=e instanceof VideoStream.Problem p?p.getMessage():"Este video ya no está disponible en el contenido importado. Vuelve a su publicación.";}
        finally{busy=false;updates.postValue(1);}
    });}
    synchronized void pause(){if(session!=null)session.pause();}
    @Override protected synchronized void onCleared(){closed=true;if(session!=null)session.close();worker.shutdownNow();}
    static String message(PlaybackException error){Throwable cause=error;for(int i=0;i<12&&cause!=null;i++,cause=cause.getCause())if(cause instanceof VideoStream.Problem p)return p.getMessage()+"\nCódigo: "+error.getErrorCodeName()+" ("+error.errorCode+").";
        switch(error.errorCode){case PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES,PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED,PlaybackException.ERROR_CODE_DECODING_FAILED->{return PlaybackMessages.error(error);}default->{}}
        return "No se pudo reproducir en línea. Comprueba internet y el formato del video; puedes usar Preparar y reproducir.\nCódigo: "+error.getErrorCodeName()+" ("+error.errorCode+").";}
    static final class NoRetry extends DefaultLoadErrorHandlingPolicy {
        @Override public long getRetryDelayMsFor(LoadErrorInfo error){return C.TIME_UNSET;}
    }
}
