package com.peach.local;

import java.io.IOException;
import java.util.*;
import org.json.*;

/** Imported metadata only. A video is never resolved from an Intent URL. */
final class SourceVideos {
    record Video(String name,String url,String provider,VideoVariants.Info variant,String expectedHash) {Video(String name,String url,String provider){this(name,url,provider,VideoVariants.Info.unknown(),"");}Video(String name,String url,String provider,VideoVariants.Info variant){this(name,url,provider,variant,"");}}
    record Selection(String publicationId,String title,List<Video> videos,boolean partial,int omitted) {
        Selection {videos=List.copyOf(videos);}
    }
    private SourceVideos() {}
    static boolean admitted(String provider,String url,boolean declared) {
        if(provider==null)return false;
        return SourceGallery.admitted(provider,url,declared) || "rule34video".equals(provider) && SourceHttp.canSave(url,declared) && MediaRedirects.videoSource(url);
    }
    static boolean id(String id){return id!=null&&!id.isBlank()&&id.length()<=1000;}
    static Selection load(LibraryDatabase db,String id)throws IOException {
        if(!id(id))throw new IOException("Publicación no válida.");
        Selection[] selected={null};IOException[] error={null};db.runInTransaction(()->{
            try{selected[0]=select(db.library().publication(id),db.library().publicationContent(id));}catch(IOException e){error[0]=e;}
        });if(error[0]!=null)throw error[0];return selected[0];
    }
    static Selection select(Publication p,PublicationContent c)throws IOException {
        if(p==null||c==null||p.id==null||!p.id.equals(c.publicationId)||p.provider==null||!SourceProviders.KEYS.contains(p.provider))throw new IOException("Esta publicación no tiene videos compatibles importados.");
        if(c.attachments==null||c.attachments.length()>2*1024*1024)throw new IOException("Lista de videos demasiado grande.");
        try{JSONArray array=new JSONArray(c.attachments);if(array.length()>1000)throw new IOException("Demasiados adjuntos.");
            List<Video> videos=new ArrayList<>();Set<String> seen=new HashSet<>();int omitted=0;
            for(int i=0;i<array.length();i++){
                JSONObject a=array.getJSONObject(i);if(!"video".equals(a.getString("kind"))){omitted++;continue;}
                Object n=a.get("name"),u=a.get("url"),d=a.get("downloadable");
                if(!(n instanceof String name)||name.isBlank()||name.length()>300||!(u instanceof String url)||!(d instanceof Boolean declared))throw new IOException("Metadatos de video no válidos.");
                if(!admitted(p.provider,url,declared)){omitted++;continue;}
                if(seen.add(url))videos.add(new Video(name,url,p.provider,VideoVariants.info(p,c,a,name,url),PixeldrainUrls.expected(a)));
            }return new Selection(p.id,p.title,videos,c.partial,omitted);
        }catch(JSONException e){throw new IOException("Lista de videos no válida.");}
    }
}
