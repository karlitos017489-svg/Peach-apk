package com.peach.local;

import android.net.Uri;
import androidx.media3.common.C;
import androidx.media3.datasource.*;
import java.io.IOException;

/** Media3 receives an opaque application URI; every network read uses the selected source policy. */
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
final class StreamDataSource extends BaseDataSource {
    final VideoStream.Session session;VideoStream.Transfer input;Uri uri;long remaining;boolean started;
    StreamDataSource(VideoStream.Session session){super(true);this.session=session;}
    static boolean compatibleHeaders(java.util.Map<String,String> headers){
        if(headers.isEmpty())return true;
        if(headers.size()!=1)return false;
        var entry=headers.entrySet().iterator().next();
        // ProgressiveMediaPeriod adds this hint even for MP4. It is intentionally
        // consumed here, never forwarded to HTTP: this transport does not enable ICY.
        return "Icy-MetaData".equalsIgnoreCase(entry.getKey())&&"1".equals(entry.getValue());
    }
    static Uri uri(String key){if(!VideoCache.key(key))throw new IllegalArgumentException();return new Uri.Builder().scheme("peach-stream").authority("video").appendPath(key).build();}
    @Override public long open(DataSpec spec)throws IOException {
        if(input!=null||!uri(session.key).equals(spec.uri)||spec.httpMethod!=DataSpec.HTTP_METHOD_GET||spec.httpBody!=null||!compatibleHeaders(spec.httpRequestHeaders)||spec.uriPositionOffset!=0||spec.position<0)throw new VideoStream.Problem(VideoStream.Reason.REQUEST);
        transferInitializing(spec);try{input=session.open(spec.position);}catch(VideoStream.Problem p){if(p.reason==VideoStream.Reason.RANGE)throw new DataSourceException(p,androidx.media3.common.PlaybackException.ERROR_CODE_IO_READ_POSITION_OUT_OF_RANGE);throw p;}uri=spec.uri;remaining=input.length;
        if(spec.length!=C.LENGTH_UNSET)remaining=remaining<0?spec.length:Math.min(remaining,spec.length);
        started=true;transferStarted(spec);return spec.length==C.LENGTH_UNSET?remaining:spec.length;
    }
    @Override public int read(byte[] bytes,int offset,int length)throws IOException {
        if(length==0)return 0;if(input==null)throw new IOException("Lectura cerrada.");if(remaining==0)return C.RESULT_END_OF_INPUT;
        int n=input.read(bytes,offset,remaining<0?length:(int)Math.min(length,remaining));if(n<0)return C.RESULT_END_OF_INPUT;if(remaining>=0)remaining-=n;bytesTransferred(n);return n;
    }
    @Override public Uri getUri(){return uri;}
    @Override public void close(){try{if(input!=null)input.close();}finally{input=null;uri=null;if(started){started=false;transferEnded();}}}
}
