package com.peach.local;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.time.format.*;
import java.util.*;
import org.json.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.*;

/** Public visitor HTML only. A visible card is an excerpt, not proof of a complete/free body. */
public final class SubscribeStarConnector {
    private final SourceHttp.Transport http;
    public SubscribeStarConnector(SourceHttp.Transport http){this.http=http;}
    public SourcePage newest(String ref,String etag,String modified,SourceHttp.Token token)throws IOException {
        var response=http.get(SubscribeStarUrls.url(ref),etag,modified,token);token.check();if(response.status()==304)return new SourcePage(new JSONArray(),etag,modified,0,true);
        if(response.status()!=200)throw new IOException("Estado HTTP SubscribeStar no válido.");return parse(ref,SourceHttp.utf8(response.bytes()),response.etag(),response.modified());
    }
    public static SourcePage parse(String ref,String html,String etag,String modified)throws IOException {
        if(html.getBytes(StandardCharsets.UTF_8).length>SourceHttp.JSON_LIMIT)throw new IOException("Página pública mayor de 2 MiB.");
        String creator=SubscribeStarUrls.creator(ref);Document page=Jsoup.parse(html,SubscribeStarUrls.url(creator));
        Element identity=page.selectFirst("link[rel=canonical]");if(identity==null)identity=page.selectFirst("meta[property=og:url]");
        try{if(identity==null)throw new IllegalArgumentException();SubscribeStarUrls.creatorPage(identity.hasAttr("href")?identity.absUrl("href"):identity.attr("content"),creator);}catch(IllegalArgumentException e){throw new IOException("SubscribeStar no devolvió la página pública del creador consultado; caché conservada.",e);}
        page.select("script,style,noscript,template,[hidden],[aria-hidden=true],.is-hidden,.post-comments,.comments,.post-edit_form").remove();
        JSONArray rows=new JSONArray();Set<String> seen=new HashSet<>();int inspected=0,skipped=0;
        for(Element post:page.select("div.post[data-id]")) {
            if(++inspected>1000)throw new IOException("Demasiados nodos de publicaciones.");String id=post.attr("data-id");if(!id.matches("[0-9]{1,30}")){skipped++;continue;}
            Element author=post.selectFirst("a.post-user[href]"),dateNode=post.selectFirst(".post-date a[href]");
            try{if(author==null || dateNode==null)throw new IllegalArgumentException();SubscribeStarUrls.creatorPage(author.absUrl("href"),creator);SubscribeStarUrls.postUrl(creator,dateNode.absUrl("href"),id);}catch(IllegalArgumentException e){skipped++;continue;}
            Element content=post.selectFirst(".post-content");if(content==null || content.text().isBlank()){skipped++;continue;}
            if(!seen.add(id))continue;
            Element heading=post.selectFirst(".post-title h2");String title=heading==null?"":heading.text();if(title.isBlank())title="SubscribeStar #"+id;
            String date="",precision="unknown",raw=dateNode.text().trim();
            try{date=LocalDateTime.parse(raw,new DateTimeFormatterBuilder().parseCaseInsensitive().appendPattern("MMM dd, uuuu hh:mm a").toFormatter(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT)).toString();precision="approximate";}catch(DateTimeException ignored){/* Displayed clock has no timezone; never invent UTC. */}
            try{rows.put(new JSONObject().put("id",id).put("title",FanboxConnector.clipped(title,300)).put("date",date).put("precision",precision).put("url",SubscribeStarUrls.postUrl(creator,dateNode.absUrl("href"),id)).put("text","Tarjeta pública; puede ser un adelanto. El cuerpo completo no se obtuvo.\n\n"+FanboxConnector.clipped(content.text(),4000)).put("attachments",new JSONArray()).put("partial",true).put("type","public-card"));}catch(JSONException e){throw new IOException("Tarjeta SubscribeStar no válida.",e);}
            if(rows.length()>100)throw new IOException("Más de 100 tarjetas públicas en la página.");
        }
        if(rows.length()==0)throw new IOException("No hay tarjetas públicas reconocibles. Puede requerir sesión o verificación, no tener publicaciones visibles o haber cambiado la página; caché conservada.");
        return new SourcePage(rows,SourceHttp.header(etag),SourceHttp.header(modified),skipped,false);
    }
}
