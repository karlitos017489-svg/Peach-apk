package com.peach.local;

import java.net.URI;
import java.util.*;

/** Same creator and same host on every request; .com and .adult are distinct identities. */
public final class SubscribeStarUrls {
    private static final Set<String> HOSTS=Set.of("subscribestar.com","subscribestar.adult");
    private static final Set<String> RESERVED=Set.of("posts","search","login","signup","stars","logout","settings","api","subscriptions","messages","subscribe","about","terms","privacy");
    private SubscribeStarUrls() {}
    static String host(String raw){String h=raw.toLowerCase(Locale.ROOT);if(h.startsWith("www."))h=h.substring(4);if(!HOSTS.contains(h))throw new IllegalArgumentException("Usa una página de creador SubscribeStar.");return h;}
    static boolean site(String raw){try{host(raw);return true;}catch(IllegalArgumentException e){return false;}}
    public static String creator(String input){
        if(input==null)throw new IllegalArgumentException("Falta el creador SubscribeStar.");String value=input.trim(),hostname="subscribestar.com",slug;
        if(value.startsWith("https://")){URI u=SourceHttp.https(value);hostname=host(u.getHost());if(u.getRawQuery()!=null)throw new IllegalArgumentException("Usa la página del creador sin parámetros.");String path=u.getRawPath();if(!path.matches("/[A-Za-z0-9_-]{1,80}/?"))throw new IllegalArgumentException("Usa la página del creador, no una publicación.");slug=path.substring(1).replaceFirst("/$","");}
        else{String[] parts=value.split("/",-1);if(parts.length==1)slug=parts[0];else if(parts.length==2){hostname=host(parts[0]);slug=parts[1];}else throw new IllegalArgumentException("Identificador SubscribeStar no válido.");}
        slug=slug.toLowerCase(Locale.ROOT);if(!slug.matches("[a-z0-9_-]{1,80}") || RESERVED.contains(slug))throw new IllegalArgumentException("Identificador de creador SubscribeStar no válido.");return hostname+"/"+slug;
    }
    public static String url(String ref){return "https://"+creator(ref);}
    static void creatorPage(String url,String expected){if(!creator(url).equals(creator(expected)))throw new IllegalArgumentException("La redirección no corresponde al mismo creador y sitio SubscribeStar.");}
    public static String postUrl(String ref,String raw,String id){try{URI u=SourceHttp.https(raw);String hostname=creator(ref).split("/",2)[0];if(!host(u.getHost()).equals(hostname) || u.getRawQuery()!=null || !id.matches("[0-9]{1,30}") || !u.getRawPath().matches("/posts/"+id+"/?"))throw new IllegalArgumentException();return "https://"+hostname+"/posts/"+id;}catch(Exception e){throw new IllegalArgumentException("Referencia de publicación SubscribeStar no válida.");}}
}
