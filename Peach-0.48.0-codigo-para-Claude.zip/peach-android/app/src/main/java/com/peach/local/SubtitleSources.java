package com.peach.local;

import android.content.Context;
import android.net.Uri;
import androidx.media3.common.C;
import androidx.media3.datasource.*;
import java.io.*;
import java.util.concurrent.ConcurrentHashMap;

/** Binds opaque subtitle identities to explicitly selected content documents.
 * DefaultDataSource handles local video; its remote fallback is replaced by this
 * in-memory Unicode adapter, which cannot open HTTP/file URIs. */
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
final class SubtitleSources implements DataSource.Factory {
    private record Track(Uri uri,String encoding) {}
    private final Context context;private final ConcurrentHashMap<String,Track> tracks=new ConcurrentHashMap<>();
    SubtitleSources(Context context){this.context=context.getApplicationContext();}
    Uri register(Uri uri,String encoding)throws IOException {
        if(!"content".equals(uri.getScheme()) || !java.util.Set.of("auto","windows-1252").contains(encoding))throw new IOException("Subtítulo local no admitido.");
        String key="peach-subtitle://local/"+java.util.UUID.randomUUID();tracks.put(key,new Track(uri,encoding));return Uri.parse(key);
    }
    private static boolean validHeaders(java.util.Map<String,String> headers){return headers.isEmpty() || headers.size()==1 && headers.entrySet().stream().allMatch(e->e.getKey().equalsIgnoreCase("Icy-MetaData") && e.getValue().equals("1"));}
    @Override public DataSource createDataSource(){return new DefaultDataSource(context,new UnicodeSource());}
    private final class UnicodeSource extends BaseDataSource {
        private byte[] bytes;private int at,end;private Uri uri;private volatile InputStream loading;private volatile int generation;
        UnicodeSource(){super(false);}
        @Override public long open(DataSpec spec)throws IOException {
            int token=++generation;Track track=tracks.get(spec.uri.toString());
            if(track==null || spec.httpMethod!=DataSpec.HTTP_METHOD_GET || spec.httpBody!=null || !validHeaders(spec.httpRequestHeaders) || spec.position<0)throw new IOException("Origen de subtítulo no admitido.");
            transferInitializing(spec);
            try(InputStream input=context.getContentResolver().openInputStream(track.uri());ByteArrayOutputStream output=new ByteArrayOutputStream()) {
                if(input==null)throw new IOException("Subtítulo inaccesible.");loading=input;byte[] buffer=new byte[16384];int n;
                while((n=input.read(buffer))!=-1){check(token);if(n==0 || n>SubtitleText.MAX_BYTES-output.size())throw new IOException("Subtítulo fuera del límite de 8 MiB.");output.write(buffer,0,n);}
                check(token);byte[] decoded=SubtitleText.unicode(output.toByteArray(),track.encoding());check(token);
                if(spec.position>decoded.length)throw new DataSourceException(2008);
                bytes=decoded;at=(int)spec.position;long available=bytes.length-at;end=at+(int)(spec.length==C.LENGTH_UNSET?available:Math.min(available,spec.length));uri=spec.uri;transferStarted(spec);return end-at;
            }finally{loading=null;}
        }
        private void check(int token)throws InterruptedIOException{if(token!=generation || Thread.currentThread().isInterrupted())throw new InterruptedIOException("Lectura de subtítulo cancelada.");}
        @Override public int read(byte[] target,int offset,int length)throws IOException{if(length==0)return 0;if(bytes==null)throw new IOException("Subtítulo cerrado.");if(at==end)return C.RESULT_END_OF_INPUT;int n=Math.min(length,end-at);System.arraycopy(bytes,at,target,offset,n);at+=n;bytesTransferred(n);return n;}
        @Override public Uri getUri(){return uri;}
        @Override public void close(){generation++;InputStream input=loading;if(input!=null)try{input.close();}catch(IOException ignored){}bytes=null;if(uri!=null){uri=null;transferEnded();}}
    }
}
