package com.peach.local;

import java.io.*;
import java.nio.*;
import java.nio.charset.*;

/** No encoding guessing: Unicode BOM/strict UTF-8, or an explicit Windows-1252 choice. */
final class SubtitleText {
    static final int MAX_BYTES=8*1024*1024;
    private SubtitleText() {}
    static byte[] unicode(byte[] raw,String encoding)throws IOException {
        if(raw.length>MAX_BYTES)throw new IOException("Subtítulo mayor de 8 MiB.");
        Charset charset;int offset=0;
        if("windows-1252".equals(encoding))charset=Charset.forName("windows-1252");
        else if("auto".equals(encoding)) {
            charset=StandardCharsets.UTF_8;
            if(raw.length>=3 && (raw[0]&255)==239 && (raw[1]&255)==187 && (raw[2]&255)==191)offset=3;
            else if(raw.length>=2 && (raw[0]&255)==255 && (raw[1]&255)==254){offset=2;charset=StandardCharsets.UTF_16LE;}
            else if(raw.length>=2 && (raw[0]&255)==254 && (raw[1]&255)==255){offset=2;charset=StandardCharsets.UTF_16BE;}
        }else throw new IOException("Codificación de subtítulo no admitida.");
        try {
            String text=charset.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(raw,offset,raw.length-offset)).toString();
            if(text.indexOf('\0')>=0)throw new IOException("El subtítulo contiene datos binarios o UTF-16 sin BOM.");
            byte[] utf8=text.getBytes(StandardCharsets.UTF_8);if(utf8.length>3*MAX_BYTES)throw new IOException("Subtítulo fuera del límite de texto.");return utf8;
        }catch(CharacterCodingException e){throw new IOException("Subtítulo sin Unicode válido. Vuelve a añadirlo y elige Windows-1252 si corresponde.",e);}
    }
}
