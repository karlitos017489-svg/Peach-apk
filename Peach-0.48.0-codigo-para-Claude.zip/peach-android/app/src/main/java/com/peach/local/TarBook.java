package com.peach.local;

import java.io.*;
import java.util.*;
import org.apache.commons.compress.archivers.tar.*;

/** USTAR, bounded PAX/GNU long names; regular files only. No filesystem extraction. */
public final class TarBook implements ArchiveBook {
    static final int MAX_METADATA=64*1024,MAX_METADATA_TOTAL=4*1024*1024;
    private final TarFile tar;private final List<Item> items;
    private final Map<String,TarArchiveEntry> entries=new HashMap<>();
    public TarBook(File source)throws IOException {
        preflight(source);TarFile opened=new TarFile(source);tar=opened;
        try {
            List<Item> found=new ArrayList<>();Set<String> seen=new HashSet<>();
            for(TarArchiveEntry e:tar.getEntries()) {
                String name=e.getName();if(name.length()>4096)throw new IOException("Nombre TAR mayor de 4.096 caracteres.");while(name.startsWith("./"))name=name.substring(2);if(e.isDirectory() && (name.isEmpty() || name.equals(".")))continue;ZipBook.safeName(name);
                if(!seen.add(name) || seen.size()>ZipBook.MAX_ENTRIES)throw new IOException("TAR con nombres duplicados o demasiadas entradas.");
                if(e.isSparse())throw new IOException("TAR disperso (sparse) no admitido en esta entrega.");
                if(e.getSize()<0 || e.getSize()>ReaderSession.MAX_SOURCE_BYTES || e.getDataOffset()<0 || e.getDataOffset()>source.length()-e.getSize())throw new IOException("Índice TAR truncado o fuera de límite.");
                if(!e.isDirectory()) {
                    boolean regular=(e.getLinkFlag()==0 || e.getLinkFlag()=='0') && !e.isSparse();
                    found.add(new Item(name,e.getSize(),regular?DocumentRules.entryKind(name):""));entries.put(name,e);
                }
            }
            found.sort((a,b)->DocumentRules.naturalCompare(a.name(),b.name()));items=List.copyOf(found);
        }catch(IOException|RuntimeException|Error error){opened.close();throw error;}
    }
    public List<Item> items(){return items;}
    public File read(String name,File directory)throws IOException {
        Item item=item(name);if(item==null || item.kind().isEmpty())throw new IOException("Entrada catalogada sin lector integrado; no se siguen enlaces.");
        if(item.bytes()>ZipBook.MAX_ENTRY_BYTES)throw new IOException("Entrada mayor de 64 MiB.");
        return ArchiveFiles.copy(tar.getInputStream(entries.get(name)),directory,"entry",ZipBook.MAX_ENTRY_BYTES,item.bytes());
    }
    /** Before library parsing: bound raw metadata allocation, recursive extension chains and offsets. */
    static void preflight(File source)throws IOException {
        if(source.length()<1024 || source.length()>ReaderSession.MAX_SOURCE_BYTES || source.length()%512!=0)throw new IOException("Tamaño TAR incompatible o truncado.");
        long deadline=System.nanoTime()+90_000_000_000L;int count=0,metadata=0,chain=0;
        try(RandomAccessFile in=new RandomAccessFile(source,"r")) {
            byte[] header=new byte[512];boolean ended=false;
            while(in.getFilePointer()<in.length()) {
                ArchiveFiles.check(deadline);in.readFully(header);boolean zero=true;for(byte value:header)if(value!=0){zero=false;break;}
                if(zero){in.readFully(header);for(byte value:header)if(value!=0)throw new IOException("Final TAR no válido.");ended=true;break;}
                if(++count>ZipBook.MAX_ENTRIES || !TarUtils.verifyCheckSum(header))throw new IOException("TAR con demasiadas entradas o cabecera dañada.");
                long size;try{size=TarUtils.parseOctalOrBinary(header,124,12);}catch(IllegalArgumentException e){throw new IOException("Tamaño de entrada TAR no válido.",e);}
                if(size<0 || size>ReaderSession.MAX_SOURCE_BYTES)throw new IOException("Tamaño de entrada TAR fuera del límite.");
                byte flag=header[156];boolean extension=flag=='x' || flag=='g' || flag=='L' || flag=='K';
                if(flag=='S')throw new IOException("TAR disperso (sparse) no admitido en esta entrega.");
                if(extension){if(size>MAX_METADATA || (metadata+=size)>MAX_METADATA_TOTAL || ++chain>8)throw new IOException("Metadatos TAR fuera del límite.");}
                else chain=0;
                long padded=(size+511)/512*512,next=in.getFilePointer()+padded;if(next>in.length())throw new IOException("Entrada TAR truncada.");
                if(extension && (flag=='x' || flag=='g')) {
                    byte[] pax=new byte[(int)size];in.readFully(pax);String fields=new String(pax,java.nio.charset.StandardCharsets.UTF_8);
                    // Overrides can change physical layout or allocate sparse maps before an entry is returned.
                    if(java.util.regex.Pattern.compile("(?m)^[0-9]+ (?:size|GNU\\.sparse[^=]*|SCHILY\\.realsize)=").matcher(fields).find())throw new IOException("TAR con tamaño PAX alternativo o sparse no admitido.");
                }
                in.seek(next);
            }
            if(!ended)throw new IOException("TAR sin registros finales completos.");
            // No concatenated archives or nonzero data after the first end marker.
            byte[] block=new byte[65536];int n;while((n=in.read(block))!=-1){ArchiveFiles.check(deadline);for(int i=0;i<n;i++)if(block[i]!=0)throw new IOException("Datos adicionales después del final TAR.");}
            if(chain!=0)throw new IOException("Extensión TAR sin entrada posterior.");
        }
    }
    @Override public void close()throws IOException{tar.close();}
}
