package com.peach.local;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;

/** Plain text only; never HTML rendering, script evaluation or network loading. */
public final class TextPreview {
    public static final int MAX_BYTES=1024*1024,MAX_CHARS=200000;
    public record Result(String text,boolean truncated) {}
    private TextPreview() {}
    public static Result read(InputStream input) throws IOException {
        var buffer=new java.io.ByteArrayOutputStream();byte[] chunk=new byte[8192];int count;
        while(buffer.size()<=MAX_BYTES && (count=input.read(chunk,0,Math.min(chunk.length,MAX_BYTES+1-buffer.size())))!=-1) {
            if(Thread.currentThread().isInterrupted())throw new java.io.InterruptedIOException();
            if(count==0)throw new IOException("El documento no devolvió datos.");buffer.write(chunk,0,count);
        }
        byte[] bytes=buffer.toByteArray();boolean truncated=bytes.length>MAX_BYTES;
        int size=Math.min(bytes.length,MAX_BYTES),offset=0;var charset=StandardCharsets.UTF_8;
        if(size>=3 && (bytes[0]&255)==239 && (bytes[1]&255)==187 && (bytes[2]&255)==191)offset=3;
        else if(size>=2 && (bytes[0]&255)==255 && (bytes[1]&255)==254){charset=StandardCharsets.UTF_16LE;offset=2;}
        else if(size>=2 && (bytes[0]&255)==254 && (bytes[1]&255)==255){charset=StandardCharsets.UTF_16BE;offset=2;}
        var decoder=charset.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT);
        CharBuffer chars=CharBuffer.allocate(MAX_CHARS+1);
        try {
            var result=decoder.decode(ByteBuffer.wrap(bytes,offset,size-offset),chars,!truncated);
            if(result.isError())result.throwException();
            truncated|=result.isOverflow() || chars.position()>MAX_CHARS;
        }catch(CharacterCodingException error){throw new IOException("Texto no compatible. Usa UTF-8 o UTF-16 con BOM.",error);}
        chars.flip();String text=chars.toString();if(text.length()>MAX_CHARS)text=text.substring(0,MAX_CHARS);
        if(!text.isEmpty() && Character.isHighSurrogate(text.charAt(text.length()-1))){text=text.substring(0,text.length()-1);truncated=true;}
        return new Result(text,truncated);
    }
}
