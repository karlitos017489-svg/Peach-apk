package com.peach.local;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.util.LruCache;
import android.widget.ImageView;
import java.io.InputStream;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public final class Thumbnails {
    private static final LruCache<String,Bitmap> CACHE = new LruCache<>(8*1024*1024) {
        @Override protected int sizeOf(String key,Bitmap bitmap) { return bitmap.getAllocationByteCount(); }
    };
    private static final ThreadPoolExecutor POOL = new ThreadPoolExecutor(2,2,30,TimeUnit.SECONDS,
        new ArrayBlockingQueue<>(48),new ThreadPoolExecutor.AbortPolicy());
    private static final java.util.Map<String,java.util.List<java.lang.ref.WeakReference<ImageView>>> PENDING=new java.util.HashMap<>();
    private Thumbnails() {}
    static void clearMemory(){CACHE.evictAll();}
    public static void load(Context context, MediaEntry media, ImageView view) {
        String key=media.uri+"|"+media.modified+"|"+media.poster+"|"+media.mediaType;
        view.setTag(key);
        Bitmap cached=CACHE.get(key);
        if (cached!=null) { view.setScaleType(ImageView.ScaleType.CENTER_CROP);view.setImageBitmap(cached); return; }
        view.setScaleType(ImageView.ScaleType.CENTER_INSIDE);view.setImageDrawable(PeachDesign.icon(context,MediaRules.VIDEO.equals(media.mediaType)?R.drawable.ic_ui_play:MediaRules.AUDIO.equals(media.mediaType)?R.drawable.ic_ui_audio:MediaRules.IMAGE.equals(media.mediaType)?R.drawable.ic_ui_image:R.drawable.ic_ui_file,UiAppearance.secondary(context)));
        if(!MediaRules.IMAGE.equals(media.mediaType) && !MediaRules.playable(media) && media.poster.isEmpty())return;
        Context app=context.getApplicationContext();
        synchronized(PENDING){var waiting=PENDING.get(key);if(waiting!=null){waiting.removeIf(ref->ref.get()==null||ref.get()==view);if(waiting.size()<128)waiting.add(new java.lang.ref.WeakReference<>(view));return;}var first=new java.util.ArrayList<java.lang.ref.WeakReference<ImageView>>();first.add(new java.lang.ref.WeakReference<>(view));PENDING.put(key,first);}
        try{POOL.execute(() -> {
            try{
            Bitmap bitmap=null;
            try {
                if (MediaRules.IMAGE.equals(media.mediaType)) bitmap=ImageFiles.decode(app.getContentResolver(),Uri.parse(media.uri),640).bitmap();
                else {
                    if (!media.poster.isEmpty()) bitmap=ImageFiles.decode(app.getContentResolver(),Uri.parse(media.poster),640).bitmap();
                    if (bitmap==null && MediaRules.VIDEO.equals(media.mediaType) && MediaRules.playable(media)) bitmap=frame(app,Uri.parse(media.uri));
                }
            } catch (Exception ignored) { /* A placeholder remains available for unsupported media. */ }
            catch (OutOfMemoryError ignored) { /* Bound decoding still depends on the platform decoder. */ }
            if (bitmap!=null) {
                CACHE.put(key,bitmap); Bitmap result=bitmap;
                java.util.List<java.lang.ref.WeakReference<ImageView>> waiting;
                synchronized(PENDING){waiting=PENDING.remove(key);}
                if(waiting!=null)for(var reference:waiting){ImageView target=reference.get();if(target!=null)target.post(()->{if(key.equals(target.getTag())){target.setScaleType(ImageView.ScaleType.CENTER_CROP);target.setImageBitmap(result);}});}
            }
            }finally{synchronized(PENDING){PENDING.remove(key);}}
        });}catch(java.util.concurrent.RejectedExecutionException ignored){synchronized(PENDING){PENDING.remove(key);}}
    }
    static Bitmap frame(Context context,Uri uri) throws Exception {
        if (android.os.Build.VERSION.SDK_INT<27) return null;
        MediaMetadataRetriever retriever=new MediaMetadataRetriever();
        try {
            retriever.setDataSource(context,uri);
            return retriever.getScaledFrameAtTime(0,MediaMetadataRetriever.OPTION_CLOSEST_SYNC,480,270);
        } finally {
            // close()/AutoCloseable were added in API 29; release() also exists on API 26–28.
            retriever.release();
        }
    }
}
