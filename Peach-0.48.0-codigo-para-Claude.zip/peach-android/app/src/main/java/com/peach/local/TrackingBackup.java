package com.peach.local;

import java.util.*;
import org.json.*;

/** Backup v8 tracking, applied within the complete personal-state transaction. */
public final class TrackingBackup {
    private TrackingBackup() {}
    static JSONObject want(WantItem w) {
        try {JSONObject row=new JSONObject().put("id",w.id);
            row.put("state",w.state);
            row.put("releaseDate",w.releaseDate);
            row.put("origin",w.origin);
            row.put("source",w.source);
            row.put("lastSearchAt",w.lastSearchAt);
            row.put("lastSearchOutcome",w.lastSearchOutcome);
            row.put("lastSearchNote",w.lastSearchNote);
            row.put("acquiredAt",w.acquiredAt);
            row.put("acquiredBatch",w.acquiredBatch);
            row.put("priorState",w.priorState);
            row.put("publicationId",w.publicationId==null?JSONObject.NULL:w.publicationId);
            row.put("searchCount",w.searchCount);
            row.put("updatedAt",w.updatedAt);
            return row;
        }catch(JSONException e){throw new IllegalArgumentException("Deseo inválido.",e);}
    }
    static JSONObject fingerprint(WantItem w){try{return want(w).put("title",w.title).put("code",w.code).put("notes",w.notes).put("entityId",w.entityId==null?JSONObject.NULL:w.entityId).put("mediaId",w.mediaId==null?JSONObject.NULL:w.mediaId).put("createdAt",w.createdAt);}catch(JSONException e){throw new IllegalArgumentException(e);}}
    static void applyWant(WantItem w,JSONObject row) throws JSONException {
        w.state=text(row,"state",4096);
        w.releaseDate=text(row,"releaseDate",4096);
        w.origin=text(row,"origin",4096);
        w.source=text(row,"source",4096);
        w.lastSearchAt=text(row,"lastSearchAt",4096);
        w.lastSearchOutcome=text(row,"lastSearchOutcome",4096);
        w.lastSearchNote=text(row,"lastSearchNote",4000);
        w.acquiredAt=text(row,"acquiredAt",4096);
        w.acquiredBatch=text(row,"acquiredBatch",4096);
        w.priorState=text(row,"priorState",4096);
        w.publicationId=nullable(row,"publicationId");long count=number(row,"searchCount");if(count>1000000)throw new IllegalArgumentException("Contador inválido.");w.searchCount=(int)count;w.updatedAt=number(row,"updatedAt");
        WantStore.state(w.state);WantStore.state(w.priorState);
        if(!List.of("","found","none","error").contains(w.lastSearchOutcome))throw new IllegalArgumentException("Resultado de búsqueda inválido.");
    }
    static void preserve(WantItem old,WantItem incoming){
        if(old==null){incoming.state=incoming.mediaId==null?"wanted":"acquired";incoming.updatedAt=incoming.createdAt;return;}
        try{applyWant(incoming,want(old));}catch(JSONException e){throw new IllegalArgumentException(e);}
    }
    static JSONObject publication(Publication p) throws JSONException {
        JSONObject row=new JSONObject();
        row.put("id",p.id);
        row.put("title",p.title);
        row.put("provider",p.provider);
        row.put("sourceRef",p.sourceRef);
        row.put("sourceLabel",p.sourceLabel);
        row.put("externalId",p.externalId);
        row.put("url",p.url);
        row.put("publishedAt",p.publishedAt);
        row.put("precision",p.precision);
        row.put("semantics",p.semantics);
        row.put("releaseKey",p.releaseKey);
        row.put("variant",p.variant);
        row.put("variantLabel",p.variantLabel);
        row.put("status",p.status);
        row.put("origin",p.origin);
        row.put("notes",p.notes);
        row.put("entityId",p.entityId==null?JSONObject.NULL:p.entityId);
        row.put("mediaId",p.mediaId==null?JSONObject.NULL:p.mediaId);
        row.put("createdAt",p.createdAt);
        return row;
    }
    static Publication publication(JSONObject row) throws JSONException {
        Publication p=new Publication();
        p.id=text(row,"id",4096);
        p.title=text(row,"title",4096);
        p.provider=text(row,"provider",4096);
        p.sourceRef=text(row,"sourceRef",4096);
        p.sourceLabel=text(row,"sourceLabel",4096);
        p.externalId=text(row,"externalId",4096);
        p.url=text(row,"url",4096);
        p.publishedAt=text(row,"publishedAt",4096);
        p.precision=text(row,"precision",4096);
        p.semantics=text(row,"semantics",4096);
        p.releaseKey=text(row,"releaseKey",4096);
        p.variant=text(row,"variant",4096);
        p.variantLabel=text(row,"variantLabel",4096);
        p.status=text(row,"status",4096);
        p.origin=text(row,"origin",4096);
        p.notes=text(row,"notes",4000);
        p.entityId=nullable(row,"entityId");p.mediaId=nullable(row,"mediaId");p.createdAt=number(row,"createdAt");PublicationStore.validate(p);return p;
    }
    static String text(JSONObject row,String key,int max){Object v=row.opt(key);if(!(v instanceof String s) || s.length()>max || s.indexOf('\0')>=0)throw new IllegalArgumentException("Campo inválido: "+key);return s;}
    static long number(JSONObject row,String key){Object v=row.opt(key);if(!(v instanceof Number n) || n.doubleValue()!=n.longValue() || n.longValue()<0)throw new IllegalArgumentException("Número inválido: "+key);return n.longValue();}
    static String nullable(JSONObject row,String key){if(!row.has(key))throw new IllegalArgumentException("Campo ausente: "+key);if(row.isNull(key))return null;String v=text(row,key,key.equals("mediaId")?8*1024*1024:1000);if(v.isBlank())throw new IllegalArgumentException("Referencia vacía.");return v;}
    public static void write(LibraryDao dao,JSONObject backup) throws JSONException {
        JSONArray wants=new JSONArray(),publications=new JSONArray();for(WantItem w:dao.wants())wants.put(want(w));for(Publication p:dao.publications()){PublicationStore.validate(p);publications.put(publication(p));}
        if(wants.length()>5000 || publications.length()>10000)throw new IllegalArgumentException("Seguimiento demasiado grande.");backup.put("wantTracking",wants).put("publications",publications);
    }
    public static void restore(LibraryDao dao,JSONObject backup) throws JSONException {
        JSONArray publications=backup.getJSONArray("publications"),tracking=backup.getJSONArray("wantTracking"),wants=backup.getJSONArray("wants");
        if(publications.length()>10000 || tracking.length()>5000)throw new IllegalArgumentException("Seguimiento demasiado grande.");
        Set<String> entityIds=new HashSet<>(),ids=new HashSet<>(),wantIds=new HashSet<>(),publicationIds=new HashSet<>();
        JSONArray entities=backup.getJSONArray("entities");for(int i=0;i<entities.length();i++)entityIds.add(entities.getJSONObject(i).getString("id"));for(int i=0;i<wants.length();i++)wantIds.add(wants.getJSONObject(i).getString("id"));
        for(int i=0;i<publications.length();i++) {
            Publication p=publication(publications.getJSONObject(i));if(!publicationIds.add(p.id) || p.entityId!=null && !entityIds.contains(p.entityId))throw new IllegalArgumentException("Publicación duplicada o identidad ajena.");
            if(p.mediaId!=null && dao.get(p.mediaId)==null)p.mediaId=null;
            if(dao.publication(p.id)==null)dao.insertPublication(p);else dao.updatePublication(p);
        }
        for(int i=0;i<tracking.length();i++) {
            JSONObject row=tracking.getJSONObject(i);String id=text(row,"id",1000);if(!wantIds.contains(id) || !ids.add(id))throw new IllegalArgumentException("Seguimiento duplicado o sin deseo.");
            WantItem w=dao.want(id);if(w==null)throw new IllegalArgumentException("Deseo ausente.");applyWant(w,row);
            if(w.publicationId!=null && !publicationIds.contains(w.publicationId))throw new IllegalArgumentException("Publicación ajena a la copia.");dao.updateWant(w);
        }
        if(!ids.equals(wantIds))throw new IllegalArgumentException("Falta el seguimiento de una obra.");
    }
}
