package com.peach.local;

import android.app.Activity;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import java.io.*;

/** Local appearance only. No network, media grants or library state. */
final class UiAppearance {
    static final java.util.concurrent.ExecutorService IO=java.util.concurrent.Executors.newFixedThreadPool(2);
    static final String PREFS="peach-appearance";
    static final int[] COLORS={0xffedab8d,0xff8eb9f3,0xff8dcfb0,0xffbca2e8,0xffe8a0bc,0xffe2c47f};
    static final String[] NAMES={"Durazno","Azul","Menta","Lavanda","Rosa","Arena"};
    static android.content.SharedPreferences prefs(Context c){return c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
    static boolean dark(Context c){if(c instanceof PlayerActivity||c instanceof AudioActivity||c instanceof ImageViewerActivity||c instanceof ReaderActivity)return true;int mode=prefs(c).getInt("mode",1);return mode==1||mode==0&&(c.getResources().getConfiguration().uiMode&0x30)==0x20;}
    static int background(Context c){return dark(c)?0xff090b10:0xfff7f7fa;}
    static int surface(Context c){return dark(c)?0xff171a23:0xffffffff;}
    static int text(Context c){return dark(c)?0xfff1f3f8:0xff18212f;}
    static int secondary(Context c){return dark(c)?0xffb8c2d2:0xff536175;}
    static int accentIndex(Context c){return Math.max(0,Math.min(COLORS.length-1,prefs(c).getInt("accent",0)));}
    static int accent(Context c){int index=accentIndex(c);return dark(c)?COLORS[index]:new int[]{0xff8d4226,0xff245998,0xff246b4e,0xff654398,0xff913b5b,0xff755814}[index];}
    static int theme(Context c){return new int[]{R.style.PeachPeach,R.style.PeachBlue,R.style.PeachMint,R.style.PeachLavender,R.style.PeachRose,R.style.PeachSand}[accentIndex(c)];}
    static boolean motion(Context c){return prefs(c).getInt("motion",1)>0&&android.animation.ValueAnimator.areAnimatorsEnabled();}
    static int dp(Context c,int value){return Math.round(value*c.getResources().getDisplayMetrics().density);}
    static GradientDrawable rounded(Context c,int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(c,radius));return d;}
    static void polish(View view){
        Context c=view.getContext();
        if(view instanceof androidx.media3.ui.PlayerView)return;
        if(view.getTag(R.id.design_role)!=null){PeachDesign.finish(view);}
        else if(view instanceof Button b){b.setAllCaps(false);b.setMinHeight(dp(c,48));b.setTextColor(text(c));
            GradientDrawable face=rounded(c,surface(c),14);b.setTextSize(14); b.setPadding(dp(c,14),dp(c,6),dp(c,14),dp(c,6));
            b.setBackground(new RippleDrawable(android.content.res.ColorStateList.valueOf((accent(c)&0x00ffffff)|0x33000000),face,null));
            if(motion(c))b.setOnTouchListener((v,event)->{if(event.getActionMasked()==MotionEvent.ACTION_DOWN)v.animate().scaleX(.97f).scaleY(.97f).setDuration(90).start();else if(event.getActionMasked()==MotionEvent.ACTION_UP||event.getActionMasked()==MotionEvent.ACTION_CANCEL)v.animate().scaleX(1).scaleY(1).setDuration(120).start();return false;});
        }else if(view instanceof TextView t){t.setTextColor(text(c));if(t instanceof EditText){t.setHintTextColor(secondary(c));t.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent(c)));}}
        if(view instanceof ProgressBar p){p.setProgressTintList(android.content.res.ColorStateList.valueOf(accent(c)));p.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(accent(c)));}
        if(view instanceof ViewGroup group)for(int i=0;i<group.getChildCount();i++)polish(group.getChildAt(i));
    }
    static LinearLayout column(Activity activity,String title){
        ScrollView scroll=new ScrollView(activity);scroll.setFillViewport(true);LinearLayout root=new LinearLayout(activity);root.setOrientation(LinearLayout.VERTICAL);int pad=dp(activity,18);root.setPadding(pad,pad,pad,pad);scroll.addView(root);activity.setContentView(scroll);
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(scroll,(v,insets)->{var b=insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars()|androidx.core.view.WindowInsetsCompat.Type.displayCutout()|androidx.core.view.WindowInsetsCompat.Type.ime());v.setPadding(b.left,b.top,b.right,b.bottom);return insets;});
        LinearLayout header=PeachDesign.row(activity);header.addView(PeachDesign.iconButton(activity,R.drawable.ic_ui_back,"Volver",v->activity.finish()));TextView heading=PeachDesign.text(activity,title,24,"section");heading.setPadding(dp(activity,10),0,0,0);header.addView(heading,new LinearLayout.LayoutParams(0,dp(activity,68),1));root.addView(header);return root;
    }
    static File wallpaper(Context c){return WallpaperStore.file(c);}
    static volatile Bitmap wallpaperBitmap;static volatile String wallpaperKey="";
    static synchronized void clearWallpaperMemory(){wallpaperBitmap=null;wallpaperKey="";}
    static void applyWallpaper(Activity activity){
        IO.execute(()->{try{WallpaperStore.Snapshot snapshot=WallpaperStore.load(activity);
            activity.runOnUiThread(()->{if(activity.isDestroyed()||!snapshot.key().equals(WallpaperStore.key(activity)))return;
                int strength=Math.max(10,Math.min(80,prefs(activity).getInt("wallpaperStrength",35)));int base=background(activity);
                ColorDrawable veil=new ColorDrawable((base&0xffffff)|((255-strength*255/100)<<24));activity.getWindow().setBackgroundDrawable(new LayerDrawable(new Drawable[]{new WallpaperImage(snapshot.bitmap()),veil}));});
            }catch(Exception|OutOfMemoryError ignored){/* Keep the normal readable background. */}
        });
    }
    static void saveWallpaper(Context c,android.net.Uri uri)throws IOException {WallpaperStore.save(c,uri);}
}
