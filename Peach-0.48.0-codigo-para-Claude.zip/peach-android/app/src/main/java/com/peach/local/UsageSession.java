package com.peach.local;

import androidx.annotation.NonNull;
import androidx.room.*;

/** One local visit. An old checkpoint is not proof that a player is still running. */
@Entity(tableName="usage_sessions",foreignKeys=@ForeignKey(entity=MediaEntry.class,parentColumns="id",childColumns="mediaId",onDelete=ForeignKey.CASCADE),
    indices={@Index("mediaId"),@Index(value={"startedAt","id"})})
public class UsageSession {
    @PrimaryKey @NonNull public String id="";
    @NonNull public String mediaId="";
    @NonNull public String kind="";
    @NonNull public String title="";
    @NonNull public String searchTitle="";
    public long startedAt,updatedAt,position,duration;
    @NonNull public String entry="";
    public int page,scroll;
    @NonNull public String status="open";
    public boolean completed;
}
