package com.peach.local;

import java.text.Normalizer;
import java.util.*;
import org.json.*;

/** Bounded history, separate from media progress and counters. No reconstruction of old visits. */
public final class UsageStore {
    public static final int KEEP=10000,PAGE=100;
    static final Set<String> KINDS=Set.of("video","audio","image","reading");
    static final Set<String> STATES=Set.of("open","active","paused","closed","ended","error");
    private final LibraryDatabase db;
    public static class Summary {public long sessions,documents,finals;}
    public record Page(List<UsageSession> rows,Summary summary,int offset){public Page{rows=List.copyOf(rows);}}
    public Page page(long since,String kind,String query,int offset){
        if(since<0||!kind.isEmpty()&&!KINDS.contains(kind)||query.length()>300||offset<0||offset>KEEP)throw new IllegalArgumentException("Filtro de historial inválido.");
        Page[] result=new Page[1];String term=fold(query.trim());db.runInTransaction(()->{
            Summary summary=db.library().usageSummary(since,kind,term);int start=summary.sessions==0?0:Math.min(offset,(int)((summary.sessions-1)/PAGE)*PAGE);
            result[0]=new Page(db.library().usagePage(since,kind,term,PAGE,start),summary,start);
        });return result[0];
    }
    public UsageStore(LibraryDatabase db){this.db=db;}
    static String fold(String s){return Normalizer.normalize(s,Normalizer.Form.NFC).toLowerCase(Locale.ROOT);}
    static String shortTitle(String s){int end=Math.min(300,s.length());if(end<s.length()&&end>0&&Character.isHighSurrogate(s.charAt(end-1)))end--;return s.substring(0,end);}
    public void begin(String id,String mediaId,String kind,long now){
        uuid(id);if(!KINDS.contains(kind)||now<0)throw new IllegalArgumentException("Sesión inválida.");
        db.runInTransaction(()->{
            MediaEntry media=db.library().get(mediaId);if(media==null)return;
            if(kind.equals("reading")?!DocumentRules.readable(media.name):!kind.equals(media.mediaType))return;
            UsageSession existing=db.library().usage(id);
            if(existing!=null){if(!existing.mediaId.equals(mediaId)||!existing.kind.equals(kind))throw new IllegalArgumentException("Identidad de sesión en conflicto.");return;}
            UsageSession row=new UsageSession();row.id=id;row.mediaId=mediaId;row.kind=kind;row.title=shortTitle(media.displayTitle());row.searchTitle=fold(row.title);row.startedAt=row.updatedAt=now;
            db.library().insertUsage(row);db.library().pruneUsage(KEEP);
        });
    }
    public void checkpoint(String id,long position,long duration,String entry,int page,int scroll,String status,boolean completed,long now){
        uuid(id);validateValues(position,duration,entry,page,scroll,status,now);
        db.library().checkpointUsage(id,position,duration,entry,page,scroll,status,completed,now);
    }
    public void touch(String id,String status,long now){uuid(id);if(!STATES.contains(status)||now<0)throw new IllegalArgumentException("Estado inválido.");db.library().touchUsage(id,status,now);}
    static void validateValues(long position,long duration,String entry,int page,int scroll,String status,long now){
        if(position<0||duration<0||entry==null||entry.length()>4096||page<0||page>100000||scroll<0||scroll>10000000||!STATES.contains(status)||now<0)throw new IllegalArgumentException("Posición de historial inválida.");
    }
    static void uuid(String id){if(id==null||!id.matches("[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}"))throw new IllegalArgumentException("Identificador de sesión inválido.");}
    public static String kindLabel(String kind){return switch(kind){case "audio"->"Audio";case "image"->"Imagen";case "reading"->"Lectura";default->"Video";};}
    public static String statusLabel(String status){return switch(status){case "active"->"En uso en el último registro";case "paused"->"Pausa en el último registro";case "closed"->"Visita cerrada";case "ended"->"Final AV alcanzado";case "error"->"Error de reproducción";default->"Apertura registrada";};}
    public static JSONArray backup(LibraryDao dao)throws JSONException{
        JSONArray out=new JSONArray();for(UsageSession s:dao.usageBackup(KEEP+1))out.put(new JSONObject().put("id",s.id).put("mediaId",s.mediaId).put("kind",s.kind).put("title",s.title)
            .put("startedAt",s.startedAt).put("updatedAt",s.updatedAt).put("position",s.position).put("duration",s.duration).put("entry",s.entry).put("page",s.page).put("scroll",s.scroll).put("status",s.status).put("completed",s.completed));
        if(out.length()>KEEP)throw new IllegalArgumentException("Historial demasiado grande.");return out;
    }
    public static void restore(LibraryDatabase db,JSONObject backup){
        JSONArray rows=backup.optJSONArray("usageSessions");if(rows==null||rows.length()>KEEP)throw new IllegalArgumentException("Historial inválido.");
        Set<String> seen=new HashSet<>();
        for(int i=0;i<rows.length();i++){
            JSONObject o=rows.optJSONObject(i);if(o==null)throw new IllegalArgumentException("Sesión inválida.");
            UsageSession s=new UsageSession();s.id=string(o,"id",36);uuid(s.id);s.mediaId=string(o,"mediaId",8*1024*1024);s.kind=string(o,"kind",20);s.title=string(o,"title",300);s.searchTitle=fold(s.title);s.status=string(o,"status",20);s.entry=string(o,"entry",4096);
            s.startedAt=number(o,"startedAt");s.updatedAt=number(o,"updatedAt");s.position=number(o,"position");s.duration=number(o,"duration");long page=number(o,"page"),scroll=number(o,"scroll");
            if(page>100000||scroll>10000000||s.updatedAt<s.startedAt||s.mediaId.isEmpty()||!KINDS.contains(s.kind)||!(o.opt("completed") instanceof Boolean done)||!seen.add(s.id))throw new IllegalArgumentException("Sesión inválida o repetida.");
            s.page=(int)page;s.scroll=(int)scroll;s.completed=done;validateValues(s.position,s.duration,s.entry,s.page,s.scroll,s.status,s.updatedAt);
            if((s.completed&&!Set.of("video","audio").contains(s.kind))||(s.status.equals("ended")&&!s.completed))throw new IllegalArgumentException("Final de sesión inválido.");
            if(db.library().get(s.mediaId)==null)continue;
            UsageSession old=db.library().usage(s.id);
            if(old!=null){if(!old.mediaId.equals(s.mediaId)||!old.kind.equals(s.kind)||old.startedAt!=s.startedAt)throw new IllegalArgumentException("Identidad de historial en conflicto.");if(old.updatedAt>=s.updatedAt)continue;db.library().updateUsage(s);}
            else db.library().insertUsage(s);
        }
        db.library().pruneUsage(KEEP);
    }
    private static long number(JSONObject o,String key){
        if(!(o.opt(key) instanceof Number n)||n.longValue()<0)throw new IllegalArgumentException("Número de historial inválido.");
        long value=n.longValue();if(new java.math.BigDecimal(n.toString()).compareTo(java.math.BigDecimal.valueOf(value))!=0)throw new IllegalArgumentException("Número de historial inválido.");return value;
    }
    private static String string(JSONObject o,String key,int limit){if(!(o.opt(key) instanceof String s)||s.length()>limit)throw new IllegalArgumentException("Texto de historial inválido.");return s;}
}
