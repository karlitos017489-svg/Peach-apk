package com.peach.local;

import android.os.Bundle;
import java.util.UUID;

/** UI/player-looper owned token; all writes use the existing serial DB executor. */
public final class UsageTracker {
    private static final String PROCESS=UUID.randomUUID().toString();
    private final UsageStore store;
    private String id="",mediaId="",kind="";
    private boolean begun;
    public UsageTracker(LibraryDatabase db,Bundle state){store=new UsageStore(db);
        if(state!=null&&PROCESS.equals(state.getString("usageProcess"))){id=state.getString("usageId","");mediaId=state.getString("usageMedia","");kind=state.getString("usageKind","");begun=state.getBoolean("usageBegun");}}
    /** Reserve before asynchronous loading, but do not record failed or cancelled opens. */
    public void prepare(String document){if(matches(document))return;finish();id=UUID.randomUUID().toString();mediaId=document;kind="";begun=false;}
    public void open(MediaEntry media,String type){
        if(matches(media.id)&&kind.equals(type)&&begun)return;
        if(!matches(media.id)||!kind.isEmpty()&&!kind.equals(type)){finish();prepare(media.id);}
        kind=type;begun=true;String token=id,document=mediaId;long now=System.currentTimeMillis();
        LibraryDatabase.IO.execute(()->store.begin(token,document,type,now));
    }
    public boolean matches(String document){return !id.isEmpty()&&mediaId.equals(document);}
    public void checkpoint(long position,long duration,String entry,int page,int scroll,String status,boolean completed){
        if(id.isEmpty()||!begun)return;String token=id;long now=System.currentTimeMillis();
        LibraryDatabase.IO.execute(()->store.checkpoint(token,Math.max(0,position),Math.max(0,duration),entry,page,scroll,status,completed,now));
    }
    public void touch(String status){if(id.isEmpty()||!begun)return;String token=id;long now=System.currentTimeMillis();LibraryDatabase.IO.execute(()->store.touch(token,status,now));}
    public void finish(){touch("closed");id="";mediaId="";kind="";begun=false;}
    public void save(Bundle state){state.putString("usageProcess",PROCESS);state.putString("usageId",id);state.putString("usageMedia",mediaId);state.putString("usageKind",kind);state.putBoolean("usageBegun",begun);}
}
