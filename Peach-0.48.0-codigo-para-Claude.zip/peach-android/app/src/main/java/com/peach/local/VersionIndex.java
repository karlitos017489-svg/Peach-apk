package com.peach.local;

import java.text.Normalizer;
import java.util.*;
import java.util.regex.*;

/** Read-only filename evidence. A proposal is never a content identity or a deduplication decision. */
public final class VersionIndex {
    public static final int MAX_MEDIA=20000, MAX_MEMBERS=200, MAX_PROPOSALS=1000;
    private static final Pattern SUFFIX=Pattern.compile("(?iu)(?:^|[\\s._-]+)(2160p|4320p|1440p|1080p|720p|480p|4k|8k|x264|x265|h264|h265|hevc|avc|extended|uncut|theatrical|remastered|restored|directors[ ._-]+cut|中字|无码|有码|修复|美颜|(?:cd|disc|disk|dvd|part|pt|vol)[ ._-]*([0-9]{1,3})(?:[ ._-]+(?:of|de)[ ._-]+([0-9]{1,3}))?)$");
    private static final Pattern CODE=Pattern.compile("(?i)^(FC2[ _-]*PPV[ _-]*[0-9]{3,9}|[A-Z]{2,8}-[0-9]{2,8})(?![A-Z0-9])");
    private VersionIndex() {}

    public record Evidence(String id,String root,String folder,String name,String uri,long bytes,long modified,
                           long duration,String base,String resolution,String codec,String edition,String processing,
                           int part,int total,String code,List<String> tokens,List<String> warnings,boolean safe) {
        public Evidence {tokens=List.copyOf(tokens);warnings=List.copyOf(warnings);}
        public String signature(){return String.join(" · ",List.of(resolution.isEmpty()?"Resolución no indicada":resolution,
            edition.isEmpty()?"Edición no indicada":edition,codec.isEmpty()?"Códec no indicado":codec,
            processing.isEmpty()?"Sin marca de procesamiento":processing));}
        public String label(){return name+"\n"+signature()+(part>0?" · Parte "+part+(total>0?" de "+total:""):" · Archivo sin marca de parte");}
        public String describe(){return label()+"\nIndicios del nombre: "+(tokens.isEmpty()?"ninguno":String.join(" / ",tokens))+
            "\nCódigo NFO: "+(code.isEmpty()?"no indicado":code)+"\nDuración guardada: "+(duration>0?duration/1000+" s":"desconocida")+
            (warnings.isEmpty()?"":"\n"+String.join("\n",warnings));}
    }
    public record Proposal(String key,String title,String root,String folder,List<Evidence> members,List<String> warnings) {
        public Proposal {members=List.copyOf(members);warnings=List.copyOf(warnings);}
        public String label(){return title+" · "+members.size()+" archivos\n"+(folder.isEmpty()?"Carpeta raíz":folder);}
    }
    private static final class Marks {
        String resolution="",codec="",edition="",processing="";int part,total;boolean safe=true;
        final List<String> tokens=new ArrayList<>(),warnings=new ArrayList<>();
        String assign(String old,String value){if(!old.isEmpty()&&!old.equals(value)){safe=false;warnings.add("Marcas contradictorias en el nombre.");}return value;}
        void add(String token,String number,String count){
            tokens.add(token);String t=token.toLowerCase(Locale.ROOT);
            if(number!=null){int n=Integer.parseInt(number),c=count==null?0:Integer.parseInt(count);
                if(part>0||n<1||c>0&&n>c||count!=null&&c==0){safe=false;warnings.add("Numeración de partes contradictoria o inválida.");}
                part=n;total=c;
            }else if(t.matches("(?:2160p|4320p|1440p|1080p|720p|480p|4k|8k)"))resolution=assign(resolution,switch(t){case "4k"->"2160p";case "8k"->"4320p";default->t;});
            else if(Set.of("x264","h264","avc","x265","h265","hevc").contains(t))codec=assign(codec,Set.of("x265","h265","hevc").contains(t)?"H.265":"H.264");
            else if(Set.of("remastered","restored","修复","美颜").contains(t))processing=assign(processing,t);
            else edition=assign(edition,t.replaceAll("[ ._-]+"," "));
        }
    }
    public static Evidence inspect(MediaEntry m){
        String rest=MediaRules.stem(m.name);Marks marks=new Marks();
        if(rest.length()>512){marks.safe=false;marks.warnings.add("Nombre mayor de 512 caracteres; sin propuesta automática.");}
        else for(int i=0;i<32;i++){
            String next=stripOne(rest,marks);if(next==null)break;rest=next.trim();
            if(i==31){marks.safe=false;marks.warnings.add("Demasiadas marcas en el nombre.");}
        }
        String base=rest.replaceAll("^[\\s._-]+|[\\s._-]+$","");
        String code=m.localDetails().getOrDefault("code","").trim();
        Matcher filenameCode=CODE.matcher(base);
        if(filenameCode.find()&&!code.isEmpty()&&!codeKey(filenameCode.group(1)).equals(codeKey(code))){marks.safe=false;marks.warnings.add("El código del nombre contradice el código NFO.");}
        if(base.isBlank()){marks.safe=false;marks.warnings.add("No queda un nombre de obra después de las marcas.");}
        if(m.missing || !MediaRules.VIDEO.equals(m.mediaType)||!MediaRules.playable(m))marks.safe=false;
        return new Evidence(m.id,m.root,m.folder,m.name,m.uri,m.bytes,m.modified,Math.max(0,m.duration),base,
            marks.resolution,marks.codec,marks.edition,marks.processing,marks.part,marks.total,code,marks.tokens,marks.warnings,marks.safe);
    }
    private static String stripOne(String text,Marks marks){
        String rest=text.trim();if(rest.isEmpty())return null;
        char end=rest.charAt(rest.length()-1);char open=end==']'?'[':end==')'?'(':end=='】'?'【':0;
        if(open!=0){int at=rest.lastIndexOf(open);if(at<0)return null;String inner=rest.substring(at+1,rest.length()-1).trim();
            Marks trial=new Marks();String p=inner;
            for(int i=0;i<16;i++){Matcher match=SUFFIX.matcher(p);if(!match.find())break;trial.add(match.group(1),match.group(2),match.group(3));p=p.substring(0,match.start()).trim();if(p.isEmpty())break;}
            if(!p.isEmpty()||trial.tokens.isEmpty())return null;
            // Parse into the real collector so contradictions across brackets remain visible.
            p=inner;while(!p.isEmpty()){Matcher match=SUFFIX.matcher(p);if(!match.find())return null;marks.add(match.group(1),match.group(2),match.group(3));p=p.substring(0,match.start()).trim();}
            return rest.substring(0,at);
        }
        Matcher match=SUFFIX.matcher(rest);if(!match.find())return null;
        marks.add(match.group(1),match.group(2),match.group(3));return rest.substring(0,match.start());
    }
    static String codeKey(String value){return value.toUpperCase(Locale.ROOT).replaceAll("[ _-]","");}
    private static String baseKey(String value){return Normalizer.normalize(value,Normalizer.Form.NFC).toLowerCase(Locale.ROOT).replaceAll("[\\s._-]+"," ").trim();}
    static String key(Evidence e){return e.root()+"\u0000"+e.folder()+"\u0000"+baseKey(e.base());}

    public static List<Proposal> scan(List<MediaEntry> rows){
        if(rows.size()>MAX_MEDIA)throw new IllegalArgumentException("Máximo de revisión: 20.000 documentos. Elige una carpeta más pequeña.");
        Map<String,List<Evidence>> buckets=new TreeMap<>();Set<String> ids=new HashSet<>();
        for(MediaEntry row:rows){if(!ids.add(row.id))throw new IllegalArgumentException("Documento repetido en la revisión.");
            if(!MediaRules.VIDEO.equals(row.mediaType)||row.missing||!MediaRules.playable(row))continue;
            Evidence e=inspect(row);if(e.safe())buckets.computeIfAbsent(key(e),k->new ArrayList<>()).add(e);
        }
        List<Proposal> result=new ArrayList<>();
        for(var bucket:buckets.entrySet()){
            List<Evidence> members=bucket.getValue();if(members.size()<2||members.stream().noneMatch(e->!e.tokens().isEmpty()))continue;
            if(members.size()>MAX_MEMBERS)throw new IllegalArgumentException("Una propuesta supera 200 archivos. Revisa una carpeta más pequeña.");
            Set<String> codes=new HashSet<>();for(Evidence e:members)if(!e.code().isEmpty())codes.add(codeKey(e.code()));
            if(codes.size()>1)continue; // Explicit disagreement beats a similar filename.
            members.sort(Comparator.comparing(Evidence::signature).thenComparingInt(Evidence::part).thenComparing(Evidence::name).thenComparing(Evidence::id));
            List<String> warnings=new ArrayList<>();warnings.add("Coincidencia de nombres en la misma carpeta; requiere revisión. No comprueba el contenido.");
            if(members.stream().anyMatch(e->e.resolution().isEmpty()))warnings.add("Hay archivos sin resolución indicada en el nombre.");
            if(members.stream().anyMatch(e->e.duration()==0))warnings.add("Hay duraciones desconocidas; no se confirma equivalencia entre versiones.");
            List<Long> full=members.stream().filter(e->e.part()==0&&e.duration()>0).map(Evidence::duration).toList();
            if(full.size()>1&&Collections.max(full)-Collections.min(full)>Math.max(15000,Collections.max(full)*.10))warnings.add("Las duraciones de archivos sin marca de parte difieren más del margen de 10 % / 15 s.");
            if(members.stream().anyMatch(e->e.part()>0)&&orderedParts(members).isEmpty())warnings.add("La selección completa no es una sola secuencia continua de partes. Revisa los subconjuntos por especificación.");
            Evidence first=members.get(0);result.add(new Proposal(bucket.getKey(),first.base(),first.root(),first.folder(),members,warnings));
            if(result.size()>MAX_PROPOSALS)throw new IllegalArgumentException("Más de 1.000 propuestas. Elige una carpeta más pequeña.");
        }
        return List.copyOf(result);
    }
    /** Only one unambiguous signature with every explicitly labelled part 1..N. */
    public static List<Evidence> orderedParts(List<Evidence> selected){
        if(selected.size()<2||selected.size()>MAX_MEMBERS)return List.of();
        List<Evidence> parts=new ArrayList<>(selected);parts.sort(Comparator.comparingInt(Evidence::part));
        Evidence first=parts.get(0);int total=0;
        for(int i=0;i<parts.size();i++){Evidence e=parts.get(i);
            if(!e.safe()||e.part()!=i+1||!key(e).equals(key(first))||!e.signature().equals(first.signature()))return List.of();
            if(e.total()>0){if(total>0&&total!=e.total())return List.of();total=e.total();}
        }
        return total>0&&total!=parts.size()?List.of():List.copyOf(parts);
    }
    public static String describe(MediaEntry m){Evidence e=inspect(m);return e.tokens().isEmpty()&&e.warnings().isEmpty()?"":
        "Indicios del nombre, no mediciones ni identidad confirmada.\n"+e.describe();}
}
