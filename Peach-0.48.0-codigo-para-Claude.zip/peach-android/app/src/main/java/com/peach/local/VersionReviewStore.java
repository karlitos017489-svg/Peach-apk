package com.peach.local;

import java.util.*;

/** Persist only explicitly reviewed ordinary groups/lists, using existing backup and undo paths. */
public final class VersionReviewStore {
    private final LibraryDatabase db;
    public VersionReviewStore(LibraryDatabase db){this.db=db;}
    public record Result(String id,String name,boolean reused,boolean playlist) {}
    public Result apply(VersionIndex.Proposal proposal,List<String> chosen,String name,boolean parts){
        String label=PlaylistStore.validName(name,80);List<String> ids=List.copyOf(chosen);
        if(ids.size()<2||ids.size()>VersionIndex.MAX_MEMBERS||new HashSet<>(ids).size()!=ids.size())
            throw new IllegalArgumentException("Elige al menos dos documentos distintos de la propuesta.");
        Result[] result=new Result[1];db.runInTransaction(()->{
            Map<String,VersionIndex.Evidence> preview=new HashMap<>();for(var e:proposal.members())preview.put(e.id(),e);
            List<VersionIndex.Evidence> verified=new ArrayList<>();Set<String> codes=new HashSet<>();
            for(String id:ids){MediaEntry row=db.library().get(id);var expected=preview.get(id);
                if(row==null||expected==null||!expected.equals(VersionIndex.inspect(row)))
                    throw new IllegalArgumentException("La biblioteca cambió desde la vista previa. Actualiza las propuestas y revisa otra vez.");
                var actual=VersionIndex.inspect(row);
                if(!actual.safe()||!VersionIndex.key(actual).equals(proposal.key()))throw new IllegalArgumentException("La selección ya no forma una propuesta compatible.");
                verified.add(actual);if(!actual.code().isEmpty())codes.add(VersionIndex.codeKey(actual.code()));
            }
            if(codes.size()>1)throw new IllegalArgumentException("Los códigos NFO seleccionados se contradicen.");
            // A reviewed subset may omit every marked version and retain two unmarked files.
            // It still belongs to the original proposal; do not invent a new scan requirement.
            if(parts){
                var order=VersionIndex.orderedParts(verified);
                if(order.isEmpty())throw new IllegalArgumentException("Elige una única versión con partes explícitas consecutivas desde 1, sin duplicados ni huecos.");
                List<String> ordered=order.stream().map(VersionIndex.Evidence::id).toList();
                for(Playlist p:db.library().playlists())if(db.library().playlistItems(p.id).stream().map(i->i.mediaId).toList().equals(ordered)){
                    result[0]=new Result(p.id,p.name,true,true);return;
                }
                if(db.library().playlists().size()>=1000)throw new IllegalArgumentException("Límite de 1.000 listas; elimina una antes de crear otra.");
                PlaylistStore store=new PlaylistStore(db);String id=store.create(label);
                for(String mediaId:ordered)store.add(id,mediaId);result[0]=new Result(id,label,false,true);
            }else{
                Set<String> selected=new HashSet<>(ids);Map<String,Set<String>> saved=new HashMap<>();
                for(MediaGroupItem i:db.library().groupItems())saved.computeIfAbsent(i.groupId,k->new HashSet<>()).add(i.mediaId);
                for(MediaGroup g:db.library().groups())if(selected.equals(saved.get(g.id))){result[0]=new Result(g.id,g.name,true,false);return;}
                if(db.library().groups().size()>=1000)throw new IllegalArgumentException("Límite de 1.000 grupos; elimina uno antes de crear otro.");
                GroupStore store=new GroupStore(db);String id=store.create(label);for(String mediaId:ids)store.add(id,mediaId);
                result[0]=new Result(id,label,false,false);
            }
        });return result[0];
    }
}
