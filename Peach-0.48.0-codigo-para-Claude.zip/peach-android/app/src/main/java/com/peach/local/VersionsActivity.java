package com.peach.local;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.*;
import java.util.*;

/** Native review. Scanning is read-only; only a selected proposal can create a group/list. */
public final class VersionsActivity extends PeachActivity {
    public static class Draft extends ViewModel {
        final MutableLiveData<Integer> updates=new MutableLiveData<>(0);
        List<VersionIndex.Proposal> proposals=List.of();List<LibraryRoot> roots=List.of();
        String root="",folder="",query="",status="Busca indicios de versiones y partes en nombres de videos locales. Cada propuesta reúne solo archivos de la misma raíz y carpeta.",reviewKey="",name="";
        Set<String> chosen=new LinkedHashSet<>();boolean initialized,busy;
    }
    private LibraryDatabase db;private Draft draft;private Spinner roots;private EditText folder,search;
    private TextView status;private Button refresh;private ArrayAdapter<String> adapter;
    private final List<VersionIndex.Proposal> visible=new ArrayList<>();private boolean rendering;
    private AlertDialog review;private Button groupAction,partsAction;
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);db=LibraryDatabase.get(this);draft=new ViewModelProvider(this).get(Draft.class);
        if(!draft.initialized){draft.initialized=true;draft.root=extra("root");draft.folder=draft.root.isEmpty()?"":extra("folder");}
        LinearLayout column=new LinearLayout(this);column.setOrientation(LinearLayout.VERTICAL);
        int pad=(int)(12*getResources().getDisplayMetrics().density);column.setPadding(pad,pad,pad,pad);setContentView(column);
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(column,(view,insets)->{var bars=insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars()|androidx.core.view.WindowInsetsCompat.Type.displayCutout()|androidx.core.view.WindowInsetsCompat.Type.ime());view.setPadding(pad+bars.left,pad+bars.top,pad+bars.right,pad+bars.bottom);return insets;});
        LinearLayout toolbar=new LinearLayout(this);column.addView(toolbar);
        Button back=button(toolbar,"Volver",v->finish());back.setContentDescription("Volver a la biblioteca");
        TextView title=new TextView(this);title.setText(R.string.versions_title);title.setTextSize(20);toolbar.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        roots=new Spinner(this);roots.setContentDescription("Carpeta raíz a revisar");column.addView(roots);
        roots.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> p){}public void onItemSelected(AdapterView<?> p,View view,int index,long id){if(rendering)return;String value=index==0?"":draft.roots.get(index-1).uri;if(!value.equals(draft.root)){draft.root=value;draft.folder="";folder.setText("");invalidate();}}});
        folder=input(column,"Subcarpeta (incluye descendientes)",draft.folder);folder.setId(R.id.versions_folder);
        refresh=button(column,"Buscar propuestas",v->scan());refresh.setId(R.id.versions_scan);
        status=new TextView(this);status.setId(R.id.versions_status);status.setTextIsSelectable(true);column.addView(status);
        search=input(column,"Filtrar propuestas por nombre, marcas o carpeta",draft.query);search.setId(R.id.versions_search);
        ListView list=new ListView(this);list.setId(R.id.versions_list);column.addView(list,new LinearLayout.LayoutParams(-1,0,1));
        adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,new ArrayList<>());list.setAdapter(adapter);
        list.setOnItemClickListener((p,v,index,id)->{var proposal=visible.get(index);draft.reviewKey=proposal.key();draft.name=shortName(proposal.title());draft.chosen=new LinkedHashSet<>(proposal.members().stream().map(VersionIndex.Evidence::id).toList());showReview(proposal);});
        watch(folder,()->{draft.folder=folder.getText().toString();invalidate();});watch(search,()->{draft.query=search.getText().toString();filter();});
        draft.updates.observe(this,n->render());
        if(draft.roots.isEmpty()&&!draft.busy)work(()->{draft.roots=db.library().roots();});
    }
    private String extra(String key){String value=getIntent().getStringExtra(key);return value==null||value.length()>4096?"":value;}
    private Button button(LinearLayout parent,String text,View.OnClickListener click){Button b=new Button(this);b.setText(text);b.setAllCaps(false);b.setOnClickListener(click);parent.addView(b);return b;}
    private EditText input(LinearLayout parent,String hint,String text){EditText v=new EditText(this);v.setHint(hint);v.setSingleLine(true);v.setText(text);parent.addView(v);return v;}
    private void watch(EditText v,Runnable changed){v.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){if(!rendering)changed.run();}public void afterTextChanged(android.text.Editable e){}});}
    private void invalidate(){draft.proposals=List.of();draft.reviewKey="";draft.status="El ámbito cambió. Busca propuestas otra vez.";render();}
    interface Job{void run()throws Exception;}
    private void work(Job job){if(draft.busy)return;draft.busy=true;render();Draft retained=draft;
        LibraryDatabase.IO.execute(()->{try{job.run();}catch(Exception e){retained.status="No se pudo completar: "+(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage());}finally{retained.busy=false;retained.updates.postValue(1);}});
    }
    private void scan(){String root=draft.root,path=draft.folder;draft.proposals=List.of();draft.reviewKey="";
        work(()->{List<MediaEntry> scoped=db.library().reviewMedia(root,path,VersionIndex.MAX_MEDIA+1);
            draft.proposals=VersionIndex.scan(scoped);draft.status=draft.proposals.size()+" propuestas. Buscar no modifica la biblioteca. Revisa cada selección antes de guardarla.";});
    }
    private String rootLabel(String uri){for(LibraryRoot r:draft.roots)if(r.uri.equals(uri))return r.label;return uri;}
    private void filter(){visible.clear();List<String> labels=new ArrayList<>();String query=draft.query.trim().toLowerCase(Locale.ROOT);
        for(var p:draft.proposals){String label=p.label()+"\nRaíz: "+rootLabel(p.root());StringBuilder haystack=new StringBuilder(label);
            for(var e:p.members())haystack.append('\n').append(e.describe());
            if(haystack.toString().toLowerCase(Locale.ROOT).contains(query)){visible.add(p);labels.add(label);}}
        adapter.clear();adapter.addAll(labels);
    }
    private void render(){if(isDestroyed()||status==null)return;rendering=true;
        List<String> labels=new ArrayList<>();labels.add("Todas las raíces (sin mezclar carpetas)");int selection=0;
        for(LibraryRoot root:draft.roots){labels.add(root.label);if(root.uri.equals(draft.root))selection=labels.size()-1;}
        // An unavailable remembered root must not silently broaden the next scan.
        if(!draft.root.isEmpty()&&selection==0&&!draft.busy){draft.status="La raíz seleccionada ya no está en la biblioteca. Elige otra raíz.";}
        roots.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels));roots.setSelection(selection);
        roots.setEnabled(!draft.busy);folder.setEnabled(!draft.busy&&!draft.root.isEmpty());
        refresh.setEnabled(!draft.busy&&(draft.root.isEmpty()||selection>0));status.setText(draft.busy?"Revisando biblioteca…":draft.status);
        filter();rendering=false;
        if(review!=null){if(draft.reviewKey.isEmpty()){review.dismiss();review=null;}else updateActions();}
        if(review==null&&!draft.reviewKey.isEmpty())for(var p:draft.proposals)if(p.key().equals(draft.reviewKey)){showReview(p);break;}
    }
    private void showReview(VersionIndex.Proposal proposal){
        if(review!=null&&review.isShowing())return;
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(20,0,20,0);
        TextView explanation=new TextView(this);explanation.setText(getString(R.string.versions_review_explanation,String.join("\n",proposal.warnings())));explanation.setTextIsSelectable(true);body.addView(explanation);
        TextView result=new TextView(this);result.setId(R.id.versions_review_status);result.setTextIsSelectable(true);body.addView(result);
        EditText name=input(body,"Nombre del grupo o lista (máximo 80)",draft.name);name.setId(R.id.versions_name);name.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(80)});
        watch(name,()->{draft.name=name.getText().toString();updateActions();});
        review=new AlertDialog.Builder(this).setTitle("Revisar · "+proposal.title()).setView(body)
            .setMultiChoiceItems(proposal.members().stream().map(VersionIndex.Evidence::describe).toArray(String[]::new),
                checked(proposal),(dialog,index,on)->{String id=proposal.members().get(index).id();if(on)draft.chosen.add(id);else draft.chosen.remove(id);updateActions();})
            .setPositiveButton("Guardar grupo",null).setNeutralButton("Lista de partes",null)
            .setNegativeButton("Volver",(d,w)->draft.reviewKey="").create();
        review.setOnCancelListener(d->draft.reviewKey="");
        review.show();groupAction=review.getButton(AlertDialog.BUTTON_POSITIVE);partsAction=review.getButton(AlertDialog.BUTTON_NEUTRAL);
        groupAction.setOnClickListener(v->save(proposal,false));partsAction.setOnClickListener(v->save(proposal,true));updateActions();
    }
    private boolean[] checked(VersionIndex.Proposal p){boolean[] values=new boolean[p.members().size()];for(int i=0;i<values.length;i++)values[i]=draft.chosen.contains(p.members().get(i).id());return values;}
    private void updateActions(){if(groupAction==null||partsAction==null)return;boolean ready=!draft.busy&&draft.chosen.size()>=2&&!draft.name.trim().isEmpty();groupAction.setEnabled(ready);
        var p=draft.proposals.stream().filter(x->x.key().equals(draft.reviewKey)).findFirst().orElse(null);
        boolean ordered=p!=null&&!VersionIndex.orderedParts(p.members().stream().filter(e->draft.chosen.contains(e.id())).toList()).isEmpty();
        partsAction.setEnabled(ready&&ordered);
        if(review!=null){review.getListView().setEnabled(!draft.busy);review.findViewById(R.id.versions_name).setEnabled(!draft.busy);
            ((TextView)review.findViewById(R.id.versions_review_status)).setText(draft.busy?"Guardando selección…":draft.status);
            review.getButton(AlertDialog.BUTTON_NEGATIVE).setEnabled(!draft.busy);review.setCancelable(!draft.busy);}}
    private void save(VersionIndex.Proposal proposal,boolean parts){List<String> ids=List.copyOf(draft.chosen);String name=draft.name;
        work(()->{var result=new VersionReviewStore(db).apply(proposal,ids,name,parts);draft.status=(result.reused()?"Ya existía: ":"Guardado: ")+result.name()+
            (parts?". Disponible en Listas de reproducción; conserva el orden numérico.":". Disponible en Grupos / versiones; no cambia archivos ni progreso.");draft.reviewKey="";});
    }
    private static String shortName(String name){if(name.length()<=80)return name;int end=Character.isHighSurrogate(name.charAt(79))?79:80;return name.substring(0,end);}
    @Override protected void onDestroy(){if(review!=null){review.setOnCancelListener(null);review.dismiss();review=null;}super.onDestroy();}
}
