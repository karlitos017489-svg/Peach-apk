package com.peach.local;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.*;

/** Private immutable completed copies. Pins protect every preparing/playing owner. */
final class VideoCache {
    static final long BUDGET=2L*1024*1024*1024;
    static final int MAX_FILES=8;
    static final Object LOCK=new Object();
    static final Map<File,Integer> PINS=new HashMap<>();
    static final Map<File,Long> PARTS=new HashMap<>();
    static final Set<File> PREPARING=new HashSet<>();
    static final Map<File,Long> WAITS=new LinkedHashMap<>();
    interface Fetcher {SourceHttp.Download fetch(String url,File file,SourceHttp.Token token,long limit)throws IOException;}
    static final class Problem extends IOException {Problem(String text){super(text);}}
    record Stamp(long bytes,String sha,String extension) {}
    static final class Lease implements AutoCloseable {
        final File file;final String key;final boolean cached;final Stamp stamp;private boolean closed;
        Lease(File file,String key,boolean cached,Stamp stamp){this.file=file;this.key=key;this.cached=cached;this.stamp=stamp;}
        @Override public void close(){synchronized(LOCK){if(!closed){closed=true;int count=PINS.getOrDefault(file,0);if(count<=1)PINS.remove(file);else PINS.put(file,count-1);}}}
    }
    final File root;final long budget;
    VideoCache(File cache){this(cache,BUDGET);}
    VideoCache(File cache,long budget){if(budget<1||budget>BUDGET)throw new IllegalArgumentException();this.root=new File(cache,"peach-source-video");this.budget=budget;}
    static boolean key(String key){return key!=null&&key.matches("[a-f0-9]{64}");}
    static String keyFor(String url){return GalleryCache.key(url);}
    static boolean data(String name){return name.matches("[a-f0-9]{64}\\.(mp4|webm|mkv|mov)");}
    File meta(String key){return new File(root,key+".meta");}
    List<File> files(){File[] f=root.listFiles((d,n)->data(n));return new ArrayList<>(f==null?List.of():Arrays.asList(f));}
    boolean pinned(File file){return PINS.getOrDefault(file,0)>0;}
    void remove(File file){if(!pinned(file)){file.delete();meta(file.getName().substring(0,64)).delete();}}
    void initialize()throws IOException {
        if(!root.isDirectory()&&!root.mkdirs())throw new Problem("No se pudo abrir la copia temporal de video.");
        File[] files=root.listFiles();if(files==null)return;
        for(File file:files){String n=file.getName();
            if(n.startsWith("selected-video-")&&n.endsWith(".part")&&!PARTS.containsKey(file))file.delete();
            else if(data(n)&&!meta(n.substring(0,64)).isFile())remove(file);
            else if(n.matches("[a-f0-9]{64}\\.meta")&&files().stream().noneMatch(f->f.getName().startsWith(n.substring(0,64)+".")))file.delete();
        }
    }
    Stamp read(String key)throws IOException {
        File file=meta(key);if(file.length()<1||file.length()>160)throw new Problem("La copia temporal no está disponible o está dañada.");
        String[] p=new String(Files.readAllBytes(file.toPath()),StandardCharsets.US_ASCII).split("\n");
        try{if(p.length!=4||!p[0].equals("peach-video-1")||!p[2].matches("[a-f0-9]{64}")||!Set.of("mp4","webm","mkv","mov").contains(p[3]))throw new IllegalArgumentException();
            long bytes=Long.parseLong(p[1]);if(bytes<1||bytes>budget)throw new IllegalArgumentException();return new Stamp(bytes,p[2],p[3]);
        }catch(IllegalArgumentException e){throw new Problem("La copia temporal no está disponible o está dañada.");}
    }
    static String checksum(File file,SourceHttp.Token token)throws IOException {
        MessageDigest d;try{d=MessageDigest.getInstance("SHA-256");}catch(Exception e){throw new AssertionError(e);}
        try(InputStream in=new FileInputStream(file)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1){token.check();d.update(b,0,n);}}token.check();return GalleryCache.hex(d.digest());
    }
    void verify(SourceVideos.Video video,File file,Stamp stamp,SourceHttp.Token token)throws IOException {
        if(!video.expectedHash().isEmpty()&&!video.expectedHash().equals(stamp.sha())||file.length()!=stamp.bytes()||!checksum(file,token).equals(stamp.sha())||PawchiveUrls.downloadable(video.url())&&!PawchiveUrls.expectedHash(video.url()).equals(stamp.sha()))throw new Problem("La copia temporal está incompleta o no coincide con su hash.");
        LocalMedia.Format actual=LocalMedia.inspect(file);if(!actual.kind().equals("video")||!actual.extension().equals(stamp.extension()))throw new Problem("El adjunto no contiene un video compatible para esta copia temporal.");
        token.check();
    }
    void trim(long needed)throws IOException {
        List<File> files=files();files.sort(Comparator.comparingLong(File::lastModified).thenComparing(File::getName));long bytes=files.stream().mapToLong(File::length).sum();int count=files.size();
        for(File file:files)if(!pinned(file)&&(bytes+needed>budget||count>=MAX_FILES)){long length=file.length();remove(file);if(!file.exists()){bytes-=length;count--;}}
        if(bytes+needed>budget||count>=MAX_FILES)throw new Problem("La caché de video está en uso. Cierra otros videos y vuelve a intentarlo.");
    }
    Lease acquire(SourceVideos.Video video,boolean offline,SourceHttp.Token token,Fetcher fetcher)throws IOException {
        token.check();if(video==null||!SourceVideos.admitted(video.provider(),video.url(),true))throw new Problem("Esta referencia no admite preparación de video.");
        String key=keyFor(video.url());Lease hit=null;
        synchronized(LOCK){initialize();try{Stamp s=read(key);File file=new File(root,key+"."+s.extension());if(file.isFile()){PINS.merge(file,1,Integer::sum);hit=new Lease(file,key,true,s);}}catch(IOException ignored){for(File f:files())if(f.getName().startsWith(key+".")){if(pinned(f))throw new Problem("La copia temporal está en uso y no se puede sustituir. Cierra el video.");remove(f);}meta(key).delete();}}
        if(hit!=null){try{verify(video,hit.file,hit.stamp,token);hit.file.setLastModified(System.currentTimeMillis());return hit;}
            catch(InterruptedIOException e){hit.close();throw e;}catch(IOException|RuntimeException e){synchronized(LOCK){hit.close();if(pinned(hit.file))throw new Problem("La copia temporal está en uso y no se puede sustituir. Cierra el video.");remove(hit.file);}}}
        token.check();if(offline)throw new Problem("Este video no tiene una copia temporal válida. Desactiva Sin conexión y pulsa Preparar y reproducir.");
        File part;long limit;File marker=meta(key);
        synchronized(LOCK){if(PREPARING.contains(marker))throw new Problem("Este video ya se está preparando. Espera o cancela la otra preparación.");
            Long until=WAITS.get(marker);if(until!=null&&until>System.nanoTime())throw new SourceHttp.Failure("Espera antes de preparar de nuevo.",429,Math.max(1,(until-System.nanoTime())/1_000_000_000L));
            long pinned=PINS.keySet().stream().filter(f->f.getParentFile().equals(root)).mapToLong(File::length).sum(),reserved=PARTS.entrySet().stream().filter(e->e.getKey().getParentFile().equals(root)).mapToLong(Map.Entry::getValue).sum();
            limit=budget-pinned-reserved;if(limit<1)throw new Problem("Hay otra preparación o video usando la caché. Ciérralo y vuelve a intentarlo.");
            part=File.createTempFile("selected-video-",".part",root);PARTS.put(part,limit);PREPARING.add(marker);
        }
        File stampPart=null,completed=null;Lease result=null;boolean done=false;
        try{SourceHttp.Download d=fetcher.fetch(video.url(),part,token,limit);token.check();
            if(d.bytes()<1||d.bytes()>limit||part.length()!=d.bytes()||!d.sha256().matches("[a-f0-9]{64}"))throw new Problem("La descarga de video no superó la comprobación de tamaño.");
            LocalMedia.Format actual=LocalMedia.inspect(part);if(!actual.kind().equals("video")||!Set.of("mp4","webm","mkv","mov").contains(actual.extension()))throw new Problem("El adjunto no contiene un video MP4, WebM, MKV o MOV reconocible.");
            Stamp stamp=new Stamp(d.bytes(),d.sha256(),actual.extension());verify(video,part,stamp,token);
            synchronized(LOCK){stampPart=File.createTempFile("selected-video-",".part",root);PARTS.put(stampPart,0L);}
            Files.write(stampPart.toPath(),("peach-video-1\n"+stamp.bytes()+"\n"+stamp.sha()+"\n"+stamp.extension()).getBytes(StandardCharsets.US_ASCII));
            synchronized(LOCK){token.check();trim(stamp.bytes());completed=new File(root,key+"."+stamp.extension());
                if(pinned(completed))throw new Problem("Este video está en uso; no se puede sustituir su copia.");
                if(!part.renameTo(completed)||!stampPart.renameTo(meta(key)))throw new Problem("No se pudo conservar la copia temporal del video.");
                completed.setLastModified(System.currentTimeMillis());PINS.merge(completed,1,Integer::sum);WAITS.remove(marker);result=new Lease(completed,key,false,stamp);done=true;return result;
            }
        }catch(SourceHttp.Failure e){if(e.status==429)synchronized(LOCK){if(WAITS.size()>=128)WAITS.remove(WAITS.keySet().iterator().next());WAITS.put(marker,System.nanoTime()+Math.min(86400,Math.max(1,e.retrySeconds))*1_000_000_000L);}throw e;}
        finally{synchronized(LOCK){PARTS.remove(part);if(stampPart!=null)PARTS.remove(stampPart);PREPARING.remove(marker);part.delete();if(stampPart!=null)stampPart.delete();if(!done&&completed!=null)remove(completed);}}
    }
    void discard(String key)throws IOException {
        if(!key(key))throw new Problem("Copia temporal no válida.");synchronized(LOCK){initialize();if(PREPARING.contains(meta(key)))throw new Problem("Cancela la preparación antes de retirar su copia.");
            for(File file:files())if(file.getName().startsWith(key+".")){if(pinned(file))throw new Problem("El video está abierto. Cierra su reproductor antes de retirar la copia temporal.");remove(file);}
            meta(key).delete();
        }
    }
    int clearUnused()throws IOException {synchronized(LOCK){initialize();int count=0;for(File file:files())if(!pinned(file)&&!PREPARING.contains(meta(file.getName().substring(0,64)))){remove(file);if(!file.exists())count++;}return count;}}
    static String message(Exception e,SourceHttp.Token token){if(token.cancelled||e instanceof InterruptedIOException)return "Preparación cancelada; los archivos guardados se conservan.";if(e instanceof Problem)return e.getMessage();if(e instanceof SourceHttp.Failure f)return "La fuente respondió HTTP "+f.status+(f.status==429?". Espera "+f.retrySeconds+" segundos antes de reintentar.":". No se pudo preparar el video.");return "No se pudo preparar el video. Revisa la conexión, el espacio disponible y la compatibilidad del adjunto.";}
}
