package com.peach.local;

import java.util.*;
import org.json.JSONObject;

/** Display/ranking of source-declared variants, never proof of resolution or completeness. */
final class VideoVariants {
    record Info(String role,int height,long bytes,String group) {static Info unknown(){return new Info("unknown",0,0,"");}}
    static boolean preview(String text){return text!=null&&java.util.regex.Pattern.compile("(?i)(?:^|[\\s_./-])(preview|teaser|trailer|vista previa)(?:[\\s_./0-9-]|$)").matcher(text).find();}
    static int height(String text){var m=java.util.regex.Pattern.compile("(?i)(?<![0-9])([1-9][0-9]{2,3})p").matcher(Objects.toString(text,""));if(!m.find())return 0;int n=Integer.parseInt(m.group(1));return n>=100&&n<=8640?n:0;}
    static long number(JSONObject a,String key,long max){Object value=a.opt(key);if(!(value instanceof Number)||!value.toString().matches("[0-9]{1,18}"))return 0;try{long n=Long.parseLong(value.toString());return n<=max?n:0;}catch(NumberFormatException e){return 0;}}
    static Info info(Publication p,PublicationContent c,JSONObject a,String name,String url){
        String role=a.optString("videoRole","unknown");if(!Set.of("download","published","preview","unknown").contains(role))role="unknown";
        String path;try{path=SourceHttp.https(url).getRawPath();}catch(Exception e){path="";}
        if(preview(name)||preview(path)||p.provider.equals("rule34video")&&MediaRedirects.videoSource(url)&&c.type.equals("list"))role="preview";
        else if(role.equals("unknown")&&p.provider.equals("rule34video")&&c.type.equals("rule34video-detail")&&name.matches("(?i).*·\\s*(MP4|WEBM)\\s+.*"))role="download";
        int height=(int)number(a,"videoHeight",8640);if(height==0&&p.provider.equals("rule34video")&&role.equals("download"))height=height(name);
        String group=p.provider.equals("rule34video")&&MediaRedirects.videoSource(url)?PartialDownload.key(p.id):a.optString("variantGroup","");if(!VideoCache.key(group))group=PartialDownload.key(url);
        return new Info(role,height,number(a,"variantBytes",999999999999999999L),group);
    }
    static int best(List<SourceVideos.Video> videos){if(videos.isEmpty())return 0;int base=0;for(int i=0;i<videos.size();i++)if(!videos.get(i).variant().role().equals("preview")){base=i;break;}int best=base;String group=videos.get(base).variant().group();for(int i=base+1;i<videos.size();i++)if(group.equals(videos.get(i).variant().group())&&compare(videos.get(i).variant(),videos.get(best).variant())>0)best=i;return best;}
    static int compare(Info a,Info b){int value=Boolean.compare(!a.role().equals("preview"),!b.role().equals("preview"));if(value!=0)return value;value=Integer.compare(a.height(),b.height());return value!=0?value:Long.compare(a.bytes(),b.bytes());}
    static String label(SourceVideos.Video video){Info v=video.variant();String role=switch(v.role()){case "preview"->"Vista previa";case "download"->"Versión de descarga";case "published"->"Archivo publicado";default->"Variante";};return video.name()+"\n"+role+(v.height()>0?" · "+v.height()+"p declarados":" · calidad no declarada")+(v.bytes()>0?" · "+String.format(Locale.ROOT,"%.1f",v.bytes()/1048576.0)+" MiB declarados":"");}
    static JSONObject mark(JSONObject a,String role,int height,long bytes,String group)throws org.json.JSONException {if(a==null)return null;a.put("videoRole",role);if(height>0)a.put("videoHeight",height);if(bytes>0)a.put("variantBytes",bytes);if(group!=null&&!group.isEmpty())a.put("variantGroup",group);return a;}
}
