package com.peach.local;

import java.io.*;
import java.util.*;
import org.json.*;

/** Explicit metadata-only refresh of one imported publication, then a reviewed atomic apply. */
final class VideoVersionReview {
    record Snapshot(Publication publication,PublicationContent content,FollowSource source,String identity,String stamp) {}
    record Review(Snapshot before,PublicationContent next,SourceVideos.Selection selection) {}
    static boolean canQuery(Publication p){try{if(p==null||!Set.of("rule34video","rule34paheal","cumst").contains(p.provider))return false;SourceProviders.ref(p.provider,p.sourceRef);SourceProviders.postUrl(p.provider,p.sourceRef,p.externalId,p.url);return true;}catch(IllegalArgumentException e){return false;}}
    static String identity(Publication p){return p==null?"":p.provider+"\n"+p.sourceRef+"\n"+p.externalId+"\n"+p.url;}
    static String stamp(PublicationContent c)throws IOException{try{return c==null?"":SourceBackup.content(c).toString();}catch(JSONException e){throw new IOException("Contenido guardado no válido.");}}
    static void ready(FollowSource s)throws IOException{if(s!=null&&(s.paused||s.cooldownUntil>System.currentTimeMillis()))throw new IOException(s.paused?"La fuente está pausada.":"La fuente pidió esperar antes de consultar otra vez.");}
    static Snapshot snapshot(LibraryDatabase db,String id)throws IOException {
        Snapshot[] out={null};IOException[] error={null};db.runInTransaction(()->{try{Publication p=db.library().publication(id);if(!canQuery(p))throw new IOException("Esta publicación no admite consulta de versiones desde esta pantalla.");PublicationContent c=db.library().publicationContent(id);FollowSource s=c==null||c.sourceId==null?null:db.library().source(c.sourceId);if(s!=null&&(!s.provider.equals(p.provider)||!s.ref.equals(SourceProviders.ref(p.provider,p.sourceRef))))throw new IOException("La fuente vinculada cambió.");ready(s);out[0]=new Snapshot(p,c,s,identity(p),stamp(c));}catch(IOException e){error[0]=e;}});if(error[0]!=null)throw error[0];return out[0];
    }
    static Review query(LibraryDatabase db,String id,SourceHttp.Transport http,SourceHttp.Token token)throws IOException {
        if(!SourceVideos.id(id))throw new IOException("Publicación no válida.");Snapshot before=snapshot(db,id);Publication p=before.publication();token.check();
        try{JSONObject body=p.provider.equals("cumst")?new CumstConnector(http).detail(p.sourceRef,p.externalId,token):new WebSourceConnector(http,()->null).detail(p.provider,p.sourceRef,p.externalId,p.url,token);token.check();PublicationContent next=new PublicationContent();next.publicationId=p.id;next.sourceId=before.content()==null?null:before.content().sourceId;next.text=body.getString("text");next.attachments=body.getJSONArray("attachments").toString();next.type=body.getString("type");next.partial=body.getBoolean("partial");next.checkedAt=System.currentTimeMillis();GofileReview.keepResolved(before.content(),next);PixeldrainReview.keep(before.content(),next);SourceBackup.validateContent(next);return new Review(before,next,SourceVideos.select(p,next));
        }catch(SourceHttp.Failure e){if(e.status==429&&before.source()!=null)db.runInTransaction(()->{FollowSource s=db.library().source(before.source().id);if(s!=null&&s.provider.equals(p.provider)&&s.ref.equals(SourceProviders.ref(p.provider,p.sourceRef))){s.cooldownUntil=Math.max(s.cooldownUntil,System.currentTimeMillis()+Math.min(86400,Math.max(1,e.retrySeconds))*1000L);s.lastError="La fuente pidió esperar (HTTP429).";s.revision++;db.library().updateSource(s);}});throw new IOException("No se pudieron consultar las versiones (HTTP "+e.status+"). Se conserva el contenido actual.");
        }catch(InterruptedIOException e){throw e;}catch(IOException|JSONException|IllegalArgumentException e){throw new IOException("No se pudieron leer las versiones de esta publicación. Se conserva el contenido actual.");}
    }
    static void apply(LibraryDatabase db,Review review,SourceHttp.Token token)throws IOException {
        IOException[] error={null};db.runInTransaction(()->{try{token.check();Snapshot current=snapshot(db,review.before().publication().id);if(!current.identity().equals(review.before().identity())||!current.stamp().equals(review.before().stamp()))throw new IOException("La publicación cambió mientras revisabas. Consulta las versiones otra vez.");SourceBackup.validateContent(review.next());var next=SourceVideos.select(current.publication(),review.next());if(next.videos().stream().noneMatch(v->!GofileUrls.downloadable(v.url())))throw new IOException("No se encontraron videos compatibles; se conserva el contenido actual.");if(current.content()!=null&&next.videos().stream().filter(v->!GofileUrls.downloadable(v.url())).allMatch(v->v.variant().role().equals("preview"))&&SourceVideos.select(current.publication(),current.content()).videos().stream().filter(v->!GofileUrls.downloadable(v.url())).anyMatch(v->!v.variant().role().equals("preview")))throw new IOException("La consulta solo entregó vistas previas. Se conservan las versiones actuales.");token.check();db.library().putPublicationContent(review.next());}catch(IOException e){error[0]=e;}});if(error[0]!=null)throw error[0];
    }
}
