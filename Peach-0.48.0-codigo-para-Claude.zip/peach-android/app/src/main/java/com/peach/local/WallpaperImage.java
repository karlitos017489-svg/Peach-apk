package com.peach.local;

import android.graphics.*;
import android.graphics.drawable.Drawable;

/** Center crop preserves proportions in portrait, landscape and split screen. */
final class WallpaperImage extends Drawable {
    private final Bitmap bitmap;private final Paint paint=new Paint(Paint.FILTER_BITMAP_FLAG);
    WallpaperImage(Bitmap bitmap){this.bitmap=bitmap;}
    static Rect crop(int width,int height,int viewWidth,int viewHeight){
        if(width<1||height<1||viewWidth<1||viewHeight<1)return new Rect(0,0,Math.max(1,width),Math.max(1,height));
        if((long)width*viewHeight>(long)height*viewWidth){int n=Math.max(1,(int)((long)height*viewWidth/viewHeight));return new Rect((width-n)/2,0,(width-n)/2+n,height);}
        int n=Math.max(1,(int)((long)width*viewHeight/viewWidth));return new Rect(0,(height-n)/2,width,(height-n)/2+n);
    }
    @Override public void draw(Canvas canvas){Rect b=getBounds();if(b.width()>0&&b.height()>0)canvas.drawBitmap(bitmap,crop(bitmap.getWidth(),bitmap.getHeight(),b.width(),b.height()),b,paint);}
    @Override public void setAlpha(int alpha){paint.setAlpha(alpha);invalidateSelf();}
    @Override public void setColorFilter(ColorFilter filter){paint.setColorFilter(filter);invalidateSelf();}
    @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
