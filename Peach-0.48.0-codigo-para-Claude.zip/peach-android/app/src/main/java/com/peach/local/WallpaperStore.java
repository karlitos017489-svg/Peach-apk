package com.peach.local;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.util.AtomicFile;
import java.io.*;

/** Recover interrupted atomic writes; only app-owned wallpaper files are touched. */
final class WallpaperStore {
    static final Object LOCK=new Object();
    record Snapshot(Bitmap bitmap,String key) {}
    static File file(Context c){return new File(c.getFilesDir(),"peach-wallpaper.jpg");}
    static String key(Context c){File f=file(c);return f.lastModified()+"|"+f.length()+"|"+UiAppearance.prefs(c).getLong("wallpaperRevision",0);}
    static Snapshot load(Context c)throws IOException {synchronized(LOCK){
        AtomicFile atomic=new AtomicFile(file(c));
        try(InputStream ignored=atomic.openRead()){/* Restores .bak and discards interrupted .new as required by the platform. */}
        String key=key(c);Bitmap bitmap=UiAppearance.wallpaperBitmap;
        if(bitmap==null||!key.equals(UiAppearance.wallpaperKey)){bitmap=ImageFiles.decode(file(c),1440).bitmap();UiAppearance.wallpaperBitmap=bitmap;UiAppearance.wallpaperKey=key;}
        return new Snapshot(bitmap,key);
    }}
    static void save(Context c,Uri uri)throws IOException {
        File temp=File.createTempFile("wallpaper-",".tmp",c.getCacheDir());
        try{
            try(InputStream in=c.getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(temp)){if(in==null)throw new IOException("No se pudo abrir la imagen.");byte[] b=new byte[32768];int n;long total=0;while((n=in.read(b))!=-1){total+=n;if(total>16L*1024*1024)throw new IOException("Elige una imagen de hasta 16 MiB.");out.write(b,0,n);}}
            Bitmap bitmap=ImageFiles.decode(temp,1440).bitmap();
            try{synchronized(LOCK){AtomicFile target=new AtomicFile(file(c));FileOutputStream output=null;
                try{output=target.startWrite();if(!bitmap.compress(Bitmap.CompressFormat.JPEG,88,output))throw new IOException("No se pudo preparar el fondo.");target.finishWrite(output);output=null;changed(c);}
                finally{if(output!=null)target.failWrite(output);}
            }}finally{bitmap.recycle();}
        }finally{temp.delete();}
    }
    static boolean remove(Context c){synchronized(LOCK){new AtomicFile(file(c)).delete();changed(c);return !file(c).exists()&&!new File(file(c)+".bak").exists()&&!new File(file(c)+".new").exists();}}
    private static void changed(Context c){UiAppearance.prefs(c).edit().putLong("wallpaperRevision",UiAppearance.prefs(c).getLong("wallpaperRevision",0)+1).apply();UiAppearance.clearWallpaperMemory();}
}
