package com.peach.local;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ForeignKey;
import androidx.room.Index;

@Entity(tableName="want_items",foreignKeys={
    @ForeignKey(entity=CatalogEntity.class,parentColumns="id",childColumns="entityId",onDelete=ForeignKey.SET_NULL),
    @ForeignKey(entity=MediaEntry.class,parentColumns="id",childColumns="mediaId",onDelete=ForeignKey.SET_NULL)},
    indices={@Index("entityId"),@Index("mediaId")})
public class WantItem {
    @PrimaryKey @NonNull public String id="";
    @NonNull public String title="";
    @NonNull public String code="";
    @NonNull public String notes="";
    @Nullable public String entityId;
    @Nullable public String mediaId;
    public long createdAt;
    @NonNull @androidx.room.ColumnInfo(defaultValue="'wanted'") public String state="wanted";
    @NonNull @androidx.room.ColumnInfo(defaultValue="''") public String releaseDate="";
    @NonNull @androidx.room.ColumnInfo(defaultValue="'manual'") public String origin="manual";
    @NonNull @androidx.room.ColumnInfo(defaultValue="''") public String source="";
    @Nullable public String publicationId;
    @androidx.room.ColumnInfo(defaultValue="0") public int searchCount;
    @NonNull @androidx.room.ColumnInfo(defaultValue="''") public String lastSearchAt="";
    @NonNull @androidx.room.ColumnInfo(defaultValue="''") public String lastSearchOutcome="";
    @NonNull @androidx.room.ColumnInfo(defaultValue="''") public String lastSearchNote="";
    @NonNull @androidx.room.ColumnInfo(defaultValue="''") public String acquiredAt="";
    @NonNull @androidx.room.ColumnInfo(defaultValue="''") public String acquiredBatch="";
    @NonNull @androidx.room.ColumnInfo(defaultValue="'wanted'") public String priorState="wanted";
    @androidx.room.ColumnInfo(defaultValue="0") public long updatedAt;
}
