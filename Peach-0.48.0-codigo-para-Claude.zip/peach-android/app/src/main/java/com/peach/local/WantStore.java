package com.peach.local;

import java.time.LocalDate;
import java.time.Instant;
import java.util.*;

/** Local work tracking. Matching is explicit and never runs in a scanner. */
public final class WantStore {
    private final LibraryDatabase db;
    public WantStore(LibraryDatabase db){this.db=db;}
    public String create(String title,String code,String notes,String entityId) {
        WantItem item=new WantItem();item.id=UUID.randomUUID().toString();item.createdAt=System.currentTimeMillis();item.updatedAt=item.createdAt;
        item.title=EntityStore.name(title);item.code=code(code);item.notes=EntityStore.notes(notes);item.entityId=entityId;
        db.runInTransaction(()->{check(item);db.library().insertWant(item);});return item.id;
    }
    public void edit(String id,String title,String code,String notes) {
        db.runInTransaction(()->{WantItem item=require(id);item.title=EntityStore.name(title);item.code=code(code);item.notes=EntityStore.notes(notes);touch(item);});
    }
    public void track(String id,String releaseDate,String state) {
        if(!releaseDate.isEmpty())try{if(!LocalDate.parse(releaseDate).toString().equals(releaseDate))throw new IllegalArgumentException();}catch(Exception e){throw new IllegalArgumentException("Usa una fecha AAAA-MM-DD válida o déjala vacía.");}
        state(state);
        db.runInTransaction(()->{WantItem w=require(id);w.releaseDate=releaseDate;w.state=state;w.acquiredBatch="";w.acquiredAt=state.equals("acquired")?Instant.now().toString():"";if(!state.equals("acquired"))w.mediaId=null;touch(w);});
    }
    public void attach(String id,String mediaId) {
        db.runInTransaction(()->{WantItem item=require(id);item.mediaId=mediaId;item.state=mediaId==null?"wanted":"acquired";item.acquiredAt=mediaId==null?"":Instant.now().toString();item.acquiredBatch="";check(item);touch(item);});
    }
    public String fromPublication(String id) {
        return db.runInTransaction(()->{
            Publication p=db.library().publication(id);if(p==null)throw new IllegalArgumentException("Publicación no disponible.");
            for(WantItem w:db.library().wants())if(id.equals(w.publicationId))return w.id;
            String key=create(p.title,"",p.notes,p.entityId);WantItem w=require(key);w.publicationId=id;w.releaseDate=!p.precision.equals("exact") || day(p.publishedAt)==null?"":p.publishedAt.substring(0,10);w.origin="publication";w.source=p.origin;touch(w);
            if(p.status.equals("ignored")){p.status="seen";db.library().updatePublication(p);}return key;
        });
    }
    public void search(String id,String outcome,String note,LocalDate today) {
        if(!List.of("found","none","error").contains(outcome))throw new IllegalArgumentException("Resultado inválido.");String n=EntityStore.notes(note);
        db.runInTransaction(()->{WantItem w=require(id);if(w.state.equals("acquired") || phase(w,today).equals("unreleased"))throw new IllegalArgumentException("La obra ya está conseguida o todavía no se publica.");
            w.lastSearchAt=Instant.now().toString();w.lastSearchOutcome=outcome;w.lastSearchNote=n;
            LocalDate release=day(w.releaseDate);boolean fresh=release!=null && release.isAfter(today.minusDays(90));
            if(outcome.equals("found")){w.searchCount=0;w.state="wanted";}
            if(outcome.equals("none") && !fresh){w.searchCount=Math.min(1000000,w.searchCount+1);if(w.searchCount>=3)w.state="given_up";}touch(w);
        });
    }
    public void reset(String id){db.runInTransaction(()->{WantItem w=require(id);if(w.state.equals("acquired"))return;w.searchCount=0;if(w.state.equals("given_up"))w.state="wanted";touch(w);});}
    static LocalDate day(String date){try{return LocalDate.parse(date.substring(0,10));}catch(Exception e){return null;}}
    public static String phase(WantItem w,LocalDate today){if(w.state.equals("acquired"))return "acquired";LocalDate date=day(w.releaseDate);return date!=null && date.isAfter(today)?"unreleased":w.state.equals("given_up")?"given_up":"searching";}
    public static String label(WantItem w){return switch(phase(w,LocalDate.now())){case "acquired"->"Conseguida";case "unreleased"->"Sin publicar";case "given_up"->"Pausada tras búsquedas";default->"Pendiente de conseguir";};}
    static void state(String value){if(!List.of("wanted","given_up","acquired").contains(value))throw new IllegalArgumentException("Estado de deseo inválido.");}
    /** Case folding only; no guessing of provider-specific upstream normalization rules. */
    static String codeKey(String value){return value.trim().toUpperCase(Locale.ROOT);}
    public static String code(String value){if(value.length()>100 || value.indexOf('\0')>=0)throw new IllegalArgumentException("Usa hasta 100 caracteres en el código.");return value.trim();}
    private WantItem require(String id){WantItem item=db.library().want(id);if(item==null)throw new IllegalArgumentException("Obra no disponible.");return item;}
    private void touch(WantItem item){item.updatedAt=System.currentTimeMillis();db.library().updateWant(item);}
    private void check(WantItem item) {
        if(item.entityId!=null && db.library().entity(item.entityId)==null || item.mediaId!=null && db.library().get(item.mediaId)==null)throw new IllegalArgumentException("Identidad o archivo no disponible.");
    }
    public record Match(String wantId,String title,List<String> media,String state,String before) {}
    public record Review(List<Match> matches,String stamp) {}
    public Review review() {
        Map<String,List<String>> byCode=new HashMap<>();
        for(MediaEntry m:db.library().allMedia())if(!m.missing){String code=codeKey(m.details().getOrDefault("code",""));if(!code.isEmpty())byCode.computeIfAbsent(code,k->new ArrayList<>()).add(m.id);}
        List<Match> rows=new ArrayList<>();StringBuilder stamp=new StringBuilder();
        for(WantItem w:db.library().wants()) {
            if(w.state.equals("acquired") || w.code.isBlank())continue;List<String> ids=new ArrayList<>(byCode.getOrDefault(codeKey(w.code),List.of()));Collections.sort(ids);
            String state=ids.size()==1?"Coincidencia única":ids.isEmpty()?"Sin coincidencia":"Ambigua; elegir manualmente";
            String before=TrackingBackup.fingerprint(w).toString();rows.add(new Match(w.id,w.title,List.copyOf(ids),state,before));stamp.append(before).append(ids).append(state);
        }return new Review(List.copyOf(rows),stamp.toString());
    }
    public String acquire(Review plan) {
        return db.runInTransaction(()->{Review current=review();if(!current.stamp().equals(plan.stamp()))throw new IllegalArgumentException("Los deseos o códigos cambiaron. Revisa las coincidencias de nuevo.");String batch="local-review:"+UUID.randomUUID();
            for(Match row:current.matches())if(row.media().size()==1){WantItem w=require(row.wantId());w.priorState=w.state;w.state="acquired";w.mediaId=row.media().get(0);w.acquiredAt=Instant.now().toString();w.acquiredBatch=batch;touch(w);}return batch;
        });
    }
    public int revert(String batch) {
        if(!batch.startsWith("local-review:"))throw new IllegalArgumentException("Este lote no pertenece a una revisión local.");
        return db.runInTransaction(()->{int n=0;for(WantItem w:db.library().wants())if(w.acquiredBatch.equals(batch)){w.state=w.priorState;w.mediaId=null;w.acquiredAt="";w.acquiredBatch="";touch(w);n++;}return n;});
    }
}
