package com.peach.local;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Four pinned host/routing contracts. Safe manifest URLs never contain credentials. */
public final class WebSourceUrls {
    private WebSourceUrls(){}
    static final Set<String> PROVIDERS=Set.of("rule34paheal","rule34xxx","rule34video","f95zone");
    static String enc(String value){try{return URLEncoder.encode(value,"UTF-8").replace("+","%20");}catch(java.io.UnsupportedEncodingException impossible){throw new AssertionError(impossible);}}
    static String dec(String value){try{String out=URLDecoder.decode(value,"UTF-8");if(out.indexOf('\ufffd')>=0)throw new IllegalArgumentException("Codificación no válida.");return out;}catch(java.io.UnsupportedEncodingException impossible){throw new AssertionError(impossible);}}
    static Map<String,String> query(String raw){Map<String,String> out=new LinkedHashMap<>();if(raw==null)return out;for(String field:raw.split("&",-1)){String[] pair=field.split("=",2);if(pair.length!=2||out.put(dec(pair[0]),dec(pair[1]))!=null)throw new IllegalArgumentException("Parámetros no válidos.");}return out;}
    static URI url(String raw){URI u=SourceHttp.https(raw);if(u.getPort()!=-1)throw new IllegalArgumentException("URL no canónica.");return u;}
    static String id(String s){if(s==null||!s.matches("[1-9][0-9]{0,19}"))throw new IllegalArgumentException("ID de publicación no válido.");return s;}
    static String host(String provider){return switch(provider){case "rule34paheal"->"rule34.paheal.net";case "rule34xxx"->"rule34.xxx";case "rule34video"->"rule34video.com";case "f95zone"->"f95zone.to";default->throw new IllegalArgumentException("Proveedor no válido.");};}
    static String thread(String path){var m=java.util.regex.Pattern.compile("^/threads/(?:[A-Za-z0-9_-]+\\.)?([1-9][0-9]{0,11})/(?:latest|page-[1-9][0-9]{0,5}|post-[1-9][0-9]{0,19})?/?$").matcher(path);if(!m.matches())throw new IllegalArgumentException("Usa un hilo F95zone.");return m.group(1);}
    public static String creator(String provider,String raw){
        if(!PROVIDERS.contains(provider)||raw==null)throw new IllegalArgumentException("Falta referencia de fuente.");String value=raw.trim();
        if(value.startsWith("https://")){
            URI u=url(value);if(!host(provider).equals(u.getHost()))throw new IllegalArgumentException("Página de otra fuente.");String path=u.getRawPath();
            switch(provider){
                case "rule34xxx"->{var q=query(u.getRawQuery());if(!path.equals("/index.php")||!q.keySet().equals(Set.of("page","s","tags"))||!"post".equals(q.get("page"))||!"list".equals(q.get("s")))throw new IllegalArgumentException("Usa la búsqueda por etiqueta, sin clave en la URL.");value=q.get("tags");}
                case "rule34paheal"->{if(u.getRawQuery()!=null||!path.matches("/post/list/[^/]+/[1-9][0-9]{0,3}/?"))throw new IllegalArgumentException("Usa /post/list/etiqueta/1 o la etiqueta.");value=dec(path.split("/")[3]);}
                case "rule34video"->{if(u.getRawQuery()!=null||!path.matches("/models/[A-Za-z0-9_-]{1,81}/"))throw new IllegalArgumentException("Usa /models/autor/.");value=path.split("/")[2];}
                case "f95zone"->{if(u.getRawQuery()!=null)throw new IllegalArgumentException("Usa un hilo sin parámetros.");value=thread(path);}
            }
        }
        if(provider.equals("f95zone")){if(!value.matches("[1-9][0-9]{0,11}"))throw new IllegalArgumentException("Escribe el número o URL del hilo.");}
        else if(provider.equals("rule34video")){value=value.toLowerCase(Locale.ROOT);if(!value.matches("[a-z0-9][a-z0-9_-]{0,80}"))throw new IllegalArgumentException("Usa el autor de /models/autor/.");}
        else if(value.isBlank()||value.length()>100||value.chars().anyMatch(c->Character.isWhitespace(c)||Character.isISOControl(c))||value.matches(".*[&?#/%\\\\].*"))throw new IllegalArgumentException("Escribe una sola etiqueta, sin espacios o parámetros.");
        return value;
    }
    public static String page(String provider,String ref,int index){ref=creator(provider,ref);if(index<0||index>=5000||provider.equals("f95zone")&&index!=0)throw new IllegalArgumentException("Página fuera de límite.");return switch(provider){
        case "rule34paheal"->"https://rule34.paheal.net/post/list/"+enc(ref)+"/"+(index+1);
        case "rule34xxx"->"https://api.rule34.xxx/index.php?page=dapi&s=post&q=index&json=1&limit=24&pid="+index+"&tags="+enc(ref);
        case "rule34video"->"https://rule34video.com/models/"+ref+"/"+(index==0?"":"?mode=async&function=get_block&block_id=custom_list_videos_common_videos&sort_by=post_date&from="+String.format(Locale.ROOT,"%02d",index+1));
        case "f95zone"->"https://f95zone.to/threads/"+ref+"/latest";default->throw new IllegalArgumentException();};}
    static String authenticated(String ref,int index,SourceCredentials.ApiKey key){if(key==null)throw new IllegalArgumentException("Configura tu user_id y clave propia en Credenciales API. No se incluyen en las copias.");return page("rule34xxx",ref,index)+"&user_id="+key.userId()+"&api_key="+enc(key.key());}
    static void api(String raw){URI u=url(raw);var q=query(u.getRawQuery());if(!"api.rule34.xxx".equals(u.getHost())||!q.keySet().equals(Set.of("page","s","q","json","limit","pid","tags","user_id","api_key")))throw new IllegalArgumentException("API no admitida.");if(!raw.equals(authenticated(q.get("tags"),Integer.parseInt(q.get("pid")),new SourceCredentials.ApiKey(q.get("user_id"),q.get("api_key")))))throw new IllegalArgumentException("API no canónica.");}
    static String post(String provider,String ref,String id,String candidate){id(id);creator(provider,ref);if(provider.equals("rule34video")){URI u=url(candidate);if(!host(provider).equals(u.getHost())||u.getRawQuery()!=null||!u.getRawPath().matches("/video/"+id+"/[A-Za-z0-9_-]{1,180}/"))throw new IllegalArgumentException("Publicación ajena.");return candidate;}return switch(provider){case "rule34paheal"->"https://rule34.paheal.net/post/view/"+id;case "rule34xxx"->"https://rule34.xxx/index.php?page=post&s=view&id="+id;case "f95zone"->"https://f95zone.to/threads/"+ref+"/post-"+id;default->throw new IllegalArgumentException();};}
    static boolean html(String raw){try{return Set.of("rule34.paheal.net","rule34video.com","f95zone.to").contains(url(raw).getHost());}catch(IllegalArgumentException e){return false;}}
    static void validateHtml(String raw){URI u=url(raw);String p=u.getRawPath();switch(u.getHost()){
        case "f95zone.to"->{thread(p);if(u.getRawQuery()!=null)throw new IllegalArgumentException();}
        case "rule34.paheal.net"->{if(u.getRawQuery()!=null)throw new IllegalArgumentException();if(p.matches("/post/view/[1-9][0-9]{0,19}"))return;if(!p.matches("/post/list/[^/]+/[1-9][0-9]{0,3}"))throw new IllegalArgumentException();if(!raw.equals(page("rule34paheal",creator("rule34paheal",raw),Integer.parseInt(p.substring(p.lastIndexOf('/')+1))-1)))throw new IllegalArgumentException();}
        case "rule34video.com"->{if(p.matches("/models/[a-z0-9][a-z0-9_-]{0,80}/")){var q=query(u.getRawQuery());int i=q.isEmpty()?0:Integer.parseInt(q.getOrDefault("from","0"))-1;if(!raw.equals(page("rule34video",p.split("/")[2],i)))throw new IllegalArgumentException();}else{String[] parts=p.split("/");if(parts.length!=4)throw new IllegalArgumentException();post("rule34video","own",parts[2],raw);}}
        default->throw new IllegalArgumentException("Página no admitida.");
    }}
    static String redirect(String original,String next){URI a=url(original),b=url(next);if(!a.getHost().equals(b.getHost()))throw new IllegalArgumentException("Redirección fuera de la fuente.");if(a.getHost().equals("f95zone.to")){if(b.getRawQuery()!=null||!thread(a.getRawPath()).equals(thread(b.getRawPath())))throw new IllegalArgumentException("Otro hilo.");}else{if(!original.equals(next))throw new IllegalArgumentException("Redirección no incorporada.");validateHtml(next);}return next;}
    static String cleanRedirect(String original,String next){if(url(original).getHost().equals("f95zone.to")){URI u=URI.create(next);if(u.getRawFragment()!=null&&u.getRawFragment().matches("post-[1-9][0-9]{0,19}"))return next.substring(0,next.indexOf('#'));}return next;}
    static boolean publicDownloadQuery(String raw){
        if(raw.length()>2048)return false;Map<String,String> q=query(raw);
        if(q.size()>12||!"true".equals(q.get("download")))return false;
        for(var entry:q.entrySet())if(!entry.getKey().matches("[A-Za-z][A-Za-z0-9_-]{0,39}")||Set.of("api_key","user_id","password","cookie","authorization","key","url","redirect","redirect_uri","callback").contains(entry.getKey().toLowerCase(Locale.ROOT))||entry.getValue().length()>1024||entry.getValue().chars().anyMatch(c->c<32||c==127))return false;
        return true;
    }
    public static boolean downloadable(String raw){try{URI u=url(raw);boolean video=Set.of("rule34video.com","boomio-cdn.com").contains(u.getHost());if(u.getRawQuery()!=null && !(video && publicDownloadQuery(u.getRawQuery())))return false;String p=u.getRawPath();if("api-cdn.rule34.xxx".equals(u.getHost()))return p.matches("/images/[0-9]{1,12}/[a-f0-9]{32}\\.(?:jpg|jpeg|png|gif|webp|mp4|webm)");if("attachments.f95zone.to".equals(u.getHost()))return !p.contains("..") && p.matches("/[A-Za-z0-9_./-]+\\.(?:png|jpg|jpeg|gif|webp|mp4|webm|zip|rar|7z|gz|pdf|epub|txt)");if(Set.of("rule34video.com","boomio-cdn.com").contains(u.getHost()))return p.startsWith("/get_file/") && !p.contains("..") && p.matches("/get_file/[0-9]{1,12}/[A-Za-z0-9_/-]+\\.(?:mp4|webm)/?");if("r34i.paheal-cdn.net".equals(u.getHost())){var m=java.util.regex.Pattern.compile("^/([a-f0-9]{2})/([a-f0-9]{2})/([a-f0-9]{32})$").matcher(p);return m.matches()&&m.group(3).startsWith(m.group(1)+m.group(2));}return false;}catch(IllegalArgumentException e){return false;}}
}
