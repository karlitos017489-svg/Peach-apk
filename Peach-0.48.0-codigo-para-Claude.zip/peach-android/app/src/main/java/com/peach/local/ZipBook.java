package com.peach.local;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.CRC32;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipFile;

/** Read-only ZIP index. Entry names never become filesystem output paths. */
public final class ZipBook implements ArchiveBook {
    public static final int MAX_ENTRIES=10000;
    public static final long MAX_ENTRY_BYTES=64L*1024*1024;
    private final ZipFile zip;
    private final List<Item> items;
    public ZipBook(File source) throws IOException {
        int count=ZipDirectory.check(source);zip=ZipFile.builder().setFile(source).setCharset(java.nio.charset.Charset.forName("IBM437")).setUseUnicodeExtraFields(false).get();
        try {
            List<Item> found=new ArrayList<>();Set<String> names=new HashSet<>();var entries=zip.getEntries();int seen=0;
            while(entries.hasMoreElements()) {
                if(++seen>count)throw new IOException("Índice ZIP no coherente.");
                ZipArchiveEntry entry=entries.nextElement();safeName(entry.getName());
                if(!names.add(entry.getName()))throw new IOException("ZIP con nombres duplicados.");
                if(!entry.isDirectory())found.add(new Item(entry.getName(),entry.getSize(),DocumentRules.entryKind(entry.getName())));
            }
            if(seen!=count)throw new IOException("Índice ZIP no coherente.");
            found.sort((a,b)->DocumentRules.naturalCompare(a.name(),b.name()));items=List.copyOf(found);
        }catch(IOException|RuntimeException error){zip.close();throw error;}
    }
    public List<Item> items(){return items;}
    public Item item(String name){return items.stream().filter(i->i.name().equals(name)).findFirst().orElse(null);}
    public File read(String name,File directory) throws IOException {
        Item item=item(name);if(item==null || item.kind().isEmpty())throw new IOException("Esta entrada se muestra en el índice, pero no tiene lector integrado.");return readRaw(name,directory,MAX_ENTRY_BYTES);
    }
    File readRaw(String name,File directory,long max)throws IOException {
        Item item=item(name);if(item==null || item.bytes()<0 || item.bytes()>max)throw new IOException("Entrada fuera del límite de lectura.");
        var entry=zip.getEntry(name);return ArchiveFiles.copy(checked(entry),directory,"entry",max,entry.getSize());
    }
    byte[] bytes(String name,int max)throws IOException {
        Item item=item(name);if(item==null || item.bytes()<0 || item.bytes()>max)throw new IOException("Entrada fuera del límite de metadatos.");
        try(var input=checked(zip.getEntry(name));var output=new java.io.ByteArrayOutputStream()){
            byte[] buffer=new byte[8192];int n;while((n=input.read(buffer))!=-1){if(Thread.currentThread().isInterrupted())throw new java.io.InterruptedIOException();if(n==0)throw new IOException("El recurso no devolvió datos.");if(output.size()+n>max)throw new IOException("Metadatos fuera del límite.");output.write(buffer,0,n);}return output.toByteArray();
        }
    }
    private java.io.InputStream checked(ZipArchiveEntry entry)throws IOException {
        return new java.io.FilterInputStream(zip.getInputStream(entry)){
            final CRC32 crc=new CRC32();long total;boolean verified;
            @Override public int read()throws IOException{byte[] b=new byte[1];return read(b,0,1)==-1?-1:b[0]&255;}
            @Override public int read(byte[] b,int off,int len)throws IOException{int n=in.read(b,off,len);if(n>=0){total+=n;crc.update(b,off,n);if(total>entry.getSize())throw new IOException("Entrada ZIP con tamaño no válido.");}else if(!verified){verified=true;if(total!=entry.getSize() || crc.getValue()!=entry.getCrc())throw new IOException("Entrada ZIP dañada (tamaño o CRC).");}return n;}
        };
    }
    static void safeName(String value) throws IOException {
        String name=value.replace('\\','/');
        if(name.isEmpty() || name.length()>4096 || name.startsWith("/") || name.matches("^[A-Za-z]:.*") || name.chars().anyMatch(c->c<32))throw new IOException("ZIP con nombre de entrada no admitido.");
        for(String part:name.split("/"))if(part.equals("..") || part.equals("."))throw new IOException("ZIP con ruta de entrada no admitida.");
    }
    @Override public void close() throws IOException{zip.close();}
}
