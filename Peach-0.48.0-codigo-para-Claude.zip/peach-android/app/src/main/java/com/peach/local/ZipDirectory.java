package com.peach.local;

import java.io.*;

/** Bounds the ZIP/ZIP64 directory before the platform ZipFile allocates its index. */
final class ZipDirectory {
    private ZipDirectory() {}
    static int check(File source)throws IOException {
        try(RandomAccessFile f=new RandomAccessFile(source,"r")) {
            long length=f.length();if(length<22 || length>ReaderSession.MAX_SOURCE_BYTES)throw bad();
            int n=(int)Math.min(length,65557);byte[] tail=new byte[n];f.seek(length-n);f.readFully(tail);
            for(int p=n-22;p>=0;p--)if(u32(tail,p)==0x06054b50L && p+22+u16(tail,p+20)==n) {
                long end=length-n+p,count=u16(tail,p+10),size=u32(tail,p+12),offset=u32(tail,p+16),boundary=end;
                if(u16(tail,p+4)!=0 || u16(tail,p+6)!=0 || u16(tail,p+8)!=count)throw split();
                boolean sentinel=count==65535 || size==0xffffffffL || offset==0xffffffffL;
                byte[] locator=null;
                if(end>=20){f.seek(end-20);byte[] b=new byte[20];f.readFully(b);if(u32(b,0)==0x07064b50L)locator=b;}
                if(locator!=null) {
                    if(u32(locator,4)!=0 || u32(locator,16)!=1)throw split();
                    long at=u64(locator,8);if(at>end-20-56)throw bad();
                    byte[] b=new byte[56];f.seek(at);f.readFully(b);
                    long record=u64(b,4);if(u32(b,0)!=0x06064b50L || record<44 || record>1024 || at+12+record!=end-20)throw bad();
                    if(u32(b,16)!=0 || u32(b,20)!=0 || u64(b,24)!=u64(b,32))throw split();
                    long c=u64(b,32),s=u64(b,40),o=u64(b,48);
                    if(count!=65535 && count!=c || size!=0xffffffffL && size!=s || offset!=0xffffffffL && offset!=o)throw bad();
                    count=c;size=s;offset=o;boundary=at;
                }else if(sentinel)throw bad();
                if(count>ZipBook.MAX_ENTRIES || size>16L*1024*1024 || offset>boundary || size!=boundary-offset)throw bad();
                long cursor=offset;
                for(int i=0;i<count;i++) {
                    ArchiveFiles.check(Long.MAX_VALUE);if(cursor>boundary-46)throw bad();
                    byte[] b=new byte[46];f.seek(cursor);f.readFully(b);if(u32(b,0)!=0x02014b50L)throw bad();
                    int name=u16(b,28),extra=u16(b,30),comment=u16(b,32);long next=cursor+46+name+extra+comment;
                    if(name<1 || name>4096 || next>boundary)throw bad();
                    // Only store/deflate are provided by the platform. Encrypted and unsupported
                    // methods are rejected explicitly rather than advertised as a readable entry.
                    int flags=u16(b,8),method=u16(b,10);
                    if((flags&0x2041)!=0)throw new IOException("ZIP cifrado: este lector no admite contraseñas ZIP.");
                    if(method!=0 && method!=8)throw new IOException("Método ZIP no admitido; usa almacenar o Deflate.");
                    if((flags&~0x080e)!=0)throw bad();
                    long unpacked=u32(b,24),packed=u32(b,20),local=u32(b,42),disk=u16(b,34);
                    f.skipBytes(name);byte[] fields=new byte[extra];f.readFully(fields);boolean zip64=false;
                    for(int q=0;q<extra;) {
                        if(q>extra-4)throw bad();int id=u16(fields,q),len=u16(fields,q+2);q+=4;if(len>extra-q)throw bad();
                        if(id==1) {
                            if(zip64)throw bad();zip64=true;int a=q,stop=q+len;
                            if(unpacked==0xffffffffL){if(a>stop-8)throw bad();unpacked=u64(fields,a);a+=8;}
                            if(packed==0xffffffffL){if(a>stop-8)throw bad();packed=u64(fields,a);a+=8;}
                            if(local==0xffffffffL){if(a>stop-8)throw bad();local=u64(fields,a);a+=8;}
                            if(disk==65535){if(a>stop-4)throw bad();disk=u32(fields,a);}
                        }
                        q+=len;
                    }
                    if(disk!=0)throw split();
                    if(unpacked==0xffffffffL || packed==0xffffffffL || local==0xffffffffL || local>offset-30 || packed>offset-local-30)throw bad();
                    cursor=next;
                }
                if(cursor!=boundary)throw bad();return (int)count;
            }
            throw bad();
        }
    }
    static int u16(byte[] b,int p){return (b[p]&255)|((b[p+1]&255)<<8);}
    static long u32(byte[] b,int p){return (b[p]&255L)|((b[p+1]&255L)<<8)|((b[p+2]&255L)<<16)|((b[p+3]&255L)<<24);}
    static long u64(byte[] b,int p)throws IOException{long lo=u32(b,p),hi=u32(b,p+4);if(hi>0x7fffffffL)throw bad();return lo|(hi<<32);}
    private static IOException bad(){return new IOException("Índice ZIP/ZIP64 dañado o fuera de límites: 512 MiB, 10.000 entradas y 16 MiB de índice.");}
    private static IOException split(){return new IOException("ZIP dividido en varios volúmenes no admitido.");}
}
