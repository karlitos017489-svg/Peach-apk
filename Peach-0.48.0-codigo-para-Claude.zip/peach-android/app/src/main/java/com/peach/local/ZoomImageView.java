package com.peach.local;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import androidx.appcompat.widget.AppCompatImageView;

public final class ZoomImageView extends AppCompatImageView {
    private final Matrix transform=new Matrix();
    private float zoom=1;
    private final ScaleGestureDetector scales;
    private final GestureDetector gestures;
    public ZoomImageView(Context context,AttributeSet attributes) {
        super(context,attributes);setScaleType(ScaleType.MATRIX);
        scales=new ScaleGestureDetector(context,new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector detector) {scale(detector.getScaleFactor(),detector.getFocusX(),detector.getFocusY());return true;}
        });
        gestures=new GestureDetector(context,new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent event) {return true;}
            @Override public boolean onSingleTapUp(MotionEvent event) {performClick();return true;}
            @Override public boolean onDoubleTap(MotionEvent event) {if(zoom>1.1f) resetZoom();else scale(2,event.getX(),event.getY());return true;}
            @Override public boolean onScroll(MotionEvent first,MotionEvent current,float dx,float dy) {
                if (zoom>1 && !scales.isInProgress()) {transform.postTranslate(-dx,-dy);clamp();setImageMatrix(transform);}return true;
            }
        });
    }
    @Override public void setImageBitmap(Bitmap bitmap) {super.setImageBitmap(bitmap);if(transform!=null) resetZoom();}
    @Override protected void onSizeChanged(int w,int h,int oldw,int oldh) {super.onSizeChanged(w,h,oldw,oldh);resetZoom();}
    public void resetZoom() {
        transform.reset();zoom=1;
        if (getDrawable()!=null && getWidth()>0 && getHeight()>0) {
            int width=getDrawable().getIntrinsicWidth(),height=getDrawable().getIntrinsicHeight();
            if (width>0 && height>0) {
                float fit=Math.min((float)getWidth()/width,(float)getHeight()/height);
                transform.postScale(fit,fit);transform.postTranslate((getWidth()-width*fit)/2,(getHeight()-height*fit)/2);
            }
        }
        setImageMatrix(transform);
    }
    public void zoomBy(float factor) {scale(factor,getWidth()/2f,getHeight()/2f);}
    float zoomFactor() {return zoom;}
    private void scale(float factor,float x,float y) {
        if (getDrawable()==null || !Float.isFinite(factor) || factor<=0) return;
        float next=Math.max(1,Math.min(6,zoom*factor));transform.postScale(next/zoom,next/zoom,x,y);zoom=next;
        clamp();setImageMatrix(transform);
    }
    private void clamp() {
        if (getDrawable()==null) return;
        RectF bounds=new RectF(0,0,getDrawable().getIntrinsicWidth(),getDrawable().getIntrinsicHeight());transform.mapRect(bounds);
        float dx=bounds.width()<=getWidth()?(getWidth()-bounds.width())/2-bounds.left:bounds.left>0?-bounds.left:bounds.right<getWidth()?getWidth()-bounds.right:0;
        float dy=bounds.height()<=getHeight()?(getHeight()-bounds.height())/2-bounds.top:bounds.top>0?-bounds.top:bounds.bottom<getHeight()?getHeight()-bounds.bottom:0;
        transform.postTranslate(dx,dy);
    }
    @Override public boolean onTouchEvent(MotionEvent event) {scales.onTouchEvent(event);gestures.onTouchEvent(event);return true;}
    @Override public boolean performClick() {super.performClick();return true;}
}
