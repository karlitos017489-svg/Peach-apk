package com.peach.local;

import androidx.room.Room;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class AgencyStoreTest {
    LibraryDatabase db;EntityStore entities;AgencyStore store;String ana,luz,agency,other;
    @Before public void open(){db=Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().build();entities=new EntityStore(db);store=new AgencyStore(db);ana=entities.create("performer","Ana","");luz=entities.create("creator","Luz","");agency=entities.create("agency","Campo","");other=entities.create("agency","Otra","");}
    @After public void close(){db.close();}
    void media(String id,String actors){MediaEntry m=new MediaEntry();m.id=id;m.root="root";m.name=id+".mp4";m.title=id;m.actors=actors;db.library().insertMedia(m);}
    List<MediaEntry> selected(String id){return EntityIndex.select(db.library(),db.library().allMedia(),id);}
    JSONObject export()throws Exception{var out=new ByteArrayOutputStream();BackupStore.write(db.library(),out);return new JSONObject(out.toString("UTF-8"));}
    void restore(JSONObject json)throws Exception{BackupStore.read(db,new ByteArrayInputStream(json.toString().getBytes(StandardCharsets.UTF_8)));}
    static JSONObject catalog()throws Exception{JSONObject json=CatalogFixture.json(),tables=json.getJSONObject("tables");tables.getJSONArray("entity").put(CatalogFixture.row("id",12,"kind","agency","canonical_name","Agencia importada"));tables.getJSONArray("entity_membership").put(CatalogFixture.row("member_id",11,"agency_id",12,"source","official","confidence",0.7,"checked_at","2026-10-24"));return json;}
    CatalogBridge.Plan preview(JSONObject json)throws Exception{LibraryRoot root=new LibraryRoot();root.uri="root";root.state=0;db.library().addRoot(root);return CatalogBridge.preview(db.library(),CatalogTransfer.validate(json),new CatalogBridge.Options("Importado","R:/Media","root"));}
    @Test public void oneCurrentAgencyReassignmentAndRemovalPreserveDocumentState()throws Exception {
        media("a","Ana");db.library().restoreState("a",true,true,7000,90000,1,3);store.assign(ana,agency);store.assign(luz,agency);assertEquals(2,db.library().memberships().size());store.assign(ana,other);assertEquals(2,db.library().memberships().size());assertEquals(other,db.library().membership(ana).agencyId);assertEquals("manual",db.library().membership(ana).origin);assertFalse(db.library().membership(ana).checkedAt.isBlank());store.remove(ana);assertNull(db.library().membership(ana));assertTrue(db.library().get("a").favorite);assertEquals(7000,db.library().get("a").position);
    }
    @Test public void invalidKindsCyclesAndDirectAgencyFileLinksAreRejected()throws Exception {
        media("a","");String studio=entities.create("studio","Estudio","");CatalogTransferTest.rejects(()->store.assign(studio,agency));CatalogTransferTest.rejects(()->store.assign(ana,luz));CatalogTransferTest.rejects(()->store.assign(agency,other));CatalogTransferTest.rejects(()->store.assign(agency,agency));CatalogTransferTest.rejects(()->entities.link(agency,"a","agency"));assertTrue(db.library().memberships().isEmpty());assertTrue(db.library().entityLinks().isEmpty());
    }
    @Test public void agencyUnionCountsFilesOnceAndExcludesCoStarsOutsideItsRoster()throws Exception {
        media("shared","Ana, Bea");media("luz","");media("bea","Bea");String bea=entities.create("performer","Bea","");entities.alias(ana,"Alba");media("alias","Alba");entities.link(luz,"shared","creator");entities.link(luz,"luz","artist");store.assign(ana,agency);store.assign(luz,agency);
        assertEquals(Set.of("shared","luz","alias"),new HashSet<>(selected(agency).stream().map(m->m.id).toList()));assertEquals(2,db.library().memberships().size());store.assign(ana,other);assertEquals(Set.of("shared","luz"),new HashSet<>(selected(agency).stream().map(m->m.id).toList()));assertEquals(Set.of("shared","alias"),new HashSet<>(selected(other).stream().map(m->m.id).toList()));
    }
    @Test public void deleteCascadesMembershipOnlyAndRenamingPreservesUuidRelations()throws Exception {
        media("a","Ana");store.assign(ana,agency);entities.edit(agency,"Campo nuevo","");assertEquals(1,selected(agency).size());db.library().deleteEntity(agency);assertNull(db.library().membership(ana));assertNotNull(db.library().entity(ana));assertNotNull(db.library().get("a"));store.assign(ana,other);db.library().deleteEntity(ana);assertTrue(db.library().memberships().isEmpty());assertNotNull(db.library().entity(other));assertNotNull(db.library().get("a"));
    }
    @Test public void backupV7RoundTripsAndOldV6PreservesAffiliations()throws Exception {
        store.assign(ana,agency);JSONObject copy=export();assertEquals(19,copy.getInt("version"));store.assign(ana,other);restore(copy);assertEquals(agency,db.library().membership(ana).agencyId);JSONObject old=new JSONObject(copy.toString()).put("version",6);old.remove("memberships");store.assign(ana,other);restore(old);assertEquals(other,db.library().membership(ana).agencyId);
        JSONObject clear=new JSONObject(copy.toString()).put("memberships",new JSONArray());restore(clear);assertNull(db.library().membership(ana));
    }
    @Test public void malformedAffiliationsRollbackPersonalDataAndExistingMembership()throws Exception {
        media("a","");store.assign(ana,agency);JSONObject copy=export();copy.getJSONArray("items").getJSONObject(0).put("favorite",true);copy.getJSONArray("memberships").getJSONObject(0).put("agencyId",luz);CatalogTransferTest.rejects(()->restore(copy));assertFalse(db.library().get("a").favorite);assertEquals(agency,db.library().membership(ana).agencyId);
        for(Object confidence:new Object[]{"0.7",-0.1,1.1}){JSONObject invalid=export();invalid.getJSONArray("memberships").getJSONObject(0).put("confidence",confidence);CatalogTransferTest.rejects(()->restore(invalid));}
        JSONObject duplicate=export();duplicate.getJSONArray("memberships").put(duplicate.getJSONArray("memberships").getJSONObject(0));CatalogTransferTest.rejects(()->restore(duplicate));
    }
    @Test public void importsAgenciesAndProvenanceButPreservesAnExistingDifferentAffiliation()throws Exception {
        db.library().deleteEntity(ana);var plan=preview(catalog());assertEquals("Nueva",plan.affiliations.get(0).state());CatalogBridge.apply(db,plan);String member=CatalogBridge.key("Importado","entity","11"),importedAgency=CatalogBridge.key("Importado","entity","12");EntityMembership row=db.library().membership(member);assertEquals(importedAgency,row.agencyId);assertEquals("official",row.source);assertEquals(0.7,row.confidence,0);assertEquals("2026-10-24",row.checkedAt);store.assign(member,other);
        plan=preview(catalog());assertEquals("Conflicto",plan.affiliations.get(0).state());CatalogBridge.apply(db,plan);assertEquals(other,db.library().membership(member).agencyId);
    }
    @Test public void staleAffiliationPreviewCannotPartiallyWriteAnImport()throws Exception {
        db.library().deleteEntity(ana);CatalogBridge.apply(db,preview(catalog()));String member=CatalogBridge.key("Importado","entity","11");store.remove(member);var plan=preview(catalog());assertEquals("Nueva",plan.affiliations.get(0).state());store.assign(member,other);CatalogTransferTest.rejects(()->CatalogBridge.apply(db,plan));assertEquals(other,db.library().membership(member).agencyId);
    }
    @Test public void legacyTransferOmitsMembershipTableAndMalformedReferencesAreRejected()throws Exception {
        JSONObject old=catalog();old.getJSONObject("tables").remove("entity_membership");assertEquals(0,CatalogTransfer.validate(old).json().getJSONObject("tables").getJSONArray("entity_membership").length());
        JSONObject missing=catalog();missing.getJSONObject("tables").getJSONArray("entity_membership").getJSONObject(0).put("agency_id",999);CatalogTransferTest.rejects(()->CatalogTransfer.validate(missing));JSONObject duplicate=catalog();var a=duplicate.getJSONObject("tables").getJSONArray("entity_membership");a.put(a.getJSONObject(0));CatalogTransferTest.rejects(()->CatalogTransfer.validate(duplicate));
        JSONObject invalid=catalog();invalid.getJSONObject("tables").put("entity_membership",JSONObject.NULL);CatalogTransferTest.rejects(()->CatalogTransfer.validate(invalid));
    }
    @Test public void incompatibleMembershipIsRetainedAsDataAndSnapshotOnlyDoesNotCreateGraph()throws Exception {
        JSONObject json=catalog();json.getJSONObject("tables").getJSONArray("entity").getJSONObject(0).put("kind","studio");var plan=preview(json);assertEquals("Tipo no compatible",plan.affiliations.get(0).state());CatalogBridge.apply(db,plan);assertTrue(db.library().memberships().isEmpty());assertTrue(db.library().snapshots().get(0).payload.contains("entity_membership"));
        var snapshotOnly=CatalogBridge.preview(db.library(),CatalogTransfer.validate(catalog()),new CatalogBridge.Options("Solo","",""));assertEquals("Solo catálogo",snapshotOnly.affiliations.get(0).state());CatalogBridge.apply(db,snapshotOnly);assertTrue(db.library().memberships().isEmpty());
    }
    @Test public void largeRosterWithSeveralAliasesStillCountsASharedDocumentOnce()throws Exception {
        List<String> names=new ArrayList<>();db.runInTransaction(()->{for(int i=0;i<1000;i++){CatalogEntity e=new CatalogEntity();e.id="person-"+i;e.kind="performer";e.name="Persona "+i;db.library().insertEntity(e);for(int j=0;j<2;j++){EntityAlias alias=new EntityAlias();alias.entityId=e.id;alias.name="Alias "+i+" "+j;db.library().insertAlias(alias);if(j==1)names.add(alias.name);}EntityMembership m=new EntityMembership();m.memberId=e.id;m.agencyId=agency;m.checkedAt="2026-10-24";db.library().putMembership(m);}});
        media("shared",String.join(", ",names));assertEquals(1,selected(agency).size());assertEquals("shared",selected(agency).get(0).id);AgencyStore.validateAll(db.library());
    }
}
