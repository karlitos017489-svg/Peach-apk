package com.peach.local;

import android.os.Looper;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.room.Room;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowDialog;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land") @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class AgencyUiTest {
    LibraryDatabase db;
    @Before public void open(){var c=RuntimeEnvironment.getApplication();db=Room.inMemoryDatabaseBuilder(c,LibraryDatabase.class).allowMainThreadQueries().setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",db);androidx.work.testing.WorkManagerTestInitHelper.initializeTestWorkManager(c,new androidx.work.Configuration.Builder().setExecutor(Runnable::run).setTaskExecutor(Runnable::run).build());}
    @After public void close()throws Exception{idle();androidx.work.testing.WorkManagerTestInitHelper.closeWorkDatabase();db.close();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);}
    void idle()throws Exception{for(int i=0;i<3;i++){LibraryDatabase.IO.submit(()->{}).get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}}
    AlertDialog dialog(){Shadows.shadowOf(Looper.getMainLooper()).idle();return (AlertDialog)ShadowDialog.getLatestDialog();}
    View find(View view,java.util.function.Predicate<View> predicate){if(predicate.test(view))return view;if(view instanceof ViewGroup group)for(int i=0;i<group.getChildCount();i++){View found=find(group.getChildAt(i),predicate);if(found!=null)return found;}return null;}
    void customChoice(String name){ListView list=(ListView)find(dialog().getWindow().getDecorView(),v->v instanceof ListView);int match=-1;for(int i=0;i<list.getAdapter().getCount();i++)if(list.getAdapter().getItem(i).toString().contains(name))match=i;assertTrue(name,match>=0);list.performItemClick(null,match,match);}
    @Test public void agencySectionCreatesTheCorrectKindAndItsRosterCanAddAPerson()throws Exception {
        String person=new EntityStore(db).create("performer","Ana","");try(var controller=Robolectric.buildActivity(OrganizationActivity.class).setup().visible()) {
            var activity=controller.get();idle();Spinner sections=activity.findViewById(R.id.organizationSection);sections.setSelection(7);activity.findViewById(R.id.organizationCreate).performClick();EditText name=(EditText)find(dialog().getWindow().getDecorView(),v->v instanceof EditText e && "Nombre principal".contentEquals(e.getContentDescription()));name.setText("Campo");dialog().getButton(AlertDialog.BUTTON_POSITIVE).performClick();idle();CatalogEntity agency=db.library().entities().stream().filter(e->e.kind.equals("agency")).findFirst().orElseThrow();assertEquals("Campo",agency.name);
            ((ListView)activity.findViewById(R.id.organizationList)).performItemClick(null,0,0);dialog().getButton(AlertDialog.BUTTON_NEUTRAL).performClick();dialog().getListView().performItemClick(null,9,9);dialog().getButton(AlertDialog.BUTTON_POSITIVE).performClick();customChoice("Ana");idle();assertEquals(agency.id,db.library().membership(person).agencyId);assertEquals(1,dialog().getListView().getAdapter().getCount());
        }
    }
    @Test public void reassignmentUsesReviewAndPreservesTheOldAffiliationWhenCancelled()throws Exception {
        EntityStore entities=new EntityStore(db);String person=entities.create("performer","Ana",""),first=entities.create("agency","Campo",""),next=entities.create("agency","Otra","");new AgencyStore(db).assign(person,first);
        try(var controller=Robolectric.buildActivity(OrganizationActivity.class).setup().visible()) {
            var activity=controller.get();idle();((EditText)activity.findViewById(R.id.organizationSearch)).setText("Ana");((ListView)activity.findViewById(R.id.organizationList)).performItemClick(null,0,0);dialog().getButton(AlertDialog.BUTTON_NEUTRAL).performClick();dialog().getListView().performItemClick(null,9,9);dialog().getButton(AlertDialog.BUTTON_POSITIVE).performClick();customChoice("Otra");assertEquals(first,db.library().membership(person).agencyId);dialog().getButton(AlertDialog.BUTTON_NEGATIVE).performClick();assertEquals(first,db.library().membership(person).agencyId);
            ((ListView)activity.findViewById(R.id.organizationList)).performItemClick(null,0,0);dialog().getButton(AlertDialog.BUTTON_NEUTRAL).performClick();dialog().getListView().performItemClick(null,9,9);dialog().getButton(AlertDialog.BUTTON_POSITIVE).performClick();customChoice("Otra");dialog().getButton(AlertDialog.BUTTON_POSITIVE).performClick();idle();assertEquals(next,db.library().membership(person).agencyId);
        }
    }
    @Test public void agencyScopeUpdatesOnMembershipChangesAndSurvivesActivityRecreation()throws Exception {
        EntityStore store=new EntityStore(db);String person=store.create("performer","Ana",""),agency=store.create("agency","Campo","");MediaEntry media=new MediaEntry();media.id="a";media.title="Archivo";media.name="a.mp4";media.actors="Ana";db.library().insertMedia(media);new AgencyStore(db).assign(person,agency);
        var intent=new android.content.Intent(RuntimeEnvironment.getApplication(),MainActivity.class).putExtra("entityId",agency);try(var controller=Robolectric.buildActivity(MainActivity.class,intent).setup().visible()) {
            idle();var activity=controller.get();assertEquals(1,((androidx.recyclerview.widget.RecyclerView)activity.findViewById(R.id.grid)).getAdapter().getItemCount());controller.recreate();idle();activity=controller.get();assertTrue(((Button)activity.findViewById(R.id.scope)).getText().toString().contains("Campo"));LibraryDatabase.IO.submit(()->new AgencyStore(db).remove(person)).get(30,TimeUnit.SECONDS);idle();assertEquals(0,((androidx.recyclerview.widget.RecyclerView)activity.findViewById(R.id.grid)).getAdapter().getItemCount());
        }
    }
}
