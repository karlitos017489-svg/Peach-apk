package com.peach.local;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.apache.commons.compress.archivers.tar.*;
import org.junit.*;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

public class ArchiveBookTest {
    @Rule public TemporaryFolder temp=new TemporaryFolder();
    static byte[] fixture(String name)throws Exception{try(var in=ArchiveBookTest.class.getClassLoader().getResourceAsStream("archives150/"+name)){assertNotNull(in);return in.readAllBytes();}}
    File file(byte[] bytes)throws Exception{File f=temp.newFile();Files.write(f.toPath(),bytes);return f;}
    static String readString(java.nio.file.Path path)throws IOException{return new String(Files.readAllBytes(path),java.nio.charset.StandardCharsets.UTF_8);}
    File fixtureFile(String name)throws Exception{return file(fixture(name));}
    void rejectsTar(byte[] data)throws Exception{try(var book=new TarBook(file(data))){fail("Accepted invalid TAR");}catch(IOException expected){}}
    static byte[] gzip(byte[] bytes)throws Exception{var b=new ByteArrayOutputStream();try(var gz=new GZIPOutputStream(b)){gz.write(bytes);}return b.toByteArray();}
    @Test public void independentUstarFixtureIndexesNaturalOrderAndReadsOnlySelectedRegularFiles()throws Exception{
        File output=temp.newFolder();try(var book=new TarBook(fixtureFile("album.tar"))){
            assertEquals(List.of("alias.txt","fifo.txt","fotos/2.png","fotos/10.png","hard.txt","nested.tar","notes.txt","video.mp4"),book.items().stream().map(ArchiveBook.Item::name).toList());
            assertEquals(0,output.list().length);File read=book.read("notes.txt",output);assertTrue(readString(read.toPath()).startsWith("Texto propio"));assertEquals(List.of("entry"),List.of(output.list()));
            for(String name:List.of("alias.txt","hard.txt","fifo.txt","nested.tar","video.mp4")){assertEquals("",book.item(name).kind());try{book.read(name,output);fail();}catch(IOException expected){}}
            assertEquals("image",book.item("fotos/2.png").kind());
        }
    }
    @Test public void paxAndGnuLongUnicodeNamesAreAcceptedWithoutWritingPaths()throws Exception{
        for(String name:List.of("pax.tar","gnu.tar"))try(var book=new TarBook(fixtureFile(name))){assertEquals(1,book.items().size());String entry=book.items().get(0).name();assertTrue(entry.endsWith("ñ.txt"));assertTrue(entry.length()>100);File out=temp.newFolder();assertEquals("Documento largo",readString(book.read(entry,out).toPath()));assertEquals(List.of("entry"),List.of(out.list()));}
    }
    @Test public void unsafeDuplicateAndDamagedHeadersAreRejectedBeforeReadingContent()throws Exception{
        rejectsTar(fixture("traversal.tar"));rejectsTar(fixture("duplicates.tar"));byte[] bad=fixture("album.tar");bad[0]^=1;rejectsTar(bad);
        rejectsTar(Arrays.copyOf(fixture("album.tar"),600));rejectsTar(new byte[0]);
    }
    @Test public void missingEndMarkersTruncatedPayloadAndTrailingArchivesAreRejected()throws Exception{
        byte[] normal=fixture("pax.tar");int end=normal.length;while(end>=512 && allZero(normal,end-512))end-=512;rejectsTar(Arrays.copyOf(normal,end));
        byte[] tail=normal.clone();tail[tail.length-1]=1;rejectsTar(tail);
        var concat=new ByteArrayOutputStream();concat.write(normal);concat.write(normal);rejectsTar(concat.toByteArray());
    }
    static boolean allZero(byte[] b,int at){for(int i=at;i<at+512;i++)if(b[i]!=0)return false;return true;}
    static byte[] header(String name,int size,byte flag){TarArchiveEntry e=new TarArchiveEntry(name,flag);e.setSize(size);e.setModTime(0);byte[] h=new byte[512];e.writeEntryHeader(h);return h;}
    @Test public void extensionChainsMetadataBudgetsSparseAndPaxSizeOverridesAreRejected()throws Exception{
        var bytes=new ByteArrayOutputStream();bytes.write(header("meta",TarBook.MAX_METADATA+1,(byte)'x'));bytes.write(new byte[1024]);rejectsTar(bytes.toByteArray());
        bytes.reset();for(int i=0;i<9;i++)bytes.write(header("meta"+i,0,(byte)'x'));bytes.write(header("a.txt",0,(byte)'0'));bytes.write(new byte[1024]);rejectsTar(bytes.toByteArray());
        bytes.reset();bytes.write(header("sparse",0,(byte)'S'));bytes.write(new byte[1024]);rejectsTar(bytes.toByteArray());
        bytes.reset();byte[] pax="10 size=3\n".getBytes(java.nio.charset.StandardCharsets.US_ASCII);bytes.write(header("meta",pax.length,(byte)'x'));bytes.write(pax);bytes.write(new byte[512-pax.length]);bytes.write(header("a.txt",3,(byte)'0'));bytes.write(new byte[512+1024]);rejectsTar(bytes.toByteArray());
    }
    @Test public void declaredOversizedOrOutOfFileEntriesAndTooManyHeadersAreRejected()throws Exception{
        var bytes=new ByteArrayOutputStream();bytes.write(header("a.txt",1024,(byte)'0'));bytes.write(new byte[512]);rejectsTar(bytes.toByteArray());
        bytes.reset();for(int i=0;i<=ZipBook.MAX_ENTRIES;i++)bytes.write(header("f"+i,0,(byte)'0'));bytes.write(new byte[1024]);rejectsTar(bytes.toByteArray());
    }
    @Test public void tarGzipAndTgzUseSameIndexAndVerifyCrcBeforeExposingEntries()throws Exception{
        for(String name:List.of("album.tar.gz","album.TGZ")){File out=temp.newFolder();try(var book=ArchiveBook.open(fixtureFile("album.tar.gz"),name,out)){assertEquals(8,book.items().size());assertTrue(readString(book.read("notes.txt",out).toPath()).contains("Peach"));}}
        byte[] bad=fixture("album.tar.gz");bad[bad.length-8]^=1;File out=temp.newFolder();try(var book=ArchiveBook.open(file(bad),"a.tgz",out)){fail();}catch(IOException expected){}assertEquals(0,out.list().length);
    }
    @Test public void simpleGzipUsesOuterNameAndOnlyReadsCompatibleContent()throws Exception{
        File out=temp.newFolder();byte[] bytes=gzip("Texto comprimido".getBytes());try(var book=ArchiveBook.open(file(bytes),"notas.txt.gz",out)){assertEquals("notas.txt",book.items().get(0).name());assertEquals("Texto comprimido",readString(book.read("notas.txt",out).toPath()));}
        try(var book=ArchiveBook.open(file(bytes),"video.mp4.gz",temp.newFolder())){assertEquals("",book.items().get(0).kind());try{book.read("video.mp4",temp.newFolder());fail();}catch(IOException expected){}}
        assertEquals("",DocumentRules.entryKind("a.gz"));assertEquals("",DocumentRules.entryKind("a.tar"));assertEquals(MediaRules.ARCHIVE,MediaRules.type("a.tgz"));assertTrue(DocumentRules.readable("a.TAR.GZ"));
    }
    @Test public void concatenatedGzipMembersAreOneStreamAndCorruptOrInvalidStreamsCleanParts()throws Exception{
        var bytes=new ByteArrayOutputStream();bytes.write(gzip("uno".getBytes()));bytes.write(gzip("dos".getBytes()));File out=temp.newFolder();try(var book=ArchiveBook.open(file(bytes.toByteArray()),"a.txt.gz",out)){assertEquals("unodos",readString(book.read("a.txt",out).toPath()));}
        for(byte[] bad:List.of(new byte[]{1,2,3},Arrays.copyOf(gzip("abc".getBytes()),12))){File target=temp.newFolder();try(var book=ArchiveBook.open(file(bad),"a.txt.gz",target)){fail();}catch(IOException expected){}assertEquals(0,target.list().length);}
    }
    @Test public void boundedGzipExpansionDoesNotPublishPartialOutput()throws Exception{
        File compressed=temp.newFile();try(var gz=new GZIPOutputStream(new FileOutputStream(compressed))){byte[] block=new byte[1024*1024];for(int i=0;i<65;i++)gz.write(block);}
        File out=temp.newFolder();try(var book=ArchiveBook.open(compressed,"big.txt.gz",out)){fail();}catch(IOException expected){}assertEquals(0,out.list().length);
    }
    @Test public void cancellationPreservesExistingEntryAndRemovesIncompleteTemporary()throws Exception{
        File out=temp.newFolder();Files.write(new File(out,"entry").toPath(),"anterior".getBytes(java.nio.charset.StandardCharsets.UTF_8));Thread.currentThread().interrupt();
        try(var book=new TarBook(fixtureFile("album.tar"))){fail();}catch(InterruptedIOException expected){}finally{Thread.interrupted();}
        try{ArchiveFiles.copy(new ByteArrayInputStream(new byte[]{1,2,3}),out,"entry",2,-1);fail();}catch(IOException expected){}assertEquals("anterior",readString(new File(out,"entry").toPath()));assertFalse(new File(out,"entry-part").exists());
    }
    @Test public void relativeRootPrefixIsCompatibleButAliasesAndAbsoluteNamesAreRejected()throws Exception {
        var bytes=new ByteArrayOutputStream();bytes.write(header("./",0,(byte)'5'));bytes.write(header("./notes.txt",3,(byte)'0'));bytes.write("abc".getBytes());bytes.write(new byte[509+1024]);
        try(var book=new TarBook(file(bytes.toByteArray()))){assertEquals("notes.txt",book.items().get(0).name());assertEquals("abc",readString(book.read("notes.txt",temp.newFolder()).toPath()));}
        for(String name:List.of("/absolute.txt","C:\\absolute.txt","a/../escape.txt","a/./b.txt")) {
            bytes.reset();byte[] h=header("placeholder",0,(byte)'0');java.util.Arrays.fill(h,0,100,(byte)0);byte[] raw=name.getBytes(java.nio.charset.StandardCharsets.UTF_8);System.arraycopy(raw,0,h,0,raw.length);java.util.Arrays.fill(h,148,156,(byte)' ');long sum=0;for(byte value:h)sum+=value&255;TarUtils.formatCheckSumOctalBytes(sum,h,148,8);bytes.write(h);bytes.write(new byte[1024]);rejectsTar(bytes.toByteArray());
        }
        bytes.reset();bytes.write(header("./same.txt",0,(byte)'0'));bytes.write(header("same.txt",0,(byte)'0'));bytes.write(new byte[1024]);rejectsTar(bytes.toByteArray());
    }
    @Test public void gzipHeaderFilenameCannotChooseAnOutputPath()throws Exception {
        byte[] standard=gzip("abc".getBytes());standard[3]=8;var bytes=new ByteArrayOutputStream();bytes.write(standard,0,10);bytes.write("../../outside.txt".getBytes());bytes.write(0);bytes.write(standard,10,standard.length-10);File out=temp.newFolder();try(var book=ArchiveBook.open(file(bytes.toByteArray()),"safe.txt.gz",out)){assertEquals("safe.txt",book.items().get(0).name());assertEquals("abc",readString(book.read("safe.txt",out).toPath()));assertEquals(Set.of("entry","unpacked"),new HashSet<>(List.of(out.list())));}
    }

}
