package com.peach.local;

import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.util.ParsableByteArray;
import androidx.media3.extractor.*;
import androidx.media3.extractor.wav.WavExtractor;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,manifest=Config.NONE)
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public class AudioExtractorTest {
    private DefaultExtractorInput input(byte[] bytes,int offset) {
        ByteArrayInputStream stream=new ByteArrayInputStream(bytes,offset,bytes.length-offset);
        return new DefaultExtractorInput(stream::read,offset,bytes.length);
    }
    @Test public void media3ParsesActualWavSamplesFormatAndSeekMap() throws Exception {
        byte[] wav;try(var stream=getClass().getClassLoader().getResourceAsStream("media/tone.wav")){assertNotNull(stream);wav=stream.readAllBytes();}
        WavExtractor extractor=new WavExtractor();Capture capture=new Capture();extractor.init(capture);
        DefaultExtractorInput input=input(wav,0);assertTrue(extractor.sniff(input));input.resetPeekPosition();
        PositionHolder seek=new PositionHolder();int result=Extractor.RESULT_CONTINUE,iterations=0;
        try {
            while(result!=Extractor.RESULT_END_OF_INPUT && iterations++<1000) {
                result=extractor.read(input,seek);
                if(result==Extractor.RESULT_SEEK)input=input(wav,Math.toIntExact(seek.position));
            }
            assertEquals(Extractor.RESULT_END_OF_INPUT,result);assertNotNull(capture.format);assertNotNull(capture.seekMap);
            assertEquals("audio/raw",capture.format.sampleMimeType);assertEquals(8000,capture.format.sampleRate);
            assertEquals(1,capture.format.channelCount);assertEquals(C.ENCODING_PCM_16BIT,capture.format.pcmEncoding);
            assertEquals(16000,capture.bytes);assertTrue(capture.samples>0);assertTrue(capture.seekMap.isSeekable());
            assertEquals(1000000,capture.seekMap.getDurationUs());
        }finally{extractor.release();}
    }
    private static class Capture implements ExtractorOutput,TrackOutput {
        Format format;SeekMap seekMap;int bytes,samples;
        @Override public TrackOutput track(int id,int type){assertEquals(C.TRACK_TYPE_AUDIO,type);return this;}
        @Override public void endTracks(){}
        @Override public void seekMap(SeekMap value){seekMap=value;}
        @Override public void format(Format value){format=value;}
        @Override public int sampleData(androidx.media3.common.DataReader input,int length,boolean allowEnd,int part) throws IOException {
            byte[] buffer=new byte[Math.min(length,4096)];int n=input.read(buffer,0,buffer.length);if(n>0)bytes+=n;return n;
        }
        @Override public void sampleData(ParsableByteArray data,int length,int part){data.skipBytes(length);bytes+=length;}
        @Override public void sampleMetadata(long time,int flags,int size,int offset,TrackOutput.CryptoData crypto){samples++;}
    }
}
