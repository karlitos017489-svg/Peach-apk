package com.peach.local;

import android.os.Bundle;
import androidx.media3.common.PlaybackException;
import androidx.media3.session.*;
import org.junit.Test;
import static org.junit.Assert.*;

/** Real session/controller protocol over the existing deterministic Player, not physical output. */
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public class AudioHistoryTest extends AudioTestSupport {
    @Test public void reconnectAndReselectDoNotDuplicateAndPauseSavesHistory()throws Exception{await(service.select(AudioSelectionTest.args("a")));idle();MediaController c=controller();service.engine.position(6000);c.pause();idle();await(service.select(AudioSelectionTest.args("a")));controller();idle();assertEquals(1,db.library().usageCount());assertEquals(6000,db.library().usageBackup(1).get(0).position);assertEquals("paused",db.library().usageBackup(1).get(0).status);}
    @Test public void automaticTrackChangeMarksPriorFinalAndStartsAnotherVisit()throws Exception{await(service.select(AudioSelectionTest.args("a")));idle();service.engine.automaticNext();idle();assertEquals(2,db.library().usageCount());UsageSession a=db.library().usageBackup(10).stream().filter(s->s.mediaId.equals("a")).findFirst().orElseThrow();assertTrue(a.completed);assertEquals("ended",a.status);}
    @Test public void stopAndClearingHistoryDoNotResurrectCurrentTrack()throws Exception{await(service.select(AudioSelectionTest.args("a")));idle();MediaController c=controller();db.library().clearUsage();service.engine.position(7000);c.pause();idle();await(c.sendCustomCommand(AudioService.STOP,Bundle.EMPTY));idle();assertEquals(0,db.library().usageCount());assertEquals(7000,db.library().get("a").position);}
}
