package com.peach.local;

import androidx.media3.common.Player;
import java.time.Duration;
import java.util.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.Shadows;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE)
public class AudioProgressTest {
    FakeAudioPlayer player;AudioProgress progress;List<AudioProgress.Position> saved;List<String> played;
    @Before public void open(){player=new FakeAudioPlayer();saved=new ArrayList<>();played=new ArrayList<>();progress=new AudioProgress(player,saved::add,played::add);List<MediaEntry> rows=new ArrayList<>();for(String id:List.of("a","b")){MediaEntry row=new MediaEntry();row.id=id;row.uri="content://fixture/"+id;row.mediaType=MediaRules.AUDIO;rows.add(row);}progress.replace(rows);player.setMediaItems(new AudioSelection.Queue(rows,0,0).items(),0,0);player.prepare();}
    @After public void close(){progress.close();player.release();}
    AudioProgress.Position last(String id){return saved.stream().filter(p->p.id().equals(id)).reduce((a,b)->b).orElseThrow();}
    @Test public void readyPauseAndRepeatedPlayDoNotDoubleCountButChangingTracksDoes(){assertEquals(List.of("a"),played);player.play();player.pause();player.play();assertEquals(List.of("a"),played);player.seekToNextMediaItem();assertEquals(List.of("a","b"),played);player.seekToPreviousMediaItem();assertEquals(List.of("a","b","a"),played);}
    @Test public void checkpointRunsWhilePlayingAndPausePersistsLatestPosition(){player.play();player.position(6500);Shadows.shadowOf(android.os.Looper.getMainLooper()).idleFor(Duration.ofSeconds(5));assertTrue(last("a").position()>=6500);assertEquals(20000,last("a").duration());player.pause();int size=saved.size();Shadows.shadowOf(android.os.Looper.getMainLooper()).idleFor(Duration.ofSeconds(10));assertEquals(size,saved.size());}
    @Test public void completionResetsPositionAndSurvivesQueueClearWithoutOverwritingLastGoodValue(){player.play();player.ended();assertEquals(0,last("a").position());assertTrue(last("a").watched());progress.replace(List.of());player.stop();player.clearMediaItems();assertEquals(0,last("a").position());assertTrue(last("a").watched());}
    @Test public void changingTrackSavesPreviousPositionAndDuration(){player.position(7500);player.seekToNextMediaItem();assertTrue(last("a").position()>=7500);assertEquals(20000,last("a").duration());assertEquals("b",played.get(played.size()-1));}
    @Test public void decoderFailureKeepsProgressAndCloseIsIdempotentAndStopsCallbacks(){player.play();player.position(8000);player.failure();assertTrue(last("a").position()>=8000);progress.close();int n=saved.size();progress.close();Shadows.shadowOf(android.os.Looper.getMainLooper()).idleFor(Duration.ofSeconds(10));assertEquals(n,saved.size());assertFalse(player.released);}
    @Test public void watchedThresholdUsesExistingAvRule(){player.position(19500);progress.save(false);assertTrue(last("a").watched());assertEquals(20000,last("a").duration());}
    @Test public void automaticTransitionMarksPreviousCompletedAndStartsNextOnce(){player.play();player.automaticNext();assertEquals(0,last("a").position());assertTrue(last("a").watched());assertEquals(List.of("a","b"),played);assertEquals("b",player.getCurrentMediaItem().mediaId);}
}
