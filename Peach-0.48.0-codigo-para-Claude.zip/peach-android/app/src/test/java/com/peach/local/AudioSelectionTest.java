package com.peach.local;

import android.os.Bundle;
import java.util.List;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class AudioSelectionTest {
    LibraryDatabase db;
    @Before public void open(){db=androidx.room.Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().build();}
    @After public void close(){db.close();}
    MediaEntry row(String id,String type){MediaEntry r=new MediaEntry();r.id=id;r.uri="content://audio-fixture/"+id;r.root="root";r.folder="Carpeta";r.name=id+(type.equals(MediaRules.AUDIO)?".wav":".mp4");r.title=id;r.mediaType=type;db.library().insertMedia(r);return r;}
    static Bundle args(String id){Bundle b=new Bundle();b.putString("mediaId",id);return b;}
    @Test public void orderedMixedPlaylistBecomesAudioOnlyAndKeepsSelectedResumeAndPersonalTitle(){
        row("b",MediaRules.AUDIO);row("video",MediaRules.VIDEO);row("a",MediaRules.AUDIO);db.library().editMetadata("a","Personal","");db.library().progress("a",4500,20000,1,false);
        String list=new PlaylistStore(db).create("Mixta");for(String id:List.of("b","video","a"))new PlaylistStore(db).add(list,id);
        Bundle a=args("a");a.putString("playlistId",list);a.putInt("order",4);var q=AudioSelection.load(db,a);assertEquals(List.of("b","a"),q.rows().stream().map(m->m.id).toList());assertEquals(1,q.start());assertEquals(4500,q.position());assertEquals("Personal",q.items().get(1).mediaMetadata.title);assertEquals("content://audio-fixture/a",q.items().get(1).localConfiguration.uri.toString());
    }
    @Test public void rootFolderQueryAndFavoriteScopesAreRespectedWithoutLosingExplicitSelection(){
        row("a",MediaRules.AUDIO);row("b",MediaRules.AUDIO);row("c",MediaRules.AUDIO);db.library().toggleFavorite("b");Bundle b=args("b");b.putInt("filter",1);b.putString("root","root");b.putString("folder","Carpeta");assertEquals(List.of("b"),AudioSelection.load(db,b).rows().stream().map(m->m.id).toList());b.putString("query","does-not-match");assertEquals(List.of("b"),AudioSelection.load(db,b).rows().stream().map(m->m.id).toList());
    }
    @Test public void groupMembershipAndMissingNonSelectedTracksAreFiltered(){
        row("a",MediaRules.AUDIO);row("b",MediaRules.AUDIO);row("c",MediaRules.AUDIO);String group=new GroupStore(db).create("Grupo");new GroupStore(db).add(group,"b");new GroupStore(db).add(group,"c");db.getOpenHelper().getWritableDatabase().execSQL("UPDATE media SET missing=1 WHERE id='c'");Bundle b=args("b");b.putString("group",group);assertEquals(List.of("b"),AudioSelection.load(db,b).rows().stream().map(m->m.id).toList());
    }
    @Test public void callerUrlsAreIgnoredAndNonContentCatalogUrisAreRejected(){
        row("a",MediaRules.AUDIO);Bundle b=args("a");b.putString("uri","https://example.invalid/remote.mp3");assertEquals("content",AudioSelection.load(db,b).items().get(0).localConfiguration.uri.getScheme());db.getOpenHelper().getWritableDatabase().execSQL("UPDATE media SET uri='https://example.invalid/remote.mp3' WHERE id='a'");assertThrows(IllegalArgumentException.class,()->AudioSelection.load(db,b));
    }
    @Test public void missingVideoAndMalformedSelectionsLeaveCatalogUnchanged(){
        row("a",MediaRules.AUDIO);row("video",MediaRules.VIDEO);assertThrows(IllegalArgumentException.class,()->AudioSelection.load(db,args("missing")));assertThrows(IllegalArgumentException.class,()->AudioSelection.load(db,args("video")));Bundle b=args("a");b.putInt("filter",9);assertThrows(IllegalArgumentException.class,()->AudioSelection.load(db,b));b.putInt("filter",0);b.putString("query","x".repeat(4097));assertThrows(IllegalArgumentException.class,()->AudioSelection.load(db,b));assertEquals(0,db.library().get("a").playCount);
    }
    @Test public void oversizedQueueFailsExplicitlyRatherThanSilentlyTruncating(){
        db.runInTransaction(()->{for(int i=0;i<=AudioSelection.MAX_QUEUE;i++)row("a"+i,MediaRules.AUDIO);});assertThrows(IllegalArgumentException.class,()->AudioSelection.load(db,args("a0")));
    }
    @Test public void completedFilterFromLibraryIsAValidAudioSelection(){row("a",MediaRules.AUDIO);row("b",MediaRules.AUDIO);db.library().toggleWatched("a");Bundle b=args("a");b.putInt("filter",4);assertEquals(List.of("a"),AudioSelection.load(db,b).rows().stream().map(m->m.id).toList());}
}
