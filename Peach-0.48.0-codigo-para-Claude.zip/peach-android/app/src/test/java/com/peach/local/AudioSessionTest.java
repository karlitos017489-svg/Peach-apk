package com.peach.local;

import android.os.Bundle;
import android.os.Looper;
import androidx.media3.common.Player;
import androidx.media3.session.*;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28) @SQLiteMode(SQLiteMode.Mode.LEGACY)
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public class AudioSessionTest extends AudioTestSupport {
    @Test public void actualMediaControllerSelectsLibraryAudioAndCannotReplaceItWithCallerMediaUris()throws Exception{
        MediaController c=controller();assertEquals(SessionResult.RESULT_SUCCESS,await(c.sendCustomCommand(AudioService.SELECT,AudioSelectionTest.args("a"))).resultCode);idle();assertEquals("a",c.getCurrentMediaItem().mediaId);assertTrue(c.isPlaying());assertFalse(c.isCommandAvailable(Player.COMMAND_CHANGE_MEDIA_ITEMS));assertFalse(c.isCommandAvailable(Player.COMMAND_SET_MEDIA_ITEM));c.setMediaItem(androidx.media3.common.MediaItem.fromUri("https://example.invalid/not-opened.mp3"));idle();assertEquals("content://fixture/a",service.engine.getCurrentMediaItem().localConfiguration.uri.toString());c.pause();idle();assertFalse(service.engine.isPlaying());c.seekToNextMediaItem();idle();assertEquals("b",service.engine.getCurrentMediaItem().mediaId);
    }
    @Test public void reconnectAndSelectingCurrentAudioDoNotRestartPausedTrackOrDuplicateCounter()throws Exception{
        MediaController first=controller();await(first.sendCustomCommand(AudioService.SELECT,AudioSelectionTest.args("a")));idle();service.engine.position(6000);first.pause();idle();int replacements=service.engine.replacements;first.release();clients.remove(first);idle();MediaController second=controller();await(second.sendCustomCommand(AudioService.SELECT,AudioSelectionTest.args("a")));idle();assertEquals(replacements,service.engine.replacements);assertFalse(second.isPlaying());assertTrue(second.getCurrentPosition()>=6000);assertEquals(1,db.library().get("a").playCount);
    }
    @Test public void newestConcurrentSelectionWinsAndOlderResultCannotReplaceItsQueue()throws Exception{
        var first=service.select(AudioSelectionTest.args("a"));var second=service.select(AudioSelectionTest.args("b"));assertEquals(SessionError.ERROR_INVALID_STATE,await(first).resultCode);assertEquals(SessionResult.RESULT_SUCCESS,await(second).resultCode);idle();assertEquals("b",service.engine.getCurrentMediaItem().mediaId);assertEquals(0,db.library().get("a").playCount);assertEquals(1,db.library().get("b").playCount);
    }
    @Test public void invalidSelectionPreservesCurrentQueueAndStopClearsItWithProgressSaved()throws Exception{
        MediaController c=controller();await(c.sendCustomCommand(AudioService.SELECT,AudioSelectionTest.args("a")));idle();service.engine.position(8000);assertEquals(SessionError.ERROR_BAD_VALUE,await(c.sendCustomCommand(AudioService.SELECT,AudioSelectionTest.args("missing"))).resultCode);assertEquals("a",service.engine.getCurrentMediaItem().mediaId);assertEquals(SessionResult.RESULT_SUCCESS,await(c.sendCustomCommand(AudioService.STOP,Bundle.EMPTY)).resultCode);idle();assertEquals(0,c.getMediaItemCount());assertFalse(c.isPlaying());assertTrue(db.library().get("a").position>=8000);assertEquals(1,db.library().get("a").playCount);assertNull(db.library().readerProgress("a"));
    }
    @Test public void foreignUidRequiresAndroidTrustAndOwnUidIsAllowed(){int own=android.os.Process.myUid();assertTrue(AudioService.allowed(own,false));assertTrue(AudioService.allowed(own+1,true));assertFalse(AudioService.allowed(own+1,false));}
    @Test public void destroyCancelsUnappliedSelectionAndReleasesPlayerAndSession()throws Exception{
        var pending=service.select(AudioSelectionTest.args("a"));lifecycle.destroy();assertEquals(SessionError.ERROR_INVALID_STATE,await(pending).resultCode);idle();assertTrue(service.engine.released);assertEquals(0,db.library().get("a").playCount);
    }
    @Test public void stopDuringDatabaseLoadPreventsPlaybackFromStartingLater()throws Exception{
        MediaController c=controller();var blocked=new java.util.concurrent.CountDownLatch(1);var entered=new java.util.concurrent.CountDownLatch(1);
        LibraryDatabase.IO.execute(()->{entered.countDown();try{blocked.await(10,TimeUnit.SECONDS);}catch(InterruptedException error){Thread.currentThread().interrupt();}});assertTrue(entered.await(2,TimeUnit.SECONDS));
        var selected=service.select(AudioSelectionTest.args("a"));var stop=c.sendCustomCommand(AudioService.STOP,Bundle.EMPTY);
        try{for(int i=0;i<300 && !stop.isDone();i++){Shadows.shadowOf(Looper.getMainLooper()).idle();Thread.sleep(5);}assertTrue(stop.isDone());assertEquals(SessionResult.RESULT_SUCCESS,stop.get().resultCode);}finally{blocked.countDown();}
        assertEquals(SessionError.ERROR_INVALID_STATE,await(selected).resultCode);idle();assertEquals(0,service.engine.getMediaItemCount());assertEquals(0,db.library().get("a").playCount);
    }
}
