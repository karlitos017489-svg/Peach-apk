package com.peach.local;

import android.os.Bundle;
import android.os.Looper;
import androidx.media3.common.Player;
import androidx.media3.session.*;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28) @SQLiteMode(SQLiteMode.Mode.LEGACY)
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public abstract class AudioTestSupport {
    public static class TestService extends AudioService {FakeAudioPlayer engine;@Override protected Player createPlayer(){engine=new FakeAudioPlayer();return engine;}}
    LibraryDatabase db;org.robolectric.android.controller.ServiceController<TestService> lifecycle;TestService service;List<MediaController> clients;
    @Before public void open(){var context=RuntimeEnvironment.getApplication();db=androidx.room.Room.inMemoryDatabaseBuilder(context,LibraryDatabase.class).allowMainThreadQueries().setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",db);for(String id:List.of("a","b")){MediaEntry row=new MediaEntry();row.id=id;row.name=id+".wav";row.title="Audio "+id;row.uri="content://fixture/"+id;row.mediaType=MediaRules.AUDIO;db.library().insertMedia(row);}lifecycle=Robolectric.buildService(TestService.class).create();service=lifecycle.get();clients=new ArrayList<>();}
    static void idle()throws Exception{for(int i=0;i<3;i++){LibraryDatabase.IO.submit(()->{}).get(10,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}}
    static <T>T await(ListenableFuture<T> result)throws Exception{for(int i=0;i<400 && !result.isDone();i++){idle();Thread.sleep(5);}assertTrue("Async media operation completed",result.isDone());return result.get(1,TimeUnit.SECONDS);}
    MediaController controller()throws Exception{MediaController c=await(new MediaController.Builder(RuntimeEnvironment.getApplication(),service.session().getToken()).buildAsync());clients.add(c);return c;}
    @After public void close()throws Exception{for(var c:clients)c.release();idle();if(!service.engine.released)lifecycle.destroy();idle();db.close();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);}
}
