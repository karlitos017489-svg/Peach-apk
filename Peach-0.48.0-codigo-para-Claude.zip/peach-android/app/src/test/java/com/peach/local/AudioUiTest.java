package com.peach.local;

import android.content.Intent;
import android.os.Looper;
import android.view.View;
import android.widget.TextView;
import androidx.media3.session.*;
import com.google.common.util.concurrent.ListenableFuture;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land") @SQLiteMode(SQLiteMode.Mode.LEGACY) @GraphicsMode(GraphicsMode.Mode.NATIVE)
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public class AudioUiTest extends AudioTestSupport {
    public static class TestAudioActivity extends AudioActivity {static AudioService service;@Override protected ListenableFuture<MediaController> connect(){return new MediaController.Builder(this,service.session().getToken()).buildAsync();}}
    void loaded(AudioActivity activity)throws Exception{for(int i=0;i<300 && !activity.findViewById(R.id.audioStop).isEnabled();i++){idle();Thread.sleep(5);}assertTrue("Audio screen attached: "+((TextView)activity.findViewById(R.id.playerError)).getText()+" / "+((TextView)activity.findViewById(R.id.audioInfo)).getText(),activity.findViewById(R.id.audioStop).isEnabled());}
    @Test public void stoppingScreenKeepsPlayingAndReopeningUsesSamePositionAndPlayCount()throws Exception{
        TestAudioActivity.service=service;Intent intent=new Intent(RuntimeEnvironment.getApplication(),TestAudioActivity.class).putExtra("mediaId","a");
        try(var first=Robolectric.buildActivity(TestAudioActivity.class,intent).setup().visible()){
            loaded(first.get());assertEquals(View.GONE,first.get().findViewById(R.id.subtitle).getVisibility());assertTrue(((TextView)first.get().findViewById(R.id.playerTitle)).getText().toString().contains("Audio a"));service.engine.position(6000);int replacements=service.engine.replacements;first.pause().stop();idle();assertTrue(service.engine.isPlaying());assertFalse(service.engine.released);first.start().resume().visible();loaded(first.get());assertEquals(replacements,service.engine.replacements);assertTrue(service.engine.getCurrentPosition()>=6000);assertEquals(1,db.library().get("a").playCount);
        }idle();assertFalse(service.engine.released);
    }
    @Test public void recreationAttachesToAdvancedCurrentTrackAndStopButtonSavesAndFinishes()throws Exception{
        TestAudioActivity.service=service;Intent intent=new Intent(RuntimeEnvironment.getApplication(),TestAudioActivity.class).putExtra("mediaId","a");
        try(var screen=Robolectric.buildActivity(TestAudioActivity.class,intent).setup().visible()){
            loaded(screen.get());service.engine.seekToNextMediaItem();idle();screen.recreate();loaded(screen.get());assertEquals("b",service.engine.getCurrentMediaItem().mediaId);assertEquals(1,db.library().get("a").playCount);assertEquals(1,db.library().get("b").playCount);screen.get().findViewById(R.id.audioStop).performClick();idle();assertTrue(screen.get().isFinishing());assertEquals(0,service.engine.getMediaItemCount());
        }
    }
    @Test public void notificationStyleEntryWithoutSelectionAttachesToCurrentAudio()throws Exception{
        await(service.select(AudioSelectionTest.args("b")));idle();TestAudioActivity.service=service;
        try(var screen=Robolectric.buildActivity(TestAudioActivity.class,new Intent(RuntimeEnvironment.getApplication(),TestAudioActivity.class)).setup().visible()){
            loaded(screen.get());assertTrue(((TextView)screen.get().findViewById(R.id.playerTitle)).getText().toString().contains("Audio b"));assertEquals(1,db.library().get("b").playCount);
        }
    }
    @Test public void libraryAudioOpensAudioScreenWhileVideoKeepsItsExistingPlayer()throws Exception{
        var context=RuntimeEnvironment.getApplication();androidx.work.testing.WorkManagerTestInitHelper.initializeTestWorkManager(context,new androidx.work.Configuration.Builder().setExecutor(Runnable::run).setTaskExecutor(Runnable::run).build());
        try(var screen=Robolectric.buildActivity(MainActivity.class).setup().visible()){
            screen.get().findViewById(R.id.toggleFilters).performClick();((android.widget.Spinner)screen.get().findViewById(R.id.typeFilter)).setSelection(3);idle();var grid=(androidx.recyclerview.widget.RecyclerView)screen.get().findViewById(R.id.grid);assertEquals(2,grid.getAdapter().getItemCount());grid.measure(View.MeasureSpec.makeMeasureSpec(1000,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(600,View.MeasureSpec.EXACTLY));grid.layout(0,0,1000,600);grid.findViewHolderForAdapterPosition(0).itemView.performClick();Intent opened=Shadows.shadowOf(screen.get()).getNextStartedActivity();assertEquals(AudioActivity.class.getName(),opened.getComponent().getClassName());assertNotNull(opened.getStringExtra("mediaId"));
        }finally{idle();androidx.work.testing.WorkManagerTestInitHelper.closeWorkDatabase();}
    }
}
