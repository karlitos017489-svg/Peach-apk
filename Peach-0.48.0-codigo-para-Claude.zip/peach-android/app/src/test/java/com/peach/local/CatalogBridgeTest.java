package com.peach.local;

import androidx.room.Room;
import java.io.*;
import java.nio.charset.StandardCharsets;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class CatalogBridgeTest {
    LibraryDatabase db;CatalogTransfer transfer;CatalogBridge.Options options=new CatalogBridge.Options("Mi origen","R:\\Media","root");
    @Before public void open()throws Exception {
        db=Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().build();transfer=CatalogFixture.transfer();
        LibraryRoot root=new LibraryRoot();root.uri="root";root.label="Tablet";root.state=0;db.library().addRoot(root);
        media("a","Set","a.mp4",123);media("b","","b.pdf",456);MediaEntry a=db.library().get("a");db.library().editMetadata("a","Personal","Propia");db.library().restoreState("a",true,true,7000,90000,100,4);
        ReaderProgress reading=new ReaderProgress();reading.mediaId="b";reading.page=2;db.library().putReaderProgress(reading);
    }
    void media(String id,String folder,String name,long size){MediaEntry m=new MediaEntry();m.id=id;m.root="root";m.uri="content://fixture/"+id;m.folder=folder;m.name=name;m.title=name;m.bytes=size;db.library().insertMedia(m);}
    @After public void close(){db.close();}
    CatalogBridge.Plan plan()throws Exception{return CatalogBridge.preview(db.library(),transfer,options);}
    @Test public void mapsExactRelativePathsAndImportsGraphAndOrderedListsWithoutChangingPersonalOrScanState()throws Exception {
        CatalogBridge.Plan plan=plan();assertEquals("a",plan.assets.get(0).mediaId());assertEquals("b",plan.assets.get(1).mediaId());assertEquals("",plan.assets.get(2).mediaId());CatalogBridge.apply(db,plan);
        String entity=CatalogBridge.key("Mi origen","entity","11"),list=CatalogBridge.key("Mi origen","playlist","21");assertEquals("Ana",db.library().entity(entity).name);assertEquals("Alba",db.library().aliases().get(0).name);
        assertEquals("123",db.library().entityReferences().get(0).externalId);assertEquals(1,db.library().entityLinks().size());assertEquals("a",db.library().entityLinks().get(0).mediaId);
        assertEquals("b",db.library().playlistItems(list).get(0).mediaId);assertEquals("a",db.library().playlistItems(list).get(1).mediaId);
        MediaEntry a=db.library().get("a");assertEquals("Personal",a.displayTitle());assertEquals("Propia",a.displayTags());assertEquals(7000,a.position);assertEquals(4,a.playCount);assertTrue(a.favorite);assertTrue(a.watched);assertEquals("{}",a.nfoDetails);assertEquals(2,db.library().readerProgress("b").page);
        CatalogSnapshot s=db.library().snapshots().get(0);assertEquals(3,new JSONObject(s.payload).getJSONObject("tables").getJSONArray("asset").length());assertEquals("a",new JSONObject(s.bindings).getString("1"));
    }
    @Test public void repeatedImportsPreserveLocalEditsAndDoNotDuplicateNamesListsOrLinks()throws Exception {
        CatalogBridge.apply(db,plan());String entity=CatalogBridge.key("Mi origen","entity","11"),list=CatalogBridge.key("Mi origen","playlist","21");db.library().removeAlias(entity,"Alba");db.library().renamePlaylist(list,"Editada");db.library().clearPlaylist(list);
        CatalogBridge.apply(db,plan());assertEquals(1,db.library().entities().size());assertTrue(db.library().aliases().isEmpty());assertEquals("Editada",db.library().playlist(list).name);assertTrue(db.library().playlistItems(list).isEmpty());assertEquals(1,db.library().entityLinks().size());assertEquals(1,db.library().snapshots().size());
    }
    @Test public void snapshotOnlyImportKeepsUnmappedAssetsAndCanLaterMapAnotherRoot()throws Exception {
        var snapshotOnly=CatalogBridge.preview(db.library(),transfer,new CatalogBridge.Options("Mi origen","",""));assertTrue(snapshotOnly.assets.stream().allMatch(a->a.mediaId().isEmpty()));CatalogBridge.apply(db,snapshotOnly);assertTrue(db.library().entityLinks().isEmpty());
        CatalogBridge.apply(db,plan());assertEquals(1,db.library().entityLinks().size());assertEquals(1,db.library().snapshots().size());
        assertEquals(2,db.library().playlistItems(CatalogBridge.key("Mi origen","playlist","21")).size());
    }
    @Test public void rejectsAmbiguousDuplicateTargetsSizeDifferencesTraversalAndBoundaryMismatches()throws Exception {
        media("duplicate","Set","a.mp4",123);assertEquals("Ruta local ambigua",plan().assets.get(0).state());db.library().forgetMedia("root");media("a","Set","a.mp4",999);assertEquals("Tamaño diferente",plan().assets.get(0).state());
        JSONObject json=CatalogFixture.json();JSONArray assets=json.getJSONObject("tables").getJSONArray("asset");assets.getJSONObject(0).put("path","R:/Media/../Set/a.mp4");transfer=CatalogTransfer.validate(json);assertEquals("Ruta no compatible",plan().assets.get(0).state());
        assets.getJSONObject(0).put("path","R:/MediaOther/Set/a.mp4");transfer=CatalogTransfer.validate(json);assertEquals("Sin correspondencia",plan().assets.get(0).state());
        db.library().forgetMedia("root");media("a","Set","a.mp4",123);assets.getJSONObject(0).put("path","R:/Media/Set/a.mp4");assets.getJSONObject(1).put("path","R:/Media/Set/a.mp4").put("size",123);transfer=CatalogTransfer.validate(json);assertEquals("Varios assets para un documento",plan().assets.get(0).state());assertEquals("",plan().assets.get(1).mediaId());
    }
    @Test public void conflictsDoNotMergeLocalIdentitiesAndBothIncomingConflictingClaimsAreSkipped()throws Exception {
        String local=new EntityStore(db).create("performer","Alba","");CatalogBridge.Plan plan=plan();assertEquals("Conflicto",plan.identities.get(0).state());CatalogBridge.apply(db,plan);assertEquals(1,db.library().entities().size());assertNotNull(db.library().entity(local));assertTrue(db.library().entityLinks().isEmpty());
        db.library().deleteEntity(local);JSONObject json=CatalogFixture.json();json.getJSONObject("tables").getJSONArray("entity").put(CatalogFixture.row("id",12,"kind","performer","canonical_name","Alba"));transfer=CatalogTransfer.validate(json);assertEquals(2,plan().identities.stream().filter(i->i.state().equals("Conflicto")).count());
    }
    @Test public void stalePreviewAndIncompleteScansCannotCommitPartialImports()throws Exception {
        CatalogBridge.Plan old=plan();new EntityStore(db).create("performer","Alba","");CatalogTransferTest.rejects(()->CatalogBridge.apply(db,old));assertTrue(db.library().snapshots().isEmpty());assertTrue(db.library().playlists().isEmpty());assertEquals(1,db.library().entities().size());
        db.library().rootState("root",1);CatalogTransferTest.rejects(()->plan());
    }
    @Test public void snapshotsBackupRoundTripAndInvalidBindingRollsBackEntireRestore()throws Exception {
        CatalogBridge.apply(db,plan());ByteArrayOutputStream out=new ByteArrayOutputStream();BackupStore.write(db.library(),out);JSONObject backup=new JSONObject(out.toString("UTF-8"));assertEquals(19,backup.getInt("version"));
        LibraryDatabase target=Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().build();try {
            BackupStore.read(target,new ByteArrayInputStream(out.toByteArray()));assertEquals(1,target.library().snapshots().size());assertEquals(db.library().snapshots().get(0).bindings,target.library().snapshots().get(0).bindings);assertTrue(target.library().allMedia().isEmpty());
        }finally{target.close();}
        backup.getJSONArray("items").getJSONObject(0).put("favorite",false);backup.getJSONArray("catalogSnapshots").getJSONObject(0).getJSONObject("bindings").put("999","missing");CatalogTransferTest.rejects(()->BackupStore.read(db,new ByteArrayInputStream(backup.toString().getBytes(StandardCharsets.UTF_8))));assertTrue(db.library().get("a").favorite);
        JSONObject older=new JSONObject(out.toString("UTF-8")).put("version",5);older.remove("catalogSnapshots");BackupStore.read(db,new ByteArrayInputStream(older.toString().getBytes(StandardCharsets.UTF_8)));assertEquals(1,db.library().snapshots().size());
    }
    @Test public void unknownEntityKindsRemainInSnapshotAndNeverBecomeAnIncorrectLocalType()throws Exception {
        JSONObject json=CatalogFixture.json();json.getJSONObject("tables").getJSONArray("entity").getJSONObject(0).put("kind","collective");transfer=CatalogTransfer.validate(json);assertEquals("Tipo pendiente",plan().identities.get(0).state());CatalogBridge.apply(db,plan());assertTrue(db.library().entities().isEmpty());assertTrue(db.library().entityLinks().isEmpty());assertTrue(db.library().snapshots().get(0).payload.contains("collective"));
    }
    @Test public void caseAndUnicodeAreNotFoldedAndMappingsSurviveForgettingSourceRoot()throws Exception {
        JSONObject json=CatalogFixture.json();var asset=json.getJSONObject("tables").getJSONArray("asset").getJSONObject(0);asset.put("path","R:/Media/Set/A.mp4");transfer=CatalogTransfer.validate(json);assertTrue(plan().assets.get(0).mediaId().isEmpty());
        media("unicode","Álbum","本.jpg",123);asset.put("path","R:/Media/Álbum/本.jpg");transfer=CatalogTransfer.validate(json);assertEquals("unicode",plan().assets.get(0).mediaId());CatalogBridge.apply(db,plan());db.library().forgetMedia("root");db.library().forgetRoot("root");assertEquals(1,db.library().snapshots().size());assertEquals("unicode",new JSONObject(db.library().snapshots().get(0).bindings).getString("1"));assertTrue(db.library().entityLinks().isEmpty());
        assertEquals("//server/share/Media",CatalogBridge.path("\\\\server\\share\\Media\\"));
    }
    @Test public void largeRelativePathIndexDoesNotCrossJoinDuplicateNamesAcrossFolders()throws Exception {
        JSONObject json=CatalogFixture.json();JSONArray assets=json.getJSONObject("tables").getJSONArray("asset");for(int i=4;i<=1108;i++){String folder="Folder "+i;media("m"+i,folder,"same.mp4",i);assets.put(CatalogFixture.row("id",i,"location","disk","path","R:/Media/"+folder+"/same.mp4","size",i));}transfer=CatalogTransfer.validate(json);var p=plan();assertEquals(1108,p.assets.size());assertEquals("m1108",p.assets.get(1107).mediaId());assertEquals(1107,p.assets.stream().filter(a->!a.mediaId().isEmpty()).count());
    }
    @Test public void snapshotLimitRollsBackGraphAndListsAddedInTheSameTransaction()throws Exception {
        for(int i=0;i<20;i++)CatalogBridge.apply(db,CatalogBridge.preview(db.library(),transfer,new CatalogBridge.Options("Origen "+i,"","")));
        CatalogTransferTest.rejects(()->CatalogBridge.apply(db,plan()));assertEquals(20,db.library().snapshots().size());assertTrue(db.library().entities().isEmpty());assertTrue(db.library().playlists().isEmpty());assertTrue(db.library().entityLinks().isEmpty());
    }
}
