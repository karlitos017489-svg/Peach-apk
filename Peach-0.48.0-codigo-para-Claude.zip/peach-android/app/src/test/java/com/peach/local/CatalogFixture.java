package com.peach.local;

import org.json.*;
final class CatalogFixture {
    static JSONObject row(Object... pairs)throws JSONException {JSONObject row=new JSONObject();for(int i=0;i<pairs.length;i+=2)row.put((String)pairs[i],pairs[i+1]);return row;}
    static JSONObject json()throws JSONException {
        JSONObject tables=new JSONObject();for(String key:CatalogTransfer.COLUMNS.keySet())tables.put(key,new JSONArray());
        tables.getJSONArray("asset").put(row("id",1,"location","disk","path","R:\\Media\\Set\\a.mp4","name","a.mp4","size",123,"code","CAM-1"));
        tables.getJSONArray("asset").put(row("id",2,"location","disk","path","R:\\Media\\b.pdf","size",456));
        tables.getJSONArray("asset").put(row("id",3,"location","disk","path","R:\\Media\\missing.jpg","size",789));
        tables.getJSONArray("entity").put(row("id",11,"kind","performer","canonical_name","Ana"));
        tables.getJSONArray("entity_alias").put(row("entity_id",11,"alias","Alba","source","manual","confidence",0.8));
        tables.getJSONArray("entity_external_ref").put(row("entity_id",11,"provider","example","external_kind","performer","external_id","123"));
        tables.getJSONArray("asset_tag").put(row("asset_id",1,"tag","Campo","source","nfo","confidence",1));
        tables.getJSONArray("asset_entity").put(row("asset_id",1,"entity_id",11,"role","performer","source","manual","confidence",0.9));
        tables.getJSONArray("asset_entity").put(row("asset_id",3,"entity_id",11,"role","performer","source","manual","confidence",1));
        tables.getJSONArray("playlist").put(row("id",21,"profile_id","local","name","Orden","source_kind","manual"));
        tables.getJSONArray("playlist_item").put(row("playlist_id",21,"asset_id",2,"position",0));
        tables.getJSONArray("playlist_item").put(row("playlist_id",21,"asset_id",1,"position",1));
        tables.getJSONArray("playlist_item").put(row("playlist_id",21,"asset_id",3,"position",2));
        return row("format","peach-catalog-transfer","version",1,"tables",tables);
    }
    static CatalogTransfer transfer()throws Exception{return CatalogTransfer.validate(json());}
}
