package com.peach.local;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,manifest=Config.NONE)
public class CatalogIndexTest {
    private MediaEntry media(String id,String actors) {
        MediaEntry m=new MediaEntry();m.id=id;m.actors=actors;return m;
    }
    @Test public void exactTermsNeverMatchSubstringsOrMergeCaseVariants() {
        MediaEntry a=media("a","Ana, Ana"),b=media("b","Anabel"),c=media("c","ana");
        assertEquals(List.of(a),CatalogIndex.select(List.of(a,b,c),"actors","Ana","",List.of()));
        assertEquals(3,CatalogIndex.terms(List.of(a,b,c),"actors").size());
        assertEquals(1,CatalogIndex.terms(List.of(a,b,c),"actors").get(0).count());
        assertTrue(CatalogIndex.values(a,"unknown").isEmpty());
    }
    @Test public void structuredNfoPreservesCommaNamesAndSeparateStudiosAndGenres() throws Exception {
        String xml="<movie><actor><name>Rivera, Ana</name></actor><actor><name>Sol</name></actor>"+
            "<studio>Uno, Dos</studio><studio>Tres</studio><genre>Campo, costa</genre><tag>Viaje</tag></movie>";
        var nfo=NfoReader.read(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
        MediaEntry m=media("a",nfo.actors());m.tags=nfo.tags();m.studio=nfo.studio();
        m.nfoDetails=NfoDetails.encode(nfo.details(),nfo.terms());
        assertEquals(List.of("Rivera, Ana","Sol"),CatalogIndex.values(m,"actors"));
        assertEquals(List.of("Uno, Dos","Tres"),CatalogIndex.values(m,"studio"));
        assertEquals(List.of("Campo, costa"),CatalogIndex.values(m,"genres"));
        assertEquals(List.of("Campo, costa","Viaje"),CatalogIndex.values(m,"tags"));
        assertFalse(m.details().containsKey("_catalog"));
    }
    @Test public void personalTagsOverrideImportedTermsAndResetRestoresThem() {
        MediaEntry m=media("a","");m.tags="Origen";
        m.nfoDetails=NfoDetails.encode(Map.of(),Map.of("tags",List.of("Origen")));
        m.userTags="Personal, Trabajo\nViaje";assertEquals(List.of("Personal","Trabajo","Viaje"),CatalogIndex.values(m,"tags"));
        m.userTags="";assertTrue(CatalogIndex.values(m,"tags").isEmpty());
        m.userTags=null;assertEquals(List.of("Origen"),CatalogIndex.values(m,"tags"));
    }
    @Test public void seriesAndCollectionsKeepPunctuationAndCacheRefreshesAfterScan() {
        MediaEntry m=media("a","");m.nfoDetails=NfoDetails.encode(Map.of("series","Campo, costa","collection","Uno, dos"));
        assertEquals(List.of("Campo, costa"),CatalogIndex.values(m,"series"));
        assertEquals(List.of("Uno, dos"),CatalogIndex.values(m,"collection"));
        m.nfoDetails=NfoDetails.encode(Map.of(),Map.of("actors",List.of("Nueva")));
        assertEquals(List.of("Nueva"),CatalogIndex.values(m,"actors"));
        assertTrue(CatalogIndex.values(m,"series").isEmpty());
    }
    @Test public void groupMembershipRetainsMissingDocumentsAndIntersectsExactFacet() {
        MediaEntry a=media("a","Ana"),b=media("b","Sol"),c=media("c","Ana");a.missing=true;
        MediaGroupItem item=new MediaGroupItem();item.groupId="g";item.mediaId="a";
        assertEquals(List.of(a),CatalogIndex.select(List.of(a,b,c),"actors","Ana","g",List.of(item)));
        assertTrue(CatalogIndex.select(List.of(a,b,c),"actors","Sol","g",List.of(item)).isEmpty());
    }
}
