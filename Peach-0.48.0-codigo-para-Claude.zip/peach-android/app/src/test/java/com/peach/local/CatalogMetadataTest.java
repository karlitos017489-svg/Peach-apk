package com.peach.local;

import android.os.CancellationSignal;
import android.provider.DocumentsContract;
import android.net.Uri;
import androidx.room.Room;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class CatalogMetadataTest {
    LibraryDatabase db;
    @Before public void open(){db=Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().build();root("root");media("a","root","Set","a.mp4");media("b","root","","b.pdf");}
    @After public void close(){db.close();}
    void root(String id){LibraryRoot r=new LibraryRoot();r.uri=id;r.label="Tablet";r.state=0;db.library().addRoot(r);}
    void media(String id,String root,String folder,String name){MediaEntry m=new MediaEntry();m.id=id;m.uri="content://fixture/"+id;m.root=root;m.folder=folder;m.name=name;m.title=MediaRules.stem(name);m.bytes=id.equals("b")?456:123;db.library().insertMedia(m);}
    JSONObject json()throws Exception{JSONObject json=CatalogFixture.json();json.getJSONObject("tables").getJSONArray("asset").getJSONObject(0).put("catalog_title","Título del catálogo").put("original_title","Original field").put("release_date","2025-06-14").put("studio","Rivera, Ana").put("creator","Luz, Mar").put("duration",123.5);return json;}
    void apply(JSONObject json,String source,String root)throws Exception{CatalogBridge.apply(db,CatalogBridge.preview(db.library(),CatalogTransfer.validate(json),new CatalogBridge.Options(source,"R:/Media",root)));}
    @Test public void mainQueriesAndFacetsUseImportedFieldsWithAtomicNamesAndNoPlaybackMutation()throws Exception {
        apply(json(),"Origen A","root");MediaEntry a=db.library().get("a");assertEquals("Título del catálogo",a.displayTitle());assertEquals("a",a.title);assertEquals("2025",a.displayYear());assertEquals("CAM-1",a.details().get("code"));assertEquals("{}",a.nfoDetails);
        for(String q:List.of("CAM-1","Original field","Origen A","Luz, Mar","Rivera, Ana","Ana","Campo"))assertTrue(q,MediaRules.matches(a,q,0));
        assertEquals(List.of("Rivera, Ana"),CatalogIndex.values(a,"studio"));assertEquals(List.of("Luz, Mar"),CatalogIndex.values(a,"creators"));assertEquals(1,CatalogIndex.terms(db.library().allMedia(),"actors").get(0).count());
        assertEquals(1,LibraryView.select(db.library().allMedia(),"CAM-1",0,"","","",List.of(),0).size());assertEquals(0,a.duration);assertEquals(0,a.position);
        assertTrue(MediaDetailsView.describe(a,"123 B").toString().contains("Duración del catálogo (segundos)"));assertTrue(MediaDetailsView.describe(a,"123 B").toString().contains("Catálogo · Origen A"));
    }
    @Test public void nfoAndPersonalOverridesKeepPriorityWhileSourceValuesRemainVisible()throws Exception {
        MediaEntry a=db.library().get("a");a.title="Título NFO";a.studio="Estudio NFO";a.year="2024";a.nfoDetails=NfoDetails.encode(Map.of("code","NFO-1"));rescan(a);db.library().editMetadata("a","Personal","Propia");db.library().restoreState("a",true,true,7000,90000,1,4);
        apply(json(),"Origen A","root");a=db.library().get("a");assertEquals("Personal",a.displayTitle());assertEquals("NFO-1",a.details().get("code"));assertEquals("2024",a.displayYear());assertEquals("Estudio NFO",a.displayStudio());assertEquals(List.of("Propia"),CatalogIndex.values(a,"tags"));assertTrue(a.favorite);assertTrue(a.watched);assertEquals(7000,a.position);assertEquals(4,a.playCount);
        String details=MediaDetailsView.describe(a,"123 B").toString();for(String q:List.of("Título NFO","Título del catálogo","NFO-1","CAM-1","Origen A"))assertTrue(details.contains(q));
        db.library().editMetadata("a",null,null);assertEquals("Título NFO",db.library().get("a").displayTitle());
    }
    void rescan(MediaEntry m){db.library().updateScan(m.id,m.uri,m.root,m.name,m.folder,m.title,m.tags,m.actors,m.studio,m.plot,m.year,m.poster,m.subtitles,m.nfoDetails,m.mediaType,m.bytes,m.modified,m.generation);}
    @Test public void anyExistingNfoProtectsFilenameTitleAndRescanDoesNotReplaceCatalogLayer()throws Exception {
        MediaEntry a=db.library().get("a");a.nfoDetails=NfoDetails.encode(Map.of("kind","movie"));rescan(a);apply(json(),"Origen A","root");a=db.library().get("a");assertEquals("a",a.displayTitle());String cache=a.catalogMetadata;a.title="Nuevo NFO";rescan(a);assertEquals(cache,db.library().get("a").catalogMetadata);assertEquals("Nuevo NFO",db.library().get("a").displayTitle());
    }
    @Test public void disagreementsDoNotChooseOneSourceAndSameValuesDeduplicatePerDocument()throws Exception {
        apply(json(),"Origen A","root");JSONObject second=json();second.getJSONObject("tables").getJSONArray("asset").getJSONObject(0).put("catalog_title","Otro título").put("code","CAM-2");apply(second,"Origen B","root");MediaEntry a=db.library().get("a");assertEquals("a",a.displayTitle());assertNull(a.details().get("code"));assertTrue(a.catalog().conflicts().contains("title"));assertTrue(a.catalog().conflicts().contains("code"));assertEquals(List.of("Campo"),CatalogIndex.values(a,"tags"));assertEquals(1,CatalogIndex.terms(List.of(a),"actors").get(0).count());
        String text=MediaDetailsView.describe(a,"123 B").toString();assertTrue(text.contains("Diferencias entre catálogos"));assertTrue(text.contains("Origen A"));assertTrue(text.contains("Origen B"));assertTrue(MediaRules.matches(a,"CAM-2",0));assertTrue(MediaRules.matches(a,"CAM-1",0));
    }
    @Test public void metadataDerivedRelationsAreMarkedAsCatalogAndCreatorsAreNotSplit()throws Exception {
        apply(json(),"Origen A","root");CatalogEntity person=db.library().entities().get(0);var relations=EntityIndex.relations(person,db.library().allMedia(),db.library().aliases(),List.of());assertEquals(1,relations.size());assertEquals("catalog",relations.get(0).source());
        String creator=new EntityStore(db).create("creator","Luz, Mar","");var e=db.library().entity(creator);assertEquals("creator",EntityIndex.relations(e,db.library().allMedia(),List.of(),List.of()).get(0).role());
    }
    @Test public void reimportChangesOnlyItsLayerAndRebindingRemovesTheOldMetadataCopy()throws Exception {
        apply(json(),"Origen A","root");JSONObject second=json();second.getJSONObject("tables").getJSONArray("asset").getJSONObject(0).put("code","B-1");apply(second,"Origen B","root");JSONObject changed=json();changed.getJSONObject("tables").getJSONArray("asset").getJSONObject(0).put("code","A-2");apply(changed,"Origen A","root");MediaEntry a=db.library().get("a");assertFalse(a.metadataSearch().contains("CAM-1"));assertTrue(a.metadataSearch().contains("A-2"));assertTrue(a.metadataSearch().contains("B-1"));
        root("root2");media("c","root2","Set","a.mp4");apply(changed,"Origen A","root2");assertFalse(db.library().get("a").metadataSearch().contains("A-2"));assertTrue(db.library().get("a").metadataSearch().contains("B-1"));assertTrue(db.library().get("c").metadataSearch().contains("A-2"));
    }
    @Test public void restoreRebuildsFromV6SnapshotsAndNeverTrustsADerivedCacheFromBackup()throws Exception {
        apply(json(),"Origen A","root");ByteArrayOutputStream bytes=new ByteArrayOutputStream();BackupStore.write(db.library(),bytes);JSONObject backup=new JSONObject(bytes.toString("UTF-8"));assertEquals(19,backup.getInt("version"));for(int i=0;i<backup.getJSONArray("items").length();i++)assertFalse(backup.getJSONArray("items").getJSONObject(i).has("catalogMetadata"));
        db.getOpenHelper().getWritableDatabase().execSQL("UPDATE media SET catalogMetadata='[]'");assertFalse(MediaRules.matches(db.library().get("a"),"CAM-1",0));BackupStore.read(db,new ByteArrayInputStream(bytes.toByteArray()));assertTrue(MediaRules.matches(db.library().get("a"),"CAM-1",0));
        db.getOpenHelper().getWritableDatabase().execSQL("UPDATE media SET catalogMetadata='broken'");db.runInTransaction(()->CatalogMetadata.rebuild(db.getOpenHelper().getWritableDatabase()));assertTrue(MediaRules.matches(db.library().get("a"),"CAM-1",0));
    }
    @Test public void recreatingAStableDocumentCanRebuildFromPreservedBindings()throws Exception {
        apply(json(),"Origen A","root");db.library().forgetMedia("root");media("a","root","Set","a.mp4");assertEquals("[]",db.library().get("a").catalogMetadata);db.runInTransaction(()->CatalogMetadata.rebuild(db.getOpenHelper().getWritableDatabase()));assertEquals("Título del catálogo",db.library().get("a").displayTitle());
    }
    @Test public void actualScannerBaseIsRemovedOnceIncludingAnIdenticallyNamedSubfolder()throws Exception {
        String authority="com.peach.local.fixture.mapping";org.robolectric.shadows.ShadowContentResolver.registerProviderInternal(authority,new DocumentScannerTest.Provider());LibraryRoot r=new LibraryRoot();r.uri=DocumentsContract.buildTreeDocumentUri(authority,"root").toString();r.label="Videos";r.state=0;db.library().addRoot(r);ScanDirectory directory=new ScanDirectory(r.uri,DocumentsContract.buildDocumentUriUsingTree(Uri.parse(r.uri),"root").toString(),"Videos");db.library().enqueue(directory);
        var batch=new DocumentScanner(RuntimeEnvironment.getApplication().getContentResolver()).scan(r,directory,new CancellationSignal());MediaEntry scanned=batch.media().get(0);db.library().insertMedia(scanned);assertEquals("Videos",scanned.folder);
        JSONObject json=CatalogFixture.json();json.getJSONObject("tables").getJSONArray("asset").getJSONObject(0).put("path","R:/Media/campo.mp4").put("size",100);CatalogTransfer transfer=CatalogTransfer.validate(json);var plan=CatalogBridge.preview(db.library(),transfer,new CatalogBridge.Options("Scanner","R:/Media",r.uri));assertEquals(scanned.id,plan.assets.get(0).mediaId());
        MediaEntry nested=new MediaEntry();nested.folder="Videos / Videos / Set";nested.name="a.mp4";assertEquals("Videos/Set/a.mp4",CatalogBridge.relative(nested,"Videos"));nested.folder="Otra / Videos";assertEquals("",CatalogBridge.relative(nested,"Videos"));
    }
    @Test public void oversizedIndexIsMarkedPartialAndDoesNotSelectAFalseUniqueTitle()throws Exception {
        JSONObject json=json();JSONArray tags=json.getJSONObject("tables").getJSONArray("asset_tag");for(int i=0;i<2100;i++)tags.put(CatalogFixture.row("asset_id",1,"tag","Tag "+i+" "+"x".repeat(280),"source","nfo","confidence",1));apply(json,"Grande","root");MediaEntry a=db.library().get("a");assertTrue(a.catalog().partial());assertTrue(a.catalogMetadata.getBytes(StandardCharsets.UTF_8).length<=CatalogMetadata.MAX_CACHE_BYTES);assertEquals("a",a.displayTitle());assertTrue(MediaDetailsView.describe(a,"123 B").toString().contains("Índice resumido"));assertTrue(db.library().snapshots().get(0).payload.contains("Tag 2099"));
    }
    @Test public void invalidReleaseDatesDoNotGenerateYearFacetsAndMalformedCacheDoesNotCrashRead()throws Exception {
        JSONObject json=json();json.getJSONObject("tables").getJSONArray("asset").getJSONObject(0).put("release_date","2025-19-32");apply(json,"Origen A","root");assertTrue(CatalogIndex.values(db.library().get("a"),"year").isEmpty());MediaEntry a=db.library().get("a");a.catalogMetadata="broken";assertTrue(a.catalog().sources.isEmpty());assertEquals("a",a.displayTitle());
    }
}
