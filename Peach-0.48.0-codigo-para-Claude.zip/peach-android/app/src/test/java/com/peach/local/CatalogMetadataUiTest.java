package com.peach.local;

import android.os.Looper;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowDialog;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land") @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class CatalogMetadataUiTest {
    LibraryDatabase db;java.util.concurrent.Executor previousDiffExecutor;
    @Before public void open(){previousDiffExecutor=org.robolectric.util.ReflectionHelpers.getStaticField(androidx.recyclerview.widget.AsyncDifferConfig.Builder.class,"sDiffExecutor");org.robolectric.util.ReflectionHelpers.setStaticField(androidx.recyclerview.widget.AsyncDifferConfig.Builder.class,"sDiffExecutor",(java.util.concurrent.Executor)Runnable::run);var context=RuntimeEnvironment.getApplication();db=androidx.room.Room.inMemoryDatabaseBuilder(context,LibraryDatabase.class).allowMainThreadQueries().setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",db);androidx.work.testing.WorkManagerTestInitHelper.initializeTestWorkManager(context,new androidx.work.Configuration.Builder().setExecutor(Runnable::run).setTaskExecutor(Runnable::run).build());LibraryRoot root=new LibraryRoot();root.uri="root";root.state=0;db.library().addRoot(root);MediaEntry m=new MediaEntry();m.id="a";m.name="a.mp4";m.folder="Set";m.root="root";m.title="a";m.bytes=123;db.library().insertMedia(m);}
    @After public void close()throws Exception{idle();androidx.work.testing.WorkManagerTestInitHelper.closeWorkDatabase();db.close();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);org.robolectric.util.ReflectionHelpers.setStaticField(androidx.recyclerview.widget.AsyncDifferConfig.Builder.class,"sDiffExecutor",previousDiffExecutor);}
    void idle()throws Exception{for(int i=0;i<3;i++){LibraryDatabase.IO.submit(()->{}).get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}}
    void apply()throws Exception{var json=CatalogFixture.json();json.getJSONObject("tables").getJSONArray("asset").getJSONObject(0).put("catalog_title","Título del catálogo").put("creator","Luz, Mar");var transfer=CatalogTransfer.validate(json);LibraryDatabase.IO.submit(()->{try{CatalogBridge.apply(db,CatalogBridge.preview(db.library(),transfer,new CatalogBridge.Options("UI origen","R:/Media","root")));}catch(Exception e){throw new IllegalArgumentException(e);}}).get(30,TimeUnit.SECONDS);idle();}
    RecyclerView grid(MainActivity activity){RecyclerView grid=activity.findViewById(R.id.grid);grid.measure(View.MeasureSpec.makeMeasureSpec(1000,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(600,View.MeasureSpec.EXACTLY));grid.layout(0,0,1000,600);return grid;}
    View find(View v,java.util.function.Predicate<View> match){if(match.test(v))return v;if(v instanceof ViewGroup group)for(int i=0;i<group.getChildCount();i++){View found=find(group.getChildAt(i),match);if(found!=null)return found;}return null;}
    @Test public void importRefreshesMainSearchAndCardWithoutReopeningTheActivity()throws Exception {
        try(var controller=Robolectric.buildActivity(MainActivity.class).setup().visible()) {
            MainActivity activity=controller.get();idle();EditText search=activity.findViewById(R.id.search);search.setText("CAM-1");Shadows.shadowOf(Looper.getMainLooper()).idleFor(java.time.Duration.ofMillis(200));assertEquals(0,grid(activity).getAdapter().getItemCount());
            apply();assertEquals(1,grid(activity).getAdapter().getItemCount());assertEquals("Título del catálogo",((TextView)grid(activity).findViewById(R.id.title)).getText().toString());grid(activity).findViewById(R.id.details_button).performClick();AlertDialog dialog=(AlertDialog)ShadowDialog.getLatestDialog();String details=((TextView)dialog.findViewById(R.id.detail_text)).getText().toString();assertTrue(details.contains("UI origen"));assertTrue(details.contains("CAM-1"));
        }
    }
    @Test public void creatorFacetCanBeSelectedThroughExplorerAndSurvivesRecreation()throws Exception {
        apply();try(var controller=Robolectric.buildActivity(MainActivity.class).setup().visible()) {
            MainActivity activity=controller.get();idle();activity.findViewById(R.id.explore).performClick();AlertDialog dialog=(AlertDialog)ShadowDialog.getLatestDialog();ListView choices=dialog.getListView();int index=-1;for(int i=0;i<choices.getAdapter().getCount();i++)if(choices.getAdapter().getItem(i).toString().equals("Creadores"))index=i;assertTrue(index>=0);choices.performItemClick(null,index,index);
            dialog=(AlertDialog)ShadowDialog.getLatestDialog();ListView terms=(ListView)find(dialog.getWindow().getDecorView(),v->v instanceof ListView);assertEquals(1,terms.getAdapter().getCount());assertTrue(terms.getAdapter().getItem(0).toString().contains("Luz, Mar"));terms.performItemClick(null,0,0);idle();assertEquals(1,grid(activity).getAdapter().getItemCount());controller.recreate();idle();activity=controller.get();assertTrue(((Button)activity.findViewById(R.id.scope)).getText().toString().contains("Luz, Mar"));assertEquals(1,grid(activity).getAdapter().getItemCount());
        }
    }
    @Test public void readerUsesImportedTitleAndKeepsItsReadingProgressIndependent()throws Exception {
        db.library().forgetMedia("root");MediaEntry m=new MediaEntry();m.id="a";m.name="a.txt";m.title="a";m.root="root";m.folder="Set";m.bytes=7;m.mediaType=MediaRules.OTHER;m.uri=ReaderSessionTest.register("catalog-text","Lectura".getBytes(java.nio.charset.StandardCharsets.UTF_8)).toString();db.library().insertMedia(m);
        var json=CatalogFixture.json();json.getJSONObject("tables").getJSONArray("asset").getJSONObject(0).put("path","R:/Media/Set/a.txt").put("size",7).put("catalog_title","Texto de catálogo");CatalogBridge.apply(db,CatalogBridge.preview(db.library(),CatalogTransfer.validate(json),new CatalogBridge.Options("Texto","R:/Media","root")));
        ReaderActivity activity;try(var controller=Robolectric.buildActivity(ReaderActivity.class,new android.content.Intent(RuntimeEnvironment.getApplication(),ReaderActivity.class).putExtra("mediaId","a")).setup().visible()) {
            activity=controller.get();idle();java.util.concurrent.Future<?> pending=org.robolectric.util.ReflectionHelpers.getField(activity,"pending");assertNotNull(pending);pending.get(30,TimeUnit.SECONDS);idle();assertEquals("Texto de catálogo",((TextView)activity.findViewById(R.id.readerTitle)).getText().toString());assertEquals("Lectura",((TextView)activity.findViewById(R.id.readerText)).getText().toString());assertNotNull(db.library().readerProgress("a"));assertEquals(0,db.library().get("a").position);
        }java.util.concurrent.ExecutorService worker=org.robolectric.util.ReflectionHelpers.getField(activity,"worker");assertTrue(worker.awaitTermination(30,TimeUnit.SECONDS));
    }
}
