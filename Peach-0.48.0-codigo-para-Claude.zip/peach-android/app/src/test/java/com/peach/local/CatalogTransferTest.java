package com.peach.local;

import android.database.sqlite.SQLiteDatabase;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import org.json.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class CatalogTransferTest {
    interface Action {void run()throws Exception;}
    static void rejects(Action action)throws Exception {try{action.run();fail("Expected rejection");}catch(IllegalArgumentException|JSONException expected){}}
    @Test public void projectsActualUpstreamSchemasReadOnlyAndNeverExportsProviderSecrets()throws Exception {
        File file=File.createTempFile("ledger-fixture-",".db",RuntimeEnvironment.getApplication().getCacheDir());
        try {
            try(SQLiteDatabase db=SQLiteDatabase.openOrCreateDatabase(file,null)) {
                db.disableWriteAheadLogging();try(var mode=db.rawQuery("PRAGMA journal_mode=DELETE",null)){assertTrue(mode.moveToFirst());assertEquals("delete",mode.getString(0));}
                for(String script:new String[]{"0000_legacy_schema.sql","0001_core_boundaries.sql","0002_canonical_entities.sql","0017_persistent_playlists.sql"}) {
                    try(InputStream in=getClass().getClassLoader().getResourceAsStream("original/"+script)){assertNotNull(in);for(String sql:new String(in.readAllBytes(),StandardCharsets.UTF_8).split(";"))if(!sql.isBlank())db.execSQL(sql);}
                }
                try(InputStream in=getClass().getClassLoader().getResourceAsStream("original/0025_agency_entities.sql")) {
                    assertNotNull(in);String sql=new String(in.readAllBytes(),StandardCharsets.UTF_8);
                    for(String table:new String[]{"entity_new","entity_membership"}){java.util.regex.Matcher match=java.util.regex.Pattern.compile("CREATE TABLE "+table+"\\(.*?\\);",java.util.regex.Pattern.DOTALL).matcher(sql);assertTrue(match.find());db.execSQL(match.group());if(table.equals("entity_new")){db.execSQL("DROP TABLE entity");db.execSQL("ALTER TABLE entity_new RENAME TO entity");}}
                }
                for(String script:new String[]{"0018_online_follow.sql","0042_want_list.sql"})try(InputStream in=getClass().getClassLoader().getResourceAsStream("original/"+script)) {
                    assertNotNull(in);String sql=new String(in.readAllBytes(),StandardCharsets.UTF_8);
                    for(String table:script.startsWith("0018")?new String[]{"follow_source","follow_item"}:new String[]{"want_item"}){var matcher=java.util.regex.Pattern.compile("CREATE TABLE (?:IF NOT EXISTS )?"+table+"\\(.*?\\);",java.util.regex.Pattern.DOTALL).matcher(sql);assertTrue(matcher.find());db.execSQL(matcher.group());}
                }
                db.execSQL("INSERT INTO follow_source(id,provider,ref,label,url,metadata_json,created_at,updated_at) VALUES(1,'P','author','Autor','https://example.org','{\"secret\":\"PRIVATE_FEED_TOKEN\"}','now','now')");
                db.execSQL("INSERT INTO follow_item(id,source_id,external_id,title,published_at,release_key,first_seen_at,last_seen_at) VALUES(1,1,'post','Entrega','2026-10-01','work','now','now')");
                db.execSQL("INSERT INTO want_item(id,follow_item_id,origin,title,created_at,updated_at) VALUES(1,1,'follow','Deseo','now','now')");
                db.execSQL("INSERT INTO source(id,password,url) VALUES(1,'PRIVATE_PASSWORD','https://private.example')");
                db.execSQL("INSERT INTO asset(id,location,path,name,size,source_id,code) VALUES(1,'disk','R:\\Media\\a.mp4','a.mp4',123,1,'CAM-1')");
                db.execSQL("INSERT INTO entity VALUES(11,'performer','Ana','ana','{}','now','now')");
                db.execSQL("INSERT INTO entity VALUES(12,'agency','Agencia Campo','agencia campo','{}','now','now')");
                db.execSQL("INSERT INTO entity_membership VALUES(11,12,'manual',0.7,'2026-10-24')");
                db.execSQL("INSERT INTO entity_alias VALUES(11,'Alba','alba','manual',0.8)");
                db.execSQL("INSERT INTO entity_external_ref(entity_id,provider,external_kind,external_id,metadata_json) VALUES(11,'P','person','12','{\"secret\":\"PRIVATE_TOKEN\"}')");
                db.execSQL("INSERT INTO asset_entity(asset_id,entity_id,role,source) VALUES(1,11,'performer','manual')");
                db.execSQL("INSERT INTO playlist VALUES(21,'local','Lista','manual',NULL,NULL,'now','now')");
                db.execSQL("INSERT INTO playlist_item VALUES(21,1,0,'now')");
            }
            byte[] before=MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(file.toPath()));CatalogTransfer transfer=CatalogTransfer.fromDatabase(file);
            assertArrayEquals(before,MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(file.toPath())));
            JSONObject tables=transfer.json().getJSONObject("tables");assertEquals("CAM-1",tables.getJSONArray("asset").getJSONObject(0).getString("code"));assertEquals(0.8,tables.getJSONArray("entity_alias").getJSONObject(0).getDouble("confidence"),0);
            assertEquals(1,tables.getJSONArray("playlist_item").length());assertFalse(transfer.encoded().contains("PRIVATE_"));assertFalse(transfer.encoded().contains("private.example"));
            assertEquals(12,tables.getJSONArray("entity_membership").getJSONObject(0).getLong("agency_id"));assertEquals(0.7,tables.getJSONArray("entity_membership").getJSONObject(0).getDouble("confidence"),0);
            assertEquals(1,tables.getJSONArray("follow_item").length());assertEquals("wanted",tables.getJSONArray("want_item").getJSONObject(0).getString("state"));
            assertEquals(transfer.encoded(),CatalogTransfer.parse(new ByteArrayInputStream(transfer.encoded().getBytes(StandardCharsets.UTF_8))).encoded());
        }finally{SQLiteDatabase.deleteDatabase(file);}
    }
    @Test public void rejectsViewsAndWalDependentAndNonSqliteInputs()throws Exception {
        File file=File.createTempFile("ledger-bad-",".db",RuntimeEnvironment.getApplication().getCacheDir());
        try {
            try(SQLiteDatabase db=SQLiteDatabase.openOrCreateDatabase(file,null)){db.execSQL("CREATE VIEW asset AS SELECT 1 AS id,'disk' AS location,'R:/a' AS path");}
            rejects(()->CatalogTransfer.fromDatabase(file));
            try(RandomAccessFile out=new RandomAccessFile(file,"rw")){out.seek(18);out.write(new byte[]{2,2});}
            rejects(()->CatalogTransfer.fromDatabase(file));Files.write(file.toPath(),"not sqlite".getBytes(StandardCharsets.UTF_8));rejects(()->CatalogTransfer.fromDatabase(file));
        }finally{SQLiteDatabase.deleteDatabase(file);}
    }
    @Test public void rejectsBadVersionTypesDuplicatesDanglingReferencesAndUnboundedFields()throws Exception {
        for(Object version:new Object[]{"1",1.5,2,-1}){JSONObject json=CatalogFixture.json().put("version",version);rejects(()->CatalogTransfer.validate(json));}
        JSONObject duplicate=CatalogFixture.json();var rows=duplicate.getJSONObject("tables").getJSONArray("asset");rows.put(rows.getJSONObject(0));rejects(()->CatalogTransfer.validate(duplicate));
        JSONObject dangling=CatalogFixture.json();dangling.getJSONObject("tables").getJSONArray("asset_entity").getJSONObject(0).put("entity_id",999);rejects(()->CatalogTransfer.validate(dangling));
        JSONObject field=CatalogFixture.json();field.getJSONObject("tables").getJSONArray("asset").getJSONObject(0).put("path","a".repeat(4097));rejects(()->CatalogTransfer.validate(field));
        JSONObject fractional=CatalogFixture.json();fractional.getJSONObject("tables").getJSONArray("asset").getJSONObject(0).put("id",1.5);rejects(()->CatalogTransfer.validate(fractional));
        rejects(()->CatalogTransfer.parse(new ByteArrayInputStream(new byte[CatalogTransfer.MAX_BYTES+1])));
    }
    @Test public void dropsUnknownFieldsAndTablesAndPreservesNamesAsAtomicValues()throws Exception {
        JSONObject json=CatalogFixture.json(),tables=json.getJSONObject("tables");tables.put("credentials",new JSONArray().put("PRIVATE"));tables.getJSONArray("asset").getJSONObject(0).put("password","PRIVATE");tables.getJSONArray("entity").getJSONObject(0).put("canonical_name","Rivera, Ana");
        CatalogTransfer transfer=CatalogTransfer.validate(json);assertFalse(transfer.encoded().contains("PRIVATE"));assertEquals("Rivera, Ana",transfer.json().getJSONObject("tables").getJSONArray("entity").getJSONObject(0).getString("canonical_name"));
    }
    @Test public void contentUriCopyIsRemovedOnSuccessfulJsonReadAndOnMalformedInput()throws Exception {
        var context=RuntimeEnvironment.getApplication();java.util.function.Supplier<Long> count=()->java.util.Arrays.stream(context.getCacheDir().listFiles()).filter(f->f.getName().startsWith("peach-catalog-")).count();long before=count.get();
        var good=ReaderSessionTest.register("catalog-good",CatalogFixture.transfer().encoded().getBytes(StandardCharsets.UTF_8));assertEquals(3,CatalogTransfer.open(context,good).json().getJSONObject("tables").getJSONArray("asset").length());assertEquals(before,count.get().longValue());
        var bad=ReaderSessionTest.register("catalog-bad","invalid database".getBytes(StandardCharsets.UTF_8));rejects(()->CatalogTransfer.open(context,bad));assertEquals(before,count.get().longValue());
    }
    @Test public void invalidUtf8AndOversizedDatabaseCannotEnterTheCatalog()throws Exception {
        try{CatalogTransfer.parse(new ByteArrayInputStream(new byte[]{'{','"','x','"',':','"',(byte)0xff,'"','}'}));fail();}catch(java.nio.charset.CharacterCodingException expected){}
        File file=File.createTempFile("oversized-ledger-",".db",RuntimeEnvironment.getApplication().getCacheDir());try{try(RandomAccessFile out=new RandomAccessFile(file,"rw")){out.setLength(CatalogTransfer.MAX_DATABASE+1);}rejects(()->CatalogTransfer.fromDatabase(file));}finally{file.delete();}
    }
}
