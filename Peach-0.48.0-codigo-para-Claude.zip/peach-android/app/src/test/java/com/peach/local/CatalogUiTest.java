package com.peach.local;

import android.os.Looper;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.room.Room;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowDialog;
import org.robolectric.util.ReflectionHelpers;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class CatalogUiTest {
    LibraryDatabase db;
    @Before public void open(){db=Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",db);LibraryRoot root=new LibraryRoot();root.uri="root";root.label="Tablet";root.state=0;db.library().addRoot(root);MediaEntry m=new MediaEntry();m.id="a";m.name="a.mp4";m.folder="Set";m.root="root";m.bytes=123;db.library().insertMedia(m);}
    @After public void close()throws Exception{idle();db.close();ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);}
    void idle()throws Exception{for(int i=0;i<3;i++){LibraryDatabase.IO.submit(()->{}).get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}}
    Button button(CatalogActivity activity,String text){return (Button)find(activity.getWindow().getDecorView(),v->v instanceof Button b && b.getText().toString().equals(text));}
    View find(View view,java.util.function.Predicate<View> predicate){if(predicate.test(view))return view;if(view instanceof ViewGroup g)for(int i=0;i<g.getChildCount();i++){View match=find(g.getChildAt(i),predicate);if(match!=null)return match;}return null;}
    CatalogActivity.Draft load(CatalogActivity activity)throws Exception{idle();CatalogActivity.Draft draft=ReflectionHelpers.getField(activity,"draft");draft.transfer=CatalogFixture.transfer();draft.source="UI origen";draft.prefix="R:/Media";draft.root="root";draft.notifyChange();idle();return draft;}
    @Test public void nativeReviewSearchesCodesAndRequiresConfirmationBeforeAddingGraph()throws Exception {
        try(var controller=Robolectric.buildActivity(CatalogActivity.class).setup().visible()) {
            CatalogActivity activity=controller.get();load(activity);EditText search=(EditText)find(activity.getWindow().getDecorView(),v->v instanceof EditText e && e.getHint().toString().startsWith("Buscar"));search.setText("CAM-1");
            ListView list=(ListView)find(activity.getWindow().getDecorView(),v->v instanceof ListView);assertEquals(1,list.getAdapter().getCount());search.setText("");button(activity,"Vista previa").performClick();idle();assertTrue(button(activity,"Importar lo revisado").isEnabled());
            assertTrue(db.library().entities().isEmpty());button(activity,"Importar lo revisado").performClick();assertTrue(db.library().snapshots().isEmpty());AlertDialog dialog=(AlertDialog)ShadowDialog.getLatestDialog();dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick();idle();assertEquals(1,db.library().entities().size());assertEquals(1,db.library().snapshots().size());assertEquals(1,db.library().entityLinks().size());
        }
    }
    @Test public void editingMappingInvalidatesPreviewAndRotationRetainsLoadedDataAndOptions()throws Exception {
        try(var controller=Robolectric.buildActivity(CatalogActivity.class).setup().visible()) {
            CatalogActivity activity=controller.get();load(activity);button(activity,"Vista previa").performClick();idle();assertTrue(button(activity,"Importar lo revisado").isEnabled());
            EditText prefix=ReflectionHelpers.getField(activity,"prefix");prefix.setText("R:/Elsewhere");assertFalse(button(activity,"Importar lo revisado").isEnabled());controller.recreate();idle();activity=controller.get();CatalogActivity.Draft draft=ReflectionHelpers.getField(activity,"draft");assertNotNull(draft.transfer);assertEquals("R:/Elsewhere",draft.prefix);assertEquals("UI origen",draft.source);assertFalse(button(activity,"Importar lo revisado").isEnabled());
        }
    }
    @Test public void savedSnapshotsCanBeConsultedAndExportStartsNativeDocumentPicker()throws Exception {
        CatalogBridge.apply(db,CatalogBridge.preview(db.library(),CatalogFixture.transfer(),new CatalogBridge.Options("Guardado","","")));
        try(var controller=Robolectric.buildActivity(CatalogActivity.class).setup().visible()) {
            CatalogActivity activity=controller.get();idle();button(activity,"Catálogos guardados").performClick();AlertDialog dialog=(AlertDialog)ShadowDialog.getLatestDialog();dialog.getListView().performItemClick(null,0,0);idle();assertTrue(button(activity,"Exportar JSON").isEnabled());button(activity,"Exportar JSON").performClick();var intent=Shadows.shadowOf(activity).getNextStartedActivityForResult().intent;assertEquals(android.content.Intent.ACTION_CREATE_DOCUMENT,intent.getAction());assertEquals("application/json",intent.getType());
        }
    }
}
