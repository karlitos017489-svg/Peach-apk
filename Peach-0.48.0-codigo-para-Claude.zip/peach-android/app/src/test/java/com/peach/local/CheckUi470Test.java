package com.peach.local;

import android.app.Activity;
import android.content.*;
import android.net.Uri;
import android.os.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.android.controller.ActivityController;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28)
public class CheckUi470Test {
    ActivityController<DeviceCheckActivity> screen;DeviceCheckActivity activity;DeviceCheckActivity.Draft draft;DeviceCheckActivity.Runner old;int calls;
    DeviceChecks.Report report(){return new DeviceChecks.Report("{\"format\":\"peach-device-check\",\"version\":1,\"cancelled\":false,\"checks\":[]}",List.of(),false);}
    @Before public void setup()throws Exception{old=DeviceCheckActivity.runner;DeviceCheckActivity.runner=(a,t,p)->{calls++;return report();};screen=Robolectric.buildActivity(DeviceCheckActivity.class).setup().visible();activity=screen.get();draft=activity.draft;await();}
    @After public void close()throws Exception{if(screen!=null)screen.pause().stop().destroy();draft.token.cancel();draft.worker.shutdown();assertTrue(draft.worker.awaitTermination(30,TimeUnit.SECONDS));DeviceCheckActivity.runner=old;}
    void await()throws Exception{draft.worker.submit(()->{}).get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}
    @Test public void openingAndRotatingOnlyLoadsOwnLastReportWithoutStartingChecks()throws Exception {assertEquals(0,calls);var old=draft;screen.recreate();activity=screen.get();draft=activity.draft;await();assertSame(old,draft);assertEquals(0,calls);assertFalse(draft.busy);}
    @Test public void explicitStartRunsOnceAndNativePickerExportsOnlyAfterSelection()throws Exception {activity.findViewById(R.id.check_start).performClick();await();assertEquals(1,calls);assertNotNull(draft.report);activity.findViewById(R.id.check_save).performClick();var request=Shadows.shadowOf(activity).getNextStartedActivityForResult();assertEquals(Intent.ACTION_CREATE_DOCUMENT,request.intent.getAction());assertEquals("application/json",request.intent.getType());Uri uri=Uri.parse("content://own.check.ui/new");ByteArrayOutputStream out=new ByteArrayOutputStream();Shadows.shadowOf(activity.getContentResolver()).registerOutputStream(uri,out);Shadows.shadowOf(activity.getContentResolver()).registerInputStreamSupplier(uri,()->new ByteArrayInputStream(out.toByteArray()));activity.getActivityResultRegistry().dispatchResult(request.requestCode,Activity.RESULT_OK,new Intent().setData(uri));await();assertEquals(report().json(),out.toString("UTF-8"));assertTrue(draft.status.contains("guardado y comprobado"));}
    @Test public void rotatingKeepsRunningCheckAndLeavingCancelsIt()throws Exception {CountDownLatch entered=new CountDownLatch(1);DeviceCheckActivity.runner=(a,t,p)->{calls++;entered.countDown();while(!t.cancelled.get())try{Thread.sleep(5);}catch(InterruptedException e){Thread.currentThread().interrupt();break;}t.check();return report();};activity.findViewById(R.id.check_start).performClick();assertTrue(entered.await(10,TimeUnit.SECONDS));screen.recreate();activity=screen.get();draft=activity.draft;assertFalse(draft.token.cancelled.get());assertEquals(1,calls);screen.pause().stop();await();assertTrue(draft.token.cancelled.get());assertFalse(draft.busy);screen.start().resume().visible();}
    @Test public void cancelingReportPickerPreservesLocalResultAndDoesNotRerunChecks()throws Exception {activity.findViewById(R.id.check_start).performClick();await();activity.findViewById(R.id.check_save).performClick();var request=Shadows.shadowOf(activity).getNextStartedActivityForResult();activity.getActivityResultRegistry().dispatchResult(request.requestCode,Activity.RESULT_CANCELED,null);await();assertEquals(1,calls);assertNotNull(draft.report);assertFalse(draft.picking);assertTrue(draft.status.contains("local se conserva"));}
}
