package com.peach.local;
import java.io.*;
import java.nio.file.*;
import org.junit.*;
import static org.junit.Assert.*;
public class CumstDownloadTest {
    static final String URL="https://e1.cum.st/media/own/key/original.txt";
    @Test public void directCopyUsesLengthAndComputedHashWithoutInventingExpectedContentHash()throws Exception{File f=File.createTempFile("cumst-own-",".tmp");try{var d=SourceHttp.copyAttachment(URL,new ByteArrayInputStream("abc".getBytes()),f,3,new SourceHttp.Token());assertEquals(PawchiveDownloadTest.HASH,d.sha256());assertArrayEquals("abc".getBytes(),Files.readAllBytes(f.toPath()));}finally{f.delete();}}
    @Test public void redirectCannotSwitchProviderNodeOrMediaPath()throws Exception{SourceHttp.attachmentRedirect(URL,URL);for(String next:new String[]{URL.replace("e1.","e2."),URL.replace("original.txt","another.txt"),PawchiveDownloadTest.URL,"https://downloads.fanbox.cc/a"})PawchiveDownloadTest.rejects(()->SourceHttp.attachmentRedirect(URL,next));PawchiveDownloadTest.rejects(()->SourceHttp.attachmentRedirect(PawchiveDownloadTest.URL,URL));PawchiveDownloadTest.rejects(()->SourceHttp.attachmentRedirect("https://downloads.fanbox.cc/a",URL));}
    @Test public void declaredCapabilityRequiredAndLegacyPawchiveStillWorks(){assertTrue(SourceHttp.canSave(URL,true));assertFalse(SourceHttp.canSave(URL,false));assertTrue(SourceHttp.canSave(PawchiveDownloadTest.URL,false));assertFalse(SourceHttp.canSave("https://cum.st/media/own/key/original.txt",true));}
    @Test public void cancellationTruncationAndBudgetFailureCloseAndDeletePrivateOutput()throws Exception{for(int mode=0;mode<3;mode++){File f=File.createTempFile("cumst-own-",".tmp");boolean[] closed={false};InputStream in=new ByteArrayInputStream("abc".getBytes()){@Override public void close(){closed[0]=true;}};SourceHttp.Token token=new SourceHttp.Token();if(mode==0)token.cancel();int expected=mode==1?4:3,limit=mode==2?2:4;PawchiveDownloadTest.rejects(()->SourceHttp.copyAttachment(URL,in,f,expected,token,limit));assertFalse(f.exists());assertTrue(closed[0]);}}
}
