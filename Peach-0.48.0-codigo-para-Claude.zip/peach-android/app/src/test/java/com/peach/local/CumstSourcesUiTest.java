package com.peach.local;

import android.os.Looper;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.room.Room;
import java.util.concurrent.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowDialog;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land") @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class CumstSourcesUiTest {
    LibraryDatabase db;SourcesActivity activity;SourceHttp.Transport previous;int calls;
    byte[] fixture(String url){try{return (url.contains("/post/")?CumstConnectorTest.post("1"):CumstConnectorTest.posts(1)).toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);}catch(Exception e){throw new AssertionError(e);}}
    @Before public void open(){db=Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",db);previous=SourcesActivity.transport;SourcesActivity.transport=(u,e,m,t)->{calls++;return new SourceHttp.Response(200,fixture(u),"","");};}
    @After public void close()throws Exception{if(activity!=null){var draft=new androidx.lifecycle.ViewModelProvider(activity).get(SourcesActivity.Draft.class);draft.token.cancel();draft.worker.shutdown();assertTrue(draft.worker.awaitTermination(30,TimeUnit.SECONDS));}SourcesActivity.transport=previous;db.close();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);}
    void idle()throws Exception{var d=new androidx.lifecycle.ViewModelProvider(activity).get(SourcesActivity.Draft.class);for(int i=0;i<3;i++){d.worker.submit(()->{}).get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}}
    AlertDialog dialog(){Shadows.shadowOf(Looper.getMainLooper()).idle();return (AlertDialog)ShadowDialog.getLatestDialog();}
    View find(View v,java.util.function.Predicate<View> p){if(p.test(v))return v;if(v instanceof ViewGroup g)for(int i=0;i<g.getChildCount();i++){View found=find(g.getChildAt(i),p);if(found!=null)return found;}return null;}
    Button button(String label){return (Button)find(activity.getWindow().getDecorView(),v->v instanceof Button b && label.contentEquals(b.getText()));}
    @Test public void providerSelectorCreatesCumstWithoutNetworkAndQueriesOnlyAfterButton()throws Exception{try(var c=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){activity=c.get();idle();button("Añadir fuente").performClick();Spinner providers=(Spinner)find(dialog().getWindow().getDecorView(),v->v instanceof Spinner s && "Proveedor de contenido".contentEquals(s.getContentDescription()));providers.setSelection(4);Shadows.shadowOf(Looper.getMainLooper()).idle();EditText ref=(EditText)find(dialog().getWindow().getDecorView(),v->v instanceof EditText e && "Creador cum.st".contentEquals(e.getContentDescription()));assertNotNull(ref);ref.setText("patreon/123");dialog().getButton(AlertDialog.BUTTON_POSITIVE).performClick();idle();assertEquals("cumst",db.library().sources().get(0).provider);assertEquals(0,calls);assertFalse(button("Página más antigua").isEnabled());button("Consultar novedades").performClick();idle();assertEquals(1,calls);assertTrue(db.library().publications().isEmpty());button("Importar página revisada").performClick();dialog().getButton(AlertDialog.BUTTON_POSITIVE).performClick();idle();assertEquals("cumst",db.library().publications().get(0).provider);}}
    @Test public void partialContentOffersExplicitDetailAndReferenceActionWithoutAutomaticFetch()throws Exception{SourceStore store=new SourceStore(db,SourcesActivity.transport);String id=store.create("cumst","patreon/123","cum.st",null);store.fetch(id,false,new SourceHttp.Token());calls=0;try(var c=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){activity=c.get();idle();ListView list=(ListView)find(activity.getWindow().getDecorView(),v->v instanceof ListView);list.performItemClick(null,0,0);assertEquals("Consultar cuerpo",dialog().getButton(AlertDialog.BUTTON_POSITIVE).getText().toString());assertEquals("Guardar adjunto",dialog().getButton(AlertDialog.BUTTON_NEUTRAL).getText().toString());assertNotNull(find(dialog().getWindow().getDecorView(),v->v instanceof TextView t && t.getText().toString().contains("Texto propio")));dialog().getButton(AlertDialog.BUTTON_NEGATIVE).performClick();c.recreate();activity=c.get();idle();assertEquals(0,calls);assertFalse(button("Página más antigua").isEnabled());}}
}
