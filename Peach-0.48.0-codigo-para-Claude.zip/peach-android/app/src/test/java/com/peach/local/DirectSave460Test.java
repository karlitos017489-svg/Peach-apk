package com.peach.local;

import android.app.Activity;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;
import org.robolectric.shadows.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land")
public class DirectSave460Test {
    ActivityController<DirectSaveActivity> screen;DirectSaveActivity activity;DirectSaveActivity.Draft draft;DirectSaveActivity.Fetcher old;int calls;ByteArrayOutputStream bytes;
    @Before public void setup()throws Exception{old=DirectSaveActivity.fetcher;DirectSaveActivity.Draft.ACTIVE.set(false);RuntimeEnvironment.getApplication().getSharedPreferences("direct-save-recovery",0).edit().clear().commit();DirectSaveActivity.fetcher=(u,h,d,t,p)->{calls++;return DirectTransfer.copy(new ByteArrayInputStream("own attachment".getBytes()),14,"",false,d,t,p,100);};screen=Robolectric.buildActivity(DirectSaveActivity.class,DirectSaveActivity.intent(RuntimeEnvironment.getApplication(),DownloadFlowTest.URL,"own.mp4",""));screen.setup().visible();activity=screen.get();draft=activity.draft;for(var item:draft.journal.items())draft.journal.remove(item.id());}
    @After public void close()throws Exception{if(screen!=null)screen.pause().stop().destroy();if(draft!=null){draft.token.cancel();draft.worker.shutdown();assertTrue(draft.worker.awaitTermination(30,TimeUnit.SECONDS));}DirectSaveActivity.fetcher=old;DirectSaveActivity.Draft.ACTIVE.set(false);}
    void idle(){Shadows.shadowOf(Looper.getMainLooper()).idle();}
    void await()throws Exception{draft.worker.submit(()->{}).get(30,TimeUnit.SECONDS);idle();}
    org.robolectric.shadows.ShadowActivity.IntentForResult choose(){activity.findViewById(R.id.direct_choose).performClick();var next=Shadows.shadowOf(activity).getNextStartedActivityForResult();assertNotNull(next);return next;}
    Uri output(){Uri uri=Uri.parse("content://own.direct/document/"+UUID.randomUUID());bytes=new ByteArrayOutputStream();Shadows.shadowOf(activity.getContentResolver()).registerOutputStream(uri,bytes);return uri;}
    void result(org.robolectric.shadows.ShadowActivity.IntentForResult next,Uri uri){activity.getActivityResultRegistry().dispatchResult(next.requestCode,Activity.RESULT_OK,new Intent().setData(uri));}
    @Test public void openingAndChoosingDestinationNeverFetchBeforePickerResult(){assertEquals(0,calls);var next=choose();assertEquals(Intent.ACTION_CREATE_DOCUMENT,next.intent.getAction());assertTrue(next.intent.hasCategory(Intent.CATEGORY_OPENABLE));assertEquals("video/mp4",next.intent.getType());assertEquals(0,calls);assertTrue(draft.picking);}
    @Test public void selectingProviderWritesDirectlyAndDoesNotCreateAppMediaCache()throws Exception {var next=choose();Uri uri=output();Set<String> before=new HashSet<>(Arrays.asList(draft.getApplication().getCacheDir().list()));result(next,uri);await();assertEquals(1,calls);assertEquals("own attachment",bytes.toString("UTF-8"));assertTrue(draft.status,draft.status.contains("entregado al proveedor"));assertFalse(draft.busy);assertTrue(draft.journal.items().isEmpty());assertEquals(before,new HashSet<>(Arrays.asList(draft.getApplication().getCacheDir().list())));}
    @Test public void rotationWhilePickerOpenKeepsOneExplicitPendingChoice()throws Exception {var next=choose();var retained=draft;screen.recreate();activity=screen.get();draft=activity.draft;idle();assertSame(retained,draft);result(next,output());await();assertEquals(1,calls);assertEquals(14,bytes.size());}
    @Test public void cancelledPickerDoesNotFetchOrCreateRecoveryRecord()throws Exception {var next=choose();activity.getActivityResultRegistry().dispatchResult(next.requestCode,Activity.RESULT_CANCELED,null);idle();assertEquals(0,calls);assertTrue(draft.journal.items().isEmpty());assertFalse(draft.picking);}
    @Test public void failureDeletesExactlyNewDocumentAndKeepsOtherDocuments()throws Exception {AtomicReference<Uri> removed=new AtomicReference<>();ShadowContentResolver.registerProviderInternal("own.direct.delete",new DownloadFlowTest.DeletingProvider(){@Override public Bundle call(String method,String arg,Bundle extras){if(method.equals("android:deleteDocument"))removed.set(extras.getParcelable("uri"));return super.call(method,arg,extras);}});DirectSaveActivity.fetcher=(u,h,d,t,p)->{throw new IOException("Own network failure");};var next=choose();Uri uri=Uri.parse("content://own.direct.delete/document/new");result(next,uri);await();assertEquals(uri,removed.get());assertTrue(draft.journal.items().isEmpty());assertTrue(draft.status.contains("retirado"));}
    @Test public void undeletableInterruptedTargetIsRetainedAndNeverAutomaticallyResumed()throws Exception {DirectSaveActivity.fetcher=(u,h,d,t,p)->{calls++;throw new IOException("Own failure");};var next=choose();Uri uri=output();result(next,uri);await();assertEquals(1,calls);assertEquals(uri.toString(),draft.journal.items().get(0).uri());assertTrue(draft.status.contains("incompleto"));screen.recreate();activity=screen.get();draft=activity.draft;idle();assertEquals(1,calls);assertEquals(1,new DirectSaveJournal(draft.getApplication()).items().size());}
    @Test public void leavingScreenCancelsAndRotationDoesNotCancelActiveTransfer()throws Exception {CountDownLatch entered=new CountDownLatch(1);DirectSaveActivity.fetcher=(u,h,d,t,p)->{calls++;entered.countDown();while(!t.cancelled){try{Thread.sleep(5);}catch(InterruptedException e){Thread.currentThread().interrupt();break;}}t.check();throw new AssertionError();};var next=choose();result(next,output());assertTrue(entered.await(10,TimeUnit.SECONDS));screen.recreate();activity=screen.get();draft=activity.draft;assertFalse(draft.token.cancelled);screen.pause().stop();await();assertTrue(draft.token.cancelled);assertEquals(1,calls);screen.start().resume().visible();}
    @Test public void journalQuotaAndExplicitRemovalPreserveEveryOtherTarget()throws Exception {var journal=draft.journal;for(int i=0;i<16;i++)journal.add(Uri.parse("content://own.direct/document/"+i),"own "+i);try{journal.add(output(),"overflow");fail();}catch(IOException expected){}var first=journal.items().get(0);new DirectSaveJournal(draft.getApplication()).remove(first.id());assertEquals(15,journal.items().size());assertTrue(journal.items().stream().noneMatch(i->i.id().equals(first.id())));}
}
