package com.peach.local;

import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28)
public class DirectTransfer460Test {
    byte[] bytes;SourceHttp.Token token;ByteArrayOutputStream output;int opens;
    @Before public void setup(){bytes=new byte[200000];new Random(460).nextBytes(bytes);token=new SourceHttp.Token();output=new ByteArrayOutputStream();}
    DirectTransfer.Destination dest(){return ()->{opens++;return output;};}
    interface Job{void run()throws Exception;}
    void rejects(Job job)throws Exception{try{job.run();fail("Expected a transfer failure");}catch(IOException expected){}}
    DirectTransfer.Result copy(long declared,String hash,boolean video,long limit)throws Exception{return DirectTransfer.copy(new ByteArrayInputStream(bytes),declared,hash,video,dest(),token,(n,t)->{},limit);}
    @Test public void writesIncrementallyBeforeReadingEntireInputAndUsesBoundedChunks()throws Exception {
        AtomicLong reads=new AtomicLong();AtomicInteger largest=new AtomicInteger();ByteArrayInputStream input=new ByteArrayInputStream(bytes){@Override public synchronized int read(byte[] b,int o,int n){int got=super.read(b,o,n);if(got>0)reads.addAndGet(got);return got;}};
        var result=DirectTransfer.copy(input,bytes.length,"",false,()->{assertEquals(4096,reads.get());return new FilterOutputStream(output){@Override public void write(byte[] b,int o,int n)throws IOException{largest.accumulateAndGet(n,Math::max);out.write(b,o,n);}};},token,(n,t)->{assertTrue(n<=bytes.length);assertEquals(bytes.length,t);},SourceHttp.LARGE_DOWNLOAD_LIMIT);
        assertArrayEquals(bytes,output.toByteArray());assertEquals(bytes.length,result.bytes());assertEquals(GalleryCache.hex(GalleryCache.digest(bytes)),result.sha256());assertTrue(largest.get()<=65536);
    }
    @Test public void unknownLengthStillRequiresNonemptyBodyAndComputesActualHash()throws Exception {assertEquals(bytes.length,copy(-1,GalleryCache.hex(GalleryCache.digest(bytes)),false,300000).bytes());assertEquals(1,opens);bytes=new byte[0];rejects(()->copy(-1,"",false,100));}
    @Test public void announcedOversizeNeverOpensProvider()throws Exception {rejects(()->copy(bytes.length,"",false,10000));assertEquals(0,opens);}
    @Test public void unknownLengthOverflowStopsBeforeWritingBeyondLimit()throws Exception {rejects(()->copy(-1,"",false,5000));assertEquals(4096,output.size());}
    @Test public void truncationAndExtraBytesAreBothRejected()throws Exception {rejects(()->copy(bytes.length+1,"",false,300000));output.reset();rejects(()->copy(bytes.length-1,"",false,300000));assertTrue(output.size()<bytes.length);}
    @Test public void htmlAndUnrecognizedVideoNeverOpenDestination()throws Exception {bytes="<!DOCTYPE html><html>own error</html>".getBytes();rejects(()->copy(-1,"",false,1000));assertEquals(0,opens);bytes=new byte[]{1,2,3};rejects(()->copy(-1,"",true,1000));assertEquals(0,opens);}
    @Test public void expectedHashMismatchRejectsEvenAfterWritingProvider()throws Exception {rejects(()->copy(bytes.length,"0".repeat(64),false,300000));assertEquals(bytes.length,output.size());}
    @Test public void cancellationBeforeStartDoesNotOpenOrRead()throws Exception {token.cancel();rejects(()->copy(bytes.length,"",false,300000));assertEquals(0,opens);}
    @Test public void cancellationDuringWriteClosesOutputAndNeverReturnsSuccess()throws Exception {AtomicBoolean closed=new AtomicBoolean();rejects(()->DirectTransfer.copy(new ByteArrayInputStream(bytes),bytes.length,"",false,()->new FilterOutputStream(output){@Override public void write(byte[] b,int o,int n)throws IOException{out.write(b,o,n);token.cancel();}@Override public void close()throws IOException{closed.set(true);super.close();}},token,(n,t)->{},300000));assertTrue(closed.get());assertTrue(output.size()<bytes.length);}
    @Test public void providerCloseFailureAndCancellationAtCloseAreNotSuccess()throws Exception {
        for(boolean cancel:new boolean[]{false,true}){token=new SourceHttp.Token();rejects(()->DirectTransfer.copy(new ByteArrayInputStream(bytes),bytes.length,"",false,()->new ByteArrayOutputStream(){@Override public void close()throws IOException{if(cancel)token.cancel();else throw new IOException("own provider close");}},token,(n,t)->{},300000));}
    }
    @Test public void redirectsReuseExistingHostAndCredentialPolicyWithoutMediaFiles()throws Exception {
        byte[] own=RedirectHttpTest.own();var first=RedirectHttpTest.redirect(MediaRedirectsTest.CDN);var second=new RedirectHttpTest.Reply(MediaRedirectsTest.CDN,200,null,own);var factory=new RedirectHttpTest.Factory(first,second);
        var result=DirectTransfer.download(MediaRedirectsTest.ORIGINAL,"",dest(),token,(n,t)->{},factory,MediaRedirectsTest.PUBLIC);
        assertArrayEquals(own,output.toByteArray());assertEquals(own.length,result.bytes());assertEquals(2,factory.requests.size());assertTrue(first.closed&&second.closed&&second.inputClosed);assertNull(second.getRequestProperty("Cookie"));assertNull(second.getRequestProperty("Authorization"));assertNull(token.connection);
    }
    @Test public void rejectedRedirectOrServerPageNeverOpensOutput()throws Exception {
        var first=RedirectHttpTest.redirect("http://router.local/file.mp4");rejects(()->DirectTransfer.download(MediaRedirectsTest.ORIGINAL,"",dest(),token,(n,t)->{},new RedirectHttpTest.Factory(first),MediaRedirectsTest.PUBLIC));assertEquals(0,opens);assertTrue(first.closed);
        var page=new RedirectHttpTest.Reply(MediaRedirectsTest.ORIGINAL,200,null,bytes);page.mime="application/json";rejects(()->DirectTransfer.download(MediaRedirectsTest.ORIGINAL,"",dest(),token,(n,t)->{},new RedirectHttpTest.Factory(page),MediaRedirectsTest.PUBLIC));assertEquals(0,opens);assertTrue(page.closed);
    }
    @Test public void pawchiveImmutableHashIsStillMandatory()throws Exception {var reply=new RedirectHttpTest.Reply(PawchiveDownloadTest.URL,200,null,"abd".getBytes());reply.mime="text/plain";rejects(()->DirectTransfer.download(PawchiveDownloadTest.URL,"",dest(),token,(n,t)->{},new RedirectHttpTest.Factory(reply),MediaRedirectsTest.PUBLIC));assertTrue(reply.closed&&reply.inputClosed);assertEquals(3,output.size());}
    @Test public void unsupportedSourceAndMalformedHashAreRejectedWithoutConnection()throws Exception {for(String url:List.of("http://downloads.fanbox.cc/own.bin","https://example.org/own.bin"))rejects(()->DirectTransfer.download(url,"",dest(),token,(n,t)->{},u->{fail("No request");return null;},MediaRedirectsTest.PUBLIC));rejects(()->copy(-1,"NOT-A-HASH",false,300000));assertEquals(0,opens);}
}
