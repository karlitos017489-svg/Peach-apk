package com.peach.local;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.CancellationSignal;
import android.provider.DocumentsContract;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.Shadows;
import org.robolectric.annotation.Config;
import org.robolectric.shadows.ShadowContentResolver;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,manifest=Config.NONE)
public class DocumentScannerTest {
    private static final String AUTHORITY="com.peach.local.fixture.metadata";
    private android.content.ContentResolver resolver;
    private LibraryRoot root;private ScanDirectory directory;
    @Before public void setUp() {
        resolver=RuntimeEnvironment.getApplication().getContentResolver();
        ShadowContentResolver.registerProviderInternal(AUTHORITY,new Provider());
        root=new LibraryRoot();root.uri=DocumentsContract.buildTreeDocumentUri(AUTHORITY,"root").toString();
        directory=new ScanDirectory(root.uri,DocumentsContract.buildDocumentUriUsingTree(Uri.parse(root.uri),"root").toString(),"Videos");
    }
    private void nfo(String xml) {
        Uri uri=DocumentsContract.buildDocumentUriUsingTree(Uri.parse(root.uri),"nfo");
        Shadows.shadowOf(resolver).registerInputStream(uri,new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
    }
    @Test public void scannerMapsExtendedMetadataWithoutImportingNfoPlaybackState() throws Exception {
        nfo("<movie><title>Campo</title><director>Ana</director><originaltitle>Field</originaltitle><num>CAM-1</num>"+
            "<runtime>90</runtime><playcount>99</playcount><watched>true</watched><resume><position>50</position></resume></movie>");
        var batch=new DocumentScanner(resolver).scan(root,directory,new CancellationSignal());
        assertEquals(1,batch.media().size());assertEquals(0,batch.warnings());
        MediaEntry m=batch.media().get(0);assertEquals("Campo",m.title);assertEquals("Ana",m.details().get("directors"));
        assertEquals("Field",m.details().get("originalTitle"));assertEquals("CAM-1",m.details().get("code"));
        assertEquals("90",m.details().get("runtimeMinutes"));assertEquals(0,m.duration);assertEquals(0,m.position);
        assertEquals(0,m.playCount);assertFalse(m.watched);assertNull(m.userTitle);assertNull(m.userTags);
        assertEquals("content://"+AUTHORITY+"/document/video",m.id);
    }
    @Test public void invalidSidecarKeepsVideoAndReportsWarning() throws Exception {
        nfo("<movie><title>");
        var batch=new DocumentScanner(resolver).scan(root,directory,new CancellationSignal());
        assertEquals(1,batch.warnings());assertEquals(1,batch.media().size());
        assertEquals("campo",batch.media().get(0).title);assertEquals("{}",batch.media().get(0).nfoDetails);
    }
    public static class Provider extends ContentProvider {
        @Override public boolean onCreate() {return true;}
        @Override public Cursor query(Uri uri,String[] projection,String selection,String[] args,String sort) {
            MatrixCursor cursor=new MatrixCursor(projection);
            cursor.addRow(new Object[]{"video","campo.mp4","video/mp4",100L,1L});
            cursor.addRow(new Object[]{"nfo","campo.nfo","text/plain",100L,1L});return cursor;
        }
        @Override public String getType(Uri uri) {return "text/plain";}
        @Override public Uri insert(Uri uri,ContentValues values) {throw new UnsupportedOperationException();}
        @Override public int delete(Uri uri,String selection,String[] args) {throw new UnsupportedOperationException();}
        @Override public int update(Uri uri,ContentValues values,String selection,String[] args) {throw new UnsupportedOperationException();}
    }
    @Test public void scansMixedFolderButKeepsUsedVideoAndAlbumCoversOutOfGallery() throws Exception {
        ShadowContentResolver.registerProviderInternal(AUTHORITY,new MixedProvider());
        var batch=new DocumentScanner(resolver).scan(root,directory,new CancellationSignal());
        assertEquals(3,batch.media().size());assertEquals(1,batch.children().size());
        MediaEntry video=batch.media().stream().filter(m->m.name.equals("movie.mp4")).findFirst().orElseThrow();
        MediaEntry audio=batch.media().stream().filter(m->m.name.equals("song.mp3")).findFirst().orElseThrow();
        MediaEntry image=batch.media().stream().filter(m->m.name.equals("photo.png")).findFirst().orElseThrow();
        assertEquals(MediaRules.VIDEO,video.mediaType);assertTrue(video.poster.endsWith("poster"));
        assertEquals(MediaRules.AUDIO,audio.mediaType);assertTrue(audio.poster.endsWith("album-cover"));assertEquals("[]",audio.subtitles);
        assertEquals(MediaRules.IMAGE,image.mediaType);assertTrue(image.poster.isEmpty());assertEquals(0,image.duration);
        assertEquals(0,batch.warnings());
    }
    @Test public void folderContainingOnlyPicturesIndexesCoverNamedPicture() throws Exception {
        ShadowContentResolver.registerProviderInternal(AUTHORITY,new MixedProvider(){
            @Override public Cursor query(Uri uri,String[] projection,String selection,String[] args,String sort) {
                MatrixCursor c=new MatrixCursor(projection);c.addRow(new Object[]{"cover","cover.jpg","image/jpeg",12L,1L});return c;
            }
        });
        var batch=new DocumentScanner(resolver).scan(root,directory,new CancellationSignal());
        assertEquals(1,batch.media().size());assertEquals(MediaRules.IMAGE,batch.media().get(0).mediaType);
    }
    public static class MixedProvider extends Provider {
        @Override public Cursor query(Uri uri,String[] projection,String selection,String[] args,String sort) {
            MatrixCursor c=new MatrixCursor(projection);
            c.addRow(new Object[]{"video","movie.mp4","video/mp4",100L,1L});
            c.addRow(new Object[]{"poster","movie-poster.jpg","image/jpeg",12L,1L});
            c.addRow(new Object[]{"song","song.mp3","audio/mpeg",100L,1L});
            c.addRow(new Object[]{"album-cover","folder.jpg","image/jpeg",12L,1L});
            c.addRow(new Object[]{"photo","photo.png","image/png",100L,1L});
            c.addRow(new Object[]{"child","Subcarpeta",DocumentsContract.Document.MIME_TYPE_DIR,0L,1L});return c;
        }
    }
    @Test public void catalogsArchivesOtherDocumentsAndVideoReferencesWithoutReadingTheirBytes() throws Exception {
        ShadowContentResolver.registerProviderInternal(AUTHORITY,new Provider(){
            @Override public Cursor query(Uri uri,String[] projection,String selection,String[] args,String sort) {
                MatrixCursor c=new MatrixCursor(projection);
                for(String name:java.util.List.of("album.zip","album.rar","book.pdf","README","disc.iso","link.strm","old.rmvb","movie.srt","movie.nfo","poster.tbn"))
                    c.addRow(new Object[]{name,name,"application/octet-stream",100L,1L});
                return c;
            }
        });
        var batch=new DocumentScanner(resolver).scan(root,directory,new CancellationSignal());
        assertEquals(7,batch.media().size());assertEquals(0,batch.warnings());
        assertEquals(2,batch.media().stream().filter(m->MediaRules.ARCHIVE.equals(m.mediaType)).count());
        assertEquals(2,batch.media().stream().filter(m->MediaRules.OTHER.equals(m.mediaType)).count());
        assertEquals(3,batch.media().stream().filter(m->MediaRules.VIDEO.equals(m.mediaType)).count());
        assertTrue(batch.media().stream().noneMatch(MediaRules::playable));
        assertTrue(batch.media().stream().allMatch(m->m.position==0 && m.playCount==0));
    }
}
