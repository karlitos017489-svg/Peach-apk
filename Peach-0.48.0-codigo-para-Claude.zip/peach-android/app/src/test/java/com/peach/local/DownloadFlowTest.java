package com.peach.local;

import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.os.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.room.Room;
import java.io.*;
import java.nio.file.Files;
import java.util.concurrent.TimeUnit;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.shadows.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land") @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class DownloadFlowTest {
    LibraryDatabase db;SourcesActivity activity;SourcesActivity.AttachmentFetcher previous;int calls;
    static final String URL="https://api-cdn.rule34.xxx/images/1/0123456789abcdef0123456789abcdef.mp4";
    @Before public void open(){db=Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",db);previous=SourcesActivity.attachmentFetcher;}
    @After public void close()throws Exception{if(activity!=null){var d=draft();d.token.cancel();d.worker.shutdown();assertTrue(d.worker.awaitTermination(30,TimeUnit.SECONDS));d.clearPrepared();}SourcesActivity.attachmentFetcher=previous;db.close();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);}
    SourcesActivity.Draft draft(){return new androidx.lifecycle.ViewModelProvider(activity).get(SourcesActivity.Draft.class);}
    void idle()throws Exception{for(int i=0;i<3;i++){draft().worker.submit(()->{}).get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}}
    void choose(String url)throws Exception{PublicationContent c=new PublicationContent();c.attachments=new JSONArray().put(new JSONObject().put("name","own.bin").put("url",url).put("kind","video").put("downloadable",true)).toString();activity.attachments(c);((AlertDialog)ShadowDialog.getLatestDialog()).getListView().performItemClick(null,0,0);((AlertDialog)ShadowDialog.getLatestDialog()).getListView().performItemClick(null,1,1);idle();}
    byte[] mp4()throws Exception{return Files.readAllBytes(new File("src/androidTest/assets/sample.mp4").toPath());}
    @Test public void limitOrNetworkFailureNeverLaunchesCreateDocumentOrEnablesPlayback()throws Exception{
        SourcesActivity.attachmentFetcher=(u,f,t)->{calls++;throw new IOException("Supera el límite propio");};try(var a=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){activity=a.get();idle();choose(URL);assertEquals(1,calls);assertNull(Shadows.shadowOf(activity).getNextStartedActivityForResult());assertNull(draft().prepared);assertTrue(draft().lastVideoUri.isEmpty());assertTrue(SourcesActivity.Draft.activeDownloads.isEmpty());assertTrue(draft().status.contains("límite"));}
    }
    @Test public void bytesAreVerifiedThenPickerUsesDetectedFormatAndCancellationReleasesPrivateFile()throws Exception{
        byte[] bytes=mp4();SourcesActivity.attachmentFetcher=(u,f,t)->{calls++;return SourceHttp.copyAttachment(u,new ByteArrayInputStream(bytes),f,bytes.length,t);};try(var a=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){activity=a.get();idle();choose(URL);var picker=Shadows.shadowOf(activity).getNextStartedActivityForResult();assertEquals(Intent.ACTION_CREATE_DOCUMENT,picker.intent.getAction());assertEquals("video/mp4",picker.intent.getType());assertTrue(picker.intent.getStringExtra(Intent.EXTRA_TITLE).endsWith(".mp4"));File f=draft().prepared;assertArrayEquals(bytes,Files.readAllBytes(f.toPath()));assertEquals(1,calls);activity.getActivityResultRegistry().dispatchResult(picker.requestCode,android.app.Activity.RESULT_CANCELED,null);assertFalse(f.exists());assertNull(draft().prepared);assertTrue(SourcesActivity.Draft.activeDownloads.isEmpty());}
    }
    @Test public void savingPreparedFileDoesNotDownloadAgainAndGifUsesImageViewer()throws Exception{
        byte[] gif=Files.readAllBytes(new File("src/test/resources/media/own-animated.gif").toPath());SourcesActivity.attachmentFetcher=(u,f,t)->{calls++;return SourceHttp.copyAttachment(u,new ByteArrayInputStream(gif),f,gif.length,t);};try(var a=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){activity=a.get();idle();choose(URL);var picker=Shadows.shadowOf(activity).getNextStartedActivityForResult();assertEquals("image/gif",picker.intent.getType());assertTrue(draft().preparedName.endsWith(".gif"));Uri uri=Uri.parse("content://own.fixture/new-gif");ByteArrayOutputStream out=new ByteArrayOutputStream();Shadows.shadowOf(activity.getContentResolver()).registerOutputStream(uri,out);activity.getActivityResultRegistry().dispatchResult(picker.requestCode,android.app.Activity.RESULT_OK,new Intent().setData(uri));idle();assertArrayEquals(gif,out.toByteArray());assertEquals(1,calls);assertEquals("image",draft().lastKind);assertEquals(ImageViewerActivity.class.getName(),SourceFiles.openMedia(activity,uri,draft().lastVideoName,draft().lastKind).getComponent().getClassName());assertTrue(SourcesActivity.Draft.activeDownloads.isEmpty());assertTrue(db.library().allMedia().isEmpty());}
    }
    @Test public void htmlMasqueradingAsVideoNeverOpensSavePicker()throws Exception{
        SourcesActivity.attachmentFetcher=(u,f,t)->SourceHttp.copyAttachment(u,new ByteArrayInputStream("<!doctype html><html>own login page</html>".getBytes()),f,-1,t);try(var a=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){activity=a.get();idle();choose(URL);assertNull(draft().prepared);assertNull(Shadows.shadowOf(activity).getNextStartedActivityForResult());assertTrue(draft().status.contains("página web"));assertTrue(SourcesActivity.Draft.activeDownloads.isEmpty());}
    }
    @Test public void rotationDoesNotRepeatDownloadOrOpenSecondSavePicker()throws Exception{
        byte[] bytes=mp4();SourcesActivity.attachmentFetcher=(u,f,t)->{calls++;return SourceHttp.copyAttachment(u,new ByteArrayInputStream(bytes),f,bytes.length,t);};try(var a=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){activity=a.get();idle();choose(URL);var picker=Shadows.shadowOf(activity).getNextStartedActivityForResult();assertNotNull(picker);File f=draft().prepared;a.recreate();activity=a.get();idle();assertEquals(1,calls);assertEquals(f,draft().prepared);assertTrue(f.exists());assertNull(Shadows.shadowOf(activity).getNextStartedActivityForResult());
            var entered=new java.util.concurrent.CountDownLatch(1);var release=new java.util.concurrent.CountDownLatch(1);draft().work(d->{entered.countDown();if(!release.await(30,TimeUnit.SECONDS))throw new AssertionError("Own reload latch");});assertTrue(entered.await(30,TimeUnit.SECONDS));
            Uri uri=Uri.parse("content://own.fixture/after-rotation");ByteArrayOutputStream out=new ByteArrayOutputStream();Shadows.shadowOf(activity.getContentResolver()).registerOutputStream(uri,out);
            try{activity.getActivityResultRegistry().dispatchResult(picker.requestCode,android.app.Activity.RESULT_OK,new Intent().setData(uri));assertEquals(uri.toString(),draft().pendingSaveUri);assertEquals(0,out.size());}finally{release.countDown();}
            idle();assertArrayEquals(bytes,out.toByteArray());assertEquals(1,calls);assertEquals(uri.toString(),draft().lastVideoUri);assertNull(draft().prepared);assertNull(Shadows.shadowOf(activity).getNextStartedActivityForResult());}
    }
    @Test public void failedSafCopyAttemptsDeletionOnlyOfNewlyCreatedDocument()throws Exception{
        byte[] bytes=mp4();SourcesActivity.attachmentFetcher=(u,f,t)->SourceHttp.copyAttachment(u,new ByteArrayInputStream(bytes),f,bytes.length,t);DeletingProvider.deleted=0;ShadowContentResolver.registerProviderInternal("own.delete",new DeletingProvider());try(var a=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){activity=a.get();idle();draft().prepare(URL,"own.mp4","video");Uri uri=Uri.parse("content://own.delete/document/new");Shadows.shadowOf(activity.getContentResolver()).registerOutputStream(uri,new OutputStream(){public void write(int b)throws IOException{throw new IOException("Own destination full");}});try{draft().savePrepared(uri);fail();}catch(IOException expected){}assertEquals(1,DeletingProvider.deleted);assertTrue(draft().lastVideoUri.isEmpty());assertTrue(SourcesActivity.Draft.activeDownloads.isEmpty());}
    }
    @Test public void lostPreparedFileDoesNotRedownloadAndDeletesEmptyNewDestination()throws Exception{
        SourcesActivity.attachmentFetcher=(u,f,t)->{throw new AssertionError("No automatic request");};DeletingProvider.deleted=0;ShadowContentResolver.registerProviderInternal("own.delete",new DeletingProvider());try(var a=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){activity=a.get();idle();try{draft().savePrepared(Uri.parse("content://own.delete/document/new"));fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("ya no está disponible"));}assertEquals(1,DeletingProvider.deleted);}
    }
    @Test public void providerReportingZeroAfterWriteIsNotReportedAsPlayableSuccess()throws Exception{
        byte[] bytes=mp4();SourcesActivity.attachmentFetcher=(u,f,t)->SourceHttp.copyAttachment(u,new ByteArrayInputStream(bytes),f,bytes.length,t);
        DeletingProvider provider=new DeletingProvider(){@Override public Cursor query(Uri u,String[] p,String s,String[] a,String o){var c=new android.database.MatrixCursor(new String[]{android.provider.OpenableColumns.SIZE});c.addRow(new Object[]{0L});return c;}};
        android.content.pm.ProviderInfo info=new android.content.pm.ProviderInfo();info.authority="own.size";info.exported=true;provider.attachInfo(RuntimeEnvironment.getApplication(),info);ShadowContentResolver.registerProviderInternal("own.size",provider);DeletingProvider.deleted=0;
        try(var a=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){activity=a.get();idle();draft().prepare(URL,"own.mp4","video");Uri uri=Uri.parse("content://own.size/document/new");Shadows.shadowOf(activity.getContentResolver()).registerOutputStream(uri,new ByteArrayOutputStream());try{draft().savePrepared(uri);fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("incompleto"));}assertEquals(1,DeletingProvider.deleted);assertTrue(draft().lastVideoUri.isEmpty());assertFalse(draft().status.contains("Adjunto guardado"));assertTrue(SourcesActivity.Draft.activeDownloads.isEmpty());}
    }
    public static class DeletingProvider extends ContentProvider {
        static int deleted;
        public boolean onCreate(){return true;}public Cursor query(Uri u,String[] p,String s,String[] a,String o){return null;}public String getType(Uri u){return "video/mp4";}public Uri insert(Uri u,ContentValues v){return null;}public int update(Uri u,ContentValues v,String s,String[] a){return 0;}public int delete(Uri u,String s,String[] a){throw new AssertionError("Use document deletion");}
        @Override public Bundle call(String method,String arg,Bundle extras){if(method.equals("android:deleteDocument")){deleted++;return new Bundle();}return super.call(method,arg,extras);}
    }
}
