package com.peach.local;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class DownloadQueueTest {
    LibraryDatabase db;File root;DownloadQueue queue;Publication publication;byte[] own;List<String> calls;
    static final String A="https://downloads.fanbox.cc/own-a.mp4",B="https://downloads.fanbox.cc/own-b.mp4";
    @Before public void before()throws Exception{db=androidx.room.Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();root=Files.createTempDirectory("queue-own-").toFile();queue=new DownloadQueue(root);own=SourceVideosTest.own();calls=Collections.synchronizedList(new ArrayList<>());publication=GalleryProvidersTest.publication("fanbox");db.library().insertPublication(publication);body(A,B);}
    void body(String... urls)throws Exception{JSONArray all=new JSONArray();for(String url:urls)all.put(SourceVideosTest.video(url));db.library().putPublicationContent(GalleryProvidersTest.content(publication,all));}
    List<SourceAttachments.Item> items()throws Exception{return SourceAttachments.load(db,publication.id);}
    void add()throws Exception{queue.enqueue(publication.id,items());}
    SourceHttp.Download fetch(String u,File f,PartialDownload.Mark mark,SourceHttp.Token token,long limit,PartialDownload.Updates progress)throws IOException{calls.add(u);return SourceHttp.copyAttachment(u,new ByteArrayInputStream(own),f,own.length,token,limit);}
    @After public void after()throws Exception{assertFalse(queue.running());db.close();GalleryProvidersTest.remove(root);}
    @Test public void batchIsOrderedDeduplicatedAndPersistenceHasNoSourceUrls()throws Exception{
        assertEquals(2,queue.enqueue(publication.id,items()));assertEquals(0,queue.enqueue(publication.id,items()));queue.run(db,this::fetch);assertEquals(List.of(A,B),calls);var snapshot=queue.snapshot();assertEquals(2,snapshot.size());for(var j:snapshot){assertEquals("ready",j.state);assertEquals(own.length,j.bytes);assertTrue(j.name.endsWith(".mp4"));assertArrayEquals(own,Files.readAllBytes(queue.verify(j.id,new SourceHttp.Token()).toPath()));}
        String json=new String(Files.readAllBytes(queue.manifest.getBaseFile().toPath()),java.nio.charset.StandardCharsets.UTF_8);assertFalse(json.contains("https://"));DownloadQueue restored=new DownloadQueue(root);assertEquals(snapshot.get(0).id,restored.snapshot().get(0).id);assertEquals("ready",restored.snapshot().get(0).state);assertTrue(db.library().allMedia().isEmpty());assertEquals(0,db.library().usageCount());
    }
    @Test public void fullQueueRejectsEntireExtraBatchWithoutPartialInsertion()throws Exception{
        List<SourceAttachments.Item> all=new ArrayList<>();for(int i=0;i<DownloadQueue.MAX_JOBS;i++)all.add(new SourceAttachments.Item("own.mp4","https://downloads.fanbox.cc/own-"+i+".mp4","video","fanbox"));assertEquals(DownloadQueue.MAX_JOBS,queue.enqueue(publication.id,all));try{queue.enqueue(publication.id,List.of(new SourceAttachments.Item("extra.mp4",A,"video","fanbox")));fail();}catch(IOException expected){}assertEquals(DownloadQueue.MAX_JOBS,queue.snapshot().size());assertTrue(calls.isEmpty());
    }
    @Test public void badJobDoesNotBlockNextAndDoesNotAutomaticallyRetry()throws Exception{
        add();queue.run(db,(u,f,m,t,l,p)->{if(u.equals(A)){calls.add(u);throw new IOException("https://private.invalid/?OWN_SECRET");}return fetch(u,f,m,t,l,p);});assertEquals(List.of(A,B),calls);assertEquals("error",queue.snapshot().get(0).state);assertFalse(queue.snapshot().get(0).message.contains("OWN_SECRET"));assertEquals("ready",queue.snapshot().get(1).state);queue.run(db,this::fetch);assertEquals(2,calls.size());queue.continueAll();queue.run(db,this::fetch);assertEquals(List.of(A,B,A),calls);
    }
    @Test public void changedOrRemovedImportedReferenceNeverStartsNetwork()throws Exception{add();db.library().deletePublication(publication.id);queue.run(db,this::fetch);assertTrue(calls.isEmpty());assertTrue(queue.snapshot().stream().allMatch(j->j.state.equals("error")));}
    @Test public void interruptedTransferRestoresAndResumesItsPersistedStrongCheckpoint()throws Exception{
        body(A);add();int cut=90000;PartialDownloadTest.Reply first=new PartialDownloadTest.Reply(A,200,Arrays.copyOf(own,cut),"\"own-v1\"");first.declared=own.length;
        queue.run(db,(u,f,m,t,l,p)->PartialDownload.get(u,f,m,t,l,p,new RedirectHttpTest.Factory(first),MediaRedirectsTest.PUBLIC));var failed=queue.snapshot().get(0);assertEquals("error",failed.state);assertEquals(cut,failed.mark.offset());queue=new DownloadQueue(root);queue.continueAll();
        PartialDownloadTest.Reply second=new PartialDownloadTest.Reply(A,206,Arrays.copyOfRange(own,cut,own.length),"\"own-v1\"");second.headers.put("Content-Range","bytes "+cut+"-"+(own.length-1)+"/"+own.length);queue.run(db,(u,f,m,t,l,p)->PartialDownload.get(u,f,m,t,l,p,new RedirectHttpTest.Factory(second),MediaRedirectsTest.PUBLIC));assertEquals("bytes="+cut+"-",second.getRequestProperty("Range"));assertEquals("ready",queue.snapshot().get(0).state);assertArrayEquals(own,Files.readAllBytes(queue.ready(failed.id).toPath()));
    }
    @Test public void crashRestoresRunningJobAsPausedAtDurableOffset()throws Exception{
        body(A);add();byte[] large=new byte[9*1024*1024];PartialDownloadTest.Reply first=new PartialDownloadTest.Reply(A,200,large,"\"large\"");first.crashAt=5*1024*1024;
        try{queue.run(db,(u,f,m,t,l,p)->PartialDownload.get(u,f,m,t,l,p,new RedirectHttpTest.Factory(first),MediaRedirectsTest.PUBLIC));fail();}catch(PartialDownloadTest.Crash expected){}
        queue=new DownloadQueue(root);var paused=queue.snapshot().get(0);assertEquals("paused",paused.state);assertEquals(4L*1024*1024,paused.bytes);assertTrue(queue.part(paused.id).length()>paused.mark.offset());assertFalse(queue.running());
    }
    @Test public void pauseAllStopsCurrentAndNextJobAndPreservesCheckedPrefix()throws Exception{
        add();CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);ExecutorService executor=Executors.newSingleThreadExecutor();
        var first=new PartialDownloadTest.Reply(A,200,own,"\"own\""){@Override public InputStream getInputStream(){return new InputStream(){int at;public int read(){throw new AssertionError();}public int read(byte[] b,int o,int n)throws IOException{if(at>0){entered.countDown();try{release.await(10,TimeUnit.SECONDS);}catch(InterruptedException e){throw new InterruptedIOException();}}if(at>=own.length)return -1;int count=Math.min(n,own.length-at);System.arraycopy(own,at,b,o,count);at+=count;return count;}};}};
        Future<?> task=executor.submit(()->{try{queue.run(db,(u,f,m,t,l,p)->{calls.add(u);return PartialDownload.get(u,f,m,t,l,p,new RedirectHttpTest.Factory(first),MediaRedirectsTest.PUBLIC);});}catch(IOException e){throw new RuntimeException(e);}});
        try{assertTrue(entered.await(10,TimeUnit.SECONDS));queue.pauseAll();release.countDown();task.get(20,TimeUnit.SECONDS);assertEquals(List.of(A),calls);assertTrue(queue.snapshot().stream().allMatch(j->j.state.equals("paused")));assertTrue(queue.snapshot().get(0).mark.offset()>0);}finally{release.countDown();executor.shutdownNow();assertTrue(executor.awaitTermination(20,TimeUnit.SECONDS));}
    }
    @Test public void onlyOneRunnerCanOwnTheQueueAndRemovalCancelsWithoutPublishing()throws Exception{
        body(A);add();String id=queue.snapshot().get(0).id;File keep=new File(root,"keep.txt");Files.write(keep.toPath(),new byte[]{1});CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);ExecutorService worker=Executors.newSingleThreadExecutor();
        Future<?> task=worker.submit(()->{try{queue.run(db,(u,f,m,t,l,p)->{entered.countDown();try{release.await(10,TimeUnit.SECONDS);}catch(InterruptedException e){throw new InterruptedIOException();}return fetch(u,f,m,t,l,p);});}catch(IOException e){throw new RuntimeException(e);}});
        try{assertTrue(entered.await(10,TimeUnit.SECONDS));assertFalse(queue.run(db,this::fetch));queue.remove(id);release.countDown();task.get(20,TimeUnit.SECONDS);assertTrue(queue.snapshot().isEmpty());assertFalse(queue.part(id).exists());assertFalse(queue.ready(id).exists());assertTrue(keep.exists());}finally{release.countDown();worker.shutdownNow();assertTrue(worker.awaitTermination(20,TimeUnit.SECONDS));}
    }
    @Test public void privateBudgetStopsBeforeNetworkAndUsesSparseFilesForBoundary()throws Exception{
        body(A,B,"https://downloads.fanbox.cc/third.mp4");add();for(var j:queue.snapshot().subList(0,2)){synchronized(queue){var actual=queue.job(j.id);actual.state="ready";actual.bytes=SourceHttp.LARGE_DOWNLOAD_LIMIT;actual.total=actual.bytes;actual.sha="a".repeat(64);}try(RandomAccessFile f=new RandomAccessFile(queue.ready(j.id),"rw")){f.setLength(SourceHttp.LARGE_DOWNLOAD_LIMIT);}}
        queue.save();queue.run(db,this::fetch);assertTrue(calls.isEmpty());assertEquals("error",queue.snapshot().get(2).state);assertTrue(queue.snapshot().get(2).message.contains("espacio"));
    }
    @Test public void http429WaitSurvivesReloadAndExplicitStartDoesNotBypassIt()throws Exception{
        body(A);add();queue.run(db,(u,f,m,t,l,p)->{calls.add(u);throw new SourceHttp.Failure("OWN_SECRET",429,300);});queue=new DownloadQueue(root);queue.continueAll();queue.run(db,this::fetch);assertEquals(1,calls.size());assertTrue(queue.snapshot().get(0).retryAt>System.currentTimeMillis());try{queue.retry(queue.snapshot().get(0).id);fail();}catch(IOException expected){}
    }
    @Test public void retryBudgetIncludesTheSameJobsPreviousCompleteCopy()throws Exception{
        add();var first=queue.snapshot().get(0);var second=queue.snapshot().get(1);
        for(var j:List.of(first,second))try(RandomAccessFile file=new RandomAccessFile(queue.ready(j.id),"rw")){file.setLength(SourceHttp.LARGE_DOWNLOAD_LIMIT);}
        synchronized(queue){var other=queue.job(second.id);other.state="ready";other.bytes=SourceHttp.LARGE_DOWNLOAD_LIMIT;other.total=other.bytes;other.sha="a".repeat(64);queue.save();}
        queue.run(db,this::fetch);assertTrue(calls.isEmpty());assertEquals("error",queue.snapshot().get(0).state);assertTrue(queue.snapshot().get(0).message.contains("espacio"));assertEquals(DownloadQueue.BUDGET,queue.ready(first.id).length()+queue.ready(second.id).length());assertFalse(queue.part(first.id).exists());
    }
    @Test public void completedRenameBeforeMetadataCommitIsRecoveredWithoutDownload()throws Exception{
        body(A);add();var j=queue.snapshot().get(0);Files.write(queue.ready(j.id).toPath(),own);synchronized(queue){var actual=queue.job(j.id);actual.state="verifying";actual.mark=new PartialDownload.Mark(own.length,own.length,"\"own\"",PartialDownload.key(A),PartialDownload.hex(PartialDownload.digest().digest(own)));queue.save();}queue=new DownloadQueue(root);var done=queue.snapshot().get(0);assertEquals("ready",done.state);assertEquals(own.length,done.bytes);assertEquals("mp4",MediaRules.extension(done.name));assertArrayEquals(own,Files.readAllBytes(queue.verify(j.id,new SourceHttp.Token()).toPath()));assertTrue(calls.isEmpty());
    }
    @Test public void corruptedCompleteCopyIsFlaggedAndMalformedManifestDoesNotDeleteData()throws Exception{
        body(A);add();queue.run(db,this::fetch);var j=queue.snapshot().get(0);File f=queue.ready(j.id);byte[] damaged=own.clone();damaged[0]^=1;Files.write(f.toPath(),damaged);try{queue.verify(j.id,new SourceHttp.Token());fail();}catch(IOException expected){}assertEquals("error",queue.snapshot().get(0).state);assertTrue(queue.pins.isEmpty());Files.write(queue.manifest.getBaseFile().toPath(),"{bad queue".getBytes());try{new DownloadQueue(root);fail();}catch(IOException expected){}assertTrue(f.exists());
    }
    @Test public void recoveryDoesNotReportAnUncheckpointedPausedTailAsVerifiedProgress()throws Exception{
        body(A);add();String id=queue.snapshot().get(0).id;Files.write(queue.part(id).toPath(),Arrays.copyOf(own,100000));synchronized(queue){var j=queue.job(id);j.state="paused";j.bytes=100000;j.total=own.length;j.mark=PartialDownload.Mark.empty();queue.save();}queue=new DownloadQueue(root);assertEquals(0,queue.snapshot().get(0).bytes);assertEquals(-1,queue.snapshot().get(0).total);assertEquals(100000,queue.part(id).length());assertTrue(calls.isEmpty());
    }
}
