package com.peach.local;

import androidx.room.Room;
import java.util.List;
import java.util.Map;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.SQLiteMode;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,manifest=Config.NONE)
@SQLiteMode(SQLiteMode.Mode.LEGACY)
public class EntityStoreTest {
    private LibraryDatabase db;private EntityStore store;
    @Before public void open(){db=Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().build();store=new EntityStore(db);}
    @After public void close(){db.close();}
    private MediaEntry media(String id,String actor){MediaEntry m=new MediaEntry();m.id=id;m.root="root";m.name=id+".mp4";m.title=id;m.actors=actor;db.library().insertMedia(m);return m;}
    private List<MediaEntry> matches(String id){return EntityIndex.select(db.library(),db.library().allMedia(),id);}
    private void rejects(Runnable work){try{work.run();fail("Expected invalid operation");}catch(IllegalArgumentException expected){}}
    @Test public void exactAliasesResolveImportedNamesWithoutChangingDocuments() {
        MediaEntry a=media("a","Ana"),b=media("b","Rivera, Ana"),c=media("c","Anabel"),d=media("d","ana");
        b.nfoDetails=NfoDetails.encode(Map.of(),Map.of("actors",List.of("Rivera, Ana")));db.library().updateScan(b.id,"","root",b.name,"",b.title,"",b.actors,"","","","","[]",b.nfoDetails,MediaRules.VIDEO,0,0,0);
        String id=store.create("performer","Ana","");store.alias(id,"Rivera, Ana");
        assertEquals(List.of("a","b"),matches(id).stream().map(m->m.id).toList());
        assertEquals("Rivera, Ana",db.library().get("b").actors);assertEquals(4,db.library().allMedia().size());
        assertTrue(EntityIndex.relations(db.library().entity(id),db.library().allMedia(),db.library().aliases(),List.of()).stream().allMatch(r->r.source().equals("nfo")));
    }
    @Test public void aliasCollisionAndRenameCollisionRollBackEntireChange() {
        String a=store.create("performer","Ana","Notas"),b=store.create("performer","Sol","");store.alias(a,"Alba");
        rejects(()->store.create("performer","Ana",""));rejects(()->store.alias(b,"Alba"));rejects(()->store.edit(b,"Ana","Cambio"));
        assertEquals(2,db.library().entities().size());assertEquals("Sol",db.library().entity(b).name);assertEquals("",db.library().entity(b).notes);
        assertEquals(1,db.library().aliases().size());
        assertNotNull(store.create("studio","Ana",""));assertNotNull(store.create("performer","ana",""));
    }
    @Test public void renameKeepsOldSpellingAndStableIdentityWithPersonalState() {
        media("a","Ana");db.library().progress("a",7000,90000,1,false);db.library().toggleFavorite("a");
        String id=store.create("performer","Ana","");store.edit(id,"Alba","Nueva nota");store.alias(id,"Alba");
        assertEquals("Alba",db.library().entity(id).name);assertEquals("Ana",db.library().aliases().get(0).name);
        assertEquals(1,matches(id).size());assertEquals(7000,db.library().get("a").position);assertTrue(db.library().get("a").favorite);
        store.edit(id,"Ana","Otra nota");assertEquals("Alba",db.library().aliases().get(0).name);assertEquals(1,matches(id).size());
    }
    @Test public void importedAndManualLinksRemainSeparateWhenAliasOrNfoChanges() {
        media("a","Ana");media("b","");String id=store.create("performer","Principal","");store.alias(id,"Ana");store.link(id,"a","performer");store.link(id,"b","performer");
        assertEquals(3,EntityIndex.relations(db.library().entity(id),db.library().allMedia(),db.library().aliases(),db.library().entityLinks()).size());
        db.library().removeAlias(id,"Ana");assertEquals(2,matches(id).size());
        db.library().removeEntityLink(id,"a","performer");assertEquals(List.of("b"),matches(id).stream().map(m->m.id).toList());
    }
    @Test public void rolesAndNameSpacesSeparatePerformersStudiosCreatorsAndSeries() {
        MediaEntry m=media("a","Ana");m.studio="Ana";m.nfoDetails=NfoDetails.encode(Map.of("directors","Ana","artists","Ana","series","Ana"));
        db.library().updateScan(m.id,"","root",m.name,"",m.title,"",m.actors,m.studio,"","","","[]",m.nfoDetails,MediaRules.VIDEO,0,0,0);
        for(String kind:List.of("performer","studio","creator","series")) {
            String id=store.create(kind,"Ana","");var relations=EntityIndex.relations(db.library().entity(id),db.library().allMedia(),List.of(),List.of());
            assertEquals(kind.equals("creator")?2:1,relations.size());assertTrue(relations.stream().allMatch(r->EntityIndex.roles(kind).contains(r.role())));
        }
    }
    @Test public void personalTagsKeepTheirOwnProvenanceAndAnEmptyOverrideRemovesImportedLinks() {
        media("a","");db.library().editMetadata("a",null,"Viaje");String id=store.create("tag","Viaje","");
        var relations=EntityIndex.relations(db.library().entity(id),db.library().allMedia(),List.of(),List.of());
        assertEquals("user-tags",relations.get(0).source());db.library().editMetadata("a",null,"");assertTrue(matches(id).isEmpty());
    }
    @Test public void manualLinksAreIdempotentAndRejectUnknownDocumentsAndRoles() {
        media("a","");String id=store.create("creator","Ana","");store.link(id,"a","director");store.link(id,"a","director");
        assertEquals(1,db.library().entityLinks().size());rejects(()->store.link(id,"missing","director"));rejects(()->store.link(id,"a","studio"));
        rejects(()->store.link("missing","a","director"));assertEquals(1,db.library().entityLinks().size());
    }
    @Test public void externalReferencesAreTextOnlyAndUpdateByProviderAndIdentifier() {
        String id=store.create("creator","Ana","");store.reference(id,"Proveedor","123","https://example.org/id/123");
        store.reference(id,"Proveedor","123","https://example.org/new/123");assertEquals(1,db.library().entityReferences().size());
        assertEquals("https://example.org/new/123",db.library().entityReferences().get(0).url);
        for(String invalid:List.of("http://example.org","javascript:alert(1)","file:///tmp/a","https://user:pass@example.org"))rejects(()->store.reference(id,"P","other",invalid));
        assertEquals(1,db.library().entityReferences().size());
    }
    @Test public void deletingEntityCascadesOnlyItsOwnedRowsAndKeepsWantsAndMedia() {
        media("a","");String id=store.create("performer","Ana","");store.alias(id,"Alba");store.link(id,"a","performer");store.reference(id,"P","1","");
        String want=new WantStore(db).create("Campo","CAM-1","",id);new WantStore(db).attach(want,"a");db.library().deleteEntity(id);
        assertTrue(db.library().aliases().isEmpty());assertTrue(db.library().entityLinks().isEmpty());assertTrue(db.library().entityReferences().isEmpty());
        assertNull(db.library().want(want).entityId);assertEquals("a",db.library().want(want).mediaId);assertNotNull(db.library().get("a"));
    }
    @Test public void forgettingMediaPreservesIdentityAndDesiredWorkButClearsDocumentLinks() {
        media("a","");String id=store.create("performer","Ana","");store.link(id,"a","performer");String want=new WantStore(db).create("Campo","","",id);new WantStore(db).attach(want,"a");
        db.library().forgetMedia("root");assertTrue(db.library().entityLinks().isEmpty());assertNotNull(db.library().entity(id));assertNull(db.library().want(want).mediaId);assertEquals(id,db.library().want(want).entityId);
    }
    @Test public void worksCanExistWithoutFilesAndLinkExplicitlyWithoutMatchingByCode() {
        String id=new WantStore(db).create("Sin archivo","CAM-1","Nota",null);assertNull(db.library().want(id).mediaId);
        media("a","");assertNull(db.library().want(id).mediaId);new WantStore(db).attach(id,"a");assertEquals("a",db.library().want(id).mediaId);
        new WantStore(db).edit(id,"Nuevo título","CAM-2","Nueva nota");assertEquals("a",db.library().want(id).mediaId);assertEquals("CAM-2",db.library().want(id).code);
        rejects(()->new WantStore(db).attach(id,"absent"));assertEquals("a",db.library().want(id).mediaId);
        new WantStore(db).attach(id,null);assertNull(db.library().want(id).mediaId);assertNotNull(db.library().get("a"));
    }
}
