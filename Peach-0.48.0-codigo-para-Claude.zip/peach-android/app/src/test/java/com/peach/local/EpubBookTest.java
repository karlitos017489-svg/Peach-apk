package com.peach.local;

import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;
import org.junit.*;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

public class EpubBookTest {
    @Rule public TemporaryFolder temp=new TemporaryFolder();
    static byte[] fixture(String name)throws Exception{try(var input=EpubBookTest.class.getClassLoader().getResourceAsStream("epub170/"+name)){assertNotNull(input);return input.readAllBytes();}}
    static Map<String,byte[]> contents()throws Exception{var map=new LinkedHashMap<String,byte[]>();try(var zip=new ZipInputStream(new ByteArrayInputStream(fixture("book3.epub")))){java.util.zip.ZipEntry entry;while((entry=zip.getNextEntry())!=null)map.put(entry.getName(),zip.readAllBytes());}return map;}
    static byte[] encode(Map<String,byte[]> files)throws Exception{var bytes=new ByteArrayOutputStream();try(var zip=new ZipOutputStream(bytes)){for(var row:files.entrySet()){zip.putNextEntry(new ZipEntry(row.getKey()));zip.write(row.getValue());zip.closeEntry();}}return bytes.toByteArray();}
    File file(byte[] bytes)throws Exception{File file=temp.newFile();Files.write(file.toPath(),bytes);return file;}
    static void change(Map<String,byte[]> map,String key,String old,String value){String body=new String(map.get(key),StandardCharsets.UTF_8);assertTrue(body.contains(old));map.put(key,body.replace(old,value).getBytes(StandardCharsets.UTF_8));}
    void rejects(Map<String,byte[]> files)throws Exception{File output=temp.newFolder();try(var book=new EpubBook(file(encode(files)),output)){fail("Invalid EPUB accepted");}catch(IOException expected){}assertEquals(0,output.list().length);}
    @Test public void epub2And3FollowSpineInsteadOfAlphabeticZipOrderAndIndexLocalImages()throws Exception{
        for(String filename:List.of("book2.epub","book3.epub"))try(var book=new EpubBook(file(fixture(filename)),temp.newFolder())){assertEquals(List.of("EPUB/text/10.xhtml","EPUB/text/cap dos.xhtml"),book.chapters());assertEquals(3,book.items().size());assertEquals("EPUB/images/portada color.png",book.items().get(2).name());assertEquals(DocumentRules.CHAPTER,book.items().get(0).kind());assertNull(book.item("EPUB/aside.xhtml"));}
    }
    @Test public void chapterPreviewPreservesInlineWordsAndParagraphsButExcludesExecutableOrHiddenContent()throws Exception{
        File output=temp.newFolder();try(var book=new EpubBook(file(fixture("book3.epub")),output)){var preview=EpubBook.preview(book.read(book.chapters().get(0),output));String text=preview.text();assertTrue(text.contains("Rocas sedimentarias & minerales."));assertTrue(text.contains("Estratos superpuestos.\nSegundo bloque."));assertTrue(text.contains("[Imagen: Estratos]"));assertTrue(text.contains("Referencia escrita"));for(String forbidden:List.of("METADATO_NO_MOSTRAR","OCULTO","NO_SCRIPT","NO_IFRAME","css_secreto","<em>"))assertFalse(forbidden,text.contains(forbidden));assertFalse(preview.truncated());assertEquals(List.of("entry"),List.of(output.list()));}
    }
    @Test public void localUriResolutionHandlesEncodedNamesFragmentsAndInContainerParentPaths()throws Exception{
        assertEquals("Shared/capítulo ñ.xhtml",EpubBook.resolve("EPUB/package.opf","../Shared/capítulo%20ñ.xhtml#anchor"));
        for(String href:List.of("../../outside.xhtml","%2e%2e/%2e%2e/out.xhtml","https://example.invalid/a.xhtml","//example.invalid/a.xhtml","/absolute.xhtml","a.xhtml?q=1","a%5c..%5cb.xhtml","a%00.xhtml","#anchor",""))try{EpubBook.resolve("EPUB/package.opf",href);fail(href);}catch(IOException expected){}
    }
    @Test public void absentAndRemoteSpineResourcesOrUnsupportedSvgAreRejected()throws Exception{
        for(String replacement:List.of("https://example.invalid/a.xhtml","../../outside.xhtml","missing.xhtml")){var map=contents();change(map,"EPUB/package.opf","text/10.xhtml",replacement);rejects(map);}
        var map=contents();change(map,"EPUB/package.opf","id=\"ten\" href=\"text/10.xhtml\" media-type=\"application/xhtml+xml\"","id=\"ten\" href=\"text/10.xhtml\" media-type=\"image/svg+xml\"");rejects(map);
    }
    @Test public void duplicateManifestIdsDuplicateSpinePathsAndUnknownReferencesAreRejected()throws Exception{
        var map=contents();change(map,"EPUB/package.opf","id=\"two\"","id=\"ten\"");rejects(map);
        map=contents();change(map,"EPUB/package.opf","id=\"two\"","id=\"   \"");rejects(map);
        map=contents();change(map,"EPUB/package.opf","idref=\"two\"","idref=\"ten\"");rejects(map);
        map=contents();change(map,"EPUB/package.opf","idref=\"two\"","idref=\"unknown\"");rejects(map);
        map=contents();change(map,"EPUB/package.opf","<manifest>","<manifest xml:base=\"https://example.invalid/\">");rejects(map);
    }
    @Test public void firstRootfileIsUsedAndForeignXmlNamespacesAreNotMistakenForPackageElements()throws Exception{
        var map=contents();change(map,"META-INF/container.xml","</rootfiles>","<rootfile full-path=\"missing.opf\" media-type=\"application/oebps-package+xml\"/></rootfiles>");try(var book=new EpubBook(file(encode(map)),temp.newFolder())){assertEquals(2,book.chapters().size());}
        map=contents();change(map,"EPUB/package.opf","http://www.idpf.org/2007/opf","urn:foreign");rejects(map);
    }
    @Test public void encryptedAndObfuscatedResourceMarkerIsRejectedConservatively()throws Exception{
        var map=contents();map.put("META-INF/encryption.xml","<encryption/>".getBytes());rejects(map);
    }
    @Test public void utf16WithBomWorksForMetadataAndChaptersWithoutExternalEntities()throws Exception{
        var map=contents();for(String name:List.of("META-INF/container.xml","EPUB/text/10.xhtml")){String text=new String(map.get(name),StandardCharsets.UTF_8).replace("encoding=\"UTF-8\"","encoding=\"UTF-16\"");map.put(name,text.getBytes(StandardCharsets.UTF_16));}
        File out=temp.newFolder();try(var book=new EpubBook(file(encode(map)),out)){assertTrue(EpubBook.preview(book.read(book.chapters().get(0),out)).text().contains("sedimentarias"));}
    }
    @Test public void dtdAndEntityDeclarationsAreRejectedBeforeParsingUtf8OrUtf16Metadata()throws Exception{
        for(var charset:List.of(StandardCharsets.UTF_8,StandardCharsets.UTF_16)){var map=contents();String xml="<!DOCTYPE container [<!ENTITY ext SYSTEM 'https://example.invalid/no-fetch'>]><container xmlns='urn:oasis:names:tc:opendocument:xmlns:container'>&ext;</container>";map.put("META-INF/container.xml",xml.getBytes(charset));rejects(map);}
    }
    @Test public void metadataAndChapterByteLimitsDoNotOverwritePreviousView()throws Exception{
        var map=contents();map.put("META-INF/container.xml",new byte[EpubBook.MAX_METADATA+1]);rejects(map);
        map=contents();map.put("EPUB/text/10.xhtml",new byte[EpubBook.MAX_CHAPTER+1]);File out=temp.newFolder();Files.write(new File(out,"entry").toPath(),"anterior".getBytes());try(var book=new EpubBook(file(encode(map)),out)){try{book.read(book.chapters().get(0),out);fail();}catch(IOException expected){}assertEquals("anterior",new String(Files.readAllBytes(new File(out,"entry").toPath())));assertFalse(new File(out,"entry-part").exists());}
    }
    @Test public void visibleTextTruncationAndDomBudgetAreExplicitAndDoNotSplitSurrogates()throws Exception{
        File file=file(("<html><body><p>"+"a".repeat(199999)+"😀</p></body></html>").getBytes(StandardCharsets.UTF_8));var preview=EpubBook.preview(file);assertTrue(preview.truncated());assertTrue(preview.text().length()<=TextPreview.MAX_CHARS);assertFalse(Character.isHighSurrogate(preview.text().charAt(preview.text().length()-1)));
        file=file(("<body>"+"<span></span>".repeat(50001)+"</body>").getBytes());try{EpubBook.preview(file);fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("nodos"));}
    }
    @Test public void mimeContainerPackageAndEmptySpineAreRequiredButEpubIsNotAnArchiveEntryReader()throws Exception{
        for(String missing:List.of("mimetype","META-INF/container.xml","EPUB/package.opf")){var map=contents();map.remove(missing);rejects(map);}
        var map=contents();change(map,"EPUB/package.opf","version=\"3.0\"","version=\"9.0\"");rejects(map);
        map=contents();change(map,"EPUB/package.opf","<itemref idref=\"ten\"/>","");change(map,"EPUB/package.opf","<itemref idref=\"two\"/>","");rejects(map);
        assertTrue(DocumentRules.readable("book.EPUB"));assertEquals("",DocumentRules.entryKind("nested.epub"));assertEquals(MediaRules.OTHER,MediaRules.type("book.epub"));
    }
    @Test public void cancellationAndMetadataCrcCorruptionAreDetectedWithoutMaterialization()throws Exception{
        File source=file(fixture("book3.epub"));Thread.currentThread().interrupt();try(var book=new EpubBook(source,temp.newFolder())){fail();}catch(InterruptedIOException expected){}finally{Thread.interrupted();}
        byte[] bytes=fixture("book3.epub");boolean changed=false;for(int i=0;i+46<bytes.length;i++)if(bytes[i]==0x50 && bytes[i+1]==0x4b && bytes[i+2]==1 && bytes[i+3]==2){int len=(bytes[i+28]&255)|((bytes[i+29]&255)<<8);if(new String(bytes,i+46,len,StandardCharsets.UTF_8).equals("EPUB/package.opf")){Arrays.fill(bytes,i+16,i+20,(byte)0);changed=true;break;}}assertTrue(changed);try(var book=new EpubBook(file(bytes),temp.newFolder())){fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("CRC"));}
    }
    @Test public void prefixedXhtmlKeepsWordsAndBlockBreaksWhileOmittingHeadAndScripts()throws Exception {
        File input=file("<x:html xmlns:x='http://www.w3.org/1999/xhtml'><x:head><x:title>NO_TITLE</x:title></x:head><x:body><x:p>Rocas <x:em>sedimen</x:em>tarias.</x:p><x:p>Otro párrafo.</x:p><x:script>NO_SCRIPT</x:script></x:body></x:html>".getBytes(StandardCharsets.UTF_8));String text=EpubBook.preview(input).text();assertEquals("Rocas sedimentarias.\n\nOtro párrafo.",text);
    }
    @Test public void moreThanOneThousandSpineReferencesAreRejectedBeforeAnyChapterIsOpened()throws Exception {
        var map=contents();StringBuilder manifest=new StringBuilder(),spine=new StringBuilder();for(int i=0;i<1001;i++){manifest.append("<item id='c").append(i).append("' href='c").append(i).append(".xhtml' media-type='application/xhtml+xml'/>");spine.append("<itemref idref='c").append(i).append("'/>");map.put("EPUB/c"+i+".xhtml","<body>Own text</body>".getBytes());}map.put("EPUB/package.opf",("<package xmlns='http://www.idpf.org/2007/opf' version='3.0'><manifest>"+manifest+"</manifest><spine>"+spine+"</spine></package>").getBytes());rejects(map);
    }

}
