package com.peach.local;
import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;
import org.junit.*;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

public class EpubNavigation440Test {
    @Rule public TemporaryFolder temp=new TemporaryFolder();
    static Map<String,byte[]> contents(int version)throws Exception{Map<String,byte[]> map=new LinkedHashMap<>();try(var z=new ZipInputStream(new ByteArrayInputStream(Formats440Test.fixture("muestra-epub"+version+".epub")))){ZipEntry e;while((e=z.getNextEntry())!=null)map.put(e.getName(),z.readAllBytes());}return map;}
    File file(byte[] b)throws Exception{File f=temp.newFile();Files.write(f.toPath(),b);return f;}
    EpubBook book(Map<String,byte[]> map)throws Exception{return new EpubBook(file(EpubBookTest.encode(map)),temp.newFolder());}
    @Test public void epub3NavAndEpub2NcxKeepTitlesHierarchyOrderAndFragmentDestinations()throws Exception {
        for(int v:List.of(2,3))try(var book=book(contents(v))){assertEquals(List.of("Capas y minerales","Seccion intermedia","Segundo capitulo"),book.contents().stream().map(EpubBook.Contents::label).toList());assertEquals(List.of(0,1,0),book.contents().stream().map(EpubBook.Contents::depth).toList());assertEquals("EPUB/uno.xhtml",book.contents().get(1).path());assertEquals("ancla",book.contents().get(1).fragment());assertEquals("",book.navigationIssue());assertEquals(List.of("EPUB/uno.xhtml","EPUB/dos.xhtml"),book.chapters());}
    }
    @Test public void selectedFragmentFindsVisibleNativeTextWithoutExecutingHtml()throws Exception {
        File dir=temp.newFolder();try(var book=book(contents(3))){File chapter=book.read(book.chapters().get(0),dir);var selected=EpubBook.chapter(chapter,"ancla");assertTrue(selected.anchor()>1000);assertTrue(selected.anchor()<selected.preview().text().length());assertTrue(selected.preview().text().substring(selected.anchor()).contains("Seccion intermedia"));assertEquals(-1,EpubBook.chapter(chapter,"absent").anchor());assertEquals(EpubBook.preview(chapter).text(),selected.preview().text());}
    }
    @Test public void remoteUnsafeOrNonSpineNavigationDoesNotFetchOrBreakSpineReading()throws Exception {
        for(String href:List.of("https://example.invalid/no-fetch","../../escape.xhtml","imagen.png","missing.xhtml","uno.xhtml?secret=1","uno.xhtml#bad%00")){var map=contents(3);EpubBookTest.change(map,"EPUB/nav.xhtml","uno.xhtml#ancla",href);try(var book=book(map)){assertTrue(book.contents().isEmpty());assertFalse(book.navigationIssue().isEmpty());assertTrue(EpubBook.preview(book.read(book.chapters().get(0),temp.newFolder())).text().contains("Capas y minerales"));}}
    }
    @Test public void duplicateNavOrDtdInOptionalIndexFallsBackToSpine()throws Exception {
        var map=contents(3);EpubBookTest.change(map,"EPUB/nav.xhtml","</body>","<nav epub:type=\"toc\"><ol><li><a href=\"dos.xhtml\">duplicate</a></li></ol></nav></body>");try(var book=book(map)){assertTrue(book.contents().isEmpty());assertFalse(book.navigationIssue().isEmpty());}
        map=contents(2);map.put("EPUB/toc.ncx","<!DOCTYPE ncx SYSTEM 'https://example.invalid/no-fetch'><ncx/>".getBytes(StandardCharsets.UTF_8));try(var book=book(map)){assertTrue(book.contents().isEmpty());assertEquals(2,book.chapters().size());}
    }
    @Test public void excessiveIndexDepthOrEntriesIsBoundedWithoutBlockingBook()throws Exception {
        var map=contents(3);String rows="<li><a href='uno.xhtml'>uno</a></li>".repeat(1001);map.put("EPUB/nav.xhtml",("<html xmlns='http://www.w3.org/1999/xhtml' xmlns:epub='http://www.idpf.org/2007/ops'><body><nav epub:type='toc'><ol>"+rows+"</ol></nav></body></html>").getBytes());try(var book=book(map)){assertTrue(book.contents().isEmpty());assertFalse(book.navigationIssue().isEmpty());}
    }
    static void font(Map<String,byte[]> map,String algorithm,String target)throws Exception {
        EpubBookTest.change(map,"EPUB/libro.opf","</manifest>","<item id=\"font\" href=\"fuente.otf\" media-type=\"font/otf\"/></manifest>");map.put("EPUB/fuente.otf",new byte[]{1,2,3});
        map.put("META-INF/encryption.xml",("<encryption xmlns='urn:oasis:names:tc:opendocument:xmlns:container' xmlns:e='http://www.w3.org/2001/04/xmlenc#'><e:EncryptedData><e:EncryptionMethod Algorithm='"+algorithm+"'/><e:CipherData><e:CipherReference URI='"+target+"'/></e:CipherData></e:EncryptedData></encryption>").getBytes());
    }
    @Test public void standardObfuscatedFontsAreIgnoredByTextReaderButNeverDecodedOrExtracted()throws Exception {
        for(String algorithm:List.of("http://www.idpf.org/2008/embedding","http://ns.adobe.com/pdf/enc#RC")){var map=contents(3);font(map,algorithm,"EPUB/fuente.otf");try(var book=book(map)){assertEquals(3,book.items().size());assertNull(book.item("EPUB/fuente.otf"));assertEquals(3,book.contents().size());}}
    }
    @Test public void encryptionOfTextImagesAndUnrecognizedDrmIsStillRejected()throws Exception {
        for(String target:List.of("EPUB/uno.xhtml","EPUB/imagen.png","../escape.otf","https://example.invalid/font")){var map=contents(3);font(map,"http://www.idpf.org/2008/embedding",target);try(var book=book(map)){fail();}catch(IOException expected){}}
        var map=contents(3);font(map,"urn:unrecognized-drm","EPUB/fuente.otf");try(var book=book(map)){fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("DRM"));}
    }
}
