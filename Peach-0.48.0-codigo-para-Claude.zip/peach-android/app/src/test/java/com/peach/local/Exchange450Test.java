package com.peach.local;

import android.content.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class Exchange450Test {
    final ExecutorService io=Executors.newSingleThreadExecutor();Device a,b;
    interface Work<T>{T run()throws Exception;}
    <T>T work(Work<T> job)throws Exception{try{return io.submit(job::run).get(30,TimeUnit.SECONDS);}catch(ExecutionException e){if(e.getCause() instanceof Exception x)throw x;throw new AssertionError(e.getCause());}}
    static final class Device implements AutoCloseable {
        final LibraryDatabase db;final ExchangeStore store;final String root,id;final Context context;
        Device(String label)throws Exception {
            var app=RuntimeEnvironment.getApplication();File dir=Files.createTempDirectory(app.getCacheDir().toPath(),"exchange450-").toFile();String prefix=UUID.randomUUID().toString();
            context=new ContextWrapper(app){@Override public Context getApplicationContext(){return this;}@Override public File getNoBackupFilesDir(){return dir;}@Override public SharedPreferences getSharedPreferences(String name,int mode){return app.getSharedPreferences(prefix+name,mode);}};
            db=androidx.room.Room.inMemoryDatabaseBuilder(context,LibraryDatabase.class).allowMainThreadQueries().setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();store=new ExchangeStore(context,db);
            root="content://own/tree/"+label;LibraryRoot r=new LibraryRoot();r.uri=root;r.label=label;r.state=0;db.library().addRoot(r);id="content://own/document/"+label+"-one";add(id,"one.mp4",label+" / sub",100);
        }
        MediaEntry add(String id,String name,String folder,long bytes){MediaEntry m=new MediaEntry();m.id=id;m.uri=id;m.root=root;m.name=name;m.title=MediaRules.stem(name);m.folder=folder;m.bytes=bytes;m.mediaType=MediaRules.type(name);db.library().insertMedia(m);return m;}
        public void close(){db.close();}
    }
    @Before public void setup()throws Exception{a=new Device("A");b=new Device("B");}
    @After public void stop()throws Exception{a.close();b.close();io.shutdownNow();assertTrue(io.awaitTermination(30,TimeUnit.SECONDS));}
    PortableState.Packet packet(Device d)throws Exception{return work(()->d.store.export("Origen "+d.root.charAt(d.root.length()-1)));}
    Map<String,String> roots(PortableState.Packet p,Device d)throws Exception{return Map.of(p.data.getJSONArray("roots").getJSONObject(0).getString("id"),d.root);}
    ExchangeStore.Review review(PortableState.Packet p,Device target)throws Exception{return work(()->target.store.review(p,roots(p,target),Map.of()));}
    int apply(Device d,ExchangeStore.Review r,Map<String,Boolean> choices)throws Exception{return work(()->d.store.apply(r,choices));}
    Map<String,Boolean> all(ExchangeStore.Review r){Map<String,Boolean> choices=new HashMap<>();for(var c:r.fields.changes)choices.put(c.key(),true);return choices;}
    FieldMerge.Change field(ExchangeStore.Review r,String section,String field){return r.fields.changes.stream().filter(c->c.section().equals(section)&&c.field().equals(field)).findFirst().orElseThrow();}
    static JSONObject encoded(PortableState.Packet p)throws Exception{return new JSONObject(p.encoded);}
    static PortableState.Packet resign(JSONObject object)throws Exception{object.put("sha256",ExchangeJson.hash(ExchangeJson.canonical(object.getJSONObject("data"))));return new PortableState.Packet(object);}
    @Test public void exportCarriesMetadataAndOpaqueReferencesButNoDocumentGrantsOrAccountPreferences()throws Exception {
        a.context.getSharedPreferences("site-sessions",0).edit().putString("cookie","PRIVATE_OWN_SENTINEL").commit();a.db.library().editMetadata(a.id,"Título propio","capas");PortableState.Packet p=packet(a);
        assertFalse(p.encoded.contains("content://"));assertFalse(p.encoded.contains("PRIVATE_OWN_SENTINEL"));assertFalse(p.encoded.contains("keystore"));assertTrue(p.encoded.contains("Título propio"));assertTrue(p.encoded.contains("nfoDetails"));assertEquals(1,p.data.getJSONArray("media").length());work(()->{PortableState.validate(a.context,p);return null;});
    }
    @Test public void editedDigestUnknownFieldsAndWrongFormatAreRejected()throws Exception {
        PortableState.Packet p=packet(a);JSONObject j=encoded(p);j.getJSONObject("data").getJSONArray("metadata").getJSONObject(0).put("title","changed");try{new PortableState.Packet(j);fail();}catch(IOException expected){}
        j=encoded(p);j.put("password","unused");try{resign(j);fail();}catch(IOException expected){}
        j=encoded(p);j.getJSONObject("data").getJSONObject("state").getJSONArray("items").getJSONObject(0).put("cookie","unused");try{resign(j);fail();}catch(IOException expected){}
        j=encoded(p);j.put("version",2);try{resign(j);fail();}catch(IOException expected){}
    }
    @Test public void strictTypesDoNotCoerceFakeBooleansOrFractionalPositions()throws Exception {
        PortableState.Packet p=packet(a);for(Object bad:List.of("true",1)){JSONObject j=encoded(p);j.getJSONObject("data").getJSONObject("state").getJSONArray("items").getJSONObject(0).put("favorite",bad);try{resign(j);fail();}catch(IOException expected){}}
        JSONObject j=encoded(p);j.getJSONObject("data").getJSONObject("state").getJSONArray("items").getJSONObject(0).put("position",1.5);try{resign(j);fail();}catch(IOException expected){}
    }
    @Test public void explicitRootMappingRequiresCompleteScanAndExactUniquePathAndSize()throws Exception {
        PortableState.Packet p=packet(a);var none=work(()->b.store.review(p,Map.of(),Map.of()));assertEquals("",none.mapping.get(0).local());assertTrue(none.fields.changes.isEmpty());var r=review(p,b);assertEquals(b.id,r.mapping.get(0).local());
        b.db.library().rootState(b.root,1);assertEquals("",review(p,b).mapping.get(0).local());b.db.library().rootState(b.root,0);
        b.add("content://own/duplicate","one.mp4","B / sub",100);assertTrue(review(p,b).mapping.get(0).state().contains("ambigua"));
    }
    @Test public void manualMappingDoesNotPermitTwoRemoteEntriesToUseOneLocalDocument()throws Exception {
        a.add("content://own/a2","two.mp4","A / other",100);PortableState.Packet p=packet(a);Map<String,String> manual=new HashMap<>();JSONArray m=p.data.getJSONArray("media");for(int i=0;i<m.length();i++)manual.put(m.getJSONObject(i).getString("id"),b.id);
        var r=work(()->b.store.review(p,Map.of(),manual));assertTrue(r.mapping.stream().allMatch(x->x.local().isEmpty()));
    }
    @Test public void manualMappingChecksSizeFamilyAndLocalAvailability()throws Exception {
        PortableState.Packet p=packet(a);String remote=p.data.getJSONArray("media").getJSONObject(0).getString("id");MediaEntry wrong=b.add("content://own/wrong","other.mp4","B",101);
        var r=work(()->b.store.review(p,Map.of(),Map.of(remote,wrong.id)));assertEquals("",r.mapping.get(0).local());r=work(()->b.store.review(p,Map.of(),Map.of(remote,b.id)));assertEquals(b.id,r.mapping.get(0).local());
    }
    @Test public void firstEncounterConservesLocalConflictsAndChoiceAppliesOnlySelectedField()throws Exception {
        a.db.library().toggleFavorite(a.id);a.db.library().editMetadata(a.id,"Entrante","etiquetas");var r=review(packet(a),b);assertTrue(field(r,"items","favorite").conflict());apply(b,r,Map.of());assertFalse(b.db.library().get(b.id).favorite);assertNull(b.db.library().get(b.id).userTitle);
        a.db.library().toggleFavorite(a.id);apply(b,review(packet(a),b),Map.of());a.db.library().toggleFavorite(a.id);r=review(packet(a),b);var favorite=field(r,"items","favorite");apply(b,r,Map.of(favorite.key(),true));assertTrue(b.db.library().get(b.id).favorite);assertNull(b.db.library().get(b.id).userTitle);
    }
    @Test public void threeWayCombinesIndependentChangesAndKeepsUnchangedRemoteFromErasingLocalEdits()throws Exception {
        apply(b,review(packet(a),b),Map.of());a.db.library().toggleFavorite(a.id);b.db.library().toggleWatched(b.id);b.db.library().editMetadata(b.id,null,"solo local");var r=review(packet(a),b);var f=field(r,"items","favorite");assertFalse(f.conflict());assertTrue(f.incomingDefault());assertTrue(r.fields.changes.stream().noneMatch(c->c.field().equals("userTags")||c.field().equals("watched")));apply(b,r,Map.of());assertTrue(b.db.library().get(b.id).favorite);assertTrue(b.db.library().get(b.id).watched);assertEquals("solo local",b.db.library().get(b.id).userTags);
    }
    @Test public void simultaneousEditsProduceAConflictUntilUserChoosesIncoming()throws Exception {
        apply(b,review(packet(a),b),Map.of());a.db.library().editMetadata(a.id,"A cambió",null);b.db.library().editMetadata(b.id,"B cambió",null);var r=review(packet(a),b);var c=field(r,"items","userTitle");assertTrue(c.conflict());assertFalse(c.incomingDefault());apply(b,r,Map.of(c.key(),true));assertEquals("A cambió",b.db.library().get(b.id).userTitle);
    }
    @Test public void repeatedImportIsIdempotentAndDoesNotDuplicateRowsOrCounters()throws Exception {
        a.db.library().toggleFavorite(a.id);var p=packet(a);var r=review(p,b);apply(b,r,all(r));var again=review(p,b);assertTrue(again.fields.changes.isEmpty());assertEquals(0,apply(b,again,Map.of()));assertEquals(1,b.db.library().allMedia().size());assertEquals(0,b.db.library().get(b.id).playCount);
    }
    @Test public void bidirectionalVersionsRetainEachDevicesIndependentChanges()throws Exception {
        apply(b,review(packet(a),b),Map.of());apply(a,review(packet(b),a),Map.of());a.db.library().toggleFavorite(a.id);b.db.library().toggleWatched(b.id);apply(b,review(packet(a),b),Map.of());apply(a,review(packet(b),a),Map.of());assertTrue(a.db.library().get(a.id).favorite);assertTrue(a.db.library().get(a.id).watched);assertTrue(b.db.library().get(b.id).favorite);assertTrue(b.db.library().get(b.id).watched);
    }
    @Test public void sourceFileAbsenceNeverDeletesLocalRecordsOrLists()throws Exception {
        Playlist list=new Playlist();list.id="local-list";list.name="Conservar";b.db.library().insertPlaylist(list);var r=review(packet(a),b);apply(b,r,all(r));assertNotNull(b.db.library().playlist("local-list"));
    }
    @Test public void unresolvedListMembersAreProtectedAndRemainInTheOriginalPacket()throws Exception {
        MediaEntry second=a.add("content://own/a-two","two.mp4","A / sub",100);Playlist list=new Playlist();list.id="same-list";list.name="Mi lista";a.db.library().insertPlaylist(list);b.db.library().insertPlaylist(list);PlaylistItem ia=new PlaylistItem();ia.playlistId=list.id;ia.mediaId=second.id;a.db.library().insertPlaylistItem(ia);PlaylistItem ib=new PlaylistItem();ib.playlistId=list.id;ib.mediaId=b.id;b.db.library().insertPlaylistItem(ib);
        var p=packet(a);var r=review(p,b);assertTrue(r.blocked.contains(FieldMerge.key("playlists",list.id)+"\0items"));apply(b,r,all(r));assertEquals(b.id,b.db.library().playlistItems(list.id).get(0).mediaId);assertEquals(1,p.data.getJSONObject("state").getJSONArray("playlists").getJSONObject(0).getJSONArray("items").length());
    }
    @Test public void previewAndExportNeverWriteLibraryOrAdvanceSyncBases()throws Exception {
        String before=work(()->PortableState.capture(b.db).stamp());var r=review(packet(a),b);assertFalse(b.store.hasUndo());assertTrue(b.store.peers().isEmpty());assertEquals(before,work(()->PortableState.capture(b.db).stamp()));assertNotNull(r);
    }
    @Test public void staleReviewRejectsAllChangesAndDoesNotWriteUndoOrBaseline()throws Exception {
        a.db.library().toggleFavorite(a.id);var r=review(packet(a),b);b.db.library().editMetadata(b.id,"Nuevo local",null);try{apply(b,r,all(r));fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("cambió"));}assertFalse(b.db.library().get(b.id).favorite);assertEquals("Nuevo local",b.db.library().get(b.id).userTitle);assertFalse(b.store.hasUndo());assertTrue(b.store.peers().isEmpty());
    }
    @Test public void undoRestoresExactSnapshotAndRemovesOnlyRowsAddedByTheImport()throws Exception {
        CatalogEntity e=new CatalogEntity();e.id=UUID.randomUUID().toString();e.kind="creator";e.name="Persona propia";e.notes="Notas";a.db.library().insertEntity(e);a.db.library().toggleFavorite(a.id);String before=work(()->PortableState.capture(b.db).stamp());var r=review(packet(a),b);apply(b,r,all(r));assertNotNull(b.db.library().entity(e.id));work(()->{b.store.undo();return null;});assertNull(b.db.library().entity(e.id));assertEquals(before,work(()->PortableState.capture(b.db).stamp()));assertFalse(b.store.hasUndo());assertTrue(b.store.peers().isEmpty());
    }
    @Test public void undoRefusesToOverwriteAnyNewLibraryEdit()throws Exception {
        a.db.library().toggleFavorite(a.id);var r=review(packet(a),b);apply(b,r,all(r));b.db.library().editMetadata(b.id,"Después",null);try{work(()->{b.store.undo();return null;});fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("cambió"));}assertEquals("Después",b.db.library().get(b.id).userTitle);assertTrue(b.db.library().get(b.id).favorite);
    }
    @Test public void journalWriteFailureRollsBackDatabaseAndDoesNotAdvanceBaseline()throws Exception {
        a.db.library().toggleFavorite(a.id);var r=review(packet(a),b);assertTrue(b.store.directory.createNewFile());try{apply(b,r,all(r));fail();}catch(IOException expected){}assertFalse(b.db.library().get(b.id).favorite);assertTrue(b.store.peers().isEmpty());
    }
    @Test public void cancellationBeforeApplyCannotMutateState()throws Exception {
        a.db.library().toggleFavorite(a.id);var r=review(packet(a),b);work(()->{Thread.currentThread().interrupt();try{b.store.apply(r,all(r));fail();}catch(InterruptedIOException expected){}finally{Thread.interrupted();}return null;});assertFalse(b.db.library().get(b.id).favorite);assertFalse(b.store.hasUndo());
    }
    @Test public void jsonReaderRejectsOversizeMalformedUtf8DeepAndTrailingDocuments()throws Exception {
        for(byte[] bad:List.of("{}{}".getBytes(),new byte[]{(byte)255},("[".repeat(41)+"]".repeat(41)).getBytes(),new byte[ExchangeJson.MAX+1]))try{ExchangeJson.read(new ByteArrayInputStream(bad));fail();}catch(Exception expected){}
        assertEquals("[{]}",ExchangeJson.read(new ByteArrayInputStream("{\"text\":\"[{]}\"}".getBytes())).getString("text"));assertEquals("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",ExchangeJson.hash(""));
    }
}
