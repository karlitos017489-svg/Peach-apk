package com.peach.local;

import java.io.*;
import java.util.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class ExchangeGraph450Test {
    Exchange450Test f;
    @Before public void start()throws Exception{f=new Exchange450Test();f.setup();}
    @After public void stop()throws Exception{f.stop();}
    CatalogEntity entity(Exchange450Test.Device d,String name){CatalogEntity e=new CatalogEntity();e.id=UUID.randomUUID().toString();e.kind="creator";e.name=name;e.notes="Notas propias";d.db.library().insertEntity(e);return e;}
    @Test public void graphRemapsListsGroupsEntityLinksWantsPublicationsAndReaderProgressToLocalIds()throws Exception {
        var a=f.a;var b=f.b;MediaEntry ma=a.add("content://own/a-pdf","book.pdf","A / sub",30),mb=b.add("content://own/b-pdf","book.pdf","B / sub",30);
        CatalogEntity e=entity(a,"Creadora propia");MediaEntityLink link=new MediaEntityLink();link.entityId=e.id;link.mediaId=ma.id;link.role="creator";a.db.library().insertEntityLink(link);
        WantItem w=new WantItem();w.id=UUID.randomUUID().toString();w.title="Obra propia";w.code="OWN-1";w.entityId=e.id;w.mediaId=ma.id;a.db.library().insertWant(w);
        Publication p=new Publication();p.id=UUID.randomUUID().toString();p.title="Publicación propia";p.entityId=e.id;p.mediaId=ma.id;a.db.library().insertPublication(p);
        ReaderProgress reading=new ReaderProgress();reading.mediaId=ma.id;reading.entry="";reading.page=2;reading.scroll=15;reading.updatedAt=100;ReaderStore.save(a.db,reading);
        Playlist list=new Playlist();list.id=UUID.randomUUID().toString();list.name="Orden propio";a.db.library().insertPlaylist(list);PlaylistItem item=new PlaylistItem();item.playlistId=list.id;item.mediaId=ma.id;a.db.library().insertPlaylistItem(item);
        MediaGroup group=new MediaGroup();group.id=UUID.randomUUID().toString();group.name="Grupo propio";a.db.library().insertGroup(group);MediaGroupItem member=new MediaGroupItem();member.groupId=group.id;member.mediaId=ma.id;a.db.library().insertGroupItem(member);
        var packet=f.packet(a);assertFalse(packet.encoded.contains("content://own/"));f.work(()->{PortableState.validate(a.context,packet);return null;});var review=f.review(packet,b);f.apply(b,review,f.all(review));
        assertEquals(mb.id,b.db.library().want(w.id).mediaId);assertEquals(mb.id,b.db.library().publication(p.id).mediaId);assertEquals(mb.id,b.db.library().entityLinks().get(0).mediaId);assertEquals(2,b.db.library().readerProgress(mb.id).page);assertEquals(mb.id,b.db.library().playlistItems(list.id).get(0).mediaId);assertEquals(mb.id,b.db.library().groupItems(group.id).get(0).mediaId);
    }
    @Test public void invalidEntityNameConflictRejectsWholeReviewWithoutPartialFavoriteChange()throws Exception {
        var a=f.a;var b=f.b;entity(a,"Mismo nombre");entity(b,"Mismo nombre");a.db.library().toggleFavorite(a.id);var review=f.review(f.packet(a),b);String before=f.work(()->PortableState.capture(b.db).stamp());try{f.apply(b,review,f.all(review));fail();}catch(IllegalArgumentException expected){}assertEquals(before,f.work(()->PortableState.capture(b.db).stamp()));assertFalse(b.store.hasUndo());
    }
    @Test public void existingLocalLinksOutsideMappedDocumentsAreNotRemovedByIncomingGroup()throws Exception {
        var a=f.a;var b=f.b;CatalogEntity e=entity(a,"Persona");CatalogEntity copy=new CatalogEntity();copy.id=e.id;copy.kind=e.kind;copy.name=e.name;b.db.library().insertEntity(copy);MediaEntry extra=b.add("content://own/local-only","local.pdf","B",30);MediaEntityLink link=new MediaEntityLink();link.entityId=e.id;link.mediaId=extra.id;link.role="creator";b.db.library().insertEntityLink(link);var review=f.review(f.packet(a),b);f.apply(b,review,f.all(review));assertEquals(extra.id,b.db.library().entityLinks().get(0).mediaId);
    }
    @Test public void malformedTypedReferenceCannotBeHiddenByAnUnmappedMediaRow()throws Exception {
        var p=f.packet(f.a);JSONObject j=Exchange450Test.encoded(p);j.getJSONObject("data").getJSONObject("state").getJSONArray("readerProgress").put(new JSONObject().put("mediaId",j.getJSONObject("data").getJSONArray("media").getJSONObject(0).getString("id")).put("entry","").put("page",1).put("scroll",0).put("updatedAt",1));try{Exchange450Test.resign(j);fail();}catch(IOException expected){}
    }
    @Test public void unchangedSourceTransportStateAndPrivatePreferencesSurviveMetadataImportAndUndo()throws Exception {
        var a=f.a;var b=f.b;FollowSource s=new FollowSource();s.id=SourceProviders.key("fanbox","owncreator");s.provider="fanbox";s.ref="owncreator";s.label="Fuente propia";s.nextPage=1;s.revision=12;b.db.library().insertSource(s);b.context.getSharedPreferences("private-own",0).edit().putString("cookie","KEEP_PRIVATE").commit();
        a.db.library().toggleFavorite(a.id);var r=f.review(f.packet(a),b);f.apply(b,r,f.all(r));assertEquals(12,b.db.library().source(s.id).revision);assertEquals("[]",b.db.library().source(s.id).cachedPage);f.work(()->{b.store.undo();return null;});assertEquals(12,b.db.library().source(s.id).revision);assertEquals("KEEP_PRIVATE",b.context.getSharedPreferences("private-own",0).getString("cookie",""));
    }
    @Test public void noOpImportKeepsTheLastMeaningfulUndo()throws Exception {
        var a=f.a;var b=f.b;a.db.library().toggleFavorite(a.id);var p=f.packet(a);var r=f.review(p,b);f.apply(b,r,f.all(r));assertTrue(b.db.library().get(b.id).favorite);f.apply(b,f.review(p,b),Map.of());f.work(()->{b.store.undo();return null;});assertFalse(b.db.library().get(b.id).favorite);
    }
    @Test public void historyVisitsAreAtomicAndLatestKnownUpdateIsNotCountedTwice()throws Exception {
        var a=f.a;var b=f.b;String id=UUID.randomUUID().toString();UsageStore own=new UsageStore(a.db);own.begin(id,a.id,"video",100);own.checkpoint(id,5,20,"",0,0,"paused",false,200);var p=f.packet(a);var r=f.review(p,b);f.apply(b,r,f.all(r));assertEquals(1,b.db.library().usageCount());assertEquals(b.id,b.db.library().usage(id).mediaId);assertEquals(5,b.db.library().usage(id).position);
        own.checkpoint(id,10,20,"",0,0,"paused",false,300);r=f.review(f.packet(a),b);assertEquals("visit",f.field(r,"usageSessions","visit").field());f.apply(b,r,f.all(r));assertEquals(10,b.db.library().usage(id).position);assertEquals(1,b.db.library().usageCount());try{f.review(p,b);fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("anterior"));}assertEquals(10,b.db.library().usage(id).position);
    }
    @Test public void portableMetadataIncludesFirstAddedDateWithoutChangingLocationOrOriginalBytes()throws Exception {
        var a=f.a;var b=f.b;var packet=f.packet(a);long added=a.db.library().get(a.id).addedAt;String uri=b.db.library().get(b.id).uri;var r=f.review(packet,b);f.apply(b,r,f.all(r));assertEquals(added,b.db.library().get(b.id).addedAt);assertEquals(uri,b.db.library().get(b.id).uri);assertEquals(100,b.db.library().get(b.id).bytes);
    }
    @Test public void fifthOriginRequiresExplicitForgetWithoutRemovingImportedData()throws Exception {
        var b=f.b;PortableState.Packet base=f.packet(f.a);for(int i=0;i<4;i++){JSONObject raw=Exchange450Test.encoded(base);raw.put("peer",UUID.randomUUID().toString());var packet=Exchange450Test.resign(raw);f.apply(b,f.review(packet,b),Map.of());}assertEquals(4,b.store.peers().size());JSONObject raw=Exchange450Test.encoded(base);raw.put("peer",UUID.randomUUID().toString());var packet=Exchange450Test.resign(raw);try{f.apply(b,f.review(packet,b),Map.of());fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("cuatro"));}b.store.forget(b.store.peers().get(0));f.apply(b,f.review(packet,b),Map.of());assertEquals(4,b.store.peers().size());assertEquals(1,b.db.library().allMedia().size());
    }
    @Test public void physicalUriChangeAfterReviewInvalidatesEvenWhenPathSizeAndPersonalFieldsMatch()throws Exception {
        f.a.db.library().toggleFavorite(f.a.id);var r=f.review(f.packet(f.a),f.b);f.b.db.getOpenHelper().getWritableDatabase().execSQL("UPDATE media SET uri=? WHERE id=?",new Object[]{"content://own/moved-current-document",f.b.id});try{f.apply(f.b,r,f.all(r));fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("cambió"));}assertFalse(f.b.db.library().get(f.b.id).favorite);assertEquals("content://own/moved-current-document",f.b.db.library().get(f.b.id).uri);
    }
    @Test public void refreshOfTheScanInvalidatesReviewBeforeAnyIncomingChangesAreCommitted()throws Exception {
        f.a.db.library().toggleFavorite(f.a.id);var r=f.review(f.packet(f.a),f.b);f.b.db.library().rootState(f.b.root,1);try{f.apply(f.b,r,f.all(r));fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("cambió"));}assertFalse(f.b.db.library().get(f.b.id).favorite);
    }

    @Test public void generatedExchangeExamplePassesTheProductionParserAndDetachedRoomValidation()throws Exception {
        try(var in=ExchangeGraph450Test.class.getClassLoader().getResourceAsStream("exchange450/Peach-ejemplo-intercambio.json")){assertNotNull(in);var packet=new PortableState.Packet(ExchangeJson.read(in));f.work(()->{PortableState.validate(f.a.context,packet);return null;});assertEquals("Ejemplo propio Peach",packet.label);assertEquals(1,packet.data.getJSONArray("media").length());}
    }
    @Test public void manualReaderMappingDoesNotTreatPdfAndEpubAsTheSameFamily()throws Exception {
        f.a.add("content://own/pdf","book.pdf","A",50);MediaEntry wrong=f.b.add("content://own/epub","book.epub","B",50);var packet=f.packet(f.a);String pdf="";for(int i=0;i<packet.data.getJSONArray("media").length();i++){var row=packet.data.getJSONArray("media").getJSONObject(i);if(row.getString("name").equals("book.pdf"))pdf=row.getString("id");}String id=pdf;var review=f.work(()->f.b.store.review(packet,Map.of(),Map.of(id,wrong.id)));assertTrue(review.mapping.stream().filter(m->m.remote().equals(id)).allMatch(m->m.local().isEmpty()));
    }

    @Test public void sourceSequenceSurvivesReopeningStoreAndDoesNotDependOnWallClock()throws Exception {
        var first=f.packet(f.a);var another=f.work(()->new ExchangeStore(f.a.context,f.a.db).export("Reopened"));assertTrue(another.sequence>first.sequence);assertEquals(first.peer,another.peer);assertEquals(first.digest,another.digest);
    }
    @Test public void oldVersionCannotRollBackStateEvenIfItsTimestampLooksNewer()throws Exception {
        var old=f.packet(f.a);f.apply(f.b,f.review(old,f.b),Map.of());f.a.db.library().toggleFavorite(f.a.id);var fresh=f.packet(f.a);f.apply(f.b,f.review(fresh,f.b),Map.of());assertTrue(f.b.db.library().get(f.b.id).favorite);JSONObject modified=Exchange450Test.encoded(old);modified.put("createdAt",9000000000000000L);var deceptive=Exchange450Test.resign(modified);try{f.review(deceptive,f.b);fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("anterior"));}assertTrue(f.b.db.library().get(f.b.id).favorite);
    }
    @Test public void sameSourceVersionWithDifferentContentsIsNotAcceptedAsAnotherUpdate()throws Exception {
        var packet=f.packet(f.a);f.apply(f.b,f.review(packet,f.b),Map.of());JSONObject fork=Exchange450Test.encoded(packet);fork.getJSONObject("data").getJSONObject("state").getJSONArray("items").getJSONObject(0).put("favorite",true);var different=Exchange450Test.resign(fork);try{f.review(different,f.b);fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("misma versión"));}assertFalse(f.b.db.library().get(f.b.id).favorite);
    }
    @Test public void changingOnlyTheSyncBaseInvalidatesAnAlreadyPreparedReview()throws Exception {
        var older=f.review(f.packet(f.a),f.b);String before=f.work(()->PortableState.capture(f.b.db).stamp());var newer=f.review(f.packet(f.a),f.b);f.apply(f.b,newer,Map.of());assertEquals(before,f.work(()->PortableState.capture(f.b.db).stamp()));try{f.apply(f.b,older,Map.of());fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("base de sincronización cambió"));}
    }
    @Test public void canonicalJsonIsStableForSlashesAccentsEmojiAndEscapedControlCharacters()throws Exception {
        JSONObject object=new JSONObject().put("path","sub/capa-ñ/😀").put("text","linea\n\"\\");String expected="{\"path\":\"sub/capa-ñ/😀\",\"text\":\"linea\\n\\\"\\\\\"}";assertEquals(expected,ExchangeJson.canonical(object));assertEquals(ExchangeJson.canonical(object),ExchangeJson.canonical(new JSONObject(object.toString())));
    }

    @Test public void unmappedRemoteCatalogBindingCannotClearAnExistingLocalCorrespondence()throws Exception {
        String label="Catálogo propio",id=CatalogBridge.key(label,"snapshot","");for(var device:List.of(f.a,f.b)){CatalogSnapshot snapshot=new CatalogSnapshot();snapshot.id=id;snapshot.label=label;snapshot.payload=CatalogFixture.transfer().encoded();snapshot.bindings=new JSONObject().put("1",device.id).toString();snapshot.importedAt=device==f.a?100:200;device.db.library().putSnapshot(snapshot);}
        var packet=f.packet(f.a);var review=f.work(()->f.b.store.review(packet,Map.of(),Map.of()));assertTrue(review.blocked.stream().anyMatch(x->x.endsWith("unresolvedBindings")));f.apply(f.b,review,f.all(review));assertEquals(f.b.id,new JSONObject(f.b.db.library().snapshot(id).bindings).getString("1"));assertEquals(100,f.b.db.library().snapshot(id).importedAt);
    }

}
