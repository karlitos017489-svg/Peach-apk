package com.peach.local;

import android.app.Activity;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;
import org.robolectric.shadows.*;
import org.robolectric.util.ReflectionHelpers;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land") @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class ExchangeUi450Test {
    Exchange450Test fixture;ActivityController<ExchangeActivity> screen;ExchangeActivity activity;ExchangeModel model;
    @Before public void start()throws Exception{File leftovers=new File(RuntimeEnvironment.getApplication().getNoBackupFilesDir(),"peach-exchange");if(leftovers.exists())GalleryProvidersTest.remove(leftovers);fixture=new Exchange450Test();fixture.setup();ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",fixture.b.db);screen=Robolectric.buildActivity(ExchangeActivity.class).setup().visible();activity=screen.get();model=activity.model;if(model.store.directory.exists())GalleryProvidersTest.remove(model.store.directory);model.updates.setValue(1);idle();}
    @After public void stop()throws Exception{if(screen!=null)screen.pause().stop().destroy();if(model!=null)assertTrue(model.worker.awaitTermination(30,TimeUnit.SECONDS));fixture.stop();ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);}
    void idle(){Shadows.shadowOf(Looper.getMainLooper()).idle();}
    void await()throws Exception{idle();model.worker.submit(()->{}).get(30,TimeUnit.SECONDS);idle();}
    static Button find(View v,String label){if(v instanceof Button b && b.getText().toString().equals(label))return b;if(v instanceof ViewGroup g)for(int i=0;i<g.getChildCount();i++){Button found=find(g.getChildAt(i),label);if(found!=null)return found;}return null;}
    static ListView listView(View v){if(v instanceof ListView list)return list;if(v instanceof ViewGroup g)for(int i=0;i<g.getChildCount();i++){ListView found=listView(g.getChildAt(i));if(found!=null)return found;}return null;}
    Button button(String label){Button b=find(activity.getWindow().getDecorView(),label);assertNotNull(label,b);return b;}
    static EditText edit(View v){if(v instanceof EditText e)return e;if(v instanceof ViewGroup g)for(int i=0;i<g.getChildCount();i++){EditText found=edit(g.getChildAt(i));if(found!=null)return found;}return null;}
    AlertDialog dialog(){idle();return (AlertDialog)ShadowDialog.getLatestDialog();}
    Uri input(AtomicReference<String> text){Uri uri=Uri.parse("content://own.exchange/document/"+UUID.randomUUID());Shadows.shadowOf(activity.getContentResolver()).registerInputStreamSupplier(uri,()->new ByteArrayInputStream(text.get().getBytes(StandardCharsets.UTF_8)));return uri;}
    void load(PortableState.Packet p)throws Exception{model.load(input(new AtomicReference<>(p.encoded)));await();assertNotNull(model.message,model.review);}
    @Test public void openingAndRotatingDoesNotReadACloudFileMutateDatabaseOrCreateNetworkWork()throws Exception {
        assertFalse(model.busy);assertNull(model.packet);assertNull(model.selected);assertFalse(button("Aplicar cambios elegidos").isEnabled());String before=fixture.work(()->PortableState.capture(fixture.b.db).stamp());ExchangeModel old=model;screen.recreate();activity=screen.get();model=activity.model;idle();assertSame(old,model);assertEquals(before,fixture.work(()->PortableState.capture(fixture.b.db).stamp()));assertTrue(model.store.peers().isEmpty());
    }
    @Test public void pickerIsOpenableJsonAndDoesNotApplyIncomingUntilExplicitReview()throws Exception {
        button("Elegir intercambio para revisar").performClick();var request=Shadows.shadowOf(activity).getNextStartedActivityForResult();assertEquals(Intent.ACTION_OPEN_DOCUMENT,request.intent.getAction());assertEquals("application/json",request.intent.getType());assertTrue(request.intent.hasCategory(Intent.CATEGORY_OPENABLE));assertNull(model.packet);
        fixture.a.db.library().toggleFavorite(fixture.a.id);var packet=fixture.packet(fixture.a);Uri uri=input(new AtomicReference<>(packet.encoded));activity.getActivityResultRegistry().dispatchResult(request.requestCode,Activity.RESULT_OK,new Intent().setData(uri));await();assertNotNull(model.review);assertFalse(fixture.b.db.library().get(fixture.b.id).favorite);assertTrue(model.review.mapping.stream().allMatch(m->m.local().isEmpty()));
    }
    @Test public void rootSelectionReviewAndApplyPersistOnlyChosenFieldAndDraftSurvivesRotation()throws Exception {
        fixture.a.db.library().toggleFavorite(fixture.a.id);load(fixture.packet(fixture.a));button("Vincular carpetas y documentos").performClick();dialog().getListView().performItemClick(null,0,0);dialog().getListView().performItemClick(null,1,1);await();assertEquals(fixture.b.id,model.review.mapping.get(0).local());
        var choice=fixture.field(model.review,"items","favorite");model.choices.put(choice.key(),true);ExchangeModel retained=model;screen.recreate();activity=screen.get();model=activity.model;idle();assertSame(retained,model);assertTrue(model.choices.get(choice.key()));
        button("Aplicar cambios elegidos").performClick();dialog().getButton(AlertDialog.BUTTON_POSITIVE).performClick();await();assertTrue(model.message,fixture.b.db.library().get(fixture.b.id).favorite);assertNull(model.review);assertTrue(button("Deshacer última importación").isEnabled());
    }
    @Test public void cloudDocumentChangedAfterReviewIsDetectedBeforeMutation()throws Exception {
        fixture.a.db.library().toggleFavorite(fixture.a.id);PortableState.Packet p=fixture.packet(fixture.a);AtomicReference<String> body=new AtomicReference<>(p.encoded);Uri uri=input(body);model.load(uri);await();model.rootBindings.put(p.data.getJSONArray("roots").getJSONObject(0).getString("id"),fixture.b.root);model.refresh();await();for(var c:model.review.fields.changes)model.choices.put(c.key(),true);
        body.set(fixture.packet(fixture.a).encoded);model.apply();await();assertTrue(model.message,model.message.contains("archivo de intercambio cambió"));assertFalse(fixture.b.db.library().get(fixture.b.id).favorite);assertTrue(model.store.peers().isEmpty());assertFalse(model.store.hasUndo());
    }
    @Test public void exportPreparesBeforeCreatePickerAndSavedDocumentIsVerified()throws Exception {
        button("Exportar nueva versión").performClick();AlertDialog label=dialog();edit(label.getWindow().getDecorView()).setText("Tablet propia");label.getButton(AlertDialog.BUTTON_POSITIVE).performClick();await();var request=Shadows.shadowOf(activity).getNextStartedActivityForResult();assertEquals(Intent.ACTION_CREATE_DOCUMENT,request.intent.getAction());assertTrue(request.intent.getStringExtra(Intent.EXTRA_TITLE).endsWith(".json"));
        Uri out=Uri.parse("content://own.export/document/new");ByteArrayOutputStream bytes=new ByteArrayOutputStream();Shadows.shadowOf(activity.getContentResolver()).registerOutputStream(out,bytes);Shadows.shadowOf(activity.getContentResolver()).registerInputStreamSupplier(out,()->new ByteArrayInputStream(bytes.toByteArray()));activity.getActivityResultRegistry().dispatchResult(request.requestCode,Activity.RESULT_OK,new Intent().setData(out));await();assertTrue(model.message,model.message.contains("guardada y comprobada"));assertFalse(bytes.toString("UTF-8").contains("content://own/"));assertEquals("Tablet propia",new org.json.JSONObject(bytes.toString("UTF-8")).getString("label"));
    }
    @Test public void failedOrTruncatedNewDestinationDeletesOnlyThatNewDocumentAndKeepsPreparedExport()throws Exception {
        PortableState.Packet p=fixture.packet(fixture.a);var app=RuntimeEnvironment.getApplication();DownloadFlowTest.DeletingProvider.deleted=0;AtomicReference<Uri> removed=new AtomicReference<>();ShadowContentResolver.registerProviderInternal("own.exchange.delete",new DownloadFlowTest.DeletingProvider(){@Override public Bundle call(String method,String arg,Bundle extras){if(method.equals("android:deleteDocument"))removed.set(extras.getParcelable("uri"));return super.call(method,arg,extras);}});Uri uri=Uri.parse("content://own.exchange.delete/document/new");File original=Files.createTempFile("own-older-exchange-",".json").toFile();Files.write(original.toPath(),"OLDER USER FILE".getBytes(StandardCharsets.UTF_8));ByteArrayOutputStream output=new ByteArrayOutputStream();Shadows.shadowOf(app.getContentResolver()).registerOutputStream(uri,output);Shadows.shadowOf(app.getContentResolver()).registerInputStreamSupplier(uri,()->new ByteArrayInputStream(Arrays.copyOf(output.toByteArray(),Math.min(3,output.size()))));
        try{fixture.work(()->{ExchangeDocuments.writeNew(app,uri,p);return null;});fail();}catch(Exception expected){}assertEquals(1,DownloadFlowTest.DeletingProvider.deleted);assertEquals(uri,removed.get());assertArrayEquals("OLDER USER FILE".getBytes(StandardCharsets.UTF_8),Files.readAllBytes(original.toPath()));assertTrue(original.delete());assertEquals(p.encoded,new String(output.toByteArray(),StandardCharsets.UTF_8));
    }
    @Test public void importedDraftDoesNotReadAgainOnRotationOrAutoApplyAfterReturning()throws Exception {
        var p=fixture.packet(fixture.a);AtomicInteger reads=new AtomicInteger();Uri uri=Uri.parse("content://own.exchange/once");Shadows.shadowOf(activity.getContentResolver()).registerInputStreamSupplier(uri,()->{reads.incrementAndGet();return new ByteArrayInputStream(p.encoded.getBytes(StandardCharsets.UTF_8));});model.load(uri);await();assertEquals(1,reads.get());screen.recreate();activity=screen.get();model=activity.model;idle();assertEquals(1,reads.get());assertNotNull(model.review);assertTrue(model.store.peers().isEmpty());
    }
    @Test public void sourceCatalogRouteRemainsNativeAndNoExternalInputCanSelectAFileAutomatically() {
        button("Catálogo de Peach original (SQLite / JSON)").performClick();assertEquals(CatalogActivity.class.getName(),Shadows.shadowOf(activity).getNextStartedActivity().getComponent().getClassName());assertNull(model.selected);assertNull(model.packet);
    }
    @Test public void pagedReviewCanReachEveryChangeBeyondFirstHundredWithoutApplyingAnything()throws Exception {
        for(int n=0;n<110;n++){WantItem w=new WantItem();w.id=UUID.randomUUID().toString();w.title="Deseo propio "+n;fixture.a.db.library().insertWant(w);}load(fixture.packet(fixture.a));assertEquals(220,model.review.fields.changes.size());button("Revisar cambios por campo").performClick();AlertDialog rows=dialog();assertEquals(100,listView(rows.getWindow().getDecorView()).getCount());find(rows.getWindow().getDecorView(),"Siguientes").performClick();assertEquals(100,listView(rows.getWindow().getDecorView()).getCount());find(rows.getWindow().getDecorView(),"Siguientes").performClick();assertEquals(20,listView(rows.getWindow().getDecorView()).getCount());assertFalse(find(rows.getWindow().getDecorView(),"Siguientes").isEnabled());assertEquals(0,fixture.b.db.library().wants().size());
    }

}
