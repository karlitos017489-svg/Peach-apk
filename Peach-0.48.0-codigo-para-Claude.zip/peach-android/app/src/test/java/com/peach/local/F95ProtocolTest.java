package com.peach.local;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE)
public class F95ProtocolTest {
    static final String SECRET="OWN_F95_SESSION_TOKEN_12345",MASKED="https://f95zone.to/masked/OwnLink_123/",PAGE="https://f95zone.to/threads/123/latest",TARGET="https://gofile.io/d/Own123";
    static F95Session session(){return new F95Session("xf_session="+SECRET+"; theme=dark");}
    static String html(){return "<link rel='canonical' href='https://f95zone.to/threads/123/'><h1 class='p-title-value'>Own thread</h1><article data-content='post-1'><div class='bbWrapper'>Own <a href='"+MASKED+"'>Gofile</a><a href='https://attachments.f95zone.to/own/own.mp4'>Own video</a><img src='https://attachments.f95zone.to/own/own.png'><blockquote>Own hidden</blockquote></div></article>";}
    static class Reply extends PartialDownloadTest.Reply {
        final ByteArrayOutputStream sent=new ByteArrayOutputStream();
        Reply(String url,int status,String body,String mime)throws Exception{super(url,status,body.getBytes(StandardCharsets.UTF_8),null);this.mime=mime;}
        @Override public OutputStream getOutputStream(){return sent;}
    }
    static SourceHttp.Response response(String body){return new SourceHttp.Response(200,body.getBytes(StandardCharsets.UTF_8),"","");}
    @Test public void cookieHeaderIsValidatedCanonicalHiddenAndCannotInjectHeaders()throws Exception{
        var s=new F95Session("Cookie: xf_user=123%2COWN_LONG_TEST_AUTH; xf_session="+SECRET);assertTrue(s.value().startsWith("xf_user="));assertFalse(s.toString().contains(SECRET));assertFalse(s.redact("Own "+SECRET).contains(SECRET));assertTrue(s.containsSecret("https://example.test/"+SECRET));
        for(String bad:List.of("theme=dark","xf_session=x\r\nHost: other.test","xf_session=x; xf_session=y","xf_session=\"own\"","xf_session=own,other","xf_session=own\\bad","xf_session="+"x".repeat(8192)))try{new F95Session(bad);fail();}catch(IllegalArgumentException expected){assertFalse(expected.toString().contains(SECRET));}
    }
    @Test public void exactMaskedPostHasFixedBodyAndNeverFetchesReturnedHost()throws Exception{
        var reply=new Reply(MASKED,200,"{\"status\":\"ok\",\"msg\":\""+TARGET+"\"}","application/json");var factory=new RedirectHttpTest.Factory(reply);var r=F95Http.direct(factory,MediaRedirectsTest.PUBLIC).request(MASKED,true,session(),"","",new SourceHttp.Token());assertEquals(200,r.status());assertEquals(List.of(MASKED),factory.requests);assertEquals("POST",reply.getRequestMethod());assertEquals("xhr=1&download=1",reply.sent.toString("US-ASCII"));assertEquals(session().value(),reply.getRequestProperty("Cookie"));assertEquals("XMLHttpRequest",reply.getRequestProperty("X-Requested-With"));assertNull(reply.getRequestProperty("Authorization"));assertNull(reply.getRequestProperty("Origin"));assertNull(reply.getRequestProperty("Referer"));assertFalse(reply.getInstanceFollowRedirects());assertTrue(reply.closed);
    }
    @Test public void sameThreadRedirectKeepsCookieButCrossThreadAndLoginDoNotConnect()throws Exception{
        String next="https://f95zone.to/threads/own.123/post-1";var first=new Reply(PAGE,302,"","text/html");first.location=next+"#post-1";var second=new Reply(next,200,html()+SECRET,"text/html");var factory=new RedirectHttpTest.Factory(first,second);var r=F95Http.direct(factory,MediaRedirectsTest.PUBLIC).request(PAGE,false,session(),"","",new SourceHttp.Token());assertEquals(List.of(PAGE,next),factory.requests);assertEquals(session().value(),second.getRequestProperty("Cookie"));assertFalse(SourceHttp.utf8(r.bytes()).contains(SECRET));assertEquals(0,first.sent.size());
        for(String location:List.of("https://f95zone.to/threads/999/latest","https://f95zone.to/login/",TARGET,"https://attachments.f95zone.to/own/own.mp4")){var redirect=new Reply(PAGE,302,"","text/html");redirect.location=location;factory=new RedirectHttpTest.Factory(redirect);try{F95Http.direct(factory,MediaRedirectsTest.PUBLIC).request(PAGE,false,session(),"","",new SourceHttp.Token());fail();}catch(IOException expected){}assertEquals(1,factory.requests.size());}
    }
    @Test public void postRedirectAndCaptchaHtmlAreRejectedWithoutFollowingThem()throws Exception{
        for(int status:List.of(302,200)){var reply=new Reply(MASKED,status,"<html>verify "+SECRET+"</html>","text/html");reply.location=TARGET;var factory=new RedirectHttpTest.Factory(reply);try{F95Http.direct(factory,MediaRedirectsTest.PUBLIC).request(MASKED,true,session(),"","",new SourceHttp.Token());fail();}catch(IOException expected){assertFalse(expected.toString().contains(SECRET));}assertEquals(1,factory.requests.size());assertTrue(reply.closed);}
    }
    @Test public void cookieCannotBeSentToOtherRoutesHostsPrivateDnsOrCancelledRequest()throws Exception{
        var factory=new RedirectHttpTest.Factory();var transport=F95Http.direct(factory,MediaRedirectsTest.PUBLIC);for(String u:List.of(TARGET,"https://f95zone.to.evil.test/masked/own","https://sub.f95zone.to/masked/own","https://f95zone.to:443/masked/own","https://f95zone.to/masked/own?x=1","https://f95zone.to/masked/%2e%2e","https://f95zone.to/login/"))try{transport.request(u,true,session(),"","",new SourceHttp.Token());fail(u);}catch(IOException expected){}
        try{F95Http.direct(factory,h->new InetAddress[]{InetAddress.getByName("10.0.0.1")}).request(MASKED,true,session(),"","",new SourceHttp.Token());fail();}catch(IOException expected){}var token=new SourceHttp.Token();token.cancel();try{transport.request(MASKED,true,session(),"","",token);fail();}catch(IOException expected){}assertTrue(factory.requests.isEmpty());
    }
    @Test public void actualHttpDenialAndRateLimitHaveSanitizedStatusAndDoNotReadBodies()throws Exception{
        for(int status:List.of(401,403,429)){var reply=new Reply(MASKED,status,SECRET,"text/html"){@Override public InputStream getInputStream(){throw new AssertionError("Denied response must not be read");}};reply.headers.put("Retry-After","120");try{F95Http.direct(new RedirectHttpTest.Factory(reply),MediaRedirectsTest.PUBLIC).request(MASKED,true,session(),"","",new SourceHttp.Token());fail();}catch(SourceHttp.Failure expected){assertEquals(status,expected.status);assertFalse(expected.toString().contains(SECRET));if(status==429)assertEquals(120,expected.retrySeconds);}assertTrue(reply.closed);}
    }
    @Test public void metadataSizeCompressionAndUtf8RemainBoundedWithoutCredentialEcho()throws Exception{
        for(int mode=0;mode<3;mode++){var reply=new Reply(MASKED,200,mode==0?"x".repeat(SourceHttp.JSON_LIMIT+1):"{}","application/json");if(mode==1)reply.headers.put("Content-Encoding","gzip");if(mode==2){reply.bytes=new byte[]{(byte)0xff};reply.declared=1;}try{F95Http.direct(new RedirectHttpTest.Factory(reply),MediaRedirectsTest.PUBLIC).request(MASKED,true,session(),"","",new SourceHttp.Token());fail();}catch(IOException expected){assertFalse(expected.toString().contains(SECRET));}assertTrue(reply.closed);}
    }
    @Test public void optionalPrivateListUsesOnlyItsDedicatedPortAndPublicModeStillUsesOldTransport()throws Exception{
        int[] publicCalls={0},privateCalls={0};SourceHttp.Transport ordinary=(u,e,m,t)->{publicCalls[0]++;return response(html());};SourceCredentials own=new SourceCredentials(){public ApiKey rule34(){throw new AssertionError();}public F95Session f95(){return session();}};var connector=new WebSourceConnector(ordinary,own,(u,masked,s,e,m,t)->{privateCalls[0]++;assertFalse(masked);assertEquals(PAGE,u);return response(html().replace("Own thread",SECRET));});var rows=connector.list("f95zone","123",0,"","",new SourceHttp.Token()).page().candidates();assertEquals(0,publicCalls[0]);assertEquals(1,privateCalls[0]);assertFalse(rows.toString().contains(SECRET));assertEquals(1,new WebSourceConnector(ordinary,()->null).list("f95zone","123",0,"","",new SourceHttp.Token()).page().candidates().length());assertEquals(1,publicCalls[0]);
    }
    @Test public void directVideoAndSrcImageAreClassifiedWithoutOpeningAnyMedia()throws Exception{
        var rows=new WebSourceConnector((u,e,m,t)->response(html()),()->null).list("f95zone","123",0,"","",new SourceHttp.Token()).page().candidates();var a=rows.getJSONObject(0).getJSONArray("attachments");assertTrue(java.util.stream.IntStream.range(0,a.length()).mapToObj(i->a.optJSONObject(i)).anyMatch(j->j.optString("kind").equals("video")));assertTrue(java.util.stream.IntStream.range(0,a.length()).mapToObj(i->a.optJSONObject(i)).anyMatch(j->j.optString("kind").equals("image")));assertFalse(rows.toString().contains("Own hidden"));
    }
}
