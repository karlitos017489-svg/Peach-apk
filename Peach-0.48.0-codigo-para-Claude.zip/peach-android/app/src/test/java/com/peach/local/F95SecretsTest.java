package com.peach.local;
import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.concurrent.*;
import javax.crypto.spec.SecretKeySpec;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE)
public class F95SecretsTest {
    File dir;F95Secrets vault;
    @Before public void before()throws Exception{dir=Files.createTempDirectory("own-f95-vault-").toFile();vault=new F95Secrets(new File(dir,"session.bin"),new File(dir,"wait.txt"),()->new SecretKeySpec(new byte[16],"AES"));}
    @After public void after(){vault.clear();for(File f:Objects.requireNonNull(dir.listFiles()))f.delete();dir.delete();}
    @Test public void encryptionRoundTripUsesNewIvAndNeverStoresPlainCookie()throws Exception{assertNull(vault.read());vault.write(F95ProtocolTest.session());byte[] first=Files.readAllBytes(vault.file.toPath());assertFalse(new String(first,java.nio.charset.StandardCharsets.ISO_8859_1).contains(F95ProtocolTest.SECRET));assertEquals(F95ProtocolTest.session(),vault.read());vault.write(F95ProtocolTest.session());assertFalse(Arrays.equals(first,Files.readAllBytes(vault.file.toPath())));assertEquals(F95ProtocolTest.session(),vault.read());}
    @Test public void tamperWrongKeyAndUnavailableKeystoreDoNotFallBackToPlaintext()throws Exception{vault.write(F95ProtocolTest.session());byte[] b=Files.readAllBytes(vault.file.toPath());b[b.length-1]^=1;Files.write(vault.file.toPath(),b);try{vault.read();fail();}catch(IOException expected){assertFalse(expected.toString().contains(F95ProtocolTest.SECRET));}vault.write(F95ProtocolTest.session());byte[] other=new byte[16];other[0]=1;var wrong=new F95Secrets(vault.file,vault.wait,()->new SecretKeySpec(other,"AES"));try{wrong.read();fail();}catch(IOException expected){}vault.clear();var absent=new F95Secrets(vault.file,vault.wait,()->{throw new GeneralSecurityException();});try{absent.write(F95ProtocolTest.session());fail();}catch(IOException expected){}assertFalse(vault.file.exists());}
    @Test public void waitSurvivesSessionRemovalChangeAndNewInstanceAndIsMonotonic()throws Exception{long end=System.currentTimeMillis()+300000;vault.write(F95ProtocolTest.session());vault.waitUntil(end);vault.clear();assertNull(vault.read());vault.write(new F95Session("xf_session=OWN_OTHER_SESSION_TOKEN"));var next=new F95Secrets(vault.file,vault.wait,()->new SecretKeySpec(new byte[16],"AES"));assertTrue(next.waitUntil()>=end);next.waitUntil(System.currentTimeMillis());assertTrue(next.waitUntil()>=end);}
    @Test public void distinctInstancesSerializeAtomicSessionReadsAndWrites()throws Exception{var second=new F95Secrets(vault.file,vault.wait,()->new SecretKeySpec(new byte[16],"AES"));vault.write(F95ProtocolTest.session());ExecutorService worker=Executors.newFixedThreadPool(2);try{var a=worker.submit(()->{for(int i=0;i<12;i++)try{vault.write(F95ProtocolTest.session());}catch(IOException e){throw new AssertionError(e);}});var b=worker.submit(()->{for(int i=0;i<12;i++)try{assertEquals(F95ProtocolTest.session(),second.read());}catch(IOException e){throw new AssertionError(e);}});a.get(10,TimeUnit.SECONDS);b.get(10,TimeUnit.SECONDS);}finally{worker.shutdownNow();assertTrue(worker.awaitTermination(10,TimeUnit.SECONDS));}}
}
