package com.peach.local;

import android.os.Looper;
import androidx.media3.common.*;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.List;

/** Deterministic Player protocol fixture; does not claim decoding or Android audio output. */
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
final class FakeAudioPlayer extends SimpleBasePlayer {
    State state=new State.Builder().setAvailableCommands(new Player.Commands.Builder().addAllCommands().build()).build();
    boolean released;int replacements;long serial;List<MediaItemData> playlist=List.of();
    FakeAudioPlayer(){super(Looper.getMainLooper());}
    @Override protected State getState(){return state;}
    @Override protected ListenableFuture<?> handleSetMediaItems(List<MediaItem> items,int index,long position){
        replacements++;long generation=++serial;playlist=items.stream().map(item->new MediaItemData.Builder(item.mediaId+generation).setMediaItem(item).setIsSeekable(true).setDurationUs(20_000_000).build()).toList();
        state=state.buildUpon().setPlaylist(playlist).setPlaybackState(STATE_IDLE).setCurrentMediaItemIndex(items.isEmpty()?C.INDEX_UNSET:Math.max(0,index)).setContentPositionMs(position==C.TIME_UNSET?0:position).build();return Futures.immediateVoidFuture();
    }
    @Override protected ListenableFuture<?> handleSetPlayWhenReady(boolean ready){state=state.buildUpon().setPlayWhenReady(ready,PLAY_WHEN_READY_CHANGE_REASON_USER_REQUEST).build();return Futures.immediateVoidFuture();}
    @Override protected ListenableFuture<?> handlePrepare(){state=state.buildUpon().setPlaybackState(state.timeline.isEmpty()?STATE_ENDED:STATE_READY).build();return Futures.immediateVoidFuture();}
    @Override protected ListenableFuture<?> handleStop(){state=state.buildUpon().setPlaybackState(STATE_IDLE).build();return Futures.immediateVoidFuture();}
    @Override protected ListenableFuture<?> handleRelease(){released=true;return Futures.immediateVoidFuture();}
    @Override protected ListenableFuture<?> handleRemoveMediaItems(int from,int to){var items=new java.util.ArrayList<>(playlist);items.subList(from,to).clear();playlist=items;state=state.buildUpon().setPlaylist(items).setCurrentMediaItemIndex(items.isEmpty()?C.INDEX_UNSET:0).setPlaybackState(items.isEmpty()?STATE_IDLE:state.playbackState).setContentPositionMs(0).build();return Futures.immediateVoidFuture();}
    @Override protected ListenableFuture<?> handleSeek(int index,long position,int command){state=state.buildUpon().setCurrentMediaItemIndex(index==C.INDEX_UNSET?getCurrentMediaItemIndex():index).setContentPositionMs(position==C.TIME_UNSET?0:position).build();return Futures.immediateVoidFuture();}
    void position(long value){state=state.buildUpon().setContentPositionMs(value).build();invalidateState();}
    void ended(){state=state.buildUpon().setPlaybackState(STATE_ENDED).setContentPositionMs(20000).build();invalidateState();}
    void automaticNext(){state=state.buildUpon().setCurrentMediaItemIndex(1).setContentPositionMs(0).setPositionDiscontinuity(DISCONTINUITY_REASON_AUTO_TRANSITION,0).build();invalidateState();state=state.buildUpon().clearPositionDiscontinuity().build();}
    void failure(){state=state.buildUpon().setPlaybackState(STATE_IDLE).setPlayerError(new PlaybackException("Synthetic decoder failure",null,PlaybackException.ERROR_CODE_DECODING_FAILED)).build();invalidateState();}
}
