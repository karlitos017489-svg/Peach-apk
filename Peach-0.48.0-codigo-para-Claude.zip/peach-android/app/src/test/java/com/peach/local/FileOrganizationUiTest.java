package com.peach.local;
import android.content.Intent;
import android.os.Looper;
import android.view.*;
import android.widget.*;
import java.util.concurrent.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land") @GraphicsMode(GraphicsMode.Mode.NATIVE)
public class FileOrganizationUiTest {
 LibraryDatabase db;
 @Before public void setup(){var app=RuntimeEnvironment.getApplication();db=androidx.room.Room.inMemoryDatabaseBuilder(app,LibraryDatabase.class).allowMainThreadQueries().build();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",db);MediaEntry m=new MediaEntry();m.id="own";m.name="Own.mp4";m.title="Own";m.root=FileOrganizerTest.ROOT;m.uri="content://own.files/tree/root/document/own";m.folder="Root";m.bytes=3;db.library().insertMedia(m);}
 @After public void close()throws Exception{idle();db.close();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);}
 void idle()throws Exception{LibraryDatabase.IO.submit(()->{}).get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}
 View find(View v,String text){if(v instanceof TextView t&&t.getText().toString().equals(text))return v;if(v instanceof ViewGroup g)for(int i=0;i<g.getChildCount();i++){View found=find(g.getChildAt(i),text);if(found!=null)return found;}return null;}
 EditText input(View v){if(v instanceof EditText e)return e;if(v instanceof ViewGroup g)for(int i=0;i<g.getChildCount();i++){EditText e=input(g.getChildAt(i));if(e!=null)return e;}return null;}
 @Test public void screenExposesWholePartOneWithoutStartingAFileMutation()throws Exception{
  Intent intent=new Intent(RuntimeEnvironment.getApplication(),FileOrganizationActivity.class).putExtra("mediaId","own");
  try(var controller=Robolectric.buildActivity(FileOrganizationActivity.class,intent).setup().visible()){
   idle();View root=controller.get().findViewById(android.R.id.content);
   for(String s:new String[]{"Vista previa de renombrado","Vista previa de movimiento","Vista previa de papelera","Vista previa de escritura NFO","Buscar archivos con contenido idéntico","Buscar coincidencias por código NFO","Revisar versiones y partes por nombre","Historial / papelera"})assertNotNull(s,find(root,s));
   assertEquals("Own.mp4",db.library().get("own").name);assertFalse(db.library().get("own").missing);
  }
 }
 @Test public void rotatingKeepsUnappliedRenameAndDoesNotInventConfirmation()throws Exception{
  Intent intent=new Intent(RuntimeEnvironment.getApplication(),FileOrganizationActivity.class).putExtra("mediaId","own");
  try(var controller=Robolectric.buildActivity(FileOrganizationActivity.class,intent).setup().visible()){
   idle();input(controller.get().findViewById(android.R.id.content)).setText("Other.mp4");controller.recreate();idle();assertEquals("Other.mp4",input(controller.get().findViewById(android.R.id.content)).getText().toString());assertEquals("Own.mp4",db.library().get("own").name);
  }
 }
 @Test public void versionsActionReusesNativeReviewWithoutPassingAFileUrl()throws Exception{
  try(var controller=Robolectric.buildActivity(FileOrganizationActivity.class).setup().visible()){
   idle();var activity=controller.get();find(activity.findViewById(android.R.id.content),"Revisar versiones y partes por nombre").performClick();Intent next=Shadows.shadowOf(activity).getNextStartedActivity();assertEquals(VersionsActivity.class.getName(),next.getComponent().getClassName());assertNull(next.getData());assertNull(next.getExtras());
  }
 }
}
