package com.peach.local;
import android.net.Uri;
import android.provider.DocumentsContract;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.junit.*;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE)
public class FileOrganizerTest {
 @Rule public TemporaryFolder temp=new TemporaryFolder();
 static final String ROOT="content://own.files/tree/root",TARGET="content://own.files/tree/target";
 static class OwnFs implements FileOrganizer.Fs{
  final Map<String,FileOrganizer.Doc> nodes=new LinkedHashMap<>();final Map<String,byte[]> data=new HashMap<>();final Map<String,String> parents=new HashMap<>();int changes,seq;boolean allowed=true,throwAfterMove,failWrite,failCreate,throwAfterCreate;String root=FileOrganizer.treeDoc(ROOT),target=FileOrganizer.treeDoc(TARGET);
  OwnFs(){dir(root,"Root");dir(target,"Target");}
  String uri(String id){return DocumentsContract.buildDocumentUriUsingTree(Uri.parse(ROOT),id).toString();}
  void dir(String uri,String name){nodes.put(uri,new FileOrganizer.Doc(uri,name,DocumentsContract.Document.MIME_TYPE_DIR,0,1,65535));}
  String add(String parent,String name,byte[] bytes){String uri=uri("own"+(seq++));nodes.put(uri,new FileOrganizer.Doc(uri,name,"application/octet-stream",bytes.length,1,65535));parents.put(uri,parent);data.put(uri,bytes.clone());return uri;}
  public FileOrganizer.Doc stat(String uri){return nodes.get(uri);}
  public List<FileOrganizer.Doc> children(String parent){return nodes.values().stream().filter(d->parent.equals(parents.get(d.uri()))).toList();}
  public void permit(String root)throws Exception{if(!allowed)throw new IOException("Sin permiso.");}
  public String rename(String uri,String name)throws Exception{String p=parents.get(uri);var old=nodes.get(uri);String result=add(p,name,data.get(uri));nodes.put(result,new FileOrganizer.Doc(result,name,old.mime(),old.size(),old.modified(),old.flags()));nodes.remove(uri);parents.remove(uri);data.remove(uri);changes++;if(throwAfterMove){throwAfterMove=false;throw new IOException("Own interruption after mutation");}return result;}
  public String move(String uri,String parent,String target)throws Exception{assertEquals(parent,parents.get(uri));String result=rename(uri,nodes.get(uri).name());parents.put(result,target);return result;}
  public String create(String parent,String mime,String name)throws Exception{if(failCreate){failCreate=false;throw new IOException("Own failed create");}String u=add(parent,name,new byte[0]);nodes.put(u,new FileOrganizer.Doc(u,name,mime,0,1,65535));changes++;if(throwAfterCreate){throwAfterCreate=false;throw new IOException("Own interrupted create");}return u;}
  public InputStream read(String uri)throws Exception{if(!data.containsKey(uri))throw new FileNotFoundException();return new ByteArrayInputStream(data.get(uri));}
  public void write(String uri,byte[] bytes)throws Exception{var d=nodes.get(uri);if(failWrite){failWrite=false;data.put(uri,Arrays.copyOf(bytes,Math.min(3,bytes.length)));throw new IOException("Own partial write");}data.put(uri,bytes.clone());nodes.put(uri,new FileOrganizer.Doc(uri,d.name(),d.mime(),bytes.length,d.modified()+1,d.flags()));changes++;}
  public void delete(String uri){nodes.remove(uri);parents.remove(uri);data.remove(uri);changes++;}
 }
 LibraryDatabase db;OwnFs fs;File journal;FileOrganizer store;MediaEntry media;
 @Before public void setup()throws Exception{db=androidx.room.Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().build();fs=new OwnFs();journal=new File(temp.newFolder(),"journal.json");store=new FileOrganizer(fs,db,journal);media=row("first.mp4","own geology media".getBytes(StandardCharsets.UTF_8));}
 @After public void close(){ScanWorker.RUNNING.set(0);db.close();}
 MediaEntry row(String name,byte[] b){MediaEntry m=new MediaEntry();m.uri=fs.add(fs.root,name,b);m.id=FileOrganizer.key(m.uri);m.name=name;m.folder="Root";m.root=ROOT;m.title=MediaRules.stem(name);m.bytes=b.length;m.modified=1;m.favorite=true;m.position=44;m.playCount=3;db.library().insertMedia(m);if(db.library().roots().isEmpty()){LibraryRoot root=new LibraryRoot();root.uri=ROOT;root.label="Root";root.state=0;db.library().addRoot(root);}db.library().enqueue(new ScanDirectory(ROOT,fs.root,"Root"));return m;}
 void rejects(Throwing job)throws Exception{try{job.run();fail("Expected controlled rejection");}catch(IOException|IllegalArgumentException expected){}}
 interface Throwing{void run()throws Exception;}
 @Test public void previewDoesNotMutateAndRenamePreservesIdentityProgressAndUndo()throws Exception{
  var p=store.plan(media.id,"rename","renamed.mp4","");assertEquals(0,fs.changes);assertFalse(journal.exists());String id=store.apply(p);MediaEntry after=db.library().get(media.id);assertEquals("renamed.mp4",after.name);assertTrue(after.favorite);assertEquals(44,after.position);assertEquals(3,after.playCount);assertNotEquals(media.uri,after.uri);assertEquals(1,db.library().allMedia().size());
  store.undo(id);after=db.library().get(media.id);assertEquals("first.mp4",after.name);assertEquals(44,after.position);assertEquals("UNDONE",store.history().get(0).getString("state"));
 }
 @Test public void moveRebindsLocationAndUndoRestoresOriginalFolder()throws Exception{String id=store.apply(store.plan(media.id,"move","",TARGET));assertEquals(TARGET,db.library().get(media.id).root);assertEquals(fs.target,fs.parents.get(db.library().get(media.id).uri));store.undo(id);assertEquals(ROOT,db.library().get(media.id).root);assertEquals(fs.root,fs.parents.get(db.library().get(media.id).uri));}
 @Test public void trashKeepsBytesAndHasAnOwnedExcludedFolderAndRestore()throws Exception{String id=store.apply(store.plan(media.id,"trash","",""));var m=db.library().get(media.id);assertTrue(m.missing);assertArrayEquals("own geology media".getBytes(StandardCharsets.UTF_8),fs.data.get(m.uri));assertEquals(1,store.trashDirectories().size());store.undo(id);assertFalse(db.library().get(media.id).missing);assertEquals("first.mp4",db.library().get(media.id).name);}
 @Test public void occupiedDestinationAndChangedExtensionRejectBeforeWriting()throws Exception{fs.add(fs.root,"occupied.mp4",new byte[]{1});rejects(()->store.plan(media.id,"rename","occupied.mp4",""));rejects(()->store.plan(media.id,"rename","first.txt",""));assertEquals(0,fs.changes);}
 @Test public void revokedGrantAndActiveScanRejectWithoutJournal()throws Exception{fs.allowed=false;rejects(()->store.plan(media.id,"rename","next.mp4",""));fs.allowed=true;ScanWorker.RUNNING.incrementAndGet();rejects(()->store.plan(media.id,"rename","next.mp4",""));assertFalse(journal.exists());}
 @Test public void changedSourceMetadataAndNewTargetCollisionInvalidatePreview()throws Exception{var p=store.plan(media.id,"rename","next.mp4","");fs.add(fs.root,"next.mp4",new byte[]{1});rejects(()->store.apply(p));assertEquals(0,fs.changes);}
 @Test public void writeAheadJournalRecoversRenameThatThrewAfterChangingId()throws Exception{var p=store.plan(media.id,"rename","next.mp4","");fs.throwAfterMove=true;rejects(()->store.apply(p));var entry=store.history().get(0);assertEquals("REVIEW",entry.getString("state"));assertEquals("first.mp4",db.library().get(media.id).name);store=new FileOrganizer(fs,db,journal);store.recover(entry.getString("id"));assertEquals("next.mp4",db.library().get(media.id).name);assertEquals("DONE",store.history().get(0).getString("state"));}
 @Test public void undoNeverOverwritesAnExternallyChangedFile()throws Exception{String id=store.apply(store.plan(media.id,"rename","next.mp4",""));String u=db.library().get(media.id).uri;fs.data.put(u,"different bytes!!!".getBytes(StandardCharsets.UTF_8));rejects(()->store.undo(id));assertEquals("next.mp4",db.library().get(media.id).name);}
 @Test public void undoIsOrderedAndAConflictingOriginalNameIsPreserved()throws Exception{String a=store.apply(store.plan(media.id,"rename","two.mp4",""));String b=store.apply(store.plan(media.id,"rename","three.mp4",""));rejects(()->store.undo(a));fs.add(fs.root,"two.mp4",new byte[]{9});rejects(()->store.undo(b));assertEquals("three.mp4",db.library().get(media.id).name);}
 @Test public void rescanningChangedDocumentIdReusesOriginalDatabaseIdentity()throws Exception{store.apply(store.plan(media.id,"rename","next.mp4",""));MediaEntry after=db.library().get(media.id),scanned=new MediaEntry();scanned.id=FileOrganizer.key(after.uri);scanned.uri=after.uri;FileOrganizer.preserveIds(db.library(),List.of(scanned));assertEquals(media.id,scanned.id);}
 @Test public void createdNfoIsVerifiedAndUndoRemovesOnlyThatUnchangedNfo()throws Exception{String id=store.apply(store.plan(media.id,"nfo","",""));var r=store.history().get(0);String uri=r.getString("nfoUri");assertEquals("first",NfoReader.read(fs.read(uri)).title());store.undo(id);assertNull(fs.stat(uri));assertNotNull(fs.stat(media.uri));}
 @Test public void updatingExistingNfoPreservesUnknownFieldsAndExactPriorBackup()throws Exception{byte[] old="<movie><title>Old</title><uniqueid type=\"own\">ABC</uniqueid><custom>keep me</custom></movie>".getBytes(StandardCharsets.UTF_8);String uri=fs.add(fs.root,"first.nfo",old);String id=store.apply(store.plan(media.id,"nfo","",""));assertTrue(new String(fs.data.get(uri),StandardCharsets.UTF_8).contains("keep me"));assertArrayEquals(old,store.nfoBackup(id));store.undo(id);assertArrayEquals(old,fs.data.get(uri));}
 @Test public void partialNfoWriteRetainsBackupAndExplicitRestorationChecksCurrentHash()throws Exception{byte[] before="<movie><title>Old</title></movie>".getBytes(StandardCharsets.UTF_8);String uri=fs.add(fs.root,"first.nfo",before);var p=store.plan(media.id,"nfo","","");fs.failWrite=true;rejects(()->store.apply(p));String id=store.history().get(0).getString("id");assertArrayEquals(before,store.nfoBackup(id));rejects(()->store.recover(id));String hash=store.nfoCurrentHash(id);rejects(()->store.restoreNfo(id,"not-the-hash"));store.restoreNfo(id,hash);assertArrayEquals(before,fs.data.get(uri));assertEquals("UNDONE",store.history().get(0).getString("state"));}
 @Test public void nfoEditedAfterPreviewIsNotOverwritten()throws Exception{String uri=fs.add(fs.root,"first.nfo","<movie><title>A</title></movie>".getBytes(StandardCharsets.UTF_8));var p=store.plan(media.id,"nfo","","");fs.write(uri,"<movie><title>B</title></movie>".getBytes(StandardCharsets.UTF_8));int changes=fs.changes;rejects(()->store.apply(p));assertEquals(changes,fs.changes);}
 @Test public void malformedNfoAndUnsafeNamesFailWithoutMutating()throws Exception{for(String n:List.of("../a.mp4","a/b.mp4","a:bad.mp4","\u0000.mp4"," ","x\ud800.mp4"))rejects(()->store.plan(media.id,"rename",n,""));fs.add(fs.root,"first.nfo","<!DOCTYPE a [<!ENTITY x SYSTEM 'file:///private'>]><movie/>".getBytes(StandardCharsets.UTF_8));rejects(()->store.plan(media.id,"nfo","",""));assertEquals(0,fs.changes);}
 @Test public void newOrganizerInstanceDoesNotReplayPendingOperation()throws Exception{var p=store.plan(media.id,"rename","next.mp4","");fs.throwAfterMove=true;rejects(()->store.apply(p));int n=fs.changes;new FileOrganizer(fs,db,journal).history();assertEquals(n,fs.changes);}
 @Test public void identicalContentAndMatchingCodesAreSeparateReviewedEvidence()throws Exception{MediaEntry other=row("other.mp4","own geology media".getBytes(StandardCharsets.UTF_8));var result=OrganizationReview.scan(store,true);assertEquals(1,result.matches().size());String id=OrganizationReview.save(store,result.matches().get(0),List.of(media.id,other.id),"Own duplicates");assertNotNull(db.library().group(id));assertEquals(2,db.library().allMedia().size());assertEquals(0,fs.changes);assertEquals(0,OrganizationReview.scan(store,false).matches().size());}
 @Test public void sameSizeDifferentContentDoesNotBecomeDuplicate()throws Exception{row("other.mp4","different payload".getBytes(StandardCharsets.UTF_8));assertEquals(0,OrganizationReview.scan(store,true).matches().size());}
 @Test public void groupSavingRevalidatesAllSelectedBytes()throws Exception{MediaEntry other=row("other.mp4","own geology media".getBytes(StandardCharsets.UTF_8));var match=OrganizationReview.scan(store,true).matches().get(0);fs.data.put(other.uri,"changed in place!".getBytes(StandardCharsets.UTF_8));rejects(()->OrganizationReview.save(store,match,List.of(media.id,other.id),"Own group"));assertEquals(0,db.library().groups().size());}

 @Test public void codeReviewCanCreateConsecutivePartsAcrossFoldersButRejectsGaps()throws Exception{
  MediaEntry one=row("Film-part1.mp4",new byte[]{1}),two=row("Film-part2.mp4",new byte[]{2});String details=NfoDetails.encode(Map.of("code","OWN-123"));
  db.getOpenHelper().getWritableDatabase().execSQL("UPDATE media SET nfoDetails=?,folder=? WHERE id=?",new Object[]{details,"A",one.id});db.getOpenHelper().getWritableDatabase().execSQL("UPDATE media SET nfoDetails=?,folder=? WHERE id=?",new Object[]{details,"B",two.id});
  var match=OrganizationReview.scan(store,false).matches().get(0);String id=OrganizationReview.saveParts(store,match,List.of(two.id,one.id),"Own parts");assertEquals(List.of(one.id,two.id),db.library().playlistItems(id).stream().map(i->i.mediaId).toList());
  db.getOpenHelper().getWritableDatabase().execSQL("UPDATE media SET name='Film-part3.mp4' WHERE id=?",new Object[]{two.id});var changed=OrganizationReview.scan(store,false).matches().get(0);rejects(()->OrganizationReview.saveParts(store,changed,List.of(one.id,two.id),"Gap"));assertEquals(1,db.library().playlists().size());
 }
 @Test public void cancelledVerificationDoesNotStartProviderMutation()throws Exception{var p=store.plan(media.id,"rename","next.mp4","");store.cancelRequested=true;try{store.apply(p);fail();}catch(InterruptedIOException expected){}assertEquals(0,fs.changes);assertFalse(journal.exists());}
 @Test public void archivingNfoDropsBackupOnlyAfterExplicitAction()throws Exception{String id=store.apply(store.plan(media.id,"nfo","",""));int changes=fs.changes;store.archive(id);assertEquals(changes,fs.changes);assertEquals("ARCHIVED",store.history().get(0).getString("state"));rejects(()->store.undo(id));}
 @Test public void pendingUndoIsReconciledAfterProviderChangedIdentifier()throws Exception{String id=store.apply(store.plan(media.id,"rename","next.mp4",""));fs.throwAfterMove=true;rejects(()->store.undo(id));assertEquals("UNDOING",store.history().get(0).getString("state"));store.recover(id);assertEquals("first.mp4",db.library().get(media.id).name);assertEquals("UNDONE",store.history().get(0).getString("state"));}
 @Test public void corruptedJournalDoesNotTriggerAnyProviderWrite()throws Exception{java.nio.file.Files.write(journal.toPath(),"{broken".getBytes(StandardCharsets.UTF_8));try{store.history();fail();}catch(org.json.JSONException expected){}assertEquals(0,fs.changes);}

 @Test public void failedTrashFolderCreationCanBeCancelledByExplicitReconciliation()throws Exception{
  fs.failCreate=true;rejects(()->store.apply(store.plan(media.id,"trash","","")));String id=store.history().get(0).getString("id");store.recover(id);assertEquals("CANCELLED",store.history().get(0).getString("state"));assertNotNull(fs.stat(db.library().get(media.id).uri));assertFalse(db.library().get(media.id).missing);
 }
 @Test public void folderCreatedBeforeProviderExceptionIsTrackedWithoutMovingTheMedia()throws Exception{
  fs.throwAfterCreate=true;rejects(()->store.apply(store.plan(media.id,"trash","","")));String id=store.history().get(0).getString("id");store.recover(id);assertEquals("CANCELLED",store.history().get(0).getString("state"));assertEquals(1,store.trashDirectories().size());assertEquals(fs.root,fs.parents.get(db.library().get(media.id).uri));
 }
 @Test public void incompleteNewNfoRequiresExplicitRemovalAndNeverDeletesTheMedia()throws Exception{
  fs.failWrite=true;rejects(()->store.apply(store.plan(media.id,"nfo","","")));String id=store.history().get(0).getString("id");String uri=store.history().get(0).getString("nfoUri");rejects(()->store.recover(id));assertEquals("REVIEW",store.history().get(0).getString("state"));assertNotNull(fs.stat(uri));store.restoreNfo(id,store.nfoCurrentHash(id));assertNull(fs.stat(uri));assertNotNull(fs.stat(media.uri));assertEquals("UNDONE",store.history().get(0).getString("state"));
 }
}
