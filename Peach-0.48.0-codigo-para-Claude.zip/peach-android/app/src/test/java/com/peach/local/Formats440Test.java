package com.peach.local;

import java.io.*;
import java.nio.charset.*;
import java.nio.file.*;
import java.util.*;
import org.junit.*;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

public class Formats440Test {
    @Rule public TemporaryFolder temp=new TemporaryFolder();
    static byte[] fixture(String name)throws Exception{try(var in=Formats440Test.class.getClassLoader().getResourceAsStream("formats440/"+name)){assertNotNull(name,in);return in.readAllBytes();}}
    File file(byte[] bytes)throws Exception{File f=temp.newFile();Files.write(f.toPath(),bytes);return f;}
    static int signature(byte[] b,int sig){for(int i=0;i<=b.length-4;i++)if(ZipDirectory.u32(b,i)==Integer.toUnsignedLong(sig))return i;throw new AssertionError();}
    void rejects(byte[] bytes)throws Exception{try(var z=new ZipBook(file(bytes))){fail("Malformed ZIP64 accepted");}catch(IOException expected){}}
    @Test public void fullZip64DirectoryAndLocalFieldsReadExactTextAndNaturallyOrderImages()throws Exception {
        File dir=temp.newFolder();try(var book=new ZipBook(file(fixture("muestra-zip64.cbz")))) {
            assertEquals(List.of("images/2.png","images/10.png","notas.txt"),book.items().stream().map(ArchiveBook.Item::name).toList());
            assertEquals(0,dir.list().length);assertEquals("Muestra propia de lectura ZIP64. Capas y minerales.\n",ArchiveBookTest.readString(book.read("notas.txt",dir).toPath()));
            assertArrayEquals(ReaderSessionTest.class.getClassLoader().getResourceAsStream("media/small.png").readAllBytes(),Files.readAllBytes(book.read("images/2.png",dir).toPath()));
        }
        assertEquals(Set.of("entry"),Set.of(dir.list()));
    }
    @Test public void zip64OverflowTruncationMultiDiskAndMissingLocatorRejectBeforeOutput()throws Exception {
        byte[] good=fixture("muestra-zip64.cbz");int locator=signature(good,0x07064b50),end=signature(good,0x06064b50),central=signature(good,0x02014b50);
        for(int mode=0;mode<8;mode++){byte[] b=good.clone();switch(mode){case 0->b[locator]=0;case 1->b[locator+4]=1;case 2->b[locator+16]=2;case 3->b[locator+15]=(byte)128;case 4->b[end+39]=(byte)128;case 5->b[end+48]++;case 6->b[central+34]=1;case 7->b[end+4]=43;}rejects(b);}
        rejects(Arrays.copyOf(good,good.length-1));
    }
    @Test public void zip64PerEntryFieldOverflowDuplicateExtraAndEncryptedFlagsStayRejected()throws Exception {
        byte[] good=fixture("muestra-zip64.cbz");int central=signature(good,0x02014b50),extra=central+46+ZipDirectory.u16(good,central+28);
        byte[] b=good.clone();b[extra+11]=(byte)128;rejects(b);
        b=good.clone();b[extra]=2;rejects(b);
        b=good.clone();b[central+8]|=1;rejects(b);
        b=good.clone();b[central+10]=9;rejects(b);
    }
    @Test public void zip64CountAndDirectoryBudgetCannotBypassClassicLimits()throws Exception {
        byte[] b=fixture("muestra-zip64.cbz");int at=signature(b,0x06064b50);System.arraycopy(RarBookTest.le(10001,8),0,b,at+24,8);System.arraycopy(RarBookTest.le(10001,8),0,b,at+32,8);rejects(b);
        b=fixture("muestra-zip64.cbz");at=signature(b,0x06064b50);System.arraycopy(RarBookTest.le(17*1024*1024,8),0,b,at+40,8);rejects(b);
    }
    @Test public void zipNamesWithLegacyCp437AreDecodedWithoutGuessingUtf8()throws Exception {
        File f=temp.newFile();try(var out=new java.util.zip.ZipOutputStream(new FileOutputStream(f),Charset.forName("IBM437"))){out.putNextEntry(new java.util.zip.ZipEntry("notas-ñ.txt"));out.write("texto".getBytes(StandardCharsets.UTF_8));out.closeEntry();}
        try(var book=new ZipBook(f)){assertEquals("notas-ñ.txt",book.items().get(0).name());assertEquals("texto",ArchiveBookTest.readString(book.read("notas-ñ.txt",temp.newFolder()).toPath()));}
    }
    @Test public void encrypted7zDataWithBoundedPlainHeaderReadsOnlySelectedEntry()throws Exception {
        byte[] original=fixture("muestra-clave.7z");File f=file(original),dir=temp.newFolder();char[] secret="test-only".toCharArray();
        try(var book=new SevenZipBook(f,secret)){Arrays.fill(secret,'x');assertEquals("Contenido propio: capas y estratos.\n",ArchiveBookTest.readString(book.read("notas.txt",dir).toPath()));assertArrayEquals(original,Files.readAllBytes(f.toPath()));}
        assertEquals(Set.of("entry"),Set.of(dir.list()));
    }
    @Test public void wrongOrAbsent7zPasswordDoesNotReplacePreviousViewOrLeavePart()throws Exception {
        for(char[] password:new char[][]{null,"wrong".toCharArray()}){File f=file(fixture("muestra-clave.7z")),dir=temp.newFolder();Files.write(new File(dir,"entry").toPath(),"anterior".getBytes(StandardCharsets.UTF_8));try(var book=new SevenZipBook(f,password)){try{book.read("notas.txt",dir);fail();}catch(IOException expected){}}assertEquals("anterior",ArchiveBookTest.readString(new File(dir,"entry").toPath()));assertEquals(Set.of("entry"),Set.of(dir.list()));}
    }
    @Test public void encryptedOrEncoded7zHeaderIsExplicitlyOutsidePasswordSubset()throws Exception {
        for(String name:List.of("encrypted-header.7z","encrypted-data.7z")){File f=file(SevenZipBookTest.fixture(name));try(var book=new SevenZipBook(f,"test-only".toCharArray())){fail();}catch(IOException expected){}}
    }
    static byte[] coderHeader(int rounds)throws Exception{return RarBookTest.join(new byte[]{1,4,6,0,1,9,16,0,7,11,1,0,1,0x24,6,(byte)0xf1,7,1,2,(byte)rounds,0,12,1});}
    @Test public void sevenzipPasswordKdfIsBoundedBeforeAnyDecoderCanHash()throws Exception {
        for(int rounds:new int[]{0,19,20,63})SevenZipPasswordPolicy.checkHeader(coderHeader(rounds));
        for(int rounds:new int[]{21,31,62})try{SevenZipPasswordPolicy.checkHeader(coderHeader(rounds));fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("rondas"));}
        for(int length=0;length<coderHeader(19).length;length++)try{SevenZipPasswordPolicy.checkHeader(Arrays.copyOf(coderHeader(19),length));fail();}catch(IOException expected){}
    }
    @Test public void unicodeSubtitlesAndExplicitLegacyTextPreserveAccentsExactly()throws Exception {
        String expected="1\n00:00:00,000 --> 00:00:00,900\nPeach: ñ, acentos y capas.\n";
        for(String charset:List.of("utf-8","utf-16","windows-1252"))assertEquals(expected,new String(SubtitleText.unicode(fixture("muestra-"+charset+".srt"),charset.equals("windows-1252")?charset:"auto"),StandardCharsets.UTF_8));
        assertEquals("ñ",new String(SubtitleText.unicode(new byte[]{(byte)254,(byte)255,0,(byte)241},"auto"),StandardCharsets.UTF_8));
    }
    @Test public void subtitleBinaryMalformedUnicodeUnknownEncodingAndOversizeAreNotGuessed()throws Exception {
        for(byte[] bytes:List.of(new byte[]{0,1},new byte[]{(byte)255},new byte[]{(byte)255,(byte)254,1},new byte[SubtitleText.MAX_BYTES+1]))try{SubtitleText.unicode(bytes,"auto");fail();}catch(IOException expected){}
        try{SubtitleText.unicode(new byte[]{1},"arbitrary");fail();}catch(IOException expected){}
    }
}
