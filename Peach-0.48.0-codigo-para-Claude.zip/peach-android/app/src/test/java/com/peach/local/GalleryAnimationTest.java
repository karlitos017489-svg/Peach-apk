package com.peach.local;

import android.graphics.drawable.AnimatedImageDrawable;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28) @GraphicsMode(GraphicsMode.Mode.NATIVE)
public class GalleryAnimationTest {
    File base;GalleryCache cache;
    @Before public void open()throws Exception{base=Files.createTempDirectory("gallery-own-animation-").toFile();cache=new GalleryCache(base);}
    @After public void close()throws Exception{GalleryProvidersTest.remove(base);}
    GalleryCache.Frame load(String fixture,boolean offline)throws Exception{
        return cache.acquire(new SourceGallery.Image("Original.bin",SourceGalleryTest.A),offline,new SourceHttp.Token(),(u,f,t)->{
            try(InputStream in=getClass().getResourceAsStream("/media/"+fixture)){Files.copy(in,f.toPath(),StandardCopyOption.REPLACE_EXISTING);}
            return new SourceHttp.Download(f.length(),GalleryCache.checksum(f));
        });
    }
    @Test public void gifAndWebpAreRecognizedByBytesAndAnimateFromVerifiedOfflineCache()throws Exception{
        for(String fixture:List.of("own-animated.gif","own-animated.webp")){
            for(File file:cache.root.isDirectory()?cache.root.listFiles():new File[0])file.delete();
            var first=load(fixture,false);assertFalse(first.cached());assertNull(first.image());assertTrue(first.animation() instanceof AnimatedImageDrawable);assertTrue(first.animation().getIntrinsicWidth()>0);first.release();
            var offline=cache.acquire(new SourceGallery.Image("Original.bin",SourceGalleryTest.A),true,new SourceHttp.Token(),(u,f,t)->{fail("Offline must not fetch");return null;});
            assertTrue(offline.cached());var animated=(AnimatedImageDrawable)offline.animation();AnimatedImages.start(animated);assertTrue(animated.isRunning());offline.release();assertFalse(animated.isRunning());
        }
    }
    @Test public void immutableAnimationMappingSurvivesCacheFileRemoval()throws Exception{
        var frame=load("own-animated.gif",false);assertTrue(new File(cache.root,GalleryCache.key(SourceGalleryTest.A)+".image").delete());
        var animated=(AnimatedImageDrawable)frame.animation();AnimatedImages.start(animated);assertTrue(animated.isRunning());assertEquals(64,animated.getIntrinsicWidth());frame.release();assertFalse(animated.isRunning());
    }
    @Test public void brokenGifDoesNotBecomeAReadyCacheEntry()throws Exception{
        try{cache.acquire(new SourceGallery.Image("fake.gif",SourceGalleryTest.A),false,new SourceHttp.Token(),(u,f,t)->{byte[] bytes="GIF89a-own-truncated".getBytes();Files.write(f.toPath(),bytes);return new SourceHttp.Download(bytes.length,GalleryCache.checksum(f));});fail();}catch(IOException|IllegalArgumentException expected){}
        assertEquals(0,cache.root.list().length);
    }
    @Test @Config(sdk=26) public void androidEightKeepsTheStillFrameFallback()throws Exception{
        var frame=load("own-animated.gif",false);assertNull(frame.animation());assertNotNull(frame.image());assertEquals(64,frame.image().originalWidth());assertEquals(48,frame.image().originalHeight());frame.release();
    }
}
