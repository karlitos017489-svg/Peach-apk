package com.peach.local;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28) @GraphicsMode(GraphicsMode.Mode.NATIVE)
public class GalleryCacheTest {
    File base;GalleryCache cache;int calls;
    SourceGallery.Image image=new SourceGallery.Image("../../unsafe.png",SourceGalleryTest.A);
    @Before public void open()throws Exception{base=Files.createTempDirectory("gallery-test-").toFile();cache=new GalleryCache(base);}
    @After public void close()throws Exception{try(var paths=Files.walk(base.toPath())){paths.sorted(Comparator.reverseOrder()).forEach(p->p.toFile().delete());}}
    SourceHttp.Download fetch(String url,File file,SourceHttp.Token token)throws IOException{calls++;try{byte[] b=SourceGalleryTest.png();Files.write(file.toPath(),b);return new SourceHttp.Download(b.length,GalleryCache.checksum(file));}catch(Exception e){throw new IOException(e);}}
    GalleryCache.Frame load(boolean offline)throws Exception{return cache.acquire(image,offline,new SourceHttp.Token(),this::fetch);}
    @Test public void decodesActualPngAndOfflineUsesVerifiedCacheWithoutFetch()throws Exception{var a=load(false);assertFalse(a.cached());assertEquals(120,a.image().originalWidth());assertEquals(60,a.image().originalHeight());a.image().bitmap().recycle();var b=load(true);assertTrue(b.cached());assertEquals(1,calls);b.image().bitmap().recycle();}
    @Test public void tamperingIsRejectedOfflineAndCanBeFetchedAgain()throws Exception{load(false).image().bitmap().recycle();File file=new File(cache.root,GalleryCache.key(image.url())+".image");Files.write(file.toPath(),new byte[]{1,2});try{load(true);fail();}catch(IOException expected){}assertFalse(file.exists());load(false).image().bitmap().recycle();assertEquals(2,calls);}
    @Test public void invalidHashAndUndecodableImageLeaveNoCache()throws Exception{for(boolean badHash:List.of(true,false)){try{cache.acquire(image,false,new SourceHttp.Token(),(u,f,t)->{Files.write(f.toPath(),new byte[]{1,2});return new SourceHttp.Download(2,badHash?"0".repeat(64):GalleryCache.checksum(f));});fail();}catch(IOException expected){}assertEquals(0,cache.root.list().length);}}
    @Test public void cancellationAfterDownloadLeavesNoPartOrImage()throws Exception{try{cache.acquire(image,false,new SourceHttp.Token(),(u,f,t)->{var result=fetch(u,f,t);t.cancel();return result;});fail();}catch(InterruptedIOException expected){}assertEquals(0,cache.root.list().length);}
    void seed(int count,long length)throws Exception{cache.root.mkdirs();for(int i=0;i<count;i++){File f=new File(cache.root,GalleryCache.key("seed"+i)+".image");try(RandomAccessFile out=new RandomAccessFile(f,"rw")){out.setLength(length);}f.setLastModified(i+1);}}
    @Test public void evictsLeastRecentToRespectByteAndFileBudgets()throws Exception{seed(4,SourceHttp.IMAGE_LIMIT);load(false).image().bitmap().recycle();long total=Arrays.stream(cache.root.listFiles((d,n)->n.endsWith(".image"))).mapToLong(File::length).sum();assertTrue(total<=GalleryCache.BUDGET);assertFalse(new File(cache.root,GalleryCache.key("seed0")+".image").exists());for(File f:cache.root.listFiles())f.delete();seed(130,1);load(false).image().bitmap().recycle();assertTrue(cache.root.listFiles((d,n)->n.endsWith(".image")).length<=128);}
    @Test public void source429IsRespectedAcrossCacheInstancesWithoutAutomaticRetry()throws Exception{try{cache.acquire(image,false,new SourceHttp.Token(),(u,f,t)->{calls++;throw new SourceHttp.Failure("Espera",429,300);});fail();}catch(SourceHttp.Failure expected){}try{new GalleryCache(base).acquire(image,false,new SourceHttp.Token(),this::fetch);fail();}catch(SourceHttp.Failure expected){assertEquals(429,expected.status);}assertEquals(1,calls);}
    @Test public void usesHashedNamesAndRejectsUntrustedHostsWithoutFetch()throws Exception{load(false).image().bitmap().recycle();for(String name:cache.root.list())assertTrue(name.matches("[a-f0-9]{64}\\.(image|sha)"));assertFalse(new File(base,"unsafe.png").exists());try{cache.acquire(new SourceGallery.Image("x","https://example.org/a"),false,new SourceHttp.Token(),this::fetch);fail();}catch(IOException expected){}assertEquals(1,calls);}
    @Test public void removesOnlyOwnedOrphansAndPartials()throws Exception{cache.root.mkdirs();Files.write(new File(cache.root,"selected-left.part").toPath(),new byte[]{1});Files.write(new File(cache.root,"a".repeat(64)+".sha").toPath(),"orphan".getBytes());File unknown=new File(cache.root,"keep.txt");Files.write(unknown.toPath(),"keep".getBytes());load(false).image().bitmap().recycle();assertTrue(unknown.exists());assertFalse(new File(cache.root,"selected-left.part").exists());assertFalse(new File(cache.root,"a".repeat(64)+".sha").exists());}
}
