package com.peach.local;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

/** Real image transport and cache pipeline with only simulated HTTPS connections. */
@RunWith(RobolectricTestRunner.class) @Config(sdk=28) @GraphicsMode(GraphicsMode.Mode.NATIVE)
public class GalleryHttpTest {
    File base;GalleryCache cache;
    @Before public void open()throws Exception{base=Files.createTempDirectory("gallery-own-http-").toFile();cache=new GalleryCache(base);}
    @After public void close()throws Exception{GalleryProvidersTest.remove(base);}
    @Test public void sixProvidersRunProductionHttpHashDecodeThenOfflineWithoutAnotherConnection()throws Exception{
        byte[] bytes=SourceGalleryTest.png();for(var own:GalleryProvidersTest.urls(bytes).entrySet()){
            var reply=new RedirectHttpTest.Reply(own.getValue(),200,null,bytes);reply.mime="image/png";var factory=new RedirectHttpTest.Factory(reply);SourceHttp.Token token=new SourceHttp.Token();
            var frame=cache.acquire(new SourceGallery.Image("Own.bin",own.getValue()),false,token,(u,f,t)->SourceHttp.image(u,f,t,factory,MediaRedirectsTest.PUBLIC));
            assertEquals(120,frame.image().originalWidth());frame.release();assertTrue(reply.closed&&reply.inputClosed);assertNull(token.connection);assertNull(reply.getRequestProperty("Authorization"));assertNull(reply.getRequestProperty("Cookie"));assertEquals(1,factory.requests.size());
            frame=cache.acquire(new SourceGallery.Image("Own.bin",own.getValue()),true,new SourceHttp.Token(),(u,f,t)->{fail("Offline opened network");return null;});assertTrue(frame.cached());frame.release();assertEquals(1,factory.requests.size());
        }
    }
    @Test public void wrongMimeOversizeTruncationAndPawHashMismatchLeaveNoReadyImage()throws Exception{
        byte[] bytes=SourceGalleryTest.png();for(int i=0;i<4;i++){
            String url=i==3?"https://file.pawchive.pw/data/aa/bb/aabb"+"0".repeat(60)+".png":SourceGalleryTest.A;
            var reply=new RedirectHttpTest.Reply(url,200,null,bytes);reply.mime=i==0?"text/html":"image/png";
            if(i==1)reply.declared=SourceHttp.IMAGE_LIMIT+1;if(i==2)reply.declared=bytes.length+1;
            try{cache.acquire(new SourceGallery.Image("Own.png",url),false,new SourceHttp.Token(),(u,f,t)->SourceHttp.image(u,f,t,new RedirectHttpTest.Factory(reply),MediaRedirectsTest.PUBLIC));fail();}catch(IOException expected){}
            assertTrue(reply.closed);assertEquals(0,cache.root.list().length);
        }
    }
    @Test public void anotherProvidersRedirectIsRejectedBeforeOpeningItsServer()throws Exception{
        var urls=GalleryProvidersTest.urls(SourceGalleryTest.png());for(String provider:List.of("pawchive","cumst","rule34paheal","rule34xxx","f95zone")){
            var reply=new RedirectHttpTest.Reply(urls.get(provider),302,SourceGalleryTest.A,new byte[0]);var factory=new RedirectHttpTest.Factory(reply);
            try{cache.acquire(new SourceGallery.Image("Own.png",urls.get(provider)),false,new SourceHttp.Token(),(u,f,t)->SourceHttp.image(u,f,t,factory,MediaRedirectsTest.PUBLIC));fail();}catch(IOException expected){}
            assertEquals(1,factory.requests.size());assertTrue(reply.closed);assertEquals(0,cache.root.list().length);
        }
    }
}
