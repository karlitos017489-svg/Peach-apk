package com.peach.local;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

/** Own PNG and synthetic attachment metadata only. No source API or media requests. */
@RunWith(RobolectricTestRunner.class) @Config(sdk=28)
@GraphicsMode(GraphicsMode.Mode.NATIVE) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class GalleryProvidersTest {
    static Map<String,String> urls(byte[] own){
        String hash=GalleryCache.hex(GalleryCache.digest(own));Map<String,String> urls=new LinkedHashMap<>();
        urls.put("fanbox",SourceGalleryTest.A);
        urls.put("pawchive","https://file.pawchive.pw/data/"+hash.substring(0,2)+"/"+hash.substring(2,4)+"/"+hash+".png");
        urls.put("cumst","https://e1.cum.st/media/own/image/original.png");
        urls.put("rule34paheal","https://r34i.paheal-cdn.net/aa/bb/"+"aabb"+"0".repeat(28));
        urls.put("rule34xxx","https://api-cdn.rule34.xxx/images/1/"+"a".repeat(32)+".png");
        urls.put("f95zone","https://attachments.f95zone.to/own/image.png");return urls;
    }
    static Publication publication(String provider){var p=SourceGalleryTest.publication();p.provider=provider;p.id="own-"+provider;return p;}
    static PublicationContent content(Publication p,JSONArray items){PublicationContent c=new PublicationContent();c.publicationId=p.id;c.attachments=items.toString();return c;}
    @Test public void allSixProvidersOfferOnlyTheirOwnAdmittedImages()throws Exception{
        Map<String,String> urls=urls(SourceGalleryTest.png());
        for(var own:urls.entrySet()){
            var p=publication(own.getKey());JSONArray items=new JSONArray();
            for(String url:urls.values())items.put(SourceGalleryTest.image(url));
            var s=SourceGallery.select(p,content(p,items));assertEquals(own.getKey(),1,s.images().size());
            assertEquals(own.getValue(),s.images().get(0).url());assertEquals(5,s.omitted());
        }
    }
    @Test public void legacyFalsePawFlagIsReevaluatedButOtherFalseFlagsStayReferences()throws Exception{
        for(var own:urls(SourceGalleryTest.png()).entrySet()){
            var p=publication(own.getKey());String before=new JSONArray().put(SourceGalleryTest.image(own.getValue()).put("downloadable",false)).toString();
            PublicationContent c=content(p,new JSONArray(before));var s=SourceGallery.select(p,c);
            assertEquals(p.provider,p.provider.equals("pawchive")?1:0,s.images().size());assertEquals(before,c.attachments);
        }
    }
    @Test public void previewProvidersVideoAndExcludedSourcesDoNotGainImageTransport()throws Exception{
        for(String provider:List.of("patreon","subscribestar","rule34video")){
            var p=publication(provider);assertTrue(SourceGallery.select(p,content(p,new JSONArray().put(SourceGalleryTest.image(SourceGalleryTest.A)))).images().isEmpty());
        }
        for(String provider:List.of("kemono","coomer","simpcity","unknown")){
            var p=publication(provider);try{SourceGallery.select(p,content(p,new JSONArray()));fail(provider);}catch(IOException expected){}
        }
        assertFalse(SourceHttp.downloadable("https://example.org/own.png"));
        assertFalse(SourceHttp.downloadable("https://e2.cum.st/media/own/image.png"));
    }
    @Test public void orderDedupPartialAndNonImageOmissionsRemainStableAcrossProviders()throws Exception{
        for(var own:urls(SourceGalleryTest.png()).entrySet()){
            var p=publication(own.getKey());var image=SourceGalleryTest.image(own.getValue());
            var c=content(p,new JSONArray().put(image).put(image).put(SourceGalleryTest.image(own.getValue()).put("kind","video")).put(SourceGalleryTest.image("https://example.org/no.png")));
            c.partial=true;var s=SourceGallery.select(p,c);assertEquals(1,s.images().size());assertEquals(2,s.omitted());assertTrue(s.partial());
        }
    }
    @Test public void importedPawLegacyBodySurvivesBackupWithoutChangingFlagsOrAddingMedia()throws Exception{
        var app=RuntimeEnvironment.getApplication();var db=androidx.room.Room.inMemoryDatabaseBuilder(app,LibraryDatabase.class).allowMainThreadQueries().build();
        try{var p=publication("pawchive");var c=content(p,new JSONArray().put(SourceGalleryTest.image(urls(SourceGalleryTest.png()).get("pawchive")).put("downloadable",false)));
            db.library().insertPublication(p);db.library().putPublicationContent(c);ByteArrayOutputStream out=new ByteArrayOutputStream();BackupStore.write(db.library(),out);
            assertEquals(19,new JSONObject(out.toString("UTF-8")).getInt("version"));db.library().deletePublication(p.id);BackupStore.read(db,new ByteArrayInputStream(out.toByteArray()));
            assertEquals(1,SourceGallery.load(db,p.id).images().size());assertEquals(c.attachments,db.library().publicationContent(p.id).attachments);assertTrue(db.library().allMedia().isEmpty());assertEquals(0,db.library().usageCount());
        }finally{db.close();}
    }
    @Test public void ownImageCachesAndOpensOfflineForEveryProvider()throws Exception{
        byte[] bytes=SourceGalleryTest.png();File base=Files.createTempDirectory("gallery-six-own-").toFile();int[] calls={0};
        try{var cache=new GalleryCache(base);for(var own:urls(bytes).entrySet()){
            var p=publication(own.getKey());var s=SourceGallery.select(p,content(p,new JSONArray().put(SourceGalleryTest.image(own.getValue()))));
            var image=s.images().get(0);var online=cache.acquire(image,false,new SourceHttp.Token(),(u,f,t)->{calls[0]++;Files.write(f.toPath(),bytes);return new SourceHttp.Download(bytes.length,GalleryCache.checksum(f));});
            assertEquals(120,online.image().originalWidth());online.release();var offline=cache.acquire(image,true,new SourceHttp.Token(),(u,f,t)->{fail("Offline attempted a fetch");return null;});assertTrue(offline.cached());assertEquals(60,offline.image().originalHeight());offline.release();
        }assertEquals(6,calls[0]);}finally{remove(base);}
    }
    @Test public void pawExpectedHashIsCheckedEvenWhenFetcherReturnsItsOwnConsistentChecksum()throws Exception{
        byte[] bytes=SourceGalleryTest.png();File base=Files.createTempDirectory("gallery-paw-mismatch-").toFile();
        String bad="aabb"+"0".repeat(60);var image=new SourceGallery.Image("own.png","https://file.pawchive.pw/data/aa/bb/"+bad+".png");
        try{var cache=new GalleryCache(base);try{cache.acquire(image,false,new SourceHttp.Token(),(u,f,t)->{Files.write(f.toPath(),bytes);return new SourceHttp.Download(bytes.length,GalleryCache.checksum(f));});fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("verificación"));}assertEquals(0,cache.root.list().length);
        }finally{remove(base);}
    }
    @Test public void recomputedSidecarCannotOverridePawIdentityOffline()throws Exception{
        byte[] bytes=SourceGalleryTest.png();File base=Files.createTempDirectory("gallery-paw-forged-").toFile();
        try{var cache=new GalleryCache(base);String bad="aabb"+"0".repeat(60);String url="https://file.pawchive.pw/data/aa/bb/"+bad+".png";cache.root.mkdirs();String key=GalleryCache.key(url);
            Files.write(new File(cache.root,key+".image").toPath(),bytes);Files.write(new File(cache.root,key+".sha").toPath(),GalleryCache.hex(GalleryCache.digest(bytes)).getBytes(java.nio.charset.StandardCharsets.US_ASCII));
            try{cache.acquire(new SourceGallery.Image("own.png",url),true,new SourceHttp.Token(),(u,f,t)->{fail();return null;});fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("no está en caché"));}
            assertEquals(0,cache.root.list().length);
        }finally{remove(base);}
    }
    static void remove(File base)throws Exception{try(var paths=Files.walk(base.toPath())){paths.sorted(Comparator.reverseOrder()).forEach(p->p.toFile().delete());}}
}
