package com.peach.local;
import java.io.*;
import java.util.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

/** Existing real Media3 loading pipeline, now reached through the Gofile direct-file contract. */
@RunWith(RobolectricTestRunner.class) @Config(sdk=28)
public class GofilePipelineTest {
    @Test public void admittedGofileVideoDeliversSampleThroughRealProgressivePeriodWithoutBearer()throws Exception{
        var network=new StreamDataSourceTest.RangeFactory(SourceVideosTest.own());var session=new VideoStream.Session(GofileProtocolTest.URL,()->true,network,MediaRedirectsTest.PUBLIC);try(var h=new ProgressivePipelineTest.Harness(session)){h.start();h.waitPrepared();assertNotNull(h.firstVideoSample());assertFalse(network.replies.isEmpty());for(var reply:network.replies){assertEquals(GofileProtocolTest.URL,reply.getURL().toString());assertNull(reply.getRequestProperty("Authorization"));assertNull(reply.getRequestProperty("Cookie"));assertNull(reply.getRequestProperty("Referer"));}}
    }
    @Test public void privateDnsAndDifferentStoreRedirectCannotBeReachedThroughPlayer()throws Exception{
        var reply=new VideoStreamTest.Reply(GofileProtocolTest.URL,302,new byte[0],null);reply.location=GofileProtocolTest.URL.replace("store-1","store-2");var network=new RedirectHttpTest.Factory(reply);var session=new VideoStream.Session(GofileProtocolTest.URL,()->true,network,MediaRedirectsTest.PUBLIC);session.resume();try{VideoStreamTest.problem(VideoStream.Reason.NETWORK,()->session.open(0));assertEquals(1,network.requests.size());}finally{session.close();}
        network=new RedirectHttpTest.Factory();var privateSession=new VideoStream.Session(GofileProtocolTest.URL,()->true,network,h->new java.net.InetAddress[]{java.net.InetAddress.getByName("10.0.0.1")});privateSession.resume();try{VideoStreamTest.problem(VideoStream.Reason.NETWORK,()->privateSession.open(0));assertTrue(network.requests.isEmpty());}finally{privateSession.close();}
    }
}
