package com.peach.local;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE)
public class GofileProtocolTest {
    static final String ROOT="Own123",ID="11111111-2222-3333-4444-555555555555",CHILD="22222222-2222-3333-4444-555555555555",URL="https://store-1.gofile.io/download/web/"+ID+"/Own.mp4",KEY="OWN_GOFILE_TOKEN_ONLY_FOR_TESTS";
    static JSONObject file()throws Exception{return new JSONObject().put("id",ID).put("type","file").put("name","Own.mp4").put("mimetype","video/mp4").put("size",12345).put("link",URL);}
    static JSONObject payload()throws Exception{return new JSONObject().put("status","ok").put("data",new JSONObject().put("type","folder").put("name","Own folder").put("children",new JSONObject().put(ID,file()))).put("metadata",new JSONObject().put("page",1).put("hasNextPage",false));}
    static GofileHttp.Response response(JSONObject json){return new GofileHttp.Response(200,json.toString().getBytes(StandardCharsets.UTF_8),0);}
    static GofileHttp.Response errorResponse(String state)throws IOException{try{return response(new JSONObject().put("status",state).put("message",KEY));}catch(Exception e){throw new IOException();}}
    static GofileReview.Target target(){return new GofileReview.Target(ROOT,ROOT,"Own");}
    static class Reply extends VideoStreamTest.Reply {
        Reply(String url,int status,byte[] body)throws Exception{super(url,status,body,null);}
        @Override public String getContentType(){return "application/json";}
        @Override public InputStream getErrorStream(){return new ByteArrayInputStream(bytes);}
    }
    @Test public void shareCodesAreCanonicalAndCredentialsAliasesAndQueriesAreNotAccepted()throws Exception{
        assertEquals(ROOT,GofileUrls.share("https://gofile.io/d/Own123/"));assertEquals("Own12345",GofileUrls.share("https://www.gofile.io/d/Own12345"));assertEquals(ID,GofileUrls.share("https://gofile.io/d/"+ID));
        for(String u:List.of("http://gofile.io/d/Own123","https://gofile.io.evil.test/d/Own123","https://evil.gofile.io/d/Own123","https://gofile.io:443/d/Own123","https://user@gofile.io/d/Own123","https://gofile.io/d/Own123?token=OWN_SECRET","https://gofile.io/d/Own123#x","https://gofile.io/d/%4fwn123","https://gofile.io/d/a/../Own123"))try{GofileUrls.share(u);fail(u);}catch(IllegalArgumentException expected){}
    }
    @Test public void onlyStoreDownloadPathsWithoutCredentialQueriesAreAdmitted()throws Exception{
        assertTrue(GofileUrls.downloadable(URL));assertTrue(GofileUrls.downloadable(URL.replace("store-1","store-eu-par-1").replace("Own.mp4","Own%20video.mp4")));assertTrue(SourceHttp.downloadable(URL));
        for(String u:List.of(URL+"?token=SECRET",URL+"#x",URL.replace("store-1","api"),URL.replace("gofile.io","gofile.io.evil.test"),URL.replace("Own.mp4","%2e%2e"),URL.replace("Own.mp4","%2fprivate"),URL.replace("Own.mp4","%252e%252e"),URL.replace("https:","http:")))assertFalse(u,GofileUrls.downloadable(u));
        for(String next:List.of(URL.replace("Own.mp4","other.mp4"),"https://downloads.fanbox.cc/own.mp4"))try{SourceHttp.attachmentRedirect(URL,next);fail();}catch(IOException expected){}
    }
    @Test public void linkExtractionIsBoundedOrderedAndNeverTurnsMaskedOrOtherHostsIntoFolders()throws Exception{
        PublicationContent c=new PublicationContent();c.text="Own (https://gofile.io/d/Own123). https://gofile.io/d/Own123 https://gofile.io/d/Own12345 https://evil.test/d/Other1 https://f95zone.to/masked/own";c.attachments=new JSONArray().put(new JSONObject().put("url","https://gofile.io/d/Third1")).toString();assertEquals(List.of(ROOT,"Own12345","Third1"),GofileUrls.folders(c));
        c.text="";c.attachments=new JSONArray().put(GofileReview.parse(payload(),target(),1).files().get(0)).toString();assertEquals(List.of(ROOT),GofileUrls.folders(c));
    }
    @Test public void exactApiGetSendsOnlyOwnBearerAndDoesNotFollowRedirects()throws Exception{
        String endpoint=GofileUrls.page(ROOT,1);Reply reply=new Reply(endpoint,200,payload().toString().getBytes(StandardCharsets.UTF_8));var f=new RedirectHttpTest.Factory(reply);var result=GofileHttp.direct(f,MediaRedirectsTest.PUBLIC).get(ROOT,1,KEY,new SourceHttp.Token());assertEquals(200,result.status());assertEquals(List.of(endpoint),f.requests);assertEquals("Bearer "+KEY,reply.getRequestProperty("Authorization"));assertNull(reply.getRequestProperty("Cookie"));assertNull(reply.getRequestProperty("Origin"));assertNull(reply.getRequestProperty("Referer"));assertFalse(endpoint.contains(KEY));assertEquals("GET",reply.getRequestMethod());assertFalse(reply.getInstanceFollowRedirects());assertTrue(reply.closed);
        reply=new Reply(endpoint,302,new byte[0]);reply.location="https://evil.test/";f=new RedirectHttpTest.Factory(reply);try{GofileHttp.direct(f,MediaRedirectsTest.PUBLIC).get(ROOT,1,KEY,new SourceHttp.Token());fail();}catch(IOException expected){assertFalse(expected.toString().contains(KEY));}assertEquals(1,f.requests.size());assertTrue(reply.closed);
    }
    @Test public void privateDnsCancellationAndMalformedIdsStopBeforeAnyConnection()throws Exception{
        var factory=new RedirectHttpTest.Factory();var transport=GofileHttp.direct(factory,h->new InetAddress[]{InetAddress.getByName("127.0.0.1")});try{transport.get(ROOT,1,KEY,new SourceHttp.Token());fail();}catch(IOException expected){}SourceHttp.Token cancelled=new SourceHttp.Token();cancelled.cancel();try{GofileHttp.direct(factory,MediaRedirectsTest.PUBLIC).get(ROOT,1,KEY,cancelled);fail();}catch(IOException expected){}try{transport.get("../secret",1,KEY,new SourceHttp.Token());fail();}catch(IllegalArgumentException expected){}assertTrue(factory.requests.isEmpty());
    }
    @Test public void responseLimitsEncodingMimeAndDisconnectAreEnforced()throws Exception{
        String endpoint=GofileUrls.page(ROOT,1);for(boolean length:List.of(true,false)){Reply reply=new Reply(endpoint,200,new byte[SourceHttp.JSON_LIMIT+1]){@Override public long getContentLengthLong(){return length?SourceHttp.JSON_LIMIT+1:-1;}};try{GofileHttp.direct(new RedirectHttpTest.Factory(reply),MediaRedirectsTest.PUBLIC).get(ROOT,1,KEY,new SourceHttp.Token());fail();}catch(IOException expected){}assertTrue(reply.closed);}
        Reply compressed=new Reply(endpoint,200,new byte[0]);compressed.headers.put("Content-Encoding","gzip");try{GofileHttp.direct(new RedirectHttpTest.Factory(compressed),MediaRedirectsTest.PUBLIC).get(ROOT,1,KEY,new SourceHttp.Token());fail();}catch(IOException expected){}assertTrue(compressed.closed);
    }
    @Test public void parserKeepsFilesAndExplicitSubfoldersWithoutRecursiveRequests()throws Exception{
        JSONObject j=payload();j.getJSONObject("data").getJSONObject("children").put(CHILD,new JSONObject().put("id",CHILD).put("type","folder").put("name","Own nested"));var result=GofileReview.parse(j,target(),1);assertEquals(1,result.files().size());assertEquals(1,result.folders().size());assertEquals(ROOT,result.folders().get(0).root());assertEquals(CHILD,result.folders().get(0).folder());assertFalse(result.more());GofileReview.validateAsset(result.files().get(0));
    }
    @Test public void accessGatesLockedDataAndUnsafeLinksNeverBecomePlayableAssets()throws Exception{
        for(String flag:List.of("canAccess","canDownload","password")){JSONObject j=payload();j.getJSONObject("data").put(flag,flag.equals("password"));try{GofileReview.parse(j,target(),1);fail(flag);}catch(IOException expected){}}
        JSONObject j=payload();j.getJSONObject("data").getJSONObject("children").put(ID,file().put("canAccess",false));assertTrue(GofileReview.parse(j,target(),1).files().isEmpty());j.getJSONObject("data").getJSONObject("children").put(ID,file().put("link",URL+"?token=OWN_SECRET"));assertEquals(1,GofileReview.parse(j,target(),1).omitted());
    }
    @Test public void paginationIsExplicitAndWrongPageOrDeepJsonFails()throws Exception{
        JSONObject j=payload();j.getJSONObject("metadata").put("hasNextPage",true);assertTrue(GofileReview.parse(j,target(),1).more());try{GofileReview.parse(j,target(),2);fail();}catch(JSONException expected){}try{GofileReview.depth("[".repeat(33)+"0"+"]".repeat(33));fail();}catch(IOException expected){}GofileReview.depth("{\"own\":\"[not nesting] \\\"\"}");
    }
    @Test public void completeImageAndRangeStreamingUseNoApiCredential()throws Exception{
        byte[] own=SourceVideosTest.own();var reply=new VideoStreamTest.Reply(URL,200,own,"\"own-v1\"");var f=new RedirectHttpTest.Factory(reply);var session=new VideoStream.Session(URL,()->true,f,MediaRedirectsTest.PUBLIC);session.resume();try(var transfer=session.open(0)){assertEquals(16,transfer.read(new byte[16],0,16));}finally{session.close();}assertNull(reply.getRequestProperty("Authorization"));assertNull(reply.getRequestProperty("Cookie"));assertEquals("",session.delivery);
        byte[] png=SourceGalleryTest.png();String url=URL.replace("Own.mp4","Own.png");var image=new VideoStreamTest.Reply(url,200,png,null){@Override public String getContentType(){return "image/png";}};File temp=File.createTempFile("own-gofile-image-",".tmp");try{assertEquals(png.length,SourceHttp.image(url,temp,new SourceHttp.Token(),new RedirectHttpTest.Factory(image),MediaRedirectsTest.PUBLIC).bytes());assertArrayEquals(png,java.nio.file.Files.readAllBytes(temp.toPath()));assertNull(image.getRequestProperty("Authorization"));}finally{temp.delete();}
    }
    @Test public void http429IsReturnedBeforeReadingAnOversizedCompressedOrInvalidErrorBody()throws Exception{
        var reply=new Reply(GofileUrls.page(ROOT,1),429,new byte[SourceHttp.JSON_LIMIT+1]){@Override public InputStream getInputStream(){throw new AssertionError("429 error body must not be read");}@Override public InputStream getErrorStream(){throw new AssertionError("429 error body must not be read");}};reply.headers.put("Content-Encoding","gzip");reply.headers.put("Retry-After","120");var response=GofileHttp.direct(new RedirectHttpTest.Factory(reply),MediaRedirectsTest.PUBLIC).get(ROOT,1,KEY,new SourceHttp.Token());assertEquals(429,response.status());assertEquals(120,response.retrySeconds());assertEquals(0,response.bytes().length);assertTrue(reply.closed);
    }
}
