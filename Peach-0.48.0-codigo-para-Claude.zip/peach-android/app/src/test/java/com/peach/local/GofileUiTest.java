package com.peach.local;
import android.content.Intent;
import android.os.Looper;
import android.widget.EditText;
import androidx.appcompat.app.AlertDialog;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import javax.crypto.spec.SecretKeySpec;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowDialog;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land") @SQLiteMode(SQLiteMode.Mode.LEGACY) @GraphicsMode(GraphicsMode.Mode.NATIVE)
public class GofileUiTest {
    SourceVideoUiTest fixture;GofileSecrets secrets;GofileHttp.Transport previous;java.util.function.Function<android.app.Application,GofileSecrets> previousFactory;int calls;List<ActivityController<ExternalLinksActivity>> screens=new ArrayList<>();
    @Before public void before()throws Exception{fixture=new SourceVideoUiTest();fixture.before();fixture.body.text="Own https://gofile.io/d/"+GofileProtocolTest.ROOT;fixture.db.library().putPublicationContent(fixture.body);File base=RuntimeEnvironment.getApplication().getCacheDir();secrets=new GofileSecrets(new SourceSecrets(new File(base,"own-gofile-test.bin"),()->new SecretKeySpec(new byte[16],"AES")),new File(base,"own-gofile-wait.txt"));secrets.write(GofileProtocolTest.KEY);previous=ExternalLinksActivity.transport;previousFactory=ExternalLinksActivity.secretsFactory;ExternalLinksActivity.secretsFactory=a->secrets;ExternalLinksActivity.transport=(f,n,k,t)->{calls++;try{return GofileProtocolTest.response(GofileProtocolTest.payload());}catch(Exception e){throw new IOException();}};RuntimeEnvironment.getApplication().getSharedPreferences("gofile",0).edit().clear().commit();}
    @After public void after()throws Exception{for(var c:screens){var d=c.get().draft;c.pause().stop().destroy();assertTrue(d.worker.awaitTermination(20,TimeUnit.SECONDS));}ExternalLinksActivity.transport=previous;ExternalLinksActivity.secretsFactory=previousFactory;secrets.clear();secrets.wait.delete();fixture.after();}
    ActivityController<ExternalLinksActivity> screen(){var c=Robolectric.buildActivity(ExternalLinksActivity.class,new Intent(RuntimeEnvironment.getApplication(),ExternalLinksActivity.class).putExtra("publicationId",fixture.p.id).putExtra("url","https://untrusted.invalid/own")).setup().visible();screens.add(c);return c;}
    void settle(ExternalLinksActivity a)throws Exception{for(int i=0;i<2;i++){a.draft.worker.submit(()->{}).get(20,TimeUnit.SECONDS);fixture.idle();}}
    @Test public void opensWithoutNetworkReviewsThenExplicitlyAddsWithoutMediaOrPlayerLaunch()throws Exception{
        var c=screen();settle(c.get());assertEquals(0,calls);assertEquals(1,c.get().draft.targets.size());assertFalse(c.get().apply.isEnabled());c.get().query.performClick();settle(c.get());assertEquals(1,calls);assertEquals(fixture.body.attachments,fixture.db.library().publicationContent(fixture.p.id).attachments);assertTrue(c.get().apply.isEnabled());c.get().apply.performClick();fixture.idle();var dialog=(AlertDialog)ShadowDialog.getLatestDialog();assertEquals("Incorporar",dialog.getButton(AlertDialog.BUTTON_POSITIVE).getText().toString());dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick();settle(c.get());assertEquals(2,SourceVideos.load(fixture.db,fixture.p.id).videos().size());assertEquals(0,fixture.calls);assertNull(Shadows.shadowOf(c.get()).getNextStartedActivity());assertTrue(fixture.db.library().allMedia().isEmpty());assertEquals(0,fixture.db.library().usageCount());
    }
    @Test public void offlineAndMissingKeyPreventNetworkAndKeepCurrentBody()throws Exception{
        var c=screen();settle(c.get());c.get().offline.setChecked(true);assertFalse(c.get().query.isEnabled());c.get().query.performClick();settle(c.get());assertEquals(0,calls);c.get().offline.setChecked(false);secrets.clear();c.get().query.performClick();settle(c.get());assertEquals(0,calls);assertTrue(c.get().draft.status.contains("clave"));assertEquals(fixture.body.attachments,fixture.db.library().publicationContent(fixture.p.id).attachments);
    }
    @Test public void rotationDuringOneQueryKeepsSameWorkerAndReviewWithoutAutoApply()throws Exception{
        CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);ExternalLinksActivity.transport=(f,n,k,t)->{calls++;entered.countDown();try{release.await(5,TimeUnit.SECONDS);return GofileProtocolTest.response(GofileProtocolTest.payload());}catch(Exception e){throw new IOException();}};var c=screen();settle(c.get());c.get().query.performClick();assertTrue(entered.await(5,TimeUnit.SECONDS));var draft=c.get().draft;try{c.recreate();assertSame(draft,c.get().draft);}finally{release.countDown();}settle(c.get());assertEquals(1,calls);assertNotNull(c.get().draft.review);assertEquals(fixture.body.attachments,fixture.db.library().publicationContent(fixture.p.id).attachments);
    }
    @Test public void leavingCancelsAndCannotWriteOrOfferLateReview()throws Exception{
        CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);ExternalLinksActivity.transport=(f,n,k,t)->{calls++;entered.countDown();try{release.await(5,TimeUnit.SECONDS);return GofileProtocolTest.response(GofileProtocolTest.payload());}catch(Exception e){throw new IOException();}};var c=screen();settle(c.get());c.get().query.performClick();assertTrue(entered.await(5,TimeUnit.SECONDS));c.pause().stop();assertTrue(c.get().draft.token.cancelled);release.countDown();c.start().resume().visible();settle(c.get());assertNull(c.get().draft.review);assertEquals(fixture.body.attachments,fixture.db.library().publicationContent(fixture.p.id).attachments);assertTrue(c.get().draft.status.contains("cancelada"));
    }
    @Test public void keyDialogIsSecureNotPrefilledNotStateSavedAndDeletingDoesNotDeleteContent()throws Exception{
        var c=screen();settle(c.get());c.get().credentials.performClick();fixture.idle();var dialog=(AlertDialog)ShadowDialog.getLatestDialog();assertNotEquals(0,dialog.getWindow().getAttributes().flags&android.view.WindowManager.LayoutParams.FLAG_SECURE);List<EditText> edits=new ArrayList<>();collect(dialog.getWindow().getDecorView(),edits);assertEquals(1,edits.size());assertEquals("",edits.get(0).getText().toString());assertFalse(edits.get(0).isSaveEnabled());dialog.getButton(AlertDialog.BUTTON_NEUTRAL).performClick();settle(c.get());assertNull(secrets.token());assertEquals(fixture.body.attachments,fixture.db.library().publicationContent(fixture.p.id).attachments);assertEquals(0,calls);
    }
    static void collect(android.view.View v,List<EditText> result){if(v instanceof EditText e)result.add(e);if(v instanceof android.view.ViewGroup group)for(int i=0;i<group.getChildCount();i++)collect(group.getChildAt(i),result);}
    @Test public void pagesRemainExplicitAndCanAdvanceAfterApplyingWithoutRequeryingFirstPage()throws Exception{
        ExternalLinksActivity.transport=(f,n,k,t)->{calls++;try{var json=GofileProtocolTest.payload();json.getJSONObject("metadata").put("page",n).put("hasNextPage",n==1);if(n==2)json.getJSONObject("data").put("children",new JSONObject());return GofileProtocolTest.response(json);}catch(Exception e){throw new IOException();}};var c=screen();settle(c.get());c.get().query.performClick();settle(c.get());assertEquals(1,calls);assertTrue(c.get().next.isEnabled());c.get().draft.apply();settle(c.get());assertTrue(c.get().next.isEnabled());c.get().next.performClick();settle(c.get());assertEquals(2,calls);assertEquals(2,c.get().draft.page);assertFalse(c.get().next.isEnabled());assertFalse(c.get().apply.isEnabled());assertTrue(c.get().previous.isEnabled());
    }
    @Test public void childFolderSelectionAndRotationDoNotTriggerRequestsOrResetItsTarget()throws Exception{
        ExternalLinksActivity.transport=(folder,n,k,t)->{calls++;assertEquals(calls==1?GofileProtocolTest.ROOT:GofileProtocolTest.CHILD,folder);try{var json=GofileProtocolTest.payload();if(calls==1)json.getJSONObject("data").getJSONObject("children").put(GofileProtocolTest.CHILD,new JSONObject().put("id",GofileProtocolTest.CHILD).put("type","folder").put("name","Own child"));return GofileProtocolTest.response(json);}catch(Exception e){throw new IOException();}};var c=screen();settle(c.get());c.get().query.performClick();settle(c.get());assertEquals(2,c.get().draft.targets.size());c.get().folders.setSelection(1);fixture.idle();settle(c.get());assertEquals(1,c.get().draft.selected);assertEquals(1,calls);assertNull(c.get().draft.review);c.get().query.performClick();settle(c.get());assertEquals(2,calls);assertEquals(1,c.get().draft.selected);assertEquals(GofileProtocolTest.CHILD,c.get().draft.review.target().folder());c.recreate();settle(c.get());assertEquals(1,c.get().draft.selected);assertEquals(2,calls);
    }
}
