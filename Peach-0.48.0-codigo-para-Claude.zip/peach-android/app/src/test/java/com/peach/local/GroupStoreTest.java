package com.peach.local;

import android.content.Context;
import androidx.room.Room;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.SQLiteMode;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,manifest=Config.NONE)
@SQLiteMode(SQLiteMode.Mode.LEGACY)
public class GroupStoreTest {
    private LibraryDatabase db;private GroupStore store;
    @Before public void open() {
        Context context=RuntimeEnvironment.getApplication();db=Room.inMemoryDatabaseBuilder(context,LibraryDatabase.class).allowMainThreadQueries().build();
        store=new GroupStore(db);
        for(String id:java.util.List.of("a","b")) {
            MediaEntry m=new MediaEntry();m.id=id;m.root=id;m.title="Mismo título";m.nfoDetails=NfoDetails.encode(java.util.Map.of("code","CAM-1"));
            db.library().insertMedia(m);db.library().progress(id,id.equals("a")?1000:2000,9000,1,false);
        }
    }
    @After public void close(){db.close();}
    @Test public void explicitGroupsNeverMergeSameCodeOrProgressAndAddingIsIdempotent() {
        assertTrue(db.library().groups().isEmpty());String group=store.create(" Versiones ");
        store.add(group,"a");store.add(group,"b");store.add(group,"a");
        assertEquals(2,db.library().groupItems(group).size());assertEquals("Versiones",db.library().group(group).name);
        db.library().toggleFavorite("a");store.rename(group,"Obra");
        assertEquals(1000,db.library().get("a").position);assertEquals(2000,db.library().get("b").position);
        assertTrue(db.library().get("a").favorite);assertFalse(db.library().get("b").favorite);
        db.library().deleteGroup(group);assertTrue(db.library().groupItems().isEmpty());assertEquals(2,db.library().allMedia().size());
    }
    @Test public void forgettingRootCascadesMembershipAndPreservesOtherMembers() {
        String group=store.create("Mi obra");store.add(group,"a");store.add(group,"b");
        db.library().forgetMedia("a");assertEquals(1,db.library().groupItems(group).size());
        assertEquals("b",db.library().groupItems(group).get(0).mediaId);assertNotNull(db.library().group(group));
    }
    @Test public void rescanAndMissingStateKeepGroupAndPersonalState() {
        String group=store.create("Obra");store.add(group,"a");MediaEntry m=db.library().get("a");
        db.library().editMetadata("a","Personal","");db.library().markMissing("a",1);
        assertTrue(db.library().get("a").missing);assertEquals(1,db.library().groupItems(group).size());
        db.library().updateScan("a",m.uri,m.root,"nuevo.mp4","Carpeta","Nuevo","","","","","","","[]","{}",MediaRules.VIDEO,1,1,2);
        assertFalse(db.library().get("a").missing);assertEquals("Personal",db.library().get("a").displayTitle());
        assertEquals(1000,db.library().get("a").position);assertEquals(1,db.library().groupItems(group).size());
    }
    @Test public void v3BackupRoundTripIsIdempotentAndSkipsDocumentsNotIndexed() throws Exception {
        String group=store.create("Obra");store.add(group,"a");store.add(group,"b");
        ByteArrayOutputStream out=new ByteArrayOutputStream();BackupStore.write(db.library(),out);
        JSONObject backup=new JSONObject(out.toString("UTF-8"));assertEquals(19,backup.getInt("version"));
        backup.getJSONArray("groups").getJSONObject(0).getJSONArray("items").put("not-indexed");
        db.library().clearGroup(group);store.rename(group,"Temporal");
        for(int i=0;i<2;i++)BackupStore.read(db,new ByteArrayInputStream(backup.toString().getBytes(StandardCharsets.UTF_8)));
        assertEquals(2,db.library().groupItems(group).size());assertEquals("Obra",db.library().group(group).name);
        assertEquals(1000,db.library().get("a").position);
    }
    @Test public void malformedGroupRollsBackAllPlaybackEditsAndEarlierGroups() throws Exception {
        JSONObject backup=new JSONObject();backup.put("format","peach-local-state");backup.put("version",3);
        backup.put("items",new JSONArray().put(new JSONObject().put("id","a").put("favorite",true)));
        backup.put("playlists",new JSONArray());
        JSONObject valid=new JSONObject().put("id","one").put("name","Uno").put("items",new JSONArray().put("a"));
        JSONObject invalid=new JSONObject().put("id","two").put("name","Dos").put("items",new JSONArray().put(42));
        backup.put("groups",new JSONArray().put(valid).put(invalid));
        try {BackupStore.read(db,new ByteArrayInputStream(backup.toString().getBytes(StandardCharsets.UTF_8)));fail();}
        catch(IllegalArgumentException expected) {assertFalse(db.library().get("a").favorite);assertTrue(db.library().groups().isEmpty());assertEquals(1000,db.library().get("a").position);}
    }
    @Test public void v2BackupPreservesExistingGroups() throws Exception {
        String group=store.create("Conservar");store.add(group,"a");
        String old="{\"format\":\"peach-local-state\",\"version\":2,\"items\":[{\"id\":\"a\",\"favorite\":true}],\"playlists\":[]}";
        BackupStore.read(db,new ByteArrayInputStream(old.getBytes(StandardCharsets.UTF_8)));
        assertTrue(db.library().get("a").favorite);assertEquals(1,db.library().groupItems(group).size());
    }
    @Test public void addingUnknownDocumentOrGroupFailsWithoutCreatingDanglingRows() {
        String group=store.create("Obra");
        for(String[] pair:new String[][]{{group,"absent"},{"absent","a"}}) {
            try{store.add(pair[0],pair[1]);fail();}catch(IllegalArgumentException expected){}
        }
        assertTrue(db.library().groupItems().isEmpty());
    }
}
