package com.peach.local;

import android.os.Looper;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowDialog;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land") @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class HistoryUiTest {
    LibraryDatabase db;
    @Before public void open(){db=androidx.room.Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",db);for(String id:List.of("a","b")){MediaEntry m=VersionIndexTest.row(id,id+".mp4");m.title=id.equals("a")?"ÁRBOL %_":"Otra obra";db.library().insertMedia(m);}db.library().restoreState("a",true,false,600,2000,1,7);}
    void idle()throws Exception{for(int i=0;i<4;i++){LibraryDatabase.IO.submit(()->{}).get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}}
    @After public void close()throws Exception{idle();db.close();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);}
    void visits(int count){UsageStore store=new UsageStore(db);for(int i=0;i<count;i++)store.begin(UUID.randomUUID().toString(),i%2==0?"a":"b","video",System.currentTimeMillis()+i);}
    int rows(HistoryActivity a){return ((ListView)a.findViewById(R.id.history_list)).getAdapter().getCount();}
    @Test public void pagesOneHundredVisitsAndReportsFilteredTotals()throws Exception{visits(105);try(var c=Robolectric.buildActivity(HistoryActivity.class).setup().visible()){idle();assertEquals(100,rows(c.get()));assertTrue(((TextView)c.get().findViewById(R.id.history_status)).getText().toString().contains("105 sesiones"));c.get().findViewById(R.id.history_older).performClick();idle();assertEquals(5,rows(c.get()));c.get().findViewById(R.id.history_newer).performClick();idle();assertEquals(100,rows(c.get()));}}
    @Test public void searchAndKindFilterSurviveRecreation()throws Exception{visits(4);try(var c=Robolectric.buildActivity(HistoryActivity.class).setup().visible()){idle();((EditText)c.get().findViewById(R.id.history_search)).setText("árbol %_");Shadows.shadowOf(Looper.getMainLooper()).idleFor(java.time.Duration.ofMillis(220));idle();assertEquals(2,rows(c.get()));c.recreate();idle();assertEquals("árbol %_",((EditText)c.get().findViewById(R.id.history_search)).getText().toString());assertEquals(2,rows(c.get()));((Spinner)c.get().findViewById(R.id.history_kind)).setSelection(2);idle();assertEquals(0,rows(c.get()));}}
    @Test public void detailOpensCurrentDocumentAndDeletingOnlyRemovesVisit()throws Exception{visits(1);try(var c=Robolectric.buildActivity(HistoryActivity.class).setup().visible()){idle();((ListView)c.get().findViewById(R.id.history_list)).performItemClick(null,0,0);idle();AlertDialog dialog=(AlertDialog)ShadowDialog.getLatestDialog();dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick();idle();var intent=Shadows.shadowOf(c.get()).getNextStartedActivity();assertEquals(PlayerActivity.class.getName(),intent.getComponent().getClassName());assertEquals("a",intent.getStringExtra("mediaId"));((ListView)c.get().findViewById(R.id.history_list)).performItemClick(null,0,0);idle();dialog=(AlertDialog)ShadowDialog.getLatestDialog();dialog.getButton(AlertDialog.BUTTON_NEUTRAL).performClick();idle();assertEquals(0,rows(c.get()));assertEquals(600,db.library().get("a").position);assertEquals(7,db.library().get("a").playCount);assertTrue(db.library().get("a").favorite);visits(1);idle();c.get().findViewById(R.id.history_clear).performClick();dialog=(AlertDialog)ShadowDialog.getLatestDialog();dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick();idle();assertEquals(0,rows(c.get()));assertEquals(7,db.library().get("a").playCount);}}
    @Test public void localCalendarFiltersHandleDstDaysWithoutAssumingTwentyFourHours(){var zone=java.time.ZoneId.of("America/New_York");var date=java.time.LocalDate.of(2026,3,9);assertEquals(date.minusDays(6).atStartOfDay(zone).toInstant().toEpochMilli(),HistoryActivity.since(2,date,zone));assertEquals(0,HistoryActivity.since(0,date,zone));assertTrue(HistoryActivity.describe(new UsageSession()).contains("No confirma reproducción actual"));}
}
