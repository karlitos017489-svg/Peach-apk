package com.peach.local;

import android.graphics.Color;
import android.net.Uri;
import java.io.ByteArrayInputStream;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.Shadows;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,manifest=Config.NONE)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class ImageFilesTest {
    private Uri source(String name) throws Exception {
        byte[] bytes;
        try(var in=getClass().getClassLoader().getResourceAsStream("media/"+name)){assertNotNull(in);bytes=in.readAllBytes();}
        Uri uri=Uri.parse("content://image-fixture/"+name);
        Shadows.shadowOf(RuntimeEnvironment.getApplication().getContentResolver()).registerInputStreamSupplier(uri,()->new ByteArrayInputStream(bytes));
        return uri;
    }
    @Test public void nativePngDecodePreservesPixelsAndDimensions() throws Exception {
        var decoded=ImageFiles.decode(RuntimeEnvironment.getApplication().getContentResolver(),source("small.png"),640);
        try {
            assertEquals(120,decoded.originalWidth());assertEquals(60,decoded.originalHeight());
            assertEquals(120,decoded.bitmap().getWidth());assertEquals(Color.RED,decoded.bitmap().getPixel(5,5));assertEquals(Color.BLUE,decoded.bitmap().getPixel(100,5));
        }finally{decoded.bitmap().recycle();}
    }
    @Test public void largeImageIsActuallySubsampledBeforeAllocation() throws Exception {
        var decoded=ImageFiles.decode(RuntimeEnvironment.getApplication().getContentResolver(),source("large.png"),640);
        try {
            assertEquals(4096,decoded.originalWidth());assertEquals(1024,decoded.originalHeight());
            assertTrue(decoded.bitmap().getWidth()<=640);assertTrue(decoded.bitmap().getHeight()<=640);
            assertTrue(decoded.bitmap().getAllocationByteCount()<=640*640*4);
        }finally{decoded.bitmap().recycle();}
    }
    @Test public void exifRotationChangesDisplayedOrientation() throws Exception {
        var decoded=ImageFiles.decode(RuntimeEnvironment.getApplication().getContentResolver(),source("rotated.jpg"),640);
        try {assertEquals(20,decoded.originalWidth());assertEquals(40,decoded.originalHeight());assertEquals(20,decoded.bitmap().getWidth());assertEquals(40,decoded.bitmap().getHeight());}
        finally{decoded.bitmap().recycle();}
    }
    @Test public void allExifMatricesMapDistinctOrientations() {
        float[][] expected={{2,3},{-2,3},{-2,-3},{2,-3},{3,2},{-3,2},{-3,-2},{3,-2}};
        for(int i=1;i<=8;i++){float[] p={2,3};ImageFiles.orientation(i).mapPoints(p);assertArrayEquals(expected[i-1],p,0.001f);}
    }
    @Test public void sampleSizeRejectsInvalidHeadersAndHonorsEdge() {
        assertEquals(8,ImageFiles.sampleSize(4096,1024,640));assertEquals(1,ImageFiles.sampleSize(120,60,640));
        for(int width:new int[]{-1,0,Integer.MAX_VALUE})try{ImageFiles.sampleSize(width,100,640);fail();}catch(IllegalArgumentException expected){}
    }
    @Test public void corruptImageReportsFailureInsteadOfProducingFakeBitmap() throws Exception {
        Uri uri=Uri.parse("content://image-fixture/corrupt");
        Shadows.shadowOf(RuntimeEnvironment.getApplication().getContentResolver()).registerInputStreamSupplier(uri,()->new ByteArrayInputStream(new byte[]{1,2,3}));
        try{ImageFiles.decode(RuntimeEnvironment.getApplication().getContentResolver(),uri,640);fail();}catch(java.io.IOException expected){}
    }
}
