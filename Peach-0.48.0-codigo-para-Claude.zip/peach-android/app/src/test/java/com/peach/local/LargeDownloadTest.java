package com.peach.local;
import java.io.*;
import org.junit.Test;
import static org.junit.Assert.*;
public class LargeDownloadTest {
    static final String URL="https://downloads.fanbox.cc/own-synthetic.bin";
    static class Repeated extends InputStream {long remaining;long read;boolean closed;Repeated(long n){remaining=n;}public int read(){if(remaining--<=0)return -1;read++;return 7;}public int read(byte[] b,int o,int l){if(remaining<=0)return -1;int n=(int)Math.min(l,remaining);java.util.Arrays.fill(b,o,o+n,(byte)7);remaining-=n;read+=n;return n;}public void close(){closed=true;}}
    @Test public void actual129MiBStreamSucceedsWithLargePolicyWithoutWholeFileArray()throws Exception{long n=129L*1024*1024;File f=File.createTempFile("own-large-",".tmp");Repeated input=new Repeated(n);try{var result=SourceHttp.copyAttachment(URL,input,f,n,new SourceHttp.Token(),SourceHttp.LARGE_DOWNLOAD_LIMIT);assertEquals(n,result.bytes());assertEquals(n,f.length());assertEquals(n,input.read);assertTrue(input.closed);assertEquals(64,result.sha256().length());}finally{f.delete();}}
    @Test public void old128PolicyRemainsBoundedAndOversize2GiBStopsBeforeReading()throws Exception{for(long limit:new long[]{SourceHttp.DOWNLOAD_LIMIT,SourceHttp.LARGE_DOWNLOAD_LIMIT}){File f=File.createTempFile("own-limit-",".tmp");Repeated input=new Repeated(1);try{try{SourceHttp.copyAttachment(URL,input,f,limit+1,new SourceHttp.Token(),limit);fail();}catch(IOException expected){}assertEquals(0,input.read);assertTrue(input.closed);assertFalse(f.exists());}finally{f.delete();}}assertEquals(2L*1024*1024*1024,SourceHttp.LARGE_DOWNLOAD_LIMIT);}
    @Test public void unknownLengthBeyondLimitCleansPartialAndCancellationStillStops()throws Exception{for(boolean cancel:new boolean[]{false,true}){File f=File.createTempFile("own-large-cancel-",".tmp");SourceHttp.Token token=new SourceHttp.Token();if(cancel)token.cancel();Repeated input=new Repeated(65537);try{try{SourceHttp.copyAttachment(URL,input,f,-1,token,65536);fail();}catch(IOException expected){}assertFalse(f.exists());assertTrue(input.closed);}finally{f.delete();}}}
}
