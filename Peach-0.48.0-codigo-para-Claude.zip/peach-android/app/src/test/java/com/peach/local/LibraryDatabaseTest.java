package com.peach.local;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import androidx.room.Room;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.SQLiteMode;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,manifest=Config.NONE)
@SQLiteMode(SQLiteMode.Mode.LEGACY)
public class LibraryDatabaseTest {
    private Context context;private LibraryDatabase db;
    @Before public void open() {
        context=RuntimeEnvironment.getApplication();
        db=Room.inMemoryDatabaseBuilder(context,LibraryDatabase.class).allowMainThreadQueries().build();
    }
    @After public void close() {db.close();context.deleteDatabase("migration-v1.db");context.deleteDatabase("migration-v2.db");}
    private MediaEntry add(String id) {
        MediaEntry m=new MediaEntry();m.id=id;m.title="Importado "+id;m.tags="NFO";m.root="root";m.uri="content://fixture/"+id;
        db.library().insertMedia(m);return m;
    }
    @Test public void migrationFromExportedV1PreservesCatalogRootsAndCheckpoints() throws Exception {
        var path=context.getDatabasePath("migration-v1.db");path.getParentFile().mkdirs();
        String schema;
        try (var input=getClass().getClassLoader().getResourceAsStream("com.peach.local.LibraryDatabase/1.json")) {
            assertNotNull(input);schema=new String(input.readAllBytes(),StandardCharsets.UTF_8);
        }
        JSONObject v1=new JSONObject(schema).getJSONObject("database");
        try (SQLiteDatabase old=SQLiteDatabase.openOrCreateDatabase(path,null)) {
            JSONArray entities=v1.getJSONArray("entities");
            for (int i=0;i<entities.length();i++) {
                JSONObject entity=entities.getJSONObject(i);String table=entity.getString("tableName");
                old.execSQL(entity.getString("createSql").replace("${TABLE_NAME}",table));
                ContentValues values=new ContentValues();JSONArray fields=entity.getJSONArray("fields");
                for (int j=0;j<fields.length();j++) {
                    JSONObject field=fields.getJSONObject(j);String column=field.getString("columnName");
                    if (field.getString("affinity").equals("TEXT")) values.put(column,"fixture");else values.put(column,0);
                }
                if (table.equals("media")) {
                    values.put("id","old-video");values.put("uri","content://old/video");values.put("root","content://old/tree");
                    values.put("title","Video anterior");values.put("favorite",1);values.put("watched",1);
                    values.put("position",7000);values.put("duration",20000);values.put("lastPlayed",123);values.put("playCount",4);
                } else if (table.equals("roots")) {
                    values.put("uri","content://old/tree");values.put("generation",7);values.put("directories",12);
                } else {
                    values.put("root","content://old/tree");values.put("uri","content://old/pending");
                }
                assertTrue(old.insertOrThrow(table,null,values)>0);
            }
            JSONArray setup=v1.getJSONArray("setupQueries");
            for (int i=0;i<setup.length();i++) old.execSQL(setup.getString(i));
            old.setVersion(1);
        }
        LibraryDatabase migrated=Room.databaseBuilder(context,LibraryDatabase.class,"migration-v1.db")
                .addMigrations(LibraryDatabase.MIGRATION_1_2,LibraryDatabase.MIGRATION_2_3,LibraryDatabase.MIGRATION_3_4,LibraryDatabase.MIGRATION_4_5,LibraryDatabase.MIGRATION_5_6,LibraryDatabase.MIGRATION_6_7,LibraryDatabase.MIGRATION_7_8,LibraryDatabase.MIGRATION_8_9,LibraryDatabase.MIGRATION_9_10,LibraryDatabase.MIGRATION_10_11,LibraryDatabase.MIGRATION_11_12,LibraryDatabase.MIGRATION_12_13).allowMainThreadQueries().build();
        try {
            MediaEntry old=migrated.library().get("old-video");
            assertEquals("Video anterior",old.displayTitle());assertEquals("content://old/video",old.uri);
            assertTrue(old.favorite);assertTrue(old.watched);assertEquals(7000,old.position);assertEquals(4,old.playCount);
            assertNull(old.userTitle);assertNull(old.userTags);assertEquals(0,old.addedAt);assertEquals("{}",old.nfoDetails);
            assertEquals(7,migrated.library().roots().get(0).generation);
            assertNotNull(migrated.library().next("content://old/tree"));
            assertTrue(migrated.library().playlists().isEmpty());
        } finally {migrated.close();}
    }
    @Test public void rescanPreservesOverridesAndFirstAddedTimeAndResetUsesNewNfo() {
        MediaEntry initial=add("m");db.library().editMetadata("m","Mi título","");
        db.library().progress("m",7000,20000,1,false);db.library().toggleFavorite("m");
        db.library().updateScan("m",initial.uri,"root","m.mp4","Videos","NFO nuevo","Nuevas","","","","","","[]","{}",MediaRules.VIDEO,9,10,2);
        MediaEntry row=db.library().get("m");assertEquals("Mi título",row.displayTitle());assertEquals("",row.displayTags());
        assertEquals(initial.addedAt,row.addedAt);assertEquals(7000,row.position);assertTrue(row.favorite);
        db.library().editMetadata("m",null,null);assertEquals("NFO nuevo",db.library().get("m").displayTitle());
        assertEquals("Nuevas",db.library().get("m").displayTags());
    }
    @Test public void migrationFromExportedV2PreservesEditsListsAndPlayback() throws Exception {
        var path=context.getDatabasePath("migration-v2.db");path.getParentFile().mkdirs();
        JSONObject v2;
        try (var input=getClass().getClassLoader().getResourceAsStream("com.peach.local.LibraryDatabase/2.json")) {
            assertNotNull(input);v2=new JSONObject(new String(input.readAllBytes(),StandardCharsets.UTF_8)).getJSONObject("database");
        }
        try (SQLiteDatabase old=SQLiteDatabase.openOrCreateDatabase(path,null)) {
            JSONArray entities=v2.getJSONArray("entities");
            for (int i=0;i<entities.length();i++) {
                JSONObject entity=entities.getJSONObject(i);String table=entity.getString("tableName");
                old.execSQL(entity.getString("createSql").replace("${TABLE_NAME}",table));
                JSONArray indices=entity.optJSONArray("indices");
                if (indices!=null) for (int j=0;j<indices.length();j++) old.execSQL(indices.getJSONObject(j).getString("createSql").replace("${TABLE_NAME}",table));
                ContentValues values=new ContentValues();JSONArray fields=entity.getJSONArray("fields");
                for (int j=0;j<fields.length();j++) {
                    JSONObject field=fields.getJSONObject(j);String column=field.getString("columnName");
                    if (!field.optBoolean("notNull",false)) values.putNull(column);
                    else if (field.getString("affinity").equals("TEXT")) values.put(column,"fixture");else values.put(column,0);
                }
                switch(table) {
                    case "media" -> {
                        values.put("id","old");values.put("uri","content://old/video");values.put("root","root");
                        values.put("title","Origen");values.put("userTitle","Mi título");values.put("userTags","");
                        values.put("addedAt",12345);values.put("position",7000);values.put("duration",90000);
                        values.put("favorite",1);values.put("watched",1);values.put("playCount",4);values.put("subtitles","[]");
                    }
                    case "roots" -> {values.put("uri","root");values.put("generation",9);values.put("warnings",2);}
                    case "scan_queue" -> {values.put("root","root");values.put("uri","content://old/pending");}
                    case "playlists" -> {values.put("id","list");values.put("name","Lista anterior");values.put("createdAt",54321);}
                    case "playlist_items" -> {values.put("playlistId","list");values.put("mediaId","old");values.put("position",3);}
                }
                old.insertOrThrow(table,null,values);
            }
            JSONArray setup=v2.getJSONArray("setupQueries");for (int i=0;i<setup.length();i++) old.execSQL(setup.getString(i));
            old.setVersion(2);
        }
        LibraryDatabase migrated=Room.databaseBuilder(context,LibraryDatabase.class,"migration-v2.db")
            .addMigrations(LibraryDatabase.MIGRATION_2_3,LibraryDatabase.MIGRATION_3_4,LibraryDatabase.MIGRATION_4_5,LibraryDatabase.MIGRATION_5_6,LibraryDatabase.MIGRATION_6_7,LibraryDatabase.MIGRATION_7_8,LibraryDatabase.MIGRATION_8_9,LibraryDatabase.MIGRATION_9_10,LibraryDatabase.MIGRATION_10_11,LibraryDatabase.MIGRATION_11_12,LibraryDatabase.MIGRATION_12_13).allowMainThreadQueries().build();
        try {
            MediaEntry row=migrated.library().get("old");assertEquals("{}",row.nfoDetails);
            assertEquals("Mi título",row.displayTitle());assertEquals("",row.displayTags());assertEquals(12345,row.addedAt);
            assertEquals(7000,row.position);assertEquals(90000,row.duration);assertEquals(4,row.playCount);
            assertTrue(row.favorite);assertTrue(row.watched);assertEquals("content://old/video",row.uri);assertEquals("[]",row.subtitles);
            assertEquals("Lista anterior",migrated.library().playlist("list").name);
            assertEquals(54321,migrated.library().playlist("list").createdAt);
            assertEquals("old",migrated.library().playlistMedia("list").get(0).id);assertEquals(3,migrated.library().playlistItems("list").get(0).position);
            assertEquals(9,migrated.library().roots().get(0).generation);assertEquals(2,migrated.library().roots().get(0).warnings);
            assertNotNull(migrated.library().next("root"));
        } finally {migrated.close();}
    }
    @Test public void rescanReplacesOnlyImportedDetailsAndBackupKeepsCurrentNfo() throws Exception {
        MediaEntry m=add("a");db.library().editMetadata("a","Personal","Mis etiquetas");
        PlaylistStore store=new PlaylistStore(db);String list=store.create("Lista");store.add(list,"a");
        db.library().progress("a",8000,20000,5,false);db.library().toggleFavorite("a");
        String details=NfoDetails.encode(java.util.Map.of("directors","Ana","code","CAM-2"));
        db.library().updateScan(m.id,m.uri,m.root,m.name,m.folder,"Nuevo NFO","Importadas","Actor","Estudio","Texto","2026","","[]",details,MediaRules.VIDEO,30,99,2);
        MediaEntry row=db.library().get("a");assertEquals("Ana",row.details().get("directors"));
        assertEquals("Personal",row.displayTitle());assertEquals("Mis etiquetas",row.displayTags());
        assertEquals(8000,row.position);assertTrue(row.favorite);assertEquals("a",db.library().playlistMedia(list).get(0).id);
        ByteArrayOutputStream output=new ByteArrayOutputStream();BackupStore.write(db.library(),output);
        assertFalse(output.toString("UTF-8").contains("nfoDetails"));
        BackupStore.read(db,new ByteArrayInputStream(output.toByteArray()));assertEquals(details,db.library().get("a").nfoDetails);
        db.library().updateScan(m.id,m.uri,m.root,m.name,m.folder,"Sin NFO","","","","","","","[]","{}",MediaRules.VIDEO,30,100,3);
        assertTrue(db.library().get("a").details().isEmpty());assertEquals("Personal",db.library().get("a").displayTitle());
    }
    @Test public void listMembershipDeduplicatesReordersAndDeletingListPreservesMedia() {
        add("a");add("b");PlaylistStore store=new PlaylistStore(db);String list=store.create("Campo");
        store.add(list,"a");store.add(list,"b");store.add(list,"a");assertEquals(2,db.library().playlistItems(list).size());
        store.move(list,"b",-1);assertEquals("b",db.library().playlistMedia(list).get(0).id);
        store.move(list,"b",-1);assertEquals("b",db.library().playlistMedia(list).get(0).id);
        store.rename(list,"Favoritos de campo");assertEquals("Favoritos de campo",db.library().playlist(list).name);
        db.library().deletePlaylist(list);assertTrue(db.library().playlistItems(list).isEmpty());assertEquals(2,db.library().allMedia().size());
    }
    @Test public void mixedMediaBackupRoundTripKeepsTypesListsAndPersonalData() throws Exception {
        PlaylistStore store=new PlaylistStore(db);String list=store.create("Mixta");
        for(String type:java.util.List.of(MediaRules.VIDEO,MediaRules.IMAGE,MediaRules.AUDIO)) {
            MediaEntry m=new MediaEntry();m.id=type;m.mediaType=type;db.library().insertMedia(m);
            store.add(list,type);db.library().toggleFavorite(type);db.library().editMetadata(type,"Personal "+type,"Local");
        }
        db.library().progress(MediaRules.AUDIO,5000,10000,1,false);
        ByteArrayOutputStream out=new ByteArrayOutputStream();BackupStore.write(db.library(),out);
        db.library().deletePlaylist(list);db.library().toggleFavorite(MediaRules.IMAGE);
        assertEquals(3,BackupStore.read(db,new ByteArrayInputStream(out.toByteArray())));
        assertEquals(3,db.library().playlistItems(list).size());assertEquals(5000,db.library().get(MediaRules.AUDIO).position);
        for(String type:java.util.List.of(MediaRules.VIDEO,MediaRules.IMAGE,MediaRules.AUDIO)) {
            MediaEntry m=db.library().get(type);assertEquals(type,m.mediaType);assertTrue(m.favorite);assertEquals("Personal "+type,m.displayTitle());
        }
    }
    @Test public void unavailableMediaRemainInListAndRemovedCatalogRowsCascadeOnlyMembership() {
        add("a");PlaylistStore store=new PlaylistStore(db);String list=store.create("Lista");store.add(list,"a");
        db.library().markMissing("root",99);assertTrue(db.library().playlistMedia(list).get(0).missing);
        db.library().forgetMedia("root");assertTrue(db.library().playlistItems(list).isEmpty());assertNotNull(db.library().playlist(list));
    }
    @Test public void currentBackupRestoresEditsPlaylistsAndOrder() throws Exception {
        add("a");add("b");db.library().editMetadata("a","Mi edición","Rocas");db.library().toggleFavorite("a");
        db.library().progress("a",8000,20000,10,false);
        PlaylistStore store=new PlaylistStore(db);String list=store.create("Lista");store.add(list,"b");store.add(list,"a");
        ByteArrayOutputStream output=new ByteArrayOutputStream();BackupStore.write(db.library(),output);
        assertEquals(19,new JSONObject(output.toString("UTF-8")).getInt("version"));
        db.library().editMetadata("a",null,null);db.library().deletePlaylist(list);db.library().toggleFavorite("a");
        assertEquals(2,BackupStore.read(db,new ByteArrayInputStream(output.toByteArray())));
        assertEquals("Mi edición",db.library().get("a").displayTitle());assertTrue(db.library().get("a").favorite);
        assertEquals(8000,db.library().get("a").position);assertEquals("b",db.library().playlistMedia(list).get(0).id);
        BackupStore.read(db,new ByteArrayInputStream(output.toByteArray()));assertEquals(2,db.library().playlistItems(list).size());
    }
    @Test public void legacyBackupRestoresProgressWithoutClearingNewFields() throws Exception {
        add("a");db.library().editMetadata("a","Personal","Local");
        PlaylistStore store=new PlaylistStore(db);String list=store.create("Lista");store.add(list,"a");
        String old="{\"format\":\"peach-local-state\",\"version\":1,\"items\":[{\"id\":\"a\",\"favorite\":true,\"position\":9000,\"duration\":20000}]}";
        assertEquals(1,BackupStore.read(db,new ByteArrayInputStream(old.getBytes(StandardCharsets.UTF_8))));
        assertEquals(9000,db.library().get("a").position);assertEquals("Personal",db.library().get("a").displayTitle());
        assertEquals(1,db.library().playlistItems(list).size());
    }
    @Test public void invalidListInBackupRollsBackAllStateChanges() throws Exception {
        add("a");String invalid="{\"format\":\"peach-local-state\",\"version\":2,\"items\":[{\"id\":\"a\",\"favorite\":true}],\"playlists\":[{\"id\":\"bad\",\"name\":\"\",\"items\":[]}]}";
        try {BackupStore.read(db,new ByteArrayInputStream(invalid.getBytes(StandardCharsets.UTF_8)));fail("Expected invalid list");}
        catch (IllegalArgumentException expected) {assertFalse(db.library().get("a").favorite);assertTrue(db.library().playlists().isEmpty());}
    }
    @Test public void persistedListAndEditsSurviveDatabaseReopen() {
        String name="reopen-v2.db";context.deleteDatabase(name);
        LibraryDatabase first=Room.databaseBuilder(context,LibraryDatabase.class,name).allowMainThreadQueries().build();
        try {
            MediaEntry m=new MediaEntry();m.id="saved";m.nfoDetails=NfoDetails.encode(java.util.Map.of("directors","Ana"));
            first.library().insertMedia(m);first.library().editMetadata("saved","Persistente","");
            PlaylistStore store=new PlaylistStore(first);String id=store.create("Guardada");store.add(id,"saved");
        } finally {first.close();}
        LibraryDatabase reopened=Room.databaseBuilder(context,LibraryDatabase.class,name).allowMainThreadQueries().build();
        try {
            assertEquals("Persistente",reopened.library().get("saved").displayTitle());assertEquals(1,reopened.library().playlists().size());
            assertEquals("Ana",reopened.library().get("saved").details().get("directors"));
            assertEquals("saved",reopened.library().playlistMedia(reopened.library().playlists().get(0).id).get(0).id);
        } finally {reopened.close();context.deleteDatabase(name);}
    }
    @Test public void catalogAndPlaylistHandle1105ItemsWithStableOrder() {
        PlaylistStore store=new PlaylistStore(db);String list=store.create("Colección grande");
        long start=System.nanoTime();
        db.runInTransaction(()-> {
            for (int i=0;i<1105;i++) {String id="large-"+i;add(id);store.add(list,id);}
        });
        assertEquals(1105,db.library().allMedia().size());assertEquals(1105,db.library().playlistItems(list).size());
        store.move(list,"large-1104",-1);
        assertEquals("large-1104",db.library().playlistMedia(list).get(1103).id);
        System.out.println("PEACH_CATALOG_PLAYLIST_1105_MS="+java.util.concurrent.TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-start));
    }
}
