package com.peach.local;

import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Spinner;
import androidx.appcompat.app.AlertDialog;
import java.util.concurrent.TimeUnit;
import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.Shadows;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.SQLiteMode;
import org.robolectric.shadows.ShadowDialog;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,qualifiers="w1280dp-h800dp-land")
@SQLiteMode(SQLiteMode.Mode.LEGACY)
public class LibraryUiTest {
    private LibraryDatabase fixture;
    @Before public void initializeScheduler() {
        fixture=androidx.room.Room.inMemoryDatabaseBuilder(org.robolectric.RuntimeEnvironment.getApplication(),LibraryDatabase.class)
            .allowMainThreadQueries().setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();
        org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",fixture);
        androidx.work.testing.WorkManagerTestInitHelper.initializeTestWorkManager(
            org.robolectric.RuntimeEnvironment.getApplication(),new androidx.work.Configuration.Builder()
                .setExecutor(Runnable::run).setTaskExecutor(Runnable::run).build());
    }
    @After public void closeFixture() throws Exception {
        LibraryDatabase.IO.submit(()->{}).get(30,TimeUnit.SECONDS);
        Shadows.shadowOf(Looper.getMainLooper()).idle();
        androidx.work.testing.WorkManagerTestInitHelper.closeWorkDatabase();
        fixture.close();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);
    }
    @Test public void scopeDialogCreatesPlaylistThroughVisibleControls() throws Exception {
        try (var controller=Robolectric.buildActivity(MainActivity.class).setup().visible()) {
            MainActivity activity=controller.get();
            activity.findViewById(R.id.scope).performClick();
            Shadows.shadowOf(Looper.getMainLooper()).idle();
            AlertDialog scope=(AlertDialog)ShadowDialog.getLatestDialog();
            scope.getListView().performItemClick(null,2,2);
            Shadows.shadowOf(Looper.getMainLooper()).idle();
            AlertDialog lists=(AlertDialog)ShadowDialog.getLatestDialog();
            lists.getButton(AlertDialog.BUTTON_POSITIVE).performClick();
            Shadows.shadowOf(Looper.getMainLooper()).idle();
            AlertDialog create=(AlertDialog)ShadowDialog.getLatestDialog();
            EditText name=findEditText(create.getWindow().getDecorView());assertNotNull(name);
            name.setText("Lista creada desde UI");create.getButton(AlertDialog.BUTTON_POSITIVE).performClick();
            boolean exists=LibraryDatabase.IO.submit(()->LibraryDatabase.get(activity).library().playlists().stream()
                .anyMatch(p->p.name.equals("Lista creada desde UI"))).get(30,TimeUnit.SECONDS);
            assertTrue(exists);Shadows.shadowOf(Looper.getMainLooper()).idle();assertFalse(activity.isFinishing());
        }
    }
    @Test public void sortSelectionPersistsAfterActivityRecreation() {
        try (var first=Robolectric.buildActivity(MainActivity.class).setup().visible()) {
            first.get().findViewById(R.id.toggleFilters).performClick();((Spinner)first.get().findViewById(R.id.order)).setSelection(1);
            first.pause().stop();
        }
        try (var reopened=Robolectric.buildActivity(MainActivity.class).setup().visible()) {
            assertEquals(1,((Spinner)reopened.get().findViewById(R.id.order)).getSelectedItemPosition());
            assertNotNull(reopened.get().findViewById(R.id.grid));
        }
    }
    @Test public void detailsButtonOpensScrollableExtendedFacts() {
        MediaEntry m=new MediaEntry();m.id="details-fixture";m.title="Campo";m.name="campo.mp4";m.folder="Videos";
        m.nfoDetails=NfoDetails.encode(java.util.Map.of("directors","Ana","collection","Expediciones","code","CAM-1"));
        fixture.library().insertMedia(m);
        try (var controller=Robolectric.buildActivity(MainActivity.class).setup().visible()) {
            MainActivity activity=controller.get();Shadows.shadowOf(Looper.getMainLooper()).idle();
            androidx.recyclerview.widget.RecyclerView grid=activity.findViewById(R.id.grid);
            grid.measure(View.MeasureSpec.makeMeasureSpec(1000,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(600,View.MeasureSpec.EXACTLY));
            grid.layout(0,0,1000,600);Shadows.shadowOf(Looper.getMainLooper()).idle();
            View button=grid.findViewById(R.id.details_button);assertNotNull(button);button.performClick();
            Shadows.shadowOf(Looper.getMainLooper()).idle();
            AlertDialog details=(AlertDialog)ShadowDialog.getLatestDialog();
            android.widget.TextView text=details.findViewById(R.id.detail_text);assertNotNull(text);
            assertTrue(text.isTextSelectable());assertTrue(text.getParent() instanceof android.widget.ScrollView);
            assertTrue(text.getText().toString().contains("Dirección\nAna"));assertTrue(text.getText().toString().contains("Colección\nExpediciones"));
            assertTrue(text.getText().toString().contains("Código\nCAM-1"));
            details.getButton(AlertDialog.BUTTON_POSITIVE).performClick();Shadows.shadowOf(Looper.getMainLooper()).idle();
            android.content.Intent playback=Shadows.shadowOf(activity).getNextStartedActivity();assertNotNull(playback);
            assertEquals(PlayerActivity.class.getName(),playback.getComponent().getClassName());
            assertEquals(m.id,playback.getStringExtra("mediaId"));
            button.performClick();Shadows.shadowOf(Looper.getMainLooper()).idle();
            details=(AlertDialog)ShadowDialog.getLatestDialog();
            details.getButton(AlertDialog.BUTTON_NEUTRAL).performClick();Shadows.shadowOf(Looper.getMainLooper()).idle();
            AlertDialog actions=(AlertDialog)ShadowDialog.getLatestDialog();assertNotNull(actions.getListView());
        }
    }
    private EditText findEditText(View view) {
        if (view instanceof EditText text) return text;
        if (view instanceof ViewGroup group) for (int i=0;i<group.getChildCount();i++) {
            EditText result=findEditText(group.getChildAt(i));if (result!=null) return result;
        }
        return null;
    }
    @Test public void mediaTypeSelectionFiltersAndPersistsAcrossRecreation() {
        for(String type:java.util.List.of(MediaRules.VIDEO,MediaRules.AUDIO,MediaRules.IMAGE)) {
            MediaEntry m=new MediaEntry();m.id=type;m.title=type;m.mediaType=type;fixture.library().insertMedia(m);
        }
        try(var controller=Robolectric.buildActivity(MainActivity.class).setup().visible()) {
            MainActivity activity=controller.get();Shadows.shadowOf(Looper.getMainLooper()).idle();
            activity.findViewById(R.id.toggleFilters).performClick();Spinner types=activity.findViewById(R.id.typeFilter);types.setSelection(3);Shadows.shadowOf(Looper.getMainLooper()).idle();
            assertEquals(1,((androidx.recyclerview.widget.RecyclerView)activity.findViewById(R.id.grid)).getAdapter().getItemCount());
            controller.recreate();Shadows.shadowOf(Looper.getMainLooper()).idle();
            assertEquals(3,((Spinner)controller.get().findViewById(R.id.typeFilter)).getSelectedItemPosition());
        }
    }
    @Test @org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
    public void nativeImageViewerDecodesNavigatesZoomsFavoritesAndRestoresCurrentImage() throws Exception {
        for(String id:java.util.List.of("a","b")) {
            MediaEntry m=new MediaEntry();m.id=id;m.title=id;m.mediaType=MediaRules.IMAGE;m.uri="content://viewer/"+id;
            fixture.library().insertMedia(m);
            byte[] bytes;
            try(var in=getClass().getClassLoader().getResourceAsStream("media/small.png")){assertNotNull(in);bytes=in.readAllBytes();}
            Shadows.shadowOf(org.robolectric.RuntimeEnvironment.getApplication().getContentResolver()).registerInputStreamSupplier(
                android.net.Uri.parse(m.uri),()->new java.io.ByteArrayInputStream(bytes));
        }
        android.content.Intent intent=new android.content.Intent(org.robolectric.RuntimeEnvironment.getApplication(),ImageViewerActivity.class).putExtra("mediaId","a");
        try(var controller=Robolectric.buildActivity(ImageViewerActivity.class,intent).setup().visible()) {
            idleLibrary();ImageViewerActivity activity=controller.get();awaitImage(activity);
            ZoomImageView canvas=activity.findViewById(R.id.imageCanvas);assertNotNull(canvas.getDrawable());
            activity.findViewById(R.id.imageZoomIn).performClick();assertEquals(1.5f,canvas.zoomFactor(),0.001f);
            activity.findViewById(R.id.imageFit).performClick();assertEquals(1,canvas.zoomFactor(),0.001f);
            activity.findViewById(R.id.imageFavorite).performClick();idleLibrary();assertTrue(fixture.library().get("a").favorite);
            activity.findViewById(R.id.imageNext).performClick();awaitImage(activity);
            assertEquals("b",((android.widget.TextView)activity.findViewById(R.id.imageTitle)).getText().toString());
            idleLibrary();assertEquals(1,fixture.library().get("b").playCount);assertEquals(2,fixture.library().usageCount());
            controller.recreate();idleLibrary();awaitImage(controller.get());idleLibrary();
            assertEquals("b",((android.widget.TextView)controller.get().findViewById(R.id.imageTitle)).getText().toString());
            assertEquals(1,fixture.library().get("b").playCount);assertEquals(2,fixture.library().usageCount());
        }
    }
    @Test public void searchableMetadataBrowserFiltersExactlyAndRestoresScope() throws Exception {
        for(String actor:java.util.List.of("Ana","Anabel")) {
            MediaEntry m=new MediaEntry();m.id=actor;m.title=actor;m.actors=actor;m.name="campo.mp4";fixture.library().insertMedia(m);
        }
        try(var controller=Robolectric.buildActivity(MainActivity.class).setup().visible()) {
            MainActivity activity=controller.get();Shadows.shadowOf(Looper.getMainLooper()).idle();
            activity.findViewById(R.id.explore).performClick();
            AlertDialog explore=(AlertDialog)ShadowDialog.getLatestDialog();explore.getListView().performItemClick(null,1,1);
            AlertDialog terms=(AlertDialog)ShadowDialog.getLatestDialog();EditText query=findEditText(terms.getWindow().getDecorView());
            assertNotNull(query);query.setText("Ana");
            android.widget.ListView list=findList(terms.getWindow().getDecorView());assertNotNull(list);assertEquals(2,list.getAdapter().getCount());
            list.performItemClick(null,0,0);Shadows.shadowOf(Looper.getMainLooper()).idle();
            awaitGrid(activity,1);var grid=(androidx.recyclerview.widget.RecyclerView)activity.findViewById(R.id.grid);assertEquals(1,grid.getAdapter().getItemCount());
            grid.measure(View.MeasureSpec.makeMeasureSpec(1000,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(600,View.MeasureSpec.EXACTLY));grid.layout(0,0,1000,600);
            grid.findViewById(R.id.details_button).performClick();
            Shadows.shadowOf(Looper.getMainLooper()).idle();
            ((AlertDialog)ShadowDialog.getLatestDialog()).getButton(AlertDialog.BUTTON_POSITIVE).performClick();
            Shadows.shadowOf(Looper.getMainLooper()).idle();
            var intent=Shadows.shadowOf(activity).getNextStartedActivity();assertEquals("actors",intent.getStringExtra("facet"));assertEquals("Ana",intent.getStringExtra("term"));
            controller.recreate();Shadows.shadowOf(Looper.getMainLooper()).idle();
            awaitGrid(controller.get(),1);assertEquals(1,((androidx.recyclerview.widget.RecyclerView)controller.get().findViewById(R.id.grid)).getAdapter().getItemCount());
            assertTrue(((android.widget.Button)controller.get().findViewById(R.id.scope)).getText().toString().contains("Ana"));
        }
    }
    @Test public void createsGroupFromFileActionsAndKeepsScopeOnRecreation() throws Exception {
        MediaEntry m=new MediaEntry();m.id="a";m.title="Campo";m.name="campo.mp4";fixture.library().insertMedia(m);
        try(var controller=Robolectric.buildActivity(MainActivity.class).setup().visible()) {
            MainActivity activity=controller.get();Shadows.shadowOf(Looper.getMainLooper()).idle();
            var grid=(androidx.recyclerview.widget.RecyclerView)activity.findViewById(R.id.grid);
            grid.measure(View.MeasureSpec.makeMeasureSpec(1000,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(600,View.MeasureSpec.EXACTLY));grid.layout(0,0,1000,600);
            grid.findViewById(R.id.details_button).performClick();
            Shadows.shadowOf(Looper.getMainLooper()).idle();
            ((AlertDialog)ShadowDialog.getLatestDialog()).getButton(AlertDialog.BUTTON_NEUTRAL).performClick();
            Shadows.shadowOf(Looper.getMainLooper()).idle();
            ((AlertDialog)ShadowDialog.getLatestDialog()).getListView().performItemClick(null,4,4);
            Shadows.shadowOf(Looper.getMainLooper()).idle();
            ((AlertDialog)ShadowDialog.getLatestDialog()).getButton(AlertDialog.BUTTON_POSITIVE).performClick();
            Shadows.shadowOf(Looper.getMainLooper()).idle();
            AlertDialog create=(AlertDialog)ShadowDialog.getLatestDialog();EditText name=findEditText(create.getWindow().getDecorView());
            assertNotNull(name);name.setText("Obra y versiones");create.getButton(AlertDialog.BUTTON_POSITIVE).performClick();idleLibrary();
            assertEquals(1,fixture.library().groups().size());String id=fixture.library().groups().get(0).id;
            assertEquals("a",fixture.library().groupItems(id).get(0).mediaId);
            assertTrue(((android.widget.Button)activity.findViewById(R.id.scope)).getText().toString().contains("Obra y versiones"));
            controller.recreate();Shadows.shadowOf(Looper.getMainLooper()).idle();
            assertEquals(1,((androidx.recyclerview.widget.RecyclerView)controller.get().findViewById(R.id.grid)).getAdapter().getItemCount());
            assertTrue(((android.widget.Button)controller.get().findViewById(R.id.scope)).getText().toString().startsWith("Grupo"));
        }
    }
    @Test public void archiveCardShowsCatalogNoticeWithoutStartingPlayer() throws Exception {
        // RAR now routes to a bounded reader. Keep this check for catalogued archives
        // whose format still has no reader (for example, a legacy imported ARJ record).
        MediaEntry m=new MediaEntry();m.id="unknown-archive";m.title="Álbum";m.name="album.arj";m.mediaType=MediaRules.ARCHIVE;fixture.library().insertMedia(m);
        try(var controller=Robolectric.buildActivity(MainActivity.class).setup().visible()) {
            MainActivity activity=controller.get();activity.findViewById(R.id.toggleFilters).performClick();((Spinner)activity.findViewById(R.id.typeFilter)).setSelection(4);
            Shadows.shadowOf(Looper.getMainLooper()).idle();var grid=(androidx.recyclerview.widget.RecyclerView)activity.findViewById(R.id.grid);
            grid.measure(View.MeasureSpec.makeMeasureSpec(1000,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(600,View.MeasureSpec.EXACTLY));grid.layout(0,0,1000,600);
            // AsyncListDiffer computes filter changes off the main thread. Wait for its
            // committed list, not merely one main-looper drain; retain the behavior checks.
            long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(5);
            while(grid.getAdapter().getItemCount()!=1 && System.nanoTime()<deadline){Thread.sleep(10);Shadows.shadowOf(Looper.getMainLooper()).idle();}
            assertEquals(1,grid.getAdapter().getItemCount());
            grid.measure(View.MeasureSpec.makeMeasureSpec(1000,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(600,View.MeasureSpec.EXACTLY));grid.layout(0,0,1000,600);
            grid.findViewHolderForAdapterPosition(0).itemView.performClick();
            AlertDialog details=(AlertDialog)ShadowDialog.getLatestDialog();assertNotNull(details);
            assertTrue(((android.widget.TextView)details.findViewById(R.id.detail_text)).getText().toString().contains("no tiene lector integrado"));
            assertEquals(View.GONE,details.getButton(AlertDialog.BUTTON_POSITIVE).getVisibility());
            assertNull(Shadows.shadowOf(activity).getNextStartedActivity());
        }
    }
    private android.widget.ListView findList(View view) {
        if(view instanceof android.widget.ListView list)return list;
        if(view instanceof ViewGroup group)for(int i=0;i<group.getChildCount();i++) {
            var result=findList(group.getChildAt(i));if(result!=null)return result;
        }
        return null;
    }
    private void awaitGrid(MainActivity activity,int expected)throws Exception{long until=System.nanoTime()+TimeUnit.SECONDS.toNanos(10);do{idleLibrary();if(((androidx.recyclerview.widget.RecyclerView)activity.findViewById(R.id.grid)).getAdapter().getItemCount()==expected)return;Thread.sleep(10);}while(System.nanoTime()<until);}
    private void idleLibrary() throws Exception {
        LibraryDatabase.IO.submit(()->{}).get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();
    }
    private void awaitImage(ImageViewerActivity activity) throws Exception {
        java.util.concurrent.Future<?> pending=org.robolectric.util.ReflectionHelpers.getField(activity,"pending");
        assertNotNull(pending);pending.get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();
        assertNotNull(((ZoomImageView)activity.findViewById(R.id.imageCanvas)).getDrawable());
    }
}
