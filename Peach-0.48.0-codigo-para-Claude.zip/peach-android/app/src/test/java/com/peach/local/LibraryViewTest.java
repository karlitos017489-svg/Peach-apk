package com.peach.local;

import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

public class LibraryViewTest {
    private MediaEntry media(String id,String title,String root,String folder) {
        MediaEntry m=new MediaEntry();m.id=id;m.title=title;m.root=root;m.folder=folder;return m;
    }
    @Test public void folderScopeRespectsRootAndDirectoryBoundary() {
        MediaEntry a=media("a","Uno","r","Videos / Campo"), b=media("b","Dos","r","Videos / Campo2");
        MediaEntry c=media("c","Tres","other","Videos / Campo"),d=media("d","Cuatro","r","Videos / Campo / Norte");
        assertEquals(List.of(a,d),LibraryView.select(List.of(a,b,c,d),"",0,"r","Videos / Campo","",List.of(),0)
            .stream().sorted(java.util.Comparator.comparing(m->m.id)).toList());
    }
    @Test public void findsOnlyImmediateSubfoldersFromIndexedVideos() {
        var rows=List.of(media("a","A","r","Videos / Norte / Sitio"),media("b","B","r","Videos / Sur"),
            media("c","C","other","Videos / Este"));
        assertEquals(List.of("Norte","Sur"),LibraryView.children(rows,"r","Videos"));
        assertEquals(List.of("Sitio"),LibraryView.children(rows,"r","Videos / Norte"));
    }
    @Test public void customTitleTagsAndClearedTagsDriveSearch() {
        MediaEntry m=media("a","Original","r","Videos");m.tags="Antiguas";m.userTitle="Personal";m.userTags="Geología";
        assertTrue(MediaRules.matches(m,"personal",0));assertTrue(MediaRules.matches(m,"geología",0));
        assertFalse(MediaRules.matches(m,"antiguas",0));m.userTags="";
        assertFalse(MediaRules.matches(m,"geología",0));
    }
    @Test public void distinctProviderFolderNamesAreNotMergedByCase() {
        var rows=List.of(media("a","A","r","Videos / Campo"),media("b","B","r","Videos / campo"));
        assertEquals(2,LibraryView.children(rows,"r","Videos").size());
    }
    @Test public void playlistOrderAndFiltersCombineWithoutChangingSource() {
        MediaEntry a=media("a","Alfa","r","Videos"),b=media("b","Beta","r","Videos");b.favorite=true;
        PlaylistItem x=new PlaylistItem();x.playlistId="list";x.mediaId="b";x.position=0;
        PlaylistItem y=new PlaylistItem();y.playlistId="list";y.mediaId="a";y.position=1;
        assertEquals(List.of(b,a),LibraryView.select(List.of(a,b),"",0,"","","list",List.of(x,y),4));
        assertEquals(List.of(b),LibraryView.select(List.of(a,b),"",1,"","","list",List.of(x,y),4));
        assertEquals("Alfa",a.title);
    }
    @Test public void sortByAddedAndLastPlayedUsesStableTieBreak() {
        MediaEntry a=media("a","Alfa","r","Videos"),b=media("b","Beta","r","Videos");
        a.addedAt=0;b.addedAt=100;a.lastPlayed=200;b.lastPlayed=10;
        assertEquals(List.of(b,a),LibraryView.select(List.of(a,b),"",0,"","","",List.of(),2));
        assertEquals(List.of(a,b),LibraryView.select(List.of(a,b),"",0,"","","",List.of(),3));
    }
}
