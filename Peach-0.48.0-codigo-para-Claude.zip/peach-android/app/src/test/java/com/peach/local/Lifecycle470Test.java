package com.peach.local;

import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.os.*;
import java.io.*;
import java.nio.file.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import androidx.appcompat.app.AlertDialog;
import androidx.media3.exoplayer.ExoPlayer;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.shadows.*;
import org.robolectric.util.ReflectionHelpers;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28) @SQLiteMode(SQLiteMode.Mode.LEGACY) @GraphicsMode(GraphicsMode.Mode.NATIVE)
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public class Lifecycle470Test {
    Context app;
    @Before public void setup(){app=RuntimeEnvironment.getApplication();WallpaperStore.remove(app);}
    @After public void stop(){WallpaperStore.remove(app);}
    Uri image()throws Exception {Bitmap bitmap=Bitmap.createBitmap(120,60,Bitmap.Config.ARGB_8888);bitmap.eraseColor(Color.rgb(90,140,60));ByteArrayOutputStream out=new ByteArrayOutputStream();bitmap.compress(Bitmap.CompressFormat.PNG,100,out);bitmap.recycle();Uri uri=Uri.parse("content://own.wallpaper/image");Shadows.shadowOf(app.getContentResolver()).registerInputStreamSupplier(uri,()->new ByteArrayInputStream(out.toByteArray()));return uri;}
    @Test public void interruptedAtomicWallpaperWriteRestoresLastCompleteImage()throws Exception {UiAppearance.saveWallpaper(app,image());byte[] before=Files.readAllBytes(UiAppearance.wallpaper(app).toPath());android.util.AtomicFile atomic=new android.util.AtomicFile(UiAppearance.wallpaper(app));FileOutputStream partial=atomic.startWrite();partial.write(new byte[]{1,2,3});partial.close();UiAppearance.clearWallpaperMemory();WallpaperStore.Snapshot loaded=WallpaperStore.load(app);assertTrue(loaded.bitmap().getWidth()>0);assertArrayEquals(before,Files.readAllBytes(UiAppearance.wallpaper(app).toPath()));}
    @Test public void removeWallpaperClearsAtomicBackupsAndDoesNotResurrectAfterRestart()throws Exception {UiAppearance.saveWallpaper(app,image());android.util.AtomicFile atomic=new android.util.AtomicFile(UiAppearance.wallpaper(app));FileOutputStream partial=atomic.startWrite();partial.write(new byte[]{1});partial.close();assertTrue(WallpaperStore.remove(app));try{WallpaperStore.load(app);fail();}catch(FileNotFoundException expected){}assertFalse(new File(UiAppearance.wallpaper(app)+".bak").exists());assertFalse(new File(UiAppearance.wallpaper(app)+".new").exists());}
    @Test public void sameSizedWallpaperSavedWithinSameTimestampStillGetsNewRevision()throws Exception {Uri uri=image();UiAppearance.saveWallpaper(app,uri);long stamp=UiAppearance.wallpaper(app).lastModified(),length=UiAppearance.wallpaper(app).length();String before=WallpaperStore.key(app);UiAppearance.saveWallpaper(app,uri);assertEquals(length,UiAppearance.wallpaper(app).length());assertTrue(UiAppearance.wallpaper(app).setLastModified(stamp));assertNotEquals(before,WallpaperStore.key(app));}
    @Test public void wallpaperCroppingPreservesProportionsInBothOrientations(){assertEquals(new Rect(35,0,125,90),WallpaperImage.crop(160,90,100,100));assertEquals(new Rect(0,55,90,105),WallpaperImage.crop(90,160,160,90));assertEquals(new Rect(0,0,160,90),WallpaperImage.crop(160,90,160,90));}
    @Test public void stoppingPlayerDismissesVolumeBeforeReleasingItsEngine()throws Exception {LibraryUiTest fixture=new LibraryUiTest();fixture.initializeScheduler();try(var screen=Robolectric.buildActivity(PlayerActivity.class,SourceFiles.play(app,Uri.parse("content://own.lifecycle/video"),"own.mp4")).create().visible()){PlayerActivity a=screen.get();ExoPlayer player=new ExoPlayer.Builder(a).build();ReflectionHelpers.setField(a,"player",player);screen.start().resume();a.findViewById(R.id.player_volume).performClick();AlertDialog dialog=(AlertDialog)ShadowDialog.getLatestDialog();assertTrue(dialog.isShowing());screen.pause().stop();assertFalse(dialog.isShowing());assertNull(ReflectionHelpers.getField(a,"player"));}finally{fixture.closeFixture();}}
    @Test public void secondTransferCleanupRunsOffUiAndCannotReleaseOtherTransfersGlobalSlot()throws Exception {DirectSave460Test fixture=new DirectSave460Test();fixture.setup();try{DirectSaveActivity.Draft.ACTIVE.set(true);CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);AtomicBoolean onMain=new AtomicBoolean(true);ShadowContentResolver.registerProviderInternal("own.busy.cleanup",new DownloadFlowTest.DeletingProvider(){@Override public Bundle call(String method,String arg,Bundle extras){if(method.equals("android:deleteDocument")){onMain.set(Looper.myLooper()==Looper.getMainLooper());entered.countDown();try{release.await(5,TimeUnit.SECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}}return super.call(method,arg,extras);}});fixture.draft.start(Uri.parse("content://own.busy.cleanup/document/new"));try{assertTrue(entered.await(10,TimeUnit.SECONDS));assertFalse(onMain.get());assertTrue(fixture.draft.busy);assertTrue(DirectSaveActivity.Draft.ACTIVE.get());}finally{release.countDown();}fixture.await();assertFalse(fixture.draft.busy);assertTrue(DirectSaveActivity.Draft.ACTIVE.get());assertEquals(0,fixture.calls);assertTrue(fixture.draft.journal.items().isEmpty());}finally{fixture.close();}}
}
