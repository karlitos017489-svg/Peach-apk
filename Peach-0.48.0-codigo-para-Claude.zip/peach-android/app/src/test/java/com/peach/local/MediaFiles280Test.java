package com.peach.local;

import android.net.Uri;
import android.graphics.drawable.AnimatedImageDrawable;
import java.io.*;
import java.nio.file.Files;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE) @GraphicsMode(GraphicsMode.Mode.NATIVE)
public class MediaFiles280Test {
    @Test public void mp4AndGifHeadersCorrectBinNamesAndMediaKind()throws Exception{
        for(String[] p:new String[][]{{"src/androidTest/assets/sample.mp4","mp4","video"},{"src/test/resources/media/own-animated.gif","gif","image"},{"src/test/resources/media/small.png","png","image"},{"src/test/resources/media/rotated.jpg","jpg","image"}}){LocalMedia.Format f=LocalMedia.inspect(new File(p[0]));assertEquals(p[1],f.extension());assertEquals(p[2],f.kind());assertEquals("own."+p[1],LocalMedia.name("own.bin",f));}
    }
    @Test public void emptyAndHtmlAreExplainedRatherThanRenamedMp4()throws Exception{
        for(byte[] b:new byte[][]{new byte[0],"  <!doctype html><html>Own login</html>".getBytes(),"<html>own</html>".getBytes()})try{LocalMedia.header(b);fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("vacío")||expected.getMessage().contains("página web"));}
        assertEquals("own.bin",LocalMedia.name("own.bin",LocalMedia.header(new byte[]{1,2,3})));
    }
    @Test public void inspectionReadsAtMostFourKiBAndClosesStream()throws Exception{
        int[] read={0};boolean[] close={false};InputStream input=new InputStream(){public int read(){throw new AssertionError();}public int read(byte[] b,int off,int length){read[0]+=length;java.util.Arrays.fill(b,off,off+length,(byte)1);return length;}public void close(){close[0]=true;}};LocalMedia.inspect(input);assertEquals(4096,read[0]);assertTrue(close[0]);
    }
    @Test public void nativeGifDrawableIsAnimatedAndStopsWithLifecycleHelper()throws Exception{
        byte[] bytes=Files.readAllBytes(new File("src/test/resources/media/own-animated.gif").toPath());Uri uri=Uri.parse("content://own.gif/animation.bin");var resolver=RuntimeEnvironment.getApplication().getContentResolver();Shadows.shadowOf(resolver).registerInputStreamSupplier(uri,()->new ByteArrayInputStream(bytes));
        // ImageDecoder's URI source uses an asset file descriptor, as on Android SAF.
        var provider=new android.content.ContentProvider(){
            public boolean onCreate(){return true;}public android.database.Cursor query(Uri u,String[] p,String s,String[] a,String o){return null;}public String getType(Uri u){return "image/gif";}public Uri insert(Uri u,android.content.ContentValues v){return null;}public int update(Uri u,android.content.ContentValues v,String s,String[] a){return 0;}public int delete(Uri u,String s,String[] a){return 0;}
            @Override public android.os.ParcelFileDescriptor openFile(Uri u,String mode)throws FileNotFoundException{return android.os.ParcelFileDescriptor.open(new File("src/test/resources/media/own-animated.gif"),android.os.ParcelFileDescriptor.MODE_READ_ONLY);}
        };
        android.content.pm.ProviderInfo info=new android.content.pm.ProviderInfo();info.authority="own.gif";info.exported=true;provider.attachInfo(RuntimeEnvironment.getApplication(),info);
        org.robolectric.shadows.ShadowContentResolver.registerProviderInternal("own.gif",provider);
        var drawable=AnimatedImages.decode(resolver,uri);assertTrue(drawable instanceof AnimatedImageDrawable);assertEquals(64,drawable.getIntrinsicWidth());assertEquals(48,drawable.getIntrinsicHeight());AnimatedImages.start(drawable);assertTrue(((AnimatedImageDrawable)drawable).isRunning());AnimatedImages.stop(drawable);assertFalse(((AnimatedImageDrawable)drawable).isRunning());
    }
}
