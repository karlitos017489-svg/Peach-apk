package com.peach.local;

import android.net.Uri;
import androidx.media3.common.*;
import androidx.media3.datasource.*;
import androidx.media3.extractor.*;
import androidx.media3.extractor.text.*;
import java.io.*;
import java.nio.charset.*;
import java.util.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

/** Real extractor/subtitle parser and local content adapter; no Android codec claim. */
@RunWith(RobolectricTestRunner.class) @Config(sdk=28)
public class MediaFormats440Test {
    @Test public void eightRealContainersEmitVideoSamplesFromOwnGeneratedMedia()throws Exception {
        Map<String,String> expected=Map.of("mp4","video/avc","mov","video/avc","mkv","video/avc","webm","video/x-vnd.on2.vp8","avi","video/mp4v-es","flv","video/avc","ts","video/avc","mpg","video/mpeg2");
        for(var sample:expected.entrySet()) {
            byte[] bytes=Formats440Test.fixture("muestra."+sample.getKey());Extractor chosen=null;
            for(Extractor e:new DefaultExtractorsFactory().createExtractors()) {
                ByteArrayDataSource source=new ByteArrayDataSource(bytes);source.open(new DataSpec(Uri.parse("data://own/sample")));boolean accepted;
                try{accepted=e.sniff(new DefaultExtractorInput(source,0,bytes.length));}finally{source.close();}
                if(accepted){chosen=e;break;}e.release();
            }
            assertNotNull(sample.getKey(),chosen);StreamDataSourceTest.Capture capture=new StreamDataSourceTest.Capture();chosen.init(capture);
            ByteArrayDataSource source=new ByteArrayDataSource(bytes);source.open(new DataSpec(Uri.parse("data://own/sample")));DefaultExtractorInput input=new DefaultExtractorInput(source,0,bytes.length);PositionHolder seek=new PositionHolder();
            try{int loops=0;while(loops++<10000){int result=chosen.read(input,seek);if(result==Extractor.RESULT_END_OF_INPUT)break;if(result==Extractor.RESULT_SEEK){source.close();source=new ByteArrayDataSource(bytes);source.open(new DataSpec.Builder().setUri(Uri.parse("data://own/sample")).setPosition(seek.position).build());input=new DefaultExtractorInput(source,seek.position,bytes.length);}}assertTrue(sample.getKey()+" loop limit",loops<10000);assertTrue(sample.getKey()+" samples",capture.videoSamples>0);assertEquals(sample.getKey(),sample.getValue(),capture.video.sampleMimeType);}
            finally{source.close();chosen.release();}
        }
    }
    @Test public void srtVttAndAssParsersProduceRealVisibleCuesAfterUnicodeConversion()throws Exception {
        String srt="1\n00:00:00,000 --> 00:00:00,900\nPeach: ñ y capas.\n";
        String vtt="WEBVTT\n\n00:00.000 --> 00:00.900\nPeach: ñ y capas.\n";
        String ass="[Script Info]\nScriptType: v4.00+\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\nDialogue: 0,0:00:00.00,0:00:00.90,Default,,0,0,0,,Peach: ñ y capas.\n";
        List<SubtitleParser> parsers=List.of(new androidx.media3.extractor.text.subrip.SubripParser(),new androidx.media3.extractor.text.webvtt.WebvttParser(),new androidx.media3.extractor.text.ssa.SsaParser());
        for(int i=0;i<parsers.size();i++){String text=List.of(srt,vtt,ass).get(i);byte[] bytes=SubtitleText.unicode(text.getBytes(StandardCharsets.UTF_16),"auto");List<CuesWithTiming> result=new ArrayList<>();parsers.get(i).parse(bytes,0,bytes.length,SubtitleParser.OutputOptions.allCues(),result::add);assertTrue(result.stream().flatMap(c->c.cues.stream()).anyMatch(c->c.text!=null && c.text.toString().contains("Peach: ñ y capas.")));}
    }
    @Test public void subtitleAdapterUsesOnlyBoundContentUriAndSupportsOutputRanges()throws Exception {
        SubtitleSources factory=new SubtitleSources(RuntimeEnvironment.getApplication());Uri selected=ReaderSessionTest.register("subtitle-own",Formats440Test.fixture("muestra-utf-16.srt"));Uri opaque=factory.register(selected,"auto");assertFalse(opaque.toString().contains(selected.toString()));
        byte[] expected=SubtitleText.unicode(Formats440Test.fixture("muestra-utf-16.srt"),"auto");DataSource source=factory.createDataSource();try{assertEquals(12,source.open(new DataSpec.Builder().setUri(opaque).setPosition(2).setLength(12).build()));byte[] bytes=new byte[32];assertEquals(12,source.read(bytes,0,32));assertArrayEquals(Arrays.copyOfRange(expected,2,14),Arrays.copyOf(bytes,12));assertEquals(-1,source.read(bytes,0,32));assertEquals(opaque,source.getUri());}finally{source.close();}assertNull(source.getUri());
    }
    @Test public void subtitleAdapterRejectsUnknownIdsRemoteUrlsAndInjectedHeadersWithoutOpeningContent()throws Exception {
        SubtitleSources factory=new SubtitleSources(RuntimeEnvironment.getApplication());Uri selected=ReaderSessionTest.register("never",new byte[0]);Uri opaque=factory.register(selected,"auto");
        for(DataSpec spec:List.of(new DataSpec(Uri.parse("peach-subtitle://local/unknown")),new DataSpec(Uri.parse("https://example.invalid/no-fetch")),new DataSpec.Builder().setUri(opaque).setHttpRequestHeaders(Map.of("Cookie","secret")).build(),new DataSpec.Builder().setUri(opaque).setHttpMethod(DataSpec.HTTP_METHOD_POST).build())){DataSource source=factory.createDataSource();try{source.open(spec);fail();}catch(IOException expected){}finally{source.close();}}
        try{factory.register(Uri.parse("https://example.invalid/"),"auto");fail();}catch(IOException expected){}
    }
    @Test public void oversizedOrMalformedSubtitleReadIsBoundedAndCloseCanBeRepeated()throws Exception {
        SubtitleSources factory=new SubtitleSources(RuntimeEnvironment.getApplication());for(byte[] input:List.of(new byte[]{(byte)255},new byte[SubtitleText.MAX_BYTES+1])){Uri opaque=factory.register(ReaderSessionTest.register(UUID.randomUUID().toString(),input),"auto");DataSource source=factory.createDataSource();try{source.open(new DataSpec(opaque));fail();}catch(IOException expected){}finally{source.close();source.close();}}
    }
    @Test public void diagnosticReportsDetectedFormatAndSupportWithoutInventingResolution() {
        var group=new androidx.media3.common.TrackGroup(new Format.Builder().setSampleMimeType("video/avc").setWidth(160).setHeight(120).setCodecs("avc1.42001E").build());
        Tracks tracks=new Tracks(com.google.common.collect.ImmutableList.of(new Tracks.Group(group,false,new int[]{C.FORMAT_HANDLED},new boolean[]{true})));
        String text=PlaybackFormat.describe(tracks);assertTrue(text.contains("video/avc"));assertTrue(text.contains("160×120"));assertTrue(text.contains("seleccionada"));assertFalse(text.contains("1920"));assertTrue(PlaybackFormat.describe(Tracks.EMPTY).contains("Todavía no hay pistas"));
    }
    @Test public void realMergedMediaSourceDeliversSubtitleSamplesThroughUnicodeAdapter()throws Exception {
        var factory=new SubtitleSources(RuntimeEnvironment.getApplication());Uri subtitle=factory.register(ReaderSessionTest.register("pipeline-subtitle",Formats440Test.fixture("muestra-utf-16.srt")),"auto");
        Uri video=Uri.parse("data:video/mp4;base64,"+java.util.Base64.getEncoder().encodeToString(Formats440Test.fixture("muestra.mp4")));
        var item=new MediaItem.Builder().setUri(video).setSubtitleConfigurations(List.of(new MediaItem.SubtitleConfiguration.Builder(subtitle).setMimeType("application/x-subrip").build())).build();
        var source=new androidx.media3.exoplayer.source.DefaultMediaSourceFactory(factory).createMediaSource(item);
        androidx.media3.exoplayer.source.MediaPeriod[] period={null};boolean[] prepared={false};
        androidx.media3.exoplayer.source.MediaSource.MediaSourceCaller caller=(s,timeline)->{if(period[0]!=null)return;period[0]=source.createPeriod(new androidx.media3.exoplayer.source.MediaSource.MediaPeriodId(timeline.getUidOfPeriod(0)),new androidx.media3.exoplayer.upstream.DefaultAllocator(true,C.DEFAULT_BUFFER_SEGMENT_SIZE),0);period[0].prepare(new androidx.media3.exoplayer.source.MediaPeriod.Callback(){public void onPrepared(androidx.media3.exoplayer.source.MediaPeriod p){prepared[0]=true;}public void onContinueLoadingRequested(androidx.media3.exoplayer.source.MediaPeriod p){p.continueLoading(new androidx.media3.exoplayer.LoadingInfo.Builder().setPlaybackPositionUs(0).build());}},0);};
        try{source.prepareSource(caller,null,androidx.media3.exoplayer.analytics.PlayerId.UNSET);long end=System.nanoTime()+5_000_000_000L;
            while(!prepared[0] && System.nanoTime()<end){org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle();if(period[0]!=null)period[0].maybeThrowPrepareError();Thread.sleep(5);}assertTrue("Merged video/subtitle source must prepare",prepared[0]);
            var groups=period[0].getTrackGroups();TrackGroup text=null;for(int i=0;i<groups.length;i++)if(groups.get(i).type==C.TRACK_TYPE_TEXT)text=groups.get(i);assertNotNull(text);
            var streams=new androidx.media3.exoplayer.source.SampleStream[1];period[0].selectTracks(new androidx.media3.exoplayer.trackselection.ExoTrackSelection[]{new androidx.media3.exoplayer.trackselection.FixedTrackSelection(text,0)},new boolean[1],streams,new boolean[1],0);
            var format=new androidx.media3.exoplayer.FormatHolder();var buffer=new androidx.media3.decoder.DecoderInputBuffer(androidx.media3.decoder.DecoderInputBuffer.BUFFER_REPLACEMENT_MODE_NORMAL);boolean received=false;end=System.nanoTime()+5_000_000_000L;
            while(System.nanoTime()<end){period[0].continueLoading(new androidx.media3.exoplayer.LoadingInfo.Builder().setPlaybackPositionUs(0).build());org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle();int result=streams[0].readData(format,buffer,0);if(result==C.RESULT_BUFFER_READ && !buffer.isEndOfStream()){assertTrue(buffer.data.position()>0);received=true;break;}streams[0].maybeThrowError();Thread.sleep(5);}assertTrue("Real text SampleStream must receive a cue",received);
        }finally{if(period[0]!=null)source.releasePeriod(period[0]);source.releaseSource(caller);org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle();}
    }
}
