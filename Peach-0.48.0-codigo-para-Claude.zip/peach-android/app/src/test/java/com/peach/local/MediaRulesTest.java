package com.peach.local;

import org.junit.Test;
import static org.junit.Assert.*;

public class MediaRulesTest {
    @Test public void indexesVideoReferencesButExcludesImageSidecars() {
        assertTrue(MediaRules.isVideo("campo.MP4")); assertTrue(MediaRules.isVideo("campo.mkv"));
        assertFalse(MediaRules.isVideo("campo.mp4.jpg")); assertTrue(MediaRules.isVideo("campo.strm"));
        assertTrue(MediaRules.isVideo("campo.iso"));
    }
    @Test public void pairsOnlyExactOrKnownSubtitleSuffixes() {
        assertTrue(MediaRules.subtitleMatches("campo.mp4","campo.es.srt"));
        assertTrue(MediaRules.subtitleMatches("campo.mp4","campo.en.forced.vtt"));
        assertTrue(MediaRules.subtitleMatches("campo.MP4","CAMPO.ass"));
        assertFalse(MediaRules.subtitleMatches("campo.mp4","campo2.srt"));
        assertFalse(MediaRules.subtitleMatches("campo.mp4","campo.otra.srt"));
    }
    @Test public void mapsSubtitleMimeTypes() {
        assertEquals("application/x-subrip",MediaRules.subtitleMime("test.srt"));
        assertEquals("text/x-ssa",MediaRules.subtitleMime("test.ass"));
        assertEquals("text/vtt",MediaRules.subtitleMime("test.vtt"));
    }
    @Test public void marksWatchedAtNinetyFivePercent() {
        assertFalse(MediaRules.watchedByProgress(0,0));
        assertFalse(MediaRules.watchedByProgress(949,1000));
        assertTrue(MediaRules.watchedByProgress(950,1000));
    }
    @Test public void filtersAndSearchesMetadata() {
        MediaEntry m=new MediaEntry(); m.title="Sonora";m.tags="Geología";
        assertTrue(MediaRules.matches(m,"GEOLOGÍA",0));
        assertFalse(MediaRules.matches(m,"",1)); m.favorite=true;
        assertTrue(MediaRules.matches(m,"son",1));m.watched=true;
        assertFalse(MediaRules.matches(m,"",2));assertTrue(MediaRules.matches(m,"",4));
    }
    @Test public void requiresProgressForContinueFilter() {
        MediaEntry m=new MediaEntry();assertFalse(MediaRules.matches(m,"",3));
        m.position=123;assertTrue(MediaRules.matches(m,"",3));
    }
}
