package com.peach.local;

import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

public class MediaTypesTest {
    private MediaEntry row(String id,String type) {MediaEntry m=new MediaEntry();m.id=id;m.title=id;m.mediaType=type;m.root="r";m.folder="Carpeta";return m;}
    @Test public void classifiesOriginalFamiliesIncludingCatalogOnlyFormats() {
        for(String n:List.of("foto.JPG","foto.heic","foto.png","foto.webp")) assertEquals(MediaRules.IMAGE,MediaRules.type(n));
        for(String n:List.of("voz.MP3","voz.m4a","voz.wav","voz.flac","voz.opus"))assertEquals(MediaRules.AUDIO,MediaRules.type(n));
        assertEquals(MediaRules.VIDEO,MediaRules.type("campo.MP4"));
        for(String n:List.of("archivo.zip","archivo.RAR","archivo.7z","archivo.tar","archivo.gz"))assertEquals(MediaRules.ARCHIVE,MediaRules.type(n));
        for(String n:List.of("archivo.strm","disco.iso","archivo.rmvb"))assertEquals(MediaRules.VIDEO,MediaRules.type(n));
        assertEquals(MediaRules.OTHER,MediaRules.type("documento.pdf"));
        for(String n:List.of("campo.nfo","campo.srt","poster.tbn"))assertTrue(MediaRules.sidecar(n));
    }
    @Test public void typeScopeCombinesWithFolderSearchAndFavorites() {
        MediaEntry v=row("video",MediaRules.VIDEO),a=row("audio",MediaRules.AUDIO),i=row("imagen",MediaRules.IMAGE);a.favorite=true;
        assertEquals(List.of(a),LibraryView.select(List.of(v,a,i),"aud",1,"r","Carpeta","",List.of(),0,MediaRules.AUDIO));
        assertTrue(LibraryView.select(List.of(v,a,i),"",1,"r","Carpeta","",List.of(),0,MediaRules.IMAGE).isEmpty());
        assertEquals(3,LibraryView.select(List.of(v,a,i),"",0,"","","",List.of(),0,"").size());
    }
    @Test public void mixedListsKeepGlobalIdentityAndSeparateAvFromImages() {
        MediaEntry a=row("audio",MediaRules.AUDIO),i=row("foto",MediaRules.IMAGE),v=row("video",MediaRules.VIDEO);
        assertEquals(List.of(a,v),MediaQueues.select(List.of(a,i,v),a,false));
        assertEquals(List.of(i),MediaQueues.select(List.of(a,i,v),i,true));
        assertTrue(MediaQueues.select(List.of(i),i,false).isEmpty());
        assertTrue(MediaQueues.select(List.of(a,i,v),i,false).isEmpty());
        assertEquals(List.of(a),MediaQueues.select(List.of(),a,false));
    }
    @Test public void unavailableMembersAreSkippedExceptTheExplicitSelection() {
        MediaEntry a=row("a",MediaRules.IMAGE),b=row("b",MediaRules.IMAGE);a.missing=true;b.missing=true;
        assertEquals(List.of(a),MediaQueues.select(List.of(b,a),a,true));
    }
    @Test public void catalogOnlyDocumentsNeverEnterAvQueues() {
        MediaEntry archive=row("archive",MediaRules.ARCHIVE),other=row("other",MediaRules.OTHER),iso=row("disc",MediaRules.VIDEO);
        iso.name="disc.iso";MediaEntry audio=row("audio",MediaRules.AUDIO),video=row("video",MediaRules.VIDEO);
        assertEquals(List.of(audio,video),MediaQueues.select(List.of(archive,other,iso,audio,video),audio,false));
        for(MediaEntry m:List.of(archive,other,iso)) {
            assertTrue(MediaQueues.select(List.of(audio,m),m,false).isEmpty());assertFalse(MediaRules.catalogNotice(m).isEmpty());
        }
    }
    @Test public void coversEveryExtensionFamilyDeclaredByOriginalScanner() {
        for(String extension:List.of("mp4","m4v","mkv","avi","wmv","mov","ts","flv","rmvb","mpg","m2ts","strm","iso"))assertEquals(MediaRules.VIDEO,MediaRules.type("x."+extension));
        for(String extension:List.of("jpg","jpeg","png","gif","bmp","webp"))assertEquals(MediaRules.IMAGE,MediaRules.type("x."+extension));
        for(String extension:List.of("mp3","flac","wav","m4a","ogg","opus"))assertEquals(MediaRules.AUDIO,MediaRules.type("x."+extension));
        for(String extension:List.of("zip","rar","7z","tar","gz"))assertEquals(MediaRules.ARCHIVE,MediaRules.type("x."+extension));
        assertEquals(MediaRules.OTHER,MediaRules.type("README"));assertEquals(MediaRules.OTHER,MediaRules.type("x.pdf"));
    }
}
