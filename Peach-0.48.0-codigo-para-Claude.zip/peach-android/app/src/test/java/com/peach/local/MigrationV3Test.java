package com.peach.local;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import androidx.room.Room;
import java.nio.charset.StandardCharsets;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.SQLiteMode;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,manifest=Config.NONE)
@SQLiteMode(SQLiteMode.Mode.LEGACY)
public class MigrationV3Test {
    @Test public void exportedV3UpgradePreservesNfoPersonalStateRootsAndLists() throws Exception {
        Context context=RuntimeEnvironment.getApplication();String name="migration-v3.db";context.deleteDatabase(name);
        var path=context.getDatabasePath(name);path.getParentFile().mkdirs();JSONObject schema;
        try(var in=getClass().getClassLoader().getResourceAsStream("com.peach.local.LibraryDatabase/3.json")) {
            assertNotNull(in);schema=new JSONObject(new String(in.readAllBytes(),StandardCharsets.UTF_8)).getJSONObject("database");
        }
        try(SQLiteDatabase old=SQLiteDatabase.openOrCreateDatabase(path,null)) {
            JSONArray entities=schema.getJSONArray("entities");
            for(int i=0;i<entities.length();i++) {
                JSONObject entity=entities.getJSONObject(i);String table=entity.getString("tableName");
                old.execSQL(entity.getString("createSql").replace("${TABLE_NAME}",table));
                JSONArray indices=entity.optJSONArray("indices");
                if(indices!=null)for(int j=0;j<indices.length();j++)old.execSQL(indices.getJSONObject(j).getString("createSql").replace("${TABLE_NAME}",table));
                ContentValues values=new ContentValues();JSONArray fields=entity.getJSONArray("fields");
                for(int j=0;j<fields.length();j++) {
                    JSONObject field=fields.getJSONObject(j);String key=field.getString("columnName");
                    if(!field.optBoolean("notNull"))values.putNull(key);
                    else if(field.getString("affinity").equals("TEXT"))values.put(key,"fixture");else values.put(key,0);
                }
                switch(table) {
                    case "media"->{values.put("id","video");values.put("uri","content://fixture/video");values.put("root","root");values.put("name","campo.mp4");
                        values.put("title","Origen");values.put("userTitle","Personal");values.put("userTags","");values.put("nfoDetails","{\"directors\":\"Ana\"}");
                        values.put("position",7000);values.put("duration",90000);values.put("favorite",1);values.put("watched",1);values.put("playCount",5);values.put("addedAt",123);}
                    case "roots"->{values.put("uri","root");values.put("generation",9);}
                    case "scan_queue"->{values.put("root","root");values.put("uri","content://fixture/pending");}
                    case "playlists"->{values.put("id","list");values.put("name","Mi lista");}
                    case "playlist_items"->{values.put("playlistId","list");values.put("mediaId","video");values.put("position",2);}
                }
                old.insertOrThrow(table,null,values);
            }
            JSONArray setup=schema.getJSONArray("setupQueries");for(int i=0;i<setup.length();i++)old.execSQL(setup.getString(i));old.setVersion(3);
        }
        LibraryDatabase migrated=Room.databaseBuilder(context,LibraryDatabase.class,name).addMigrations(LibraryDatabase.MIGRATION_3_4,LibraryDatabase.MIGRATION_4_5,LibraryDatabase.MIGRATION_5_6,LibraryDatabase.MIGRATION_6_7,LibraryDatabase.MIGRATION_7_8,LibraryDatabase.MIGRATION_8_9,LibraryDatabase.MIGRATION_9_10,LibraryDatabase.MIGRATION_10_11,LibraryDatabase.MIGRATION_11_12,LibraryDatabase.MIGRATION_12_13).allowMainThreadQueries().build();
        try {
            MediaEntry m=migrated.library().get("video");assertEquals(MediaRules.VIDEO,m.mediaType);assertEquals("Personal",m.displayTitle());assertEquals("",m.displayTags());
            assertEquals("Ana",m.details().get("directors"));assertEquals("content://fixture/video",m.uri);
            assertEquals(7000,m.position);assertEquals(90000,m.duration);assertTrue(m.favorite);assertTrue(m.watched);assertEquals(5,m.playCount);assertEquals(123,m.addedAt);
            assertEquals(9,migrated.library().roots().get(0).generation);assertNotNull(migrated.library().next("root"));
            assertEquals("Mi lista",migrated.library().playlist("list").name);assertEquals("video",migrated.library().playlistMedia("list").get(0).id);
            assertEquals(2,migrated.library().playlistItems("list").get(0).position);
        } finally {migrated.close();context.deleteDatabase(name);}
    }
}
