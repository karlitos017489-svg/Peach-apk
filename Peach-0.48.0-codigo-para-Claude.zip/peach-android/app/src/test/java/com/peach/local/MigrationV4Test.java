package com.peach.local;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import androidx.room.Room;
import java.nio.charset.StandardCharsets;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.SQLiteMode;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,manifest=Config.NONE)
@SQLiteMode(SQLiteMode.Mode.LEGACY)
public class MigrationV4Test {
    @Test public void exportedV4UpgradePreservesMixedCatalogListsRootsAndPersonalState() throws Exception {
        var context=RuntimeEnvironment.getApplication();String name="migration-v4.db";context.deleteDatabase(name);
        var path=context.getDatabasePath(name);path.getParentFile().mkdirs();JSONObject schema;
        try(var in=getClass().getClassLoader().getResourceAsStream("com.peach.local.LibraryDatabase/4.json")) {
            assertNotNull(in);schema=new JSONObject(new String(in.readAllBytes(),StandardCharsets.UTF_8)).getJSONObject("database");
        }
        try(SQLiteDatabase old=SQLiteDatabase.openOrCreateDatabase(path,null)) {
            JSONArray entities=schema.getJSONArray("entities");
            for(int i=0;i<entities.length();i++) {
                JSONObject entity=entities.getJSONObject(i);String table=entity.getString("tableName");
                old.execSQL(entity.getString("createSql").replace("${TABLE_NAME}",table));
                JSONArray indices=entity.optJSONArray("indices");
                if(indices!=null)for(int j=0;j<indices.length();j++)old.execSQL(indices.getJSONObject(j).getString("createSql").replace("${TABLE_NAME}",table));
                ContentValues values=new ContentValues();JSONArray fields=entity.getJSONArray("fields");
                for(int j=0;j<fields.length();j++) {
                    JSONObject field=fields.getJSONObject(j);String key=field.getString("columnName");
                    if(!field.optBoolean("notNull"))values.putNull(key);
                    else if(field.getString("affinity").equals("TEXT"))values.put(key,"fixture");else values.put(key,0);
                }
                switch(table) {
                    case "media"->{values.put("id","audio");values.put("uri","content://fixture/audio");values.put("root","root");values.put("name","campo.mp3");
                        values.put("mediaType","audio");values.put("title","Origen");values.put("userTitle","Personal");values.put("userTags","");
                        values.put("nfoDetails","{\"artists\":\"Ana\"}");values.put("position",7000);values.put("duration",90000);
                        values.put("favorite",1);values.put("watched",1);values.put("playCount",5);values.put("addedAt",123);}
                    case "roots"->{values.put("uri","root");values.put("generation",9);}
                    case "scan_queue"->{values.put("root","root");values.put("uri","content://fixture/pending");}
                    case "playlists"->{values.put("id","list");values.put("name","Mi lista");}
                    case "playlist_items"->{values.put("playlistId","list");values.put("mediaId","audio");values.put("position",2);}
                }
                old.insertOrThrow(table,null,values);
                if(table.equals("media")) {values.put("id","image");values.put("mediaType","image");old.insertOrThrow(table,null,values);}
            }
            JSONArray setup=schema.getJSONArray("setupQueries");for(int i=0;i<setup.length();i++)old.execSQL(setup.getString(i));old.setVersion(4);
        }
        LibraryDatabase migrated=Room.databaseBuilder(context,LibraryDatabase.class,name).addMigrations(LibraryDatabase.MIGRATION_4_5,LibraryDatabase.MIGRATION_5_6,LibraryDatabase.MIGRATION_6_7,LibraryDatabase.MIGRATION_7_8,LibraryDatabase.MIGRATION_8_9,LibraryDatabase.MIGRATION_9_10,LibraryDatabase.MIGRATION_10_11,LibraryDatabase.MIGRATION_11_12,LibraryDatabase.MIGRATION_12_13).allowMainThreadQueries().build();
        try {
            MediaEntry m=migrated.library().get("audio");assertEquals(MediaRules.AUDIO,m.mediaType);assertEquals("Personal",m.displayTitle());
            assertEquals("",m.displayTags());assertEquals("Ana",m.details().get("artists"));assertEquals(7000,m.position);
            assertEquals(90000,m.duration);assertTrue(m.favorite);assertTrue(m.watched);assertEquals(5,m.playCount);assertEquals(123,m.addedAt);
            assertEquals(MediaRules.IMAGE,migrated.library().get("image").mediaType);assertEquals(9,migrated.library().roots().get(0).generation);
            assertNotNull(migrated.library().next("root"));assertEquals("audio",migrated.library().playlistItems("list").get(0).mediaId);
            assertEquals(2,migrated.library().playlistItems("list").get(0).position);assertTrue(migrated.library().groups().isEmpty());
            String group=new GroupStore(migrated).create("Versiones");new GroupStore(migrated).add(group,"audio");assertEquals(1,migrated.library().groupItems().size());
            assertEquals(13,migrated.getOpenHelper().getReadableDatabase().getVersion());
        } finally {migrated.close();context.deleteDatabase(name);}
    }
}
