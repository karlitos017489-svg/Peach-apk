package com.peach.local;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import androidx.room.Room;
import java.nio.charset.StandardCharsets;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.SQLiteMode;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,manifest=Config.NONE)
@SQLiteMode(SQLiteMode.Mode.LEGACY)
public class MigrationV5Test {
    @Test public void exportedV5UpgradePreservesGroupsListsMediaAndScanThenAcceptsNewOrganization() throws Exception {
        var context=RuntimeEnvironment.getApplication();String name="migration-v5.db";context.deleteDatabase(name);
        var path=context.getDatabasePath(name);path.getParentFile().mkdirs();JSONObject schema;
        try(var in=getClass().getClassLoader().getResourceAsStream("com.peach.local.LibraryDatabase/5.json")){
            assertNotNull(in);schema=new JSONObject(new String(in.readAllBytes(),StandardCharsets.UTF_8)).getJSONObject("database");
        }
        try(SQLiteDatabase old=SQLiteDatabase.openOrCreateDatabase(path,null)) {
            JSONArray entities=schema.getJSONArray("entities");
            for(int i=0;i<entities.length();i++) {
                JSONObject entity=entities.getJSONObject(i);String table=entity.getString("tableName");
                old.execSQL(entity.getString("createSql").replace("${TABLE_NAME}",table));
                JSONArray indexes=entity.optJSONArray("indices");if(indexes!=null)for(int j=0;j<indexes.length();j++)old.execSQL(indexes.getJSONObject(j).getString("createSql").replace("${TABLE_NAME}",table));
                ContentValues values=new ContentValues();JSONArray fields=entity.getJSONArray("fields");
                for(int j=0;j<fields.length();j++) {
                    JSONObject f=fields.getJSONObject(j);String key=f.getString("columnName");
                    if(!f.optBoolean("notNull"))values.putNull(key);else if(f.getString("affinity").equals("TEXT"))values.put(key,"fixture");else values.put(key,0);
                }
                switch(table) {
                    case "media"->{values.put("id","a");values.put("root","root");values.put("uri","content://fixture/a");values.put("name","a.mp3");values.put("mediaType","audio");
                        values.put("userTitle","Personal");values.put("userTags","");values.put("position",7000);values.put("duration",90000);values.put("favorite",1);values.put("playCount",5);values.put("nfoDetails","{\"artists\":\"Ana\"}");}
                    case "roots"->{values.put("uri","root");values.put("generation",9);}
                    case "scan_queue"->{values.put("root","root");values.put("uri","content://fixture/pending");}
                    case "playlists"->{values.put("id","list");values.put("name","Lista");}
                    case "playlist_items"->{values.put("playlistId","list");values.put("mediaId","a");values.put("position",2);}
                    case "media_groups"->{values.put("id","group");values.put("name","Versiones");}
                    case "media_group_items"->{values.put("groupId","group");values.put("mediaId","a");}
                    default->throw new AssertionError(table);
                }
                old.insertOrThrow(table,null,values);
            }
            JSONArray setup=schema.getJSONArray("setupQueries");for(int i=0;i<setup.length();i++)old.execSQL(setup.getString(i));old.setVersion(5);
        }
        LibraryDatabase migrated=Room.databaseBuilder(context,LibraryDatabase.class,name).addMigrations(LibraryDatabase.MIGRATION_5_6,LibraryDatabase.MIGRATION_6_7,LibraryDatabase.MIGRATION_7_8,LibraryDatabase.MIGRATION_8_9,LibraryDatabase.MIGRATION_9_10,LibraryDatabase.MIGRATION_10_11,LibraryDatabase.MIGRATION_11_12,LibraryDatabase.MIGRATION_12_13).allowMainThreadQueries().build();
        try {
            MediaEntry m=migrated.library().get("a");assertEquals("Personal",m.displayTitle());assertEquals("",m.displayTags());assertEquals("audio",m.mediaType);assertEquals("Ana",m.details().get("artists"));
            assertEquals(7000,m.position);assertEquals(90000,m.duration);assertTrue(m.favorite);assertEquals(5,m.playCount);
            assertEquals(9,migrated.library().roots().get(0).generation);assertNotNull(migrated.library().next("root"));assertEquals(2,migrated.library().playlistItems("list").get(0).position);
            assertEquals("Versiones",migrated.library().group("group").name);assertEquals("a",migrated.library().groupItems("group").get(0).mediaId);
            assertTrue(migrated.library().entities().isEmpty());assertTrue(migrated.library().wants().isEmpty());
            String identity=new EntityStore(migrated).create("creator","Ana","");new EntityStore(migrated).alias(identity,"Alba");
            String want=new WantStore(migrated).create("Obra","CAM-1","",identity);new WantStore(migrated).attach(want,"a");assertEquals("a",migrated.library().want(want).mediaId);
            assertEquals(13,migrated.getOpenHelper().getReadableDatabase().getVersion());
        }finally{migrated.close();context.deleteDatabase(name);}
    }
}
