package com.peach.local;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import androidx.room.Room;
import java.nio.charset.StandardCharsets;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.SQLiteMode;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class MigrationV7Test {
    @Test public void exportedV7MigrationPreservesReadersAndAddsCatalogSnapshots() throws Exception {
        var context=RuntimeEnvironment.getApplication();String name="migration-v7.db";context.deleteDatabase(name);var path=context.getDatabasePath(name);path.getParentFile().mkdirs();JSONObject schema;
        try(var in=getClass().getClassLoader().getResourceAsStream("com.peach.local.LibraryDatabase/7.json")){assertNotNull(in);schema=new JSONObject(new String(in.readAllBytes(),StandardCharsets.UTF_8)).getJSONObject("database");}
        try(SQLiteDatabase old=SQLiteDatabase.openOrCreateDatabase(path,null)) {
            JSONArray tables=schema.getJSONArray("entities");
            for(int i=0;i<tables.length();i++) {
                JSONObject table=tables.getJSONObject(i);String key=table.getString("tableName");old.execSQL(table.getString("createSql").replace("${TABLE_NAME}",key));
                JSONArray indexes=table.optJSONArray("indices");if(indexes!=null)for(int j=0;j<indexes.length();j++)old.execSQL(indexes.getJSONObject(j).getString("createSql").replace("${TABLE_NAME}",key));
                ContentValues values=new ContentValues();JSONArray fields=table.getJSONArray("fields");
                for(int j=0;j<fields.length();j++){JSONObject field=fields.getJSONObject(j);String column=field.getString("columnName");if(!field.optBoolean("notNull"))values.putNull(column);else if(field.getString("affinity").equals("TEXT"))values.put(column,"");else values.put(column,0);}
                switch(key) {
                    case "media"->{values.put("id","a");values.put("root","root");values.put("uri","content://fixture/a");values.put("name","a.pdf");values.put("mediaType","other");values.put("userTitle","Personal");values.put("position",7000);values.put("favorite",1);values.put("nfoDetails","{}");}
                    case "roots"->{values.put("uri","root");values.put("generation",9);}
                    case "scan_queue"->{values.put("root","root");values.put("uri","content://fixture/pending");}
                    case "playlists"->{values.put("id","list");values.put("name","Lista");}
                    case "playlist_items"->{values.put("playlistId","list");values.put("mediaId","a");values.put("position",2);}
                    case "media_groups"->{values.put("id","group");values.put("name","Versiones");}
                    case "media_group_items"->{values.put("groupId","group");values.put("mediaId","a");}
                    case "catalog_entities"->{values.put("id","entity");values.put("kind","performer");values.put("name","Ana");values.put("favorite",1);}
                    case "entity_aliases"->{values.put("entityId","entity");values.put("name","Alba");}
                    case "media_entity_links"->{values.put("entityId","entity");values.put("mediaId","a");values.put("role","performer");}
                    case "entity_references"->{values.put("entityId","entity");values.put("provider","P");values.put("externalId","123");}
                    case "reader_progress"->{values.put("mediaId","a");values.put("entry","chapter.pdf");values.put("page",2);values.put("scroll",40);values.put("updatedAt",123);}
                    case "want_items"->{values.put("id","want");values.put("title","Deseo");values.put("entityId","entity");values.put("mediaId","a");}
                    default->throw new AssertionError(key);
                }
                old.insertOrThrow(key,null,values);
            }
            JSONArray setup=schema.getJSONArray("setupQueries");for(int i=0;i<setup.length();i++)old.execSQL(setup.getString(i));old.setVersion(7);
        }
        LibraryDatabase migrated=Room.databaseBuilder(context,LibraryDatabase.class,name).addMigrations(LibraryDatabase.MIGRATION_7_8,LibraryDatabase.MIGRATION_8_9,LibraryDatabase.MIGRATION_9_10,LibraryDatabase.MIGRATION_10_11,LibraryDatabase.MIGRATION_11_12,LibraryDatabase.MIGRATION_12_13).allowMainThreadQueries().build();
        try {
            assertEquals(13,migrated.getOpenHelper().getReadableDatabase().getVersion());assertEquals("Personal",migrated.library().get("a").displayTitle());assertEquals(7000,migrated.library().get("a").position);assertTrue(migrated.library().get("a").favorite);
            assertEquals(9,migrated.library().roots().get(0).generation);assertNotNull(migrated.library().next("root"));assertEquals(2,migrated.library().playlistItems("list").get(0).position);assertEquals("a",migrated.library().groupItems("group").get(0).mediaId);
            assertTrue(migrated.library().entity("entity").favorite);assertEquals("Alba",migrated.library().aliases().get(0).name);assertEquals(1,migrated.library().entityLinks().size());assertEquals("123",migrated.library().entityReferences().get(0).externalId);assertEquals("a",migrated.library().want("want").mediaId);
            assertEquals(2,migrated.library().readerProgress("a").page);assertEquals("chapter.pdf",migrated.library().readerProgress("a").entry);assertTrue(migrated.library().snapshots().isEmpty());ReaderProgress p=new ReaderProgress();p.mediaId="a";p.page=3;ReaderStore.save(migrated,p);assertEquals(3,migrated.library().readerProgress("a").page);assertEquals(7000,migrated.library().get("a").position);
        }finally{migrated.close();context.deleteDatabase(name);}
    }
}
