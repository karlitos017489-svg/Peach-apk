package com.peach.local;

import java.io.File;
import java.nio.file.Files;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import org.junit.*;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

/** Real JNI Linux budgets, with concurrent success/failure and worker-thread reuse. */
public class Native470Test {
    @Rule public TemporaryFolder temp=new TemporaryFolder();
    @BeforeClass public static void load(){RarNativeTest.load();}
    @Test public void concurrentDecodesKeepPerThreadLimitsAndClearFailureBeforeThreadReuse()throws Exception {
        File large=temp.newFile();Files.write(large.toPath(),RarNativeTest.fixture("budget-rar5.cbr"));
        byte[] big="Peach: estratos sedimentarios y minerales.\n".repeat(100000).getBytes(StandardCharsets.UTF_8);ExecutorService workers=Executors.newFixedThreadPool(2);RarNativeTest decoder=new RarNativeTest();
        try{for(int round=0;round<8;round++){
            File smallOut=temp.newFile(),goodOut=temp.newFile();CountDownLatch ready=new CountDownLatch(2),start=new CountDownLatch(1);
            Future<long[]> small=workers.submit(()->{ready.countDown();assertTrue(start.await(10,TimeUnit.SECONDS));return decoder.decode(large,smallOut,"large.txt",big,1024*1024);});
            Future<long[]> good=workers.submit(()->{ready.countDown();assertTrue(start.await(10,TimeUnit.SECONDS));return decoder.decode(large,goodOut,"large.txt",big,RarNative.MAX_HEAP);});
            try{assertTrue(ready.await(10,TimeUnit.SECONDS));}finally{start.countDown();}
            long[] failed=small.get(30,TimeUnit.SECONDS),passed=good.get(30,TimeUnit.SECONDS);assertEquals(4,failed[0]);assertTrue(failed[1]<=1024*1024);assertEquals(0,failed[2]);assertEquals(0,passed[0]);assertTrue(passed[1]>1024*1024);assertEquals(0,passed[2]);assertArrayEquals(big,Files.readAllBytes(goodOut.toPath()));
        }}finally{workers.shutdownNow();assertTrue(workers.awaitTermination(30,TimeUnit.SECONDS));}
    }
}
