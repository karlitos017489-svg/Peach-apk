package com.peach.local;

import java.util.Map;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,manifest=Config.NONE)
public class NfoDetailsTest {
    @Test public void knownFieldsRoundTripWithoutUnknownOrEmptyFields() {
        var fields=NfoDetails.decode(NfoDetails.encode(Map.of("directors","Ana \"A\"","code","CAM-2","collection","","unknown","omitir")));
        assertEquals(2,fields.size());assertEquals("Ana \"A\"",fields.get("directors"));assertEquals("CAM-2",fields.get("code"));
        assertTrue(NfoDetails.decode("not-json").isEmpty());assertTrue(NfoDetails.decode("{\"directors\":3,\"code\":null}").isEmpty());
    }
    @Test public void extendedSearchFindsImportedFieldsAndInvalidatesCacheOnRescan() {
        MediaEntry m=new MediaEntry();m.title="Origen";m.userTitle="Personal";
        m.nfoDetails=NfoDetails.encode(Map.of("directors","ANA","collection","Expediciones","code","CAM-2","originalTitle","Field"));
        assertTrue(MediaRules.matches(m,"ana",0));assertTrue(MediaRules.matches(m,"Expediciones",0));
        assertTrue(MediaRules.matches(m,"CAM-2",0));assertTrue(MediaRules.matches(m,"field",0));
        assertFalse(MediaRules.matches(m,"ana",1));
        m.nfoDetails="{}";assertFalse(MediaRules.matches(m,"ana",0));assertTrue(MediaRules.matches(m,"personal",0));
    }
    @Test public void nativeFactsKeepNfoRuntimeSeparateAndExplainOverrides() {
        MediaEntry m=new MediaEntry();m.title="Origen";m.userTitle="Personal";m.tags="NFO";m.userTags="";
        m.name="campo.mp4";m.duration=120000;m.position=65000;
        m.nfoDetails=NfoDetails.encode(Map.of("runtimeMinutes","90","directors","Ana"));
        String text=MediaDetailsView.describe(m,"10 MB").toString();
        assertTrue(text.contains("Título\nPersonal"));assertTrue(text.contains("Título de origen\nOrigen"));
        assertTrue(text.contains("Etiquetas de origen\nNFO"));assertTrue(text.contains("Duración NFO (minutos)\n90"));
        assertTrue(text.contains("Duración de reproducción\n2:00"));assertTrue(text.contains("Continuar desde\n1:05"));
        assertTrue(text.contains("Dirección\nAna"));
    }
    @Test public void personalTitleAndEmptyTagsRemainEffectiveForSearch() {
        MediaEntry m=new MediaEntry();m.title="Nombre importado";m.userTitle="Nombre personal";m.tags="Etiqueta importada";m.userTags="";
        assertFalse(MediaRules.matches(m,"Nombre importado",0));assertFalse(MediaRules.matches(m,"Etiqueta importada",0));
        assertTrue(MediaRules.matches(m,"Nombre personal",0));
    }
}
