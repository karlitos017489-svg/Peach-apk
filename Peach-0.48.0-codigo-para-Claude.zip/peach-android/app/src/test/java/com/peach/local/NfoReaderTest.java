package com.peach.local;

import org.junit.Test;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import static org.junit.Assert.*;

public class NfoReaderTest {
    private NfoReader.Metadata parse(String text) throws Exception {
        return NfoReader.read(new ByteArrayInputStream(text.getBytes(StandardCharsets.UTF_8)));
    }
    @Test public void importsTitleActorsAndDeduplicatesTags() throws Exception {
        var m=parse("<movie><title>Exploración &amp; campo</title><year>2026</year><studio>Local</studio>"+
            "<actor><name>Ana</name></actor><genre>Geología</genre><tag>Geología</tag><tag>Campo</tag></movie>");
        assertEquals("Exploración & campo",m.title()); assertEquals("2026",m.year());
        assertEquals("Local",m.studio()); assertEquals("Ana",m.actors());
        assertTrue(m.tags().contains("Geología")); assertTrue(m.tags().contains("Campo"));
        assertEquals(2,m.tags().split(", ").length);
    }
    @Test public void acceptsEpisodeWithoutOptionalFields() throws Exception {
        var m=parse("<episodedetails><title>Capítulo</title></episodedetails>");
        assertEquals("Capítulo",m.title()); assertEquals("",m.studio());
    }
    @Test(expected=java.io.IOException.class) public void rejectsExternalEntity() throws Exception {
        parse("<!DOCTYPE movie [<!ENTITY x SYSTEM 'file:///etc/passwd'>]><movie><title>&x;</title></movie>");
    }
    @Test(expected=java.io.IOException.class) public void rejectsUtf16EntityDeclaration() throws Exception {
        String xml="<?xml version='1.0' encoding='UTF-16'?><!DOCTYPE movie><movie/>";
        NfoReader.read(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_16)));
    }
    @Test(expected=java.io.IOException.class) public void rejectsOversizeInput() throws Exception {
        NfoReader.read(new ByteArrayInputStream(new byte[NfoReader.MAX_BYTES+1]));
    }
    @Test(expected=Exception.class) public void rejectsMalformedXml() throws Exception { parse("<movie><title>"); }
    @Test(expected=java.io.IOException.class) public void rejectsUnknownRoot() throws Exception { parse("<html/>"); }
    @Test public void ignoresRemoteArtWithoutNetwork() throws Exception {
        assertEquals("Local",parse("<movie><title>Local</title><thumb>https://example.invalid/p.jpg</thumb></movie>").title());
    }
    @Test public void importsExtendedMovieFieldsAndRepeatedCredits() throws Exception {
        var m=parse("<movie><title>Campo</title><originaltitle>Field</originaltitle><tagline>Una ruta</tagline>"+
            "<director>Ana</director><director>Luis</director><director>Ana</director><credits>María</credits>"+
            "<country>México</country><country>Chile</country><genre>Documental</genre><studio>A</studio><studio>B</studio>"+
            "<premiered>2026-10-24</premiered><runtime>90.50</runtime><mpaa>PG</mpaa>"+
            "<set><name>Expediciones</name><overview>No es el nombre</overview></set>"+
            "<num>CAM-001</num><uniqueid type='tmdb'>123</uniqueid><uniqueid type='home'>CAM-001</uniqueid></movie>");
        assertEquals("2026",m.year());assertEquals("A, B",m.studio());
        var d=m.details();assertEquals("Field",d.get("originalTitle"));assertEquals("Una ruta",d.get("tagline"));
        assertEquals("Ana, Luis",d.get("directors"));assertEquals("María",d.get("writers"));
        assertEquals("México, Chile",d.get("countries"));assertEquals("Documental",d.get("genres"));
        assertEquals("90.5",d.get("runtimeMinutes"));assertEquals("PG",d.get("contentRating"));
        assertEquals("Expediciones",d.get("collection"));assertEquals("CAM-001",d.get("code"));
        assertEquals("tmdb: 123, home: CAM-001",d.get("identifiers"));
    }
    @Test public void importsEpisodeSeasonZeroAndMusicalArtists() throws Exception {
        var episode=parse("<episodedetails><showtitle>Serie</showtitle><season>0</season><episode>02</episode><aired>2025-01-02</aired></episodedetails>");
        assertEquals("Episodio",episode.details().get("kind"));assertEquals("Serie",episode.details().get("series"));
        assertEquals("0",episode.details().get("season"));assertEquals("2",episode.details().get("episode"));assertEquals("2025",episode.year());
        var music=parse("<musicvideo><artist>Ana</artist><artist>Luis</artist><artist>Ana</artist></musicvideo>");
        assertEquals("Ana, Luis",music.details().get("artists"));assertEquals("Video musical",music.details().get("kind"));
    }
    @Test public void doesNotMistakeNestedFieldsForMovieFields() throws Exception {
        var m=parse("<movie><actor><name>Actor</name><role>Guía</role><title>No es el título</title><genre>No es género</genre></actor>"+
            "<set><name>Colección</name><plot>No es sinopsis</plot></set></movie>");
        assertEquals("",m.title());assertEquals("",m.plot());assertEquals("",m.tags());assertEquals("Actor",m.actors());
        assertEquals("Actor — Guía",m.details().get("actorRoles"));
    }
    @Test public void supportsLegacyNamesDatesAndCollections() throws Exception {
        var m=parse("<movie><localtitle>Local</localtitle><outline>Breve</outline><releasedate>2024-03-01</releasedate>"+
            "<set>Colección antigua</set><id>CASA-1</id><rating>7.20</rating></movie>");
        assertEquals("Local",m.title());assertEquals("Breve",m.plot());assertEquals("2024",m.year());
        assertEquals("Colección antigua",m.details().get("collection"));assertEquals("ID: CASA-1",m.details().get("identifiers"));
        assertEquals("7.2 / 10",m.details().get("rating"));
    }
    @Test public void prefersValidDefaultRatingWithoutImportingPersonalState() throws Exception {
        var m=parse("<movie><ratings><rating name='first' max='100'><value>70</value></rating>"+
            "<rating name='imdb' max='10' default='true'><value>8.4</value></rating></ratings>"+
            "<rating>2</rating><userrating>1</userrating><playcount>999</playcount><watched>true</watched></movie>");
        assertEquals("8.4 / 10 (imdb)",m.details().get("rating"));
        assertFalse(m.details().containsKey("playcount"));assertFalse(m.details().containsKey("watched"));
    }
    @Test public void ignoresInvalidNumbersAndFallsBackToValidRating() throws Exception {
        var m=parse("<movie><runtime>1e-99999999</runtime><season>-1</season><episode>999999999999</episode>"+
            "<ratings><rating default='true' max='10'><value>NaN</value></rating>"+
            "<rating max='5'><value>6</value></rating><rating max='5'><value>0</value></rating></ratings></movie>");
        assertFalse(m.details().containsKey("runtimeMinutes"));assertFalse(m.details().containsKey("season"));
        assertFalse(m.details().containsKey("episode"));assertEquals("0 / 5",m.details().get("rating"));
    }
    @Test public void capsOptionalFieldsAndDoesNotKeepArtOrTrailerUrls() throws Exception {
        var m=parse("<movie><originaltitle>"+"x".repeat(20000)+"</originaltitle><thumb>https://example.invalid/x</thumb>"+
            "<trailer>https://example.invalid/t</trailer></movie>");
        assertTrue(m.details().get("originalTitle").length()<17000);
        assertFalse(m.details().values().stream().anyMatch(v->v.contains("https://")));
    }
    @Test public void acceptsUtf16MetadataWithoutDeclarations() throws Exception {
        var m=NfoReader.read(new ByteArrayInputStream("<?xml version='1.0' encoding='UTF-16'?><movie><director>Ana</director></movie>".getBytes(StandardCharsets.UTF_16)));
        assertEquals("Ana",m.details().get("directors"));
    }
    @Test public void deliveredNfoExampleHasSearchableMetadata() throws Exception {
        try (var input=getClass().getClassLoader().getResourceAsStream("nfo/Ruta-de-campo.nfo")) {
            assertNotNull(input);var m=NfoReader.read(input);
            assertEquals("Ruta de campo de prueba",m.title());assertEquals("2026",m.year());
            assertEquals("Ana Ejemplo",m.details().get("directors"));assertEquals("Expediciones",m.details().get("collection"));
            assertEquals("CAM-001",m.details().get("code"));assertEquals("8.5 / 10 (ejemplo)",m.details().get("rating"));
        }
    }
}
