package com.peach.local;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE)
public class NfoWriterTest {
 byte[] bytes(String s){return s.getBytes(StandardCharsets.UTF_8);}
 @Test public void commonFieldsAndUserOverridesRoundTripEscapingAndUnicode()throws Exception{MediaEntry m=new MediaEntry();m.title="old";m.userTitle="Geología <ñ> & 🪨";m.userTags="mineral, campo";m.plot="Estratos & capas";m.year="2026";m.studio="Own studio";var n=NfoReader.read(new ByteArrayInputStream(NfoWriter.encode(m)));assertEquals(m.userTitle,n.title());assertEquals(m.plot,n.plot());assertEquals(Set.of("mineral","campo"),new HashSet<>(n.terms().get("tags")));assertEquals("2026",n.year());}
 @Test public void unknownNodesRatingsIdentifiersAndUnchangedActorRolesArePreserved()throws Exception{byte[] old=bytes("<movie><title>Old</title><actor><name>Rivera, Ana</name><role>Own role</role><thumb>local-reference</thumb></actor><uniqueid type='own'>ID1</uniqueid><rating>7</rating><custom key='own'>keep</custom></movie>");var metadata=NfoReader.read(new ByteArrayInputStream(old));MediaEntry m=new MediaEntry();m.title="New";m.actors=metadata.actors();m.nfoDetails=NfoDetails.encode(metadata.details(),metadata.terms());byte[] merged=NfoWriter.merge(old,NfoWriter.encode(m));String s=new String(merged,StandardCharsets.UTF_8);assertTrue(s.contains("Own role"));assertTrue(s.contains("local-reference"));assertTrue(s.contains("ID1"));assertTrue(s.contains("keep"));assertEquals("New",NfoReader.read(new ByteArrayInputStream(merged)).title());}
 @Test public void noPlaybackPreferencesOrTokensAreSerialized()throws Exception{MediaEntry m=new MediaEntry();m.title="Own";m.favorite=true;m.position=999;m.playCount=8;m.uri="content://private-location";m.catalogMetadata="[]";String xml=new String(NfoWriter.encode(m),StandardCharsets.UTF_8);for(String s:List.of("favorite","position","playCount","private-location","Cookie","token"))assertFalse(xml.contains(s));}
 @Test public void entityDeclarationsAndDifferentNfoKindsDoNotGetOverwritten()throws Exception{byte[] fresh=NfoWriter.encode(new MediaEntry());for(String old:List.of("<!DOCTYPE a [<!ENTITY x SYSTEM 'file:///private'>]><movie/>","<episodedetails><title>Own</title></episodedetails>"))try{NfoWriter.merge(bytes(old),fresh);fail();}catch(Exception expected){}}
 @Test public void invalidXmlCharactersAndOversizedFieldsRejectBeforeWriting()throws Exception{for(String s:List.of("own\u0000title","own\ud800title","a".repeat(16385))){MediaEntry m=new MediaEntry();m.title=s;try{NfoWriter.encode(m);fail();}catch(IOException expected){}}}
 @Test public void episodeAndCodeFieldsRemainUsableByReader()throws Exception{MediaEntry m=new MediaEntry();m.title="Own episode";m.nfoDetails=NfoDetails.encode(Map.of("kind","Episodio","code","OWN-123","series","Own series","season","1","episode","2"));var n=NfoReader.read(new ByteArrayInputStream(NfoWriter.encode(m)));assertEquals("Episodio",n.details().get("kind"));assertEquals("OWN-123",n.details().get("code"));assertEquals("2",n.details().get("episode"));}
}
