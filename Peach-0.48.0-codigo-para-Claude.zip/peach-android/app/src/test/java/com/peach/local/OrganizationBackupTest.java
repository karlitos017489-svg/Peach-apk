package com.peach.local;

import androidx.room.Room;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.SQLiteMode;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,manifest=Config.NONE)
@SQLiteMode(SQLiteMode.Mode.LEGACY)
public class OrganizationBackupTest {
    private LibraryDatabase db;private EntityStore store;private String identity,want;
    @Before public void open(){
        db=Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().build();store=new EntityStore(db);
        MediaEntry m=new MediaEntry();m.id="a";m.root="root";m.title="Campo";db.library().insertMedia(m);db.library().progress("a",7000,90000,1,false);
        identity=store.create("performer","Ana","Nota");store.alias(identity,"Alba");store.link(identity,"a","performer");store.reference(identity,"P","123","https://example.org/123");
        db.library().favoriteEntity(identity);want=new WantStore(db).create("Obra deseada","CAM-1","Nota",identity);new WantStore(db).attach(want,"a");
    }
    @After public void close(){db.close();}
    private JSONObject export() throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();BackupStore.write(db.library(),out);return new JSONObject(out.toString("UTF-8"));}
    private void restore(JSONObject backup) throws Exception{BackupStore.read(db,new ByteArrayInputStream(backup.toString().getBytes(StandardCharsets.UTF_8)));}
    private void rejects(JSONObject backup) throws Exception{try{restore(backup);fail("Expected invalid backup");}catch(IllegalArgumentException expected){}}
    @Test public void v4RoundTripRestoresStableIdentitiesAliasesReferencesLinksFavoritesAndWants() throws Exception {
        JSONObject backup=export();assertEquals(19,backup.getInt("version"));
        db.library().deleteEntity(identity);db.library().deleteWant(want);
        for(int i=0;i<2;i++)restore(backup);
        assertEquals(1,db.library().entities().size());assertEquals("Ana",db.library().entity(identity).name);assertTrue(db.library().entity(identity).favorite);
        assertEquals("Alba",db.library().aliases().get(0).name);assertEquals(1,db.library().entityLinks().size());assertEquals(1,db.library().entityReferences().size());
        assertEquals(identity,db.library().want(want).entityId);assertEquals("a",db.library().want(want).mediaId);assertEquals(7000,db.library().get("a").position);
    }
    @Test public void olderV3StateLeavesIdentitiesReferencesLinksAndWantsUnchanged() throws Exception {
        JSONObject backup=export();backup.put("version",3);for(String key:java.util.List.of("entities","aliases","entityLinks","entityReferences","wants"))backup.remove(key);
        restore(backup);assertNotNull(db.library().entity(identity));assertEquals(1,db.library().entityLinks().size());assertNotNull(db.library().want(want));
    }
    @Test public void collisionWithIdentityOutsideBackupRollsBackAllPersonalState() throws Exception {
        JSONObject backup=export();String other=store.create("performer","Sol","");
        backup.getJSONArray("items").getJSONObject(0).put("favorite",true);
        backup.getJSONArray("aliases").getJSONObject(0).put("name","Sol");rejects(backup);
        assertFalse(db.library().get("a").favorite);assertEquals("Alba",db.library().aliases().get(0).name);assertNotNull(db.library().entity(other));
    }
    @Test public void invalidRoleOrReferenceRejectsTheWholeImport() throws Exception {
        JSONObject backup=export();backup.getJSONArray("entityLinks").getJSONObject(0).put("role","studio");rejects(backup);
        assertEquals("performer",db.library().entityLinks().get(0).role);
        backup=export();backup.getJSONArray("entityReferences").getJSONObject(0).put("url","file:///private/test");rejects(backup);
        assertEquals("https://example.org/123",db.library().entityReferences().get(0).url);
    }
    @Test public void absentDocumentsAreSkippedWhileDesiredWorksAndIdentitiesSurvive() throws Exception {
        JSONObject backup=export();db.library().forgetMedia("root");restore(backup);
        assertTrue(db.library().allMedia().isEmpty());assertTrue(db.library().entityLinks().isEmpty());assertNotNull(db.library().entity(identity));
        assertEquals(identity,db.library().want(want).entityId);assertNull(db.library().want(want).mediaId);assertEquals("CAM-1",db.library().want(want).code);
    }
    @Test public void authoritativeNamesCanBeSwappedByStableIdAndOtherWantsRemain() throws Exception {
        String other=store.create("performer","Sol","");JSONObject backup=export();
        JSONArray entities=backup.getJSONArray("entities");
        for(int i=0;i<entities.length();i++){JSONObject e=entities.getJSONObject(i);e.put("name",e.getString("id").equals(identity)?"Sol":"Ana");}
        String unrelated=new WantStore(db).create("Conservar","","",null);restore(backup);
        assertEquals("Sol",db.library().entity(identity).name);assertEquals("Ana",db.library().entity(other).name);assertNotNull(db.library().want(unrelated));
    }
    @Test public void malformedCollectionsDuplicateIdsAndUnknownEntityReferencesAreRejected() throws Exception {
        JSONObject backup=export();backup.put("aliases",JSONObject.NULL);rejects(backup);
        backup=export();backup.getJSONArray("entities").put(backup.getJSONArray("entities").getJSONObject(0));rejects(backup);
        backup=export();backup.getJSONArray("wants").getJSONObject(0).put("entityId","unknown");rejects(backup);
        assertEquals(1,db.library().entities().size());assertEquals(1,db.library().wants().size());assertEquals(1,db.library().entityLinks().size());
    }
    @Test public void longSafDocumentIdentityRoundTripsWithoutTruncation() throws Exception {
        String longId="content://fixture/document/"+"carpeta%2F".repeat(180)+"a.mp4";
        MediaEntry m=new MediaEntry();m.id=longId;m.title="Largo";db.library().insertMedia(m);store.link(identity,longId,"performer");new WantStore(db).attach(want,longId);
        JSONObject backup=export();db.library().clearEntityLinks(identity);new WantStore(db).attach(want,null);restore(backup);
        assertEquals(longId,db.library().want(want).mediaId);assertTrue(db.library().entityLinks().stream().anyMatch(l->l.mediaId.equals(longId)));
    }
    @Test public void fractionalTextAndUnknownBackupVersionsAreRejectedWithoutWriting() throws Exception {
        for(Object version:java.util.List.of(19.5,"19",0,20)) {
            JSONObject backup=export();backup.put("version",version);backup.getJSONArray("items").getJSONObject(0).put("favorite",true);rejects(backup);
            assertFalse(db.library().get("a").favorite);assertEquals(1,db.library().entities().size());
        }
    }
}
