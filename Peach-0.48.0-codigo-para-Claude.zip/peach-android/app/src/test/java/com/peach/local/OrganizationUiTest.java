package com.peach.local;

import android.content.Intent;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import androidx.appcompat.app.AlertDialog;
import java.util.concurrent.TimeUnit;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.Shadows;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.SQLiteMode;
import org.robolectric.shadows.ShadowDialog;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,qualifiers="w1280dp-h800dp-land")
@SQLiteMode(SQLiteMode.Mode.LEGACY)
public class OrganizationUiTest {
    private LibraryDatabase db;
    @Before public void open(){
        var context=RuntimeEnvironment.getApplication();db=androidx.room.Room.inMemoryDatabaseBuilder(context,LibraryDatabase.class).allowMainThreadQueries()
            .setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();
        org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",db);
        androidx.work.testing.WorkManagerTestInitHelper.initializeTestWorkManager(context,new androidx.work.Configuration.Builder().setExecutor(Runnable::run).setTaskExecutor(Runnable::run).build());
    }
    @After public void close() throws Exception{settle();androidx.work.testing.WorkManagerTestInitHelper.closeWorkDatabase();db.close();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);}
    private void settle() throws Exception{for(int i=0;i<3;i++){LibraryDatabase.IO.submit(()->{}).get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}}
    private void awaitGrid(MainActivity activity,int expected)throws Exception{long until=System.nanoTime()+TimeUnit.SECONDS.toNanos(10);do{settle();if(((androidx.recyclerview.widget.RecyclerView)activity.findViewById(R.id.grid)).getAdapter().getItemCount()==expected)return;Thread.sleep(10);}while(System.nanoTime()<until);}
    private void idle(){Shadows.shadowOf(Looper.getMainLooper()).idle();}
    private AlertDialog dialog(){idle();return (AlertDialog)ShadowDialog.getLatestDialog();}
    private void positive(){dialog().getButton(AlertDialog.BUTTON_POSITIVE).performClick();idle();}
    private void neutral(){dialog().getButton(AlertDialog.BUTTON_NEUTRAL).performClick();idle();}
    private EditText field(View view,String label){
        if(view instanceof EditText edit && label.contentEquals(edit.getContentDescription()))return edit;
        if(view instanceof ViewGroup group)for(int i=0;i<group.getChildCount();i++){var found=field(group.getChildAt(i),label);if(found!=null)return found;}return null;
    }
    private void input(String label,String value){EditText input=field(dialog().getWindow().getDecorView(),label);assertNotNull(label,input);input.setText(value);}
    private ListView customList(View view){if(view instanceof ListView list)return list;if(view instanceof ViewGroup group)for(int i=0;i<group.getChildCount();i++){var found=customList(group.getChildAt(i));if(found!=null)return found;}return null;}
    private String visibleText(View view){if(view instanceof android.widget.TextView text)return text.getText().toString();StringBuilder result=new StringBuilder();if(view instanceof ViewGroup group)for(int i=0;i<group.getChildCount();i++)result.append(visibleText(group.getChildAt(i))).append('\n');return result.toString();}
    private void media(String id,String actor){MediaEntry m=new MediaEntry();m.id=id;m.name=id+".mp4";m.title=id;m.actors=actor;db.library().insertMedia(m);}
    @Test public void createsIdentityAddsAliasAndSearchesByAliasThroughVisibleControls() throws Exception {
        try(var controller=Robolectric.buildActivity(OrganizationActivity.class).setup().visible()) {
            settle();OrganizationActivity activity=controller.get();activity.findViewById(R.id.organizationCreate).performClick();
            input("Nombre principal","Ana");input("Notas","Ficha propia");positive();settle();assertEquals(1,db.library().entities().size());
            ((ListView)activity.findViewById(R.id.organizationList)).performItemClick(null,0,0);neutral();dialog().getListView().performItemClick(null,2,2);idle();
            input("Alias exacto","Alba");positive();settle();assertEquals("Alba",db.library().aliases().get(0).name);
            dialog().getButton(AlertDialog.BUTTON_NEGATIVE).performClick();idle();((EditText)activity.findViewById(R.id.organizationSearch)).setText("Alba");
            assertEquals(1,((ListView)activity.findViewById(R.id.organizationList)).getAdapter().getCount());controller.recreate();settle();
            assertEquals("Alba",((EditText)controller.get().findViewById(R.id.organizationSearch)).getText().toString());
        }
    }
    @Test public void createsDesiredWorkWithoutMediaThenLinksExistingFileAndRestoresSection() throws Exception {
        media("a","");Intent intent=new Intent(RuntimeEnvironment.getApplication(),OrganizationActivity.class).putExtra("section",1);
        try(var controller=Robolectric.buildActivity(OrganizationActivity.class,intent).setup().visible()) {
            settle();var activity=controller.get();activity.findViewById(R.id.organizationCreate).performClick();input("Título de la obra","Campo");input("Código (opcional)","CAM-1");input("Notas","Buscar después");positive();settle();
            assertEquals(1,db.library().wants().size());assertNull(db.library().wants().get(0).mediaId);
            ((ListView)activity.findViewById(R.id.organizationList)).performItemClick(null,0,0);positive();dialog().getListView().performItemClick(null,1,1);idle();
            customList(dialog().getWindow().getDecorView()).performItemClick(null,0,0);idle();settle();assertEquals("a",db.library().wants().get(0).mediaId);
            controller.recreate();settle();assertEquals(1,((Spinner)controller.get().findViewById(R.id.organizationSection)).getSelectedItemPosition());
            ((EditText)controller.get().findViewById(R.id.organizationSearch)).setText("CAM-1");assertEquals(1,((ListView)controller.get().findViewById(R.id.organizationList)).getAdapter().getCount());
        }
    }
    @Test public void profileShowsImportedAndManualProvenanceAndOpensPersistentLibraryScope() throws Exception {
        media("a","Ana");media("b","Anabel");String id=new EntityStore(db).create("performer","Ana","");new EntityStore(db).link(id,"a","performer");
        Intent intent;
        try(var controller=Robolectric.buildActivity(OrganizationActivity.class).setup().visible()) {
            settle();var activity=controller.get();((ListView)activity.findViewById(R.id.organizationList)).performItemClick(null,0,0);
            String text=visibleText(dialog().getWindow().getDecorView());assertTrue(text.contains("Metadatos NFO"));assertTrue(text.contains("Vínculo manual"));assertTrue(text.contains("Archivos relacionados: 1"));
            positive();intent=Shadows.shadowOf(activity).getNextStartedActivity();assertNotNull(intent);assertEquals(id,intent.getStringExtra("entityId"));
        }
        try(var controller=Robolectric.buildActivity(MainActivity.class,intent).setup().visible()) {
            settle();var activity=controller.get();awaitGrid(activity,1);var grid=(androidx.recyclerview.widget.RecyclerView)activity.findViewById(R.id.grid);assertEquals(1,grid.getAdapter().getItemCount());
            grid.measure(View.MeasureSpec.makeMeasureSpec(1000,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(600,View.MeasureSpec.EXACTLY));grid.layout(0,0,1000,600);
            grid.findViewById(R.id.details_button).performClick();positive();Intent play=Shadows.shadowOf(activity).getNextStartedActivity();assertEquals(id,play.getStringExtra("entityId"));
            controller.recreate();settle();awaitGrid(controller.get(),1);assertEquals(1,((androidx.recyclerview.widget.RecyclerView)controller.get().findViewById(R.id.grid)).getAdapter().getItemCount());
        }
    }
    @Test public void targetFileFlowChoosesRoleAndCreatesOnlyAnExplicitLink() throws Exception {
        media("a","");String id=new EntityStore(db).create("creator","Ana","");
        Intent intent=new Intent(RuntimeEnvironment.getApplication(),OrganizationActivity.class).putExtra("targetMediaId","a");
        try(var controller=Robolectric.buildActivity(OrganizationActivity.class,intent).setup().visible()) {
            settle();var activity=controller.get();((ListView)activity.findViewById(R.id.organizationList)).performItemClick(null,0,0);idle();
            customList(dialog().getWindow().getDecorView()).performItemClick(null,1,1);idle();settle();
            assertEquals(1,db.library().entityLinks().size());assertEquals(id,db.library().entityLinks().get(0).entityId);assertEquals("director",db.library().entityLinks().get(0).role);assertTrue(activity.isFinishing());
        }
    }
    @Test public void referenceFormStoresIdentifierWithoutLaunchingBrowserOrNetworkClient() throws Exception {
        new EntityStore(db).create("performer","Ana","");
        try(var controller=Robolectric.buildActivity(OrganizationActivity.class).setup().visible()) {
            settle();var activity=controller.get();((ListView)activity.findViewById(R.id.organizationList)).performItemClick(null,0,0);neutral();dialog().getListView().performItemClick(null,6,6);idle();positive();
            input("Proveedor","Ejemplo");input("Identificador externo","123");input("URL HTTPS (opcional)","https://example.org/123");positive();settle();
            assertEquals(1,db.library().entityReferences().size());assertNull(Shadows.shadowOf(activity).getNextStartedActivity());
        }
    }
}
