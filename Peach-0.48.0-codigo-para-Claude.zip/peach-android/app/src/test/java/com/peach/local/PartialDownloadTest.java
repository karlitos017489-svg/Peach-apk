package com.peach.local;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import org.junit.*;
import static org.junit.Assert.*;

/** Production HTTPS/range machine, completely simulated connections and own bytes. */
public class PartialDownloadTest {
    static final String URL="https://downloads.fanbox.cc/own-queue.bin";
    static class Crash extends Error {}
    static class Reply extends RedirectHttpTest.Reply {
        final Map<String,String> headers=new TreeMap<>(String.CASE_INSENSITIVE_ORDER);long crashAt=-1;
        Reply(String url,int status,byte[] bytes,String etag)throws Exception{super(url,status,null,bytes);mime="application/octet-stream";if(etag!=null)headers.put("ETag",etag);}
        @Override public String getHeaderField(String key){return headers.containsKey(key)?headers.get(key):super.getHeaderField(key);}
        @Override public InputStream getInputStream()throws IOException{if(crashAt<0)return super.getInputStream();reads++;return new InputStream(){int at;public int read(){throw new AssertionError();}public int read(byte[] b,int offset,int count){if(at>=crashAt)throw new Crash();if(at>=bytes.length)return -1;int n=(int)Math.min(Math.min(count,bytes.length-at),crashAt-at);System.arraycopy(bytes,at,b,offset,n);at+=n;return n;}public void close(){inputClosed=true;}};}
    }
    static class Updates implements PartialDownload.Updates {
        PartialDownload.Mark saved=PartialDownload.Mark.empty();List<Long> progress=new ArrayList<>();
        public void checkpoint(PartialDownload.Mark mark){saved=mark;}
        public void progress(long bytes,long total){progress.add(bytes);}
    }
    File base,part;byte[] own;Updates updates;
    @Before public void before()throws Exception{base=Files.createTempDirectory("own-range-").toFile();part=new File(base,"own.part");own=new byte[150000];for(int i=0;i<own.length;i++)own[i]=(byte)(i*31);updates=new Updates();}
    @After public void after()throws Exception{try(var paths=Files.walk(base.toPath())){paths.sorted(Comparator.reverseOrder()).forEach(p->p.toFile().delete());}}
    SourceHttp.Download get(String url,Reply... replies)throws Exception{return PartialDownload.get(url,part,updates.saved,new SourceHttp.Token(),SourceHttp.LARGE_DOWNLOAD_LIMIT,updates,new RedirectHttpTest.Factory(replies),MediaRedirectsTest.PUBLIC);}
    void half(String url,String tag,int cut)throws Exception{Reply first=new Reply(url,200,Arrays.copyOf(own,cut),tag);first.declared=own.length;try{get(url,first);fail();}catch(IOException expected){}assertEquals(cut,part.length());assertEquals(cut,updates.saved.offset());assertEquals(own.length,updates.saved.total());assertTrue(first.closed&&first.inputClosed);}
    Reply suffix(String url,int cut,String tag)throws Exception{Reply r=new Reply(url,206,Arrays.copyOfRange(own,cut,own.length),tag);r.headers.put("Content-Range","bytes "+cut+"-"+(own.length-1)+"/"+own.length);return r;}
    @Test public void resumesExactBytesWithStrongValidatorAndRealContentRange()throws Exception{
        int cut=70000;half(URL,"\"v1\"",cut);Reply second=suffix(URL,cut,"\"v1\"");var d=get(URL,second);assertEquals("bytes="+cut+"-",second.getRequestProperty("Range"));assertEquals("\"v1\"",second.getRequestProperty("If-Range"));assertArrayEquals(own,Files.readAllBytes(part.toPath()));assertEquals(own.length,d.bytes());assertEquals(PartialDownload.hex(PartialDownload.digest().digest(own)),d.sha256());assertTrue(second.closed&&second.inputClosed);
    }
    @Test public void ignoredRange200ReplacesPrefixInsteadOfAppending()throws Exception{
        half(URL,"\"v1\"",50000);Reply all=new Reply(URL,200,own,"\"v2\"");get(URL,all);assertNotNull(all.getRequestProperty("Range"));assertArrayEquals(own,Files.readAllBytes(part.toPath()));assertTrue(updates.progress.contains(0L));
    }
    @Test public void weakOrMissingValidatorRestartsSafely()throws Exception{
        for(String tag:new String[]{null,"W/\"v1\""}){updates=new Updates();half(URL,tag,60000);Reply all=new Reply(URL,200,own,"\"new\"");get(URL,all);assertNull(all.getRequestProperty("Range"));assertNull(all.getRequestProperty("If-Range"));assertArrayEquals(own,Files.readAllBytes(part.toPath()));}
        assertFalse(PartialDownload.strong("\"bad\r\nheader\""));assertFalse(PartialDownload.strong("W/\"x\""));assertTrue(PartialDownload.strong("\"x\""));
    }
    @Test public void invalid206HeadersNeverAppendAndCanFallBackToFullResponse()throws Exception{
        for(int mode=0;mode<7;mode++){updates=new Updates();half(URL,"\"v1\"",50000);Reply bad=suffix(URL,50000,"\"v1\"");
            switch(mode){case 0->bad.headers.put("Content-Range","bytes 50001-149999/150000");case 1->bad.headers.put("Content-Range","bytes 50000-149999/*");case 2->bad.headers.put("Content-Range","bytes 50000-149999/150001");case 3->bad.headers.put("ETag","\"changed\"");case 4->bad.headers.remove("ETag");case 5->bad.declared++;case 6->bad.headers.put("Content-Range","bytes 9999999999999999999-9999999999999999999/9999999999999999999");}
            Reply fresh=new Reply(URL,200,own,"\"fresh\"");get(URL,bad,fresh);assertEquals(0,bad.reads);assertNull(fresh.getRequestProperty("Range"));assertArrayEquals(own,Files.readAllBytes(part.toPath()));assertTrue(bad.closed&&fresh.closed);
        }
    }
    @Test public void status416RetriesFromZeroOnce()throws Exception{half(URL,"\"v1\"",40000);Reply bad=new Reply(URL,416,new byte[0],"\"v1\""),fresh=new Reply(URL,200,own,"\"v2\"");get(URL,bad,fresh);assertTrue(bad.closed);assertEquals(0,bad.reads);assertNull(fresh.getRequestProperty("Range"));assertArrayEquals(own,Files.readAllBytes(part.toPath()));}
    @Test public void unexpectedPartialWithoutRequestIsNeverAccepted()throws Exception{try{get(URL,suffix(URL,0,"\"v1\""));fail();}catch(PartialDownload.Problem expected){}assertEquals(0,part.length());}
    @Test public void damagedPrefixRestartsAndUncheckpointedTailIsTruncated()throws Exception{
        half(URL,"\"v1\"",50000);byte[] corrupt=Files.readAllBytes(part.toPath());corrupt[0]^=1;Files.write(part.toPath(),corrupt);Reply full=new Reply(URL,200,own,"\"v1\"");get(URL,full);assertNull(full.getRequestProperty("Range"));assertArrayEquals(own,Files.readAllBytes(part.toPath()));
        updates=new Updates();half(URL,"\"v1\"",50000);try(var out=new FileOutputStream(part,true)){out.write(new byte[10000]);}Reply next=suffix(URL,50000,"\"v1\"");get(URL,next);assertEquals("bytes=50000-",next.getRequestProperty("Range"));assertArrayEquals(own,Files.readAllBytes(part.toPath()));
    }
    @Test public void completeDurableCheckpointFinishesWithoutAnyNetwork()throws Exception{get(URL,new Reply(URL,200,own,null));var result=get(URL);assertEquals(own.length,result.bytes());assertArrayEquals(own,Files.readAllBytes(part.toPath()));}
    @Test public void unknownLengthFinishesWithMeasuredTotalAndProgress()throws Exception{Reply r=new Reply(URL,200,own,"\"v1\"");r.declared=-1;get(URL,r);assertEquals(own.length,updates.saved.total());assertEquals((long)own.length,(long)updates.progress.get(updates.progress.size()-1));}
    @Test public void immutablePawCanResumeWithoutEtagButWrongHashDiscardsThePart()throws Exception{
        String sha=PartialDownload.hex(PartialDownload.digest().digest(own)),url="https://file.pawchive.pw/data/"+sha.substring(0,2)+"/"+sha.substring(2,4)+"/"+sha+".bin";
        half(url,null,60000);get(url,suffix(url,60000,null));assertArrayEquals(own,Files.readAllBytes(part.toPath()));updates=new Updates();half(url,null,60000);Reply wrong=suffix(url,60000,null);wrong.bytes[0]^=1;try{get(url,wrong);fail();}catch(PartialDownload.Problem expected){assertTrue(expected.getMessage().contains("SHA-256"));}assertEquals(0,part.length());assertEquals(0,updates.saved.offset());
    }
    @Test public void changedDeliveryTargetWithSameEtagForcesFreshRepresentation()throws Exception{
        String old="https://pixivfanbox.akamaized.net/old?signature=OWN_A",next="https://pixivfanbox.akamaized.net/new?signature=OWN_B";
        Reply hop=new Reply(URL,302,new byte[0],null);hop.location=old;Reply first=new Reply(old,200,Arrays.copyOf(own,50000),"\"same\"");first.declared=own.length;try{get(URL,hop,first);fail();}catch(IOException expected){}assertEquals(PartialDownload.key(old),updates.saved.target());
        Reply redirect=new Reply(URL,302,new byte[0],null);redirect.location=next;Reply partial=suffix(next,50000,"\"same\"");Reply again=new Reply(URL,302,new byte[0],null);again.location=next;Reply full=new Reply(next,200,own,"\"same\"");get(URL,redirect,partial,again,full);assertEquals(0,partial.reads);assertNull(full.getRequestProperty("Range"));assertArrayEquals(own,Files.readAllBytes(part.toPath()));assertFalse(updates.saved.target().contains("OWN_B"));
    }
    @Test public void processInterruptionUsesOnlyLastSyncedCheckpoint()throws Exception{
        own=new byte[9*1024*1024];for(int i=0;i<own.length;i++)own[i]=(byte)(i*17);Reply first=new Reply(URL,200,own,"\"large\"");first.crashAt=5*1024*1024;try{get(URL,first);fail();}catch(Crash expected){}assertEquals(4L*1024*1024,updates.saved.offset());assertTrue(part.length()>updates.saved.offset());int offset=(int)updates.saved.offset();Reply second=suffix(URL,offset,"\"large\"");get(URL,second);assertEquals("bytes="+offset+"-",second.getRequestProperty("Range"));assertArrayEquals(own,Files.readAllBytes(part.toPath()));assertTrue(first.closed&&first.inputClosed);
    }
    @Test public void mimeEncodingAndSizeRejectionsNeverReadBody()throws Exception{
        for(int mode=0;mode<3;mode++){updates=new Updates();Reply r=new Reply(URL,200,own,"\"v1\"");if(mode==0)r.mime="text/html";if(mode==1)r.headers.put("Content-Encoding","gzip");if(mode==2)r.declared=SourceHttp.LARGE_DOWNLOAD_LIMIT+1;try{get(URL,r);fail();}catch(PartialDownload.Problem expected){}assertEquals(0,r.reads);assertTrue(r.closed);assertEquals(0,part.length());}
    }
    @Test public void rangeSupportDoesNotAuthorizeOtherHostsOrJsonApi()throws Exception{
        try{PartialDownload.get("https://unknown.invalid/own.bin",part,updates.saved,new SourceHttp.Token(),SourceHttp.LARGE_DOWNLOAD_LIMIT,updates,new RedirectHttpTest.Factory(),MediaRedirectsTest.PUBLIC);fail();}catch(IOException expected){}
        try{SourceHttp.open("https://api.fanbox.cc/post.info?postId=1","","",new SourceHttp.Token(),true,new RedirectHttpTest.Factory(),MediaRedirectsTest.PUBLIC,0,"");fail();}catch(IOException expected){}
    }
    @Test public void transientFinalCheckpointFailureRetainsTheCompletedDigestWithoutRehashingEmptyState()throws Exception{
        PartialDownload.Mark[] durable={PartialDownload.Mark.empty()};boolean[] failed={false};var observer=new PartialDownload.Updates(){public void progress(long n,long total){}public void checkpoint(PartialDownload.Mark mark)throws IOException{if(mark.offset()==own.length&&!failed[0]){failed[0]=true;throw new IOException("Own metadata write interruption");}durable[0]=mark;}};
        Reply response=new Reply(URL,200,own,"\"own\"");try{PartialDownload.get(URL,part,durable[0],new SourceHttp.Token(),SourceHttp.LARGE_DOWNLOAD_LIMIT,observer,new RedirectHttpTest.Factory(response),MediaRedirectsTest.PUBLIC);fail();}catch(IOException expected){}assertEquals(own.length,durable[0].offset());assertEquals(PartialDownload.hex(PartialDownload.digest().digest(own)),durable[0].sha());updates.saved=durable[0];assertEquals(own.length,get(URL).bytes());
    }
}
