package com.peach.local;
import androidx.room.Room;
import java.io.*;
import java.nio.charset.StandardCharsets;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class PawchiveDownloadBackupTest {
    LibraryDatabase db;String id;
    @Before public void open()throws Exception{db=Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().build();var payload=PawchiveConnectorTest.response(PawchiveConnectorTest.posts(1));SourceStore store=new SourceStore(db,(u,e,m,t)->payload);id=store.create("pawchive","patreon/123","Fuente propia",null);store.fetch(id,false,new SourceHttp.Token());store.apply(store.review(id));}
    @After public void close(){db.close();}
    JSONObject backup()throws Exception{ByteArrayOutputStream b=new ByteArrayOutputStream();BackupStore.write(db.library(),b);return new JSONObject(b.toString("UTF-8"));}
    void restore(JSONObject b)throws Exception{BackupStore.read(db,new ByteArrayInputStream(b.toString().getBytes(StandardCharsets.UTF_8)));}
    @Test public void version13FalseReferencesRestoreUnchangedAndAreExplicitlySavable()throws Exception{JSONObject b=backup().put("version",13);JSONObject source=b.getJSONArray("sources").getJSONObject(0);JSONArray rows=new JSONArray(source.getString("cachedPage"));rows.getJSONObject(0).getJSONArray("attachments").getJSONObject(0).put("downloadable",false);source.put("cachedPage",rows.toString());b.getJSONArray("publicationContent").getJSONObject(0).getJSONArray("attachments").getJSONObject(0).put("downloadable",false);restore(b);var c=db.library().publicationContents().get(0);JSONObject a=new JSONArray(c.attachments).getJSONObject(0);assertFalse(a.getBoolean("downloadable"));assertTrue(SourceHttp.canSave(a.getString("url"),false));assertEquals(1,db.library().sources().size());}
    @Test public void version14RoundTripRetainsSourcesBodiesAndNewCapability()throws Exception{JSONObject b=backup();assertEquals(19,b.getInt("version"));restore(b);restore(b);assertTrue(new JSONArray(db.library().publicationContents().get(0).attachments).getJSONObject(0).getBoolean("downloadable"));assertEquals(1,db.library().publications().size());}
    @Test public void foreignTrueUrlCannotBeIntroducedThroughRestore()throws Exception{JSONObject b=backup(),source=b.getJSONArray("sources").getJSONObject(0);JSONArray rows=new JSONArray(source.getString("cachedPage"));rows.getJSONObject(0).getJSONArray("attachments").getJSONObject(0).put("url","https://example.org/file.txt").put("downloadable",true);source.put("cachedPage",rows.toString());b.getJSONArray("publications").getJSONObject(0).put("title","Sobrescribir");try{restore(b);fail();}catch(IllegalArgumentException expected){}assertFalse(db.library().publications().get(0).title.equals("Sobrescribir"));}
    @Test public void conservativeFalseFlagsStayValidEvenWhenAHostBecomesSupported()throws Exception{PublicationContent c=new PublicationContent();c.publicationId="own";c.attachments=new JSONArray().put(new JSONObject().put("url",PawchiveDownloadTest.URL).put("name","propio.txt").put("kind","file").put("downloadable",false)).toString();SourceBackup.validateContent(c);assertFalse(new JSONArray(c.attachments).getJSONObject(0).getBoolean("downloadable"));}
}
