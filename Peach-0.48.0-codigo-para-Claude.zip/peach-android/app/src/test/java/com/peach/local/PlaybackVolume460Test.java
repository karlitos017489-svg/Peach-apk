package com.peach.local;

import android.os.Looper;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.media3.exoplayer.ExoPlayer;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.shadows.*;
import org.robolectric.util.ReflectionHelpers;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28)
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public class PlaybackVolume460Test {
    @Before public void clear(){RuntimeEnvironment.getApplication().getSharedPreferences("playback-volume",0).edit().clear().commit();}
    @Test public void realPlayerSliderMuteAndRestoreOnlyAffectSelectedPlayer(){try(var screen=Robolectric.buildActivity(AppearanceActivity.class).setup().visible()){var a=screen.get();ExoPlayer player=new ExoPlayer.Builder(a).build(),other=new ExoPlayer.Builder(a).build();try{PlaybackVolume.show(a,()->player);Shadows.shadowOf(Looper.getMainLooper()).idle();AlertDialog dialog=(AlertDialog)ShadowDialog.getLatestDialog();SeekBar slider=dialog.findViewById(R.id.volume_level);SeekBar.OnSeekBarChangeListener listener=ReflectionHelpers.getField(slider,"mOnSeekBarChangeListener");listener.onProgressChanged(slider,35,true);assertEquals(.35f,player.getVolume(),.001);assertEquals(1f,other.getVolume(),.001);dialog.findViewById(R.id.volume_mute).performClick();assertEquals(0f,player.getVolume(),.001);dialog.findViewById(R.id.volume_mute).performClick();assertEquals(.35f,player.getVolume(),.001);assertEquals(.35f,PlaybackVolume.saved(a),.001);dialog.dismiss();}finally{player.release();other.release();}}}
    @Test public void unavailablePlayerDoesNotOpenMisleadingVolumeSlider(){try(var screen=Robolectric.buildActivity(AppearanceActivity.class).setup().visible()){PlaybackVolume.show(screen.get(),()->null);assertTrue(ShadowToast.getTextOfLatestToast().toString().contains("al iniciar"));}}
    @Test public void volumeButtonRemainsAvailableWhenVideoToolbarIsHidden(){try(var screen=Robolectric.buildActivity(PlayerActivity.class).create().visible()){PlayerActivity a=screen.get();a.findViewById(R.id.fullscreen).performClick();assertEquals(View.GONE,a.findViewById(R.id.playerBar).getVisibility());assertEquals(View.VISIBLE,a.findViewById(R.id.player_volume).getVisibility());assertTrue(a.findViewById(R.id.player_volume).hasOnClickListeners());}}
}
