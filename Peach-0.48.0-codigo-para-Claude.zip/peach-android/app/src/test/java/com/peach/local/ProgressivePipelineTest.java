package com.peach.local;

import android.net.Uri;
import android.os.Looper;
import androidx.media3.common.*;
import androidx.media3.datasource.*;
import androidx.media3.decoder.DecoderInputBuffer;
import androidx.media3.exoplayer.*;
import androidx.media3.exoplayer.analytics.PlayerId;
import androidx.media3.exoplayer.source.*;
import androidx.media3.exoplayer.trackselection.*;
import androidx.media3.exoplayer.upstream.DefaultAllocator;
import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

/** Real ProgressiveMediaSource/Period creates DataSpec; no handwritten request substitutes. */
@RunWith(RobolectricTestRunner.class) @Config(sdk=28)
public class ProgressivePipelineTest {
    static final class Trace implements DataSource {
        final StreamDataSource delegate;final List<DataSpec> requests;final AtomicReference<IOException> failure;
        Trace(VideoStream.Session session,List<DataSpec> requests,AtomicReference<IOException> failure){delegate=new StreamDataSource(session);this.requests=requests;this.failure=failure;}
        public long open(DataSpec spec)throws IOException{requests.add(spec);try{return delegate.open(spec);}catch(IOException e){failure.set(e);throw e;}}
        public int read(byte[] b,int o,int n)throws IOException{return delegate.read(b,o,n);}
        public Uri getUri(){return delegate.getUri();}public Map<String,List<String>> getResponseHeaders(){return delegate.getResponseHeaders();}
        public void addTransferListener(TransferListener listener){delegate.addTransferListener(listener);}public void close(){delegate.close();}
    }
    static final class Harness implements AutoCloseable {
        final VideoStream.Session session;final ProgressiveMediaSource source;final List<DataSpec> requests=Collections.synchronizedList(new ArrayList<>());final AtomicReference<IOException> failure=new AtomicReference<>();
        MediaPeriod period;boolean prepared;final MediaSource.MediaSourceCaller caller;
        Harness(VideoStream.Session session){this.session=session;session.resume();source=new ProgressiveMediaSource.Factory(()->new Trace(session,requests,failure)).setLoadErrorHandlingPolicy(new SourceVideoStream.NoRetry()).createMediaSource(new MediaItem.Builder().setUri(StreamDataSource.uri(session.key)).build());
            caller=(s,timeline)->{if(period!=null)return;period=source.createPeriod(new MediaSource.MediaPeriodId(timeline.getUidOfPeriod(0)),new DefaultAllocator(true,C.DEFAULT_BUFFER_SEGMENT_SIZE),0);period.prepare(new MediaPeriod.Callback(){public void onPrepared(MediaPeriod p){prepared=true;}public void onContinueLoadingRequested(MediaPeriod p){p.continueLoading(new LoadingInfo.Builder().setPlaybackPositionUs(0).build());}},0);};
        }
        void start(){source.prepareSource(caller,null,PlayerId.UNSET);}
        void waitPrepared()throws Exception{long end=System.nanoTime()+5_000_000_000L;while(!prepared&&failure.get()==null&&System.nanoTime()<end){Shadows.shadowOf(Looper.getMainLooper()).idle();Thread.sleep(5);}Shadows.shadowOf(Looper.getMainLooper()).idle();System.out.println("Progressive pipeline: prepared="+prepared+", headers="+(requests.isEmpty()?"none":requests.get(0).httpRequestHeaders)+", error="+failure.get());assertTrue("Real media period did not prepare: "+failure.get(),prepared);}
        DecoderInputBuffer firstVideoSample()throws Exception{
            var groups=period.getTrackGroups();androidx.media3.common.TrackGroup video=null;for(int i=0;i<groups.length;i++)if(groups.get(i).type==C.TRACK_TYPE_VIDEO)video=groups.get(i);assertNotNull(video);
            SampleStream[] streams=new SampleStream[1];period.selectTracks(new ExoTrackSelection[]{new FixedTrackSelection(video,0)},new boolean[1],streams,new boolean[1],0);assertNotNull(streams[0]);FormatHolder format=new FormatHolder();DecoderInputBuffer buffer=new DecoderInputBuffer(DecoderInputBuffer.BUFFER_REPLACEMENT_MODE_NORMAL);long end=System.nanoTime()+5_000_000_000L;
            while(System.nanoTime()<end){period.continueLoading(new LoadingInfo.Builder().setPlaybackPositionUs(0).build());Shadows.shadowOf(Looper.getMainLooper()).idle();int result=streams[0].readData(format,buffer,0);if(result==C.RESULT_BUFFER_READ&&!buffer.isEndOfStream()){assertNotNull(buffer.data);assertTrue(buffer.data.position()>0);return buffer;}if(result==C.RESULT_FORMAT_READ)assertEquals("video/avc",format.format.sampleMimeType);period.maybeThrowPrepareError();Thread.sleep(5);}throw new AssertionError("No video sample delivered through real media period.");
        }
        public void close()throws Exception{session.pause();if(period!=null)source.releasePeriod(period);source.releaseSource(caller);session.close();long end=System.nanoTime()+5_000_000_000L;while(System.nanoTime()<end){synchronized(session){if(session.active.isEmpty())return;}Shadows.shadowOf(Looper.getMainLooper()).idle();Thread.sleep(5);}synchronized(session){assertTrue(session.active.isEmpty());}}
    }
    @Test public void realProgressiveLoaderPreparesAndDeliversVideoWithItsOwnRequestHeaders()throws Exception {
        byte[] own=SourceVideosTest.own();var network=new StreamDataSourceTest.RangeFactory(own);var session=new VideoStream.Session(VideoStreamTest.URL,()->true,network,MediaRedirectsTest.PUBLIC);
        try(var h=new Harness(session)){h.start();h.waitPrepared();assertFalse(h.requests.isEmpty());assertEquals(Map.of("Icy-MetaData","1"),h.requests.get(0).httpRequestHeaders);assertFalse(network.replies.isEmpty());assertNotNull(h.firstVideoSample());for(var reply:network.replies){assertNull(reply.getRequestProperty("Icy-MetaData"));assertNull(reply.getRequestProperty("Authorization"));assertNull(reply.getRequestProperty("Cookie"));}}
    }
    @Test public void actualServer403IsReportedAfterTheRealLoaderRequestPassesLocalValidation()throws Exception {
        var reply=new VideoStreamTest.Reply(VideoStreamTest.URL,403,new byte[0],null);var network=new RedirectHttpTest.Factory(reply);var session=new VideoStream.Session(VideoStreamTest.URL,()->true,network,MediaRedirectsTest.PUBLIC);
        try(var h=new Harness(session)){h.start();long end=System.nanoTime()+5_000_000_000L;while(h.failure.get()==null&&System.nanoTime()<end){Shadows.shadowOf(Looper.getMainLooper()).idle();Thread.sleep(5);}assertTrue(h.failure.get() instanceof VideoStream.Problem);var problem=(VideoStream.Problem)h.failure.get();assertEquals(VideoStream.Reason.ACCESS,problem.reason);assertEquals(403,problem.httpStatus);assertEquals(1,network.requests.size());assertFalse(h.prepared);assertNull(reply.getRequestProperty("Icy-MetaData"));}
    }
    @Test public void offlineSessionBlocksTheRealLoaderWithoutMakingAnHttpRequest()throws Exception {
        var network=new StreamDataSourceTest.RangeFactory(SourceVideosTest.own());var session=new VideoStream.Session(VideoStreamTest.URL,()->false,network,MediaRedirectsTest.PUBLIC);
        try(var h=new Harness(session)){h.start();long end=System.nanoTime()+5_000_000_000L;while(h.failure.get()==null&&System.nanoTime()<end){Shadows.shadowOf(Looper.getMainLooper()).idle();Thread.sleep(5);}assertTrue(h.failure.get() instanceof VideoStream.Problem);assertEquals(VideoStream.Reason.OFFLINE,((VideoStream.Problem)h.failure.get()).reason);assertTrue(network.replies.isEmpty());assertFalse(h.prepared);}
    }
}
