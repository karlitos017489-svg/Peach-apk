package com.peach.local;
import android.content.*;
import android.database.*;
import android.net.Uri;
import android.os.*;
import android.provider.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowContentResolver;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class QueueExportTest {
    static final String AUTH="own.queue.tree";
    public static class Tree extends DocumentsProvider {
        File base;final Map<String,File> files=new LinkedHashMap<>();final Map<String,String> names=new HashMap<>();int created,deleted;boolean zeroSize,failWrite;
        public boolean onCreate(){return true;}
        public Cursor queryRoots(String[] p){return new MatrixCursor(new String[]{"root_id","document_id","title","flags","mime_types"});}
        public Cursor queryChildDocuments(String p,String[] cols,String sort){return new MatrixCursor(cols==null?new String[]{"document_id"}:cols);}
        public Cursor queryDocument(String id,String[] p){String[] cols=p==null?new String[]{"document_id","_display_name","mime_type","_size","flags"}:p;MatrixCursor c=new MatrixCursor(cols);if(!id.equals("root")&&!files.containsKey(id))return c;Object[] values=new Object[cols.length];for(int i=0;i<cols.length;i++)values[i]=switch(cols[i]){case "document_id"->id;case "_display_name"->names.getOrDefault(id,"Own folder");case "mime_type"->id.equals("root")?DocumentsContract.Document.MIME_TYPE_DIR:"video/mp4";case "_size"->id.equals("root")?0L:zeroSize?0L:files.get(id).length();case "flags"->DocumentsContract.Document.FLAG_SUPPORTS_WRITE|DocumentsContract.Document.FLAG_SUPPORTS_DELETE|DocumentsContract.Document.FLAG_DIR_SUPPORTS_CREATE;default->null;};c.addRow(values);return c;}
        public boolean isChildDocument(String parent,String child){return parent.equals("root")&&!child.equals("root");}
        public String createDocument(String parent,String mime,String name)throws FileNotFoundException{
            String id="new-"+(++created);File file=new File(base,id);try{Files.write(file.toPath(),new byte[0]);}catch(IOException e){throw new FileNotFoundException();}files.put(id,file);names.put(id,name);
            if(failWrite){Uri tree=DocumentsContract.buildTreeDocumentUri(AUTH,"root"),uri=DocumentsContract.buildDocumentUriUsingTree(tree,id);try{FileOutputStream out=new FileOutputStream(file);Shadows.shadowOf(getContext().getContentResolver()).registerOutputStream(uri,new FilterOutputStream(out){int written;public void write(byte[] b,int o,int n)throws IOException{if(written>0)throw new IOException("Own destination full");out.write(b,o,Math.min(n,100));written+=Math.min(n,100);}public void write(int b)throws IOException{throw new IOException("Own destination full");}});}catch(IOException e){throw new FileNotFoundException();}}
            return id;
        }
        public void deleteDocument(String id)throws FileNotFoundException{File f=files.remove(id);if(f==null)throw new FileNotFoundException();f.delete();deleted++;}
        public ParcelFileDescriptor openDocument(String id,String mode,CancellationSignal signal)throws FileNotFoundException{File f=files.get(id);if(f==null)throw new FileNotFoundException();return ParcelFileDescriptor.open(f,ParcelFileDescriptor.parseMode(mode));}
    }
    android.app.Application app;LibraryDatabase db;File base;DownloadQueue queue;Tree provider;byte[] own;int downloads;
    @Before public void before()throws Exception{app=RuntimeEnvironment.getApplication();db=androidx.room.Room.inMemoryDatabaseBuilder(app,LibraryDatabase.class).allowMainThreadQueries().build();base=Files.createTempDirectory("queue-export-own-").toFile();queue=new DownloadQueue(new File(base,"queue"));own=SourceVideosTest.own();var p=GalleryProvidersTest.publication("fanbox");db.library().insertPublication(p);JSONArray items=new JSONArray().put(SourceVideosTest.video(DownloadQueueTest.A)).put(SourceVideosTest.video(DownloadQueueTest.B));db.library().putPublicationContent(GalleryProvidersTest.content(p,items));queue.enqueue(p.id,SourceAttachments.load(db,p.id));queue.run(db,(u,f,m,t,l,updates)->{downloads++;return SourceHttp.copyAttachment(u,new ByteArrayInputStream(own),f,own.length,t,l);});
        provider=new Tree();provider.base=new File(base,"tree");provider.base.mkdirs();File existing=new File(provider.base,"existing");Files.write(existing.toPath(),"USER ORIGINAL".getBytes());provider.files.put("existing",existing);provider.names.put("existing","Own.mp4");android.content.pm.ProviderInfo info=new android.content.pm.ProviderInfo();info.authority=AUTH;info.exported=true;info.grantUriPermissions=true;info.readPermission="android.permission.MANAGE_DOCUMENTS";info.writePermission="android.permission.MANAGE_DOCUMENTS";provider.attachInfo(app,info);// Robolectric's five-argument query calls DocumentsProvider's deliberately
        // unsupported legacy method. Android's resolver converts it to the O+ bundle API.
        ContentProvider bridge=new ContentProvider(){
            public boolean onCreate(){return true;}public Cursor query(Uri u,String[] cols,String sel,String[] args,String sort){return provider.query(u,cols,Bundle.EMPTY,null);}
            public String getType(Uri u){return provider.getType(u);}public Bundle call(String method,String arg,Bundle extras){return provider.call(method,arg,extras);}
            public ParcelFileDescriptor openFile(Uri u,String mode)throws FileNotFoundException{return provider.openFile(u,mode);}
            public Uri insert(Uri u,ContentValues values){return null;}public int update(Uri u,ContentValues values,String sel,String[] args){return 0;}public int delete(Uri u,String sel,String[] args){return 0;}
        };bridge.attachInfo(app,info);ShadowContentResolver.registerProviderInternal(AUTH,bridge);Uri tree=DocumentsContract.buildTreeDocumentUri(AUTH,"root");app.grantUriPermission(app.getPackageName(),tree,Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);queue.folder(tree);}
    @After public void after()throws Exception{assertFalse(queue.exporting);assertTrue(queue.pins.isEmpty());db.close();GalleryProvidersTest.remove(base);}
    @Test public void savesSeveralCompletedFilesIntoOneFolderWithoutRedownloadOrOverwrite()throws Exception{
        assertEquals(2,queue.export(app,new SourceHttp.Token()));assertEquals(2,downloads);assertEquals(2,provider.created);assertEquals(0,provider.deleted);for(var j:queue.snapshot()){assertFalse(j.exported.isEmpty());assertTrue(j.pending.isEmpty());String id=DocumentsContract.getDocumentId(Uri.parse(j.exported));assertArrayEquals(own,Files.readAllBytes(provider.files.get(id).toPath()));assertTrue(provider.names.get(id).contains("-peach-"));}
        assertEquals(0,queue.export(app,new SourceHttp.Token()));assertEquals(2,provider.created);var first=queue.snapshot().get(0);String exported=DocumentsContract.getDocumentId(Uri.parse(first.exported));queue.remove(first.id);assertTrue(provider.files.get(exported).exists());assertArrayEquals("USER ORIGINAL".getBytes(),Files.readAllBytes(provider.files.get("existing").toPath()));
    }
    @Test public void zeroLengthReportedByProviderNeverMarksSavedSuccess()throws Exception{
        provider.zeroSize=true;try{queue.export(app,new SourceHttp.Token());fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("incompleto"));}assertEquals(1,provider.created);assertEquals(1,provider.deleted);assertTrue(queue.snapshot().stream().allMatch(j->j.exported.isEmpty()));assertTrue(queue.snapshot().get(0).pending.isEmpty());assertTrue(queue.ready(queue.snapshot().get(0).id).isFile());assertTrue(provider.files.get("existing").exists());
    }
    @Test public void failedPartialWriteDeletesOnlyTheNewDocumentAndKeepsPrivateOriginal()throws Exception{
        provider.failWrite=true;try{queue.export(app,new SourceHttp.Token());fail();}catch(IOException expected){}assertEquals(1,provider.created);assertEquals(1,provider.deleted);assertTrue(queue.snapshot().get(0).exported.isEmpty());assertTrue(queue.snapshot().get(0).pending.isEmpty());assertArrayEquals(own,Files.readAllBytes(queue.ready(queue.snapshot().get(0).id).toPath()));assertTrue(provider.files.get("existing").exists());
    }
    @Test public void interruptedExportLedgerCleansOnlyItsOwnPendingDocumentOnRecovery()throws Exception{
        String doc=provider.createDocument("root","video/mp4","own-pending.mp4");Files.write(provider.files.get(doc).toPath(),Arrays.copyOf(own,200));Uri uri=DocumentsContract.buildDocumentUriUsingTree(DocumentsContract.buildTreeDocumentUri(AUTH,"root"),doc);synchronized(queue){queue.job(queue.snapshot().get(0).id).pending=uri.toString();queue.save();}queue=new DownloadQueue(queue.root);queue.recoverExports(app);assertFalse(provider.files.containsKey(doc));assertEquals(1,provider.deleted);assertTrue(queue.snapshot().get(0).pending.isEmpty());assertTrue(provider.files.get("existing").exists());assertEquals(2,downloads);
    }
    @Test public void alreadyMissingPendingDocumentDoesNotBlockTheQueue()throws Exception{
        var first=queue.snapshot().get(0);synchronized(queue){queue.job(first.id).pending=DocumentsContract.buildDocumentUriUsingTree(DocumentsContract.buildTreeDocumentUri(AUTH,"root"),"already-missing").toString();queue.save();}queue.recoverExports(app);assertTrue(queue.snapshot().get(0).pending.isEmpty());assertEquals(0,provider.deleted);
    }
}
