package com.peach.local;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.lifecycle.ViewModelProvider;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowDialog;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land") @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class QueueUiTest {
    LibraryDatabase db;Publication p;byte[] own;int calls;List<ActivityController<DownloadQueueActivity>> screens=new ArrayList<>();
    @Before public void before()throws Exception{
        var app=RuntimeEnvironment.getApplication();for(var f:ViewModelProvider.AndroidViewModelFactory.class.getDeclaredFields())if(java.lang.reflect.Modifier.isStatic(f.getModifiers())&&f.getType()==ViewModelProvider.AndroidViewModelFactory.class){f.setAccessible(true);f.set(null,new ViewModelProvider.AndroidViewModelFactory(app));}
        DownloadQueue.STORES.clear();File root=new File(app.getNoBackupFilesDir(),"peach-download-queue");if(root.exists())GalleryProvidersTest.remove(root);
        db=androidx.room.Room.inMemoryDatabaseBuilder(app,LibraryDatabase.class).allowMainThreadQueries().setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",db);p=GalleryProvidersTest.publication("fanbox");db.library().insertPublication(p);db.library().putPublicationContent(GalleryProvidersTest.content(p,new JSONArray().put(SourceVideosTest.video(DownloadQueueTest.A)).put(SourceVideosTest.video(DownloadQueueTest.B))));own=SourceVideosTest.own();DownloadQueueActivity.fetcher=this::fetch;
    }
    SourceHttp.Download fetch(String u,File f,PartialDownload.Mark mark,SourceHttp.Token token,long limit,PartialDownload.Updates progress)throws IOException{calls++;return SourceHttp.copyAttachment(u,new ByteArrayInputStream(own),f,own.length,token,limit);}
    void idle()throws Exception{LibraryDatabase.IO.submit(()->{}).get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}
    void settle(DownloadQueueActivity activity)throws Exception{for(int i=0;i<2;i++){activity.draft.control.submit(()->{}).get(30,TimeUnit.SECONDS);activity.draft.transfer.submit(()->{}).get(30,TimeUnit.SECONDS);idle();}}
    ActivityController<DownloadQueueActivity> screen(String id){Intent i=new Intent(RuntimeEnvironment.getApplication(),DownloadQueueActivity.class).putExtra("publicationId",id).putExtra("url","https://not-allowed.invalid/private");var c=Robolectric.buildActivity(DownloadQueueActivity.class,i).setup().visible();screens.add(c);return c;}
    void addAll(DownloadQueueActivity a)throws Exception{a.add.performClick();idle();AlertDialog dialog=(AlertDialog)ShadowDialog.getLatestDialog();dialog.getButton(AlertDialog.BUTTON_NEUTRAL).performClick();idle();assertTrue(dialog.isShowing());dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick();settle(a);}
    @After public void after()throws Exception{for(var c:screens){var d=c.get().draft;c.pause().stop().destroy();assertTrue(d.control.awaitTermination(30,TimeUnit.SECONDS));assertTrue(d.transfer.awaitTermination(30,TimeUnit.SECONDS));if(d.queue!=null){assertFalse(d.queue.running());assertTrue(d.queue.pins.isEmpty());}}
        DownloadQueueActivity.fetcher=PartialDownload::get;idle();db.close();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);DownloadQueue.STORES.clear();File root=new File(RuntimeEnvironment.getApplication().getNoBackupFilesDir(),"peach-download-queue");if(root.exists())GalleryProvidersTest.remove(root);
        for(var f:ViewModelProvider.AndroidViewModelFactory.class.getDeclaredFields())if(java.lang.reflect.Modifier.isStatic(f.getModifiers())&&f.getType()==ViewModelProvider.AndroidViewModelFactory.class){f.setAccessible(true);f.set(null,null);}
    }
    @Test public void openAndBatchSelectionNeverFetchUntilExplicitContinue()throws Exception{
        var c=screen(p.id);settle(c.get());assertEquals(0,calls);assertEquals(2,c.get().draft.attachments.size());assertTrue(c.get().draft.queue.snapshot().isEmpty());addAll(c.get());assertEquals(2,c.get().draft.rows.size());assertEquals(0,calls);c.get().start.performClick();settle(c.get());assertEquals(2,calls);assertTrue(c.get().draft.rows.stream().allMatch(j->j.state.equals("ready")));assertTrue(db.library().allMedia().isEmpty());assertEquals(0,db.library().usageCount());
    }
    @Test public void sourcesExposeQueueForImportedPublicationWithoutChangingVideoButtons()throws Exception{
        try(var c=Robolectric.buildActivity(SourcesActivity.class,new Intent(RuntimeEnvironment.getApplication(),SourcesActivity.class).putExtra("publicationId",p.id)).setup().visible()){
            var draft=new ViewModelProvider(c.get()).get(SourcesActivity.Draft.class);draft.worker.submit(()->{}).get(30,TimeUnit.SECONDS);idle();Button button=find(c.get().getWindow().getDecorView(),"Cola de descargas");assertNotNull(button);button.performClick();idle();Intent next=Shadows.shadowOf(c.get()).getNextStartedActivity();assertEquals(DownloadQueueActivity.class.getName(),next.getComponent().getClassName());assertEquals(p.id,next.getStringExtra("publicationId"));assertNull(next.getData());assertNotNull(find(c.get().getWindow().getDecorView(),"Abrir video o GIF"));assertNotNull(find(c.get().getWindow().getDecorView(),"Reproducir descarga"));
        }assertEquals(0,calls);
    }
    static Button find(android.view.View v,String text){if(v instanceof Button b&&b.getText().toString().equals(text))return b;if(v instanceof android.view.ViewGroup g)for(int i=0;i<g.getChildCount();i++){Button b=find(g.getChildAt(i),text);if(b!=null)return b;}return null;}
    @Test public void rotationKeepsOneQueueOwnerAndLeavingPausesBeforeNextJob()throws Exception{
        CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);DownloadQueueActivity.fetcher=(u,f,m,t,l,updates)->{entered.countDown();try{release.await(15,TimeUnit.SECONDS);}catch(InterruptedException e){throw new InterruptedIOException();}return fetch(u,f,m,t,l,updates);};
        var c=screen(p.id);settle(c.get());addAll(c.get());c.get().start.performClick();assertTrue(entered.await(15,TimeUnit.SECONDS));var draft=c.get().draft;try{c.recreate();assertSame(draft,c.get().draft);assertTrue(draft.queue.running());c.pause().stop();release.countDown();c.start().resume().visible();settle(c.get());assertTrue(draft.queue.snapshot().stream().allMatch(j->j.state.equals("paused")));assertEquals(1,calls);}finally{release.countDown();}
    }
    @Test public void readyFileOpensByReadOnlyProviderAndRemovalWaitsForDescriptorClose()throws Exception{
        var c=screen(p.id);settle(c.get());addAll(c.get());c.get().start.performClick();settle(c.get());var j=c.get().draft.rows.get(0);Uri uri=QueueFilesProvider.uri(c.get(),j.id);
        try(var in=c.get().getContentResolver().openInputStream(uri)){assertNotNull(in);assertEquals(own[0]&255,in.read());assertTrue(c.get().draft.queue.pins.getOrDefault(j.id,0)>0);try{c.get().draft.queue.remove(j.id);fail();}catch(IOException expected){}}
        idle();assertTrue(c.get().draft.queue.pins.isEmpty());c.get().draft.action(j.id,"open");settle(c.get());Intent opened=Shadows.shadowOf(c.get()).getNextStartedActivity();assertEquals(PlayerActivity.class.getName(),opened.getComponent().getClassName());assertEquals(uri,opened.getData());assertFalse(opened.getDataString().contains("https://"));assertNull(Shadows.shadowOf(c.get()).getNextStartedActivity());
        try{c.get().getContentResolver().openOutputStream(uri,"w");fail();}catch(FileNotFoundException|SecurityException expected){}
        Uri bad=Uri.parse("content://"+c.get().getPackageName()+".queue/../../outside");try{c.get().getContentResolver().openInputStream(bad);fail();}catch(FileNotFoundException expected){}
    }
    @Test public void folderPickerStoresOneTreeAndSurvivesQueueReopen()throws Exception{
        var c=screen(p.id);settle(c.get());c.get().folder.performClick();var picker=Shadows.shadowOf(c.get()).getNextStartedActivityForResult();assertEquals(Intent.ACTION_OPEN_DOCUMENT_TREE,picker.intent.getAction());Uri tree=android.provider.DocumentsContract.buildTreeDocumentUri("own.queue.tree","root");c.get().getActivityResultRegistry().dispatchResult(picker.requestCode,android.app.Activity.RESULT_OK,new Intent().setData(tree));settle(c.get());assertEquals(tree.toString(),c.get().draft.queue.folder);assertTrue(c.get().export.isEnabled());var restored=new DownloadQueue(c.get().draft.queue.root);assertEquals(tree.toString(),restored.folder);assertEquals(0,calls);
    }
    @Test public void progressUsesActualCountsAndUnknownSizeHasNoInventedPercentage(){
        DownloadQueue.Job job=new DownloadQueue.Job();job.name="Own.mp4";job.state="running";job.bytes=1024*1024;assertFalse(DownloadQueue.label(job).contains("%"));job.total=2*1024*1024;assertTrue(DownloadQueue.label(job).contains("50%"));job.state="paused";assertTrue(DownloadQueue.label(job).contains("Pausada"));
    }
    @Test public void malformedOrUnimportedPublicationCannotInjectAQueueUrl()throws Exception{
        var c=screen("missing-imported-id");settle(c.get());assertTrue(c.get().draft.attachments.isEmpty());assertFalse(c.get().add.isEnabled());assertEquals(0,calls);assertTrue(c.get().draft.rows.isEmpty());
        var p=GalleryProvidersTest.publication("patreon");var body=GalleryProvidersTest.content(p,new JSONArray().put(SourceVideosTest.video(DownloadQueueTest.A)));assertTrue(SourceAttachments.select(p,body).isEmpty());
    }
}
