package com.peach.local;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class Rar4NamesTest {
 static byte[] bytes(int... a){byte[] b=new byte[a.length];for(int i=0;i<a.length;i++)b[i]=(byte)a[i];return b;}
 static byte[] join(byte[]... a)throws IOException{return RarBookTest.join(a);}
 static byte[] legacy(String name)throws IOException {
  byte[] utf=name.getBytes(StandardCharsets.UTF_16LE);var out=new ByteArrayOutputStream();
  out.write("x".repeat(utf.length/2).getBytes(StandardCharsets.US_ASCII));out.write(0);out.write(0);
  for(int at=0;at<utf.length;at+=8){out.write(0xaa);out.write(utf,at,Math.min(8,utf.length-at));}return out.toByteArray();
 }
 static void rejects(byte[] b)throws Exception{try{Rar4Names.decode(b,true);fail("Invalid name accepted");}catch(IOException expected){assertFalse(expected.getMessage().contains("private"));}}
 @Test public void asciiAndDirectUtf8KeepTheirExactSpelling()throws Exception{
  assertEquals("notes.txt",Rar4Names.decode("notes.txt".getBytes(StandardCharsets.US_ASCII),false));
  for(String s:List.of("notas/niñez.txt","日本語/地層.txt","roca-🪨.txt"))assertEquals(s,Rar4Names.decode(s.getBytes(StandardCharsets.UTF_8),true));
 }
 @Test public void ambiguousAnsiIsNeverGuessedAsUtf8OrLatin1()throws Exception{
  for(byte[] b:List.of(bytes(0xf1),"niñez.txt".getBytes(StandardCharsets.UTF_8)))try{Rar4Names.decode(b,false);fail();}catch(IOException expected){}
 }
 @Test public void allFourOperationsDecodeInOneFlagByte()throws Exception {
  byte[] vector=join("a??BC".getBytes(StandardCharsets.US_ASCII),bytes(0,4,0x1b,'a',0xb1,0x2d,0x4e,0));
  assertEquals("aұ中BC",Rar4Names.decode(vector,true));
 }
 @Test public void correctionRunsWrapTheLowByteAndKeepUnsignedHighByte()throws Exception{
  assertEquals("\u4e00\u4e01\u4e02\u4e03",Rar4Names.decode(join(bytes('z','{','|','}',0,0x4e,0xc0,0x82,0x86)),true));
  assertEquals("\uff01\uff02",Rar4Names.decode(bytes('A','B',0,255,0xc0,0x80,0xc0),true));
 }
 @Test public void plainRunsIgnoreTheSharedHighByteAndAddressOutputPosition()throws Exception{
  assertEquals("zBC",Rar4Names.decode(bytes('A','B','C',0,0x7f,0x30,'z',0),true));
 }
 @Test public void literalUtf16SupportsSupplementaryPairsAndDoesNotUsePrefix()throws Exception{
  for(String n:List.of("niñez.txt","日本語/地層.txt","roca-🪨.txt","e\u0301.txt"))assertEquals(n,Rar4Names.decode(legacy(n),true));
 }
 @Test public void flagGroupsRestartAfterFourOperations()throws Exception{
  String n="imágenes\\página-10.txt";assertEquals(n,Rar4Names.decode(legacy(n),true));
 }
 @Test public void unpairedSurrogatesAreRejectedRatherThanReplacedInIpc()throws Exception{
  rejects(bytes('x',0,0,0x80,0x00,0xd8));rejects(bytes('x',0,0,0x80,0x00,0xdc));
  rejects(join(bytes('x','x',0,0,0xa0,0x00,0xd8,'a',0)));
 }
 @Test public void eachInstructionRejectsTruncatedOperands()throws Exception{
  for(byte[] b:List.of(bytes('x',0,0,0),bytes('x',0,0,0x40),bytes('x',0,0,0x80,1),bytes('x',0,0,0xc0,0x80)))rejects(b);
 }
 @Test public void incompleteFlagGroupsWithoutAnyFinalOperandAreRejected()throws Exception{
  rejects(bytes('x',0));rejects(bytes('x',0,0));rejects(bytes('x',0,0,0));rejects(bytes(0,0,0,'a'));
 }
 @Test public void runsCannotReadTheSeparatorOrInstructionStreamAsPrefix()throws Exception{
  rejects(bytes('x',0,0,0xc0,0));rejects(bytes('x','y',0,0,0x30,'a',0));
 }
 @Test public void malformedDirectUtf8IsNotReplaced()throws Exception{
  for(byte[] b:List.of(bytes(0xc0,0xaf),bytes(0xed,0xa0,0x80),bytes(0xe2,0x82)))rejects(b);
 }
 @Test public void encodedFieldIsBoundedBeforeDecoding()throws Exception{
  rejects(new byte[0]);rejects(new byte[4097]);assertEquals(4096,Rar4Names.decode("a".repeat(4096).getBytes(StandardCharsets.US_ASCII),true).length());
 }
 @Test public void compressedRunsCannotExceedTheUtf8IpcLimit()throws Exception{
  var out=new ByteArrayOutputStream();out.write("a".repeat(1400).getBytes(StandardCharsets.US_ASCII));out.write(0);out.write(0x4e);
  int remaining=1400,operations=0;while(remaining>0){if(operations++%4==0)out.write(0xff);int n=Math.min(129,remaining);out.write(0x80|(n-2));out.write(0);remaining-=n;}rejects(out.toByteArray());
 }
 @Test public void arbitraryShortFieldsOnlyReturnValidUnicodeOrControlledIoErrors()throws Exception{
  var random=new Random(40);for(int i=0;i<5000;i++){byte[] b=new byte[1+random.nextInt(50)];random.nextBytes(b);b[random.nextInt(b.length)]=0;
   try{String s=Rar4Names.decode(b,true);assertArrayEquals(s.getBytes(StandardCharsets.UTF_8),new String(s.getBytes(StandardCharsets.UTF_8),StandardCharsets.UTF_8).getBytes(StandardCharsets.UTF_8));assertTrue(s.getBytes(StandardCharsets.UTF_8).length<=4096);}catch(IOException expected){}
  }
 }
}
