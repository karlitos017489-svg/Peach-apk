package com.peach.local;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.CRC32;
import org.junit.*;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

public class RarBookTest {
 @Rule public TemporaryFolder temp=new TemporaryFolder();
 static byte[] fixture(String name)throws Exception{try(var in=RarBookTest.class.getClassLoader().getResourceAsStream("rar038/"+name)){assertNotNull(in);return in.readAllBytes();}}
 File file(byte[] b)throws Exception{File f=temp.newFile();Files.write(f.toPath(),b);return f;}
 void rejects(byte[] b)throws Exception{try(var r=new RarBook(file(b))){fail("Invalid RAR accepted");}catch(IOException expected){}}
 static byte[] join(byte[]... values)throws IOException{var out=new ByteArrayOutputStream();for(byte[] b:values)out.write(b);return out.toByteArray();}
 static byte[] vint(long n){var out=new ByteArrayOutputStream();while(n>=128){out.write((int)(n&127)|128);n>>>=7;}out.write((int)n);return out.toByteArray();}
 static byte[] le(long n,int size){byte[] b=new byte[size];for(int i=0;i<size;i++)b[i]=(byte)(n>>>(8*i));return b;}
 static long crc(byte[] b){var c=new CRC32();c.update(b);return c.getValue();}
 static byte[] header5(int type,int flags,byte[] body,byte[] extra,byte[] payload)throws IOException{
  if(extra.length>0)flags|=1;if(type==2 || payload.length>0)flags|=2;
  byte[] b=join(vint(type),vint(flags),(flags&1)!=0?vint(extra.length):new byte[0],(flags&2)!=0?vint(payload.length):new byte[0],body,extra),s=vint(b.length),all=join(s,b);
  return join(le(crc(all),4),all,payload);
 }
 static byte[] entry5(String name,byte[] payload,long size,int f,long compression,int blockFlags,byte[] extra,long attr)throws IOException{
  byte[] n=name.getBytes(java.nio.charset.StandardCharsets.UTF_8);return header5(2,blockFlags,join(vint(f),vint(size),vint(attr),(f&2)!=0?le(0,4):new byte[0],(f&4)!=0?le(crc(payload),4):new byte[0],vint(compression),vint(1),vint(n.length),n),extra,payload);
 }
 static byte[] entry(String n,byte[] b)throws IOException{return entry5(n,b,b.length,4,0,0,new byte[0],0100644);}
 static byte[] rar5(byte[]... files)throws IOException{return join("Rar!\u001a\u0007\u0001\u0000".getBytes(java.nio.charset.StandardCharsets.ISO_8859_1),header5(1,0,vint(0),new byte[0],new byte[0]),join(files),header5(5,0,vint(0),new byte[0],new byte[0]));}
 static byte[] extra(int type){return new byte[]{1,(byte)type};}
 static byte[] ascii(String s){return s.getBytes(java.nio.charset.StandardCharsets.UTF_8);}
 @Test public void crossValidatedRar4AndRar5IndexNaturallyAndReadOnlyRequestedEntries()throws Exception{
  for(String n:List.of("album-rar4.cbr","album-rar5.rar"))try(var r=ArchiveBook.open(file(fixture(n)),n,temp.newFolder())){
   assertEquals(6,r.items().size());assertEquals("empty.txt",r.items().get(0).name());assertEquals(List.of("images/2.png","images/10.png"),r.items().stream().filter(i->i.kind().equals("image")).map(ArchiveBook.Item::name).toList());
   File out=temp.newFolder();assertEquals(0,out.list().length);String note=n.contains("rar4")?"notes.txt":"notas/ñ.txt";assertTrue(ArchiveBookTest.readString(r.read(note,out).toPath()).contains("estratos"));assertEquals(0,r.read("empty.txt",out).length());
   for(String not:List.of("nested.rar","video.mp4")){assertEquals("",r.item(not).kind());try{r.read(not,out);fail();}catch(IOException expected){}}
   assertEquals(List.of("entry"),List.of(out.list()));
  }
 }
 @Test public void dispatchAndClassificationDoNotEnableNestedArchives(){for(String n:List.of("comic.RAR","comic.CBR")){assertEquals(DocumentRules.RAR,DocumentRules.kind(n));assertTrue(DocumentRules.readable(n));assertEquals(MediaRules.ARCHIVE,MediaRules.type(n));assertTrue(DocumentRules.label(n).contains("lectura parcial"));assertEquals("",DocumentRules.entryKind(n));}}
 @Test public void truncatedDamagedTrailingAndSfxInputsAreRejected()throws Exception{
  for(String n:List.of("album-rar4.cbr","album-rar5.rar")){byte[] good=fixture(n);for(int len:new int[]{0,6,14,good.length-1})rejects(Arrays.copyOf(good,len));byte[] bad=good.clone();bad[10]^=1;rejects(bad);rejects(join(good,new byte[]{0}));rejects(join(new byte[]{'M','Z'},good));}
 }
 @Test public void unsafeAndDuplicateCanonicalNamesNeverProduceOutputPaths()throws Exception{
  for(String n:List.of("../out.txt","a/../b.txt","/root.txt","C:\\x.txt","a/./b.txt","a\u0000.txt","a:stream.txt"))rejects(rar5(entry(n,new byte[0])));
  rejects(rar5(entry("a\\b.txt",ascii("1")),entry("a/b.txt",ascii("2"))));
 }
 @Test public void storedEntrySizeMustMatchAndDeclaredBudgetsAreChecked()throws Exception{
  rejects(rar5(entry5("a.txt",ascii("123"),2,4,0,0,new byte[0],0100644)));
  rejects(rar5(entry5("a.txt",ascii("x"),ReaderSession.MAX_SOURCE_BYTES+1,4,128,0,new byte[0],0100644)));
  try(var r=new RarBook(file(rar5(entry5("a.txt",ascii("x"),ZipBook.MAX_ENTRY_BYTES+1,4,128,0,new byte[0],0100644))))){assertTrue(r.explanation("a.txt").contains("comprimida"));}
 }
 @Test public void compressedEncryptedLinksNoChecksumAndNewExtrasRemainIndexOnly()throws Exception{
  for(byte[] e:List.of(entry5("a.txt",ascii("x"),1,4,128,0,new byte[0],0100644),entry5("a.txt",ascii("x"),1,4,0,0,extra(1),0100644),entry5("a.txt",ascii("x"),1,4,0,0,extra(5),0100644),entry5("a.txt",ascii("x"),1,0,0,0,new byte[0],0100644),entry5("a.txt",ascii("x"),1,4,0,0,extra(99),0100644),entry5("a.txt",ascii("x"),1,4,0,0,new byte[0],0120777))) {
   File out=temp.newFolder();try(var r=new RarBook(file(rar5(e)))){assertEquals("",r.item("a.txt").kind());try{r.read("a.txt",out);fail();}catch(IOException expected){}assertEquals(0,out.list().length);}
  }
 }
 @Test public void badPayloadCrcPreservesExistingViewAndRemovesPartialFile()throws Exception{
  byte[] b=rar5(entry("a.txt",ascii("payload")));b[b.length-9]^=1;File f=file(b),out=temp.newFolder();Files.write(new File(out,"entry").toPath(),ascii("anterior"));
  try(var r=new RarBook(f)){try{r.read("a.txt",out);fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("CRC"));}}assertEquals("anterior",ArchiveBookTest.readString(new File(out,"entry").toPath()));assertFalse(new File(out,"entry-part").exists());
 }
 @Test public void sourceHeaderChangesAreRejectedBeforeReplacingView()throws Exception{
  File f=file(rar5(entry("a.txt",ascii("one"))));try(var r=new RarBook(f)){Files.write(f.toPath(),rar5(entry("a.txt",ascii("two"))));File out=temp.newFolder();try{r.read("a.txt",out);fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("cambió"));}assertEquals(0,out.list().length);}
 }
 @Test public void cancellationBeforeIndexAndReadDoesNotPublishParts()throws Exception{
  File f=file(fixture("album-rar5.rar"));Thread.currentThread().interrupt();try{new RarBook(f);fail();}catch(InterruptedIOException expected){}finally{Thread.interrupted();}
  try(var r=new RarBook(f)){File out=temp.newFolder();Thread.currentThread().interrupt();try{r.read("notas/ñ.txt",out);fail();}catch(InterruptedIOException expected){}finally{Thread.interrupted();}assertEquals(0,out.list().length);}
 }
 @Test public void extraRecordBoundariesDuplicatesAndIntegerOverflowAreRejected()throws Exception{
  for(byte[] extra:List.of(new byte[]{0},new byte[]{100,3},join(extra(3),extra(3)),new byte[]{1,(byte)128}))rejects(rar5(entry5("a.txt",ascii("x"),1,4,0,0,extra,0100644)));
  byte[] b=rar5(entry("a.txt",ascii("x")));b[12]=(byte)128;rejects(b);
 }
 @Test public void volumesSolidAndEncryptedHeadersAreExplicitlyRejected()throws Exception{
  for(long flags:new long[]{1,2,4}){byte[] b=join("Rar!\u001a\u0007\u0001\u0000".getBytes(java.nio.charset.StandardCharsets.ISO_8859_1),header5(1,0,vint(flags),new byte[0],new byte[0]),header5(5,0,vint(0),new byte[0],new byte[0]));rejects(b);}
  rejects(join("Rar!\u001a\u0007\u0001\u0000".getBytes(java.nio.charset.StandardCharsets.ISO_8859_1),header5(4,0,new byte[16],new byte[0],new byte[0])));
  rejects(rar5(entry5("a.txt",ascii("x"),1,4,0,8,new byte[0],0100644)));
 }
 @Test public void metadataServicesAreSkippedWithoutBecomingFilesAndEmptyArchiveWorks()throws Exception{
  byte[] service=header5(3,0,ascii("unused bounded service"),new byte[0],ascii("ignored"));File out=temp.newFolder();try(var r=new RarBook(file(rar5(service,entry("notes.txt",ascii("abc")))))){assertEquals(1,r.items().size());assertEquals("abc",ArchiveBookTest.readString(r.read("notes.txt",out).toPath()));}
  try(var r=new RarBook(file(rar5()))){assertTrue(r.items().isEmpty());}
 }
 @Test public void rar7StoreVersionAndPortableUnicodeNamesNeedNoDictionary()throws Exception{
  try(var r=new RarBook(file(rar5(entry5("notas/ñ.txt",ascii("texto"),5,4,1,0,new byte[0],0100644))))){assertEquals("text",r.item("notas/ñ.txt").kind());assertEquals("texto",ArchiveBookTest.readString(r.read("notas/ñ.txt",temp.newFolder()).toPath()));}
 }
 @Test public void headerCountCapStopsHugeIndices()throws Exception{
  var list=new ArrayList<byte[]>();for(int i=0;i<10000;i++)list.add(entry("e"+i+".txt",new byte[0]));rejects(rar5(list.toArray(byte[][]::new)));
 }
 static void fix4(byte[] b,int at){int size=(b[at+5]&255)|((b[at+6]&255)<<8);CRC32 c=new CRC32();c.update(b,at+2,size-2);byte[] crc=le(c.getValue(),2);b[at]=crc[0];b[at+1]=crc[1];}
 @Test public void rar4CompressedEncryptedAndLinksStayIndexOnly()throws Exception{
  for(int mode=0;mode<3;mode++){byte[] b=fixture("album-rar4.cbr");int at=20; // signature7 + main13
   if(mode==0)b[at+25]=0x33;
   if(mode==1)b[at+3]|=4;
   if(mode==2){byte[] attr=le(0120777,4);System.arraycopy(attr,0,b,at+28,4);}
   fix4(b,at);try(var r=new RarBook(file(b))){assertEquals("",r.item("images/10.png").kind());assertFalse(r.item("images/2.png").kind().isEmpty());assertFalse(r.explanation("images/10.png").equals("Entrada catalogada sin lector integrado."));}
  }
 }
 @Test public void rar4PayloadChecksumFailureNeverPublishesView()throws Exception{
  byte[] b=fixture("album-rar4.cbr");b[20+45]^=1;File out=temp.newFolder();try(var r=new RarBook(file(b))){try{r.read("images/10.png",out);fail();}catch(IOException expected){}}assertEquals(0,out.list().length);
 }
 @Test public void rar4VolumesAndHeaderEncryptionAreRejectedWithoutPasswordWork()throws Exception{
  for(int flags:new int[]{1,8,128,256}){byte[] b=fixture("album-rar4.cbr");b[10]=(byte)flags;b[11]=(byte)(flags>>>8);fix4(b,7);rejects(b);}
 }
 @Test public void oversizedStoredSelectionIsRefusedBeforeWritingEvenWhenIndexed()throws Exception{
  int length=(int)ZipBook.MAX_ENTRY_BYTES+1;byte[] n=ascii("large.txt"),body=join(vint(4),vint(length),vint(0100644),le(0,4),vint(0),vint(1),vint(n.length),n);
  byte[] h=join(vint(2),vint(2),vint(length),body),size=vint(h.length),sum=join(size,h);
  byte[] prefix=join("Rar!\u001a\u0007\u0001\u0000".getBytes(java.nio.charset.StandardCharsets.ISO_8859_1),header5(1,0,vint(0),new byte[0],new byte[0]),le(crc(sum),4),sum),end=header5(5,0,vint(0),new byte[0],new byte[0]);File f=temp.newFile();
  try(var raf=new RandomAccessFile(f,"rw")){raf.write(prefix);raf.seek(prefix.length+(long)length);raf.write(end);}
  File out=temp.newFolder();try(var r=new RarBook(f)){assertEquals("text",r.item("large.txt").kind());try{r.read("large.txt",out);fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("64 MiB"));}}assertEquals(0,out.list().length);
 }

}
