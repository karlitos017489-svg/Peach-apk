package com.peach.local;
import android.graphics.Color;
import android.os.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE) @GraphicsMode(GraphicsMode.Mode.NATIVE)
public class RarDecodedReaderTest {
 @Rule public org.junit.rules.TemporaryFolder temp=new org.junit.rules.TemporaryFolder();
 static class OwnEngine extends RarIpcTest.Engine {
  @Override public long[] decode(long id,ParcelFileDescriptor in,ParcelFileDescriptor out,byte[] name,long size,long crc)throws RemoteException{
   try{bytes=RarNativeTest.expected(new String(name,StandardCharsets.UTF_8));}catch(Exception e){throw new AssertionError(e);}return super.decode(id,in,out,name,size,crc);
  }
 }
 @Test public void ownRar4AndRar5RenderCompressedBmpAndTextThroughDescriptorPipeline()throws Exception{
  for(String era:List.of("rar4","rar5")){OwnEngine e=new OwnEngine();var context=new RarIpcTest.ContextDouble(e);String fixture="own-"+era+"-m3.cbr";
   try(var s=new ReaderSession(context,ReaderSessionTest.register(fixture,RarNativeTest.fixture(fixture)),fixture)){
    s.open();assertEquals(0,e.calls);var frame=s.show("page.bmp",0);assertEquals(Color.RED,frame.bitmap().getPixel(10,10));assertEquals(Color.BLUE,frame.bitmap().getPixel(110,10));frame.bitmap().recycle();assertEquals(1,e.calls);
    assertTrue(s.show("notes.txt",0).text().startsWith("Peach: estratos"));assertEquals(2,e.calls);assertEquals(2,context.unbinds);
   }assertEquals(0,new File(context.getCacheDir(),"peach-reader").list().length);
  }
 }
 @Test public void storedEntriesKeepJavaReaderWhileCompatibleCompressedEntriesUseDecoder()throws Exception{
  AtomicInteger calls=new AtomicInteger();File f=temp.newFile();Files.write(f.toPath(),RarNativeTest.fixture("own-rar5-m3.cbr"));
  RarBook.Decoder d=(source,name,expected,crc,out)->{calls.incrementAndGet();throw new IOException("Own controlled decode failure");};
  File stored=temp.newFile();Files.write(stored.toPath(),RarBookTest.rar5(RarBookTest.entry("stored.png",RarNativeTest.expected("images/2.png"))));try(var r=new RarBook(stored,d)){r.read("stored.png",temp.newFolder());assertEquals(0,calls.get());}
  try(var r=new RarBook(f,d)){assertEquals("text",r.item("notes.txt").kind());assertEquals("image",r.item("page.bmp").kind());try{r.read("notes.txt",temp.newFolder());fail();}catch(IOException expected){}assertEquals(1,calls.get());}
 }
 @Test public void unsupportedRar7OversizedDictionaryAndMissingCrcNeverCallNativeDecoder()throws Exception{
  AtomicInteger calls=new AtomicInteger();RarBook.Decoder d=(src,name,size,crc,out)->{calls.incrementAndGet();throw new AssertionError();};
  for(byte[] entry:List.of(RarBookTest.entry5("a.txt",new byte[]{1},10,4,129,0,new byte[0],0100644),RarBookTest.entry5("a.txt",new byte[]{1},10,4,128|(10<<10),0,new byte[0],0100644),RarBookTest.entry5("a.txt",new byte[]{1},10,0,128,0,new byte[0],0100644))){File f=temp.newFile();Files.write(f.toPath(),RarBookTest.rar5(entry));try(var r=new RarBook(f,d)){assertEquals("",r.item("a.txt").kind());try{r.read("a.txt",temp.newFolder());fail();}catch(IOException expected){}}}assertEquals(0,calls.get());
 }
 @Test public void changedIndexIsRejectedBeforeDecoderAndCancelIsForwarded()throws Exception{
  AtomicInteger calls=new AtomicInteger(),cancel=new AtomicInteger();File f=temp.newFile();Files.write(f.toPath(),RarNativeTest.fixture("own-rar4-m3.cbr"));RarBook.Decoder d=new RarBook.Decoder(){public File decode(File src,String name,long size,long crc,File out){calls.incrementAndGet();throw new AssertionError();}public void cancel(){cancel.incrementAndGet();}};
  try(var r=new RarBook(f,d)){Files.write(f.toPath(),RarNativeTest.fixture("own-rar5-m3.cbr"));try{r.read("notes.txt",temp.newFolder());fail();}catch(IOException expected){}r.cancel();assertEquals(1,cancel.get());assertEquals(0,calls.get());}
 }

 @Test public void solidRar5RendersExactUnicodeTextAndBmpThroughExistingReader()throws Exception{
  RarIpcTest.Engine engine=new RarIpcTest.Engine(){@Override public long[] decode(long id,ParcelFileDescriptor in,ParcelFileDescriptor out,byte[] name,long size,long crc)throws RemoteException{
   try{bytes=RarSolidNativeTest.expected(new String(name,StandardCharsets.UTF_8));}catch(Exception e){throw new AssertionError(e);}return super.decode(id,in,out,name,size,crc);
  }};
  var context=new RarIpcTest.ContextDouble(engine);
  try(var session=new ReaderSession(context,ReaderSessionTest.register("own-solid.cbr",RarSolidTest.fixture("own-solid-rar5-m3.cbr")),"own-solid.cbr")){
   session.open();assertEquals(0,engine.calls);assertEquals(4,session.items().size());
   assertTrue(session.show("02/capa-日本語.txt",0).text().startsWith("Peach: estratos"));assertEquals(1,engine.calls);
   var frame=session.show("03/imagen.bmp",0);assertEquals(Color.RED,frame.bitmap().getPixel(10,10));assertEquals(Color.BLUE,frame.bitmap().getPixel(110,10));frame.bitmap().recycle();assertEquals(2,engine.calls);assertEquals(2,context.unbinds);
  }
  assertEquals(0,new File(context.getCacheDir(),"peach-reader").list().length);
 }
 @Test public void incompatibleSolidPredecessorFailsReaderOpenBeforeServiceBinding()throws Exception{
  var engine=new RarIpcTest.Engine();var context=new RarIpcTest.ContextDouble(engine);
  byte[] invalid=RarSolidTest.archive(4,RarSolidTest.entry("a.bin",ZipBook.MAX_ENTRY_BYTES+1,3,false),RarSolidTest.entry("notes.txt",1,3,true));
  try(var session=new ReaderSession(context,ReaderSessionTest.register("invalid-solid.cbr",invalid),"invalid-solid.cbr")){
   try{session.open();fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("64 MiB"));}assertEquals(0,engine.calls);
  }
  assertEquals(0,new File(context.getCacheDir(),"peach-reader").list().length);
 }
}
