package com.peach.local;
import android.content.*;
import android.os.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.zip.CRC32;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE)
public class RarIpcTest {
 @Rule public org.junit.rules.TemporaryFolder temp=new org.junit.rules.TemporaryFolder();
 static class ContextDouble extends ContextWrapper {
  final IRarEngine engine;int binds,unbinds;boolean allowed=true;
  ContextDouble(IRarEngine e){super(RuntimeEnvironment.getApplication());engine=e;}
  @Override public Context getApplicationContext(){return this;}
  @Override public boolean bindService(Intent i,ServiceConnection c,int f){binds++;assertEquals(RarService.class.getName(),i.getComponent().getClassName());assertNull(i.getExtras());if(allowed)c.onServiceConnected(i.getComponent(),engine.asBinder());return allowed;}
  @Override public void unbindService(ServiceConnection c){unbinds++;}
 }
 static class Engine extends IRarEngine.Stub {
  byte[] bytes="own plain payload".getBytes(java.nio.charset.StandardCharsets.UTF_8);long[] result={0,1024,0};int calls,cancels;CountDownLatch entered=new CountDownLatch(1),released=new CountDownLatch(1);boolean block;String name;long job;
  public long[] decode(long id,ParcelFileDescriptor source,ParcelFileDescriptor output,byte[] name,long size,long crc)throws RemoteException{
   calls++;job=id;this.name=new String(name,java.nio.charset.StandardCharsets.UTF_8);entered.countDown();
   if(block)try{if(!released.await(5,TimeUnit.SECONDS))throw new AssertionError("No cancellation");}catch(InterruptedException e){throw new AssertionError(e);}
   try(var out=new ParcelFileDescriptor.AutoCloseOutputStream(output)){out.write(bytes);}catch(IOException e){throw new RemoteException();}return result;
  }
  public void cancel(long id){assertEquals(job,id);cancels++;released.countDown();}
 }
 static long crc(byte[] b){var c=new CRC32();c.update(b);return c.getValue();}
 File source()throws Exception{File f=temp.newFile();Files.write(f.toPath(),new byte[20]);return f;}
 @Test public void descriptorOnlyCallPublishesAfterIndependentSizeAndCrcAndUnbinds()throws Exception{
  Engine e=new Engine();ContextDouble c=new ContextDouble(e);File dir=temp.newFolder();var client=new RarClient(c);File out=client.decode(source(),"notes.txt",e.bytes.length,crc(e.bytes),dir);assertArrayEquals(e.bytes,Files.readAllBytes(out.toPath()));assertEquals("entry",out.getName());assertEquals("notes.txt",e.name);assertTrue(e.job>0);assertEquals(1,c.binds);assertEquals(1,c.unbinds);assertFalse(new File(dir,"entry-part").exists());assertEquals(0,e.cancels);
 }
 @Test public void wrongSizeOrCrcNeverReplacesExistingEntryAndAlwaysCleansPart()throws Exception{
  for(boolean badCrc:new boolean[]{false,true}){Engine e=new Engine();ContextDouble c=new ContextDouble(e);File dir=temp.newFolder();Files.write(new File(dir,"entry").toPath(),new byte[]{42});
   try{new RarClient(c).decode(source(),"notes.txt",badCrc?e.bytes.length:e.bytes.length+1,badCrc?0:crc(e.bytes),dir);fail();}catch(IOException expected){}
   assertArrayEquals(new byte[]{42},Files.readAllBytes(new File(dir,"entry").toPath()));assertFalse(new File(dir,"entry-part").exists());assertEquals(1,c.unbinds);
  }
 }
 @Test public void nativeFailureAndUnreleasedAllocationAreRejectedWithoutPublishing()throws Exception{
  for(long[] r:new long[][]{{4,1024,0},{0,1024,1},{0,RarNative.MAX_HEAP+1,0}}){Engine e=new Engine();e.result=r;ContextDouble c=new ContextDouble(e);File dir=temp.newFolder();try{new RarClient(c).decode(source(),"notes.txt",e.bytes.length,crc(e.bytes),dir);fail();}catch(IOException expected){}assertEquals(0,dir.list().length);assertEquals(1,c.unbinds);}
 }
 @Test public void connectionRefusedAndCancelledBeforeBindDoNotProduceOutput()throws Exception{
  Engine e=new Engine();ContextDouble c=new ContextDouble(e);c.allowed=false;File d=temp.newFolder();try{new RarClient(c).decode(source(),"notes.txt",e.bytes.length,crc(e.bytes),d);fail();}catch(IOException expected){}assertEquals(0,e.calls);assertEquals(0,d.list().length);
  RarClient cancelled=new RarClient(c);cancelled.cancel();try{cancelled.decode(source(),"notes.txt",e.bytes.length,crc(e.bytes),d);fail();}catch(InterruptedIOException expected){}assertEquals(1,c.binds);
 }
 @Test public void cancellingActiveRequestSendsOnlyItsIdAndPreservesPreviousOutput()throws Exception{
  Engine e=new Engine();e.block=true;ContextDouble c=new ContextDouble(e);RarClient client=new RarClient(c);File d=temp.newFolder(),f=source();Files.write(new File(d,"entry").toPath(),new byte[]{42});ExecutorService worker=Executors.newSingleThreadExecutor();
  try{Future<?> pending=worker.submit(()->{try{client.decode(f,"notes.txt",e.bytes.length,crc(e.bytes),d);throw new AssertionError();}catch(InterruptedIOException expected){}catch(IOException x){throw new AssertionError(x);}});assertTrue(e.entered.await(5,TimeUnit.SECONDS));client.cancel();pending.get(5,TimeUnit.SECONDS);assertTrue(e.cancels>=1);assertArrayEquals(new byte[]{42},Files.readAllBytes(new File(d,"entry").toPath()));assertEquals(1,c.unbinds);}finally{e.released.countDown();worker.shutdownNow();assertTrue(worker.awaitTermination(5,TimeUnit.SECONDS));}
 }
 @Test public void watchdogRejectsEvenSuccessReturnedAfterDeadline()throws Exception{
  Engine e=new Engine();e.block=true;ContextDouble c=new ContextDouble(e);File d=temp.newFolder();try{new RarClient(c,1).decode(source(),"notes.txt",e.bytes.length,crc(e.bytes),d);fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("plazo"));}assertTrue(e.cancels>=1);assertEquals(0,d.list().length);assertEquals(1,c.unbinds);
 }
 @Test public void statusMessagesAreControlledConstantsWithoutNativePaths()throws Exception{
  for(long status:new long[]{1,2,3,4,5,6,7,8,9,999})try{RarClient.validate(new long[]{status,0,0});fail();}catch(IOException expected){assertFalse(expected.getMessage().contains("https"));}
  for(long[] result:new long[][]{null,new long[0],new long[]{0,-1,0},new long[]{0,0,1}})try{RarClient.validate(result);fail();}catch(IOException expected){}
 }
}
