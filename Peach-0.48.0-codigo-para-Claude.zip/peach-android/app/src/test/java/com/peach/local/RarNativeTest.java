package com.peach.local;
import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.CRC32;
import org.junit.*;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;
/** Real pinned C engine on Linux; not Android process/Binder execution. */
public class RarNativeTest {
 @Rule public TemporaryFolder temp=new TemporaryFolder();
 static native int openFd(String path,boolean write);static native void closeFd(int fd);
 @BeforeClass public static void load(){String p=System.getProperty("peach.rar.host.library");assertNotNull("Build scripts/native/build-rar.py --targets host and set PEACH_RAR_HOST_LIBRARY",p);System.load(p);}
 static byte[] fixture(String name)throws Exception{try(var in=RarNativeTest.class.getClassLoader().getResourceAsStream("rar039/"+name)){assertNotNull(in);return in.readAllBytes();}}
 static byte[] expected(String name)throws Exception{if(name.equals("page.bmp"))try(var in=RarNativeTest.class.getClassLoader().getResourceAsStream("rar039/page.bmp")){return in.readAllBytes();}if(name.equals("notes.txt"))return "Peach: estratos sedimentarios y minerales.\n".repeat(2000).getBytes(StandardCharsets.UTF_8);try(var in=RarNativeTest.class.getClassLoader().getResourceAsStream("media/small.png")){return in.readAllBytes();}}
 static long crc(byte[] bytes){var c=new CRC32();c.update(bytes);return c.getValue();}
 File file(byte[] b)throws Exception{File f=temp.newFile();Files.write(f.toPath(),b);return f;}
 long[] decode(File source,File out,String name,byte[] expected,long limit)throws Exception{
  int in=openFd(source.getAbsolutePath(),false),output=openFd(out.getAbsolutePath(),true);assertTrue(in>=0);assertTrue(output>=0);try{return RarNative.decode(in,output,name.getBytes(StandardCharsets.UTF_8),expected.length,crc(expected),limit);}finally{closeFd(in);closeFd(output);}
 }
 @Test public void sixOfficiallyCompressedOwnArchivesProduceExactOriginalTextAndPng()throws Exception{
  for(String era:List.of("rar4","rar5"))for(int method:List.of(1,3,5))for(String name:List.of("notes.txt","images/2.png","images/10.png","page.bmp")){
   byte[] bytes=expected(name);File out=temp.newFile();long[] r=decode(file(fixture("own-"+era+"-m"+method+".cbr")),out,name,bytes,RarNative.MAX_HEAP);
   assertEquals(Arrays.toString(r),0,r[0]);assertTrue(r[1]>0);assertEquals(0,r[2]);assertArrayEquals(bytes,Files.readAllBytes(out.toPath()));
  }
 }
 @Test public void tooSmallAllocatorBudgetFailsBeforeAllocatingDictionaryAndFreesEverything()throws Exception{
  long[] r=decode(file(fixture("budget-rar5.cbr")),temp.newFile(),"large.txt","Peach: estratos sedimentarios y minerales.\n".repeat(100000).getBytes(StandardCharsets.UTF_8),1024*1024);assertEquals(4,r[0]);assertTrue(r[1]<=1024*1024);assertEquals(0,r[2]);
 }
 @Test public void independentExpectedChecksumAndLengthRejectIncorrectOutput()throws Exception{
  File in=file(fixture("own-rar5-m3.cbr"));byte[] bad=expected("notes.txt");bad[0]^=1;long[] r=decode(in,temp.newFile(),"notes.txt",bad,RarNative.MAX_HEAP);assertEquals(3,r[0]);assertEquals(0,r[2]);
  r=decode(in,temp.newFile(),"notes.txt",new byte[10],RarNative.MAX_HEAP);assertEquals(3,r[0]);assertEquals(0,r[2]);
 }
 @Test public void malformedTruncatedAndMissingEntriesReturnControlledStatusesWithoutLeaks()throws Exception{
  for(byte[] input:List.of(new byte[20],Arrays.copyOf(fixture("own-rar5-m3.cbr"),50))){long[] r=decode(file(input),temp.newFile(),"notes.txt",expected("notes.txt"),RarNative.MAX_HEAP);assertNotEquals(0,r[0]);assertEquals(0,r[2]);}
  long[] r=decode(file(fixture("own-rar5-m3.cbr")),temp.newFile(),"missing.txt",expected("notes.txt"),RarNative.MAX_HEAP);assertEquals(2,r[0]);assertEquals(0,r[2]);
 }
 @Test public void repeatedReadsDoNotReuseDictionaryOrPreviousFailureState()throws Exception{
  File f=file(fixture("own-rar4-m5.cbr"));for(int i=0;i<15;i++){long[] r=decode(f,temp.newFile(),"notes.txt",expected("notes.txt"),RarNative.MAX_HEAP);assertEquals(0,r[0]);assertEquals(0,r[2]);}
 }
 @Test public void boundedJavaIndexAndNativeDecodeComposeWithNoArchiveChosenOutputPath()throws Exception{
  File f=file(fixture("own-rar5-m3.cbr")),dir=temp.newFolder();RarBook.Decoder decoder=(src,name,size,crc,out)->{File part=new File(out,"entry-part");byte[] expected;try{expected=expected(name);long[] r=decode(src,part,name,expected,RarNative.MAX_HEAP);RarClient.validate(r);RarClient.verify(part,size,crc);}catch(Exception e){throw new IOException(e);}File result=new File(out,"entry");if(!part.renameTo(result))throw new IOException();return result;};
  try(var r=new RarBook(f,decoder)){assertEquals("text",r.item("notes.txt").kind());assertArrayEquals(expected("notes.txt"),Files.readAllBytes(r.read("notes.txt",dir).toPath()));assertEquals(Set.of("entry"),Set.of(dir.list()));}
 }
}
