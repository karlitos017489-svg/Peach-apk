package com.peach.local;
import android.graphics.Color;
import java.io.*;
import java.nio.file.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE) @GraphicsMode(GraphicsMode.Mode.NATIVE)
public class RarReaderTest {
 @Test public void localRar4AndRar5ImagesTextEmptyAndNavigationCleanTheirCache()throws Exception{
  var context=RuntimeEnvironment.getApplication();for(String n:java.util.List.of("album-rar4.cbr","album-rar5.rar")){
   try(var s=new ReaderSession(context,ReaderSessionTest.register(n,RarBookTest.fixture(n)),n)){
    s.open();assertTrue(s.archive());assertEquals("images/2.png",s.firstEntry());var first=s.show("",0);assertEquals(2,first.count());assertEquals(Color.RED,first.bitmap().getPixel(10,10));first.bitmap().recycle();assertEquals("images/10.png",s.adjacent("images/2.png",1));
    assertTrue(s.show(n.contains("rar4")?"notes.txt":"notas/ñ.txt",0).text().contains("estratos"));assertEquals("",s.show("empty.txt",0).text());
    try{s.show("nested.rar",0);fail();}catch(IOException expected){}assertEquals("",s.show("empty.txt",0).text());
   }assertEquals(0,new File(context.getCacheDir(),"peach-reader").list().length);
  }
 }
 @Test @Config(sdk=26) public void api26StoredCbrUsesExistingStaticImageDecoder()throws Exception{
  try(var s=new ReaderSession(RuntimeEnvironment.getApplication(),ReaderSessionTest.register("rar26",RarBookTest.fixture("album-rar4.cbr")),"comic.cbr")){s.open();var f=s.show("",0);assertEquals(120,f.bitmap().getWidth());assertEquals(Color.BLUE,f.bitmap().getPixel(110,10));f.bitmap().recycle();}
 }
 @Test public void pdfEntryUsesExplicitTestBackendAndKeepsPdfPageContract()throws Exception{
  byte[] b=RarBookTest.rar5(RarBookTest.entry("document.pdf",RarBookTest.ascii("own PDF backend double")));int[] closed={0};
  try(var s=new ReaderSession(RuntimeEnvironment.getApplication(),ReaderSessionTest.register("rarpdf",b),"docs.rar",file->new ReaderSession.Pages(){public int count(){return 2;}public android.graphics.Bitmap render(int n,int edge){return android.graphics.Bitmap.createBitmap(2,2,android.graphics.Bitmap.Config.ARGB_8888);}public void close(){closed[0]++;}})){s.open();var f=s.show("document.pdf",99);assertEquals(1,f.page());assertEquals(DocumentRules.PDF,f.kind());f.bitmap().recycle();}assertEquals(1,closed[0]);
 }
 @Test public void compressedOnlyArchiveExplainsLimitWhileKeepingItsIndexAvailable()throws Exception{
  byte[] b=RarBookTest.rar5(RarBookTest.entry5("notes.txt",new byte[]{1},10,4,129,0,new byte[0],0100644));
  try(var s=new ReaderSession(RuntimeEnvironment.getApplication(),ReaderSessionTest.register("rarcompressed",b),"a.cbr")){s.open();assertEquals(1,s.items().size());try{s.show("",0);fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("RAR7"));}try{s.show("notes.txt",0);fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("RAR7"));}}
 }
 @Test public void invalidSourceOrCancellationCleansPrivateSessionWithoutNetwork()throws Exception{
  var c=RuntimeEnvironment.getApplication();for(boolean cancel:new boolean[]{false,true})try(var s=new ReaderSession(c,ReaderSessionTest.register("bad-rar",new byte[20]),"bad.rar")){if(cancel)s.cancel();try{s.open();fail();}catch(IOException expected){}}
  assertEquals(0,new File(c.getCacheDir(),"peach-reader").list().length);
 }
}
