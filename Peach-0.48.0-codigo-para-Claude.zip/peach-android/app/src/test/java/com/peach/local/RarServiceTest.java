package com.peach.local;
import android.content.Intent;
import android.os.*;
import java.io.*;
import java.util.concurrent.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE)
public class RarServiceTest {
 public static class OwnService extends RarService {
  int calls,stops;long[] result={0,1024,0};CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);boolean block;
  @Override protected long[] decodeNative(int in,int out,byte[] name,long size,long crc){calls++;entered.countDown();if(block)try{release.await(5,TimeUnit.SECONDS);}catch(InterruptedException x){throw new AssertionError(x);}return result;}
  @Override protected void stopDecoder(){stops++;release.countDown();}
 }
 static class OwnController implements AutoCloseable {final org.robolectric.android.controller.ServiceController<OwnService> value=Robolectric.buildService(OwnService.class).create();OwnService get(){return value.get();}public void close(){value.destroy();}}
 @Rule public org.junit.rules.TemporaryFolder temp=new org.junit.rules.TemporaryFolder();
 IRarEngine binder(OwnService s){return IRarEngine.Stub.asInterface(s.onBind(new Intent()));}
 long[] call(IRarEngine e,long id)throws Exception{try(var in=ParcelFileDescriptor.open(temp.newFile(),ParcelFileDescriptor.MODE_READ_ONLY);var out=ParcelFileDescriptor.open(temp.newFile(),ParcelFileDescriptor.MODE_READ_WRITE)){return e.decode(id,in,out,new byte[]{'a'},1,0);}}
 @Test public void admittedRequestCallsOnlyDecoderAndCancelledBeforeRunDoesNotStart()throws Exception{
  try(var c=new OwnController()){var s=c.get();var e=binder(s);assertEquals(0,call(e,1)[0]);assertEquals(1,s.calls);e.cancel(2);assertEquals(7,call(e,2)[0]);assertEquals(1,s.calls);}
 }
 @Test public void invalidEnvelopeNeverLoadsNativeCode()throws Exception{
  try(var c=new OwnController()){var s=c.get();var e=binder(s);assertEquals(1,e.decode(-1,null,null,new byte[0],-1,-1)[0]);assertEquals(0,s.calls);}
 }
 @Test public void cancellationOnlyStopsMatchingActiveJobAndDestroyStopsActiveJob()throws Exception{
  try(var c=new OwnController()){var s=c.get();s.block=true;var e=binder(s);ExecutorService worker=Executors.newSingleThreadExecutor();try{Future<long[]> f=worker.submit(()->call(e,42));assertTrue(s.entered.await(5,TimeUnit.SECONDS));e.cancel(41);assertEquals(0,s.stops);e.cancel(42);f.get(5,TimeUnit.SECONDS);assertEquals(1,s.stops);}finally{s.release.countDown();worker.shutdownNow();assertTrue(worker.awaitTermination(5,TimeUnit.SECONDS));}}
 }
 @Test public void nativeLeakFlagStopsServiceToAvoidReusingAllocatorState()throws Exception{
  try(var c=new OwnController()){var s=c.get();s.result=new long[]{1,1024,1};call(binder(s),1);assertEquals(1,s.stops);}
 }
}
