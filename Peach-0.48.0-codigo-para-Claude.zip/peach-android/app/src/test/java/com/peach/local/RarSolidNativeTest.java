package com.peach.local;
import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.junit.*;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

/** Actual unchanged C/JNI Linux decoder. Not Android ABI/Binder execution. */
public class RarSolidNativeTest {
 @Rule public TemporaryFolder temp=new TemporaryFolder();
 @BeforeClass public static void load(){RarNativeTest.load();}
 static byte[] expected(String name)throws Exception{
  byte[] note=RarNativeTest.expected("notes.txt");
  if(name.endsWith(".bmp"))return RarNativeTest.expected("page.bmp");
  if(name.startsWith("02/"))return RarBookTest.join(note,"Segunda capa.\n".getBytes(StandardCharsets.UTF_8));
  if(name.startsWith("04/"))return RarBookTest.join(note,"Ultima capa.\n".getBytes(StandardCharsets.UTF_8));
  return note;
 }
 File file(String fixture)throws Exception{File f=temp.newFile();Files.write(f.toPath(),RarSolidTest.fixture(fixture));return f;}
 RarBook.Decoder decoder(){return (src,name,size,crc,dir)->{
  File part=new File(dir,"entry-part"),target=new File(dir,"entry");boolean done=false;
  try{long[] r=RarUnicodeNativeTest.decode(src,part,name,expected(name));RarClient.validate(r);assertEquals(0,r[2]);RarClient.verify(part,size,crc);if(!part.renameTo(target))throw new IOException();done=true;return target;}
  catch(Exception e){throw new IOException(e);}finally{if(!done)part.delete();}
 };}
 @Test public void levels135ReadEveryEntryInNaturalAndReverseOrderWithExactBytes()throws Exception{
  for(int level:List.of(1,3,5)){
   File src=file("own-solid-rar5-m"+level+".cbr"),dir=temp.newFolder();byte[] original=Files.readAllBytes(src.toPath());
   try(var r=new RarBook(src,decoder())){
    var items=new ArrayList<>(r.items());for(int pass=0;pass<2;pass++){for(var item:items)assertArrayEquals(expected(item.name()),Files.readAllBytes(r.read(item.name(),dir).toPath()));Collections.reverse(items);}
   }
   assertArrayEquals(original,Files.readAllBytes(src.toPath()));assertEquals(Set.of("entry"),Set.of(dir.list()));
  }
 }
 @Test public void repeatedSolidAndIndependentReadsResetDictionaryAndTrackedAllocations()throws Exception{
  File solid=file("own-solid-rar5-m3.cbr"),independent=temp.newFile();Files.write(independent.toPath(),RarNativeTest.fixture("own-rar5-m3.cbr"));
  for(int i=0;i<5;i++)for(String name:List.of("01/notas-ñ.txt","03/imagen.bmp","notes.txt")){
   byte[] b=name.equals("notes.txt")?RarNativeTest.expected("notes.txt"):expected(name);long[] result=RarUnicodeNativeTest.decode(name.equals("notes.txt")?independent:solid,temp.newFile(),name,b);assertEquals(Arrays.toString(result),0,result[0]);assertEquals(0,result[2]);
  }
 }
 @Test public void predecessorCrcIsNotClaimedVerifiedButSelectedCrcMustPass()throws Exception{
  File src=file("bad-first-crc.cbr"),dir=temp.newFolder();
  try(var r=new RarBook(src,decoder())){
   assertArrayEquals(expected("01/notas-ñ.txt"),Files.readAllBytes(r.read("01/notas-ñ.txt",dir).toPath()));
   byte[] previous=Files.readAllBytes(new File(dir,"entry").toPath());try{r.read("03/imagen.bmp",dir);fail();}catch(IOException expected){}
   assertArrayEquals(previous,Files.readAllBytes(new File(dir,"entry").toPath()));assertFalse(new File(dir,"entry-part").exists());
  }
  try(var r=new RarBook(file("bad-last-crc.cbr"),decoder())){try{r.read("01/notas-ñ.txt",temp.newFolder());fail();}catch(IOException expected){}}
 }
 @Test public void damagedSelectedCompressedPayloadNeverReplacesPreviousView()throws Exception{
  File src=file("bad-first-data.cbr"),dir=temp.newFolder();byte[] original=Files.readAllBytes(src.toPath());Files.write(new File(dir,"entry").toPath(),RarBookTest.ascii("previous"));
  try(var r=new RarBook(src,decoder())){try{r.read("03/imagen.bmp",dir);fail();}catch(IOException expected){}}
  assertEquals("previous",ArchiveBookTest.readString(new File(dir,"entry").toPath()));assertEquals(Set.of("entry"),Set.of(dir.list()));assertArrayEquals(original,Files.readAllBytes(src.toPath()));
 }
 @Test public void cancellationBeforeReadKeepsViewAndDoesNotStartDecoding()throws Exception{
  File src=file("own-solid-rar5-m3.cbr"),dir=temp.newFolder();Files.write(new File(dir,"entry").toPath(),RarBookTest.ascii("previous"));
  try(var r=new RarBook(src,decoder())){Thread.currentThread().interrupt();try{r.read("01/notas-ñ.txt",dir);fail();}catch(InterruptedIOException expected){}finally{Thread.interrupted();}}
  assertEquals("previous",ArchiveBookTest.readString(new File(dir,"entry").toPath()));assertEquals(Set.of("entry"),Set.of(dir.list()));
 }
 @Test public void dictionaryReconstructionStillHonorsNativeAllocatorBudget()throws Exception{
  File src=file("own-solid-rar5-m3.cbr"),out=temp.newFile();int in=RarNativeTest.openFd(src.getAbsolutePath(),false),fd=RarNativeTest.openFd(out.getAbsolutePath(),true);
  try{byte[] b=expected("01/notas-ñ.txt");long[] result=RarNative.decode(in,fd,"01/notas-ñ.txt".getBytes(StandardCharsets.UTF_8),b.length,RarNativeTest.crc(b),1024*1024);assertEquals(4,result[0]);assertTrue(result[1]<=1024*1024);assertEquals(0,result[2]);}finally{RarNativeTest.closeFd(in);RarNativeTest.closeFd(fd);}
 }
}
