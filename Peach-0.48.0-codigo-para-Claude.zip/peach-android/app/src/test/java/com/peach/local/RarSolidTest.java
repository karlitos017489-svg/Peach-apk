package com.peach.local;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import org.junit.*;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

public class RarSolidTest {
 @Rule public TemporaryFolder temp=new TemporaryFolder();
 static final RarBook.Decoder UNUSED=(s,n,z,c,d)->{throw new IOException("Decoder must not start");};
 static byte[] fixture(String n)throws Exception{try(var in=RarSolidTest.class.getClassLoader().getResourceAsStream("rar041/"+n)){assertNotNull(in);return in.readAllBytes();}}
 static byte[] archive(long flags,byte[]... entries)throws Exception{return RarBookTest.join(RarBookTest.ascii("Rar!\u001a\u0007\u0001\u0000"),RarBookTest.header5(1,0,RarBookTest.vint(flags),new byte[0],new byte[0]),RarBookTest.join(entries),RarBookTest.header5(5,0,RarBookTest.vint(0),new byte[0],new byte[0]));}
 static byte[] entry(String n,long size,int dictionary,boolean linked)throws Exception{return RarBookTest.entry5(n,new byte[]{1},size,4,128|(linked?64:0)|((long)dictionary<<10),0,new byte[0],0100644);}
 File file(byte[] b)throws Exception{File f=temp.newFile();Files.write(f.toPath(),b);return f;}
 void rejects(byte[] b)throws Exception{try(var r=new RarBook(file(b),UNUSED)){fail("Invalid solid archive accepted");}catch(IOException expected){}}
 @Test public void officialSolidSamplesIndexAndSortAllCompatibleNames()throws Exception{
  for(int method:List.of(1,3,5))try(var r=new RarBook(file(fixture("own-solid-rar5-m"+method+".cbr")),UNUSED)){
   assertEquals(List.of("01/notas-ñ.txt","02/capa-日本語.txt","03/imagen.bmp","04/final.txt"),r.items().stream().map(ArchiveBook.Item::name).toList());
   for(var i:r.items())assertFalse(i.kind().isEmpty());
  }
 }
 @Test public void solidCannotBeOpenedWithoutIsolatedDecoder()throws Exception{try(var r=new RarBook(file(fixture("own-solid-rar5-m3.cbr")))){fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("motor aislado"));}}
 @Test public void rar4SolidStillRejectsBeforeNative()throws Exception{byte[] b=RarBookTest.fixture("album-rar4.cbr");b[10]|=8;RarBookTest.fix4(b,7);rejects(b);}
 @Test public void firstFileCannotDependOnMissingDictionary()throws Exception{rejects(archive(4,entry("a.txt",1,3,true)));}
 @Test public void fileSolidFlagWithoutSolidContainerIsNotReadable()throws Exception{try(var r=new RarBook(file(archive(0,entry("a.txt",1,3,true))),UNUSED)){assertTrue(r.item("a.txt").kind().isEmpty());}}
 @Test public void zeroAndStoredMembersAreNotSentToNativeSolidSkipping()throws Exception{
  rejects(archive(4,entry("empty.txt",0,3,false)));
  rejects(archive(4,RarBookTest.entry("stored.txt",new byte[]{1})));
 }
 @Test public void eachMemberIsCappedEvenIfItHasNoViewer()throws Exception{rejects(archive(4,entry("opaque.bin",ZipBook.MAX_ENTRY_BYTES+1,3,false),entry("a.txt",1,3,true)));}
 @Test public void cumulativeDeclaredSolidExpansionCannotExceed128MiB()throws Exception{
  long n=48L*1024*1024;rejects(archive(4,entry("a.txt",n,3,false),entry("b.bin",n,3,true),entry("c.txt",n,3,true)));
  try(var r=new RarBook(file(archive(4,entry("a.txt",64L*1024*1024,3,false),entry("b.txt",64L*1024*1024,3,true))),UNUSED)){assertEquals(2,r.items().size());}
 }
 @Test public void solidDictionaryIsLimitedTo64MiB()throws Exception{
  for(int dict:new int[]{0,3,7,8,9})try(var r=new RarBook(file(archive(4,entry("a.txt",1,dict,false),entry("b.txt",1,dict,true))),UNUSED)){assertEquals(2,r.items().size());}
  for(int dict:new int[]{10,11})rejects(archive(4,entry("a.txt",1,dict,false)));
 }
 @Test public void dictionaryChangesRejectBeforeAnyMemberIsDecoded()throws Exception{rejects(archive(4,entry("a.txt",1,3,false),entry("b.txt",1,4,true)));}
 @Test public void incompatiblePredecessorMakesWholeSolidContainerUnavailable()throws Exception{
  for(byte[] e:List.of(RarBookTest.entry5("bad.bin",new byte[]{1},1,0,128,0,new byte[0],0100644),RarBookTest.entry5("bad.bin",new byte[]{1},1,4,128,0,RarBookTest.extra(1),0100644),RarBookTest.entry5("bad.bin",new byte[]{1},1,4,128,0,RarBookTest.extra(5),0100644),RarBookTest.entry5("bad.bin",new byte[]{1},1,4,128,0,RarBookTest.extra(99),0100644),RarBookTest.entry5("bad.bin",new byte[]{1},1,4,128,0,new byte[0],0120777)))rejects(archive(4,e,entry("a.txt",1,3,true)));
 }
 @Test public void unknownCompressionAndChildFlagsAreNotEnabledBySolidAdmission()throws Exception{
  for(long comp:new long[]{129,6L<<7})rejects(archive(4,RarBookTest.entry5("a.txt",new byte[]{1},1,4,comp,0,new byte[0],0100644)));
  rejects(archive(4,RarBookTest.entry5("a.txt",new byte[]{1},1,4,128,32,new byte[0],0100644)));
 }
 @Test public void unsafeOrDuplicateNamesRemainRejectedInSolidContainer()throws Exception{
  for(String n:List.of("../a.txt","/a.txt","a:private.txt"))rejects(archive(4,entry(n,1,3,false)));
  rejects(archive(4,entry("a.txt",1,3,false),entry("a.txt",1,3,true)));
 }
 @Test public void togglingOnlyMainSolidFlagInvalidatesOpenIndex()throws Exception{
  byte[] e=entry("a.txt",1,3,false);File src=file(archive(4,e)),dir=temp.newFolder();Files.write(new File(dir,"entry").toPath(),RarBookTest.ascii("previous"));
  try(var r=new RarBook(src,UNUSED)){Files.write(src.toPath(),archive(0,e));try{r.read("a.txt",dir);fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("cambió"));}}
  assertEquals("previous",ArchiveBookTest.readString(new File(dir,"entry").toPath()));
 }
 @Test public void cancellationBeforeSolidIndexNeverStartsMotor()throws Exception{
  File src=file(fixture("own-solid-rar5-m3.cbr"));Thread.currentThread().interrupt();try{new RarBook(src,UNUSED);fail();}catch(InterruptedIOException expected){}finally{Thread.interrupted();}
 }

 @Test public void opaqueServiceBlocksCannotBypassSolidDeclaredExpansionBudget()throws Exception{
  for(byte[] data:List.of(new byte[0],new byte[]{1,2,3})){
   byte[] service=RarBookTest.header5(3,0,RarBookTest.ascii("opaque"),new byte[0],data);
   rejects(archive(4,service,entry("a.txt",1,3,false)));
  }
 }
}
