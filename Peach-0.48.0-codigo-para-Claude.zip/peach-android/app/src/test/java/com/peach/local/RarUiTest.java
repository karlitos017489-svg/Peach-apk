package com.peach.local;
import android.content.Intent;
import android.os.Looper;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import java.util.concurrent.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowDialog;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land") @GraphicsMode(GraphicsMode.Mode.NATIVE) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class RarUiTest {
 LibraryDatabase db;
 @Before public void setup(){var c=RuntimeEnvironment.getApplication();db=androidx.room.Room.inMemoryDatabaseBuilder(c,LibraryDatabase.class).allowMainThreadQueries().setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",db);androidx.work.testing.WorkManagerTestInitHelper.initializeTestWorkManager(c,new androidx.work.Configuration.Builder().setExecutor(Runnable::run).setTaskExecutor(Runnable::run).build());}
 @After public void close()throws Exception{idle();androidx.work.testing.WorkManagerTestInitHelper.closeWorkDatabase();db.close();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);}
 void idle()throws Exception{for(int i=0;i<2;i++){LibraryDatabase.IO.submit(()->{}).get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}}
 void await(ReaderActivity a)throws Exception{idle();Future<?> f=org.robolectric.util.ReflectionHelpers.getField(a,"pending");assertNotNull(f);f.get(30,TimeUnit.SECONDS);idle();}
 void closed(ReaderActivity a)throws Exception{ExecutorService e=org.robolectric.util.ReflectionHelpers.getField(a,"worker");assertTrue(e.awaitTermination(30,TimeUnit.SECONDS));idle();}
 void media(String id,byte[] b){MediaEntry m=new MediaEntry();m.id=id;m.name="comic.cbr";m.title="Own RAR";m.mediaType=MediaRules.ARCHIVE;m.uri=ReaderSessionTest.register(id,b).toString();db.library().insertMedia(m);}
 Intent intent(String id){return new Intent(RuntimeEnvironment.getApplication(),ReaderActivity.class).putExtra("mediaId",id);}
 <T> T view(View v,Class<T> c){if(c.isInstance(v))return c.cast(v);if(v instanceof ViewGroup g)for(int i=0;i<g.getChildCount();i++){T f=view(g.getChildAt(i),c);if(f!=null)return f;}return null;}
 AlertDialog contents(ReaderActivity a){a.findViewById(R.id.readerContents).performClick();Shadows.shadowOf(Looper.getMainLooper()).idle();return (AlertDialog)ShadowDialog.getLatestDialog();}
 @Test public void cbrNavigatesFavoritesMarksReadAndRecreationResumesWithoutExtraPlay()throws Exception{
  media("rar",RarBookTest.fixture("album-rar4.cbr"));ReaderActivity a;try(var controller=Robolectric.buildActivity(ReaderActivity.class,intent("rar")).setup().visible()){
   a=controller.get();await(a);assertNotNull(((ZoomImageView)a.findViewById(R.id.readerCanvas)).getDrawable());a.findViewById(R.id.readerNext).performClick();await(a);assertEquals("images/10.png",db.library().readerProgress("rar").entry);
   a.findViewById(R.id.readerFavorite).performClick();a.findViewById(R.id.readerWatched).performClick();idle();assertTrue(db.library().get("rar").favorite);assertTrue(db.library().get("rar").watched);
   ReaderActivity old=a;controller.recreate();closed(old);a=controller.get();await(a);assertTrue(((TextView)a.findViewById(R.id.readerStatus)).getText().toString().contains("10.png"));assertEquals(1,db.library().get("rar").playCount);assertEquals(0,db.library().get("rar").position);
  }closed(a);
 }
 @Test public void rar5IndexSearchReadsUnicodeTextAndRoundTripsProgressInBackup18()throws Exception{
  media("rar",RarBookTest.fixture("album-rar5.rar"));ReaderActivity a;try(var controller=Robolectric.buildActivity(ReaderActivity.class,intent("rar")).setup().visible()){
   a=controller.get();await(a);var d=contents(a);view(d.getWindow().getDecorView(),EditText.class).setText("ñ.txt");view(d.getWindow().getDecorView(),ListView.class).performItemClick(null,0,0);await(a);assertTrue(((TextView)a.findViewById(R.id.readerText)).getText().toString().contains("estratos"));assertEquals("notas/ñ.txt",db.library().readerProgress("rar").entry);
   var out=new java.io.ByteArrayOutputStream();BackupStore.write(db.library(),out);assertEquals(19,new org.json.JSONObject(out.toString("UTF-8")).getInt("version"));BackupStore.read(db,new java.io.ByteArrayInputStream(out.toByteArray()));assertEquals("notas/ñ.txt",db.library().readerProgress("rar").entry);
  }closed(a);
 }
 @Test public void compressedEntryExplainsLimitationAndKeepsPreviousTextAndProgress()throws Exception{
  byte[] b=RarBookTest.rar5(RarBookTest.entry("first.txt",RarBookTest.ascii("Vista valida")),RarBookTest.entry5("compressed.txt",new byte[]{1},10,4,129,0,new byte[0],0100644));media("rar",b);ReaderActivity a;
  try(var c=Robolectric.buildActivity(ReaderActivity.class,intent("rar")).setup().visible()){
   a=c.get();await(a);assertEquals("first.txt",db.library().readerProgress("rar").entry);var d=contents(a);view(d.getWindow().getDecorView(),EditText.class).setText("compressed");ListView l=view(d.getWindow().getDecorView(),ListView.class);assertTrue(l.getAdapter().getItem(0).toString().contains("RAR7"));l.performItemClick(null,0,0);await(a);assertEquals("Vista valida",((TextView)a.findViewById(R.id.readerText)).getText().toString());assertEquals("first.txt",db.library().readerProgress("rar").entry);
  }closed(a);
 }
 @Test public void compressedOnlyArchiveHasIndexButNoFakeReadHistory()throws Exception{
  media("rar",RarBookTest.rar5(RarBookTest.entry5("compressed.txt",new byte[]{1},10,4,129,0,new byte[0],0100644)));ReaderActivity a;
  try(var c=Robolectric.buildActivity(ReaderActivity.class,intent("rar")).setup().visible()){
   a=c.get();await(a);assertTrue(a.findViewById(R.id.readerContents).isEnabled());assertTrue(((TextView)a.findViewById(R.id.readerStatus)).getText().toString().contains("RAR7"));assertNull(db.library().readerProgress("rar"));assertEquals(0,db.library().usageCount());assertEquals(0,db.library().get("rar").playCount);
  }closed(a);
 }
 @Test public void archiveFilterRoutesCbrToReaderWithMediaIdOnly()throws Exception{
  media("rar",RarBookTest.fixture("album-rar4.cbr"));
  try(var c=Robolectric.buildActivity(MainActivity.class).setup().visible()){
   var activity=c.get();activity.findViewById(R.id.toggleFilters).performClick();((Spinner)activity.findViewById(R.id.typeFilter)).setSelection(4);idle();var grid=(androidx.recyclerview.widget.RecyclerView)activity.findViewById(R.id.grid);
   long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(5);while(grid.getAdapter().getItemCount()!=1 && System.nanoTime()<deadline){Thread.sleep(10);Shadows.shadowOf(Looper.getMainLooper()).idle();}
   assertEquals(1,grid.getAdapter().getItemCount());grid.measure(View.MeasureSpec.makeMeasureSpec(1000,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(600,View.MeasureSpec.EXACTLY));grid.layout(0,0,1000,600);grid.findViewHolderForAdapterPosition(0).itemView.performClick();
   Intent started=Shadows.shadowOf(activity).getNextStartedActivity();assertNotNull(started);assertEquals(ReaderActivity.class.getName(),started.getComponent().getClassName());assertEquals("rar",started.getStringExtra("mediaId"));assertNull(started.getData());assertEquals(java.util.Set.of("mediaId"),started.getExtras().keySet());
  }
 }

}
