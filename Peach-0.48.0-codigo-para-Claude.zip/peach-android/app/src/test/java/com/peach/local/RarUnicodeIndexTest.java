package com.peach.local;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import org.junit.*;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

public class RarUnicodeIndexTest {
 @Rule public TemporaryFolder temp=new TemporaryFolder();
 static byte[] fixture(String name)throws Exception{try(var in=RarUnicodeIndexTest.class.getClassLoader().getResourceAsStream("rar040/"+name)){assertNotNull(in);return in.readAllBytes();}}
 static byte[] header(int type,int flags,byte[] body)throws Exception{
  byte[] h=RarBookTest.join(RarBookTest.le(0,2),new byte[]{(byte)type},RarBookTest.le(flags,2),RarBookTest.le(body.length+7,2),body);RarBookTest.fix4(h,0);return h;
 }
 static byte[] entry(byte[] name,boolean unicode,byte[] payload)throws Exception{
  return RarBookTest.join(header(0x74,0x8000|(unicode?0x200:0),RarBookTest.join(RarBookTest.le(payload.length,4),RarBookTest.le(payload.length,4),new byte[]{3},RarBookTest.le(RarBookTest.crc(payload),4),RarBookTest.le(0,4),new byte[]{20,0x30},RarBookTest.le(name.length,2),RarBookTest.le(0100644,4),name)),payload);
 }
 static byte[] archive(byte[]... entries)throws Exception{return RarBookTest.join(RarBookTest.ascii("Rar!\u001a\u0007\u0000"),header(0x73,0,new byte[6]),RarBookTest.join(entries),header(0x7b,0,new byte[0]));}
 File file(byte[] b)throws Exception{File f=temp.newFile();Files.write(f.toPath(),b);return f;}
 void rejects(byte[] b)throws Exception{try(var r=new RarBook(file(b))){fail();}catch(IOException expected){}}
 @Test public void officialAndSyntheticStoredUnicodeNamesOpenTheirExactContents()throws Exception{
  for(String f:List.of("official-unicode-m0.cbr","legacy-stored.cbr"))try(var r=new RarBook(file(fixture(f)))){
   assertEquals(f.startsWith("legacy")?4:3,r.items().size());for(var item:r.items()){
    assertFalse(item.name().contains("xxxx"));assertFalse(item.kind().isEmpty());byte[] b=Files.readAllBytes(r.read(item.name(),temp.newFolder()).toPath());
    assertArrayEquals(item.name().endsWith(".bmp")?RarNativeTest.expected("page.bmp"):RarNativeTest.expected("notes.txt"),b);
   }
  }
 }
 @Test public void decodedUnsafePathsAndControlsAreRejectedBeforeCreatingOutput()throws Exception{
  for(String n:List.of("../private.txt","a/../private.txt","/root.txt","C:\\private.txt","a:private.txt","a\u0000.txt","a\n.txt"))rejects(archive(entry(Rar4NamesTest.legacy(n),true,new byte[0])));
 }
 @Test public void duplicateCanonicalUnicodeNamesRejectDifferentEncodingsAndSeparators()throws Exception{
  for(String alternate:List.of("notas/niñez.txt","notas\\niñez.txt"))rejects(archive(entry(RarBookTest.ascii("notas/niñez.txt"),true,new byte[0]),entry(Rar4NamesTest.legacy(alternate),true,new byte[0])));
 }
 @Test public void canonicalNameIgnoresUnsafeAnsiFallbackButNeverCreatesItsPaths()throws Exception{
  byte[] raw=Rar4NamesTest.legacy("notas/niñez.txt");raw[0]='/';File dir=temp.newFolder();try(var r=new RarBook(file(archive(entry(raw,true,RarBookTest.ascii("own")))))){
   assertEquals("notas/niñez.txt",r.items().get(0).name());r.read("notas/niñez.txt",dir);assertEquals(Set.of("entry"),Set.of(dir.list()));
  }
 }
 @Test public void malformedUnicodeHeaderCannotFallBackToAnApparentlySafePrefix()throws Exception{
  rejects(archive(entry(Rar4NamesTest.bytes('a','.','t','x','t',0,0,0x80,0),true,new byte[0])));
 }
 @Test public void spellingChangeRevalidatesIndexAndPreservesPreviousView()throws Exception{
  File src=file(archive(entry(Rar4NamesTest.legacy("niñez.txt"),true,RarBookTest.ascii("own")))),dir=temp.newFolder(),view=new File(dir,"entry");Files.write(view.toPath(),RarBookTest.ascii("previous"));
  try(var r=new RarBook(src)){Files.write(src.toPath(),archive(entry(Rar4NamesTest.legacy("niñaz.txt"),true,RarBookTest.ascii("own"))));try{r.read("niñez.txt",dir);fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("cambió"));}}
  assertEquals("previous",ArchiveBookTest.readString(view.toPath()));assertFalse(new File(dir,"entry-part").exists());
 }
 @Test public void unicodeStoredCrcFailurePreservesPreviousView()throws Exception{
  byte[] b=archive(entry(Rar4NamesTest.legacy("niñez.txt"),true,RarBookTest.ascii("own")));b[b.length-8]^=1;File dir=temp.newFolder(),view=new File(dir,"entry");Files.write(view.toPath(),RarBookTest.ascii("previous"));
  try(var r=new RarBook(file(b))){try{r.read("niñez.txt",dir);fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("CRC"));}}assertEquals("previous",ArchiveBookTest.readString(view.toPath()));assertFalse(new File(dir,"entry-part").exists());
 }
}
