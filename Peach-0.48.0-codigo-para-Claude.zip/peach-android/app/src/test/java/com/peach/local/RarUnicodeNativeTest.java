package com.peach.local;
import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.junit.*;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;
/** Real pinned Linux JNI, never described as Android ABI/Binder execution. */
public class RarUnicodeNativeTest {
 @Rule public TemporaryFolder temp=new TemporaryFolder();
 @BeforeClass public static void load(){RarNativeTest.load();}
 File file(byte[] b)throws Exception{File f=temp.newFile();Files.write(f.toPath(),b);return f;}
 static long[] decode(File src,File dest,String name,byte[] expected)throws Exception {
  int in=RarNativeTest.openFd(src.getAbsolutePath(),false),out=RarNativeTest.openFd(dest.getAbsolutePath(),true);assertTrue(in>=0);assertTrue(out>=0);
  try{return RarNative.decode(in,out,name.getBytes(StandardCharsets.UTF_8),expected.length,RarNativeTest.crc(expected),RarNative.MAX_HEAP);}finally{RarNativeTest.closeFd(in);RarNativeTest.closeFd(out);}
 }
 @Test public void bothLegacyAndOfficialCompressedNamesSelectExactNativeContents()throws Exception{
  for(String fixture:List.of("legacy-compressed.cbr","official-unicode-m3.cbr")){
   byte[] original=RarUnicodeIndexTest.fixture(fixture);File src=file(original),dir=temp.newFolder();
   RarBook.Decoder decoder=(source,name,size,crc,out)->{File target=new File(out,"entry");try{byte[] expected=RarNativeTest.expected(name.endsWith(".bmp")?"page.bmp":"notes.txt");long[] result=decode(source,target,name,expected);RarClient.validate(result);assertEquals(0,result[2]);RarClient.verify(target,size,crc);return target;}catch(Exception e){throw new IOException(e);}};
   try(var r=new RarBook(src,decoder)){assertEquals(fixture.startsWith("legacy")?4:3,r.items().size());for(var item:r.items())assertArrayEquals(RarNativeTest.expected(item.name().endsWith(".bmp")?"page.bmp":"notes.txt"),Files.readAllBytes(r.read(item.name(),dir).toPath()));}
   assertArrayEquals(original,Files.readAllBytes(src.toPath()));assertEquals(Set.of("entry"),Set.of(dir.list()));
  }
 }
 @Test public void fallbackPrefixOrDifferentUnicodeNameCannotSelectAnEntry()throws Exception{
  File src=file(RarUnicodeIndexTest.fixture("legacy-compressed.cbr"));for(String name:List.of("xxxxxxxxxxxxxx","notas/ninez.txt","emoji/roca-?.txt","日本語/地層.txt/private")){
   long[] result=decode(src,temp.newFile(),name,RarNativeTest.expected("notes.txt"));assertEquals(Arrays.toString(result),2,result[0]);assertEquals(0,result[2]);
  }
 }
 @Test public void unicodeAndAsciiReadsDoNotKeepPreviousFilenameOrAllocationState()throws Exception{
  File unicode=file(RarUnicodeIndexTest.fixture("legacy-compressed.cbr")),ascii=file(RarNativeTest.fixture("own-rar4-m3.cbr"));
  for(int i=0;i<5;i++)for(String name:List.of("日本語/地層.txt","emoji/roca-🪨.txt","notes.txt")){
   long[] result=decode(name.equals("notes.txt")?ascii:unicode,temp.newFile(),name,RarNativeTest.expected("notes.txt"));assertEquals(Arrays.toString(result),0,result[0]);assertEquals(0,result[2]);
  }
 }
}
