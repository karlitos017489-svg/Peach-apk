package com.peach.local;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import org.junit.*;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

/** Real Linux JNI round trips on header-derived own compressed samples; no Android ABI claim. */
public class RarWide440Test {
    @Rule public TemporaryFolder temp=new TemporaryFolder();
    @BeforeClass public static void nativeLoad(){RarNativeTest.load();}
    @Test public void widened32And64MiBSolidDictionariesReadExactEntriesInReverseOrder()throws Exception {
        for(int width:new int[]{32,64}){byte[] original=Formats440Test.fixture("rar5-solid-dict"+width+".cbr");File source=temp.newFile(),dir=temp.newFolder();Files.write(source.toPath(),original);
            RarBook.Decoder decode=(src,name,size,crc,d)->{File part=new File(d,"entry-part");try{byte[] expected=RarSolidNativeTest.expected(name);long[] result=RarUnicodeNativeTest.decode(src,part,name,expected);assertEquals(Arrays.toString(result),0,result[0]);assertEquals(0,result[2]);assertTrue(result[1]<=RarNative.MAX_HEAP);RarClient.verify(part,size,crc);File output=new File(d,"entry");if(!part.renameTo(output))throw new IOException();return output;}catch(Exception e){part.delete();throw new IOException(e);}};
            try(var book=new RarBook(source,decode)){var items=new ArrayList<>(book.items());Collections.reverse(items);for(var item:items)assertArrayEquals(RarSolidNativeTest.expected(item.name()),Files.readAllBytes(book.read(item.name(),dir).toPath()));}
            assertArrayEquals(original,Files.readAllBytes(source.toPath()));assertEquals(Set.of("entry"),Set.of(dir.list()));
        }
    }
    @Test public void wideSolidStillRejectsOversizeDictionaryBeforeStartingDecoder()throws Exception {
        byte[] sample=RarSolidTest.archive(4,RarSolidTest.entry("a.txt",1,10,false));File source=temp.newFile();Files.write(source.toPath(),sample);try(var book=new RarBook(source,RarSolidTest.UNUSED)){fail();}catch(IOException expected){}
    }
}
