package com.peach.local;
import android.content.Intent;
import android.os.Looper;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowDialog;
import org.robolectric.util.ReflectionHelpers;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land") @GraphicsMode(GraphicsMode.Mode.NATIVE) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class Reader440Test {
    LibraryDatabase db;
    @Before public void start(){db=androidx.room.Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",db);}
    @After public void stop()throws Exception{idle();db.close();ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);}
    void idle()throws Exception{for(int i=0;i<2;i++){LibraryDatabase.IO.submit(()->{}).get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}}
    void await(ReaderActivity a)throws Exception{idle();java.util.concurrent.Future<?> p=ReflectionHelpers.getField(a,"pending");if(p!=null)p.get(30,TimeUnit.SECONDS);java.util.concurrent.ExecutorService worker=ReflectionHelpers.getField(a,"worker");worker.submit(()->{}).get(30,TimeUnit.SECONDS);idle();}
    void closed(ReaderActivity a)throws Exception{java.util.concurrent.ExecutorService worker=ReflectionHelpers.getField(a,"worker");assertTrue(worker.awaitTermination(30,TimeUnit.SECONDS));idle();}
    void media(String id,String name,byte[] b){MediaEntry m=new MediaEntry();m.id=id;m.name=name;m.uri=ReaderSessionTest.register(id,b).toString();m.mediaType=MediaRules.type(name);db.library().insertMedia(m);}
    Intent intent(String id,Class<?> type){return new Intent(RuntimeEnvironment.getApplication(),type).putExtra("mediaId",id);}
    static EditText edit(View view){if(view instanceof EditText e)return e;if(view instanceof ViewGroup g)for(int i=0;i<g.getChildCount();i++){EditText found=edit(g.getChildAt(i));if(found!=null)return found;}return null;}
    AlertDialog dialog(){Shadows.shadowOf(Looper.getMainLooper()).idle();return (AlertDialog)ShadowDialog.getLatestDialog();}
    void clickMenu(String text){AlertDialog d=dialog();ListView list=d.getListView();for(int i=0;i<list.getCount();i++)if(list.getAdapter().getItem(i).toString().equals(text)){list.performItemClick(null,i,i);return;}fail(text);}
    @Test public void epubIndexNavigatesNamedFragmentAndNativeSearchFindsVisibleText()throws Exception {
        media("book","book.epub",Formats440Test.fixture("muestra-epub3.epub"));ReaderActivity a;
        try(var c=Robolectric.buildActivity(ReaderActivity.class,intent("book",ReaderActivity.class)).setup().visible()) {
            a=c.get();await(a);a.findViewById(R.id.readerOptions).performClick();clickMenu("Índice del libro");AlertDialog toc=dialog();assertEquals(3,toc.getListView().getCount());toc.getListView().performItemClick(null,1,1);await(a);assertEquals("EPUB/uno.xhtml",db.library().readerProgress("book").entry);
            a.findViewById(R.id.readerOptions).performClick();clickMenu("Buscar en el texto visible");AlertDialog find=dialog();edit(find.getWindow().getDecorView()).setText("Seccion intermedia");find.getButton(AlertDialog.BUTTON_POSITIVE).performClick();idle();assertTrue(((TextView)a.findViewById(R.id.readerText)).getText() instanceof android.text.Spanned);
            a.findViewById(R.id.readerOptions).performClick();clickMenu("Índice del libro");dialog().getListView().performItemClick(null,2,2);await(a);assertEquals("EPUB/dos.xhtml",db.library().readerProgress("book").entry);assertEquals(1,db.library().get("book").playCount);
        }closed(a);
    }
    @Test public void passwordIsUsedForOwn7zButNeverSavedAcrossRotation()throws Exception {
        media("secretbook","own.7z",Formats440Test.fixture("muestra-clave.7z"));ReaderActivity a;
        try(var c=Robolectric.buildActivity(ReaderActivity.class,intent("secretbook",ReaderActivity.class)).setup().visible()) {
            a=c.get();await(a);assertTrue(((TextView)a.findViewById(R.id.readerStatus)).getText().toString().contains("cifrada"));
            a.findViewById(R.id.readerOptions).performClick();clickMenu("Contraseña de PDF / 7z");AlertDialog password=dialog();EditText input=edit(password.getWindow().getDecorView());assertFalse(input.isSaveEnabled());assertTrue((password.getWindow().getAttributes().flags&android.view.WindowManager.LayoutParams.FLAG_SECURE)!=0);input.setText("test-only");password.getButton(AlertDialog.BUTTON_POSITIVE).performClick();await(a);assertNotNull(((ZoomImageView)a.findViewById(R.id.readerCanvas)).getDrawable());assertEquals("",input.getText().toString());
            ReaderActivity old=a;c.recreate();closed(old);a=c.get();await(a);assertTrue(((TextView)a.findViewById(R.id.readerStatus)).getText().toString().contains("cifrada"));
            var backup=new java.io.ByteArrayOutputStream();BackupStore.write(db.library(),backup);assertFalse(backup.toString("UTF-8").contains("test-only"));
        }closed(a);
    }
    public static class SearchPdfActivity extends ReaderActivity {
        @Override protected void onCreate(android.os.Bundle state){setTheme(R.style.AppTheme);super.onCreate(state);}
        @Override protected ReaderSession createSession(MediaEntry m){return new ReaderSession(this,android.net.Uri.parse(m.uri),m.name,f->new ReaderSession.Pages(){public int count(){return 40;}public android.graphics.Bitmap render(int page,int edge){return android.graphics.Bitmap.createBitmap(10,10,android.graphics.Bitmap.Config.ARGB_8888);}public boolean searchable(){return true;}public int search(int page,String query){return page==18?2:0;}public void close(){}});}
    }
    @Test public void pdfSearchBatchesAt16PagesAndOpensChosenResultWithProgressSeparateFromAv()throws Exception {
        media("pdf","own.pdf",new byte[]{1});ReaderActivity a;
        try(var c=Robolectric.buildActivity(SearchPdfActivity.class,intent("pdf",SearchPdfActivity.class)).setup().visible()) {
            a=c.get();await(a);a.findViewById(R.id.readerOptions).performClick();clickMenu("Buscar dentro del PDF (Android 15+)");AlertDialog search=dialog();edit(search.getWindow().getDecorView()).setText("capas");search.getButton(AlertDialog.BUTTON_POSITIVE).performClick();await(a);AlertDialog results=dialog();assertTrue(((TextView)results.findViewById(androidx.appcompat.R.id.alertTitle)).getText().toString().contains("1–16"));results.getButton(AlertDialog.BUTTON_POSITIVE).performClick();await(a);results=dialog();assertEquals(1,results.getListView().getCount());results.getListView().performItemClick(null,0,0);await(a);assertEquals(18,db.library().readerProgress("pdf").page);assertEquals(0,db.library().get("pdf").position);
        }closed(a);
    }
    @Test public void pdfSearchContractRejectsShortQueriesHonorsCancellationAndBoundsBatch()throws Exception {
        var context=RuntimeEnvironment.getApplication();List<Integer> searched=new ArrayList<>();
        try(var session=new ReaderSession(context,ReaderSessionTest.register("search-contract",new byte[]{1}),"own.pdf",f->new ReaderSession.Pages(){public int count(){return 100;}public android.graphics.Bitmap render(int p,int edge){return null;}public boolean searchable(){return true;}public int search(int p,String q){searched.add(p);return p==2?3:0;}public void close(){}})) {
            session.open();var result=session.searchPdf("capas",0);assertEquals(16,searched.size());assertEquals(16,result.next());assertEquals(List.of(new ReaderSession.Hit(2,3)),result.hits());
            try{session.searchPdf("a",0);fail();}catch(java.io.IOException expected){}session.cancel();try{session.searchPdf("capas",16);fail();}catch(java.io.InterruptedIOException expected){}assertEquals(16,searched.size());
        }
    }
    @Test public void zip64ReaderUsesExistingImageViewAndCleansSessionAfterClosing()throws Exception {
        var context=RuntimeEnvironment.getApplication();try(var session=new ReaderSession(context,ReaderSessionTest.register("zip64-session",Formats440Test.fixture("muestra-zip64.cbz")),"own.cbz")){session.open();var frame=session.show("",0);assertEquals("images/2.png",frame.entry());assertEquals(120,frame.bitmap().getWidth());frame.bitmap().recycle();assertTrue(session.show("notas.txt",0).text().contains("ZIP64"));}
        assertEquals(0,new java.io.File(context.getCacheDir(),"peach-reader").list().length);
    }
}
