package com.peach.local;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.Shadows;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE) @GraphicsMode(GraphicsMode.Mode.NATIVE)
public class ReaderSessionTest {
    static byte[] album() throws Exception {
        byte[] png;try(var input=ReaderSessionTest.class.getClassLoader().getResourceAsStream("media/small.png")){assertNotNull(input);png=input.readAllBytes();}
        var bytes=new ByteArrayOutputStream();try(ZipOutputStream zip=new ZipOutputStream(bytes)) {
            for(String name:java.util.List.of("10.png","2.png","notes.txt","video.mp4")){zip.putNextEntry(new ZipEntry(name));zip.write(name.endsWith("png")?png:"Campo <b>texto</b>".getBytes(java.nio.charset.StandardCharsets.UTF_8));zip.closeEntry();}
        }return bytes.toByteArray();
    }
    static Uri register(String id,byte[] data){Uri uri=Uri.parse("content://reader/"+id);Shadows.shadowOf(RuntimeEnvironment.getApplication().getContentResolver()).registerInputStreamSupplier(uri,()->new ByteArrayInputStream(data));return uri;}
    @Test public void realZipImageDecodingAndTextPreviewUsePrivateCacheAndCleanup() throws Exception {
        var context=RuntimeEnvironment.getApplication();Uri uri=register("album",album());File root=new File(context.getCacheDir(),"peach-reader");
        try(ReaderSession session=new ReaderSession(context,uri,"album.cbz")) {
            session.open();assertEquals("2.png",session.firstEntry());var image=session.show("",0);
            assertEquals(0,image.page());assertEquals(2,image.count());assertEquals(120,image.bitmap().getWidth());assertEquals(Color.RED,image.bitmap().getPixel(10,10));image.bitmap().recycle();
            assertEquals("10.png",session.adjacent("2.png",1));var text=session.show("notes.txt",0);assertEquals("Campo <b>texto</b>",text.text());assertNull(text.bitmap());
            var again=session.show("2.png",0);assertEquals(Color.BLUE,again.bitmap().getPixel(110,10));again.bitmap().recycle();
        }
        assertEquals(0,root.list().length);
    }
    @Test public void activeSessionsKeepTheirCachesWhileOrphanedSessionFilesAreRemoved() throws Exception {
        var context=RuntimeEnvironment.getApplication();Uri uri=register("album",album());File root=new File(context.getCacheDir(),"peach-reader");root.mkdirs();File stale=new File(root,"session-orphan");stale.mkdir();java.nio.file.Files.write(new File(stale,"source").toPath(),new byte[]{1});
        try(ReaderSession first=new ReaderSession(context,uri,"album.zip")) {
            first.open();assertFalse(stale.exists());assertEquals(1,root.list().length);
            try(ReaderSession second=new ReaderSession(context,uri,"album.zip")){second.open();assertEquals(2,root.list().length);}
            assertEquals(1,root.list().length);var frame=first.show("2.png",0);assertNotNull(frame.bitmap());frame.bitmap().recycle();
        }assertEquals(0,root.list().length);
    }
    @Test public void cancellationAndInvalidUrisDoNotLeaveCachedSources() throws Exception {
        var context=RuntimeEnvironment.getApplication();Uri uri=register("text","Campo".getBytes(java.nio.charset.StandardCharsets.UTF_8));
        try(ReaderSession session=new ReaderSession(context,uri,"text.txt")){session.cancel();try{session.open();fail();}catch(java.io.InterruptedIOException expected){}}
        try(ReaderSession session=new ReaderSession(context,Uri.parse("file:///private/a"),"text.txt")){try{session.open();fail();}catch(java.io.IOException expected){}}
        File root=new File(context.getCacheDir(),"peach-reader");assertTrue(!root.exists() || root.list().length==0);
    }
    @Test public void pdfAdapterContractClampsPageAndClosesItsBackendWithoutClaimingNativePdfExecution() throws Exception {
        var context=RuntimeEnvironment.getApplication();Uri uri=register("pdf","fake PDF backend input".getBytes(java.nio.charset.StandardCharsets.UTF_8));AtomicInteger closed=new AtomicInteger();
        try(ReaderSession session=new ReaderSession(context,uri,"a.pdf",file->new ReaderSession.Pages(){
            public int count(){return 3;}public Bitmap render(int page,int edge){Bitmap image=Bitmap.createBitmap(4,4,Bitmap.Config.ARGB_8888);image.eraseColor(page==2?Color.BLUE:Color.RED);return image;}public void close(){closed.incrementAndGet();}
        })) {
            session.open();var frame=session.show("",99);assertEquals(2,frame.page());assertEquals(3,frame.count());assertEquals(Color.BLUE,frame.bitmap().getPixel(1,1));frame.bitmap().recycle();
        }assertEquals(1,closed.get());
    }
    @Test public void tarAndTarGzipSessionsDecodeRealImagesTextAndCleanPrivateExpansion()throws Exception {
        var context=RuntimeEnvironment.getApplication();File root=new File(context.getCacheDir(),"peach-reader");
        for(String name:java.util.List.of("album.tar","album.tar.gz","album.tgz")) {
            byte[] bytes=ArchiveBookTest.fixture(name.equals("album.tar")?"album.tar":"album.tar.gz");
            try(var session=new ReaderSession(context,register("tar-"+name,bytes),name)) {
                session.open();assertTrue(session.archive());assertEquals("fotos/2.png",session.firstEntry());var frame=session.show("",0);assertEquals(2,frame.count());assertEquals(Color.RED,frame.bitmap().getPixel(10,10));frame.bitmap().recycle();
                assertEquals("fotos/10.png",session.adjacent("fotos/2.png",1));assertTrue(session.show("notes.txt",0).text().contains("estratos"));
                try{session.show("alias.txt",0);fail();}catch(java.io.IOException expected){}assertTrue(session.show("notes.txt",0).text().contains("estratos"));
            }assertEquals(0,root.list().length);
        }
    }
    @Test public void gzipTextAndImageUseExistingRenderersAndCancelledOpenCleansAllCaches()throws Exception {
        var context=RuntimeEnvironment.getApplication();File root=new File(context.getCacheDir(),"peach-reader");
        try(var session=new ReaderSession(context,register("gz-text",ArchiveBookTest.gzip("Lectura local".getBytes())),"notes.txt.gz")){session.open();assertEquals("notes.txt",session.firstEntry());assertEquals("Lectura local",session.show("",0).text());}
        byte[] png;try(var input=getClass().getClassLoader().getResourceAsStream("media/small.png")){png=input.readAllBytes();}
        try(var session=new ReaderSession(context,register("gz-image",ArchiveBookTest.gzip(png)),"photo.png.gz")){session.open();var frame=session.show("",0);assertEquals(Color.RED,frame.bitmap().getPixel(10,10));frame.bitmap().recycle();}
        try(var session=new ReaderSession(context,register("gz-cancel",ArchiveBookTest.fixture("album.tar.gz")),"a.tgz")){session.cancel();try{session.open();fail();}catch(java.io.InterruptedIOException expected){}}
        assertEquals(0,root.list().length);
    }
    @Test public void tarPdfUsesExplicitPdfAdapterAndHonorsPageContract()throws Exception {
        var bytes=new ByteArrayOutputStream();try(var tar=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(bytes)){var e=new org.apache.commons.compress.archivers.tar.TarArchiveEntry("document.pdf");e.setSize(3);tar.putArchiveEntry(e);tar.write(new byte[]{1,2,3});tar.closeArchiveEntry();}
        AtomicInteger closed=new AtomicInteger();try(var session=new ReaderSession(RuntimeEnvironment.getApplication(),register("tar-pdf",bytes.toByteArray()),"a.tar",file->new ReaderSession.Pages(){public int count(){return 2;}public Bitmap render(int page,int edge){return Bitmap.createBitmap(4,4,Bitmap.Config.ARGB_8888);}public void close(){closed.incrementAndGet();}})){session.open();var frame=session.show("",99);assertEquals("pdf",frame.kind());assertEquals(1,frame.page());frame.bitmap().recycle();}assertEquals(1,closed.get());
    }

    @Test public void sevenZipSessionRendersImagesTextAndResumesSelectionsWithPrivateCleanup()throws Exception {
        var context=RuntimeEnvironment.getApplication();File root=new File(context.getCacheDir(),"peach-reader");
        try(var session=new ReaderSession(context,register("7z-album",SevenZipBookTest.fixture("album-solid.7z")),"album.7z")){
            session.open();assertTrue(session.archive());assertEquals("images/2.png",session.firstEntry());var first=session.show("",0);assertEquals(2,first.count());assertEquals(Color.RED,first.bitmap().getPixel(10,10));first.bitmap().recycle();assertEquals("images/10.png",session.adjacent("images/2.png",1));assertTrue(session.show("notes.txt",0).text().contains("estratos"));assertEquals("",session.show("empty.txt",0).text());
            try{session.show("link.txt",0);fail();}catch(java.io.IOException expected){}assertTrue(session.show("notes.txt",0).text().contains("estratos"));
        }assertEquals(0,root.list().length);
    }
    @Test public void encryptedSevenZipReadFailureDoesNotLeaveCachedSourcesAfterClose()throws Exception {
        var context=RuntimeEnvironment.getApplication();File root=new File(context.getCacheDir(),"peach-reader");try(var session=new ReaderSession(context,register("7z-encrypted",SevenZipBookTest.fixture("encrypted-data.7z")),"a.7z")){session.open();try{session.show("notes.txt",0);fail();}catch(java.io.IOException expected){assertTrue(expected.getMessage().contains("cifrada"));}}assertEquals(0,root.list().length);
    }
    @Test public void sevenZipPdfUsesExistingPdfAdapterWithIndependentReadingPosition()throws Exception {
        var bytes=java.nio.file.Files.createTempFile("7z-pdf-fixture-",".7z").toFile();try{
            try(var out=new org.apache.commons.compress.archivers.sevenz.SevenZOutputFile(bytes)){out.setContentCompression(org.apache.commons.compress.archivers.sevenz.SevenZMethod.COPY);var e=new org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry();e.setName("doc.pdf");out.putArchiveEntry(e);out.write(new byte[]{1,2,3});out.closeArchiveEntry();}
            try(var session=new ReaderSession(RuntimeEnvironment.getApplication(),register("7z-pdf",java.nio.file.Files.readAllBytes(bytes.toPath())),"a.7z",file->new ReaderSession.Pages(){public int count(){return 2;}public Bitmap render(int page,int edge){return Bitmap.createBitmap(4,4,Bitmap.Config.ARGB_8888);}public void close(){}})){session.open();var frame=session.show("doc.pdf",1);assertEquals(1,frame.page());assertEquals(DocumentRules.PDF,frame.kind());frame.bitmap().recycle();}
        }finally{bytes.delete();}
    }

    @Test public void epubSessionStartsAtSpineChapterAndUsesSeparateChapterAndImageSequences()throws Exception {
        var context=RuntimeEnvironment.getApplication();File root=new File(context.getCacheDir(),"peach-reader");try(var session=new ReaderSession(context,register("epub",EpubBookTest.fixture("book3.epub")),"book.epub")){
            session.open();assertTrue(session.epub());assertEquals("EPUB/text/10.xhtml",session.firstEntry());var chapter=session.show("",0);assertEquals(DocumentRules.CHAPTER,chapter.kind());assertEquals(0,chapter.page());assertEquals(2,chapter.count());assertTrue(chapter.text().contains("sedimentarias"));String next=session.adjacent(chapter.entry(),1);assertEquals("EPUB/text/cap dos.xhtml",next);assertEquals(1,session.show(next,99).page());assertEquals("",session.adjacent(next,1));var image=session.show("EPUB/images/portada color.png",0);assertEquals(Color.RED,image.bitmap().getPixel(10,10));assertEquals(1,image.count());image.bitmap().recycle();assertEquals(0,session.show("missing.xhtml",99).page());
        }assertEquals(0,root.list().length);
    }
    @Test public void failedEpubPreviewCanReturnToPreviousChapterAndCloseCleansRawCache()throws Exception {
        var map=EpubBookTest.contents();map.put("EPUB/text/cap dos.xhtml",new byte[]{(byte)255});var context=RuntimeEnvironment.getApplication();try(var session=new ReaderSession(context,register("epub-bad",EpubBookTest.encode(map)),"a.epub")){session.open();assertTrue(session.show("",0).text().contains("sedimentarias"));try{session.show("EPUB/text/cap dos.xhtml",1);fail();}catch(java.io.IOException expected){}assertTrue(session.show("EPUB/text/10.xhtml",0).text().contains("sedimentarias"));}assertEquals(0,new File(context.getCacheDir(),"peach-reader").list().length);
    }

}
