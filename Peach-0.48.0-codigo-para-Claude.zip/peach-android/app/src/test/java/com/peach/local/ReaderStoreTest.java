package com.peach.local;

import androidx.room.Room;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.SQLiteMode;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class ReaderStoreTest {
    private LibraryDatabase db;
    @Before public void open(){db=Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().build();
        for(String name:List.of("a.pdf","b.cbz","c.txt","v.mp4")){MediaEntry m=new MediaEntry();m.id=name;m.name=name;m.title=name;m.root="root";m.mediaType=MediaRules.type(name);db.library().insertMedia(m);}}
    @After public void close(){db.close();}
    private ReaderProgress progress(String id){ReaderProgress p=new ReaderProgress();p.mediaId=id;p.entry="images/2.png";p.page=2;p.scroll=400;p.updatedAt=123;return p;}
    private JSONObject backup() throws Exception{var out=new ByteArrayOutputStream();BackupStore.write(db.library(),out);return new JSONObject(out.toString("UTF-8"));}
    private void restore(JSONObject b) throws Exception{BackupStore.read(db,new ByteArrayInputStream(b.toString().getBytes(StandardCharsets.UTF_8)));}
    @Test public void readingProgressIsIndependentOfAvPositionAndSurvivesMissingRoot() {
        ReaderStore.save(db,progress("a.pdf"));assertEquals(2,db.library().readerProgress("a.pdf").page);assertEquals(0,db.library().get("a.pdf").position);
        ReaderStore.save(db,progress("v.mp4"));assertNull(db.library().readerProgress("v.mp4"));db.library().markMissing("root",1);assertNotNull(db.library().readerProgress("a.pdf"));
        db.library().forgetMedia("root");assertTrue(db.library().readerProgress().isEmpty());
    }
    @Test public void v5BackupRoundTripsAndV4LeavesReaderStateAlone() throws Exception {
        ReaderStore.save(db,progress("a.pdf"));ReaderStore.save(db,progress("b.cbz"));JSONObject b=backup();assertEquals(19,b.getInt("version"));
        ReaderProgress changed=progress("a.pdf");changed.page=9;ReaderStore.save(db,changed);restore(b);assertEquals(2,db.library().readerProgress("a.pdf").page);
        b.put("version",4);b.remove("readerProgress");ReaderStore.save(db,changed);restore(b);assertEquals(9,db.library().readerProgress("a.pdf").page);
    }
    @Test public void invalidReaderRecordRollsBackAllEarlierPersonalState() throws Exception {
        ReaderStore.save(db,progress("a.pdf"));JSONObject b=backup();b.getJSONArray("items").getJSONObject(0).put("favorite",true);b.getJSONArray("readerProgress").getJSONObject(0).put("page",-1);
        try{restore(b);fail();}catch(IllegalArgumentException expected){}
        assertFalse(db.library().allMedia().get(0).favorite);assertEquals(2,db.library().readerProgress("a.pdf").page);
    }
    @Test public void duplicateAndFractionalPositionsAreRejectedWhileUnindexedDocumentsAreSkipped() throws Exception {
        ReaderStore.save(db,progress("a.pdf"));JSONObject b=backup();var rows=b.getJSONArray("readerProgress");rows.put(rows.getJSONObject(0));
        try{restore(b);fail();}catch(IllegalArgumentException expected){}
        b=backup();b.getJSONArray("readerProgress").getJSONObject(0).put("scroll",1.5);try{restore(b);fail();}catch(IllegalArgumentException expected){}
        b=backup();b.getJSONArray("readerProgress").getJSONObject(0).put("mediaId","unknown");restore(b);assertEquals(1,db.library().readerProgress().size());
    }
    @Test public void startedFilterCombinesReaderAndAvStateWithExistingScopes() {
        ReaderStore.save(db,progress("a.pdf"));db.library().progress("v.mp4",1000,9000,1,false);
        var rows=LibraryView.select(db.library().allMedia(),"",3,"root","","",List.of(),0,"",java.util.Set.of("a.pdf"));
        assertEquals(List.of("a.pdf","v.mp4"),rows.stream().map(m->m.id).toList());
        assertEquals(1,LibraryView.select(db.library().allMedia(),"a",3,"root","","",List.of(),0,MediaRules.OTHER,java.util.Set.of("a.pdf")).size());
    }
}
