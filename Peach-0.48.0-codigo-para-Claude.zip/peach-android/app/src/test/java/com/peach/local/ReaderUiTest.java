package com.peach.local;

import android.content.Intent;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import java.util.concurrent.TimeUnit;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.Shadows;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;
import org.robolectric.annotation.SQLiteMode;
import org.robolectric.shadows.ShadowDialog;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land") @GraphicsMode(GraphicsMode.Mode.NATIVE) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class ReaderUiTest {
    private LibraryDatabase db;
    @Before public void open(){
        var context=RuntimeEnvironment.getApplication();db=androidx.room.Room.inMemoryDatabaseBuilder(context,LibraryDatabase.class).allowMainThreadQueries().setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();
        org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",db);
        androidx.work.testing.WorkManagerTestInitHelper.initializeTestWorkManager(context,new androidx.work.Configuration.Builder().setExecutor(Runnable::run).setTaskExecutor(Runnable::run).build());
    }
    @After public void close() throws Exception{idle();androidx.work.testing.WorkManagerTestInitHelper.closeWorkDatabase();db.close();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);}
    private void idle() throws Exception{for(int i=0;i<2;i++){LibraryDatabase.IO.submit(()->{}).get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}}
    private void await(ReaderActivity activity) throws Exception{idle();java.util.concurrent.Future<?> pending=org.robolectric.util.ReflectionHelpers.getField(activity,"pending");assertNotNull(pending);pending.get(30,TimeUnit.SECONDS);idle();}
    private void closed(ReaderActivity activity) throws Exception{java.util.concurrent.ExecutorService worker=org.robolectric.util.ReflectionHelpers.getField(activity,"worker");assertTrue(worker.awaitTermination(30,TimeUnit.SECONDS));idle();}
    private void media(String id,String name,byte[] bytes){MediaEntry m=new MediaEntry();m.id=id;m.name=name;m.title=id;m.mediaType=MediaRules.type(name);m.uri=ReaderSessionTest.register(id,bytes).toString();db.library().insertMedia(m);}
    private EditText edit(View view){if(view instanceof EditText input)return input;if(view instanceof ViewGroup group)for(int i=0;i<group.getChildCount();i++){var found=edit(group.getChildAt(i));if(found!=null)return found;}return null;}
    private ListView list(View view){if(view instanceof ListView list)return list;if(view instanceof ViewGroup group)for(int i=0;i<group.getChildCount();i++){var found=list(group.getChildAt(i));if(found!=null)return found;}return null;}
    @Test public void zipAlbumNavigatesDecodesFavoritesMarksReadAndResumesOnRecreation() throws Exception {
        media("album","a.cbz",ReaderSessionTest.album());Intent intent=new Intent(RuntimeEnvironment.getApplication(),ReaderActivity.class).putExtra("mediaId","album");ReaderActivity current;
        try(var controller=Robolectric.buildActivity(ReaderActivity.class,intent).setup().visible()) {
            current=controller.get();await(current);assertNotNull(((ZoomImageView)current.findViewById(R.id.readerCanvas)).getDrawable());
            current.findViewById(R.id.readerNext).performClick();await(current);assertTrue(((TextView)current.findViewById(R.id.readerStatus)).getText().toString().contains("10.png"));
            current.findViewById(R.id.readerFavorite).performClick();current.findViewById(R.id.readerWatched).performClick();idle();assertTrue(db.library().get("album").favorite);assertTrue(db.library().get("album").watched);
            assertEquals("10.png",db.library().readerProgress("album").entry);assertEquals(0,db.library().get("album").position);assertEquals(1,db.library().get("album").playCount);
            ReaderActivity old=current;controller.recreate();closed(old);current=controller.get();await(current);assertTrue(((TextView)current.findViewById(R.id.readerStatus)).getText().toString().contains("10.png"));assertEquals(1,db.library().get("album").playCount);
        }closed(current);
    }
    @Test public void zipContentsSearchReadsPlainTextAndUnsupportedEntryDoesNotReplaceProgress() throws Exception {
        media("album","a.zip",ReaderSessionTest.album());Intent intent=new Intent(RuntimeEnvironment.getApplication(),ReaderActivity.class).putExtra("mediaId","album");ReaderActivity activity;
        try(var controller=Robolectric.buildActivity(ReaderActivity.class,intent).setup().visible()) {
            activity=controller.get();await(activity);activity.findViewById(R.id.readerContents).performClick();Shadows.shadowOf(Looper.getMainLooper()).idle();AlertDialog contents=(AlertDialog)ShadowDialog.getLatestDialog();
            edit(contents.getWindow().getDecorView()).setText("notes");list(contents.getWindow().getDecorView()).performItemClick(null,0,0);await(activity);
            TextView text=activity.findViewById(R.id.readerText);assertEquals("Campo <b>texto</b>",text.getText().toString());assertTrue(text.isTextSelectable());float size=text.getTextSize();activity.findViewById(R.id.readerZoomIn).performClick();assertTrue(text.getTextSize()>size);
            assertEquals("notes.txt",db.library().readerProgress("album").entry);
            activity.findViewById(R.id.readerContents).performClick();Shadows.shadowOf(Looper.getMainLooper()).idle();contents=(AlertDialog)ShadowDialog.getLatestDialog();edit(contents.getWindow().getDecorView()).setText("video");list(contents.getWindow().getDecorView()).performItemClick(null,0,0);await(activity);
            assertTrue(((TextView)activity.findViewById(R.id.readerStatus)).getText().toString().contains("sin lector integrado"));assertEquals("notes.txt",db.library().readerProgress("album").entry);
            assertEquals("Campo <b>texto</b>",text.getText().toString());assertFalse(activity.findViewById(R.id.readerPage).isEnabled());
        }closed(activity);
    }
    public static class PdfControllerActivity extends ReaderActivity {
        @Override protected void onCreate(android.os.Bundle state){setTheme(R.style.AppTheme);super.onCreate(state);}
        @Override protected ReaderSession createSession(MediaEntry media){return new ReaderSession(this,android.net.Uri.parse(media.uri),media.name,file->new ReaderSession.Pages(){
            public int count(){return 3;}public android.graphics.Bitmap render(int page,int edge){return android.graphics.Bitmap.createBitmap(10,10,android.graphics.Bitmap.Config.ARGB_8888);}public void close(){}
        });}
    }
    @Test public void pdfControllerSupportsNextAndPageJumpUsingAnExplicitTestBackend() throws Exception {
        media("pdf","a.pdf","PDF backend double".getBytes(java.nio.charset.StandardCharsets.UTF_8));Intent intent=new Intent(RuntimeEnvironment.getApplication(),PdfControllerActivity.class).putExtra("mediaId","pdf");ReaderActivity activity;
        try(var controller=Robolectric.buildActivity(PdfControllerActivity.class,intent).setup().visible()) {
            activity=controller.get();await(activity);activity.findViewById(R.id.readerNext).performClick();await(activity);assertEquals(1,db.library().readerProgress("pdf").page);
            activity.findViewById(R.id.readerPage).performClick();Shadows.shadowOf(Looper.getMainLooper()).idle();AlertDialog page=(AlertDialog)ShadowDialog.getLatestDialog();edit(page.getWindow().getDecorView()).setText("3");page.getButton(AlertDialog.BUTTON_POSITIVE).performClick();Shadows.shadowOf(Looper.getMainLooper()).idle();await(activity);
            assertEquals(2,db.library().readerProgress("pdf").page);assertFalse(activity.findViewById(R.id.readerNext).isEnabled());
        }closed(activity);
    }
    @Test public void libraryRoutesPdfToNativeReaderAndStartedFilterIncludesReadingProgress() throws Exception {
        media("pdf","a.pdf",new byte[0]);media("video","a.mp4",new byte[0]);ReaderProgress p=new ReaderProgress();p.mediaId="pdf";ReaderStore.save(db,p);
        try(var controller=Robolectric.buildActivity(MainActivity.class).setup().visible()) {
            var activity=controller.get();activity.findViewById(R.id.toggleFilters).performClick();((Spinner)activity.findViewById(R.id.typeFilter)).setSelection(0);((Spinner)activity.findViewById(R.id.filter)).setSelection(3);idle();
            var grid=(androidx.recyclerview.widget.RecyclerView)activity.findViewById(R.id.grid);assertEquals(1,grid.getAdapter().getItemCount());grid.measure(View.MeasureSpec.makeMeasureSpec(1000,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(600,View.MeasureSpec.EXACTLY));grid.layout(0,0,1000,600);
            grid.findViewHolderForAdapterPosition(0).itemView.performClick();var intent=Shadows.shadowOf(activity).getNextStartedActivity();assertEquals(ReaderActivity.class.getName(),intent.getComponent().getClassName());assertEquals("pdf",intent.getStringExtra("mediaId"));
        }
    }
    @Test public void tarGzipContentsSearchReadsTextAndRecreatesWithoutLosingProgress()throws Exception {
        media("compressed","album.tgz",ArchiveBookTest.fixture("album.tar.gz"));Intent intent=new Intent(RuntimeEnvironment.getApplication(),ReaderActivity.class).putExtra("mediaId","compressed");ReaderActivity current;
        try(var controller=Robolectric.buildActivity(ReaderActivity.class,intent).setup().visible()) {
            current=controller.get();await(current);assertNotNull(((ZoomImageView)current.findViewById(R.id.readerCanvas)).getDrawable());
            current.findViewById(R.id.readerContents).performClick();Shadows.shadowOf(Looper.getMainLooper()).idle();AlertDialog contents=(AlertDialog)ShadowDialog.getLatestDialog();assertEquals("Contenido del comprimido",((TextView)contents.findViewById(androidx.appcompat.R.id.alertTitle)).getText().toString());
            edit(contents.getWindow().getDecorView()).setText("notes");list(contents.getWindow().getDecorView()).performItemClick(null,0,0);await(current);assertTrue(((TextView)current.findViewById(R.id.readerText)).getText().toString().contains("estratos"));assertEquals("notes.txt",db.library().readerProgress("compressed").entry);
            ReaderActivity old=current;controller.recreate();closed(old);current=controller.get();await(current);assertTrue(((TextView)current.findViewById(R.id.readerText)).getText().toString().contains("estratos"));assertEquals(1,db.library().get("compressed").playCount);
        }closed(current);
    }
    @Test public void libraryRoutesTarGzipToReaderAndGzipReadingStateSurvivesBackupRestore()throws Exception {
        media("compressed","notes.txt.gz",ArchiveBookTest.gzip("Texto local".getBytes()));ReaderProgress saved=new ReaderProgress();saved.mediaId="compressed";saved.entry="notes.txt";saved.scroll=80;ReaderStore.save(db,saved);
        var copy=new java.io.ByteArrayOutputStream();BackupStore.write(db.library(),copy);saved.entry="changed";saved.scroll=2;ReaderStore.save(db,saved);BackupStore.read(db,new java.io.ByteArrayInputStream(copy.toByteArray()));assertEquals("notes.txt",db.library().readerProgress("compressed").entry);assertEquals(80,db.library().readerProgress("compressed").scroll);
        try(var controller=Robolectric.buildActivity(MainActivity.class).setup().visible()) {
            var activity=controller.get();activity.findViewById(R.id.toggleFilters).performClick();((Spinner)activity.findViewById(R.id.typeFilter)).setSelection(0);((Spinner)activity.findViewById(R.id.filter)).setSelection(3);idle();var grid=(androidx.recyclerview.widget.RecyclerView)activity.findViewById(R.id.grid);assertEquals(1,grid.getAdapter().getItemCount());grid.measure(View.MeasureSpec.makeMeasureSpec(1000,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(600,View.MeasureSpec.EXACTLY));grid.layout(0,0,1000,600);grid.findViewHolderForAdapterPosition(0).itemView.performClick();assertEquals(ReaderActivity.class.getName(),Shadows.shadowOf(activity).getNextStartedActivity().getComponent().getClassName());
        }
    }

    @Test public void sevenZipContentsRecreationAndBackupKeepReadingSeparateFromPlayback()throws Exception {
        media("7z","album.7z",SevenZipBookTest.fixture("album-solid.7z"));Intent intent=new Intent(RuntimeEnvironment.getApplication(),ReaderActivity.class).putExtra("mediaId","7z");ReaderActivity current;
        try(var controller=Robolectric.buildActivity(ReaderActivity.class,intent).setup().visible()){
            current=controller.get();await(current);current.findViewById(R.id.readerContents).performClick();Shadows.shadowOf(Looper.getMainLooper()).idle();AlertDialog contents=(AlertDialog)ShadowDialog.getLatestDialog();edit(contents.getWindow().getDecorView()).setText("notes");list(contents.getWindow().getDecorView()).performItemClick(null,0,0);await(current);assertTrue(((TextView)current.findViewById(R.id.readerText)).getText().toString().contains("estratos"));assertEquals("notes.txt",db.library().readerProgress("7z").entry);assertEquals(0,db.library().get("7z").position);
            ReaderActivity old=current;controller.recreate();closed(old);current=controller.get();await(current);assertTrue(((TextView)current.findViewById(R.id.readerText)).getText().toString().contains("estratos"));assertEquals(1,db.library().get("7z").playCount);
        }closed(current);var out=new java.io.ByteArrayOutputStream();BackupStore.write(db.library(),out);ReaderProgress changed=db.library().readerProgress("7z");changed.entry="empty.txt";ReaderStore.save(db,changed);BackupStore.read(db,new java.io.ByteArrayInputStream(out.toByteArray()));assertEquals("notes.txt",db.library().readerProgress("7z").entry);
    }
    @Test public void mainLibraryRoutesSevenZipToNativeReader()throws Exception {
        media("7z","a.7z",SevenZipBookTest.fixture("album-solid.7z"));try(var controller=Robolectric.buildActivity(MainActivity.class).setup().visible()){
            var activity=controller.get();activity.findViewById(R.id.toggleFilters).performClick();((Spinner)activity.findViewById(R.id.typeFilter)).setSelection(0);idle();var grid=(androidx.recyclerview.widget.RecyclerView)activity.findViewById(R.id.grid);assertEquals(1,grid.getAdapter().getItemCount());grid.measure(View.MeasureSpec.makeMeasureSpec(1000,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(600,View.MeasureSpec.EXACTLY));grid.layout(0,0,1000,600);grid.findViewHolderForAdapterPosition(0).itemView.performClick();assertEquals(ReaderActivity.class.getName(),Shadows.shadowOf(activity).getNextStartedActivity().getComponent().getClassName());
        }
    }

    @Test public void epubChapterNavigationJumpFontAndRecreationUseTextViewAndSpine()throws Exception {
        media("epub","book.epub",EpubBookTest.fixture("book3.epub"));Intent intent=new Intent(RuntimeEnvironment.getApplication(),ReaderActivity.class).putExtra("mediaId","epub");ReaderActivity current;
        try(var controller=Robolectric.buildActivity(ReaderActivity.class,intent).setup().visible()){
            current=controller.get();await(current);assertEquals(View.VISIBLE,current.findViewById(R.id.readerScroll).getVisibility());assertTrue(((TextView)current.findViewById(R.id.readerText)).getText().toString().contains("sedimentarias"));assertFalse(current.findViewById(R.id.readerPrevious).isEnabled());assertTrue(current.findViewById(R.id.readerNext).isEnabled());
            current.findViewById(R.id.readerZoomIn).performClick();float font=((TextView)current.findViewById(R.id.readerText)).getTextSize();current.findViewById(R.id.readerPage).performClick();Shadows.shadowOf(Looper.getMainLooper()).idle();AlertDialog dialog=(AlertDialog)ShadowDialog.getLatestDialog();edit(dialog.getWindow().getDecorView()).setText("2");dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick();Shadows.shadowOf(Looper.getMainLooper()).idle();await(current);assertEquals("EPUB/text/cap dos.xhtml",db.library().readerProgress("epub").entry);assertFalse(current.findViewById(R.id.readerNext).isEnabled());assertTrue(current.findViewById(R.id.readerPrevious).isEnabled());
            ReaderActivity old=current;controller.recreate();closed(old);current=controller.get();await(current);assertTrue(((TextView)current.findViewById(R.id.readerText)).getText().toString().contains("Capítulo dos"));assertEquals(font,((TextView)current.findViewById(R.id.readerText)).getTextSize(),0.01f);assertEquals(1,db.library().get("epub").playCount);assertEquals(1,db.library().usageCount());assertEquals("EPUB/text/cap dos.xhtml",db.library().usageBackup(1).get(0).entry);current.findViewById(R.id.readerPrevious).performClick();await(current);assertTrue(((TextView)current.findViewById(R.id.readerStatus)).getText().toString().contains("Capítulo 1 / 2"));
        }closed(current);
    }
    @Test public void epubFailedChapterKeepsValidTextAndProgressAndIndexCanOpenLocalPicture()throws Exception {
        var map=EpubBookTest.contents();map.put("EPUB/text/cap dos.xhtml",new byte[]{(byte)255});media("epub","book.epub",EpubBookTest.encode(map));ReaderActivity activity;
        try(var controller=Robolectric.buildActivity(ReaderActivity.class,new Intent(RuntimeEnvironment.getApplication(),ReaderActivity.class).putExtra("mediaId","epub")).setup().visible()){
            activity=controller.get();await(activity);activity.findViewById(R.id.readerNext).performClick();await(activity);assertTrue(((TextView)activity.findViewById(R.id.readerText)).getText().toString().contains("sedimentarias"));assertEquals("EPUB/text/10.xhtml",db.library().readerProgress("epub").entry);
            activity.findViewById(R.id.readerContents).performClick();Shadows.shadowOf(Looper.getMainLooper()).idle();AlertDialog contents=(AlertDialog)ShadowDialog.getLatestDialog();assertEquals("Capítulos e imágenes del EPUB",((TextView)contents.findViewById(androidx.appcompat.R.id.alertTitle)).getText().toString());edit(contents.getWindow().getDecorView()).setText("portada");list(contents.getWindow().getDecorView()).performItemClick(null,0,0);await(activity);assertNotNull(((ZoomImageView)activity.findViewById(R.id.readerCanvas)).getDrawable());assertEquals("EPUB/images/portada color.png",db.library().readerProgress("epub").entry);
        }closed(activity);
    }
    @Test public void epubRoutesFromOtherFilesAndBackupKeepsChapterAndScrollWithoutAvProgress()throws Exception {
        media("epub","book.epub",EpubBookTest.fixture("book3.epub"));ReaderProgress saved=new ReaderProgress();saved.mediaId="epub";saved.entry="EPUB/text/cap dos.xhtml";saved.page=1;saved.scroll=80;ReaderStore.save(db,saved);var bytes=new java.io.ByteArrayOutputStream();BackupStore.write(db.library(),bytes);saved.entry="changed";saved.scroll=2;ReaderStore.save(db,saved);BackupStore.read(db,new java.io.ByteArrayInputStream(bytes.toByteArray()));assertEquals("EPUB/text/cap dos.xhtml",db.library().readerProgress("epub").entry);assertEquals(80,db.library().readerProgress("epub").scroll);assertEquals(0,db.library().get("epub").position);
        try(var controller=Robolectric.buildActivity(MainActivity.class).setup().visible()){
            var activity=controller.get();activity.findViewById(R.id.toggleFilters).performClick();((Spinner)activity.findViewById(R.id.typeFilter)).setSelection(0);((Spinner)activity.findViewById(R.id.filter)).setSelection(3);idle();var grid=(androidx.recyclerview.widget.RecyclerView)activity.findViewById(R.id.grid);assertEquals(1,grid.getAdapter().getItemCount());grid.measure(View.MeasureSpec.makeMeasureSpec(1000,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(600,View.MeasureSpec.EXACTLY));grid.layout(0,0,1000,600);grid.findViewHolderForAdapterPosition(0).itemView.performClick();assertEquals(ReaderActivity.class.getName(),Shadows.shadowOf(activity).getNextStartedActivity().getComponent().getClassName());
        }
    }

}
