package com.peach.local;
import android.os.Looper;
import android.net.Uri;
import androidx.room.Room;
import java.io.*;
import java.nio.file.Files;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class) @Config(sdk=28) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class RedirectFlowTest {
    LibraryDatabase db;SourcesActivity activity;SourcesActivity.AttachmentFetcher previous;
    @Before public void open(){db=Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",db);previous=SourcesActivity.attachmentFetcher;}
    @After public void close()throws Exception{if(activity!=null){var d=draft();d.token.cancel();d.worker.shutdown();assertTrue(d.worker.awaitTermination(30,TimeUnit.SECONDS));d.clearPrepared();}SourcesActivity.attachmentFetcher=previous;db.close();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);}
    SourcesActivity.Draft draft(){return new androidx.lifecycle.ViewModelProvider(activity).get(SourcesActivity.Draft.class);}
    void idle()throws Exception{for(int i=0;i<3;i++){draft().worker.submit(()->{}).get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}}
    @Test public void redirectedOwnMp4PassesActualHttpDownloadPreparationAndSafCopy()throws Exception{
        byte[] bytes=RedirectHttpTest.own();var first=RedirectHttpTest.redirect(MediaRedirectsTest.CDN);var second=new RedirectHttpTest.Reply(MediaRedirectsTest.CDN,200,null,bytes);var factory=new RedirectHttpTest.Factory(first,second);
        SourcesActivity.attachmentFetcher=(u,f,t)->SourceHttp.download(u,f,t,SourceHttp.LARGE_DOWNLOAD_LIMIT,factory,MediaRedirectsTest.PUBLIC);
        try(var controller=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){activity=controller.get();idle();draft().prepare(MediaRedirectsTest.ORIGINAL,"own.bin","video");assertTrue(draft().preparedName.endsWith(".mp4"));Uri uri=Uri.parse("content://own.fixture/redirected");ByteArrayOutputStream out=new ByteArrayOutputStream();Shadows.shadowOf(activity.getContentResolver()).registerOutputStream(uri,out);draft().savePrepared(uri);assertArrayEquals(bytes,out.toByteArray());assertEquals(2,factory.requests.size());assertEquals(uri.toString(),draft().lastVideoUri);assertTrue(db.library().allMedia().isEmpty());assertTrue(db.library().sources().isEmpty());assertFalse(draft().status.contains("OWN_ONLY"));assertTrue(SourcesActivity.Draft.activeDownloads.isEmpty());}
    }
    @Test public void unsupportedBinaryFromVideoServerIsNotSavedAsCompletedVideo()throws Exception{
        SourcesActivity.attachmentFetcher=(u,f,t)->SourceHttp.copyAttachment(u,new ByteArrayInputStream(new byte[]{1,2,3}),f,3,t);
        try(var controller=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){activity=controller.get();idle();try{draft().prepare(MediaRedirectsTest.ORIGINAL,"own.bin","video");fail();}catch(IOException e){assertTrue(e.getMessage().contains("reconocible"));}assertNull(draft().prepared);assertTrue(draft().lastVideoUri.isEmpty());assertTrue(SourcesActivity.Draft.activeDownloads.isEmpty());}
    }
}
