package com.peach.local;

import java.io.*;
import java.nio.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.CRC32;
import org.apache.commons.compress.archivers.sevenz.*;
import org.junit.*;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

public class SevenZipBookTest {
    @Rule public TemporaryFolder temp=new TemporaryFolder();
    static byte[] fixture(String name)throws Exception{try(var in=SevenZipBookTest.class.getClassLoader().getResourceAsStream("archives160/"+name)){assertNotNull(in);return in.readAllBytes();}}
    File file(byte[] bytes)throws Exception{File f=temp.newFile();Files.write(f.toPath(),bytes);return f;}
    static String text(File file)throws IOException{return new String(Files.readAllBytes(file.toPath()),java.nio.charset.StandardCharsets.UTF_8);}
    void rejected(byte[] data)throws Exception{try(var book=new SevenZipBook(file(data))){fail("Invalid 7z accepted");}catch(IOException expected){}}
    @Test public void independentLzmaLzma2AndCopyFixturesIndexAndReadWithoutExtractingDirectories()throws Exception{
        for(String fixture:List.of("album-solid.7z","album-lzma.7z","album-copy.7z"))try(var book=new SevenZipBook(file(fixture(fixture)))){
            List<String> names=book.items().stream().map(ArchiveBook.Item::name).toList();assertTrue(names.indexOf("images/2.png")<names.indexOf("images/10.png"));assertTrue(names.contains("日本語.txt"));assertEquals("",book.item("link.txt").kind());assertEquals("",book.item("nested.7z").kind());
            File out=temp.newFolder();assertEquals(0,out.list().length);assertTrue(text(book.read("notes.txt",out)).contains("estratos"));assertEquals("Texto Unicode",text(book.read("日本語.txt",out)));assertEquals(List.of("entry"),List.of(out.list()));
            for(String name:List.of("link.txt","nested.7z","video.mp4"))try{book.read(name,out);fail();}catch(IOException expected){}
        }
    }
    @Test public void solidEntriesCanBeSelectedInBothDirectionsAndEmptyFilesDoNotReusePriorStream()throws Exception{
        try(var book=new SevenZipBook(file(fixture("album-solid.7z")))){File out=temp.newFolder();for(String name:List.of("notes.txt","日本語.txt","empty.txt","notes.txt","empty.txt")){File selected=book.read(name,out);if(name.equals("empty.txt"))assertEquals(0,selected.length());else assertTrue(selected.length()>0);}assertEquals(1,out.list().length);}
    }
    @Test public void corruptedDataDoesNotReplaceLastValidViewAndNewSelectionStillWorks()throws Exception{
        byte[] bytes=fixture("crc-copy.7z");bytes[32]^=1;File out=temp.newFolder();Files.write(new File(out,"entry").toPath(),"anterior".getBytes());try(var book=new SevenZipBook(file(bytes))){try{book.read("safe.txt",out);fail();}catch(IOException expected){}assertEquals("anterior",text(new File(out,"entry")));assertFalse(new File(out,"entry-part").exists());}
    }
    @Test public void truncatedBadSignatureStartCrcHeaderCrcAndTrailingDataAreRejected()throws Exception{
        byte[] normal=fixture("album-copy.7z");rejected(Arrays.copyOf(normal,31));rejected(Arrays.copyOf(normal,normal.length-1));
        for(int pos:new int[]{0,8,normal.length-2}){byte[] bad=normal.clone();bad[pos]^=1;rejected(bad);}rejected(Arrays.copyOf(normal,normal.length+1));
    }
    static byte[] wrap(byte[] next)throws Exception {
        byte[] raw=new byte[32+next.length];byte[] signature={0x37,0x7a,(byte)0xbc,(byte)0xaf,0x27,0x1c};System.arraycopy(signature,0,raw,0,6);raw[7]=4;System.arraycopy(next,0,raw,32,next.length);
        ByteBuffer b=ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN);b.putLong(12,0);b.putLong(20,next.length);CRC32 crc=new CRC32();crc.update(next);b.putInt(28,(int)crc.getValue());crc.reset();crc.update(raw,12,20);b.putInt(8,(int)crc.getValue());return raw;
    }
    @Test public void encodedHeaderExpansionIsBoundedBeforeLibraryAllocatesItsOutput()throws Exception{
        // Encoded header: one COPY folder, declared output >4MiB, with no data to decode.
        var next=new ByteArrayOutputStream();next.write(new byte[]{0x17,6,0,1,9,0,0,7,11,1,0,1,1,0,12,(byte)255});next.write(ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(SevenZipBook.MAX_HEADER+1L).array());next.write(new byte[]{0,0});rejected(wrap(next.toByteArray()));
        // Header outside raw byte cap, without actually allocating it.
        byte[] normal=fixture("album-copy.7z");ByteBuffer b=ByteBuffer.wrap(normal).order(ByteOrder.LITTLE_ENDIAN);b.putLong(20,SevenZipBook.MAX_HEADER+1L);CRC32 crc=new CRC32();crc.update(normal,12,20);b.putInt(8,(int)crc.getValue());rejected(normal);
    }
    @Test public void encryptedHeaderAndEncryptedEntryRemainUnsupportedWithoutPasswords()throws Exception{
        rejected(fixture("encrypted-header.7z"));File out=temp.newFolder();try(var book=new SevenZipBook(file(fixture("encrypted-data.7z")))){assertNotNull(book.item("notes.txt"));try{book.read("notes.txt",out);fail();}catch(IOException expected){}assertEquals(0,out.list().length);}
    }
    @Test public void dictionaryMemoryAndDeclaredTotalAndSelectedEntrySizesAreBounded()throws Exception{
        rejected(fixture("total-limit.7z"));for(String fixture:List.of("large-dictionary.7z","entry-limit.7z")){File out=temp.newFolder();try(var book=new SevenZipBook(file(fixture(fixture)))){String name=fixture.startsWith("entry")?"big1.txt":"notes.txt";try{book.read(name,out);fail();}catch(IOException expected){}assertEquals(0,out.list().length);}}
    }
    File copyArchive(String... names)throws Exception {
        File file=temp.newFile();try(var out=new SevenZOutputFile(file)){out.setContentCompression(SevenZMethod.COPY);for(String name:names){var e=new SevenZArchiveEntry();e.setName(name);e.setSize(0);out.putArchiveEntry(e);out.closeArchiveEntry();}}return file;
    }
    @Test public void unsafeDuplicateUnnamedAndMoreThanTenThousandEntriesAreRejected()throws Exception {
        for(String name:List.of("","../escape.txt","/absolute.txt","C:\\absolute.txt","a/../escape.txt","a/./escape.txt","bad\nname.txt"))rejected(Files.readAllBytes(copyArchive(name).toPath()));
        rejected(Files.readAllBytes(copyArchive("same.txt","same.txt").toPath()));String[] many=new String[10001];for(int i=0;i<many.length;i++)many[i]="f"+i;rejected(Files.readAllBytes(copyArchive(many).toPath()));
    }
    @Test public void specialUnixReparseAndAntiEntriesCannotBecomeReadableText()throws Exception {
        var e=new SevenZArchiveEntry();e.setName("a.txt");assertTrue(SevenZipBook.regular(e));e.setAntiItem(true);assertFalse(SevenZipBook.regular(e));e.setAntiItem(false);e.setHasWindowsAttributes(true);e.setWindowsAttributes(0x400);assertFalse(SevenZipBook.regular(e));
        e.setWindowsAttributes((0120777<<16)|0x8000);assertFalse(SevenZipBook.regular(e));e.setWindowsAttributes((0100644<<16)|0x8000);assertTrue(SevenZipBook.regular(e));
    }
    @Test public void cancelledIndexOrSelectionPreservesCacheAndRecoveryIsPossible()throws Exception {
        File source=file(fixture("album-solid.7z"));Thread.currentThread().interrupt();try(var book=new SevenZipBook(source)){fail();}catch(InterruptedIOException expected){}finally{Thread.interrupted();}
        try(var book=new SevenZipBook(source)){File out=temp.newFolder();Files.write(new File(out,"entry").toPath(),"previo".getBytes());Thread.currentThread().interrupt();try{book.read("notes.txt",out);fail();}catch(InterruptedIOException expected){}finally{Thread.interrupted();}assertEquals("previo",text(new File(out,"entry")));assertTrue(text(book.read("notes.txt",out)).contains("estratos"));}
    }
    @Test public void emptyDeclaredStreamWithNonzeroCrcCannotBypassIntegrityCheck()throws Exception {
        byte[] raw=fixture("crc-copy.7z");ByteBuffer view=ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN);int offset=32+(int)view.getLong(12),size=(int)view.getLong(20);boolean changed=false;
        for(int i=offset;i<offset+size-1;i++)if(raw[i]==12 && (raw[i+1]&255)=="CRC propio".getBytes().length){raw[i+1]=0;changed=true;break;}assertTrue(changed);
        CRC32 crc=new CRC32();crc.update(raw,offset,size);view.putInt(28,(int)crc.getValue());crc.reset();crc.update(raw,12,20);view.putInt(8,(int)crc.getValue());File out=temp.newFolder();try(var book=new SevenZipBook(file(raw))){assertEquals(0,book.item("safe.txt").bytes());try{book.read("safe.txt",out);fail();}catch(IOException expected){assertTrue(expected.getMessage().contains("CRC"));}assertEquals(0,out.list().length);}
    }

}
