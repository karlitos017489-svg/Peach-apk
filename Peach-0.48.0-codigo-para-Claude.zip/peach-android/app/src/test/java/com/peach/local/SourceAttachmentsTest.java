package com.peach.local;
import java.io.*;
import java.util.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class) @Config(sdk=28) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class SourceAttachmentsTest {
    @Test public void imageVideoAndFileRemainProviderBoundWithLegacyPawFlags()throws Exception{
        for(var entry:SourceVideosTest.urls().entrySet())for(String kind:List.of("image","video","file")){
            var p=GalleryProvidersTest.publication(entry.getKey());JSONArray a=new JSONArray();for(String url:SourceVideosTest.urls().values())a.put(SourceVideosTest.video(url).put("kind",kind));var c=GalleryProvidersTest.content(p,a);assertEquals(1,SourceAttachments.select(p,c).size());assertEquals(entry.getValue(),SourceAttachments.select(p,c).get(0).url());
            c.attachments=new JSONArray().put(SourceVideosTest.video(entry.getValue()).put("kind",kind).put("downloadable",false)).toString();assertEquals(p.provider.equals("pawchive")?1:0,SourceAttachments.select(p,c).size());
        }
    }
    @Test public void referenceKindsUnknownSourcesAndMalformedBodiesCannotEnqueueUrls()throws Exception{
        for(String provider:List.of("patreon","subscribestar")){var p=GalleryProvidersTest.publication(provider);assertTrue(SourceAttachments.select(p,GalleryProvidersTest.content(p,new JSONArray().put(SourceVideosTest.video(DownloadQueueTest.A)))).isEmpty());}
        var p=GalleryProvidersTest.publication("fanbox");var c=GalleryProvidersTest.content(p,new JSONArray().put(SourceVideosTest.video(DownloadQueueTest.A).put("kind","reference")));assertTrue(SourceAttachments.select(p,c).isEmpty());
        for(String malformed:List.of("{}","[true]","[{\"name\":\"own\"}]","["+String.join(",",Collections.nCopies(1001,"{}"))+"]")){c.attachments=malformed;try{SourceAttachments.select(p,c);fail();}catch(IOException expected){}}
    }
    @Test public void fileAttachmentsSurvivePersonalBackupWithoutOperationalQueueData()throws Exception{
        var db=androidx.room.Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().build();try{var p=GalleryProvidersTest.publication("fanbox");var c=GalleryProvidersTest.content(p,new JSONArray().put(SourceVideosTest.video("https://downloads.fanbox.cc/own.txt").put("kind","file").put("name","own.txt")));db.library().insertPublication(p);db.library().putPublicationContent(c);String before=c.attachments;ByteArrayOutputStream bytes=new ByteArrayOutputStream();BackupStore.write(db.library(),bytes);JSONObject json=new JSONObject(bytes.toString("UTF-8"));assertEquals(19,json.getInt("version"));assertFalse(json.has("downloadQueue"));db.library().deletePublication(p.id);BackupStore.read(db,new ByteArrayInputStream(bytes.toByteArray()));assertEquals("file",SourceAttachments.load(db,p.id).get(0).kind());assertEquals(before,db.library().publicationContent(p.id).attachments);assertTrue(db.library().allMedia().isEmpty());}finally{db.close();}
    }
}
