package com.peach.local;

import java.io.*;
import java.nio.file.Files;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE)
public class SourceDocumentsTest {
    @Test public void downloadedFileIsCopiedThroughContentResolverAndOutputIsClosed()throws Exception{var app=RuntimeEnvironment.getApplication();var uri=android.net.Uri.parse("content://fixture/public-download");boolean[] closed={false};ByteArrayOutputStream out=new ByteArrayOutputStream(){@Override public void close()throws IOException{closed[0]=true;super.close();}};Shadows.shadowOf(app.getContentResolver()).registerOutputStream(uri,out);File file=File.createTempFile("source-document-",".tmp",app.getCacheDir());try{Files.write(file.toPath(),"contenido".getBytes());SourcesActivity.Draft.copyToDocument(app,uri,file);assertArrayEquals("contenido".getBytes(),out.toByteArray());assertTrue(closed[0]);}finally{file.delete();}}
    @Test public void providerWriteFailureClosesOutputAndIsNotReportedAsSuccess()throws Exception{var app=RuntimeEnvironment.getApplication();var uri=android.net.Uri.parse("content://fixture/broken-download");boolean[] closed={false};OutputStream out=new OutputStream(){@Override public void write(int b)throws IOException{throw new IOException("Provider error");}@Override public void close(){closed[0]=true;}};Shadows.shadowOf(app.getContentResolver()).registerOutputStream(uri,out);File file=File.createTempFile("source-document-",".tmp",app.getCacheDir());try{Files.write(file.toPath(),new byte[]{1,2,3});try{SourcesActivity.Draft.copyToDocument(app,uri,file);fail();}catch(IOException expected){}assertTrue(closed[0]);}finally{file.delete();}}
    @Test public void orphanPrivateDownloadsArePrunedWhileActiveFilesAndOtherCachesRemain()throws Exception{File directory=RuntimeEnvironment.getApplication().getCacheDir(),orphan=File.createTempFile("peach-public-download-",".tmp",directory),other=File.createTempFile("other-cache-",".tmp",directory),active=SourcesActivity.Draft.downloadFile(directory);try{assertFalse(orphan.exists());SourcesActivity.Draft.pruneDownloads(directory);assertTrue(active.exists());assertTrue(other.exists());SourcesActivity.Draft.releaseDownload(active);assertFalse(active.exists());}finally{SourcesActivity.Draft.releaseDownload(active);orphan.delete();other.delete();}}
}
