package com.peach.local;

import java.io.*;
import java.util.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class SourceGalleryTest {
    static final String A="https://downloads.fanbox.cc/images/a.png",B="https://pixivfanbox.akamaized.net/images/b.png";
    static Publication publication(){Publication p=new Publication();p.id="gallery-post";p.provider="fanbox";p.sourceRef="artist";p.sourceLabel="Autora";p.externalId="123";p.title="Galería propia";return p;}
    static JSONObject image(String url)throws Exception{return new JSONObject().put("kind","image").put("name","Imagen.png").put("url",url).put("downloadable",true);}
    static PublicationContent content()throws Exception{PublicationContent c=new PublicationContent();c.publicationId=publication().id;c.attachments=new JSONArray().put(image(A)).put(image(B)).toString();return c;}
    static byte[] png()throws Exception{try(InputStream in=SourceGalleryTest.class.getResourceAsStream("/media/small.png")){return in.readAllBytes();}}
    LibraryDatabase db;
    @Before public void open(){db=androidx.room.Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().build();}
    @After public void close(){db.close();}
    @Test public void preservesImportedOrderDeduplicatesAndReturnsImmutableSelection()throws Exception{var c=content();c.attachments=new JSONArray(c.attachments).put(image(A)).toString();var s=SourceGallery.select(publication(),c);assertEquals(List.of(A,B),s.images().stream().map(SourceGallery.Image::url).toList());try{s.images().clear();fail();}catch(UnsupportedOperationException expected){}assertTrue(s.partial());}
    @Test public void filesExternalHostsAndFalseFlagsAreOmitted()throws Exception{var c=content();c.attachments=new JSONArray().put(image(A)).put(image(B).put("kind","file")).put(image("https://example.org/x.png")).put(image(B).put("downloadable",false)).toString();var s=SourceGallery.select(publication(),c);assertEquals(1,s.images().size());assertEquals(3,s.omitted());}
    @Test public void rejectsMissingContentMismatchedIdsAndUnknownProviders()throws Exception{for(int i=0;i<4;i++){var p=publication();var c=content();if(i==0)p=null;if(i==1)c=null;if(i==2)c.publicationId="another";if(i==3)p.provider="unknown";try{SourceGallery.select(p,c);fail();}catch(IOException expected){}}}
    @Test public void rejectsMalformedMetadataAndExcessAttachments()throws Exception{for(String bad:List.of("{}","[1]","[{\"kind\":\"image\",\"name\":true}]","["+String.join(",",Collections.nCopies(1001,"{}"))+"]")){var c=content();c.attachments=bad;try{SourceGallery.select(publication(),c);fail();}catch(IOException expected){}}}
    @Test public void savedIdLoadsWithoutCreatingMediaOrHistory()throws Exception{db.library().insertPublication(publication());db.library().putPublicationContent(content());assertEquals(2,SourceGallery.load(db,publication().id).images().size());assertTrue(db.library().allMedia().isEmpty());assertEquals(0,db.library().usageCount());}
    @Test public void backupElevenRetainsImageReferencesWithoutEmbeddingMedia()throws Exception{db.library().insertPublication(publication());db.library().putPublicationContent(content());ByteArrayOutputStream out=new ByteArrayOutputStream();BackupStore.write(db.library(),out);assertEquals(19,new JSONObject(out.toString("UTF-8")).getInt("version"));db.library().deletePublication(publication().id);BackupStore.read(db,new ByteArrayInputStream(out.toByteArray()));assertEquals(List.of(A,B),SourceGallery.load(db,publication().id).images().stream().map(SourceGallery.Image::url).toList());assertTrue(db.library().allMedia().isEmpty());assertEquals(0,db.library().usageCount());}
}
