package com.peach.local;

import android.content.Intent;
import android.os.Looper;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowDialog;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land") @GraphicsMode(GraphicsMode.Mode.NATIVE) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class SourceGalleryUiTest {
    LibraryDatabase db;List<String> urls=Collections.synchronizedList(new ArrayList<>());List<ActivityController<SourceGalleryActivity>> screens=new ArrayList<>();
    @Before public void open()throws Exception{db=androidx.room.Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",db);db.library().insertPublication(SourceGalleryTest.publication());db.library().putPublicationContent(SourceGalleryTest.content());RuntimeEnvironment.getApplication().getSharedPreferences("source-gallery",0).edit().clear().commit();clean();SourceGalleryActivity.fetcher=this::fetch;}
    SourceHttp.Download fetch(String u,File f,SourceHttp.Token t)throws IOException{urls.add(u);try{byte[] b=SourceGalleryTest.png();Files.write(f.toPath(),b);return new SourceHttp.Download(b.length,GalleryCache.checksum(f));}catch(Exception e){throw new IOException(e);}}
    void clean()throws Exception{File root=new GalleryCache(RuntimeEnvironment.getApplication().getCacheDir()).root;if(root.exists())try(var paths=Files.walk(root.toPath())){paths.sorted(Comparator.reverseOrder()).forEach(p->p.toFile().delete());}}
    void idle()throws Exception{LibraryDatabase.IO.submit(()->{}).get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}
    void settle(SourceGalleryActivity a)throws Exception{idle();a.worker.submit(()->{}).get(30,TimeUnit.SECONDS);idle();}
    ActivityController<SourceGalleryActivity> screen(String id){Intent i=new Intent(RuntimeEnvironment.getApplication(),SourceGalleryActivity.class).putExtra("publicationId",id);var c=Robolectric.buildActivity(SourceGalleryActivity.class,i).setup().visible();screens.add(c);return c;}
    @After public void close()throws Exception{for(var c:screens){var a=c.get();c.pause().stop().destroy();assertTrue(a.worker.awaitTermination(30,TimeUnit.SECONDS));}SourceGalleryActivity.fetcher=SourceHttp::image;idle();db.close();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);clean();}
    @Test public void navigationZoomAndRotationUseSavedSelectionAndCache()throws Exception{var c=screen("gallery-post");settle(c.get());assertTrue(c.get().shown);assertEquals(List.of(SourceGalleryTest.A),urls);c.get().findViewById(R.id.imageZoomIn).performClick();assertTrue(c.get().canvas.zoomFactor()>1);c.get().findViewById(R.id.imageFit).performClick();assertEquals(1,c.get().canvas.zoomFactor(),0);c.get().findViewById(R.id.imageNext).performClick();settle(c.get());assertEquals(1,c.get().index);assertEquals(2,urls.size());c.recreate();settle(c.get());assertEquals(1,c.get().index);assertTrue(c.get().shown);assertEquals(2,urls.size());assertTrue(db.library().allMedia().isEmpty());assertEquals(0,db.library().usageCount());}
    @Test public void offlineNeverFetchesAndCachedImageRemainsAvailable()throws Exception{RuntimeEnvironment.getApplication().getSharedPreferences("source-gallery",0).edit().putBoolean("offline",true).commit();var c=screen("gallery-post");settle(c.get());assertTrue("Offline no debe consultar",urls.isEmpty());assertFalse(c.get().shown);assertTrue(((TextView)c.get().findViewById(R.id.imageStatus)).getText().toString().contains("no está en caché"));c.get().offline.setChecked(false);settle(c.get());assertEquals(1,urls.size());c.get().offline.setChecked(true);settle(c.get());assertTrue(c.get().shown);c.get().findViewById(R.id.imageNext).performClick();settle(c.get());assertFalse(c.get().shown);assertFalse(c.get().findViewById(R.id.imageZoomIn).isEnabled());assertEquals(1,urls.size());}
    @Test public void nextCancelsOldRequestAndStaleImageNeverReplacesSelection()throws Exception{CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);boolean[] cancelled={false};SourceGalleryActivity.fetcher=(u,f,t)->{if(u.equals(SourceGalleryTest.A)){entered.countDown();try{release.await(10,TimeUnit.SECONDS);}catch(InterruptedException e){/* emulate a transport completing late */}cancelled[0]=t.cancelled;}return fetch(u,f,t);};var c=screen("gallery-post");idle();assertTrue(entered.await(10,TimeUnit.SECONDS));c.get().findViewById(R.id.imageNext).performClick();release.countDown();settle(c.get());assertTrue(cancelled[0]);assertEquals(1,c.get().index);assertTrue(c.get().shown);assertFalse(new File(new GalleryCache(c.get().getCacheDir()).root,GalleryCache.key(SourceGalleryTest.A)+".image").exists());assertEquals(SourceGalleryTest.B,urls.get(urls.size()-1));}
    @Test public void missingPublicationDoesNotFetchAndCallerUrlIsIgnored()throws Exception{var c=screen("absent");c.get().getIntent().putExtra("url",SourceGalleryTest.A);settle(c.get());assertNull(c.get().selection);assertTrue(urls.isEmpty());assertFalse(c.get().findViewById(R.id.gallery_retry).isEnabled());}
    @Test public void savedBodyOffersGalleryAndPreservesSaveAttachmentAction()throws Exception{try(var c=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){idle();c.get().content(SourceGalleryTest.publication(),SourceGalleryTest.content(),null);AlertDialog d=(AlertDialog)ShadowDialog.getLatestDialog();assertEquals("Ver imágenes",d.getButton(AlertDialog.BUTTON_POSITIVE).getText().toString());assertEquals("Guardar adjunto",d.getButton(AlertDialog.BUTTON_NEUTRAL).getText().toString());d.getButton(AlertDialog.BUTTON_POSITIVE).performClick();idle();Intent next=Shadows.shadowOf(c.get()).getNextStartedActivity();assertEquals(SourceGalleryActivity.class.getName(),next.getComponent().getClassName());assertEquals("gallery-post",next.getStringExtra("publicationId"));}}
    @Test public void importedProvidersOfferGalleryWhileUnimportedReviewDoesNotOpenIt()throws Exception{
        try(var c=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){
            idle();for(var own:GalleryProvidersTest.urls(SourceGalleryTest.png()).entrySet()){
                var p=GalleryProvidersTest.publication(own.getKey());var body=GalleryProvidersTest.content(p,new org.json.JSONArray().put(SourceGalleryTest.image(own.getValue())));
                c.get().content(p,body,null);AlertDialog d=(AlertDialog)ShadowDialog.getLatestDialog();assertEquals("Ver imágenes",d.getButton(AlertDialog.BUTTON_POSITIVE).getText().toString());d.getButton(AlertDialog.BUTTON_POSITIVE).performClick();idle();Intent next=Shadows.shadowOf(c.get()).getNextStartedActivity();assertEquals(p.id,next.getStringExtra("publicationId"));
                c.get().content(p,body,p.externalId);d=(AlertDialog)ShadowDialog.getLatestDialog();assertNotEquals("Ver imágenes",d.getButton(AlertDialog.BUTTON_POSITIVE).getText().toString());d.dismiss();
            }
        }assertTrue(urls.isEmpty());
    }
    @Test public void pawLegacyImportedImageOpensAndRotatesWithoutRefetchOrCatalogMutation()throws Exception{
        var p=GalleryProvidersTest.publication("pawchive");String url=GalleryProvidersTest.urls(SourceGalleryTest.png()).get("pawchive");
        var body=GalleryProvidersTest.content(p,new org.json.JSONArray().put(SourceGalleryTest.image(url).put("downloadable",false)));db.library().insertPublication(p);db.library().putPublicationContent(body);
        var c=screen(p.id);settle(c.get());assertTrue(c.get().shown);assertEquals(List.of(url),urls);c.recreate();settle(c.get());assertTrue(c.get().shown);assertEquals(1,urls.size());
        assertEquals(body.attachments,db.library().publicationContent(p.id).attachments);assertTrue(db.library().allMedia().isEmpty());assertEquals(0,db.library().usageCount());
    }
    @Test public void galleryAnimationStopsOnPauseResumesAndReleasesWhenNavigating()throws Exception{
        SourceGalleryActivity.fetcher=(u,f,t)->{urls.add(u);try(var in=getClass().getResourceAsStream("/media/own-animated.gif")){Files.copy(in,f.toPath(),StandardCopyOption.REPLACE_EXISTING);}return new SourceHttp.Download(f.length(),GalleryCache.checksum(f));};
        var c=screen("gallery-post");settle(c.get());var first=(android.graphics.drawable.AnimatedImageDrawable)c.get().canvas.getDrawable();assertTrue(first.isRunning());
        c.pause().stop();assertFalse(first.isRunning());c.start().resume().visible();settle(c.get());assertTrue(first.isRunning());assertEquals(1,urls.size());
        c.get().findViewById(R.id.imageNext).performClick();settle(c.get());assertFalse(first.isRunning());var second=(android.graphics.drawable.AnimatedImageDrawable)c.get().canvas.getDrawable();assertTrue(second.isRunning());
        c.recreate();settle(c.get());assertFalse(second.isRunning());assertEquals(1,c.get().index);assertTrue(c.get().canvas.getDrawable() instanceof android.graphics.drawable.AnimatedImageDrawable);assertEquals(2,urls.size());
        assertTrue(db.library().allMedia().isEmpty());assertEquals(0,db.library().usageCount());
    }
}
