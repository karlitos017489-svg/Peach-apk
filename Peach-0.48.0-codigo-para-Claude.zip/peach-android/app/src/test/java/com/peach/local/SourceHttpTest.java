package com.peach.local;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import org.junit.*;
import static org.junit.Assert.*;

public class SourceHttpTest {
    @Test public void onlyOfficialAttachmentHostsAndSafeHeadersAreAccepted(){assertTrue(SourceHttp.downloadable("https://downloads.fanbox.cc/a.png"));for(String u:List.of("http://downloads.fanbox.cc/a","https://downloads.fanbox.cc.evil.org/a","https://127.0.0.1/a","https://u:p@downloads.fanbox.cc/a","https://downloads.fanbox.cc:8443/a"))assertFalse(u,SourceHttp.downloadable(u));assertEquals("",SourceHttp.header("v1\r\nCookie: bad"));assertEquals("v1",SourceHttp.header("v1"));assertEquals(300,SourceHttp.retry("not-a-time"));assertEquals(86400,SourceHttp.retry("999999"));}
    @Test public void actualStreamDownloadChecksLengthChecksumAndClosesResources()throws Exception{File file=File.createTempFile("peach-copy-test",".tmp");boolean[] closed={false};try{InputStream in=new ByteArrayInputStream("abc".getBytes()){@Override public void close()throws IOException{closed[0]=true;super.close();}};var result=SourceHttp.copy(in,file,3,new SourceHttp.Token());assertEquals(3,result.bytes());assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",result.sha256());assertTrue(closed[0]);assertArrayEquals("abc".getBytes(),Files.readAllBytes(file.toPath()));}finally{file.delete();}}
    @Test public void cancelledEmptyTruncatedAndOversizedStreamsLeaveNoPrivatePartialFiles()throws Exception{for(int mode=0;mode<4;mode++){File file=File.createTempFile("peach-copy-test",".tmp");SourceHttp.Token token=new SourceHttp.Token();if(mode==0)token.cancel();try{SourceHttp.copy(new ByteArrayInputStream(mode==1?new byte[0]:new byte[]{1,2}),file,mode==2?3:mode==3?SourceHttp.DOWNLOAD_LIMIT+1:2,token);fail();}catch(IOException expected){}assertFalse(file.exists());}}
    @Test public void apiReadsRejectOversizeAndCancellationBeforePublishingAnyResult()throws Exception{try{SourceHttp.bounded(new ByteArrayInputStream(new byte[5]),4,new SourceHttp.Token());fail();}catch(IOException expected){}SourceHttp.Token token=new SourceHttp.Token();token.cancel();try{SourceHttp.bounded(new ByteArrayInputStream(new byte[2]),4,token);fail();}catch(InterruptedIOException expected){}}
}
