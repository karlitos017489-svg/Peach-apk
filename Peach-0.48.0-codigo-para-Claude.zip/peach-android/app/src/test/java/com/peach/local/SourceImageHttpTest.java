package com.peach.local;
import java.io.*;
import org.junit.*;
import static org.junit.Assert.*;
public class SourceImageHttpTest {
    @Test public void smallerImageLimitChecksHashAndClosesStream()throws Exception{File f=File.createTempFile("image-http-",".part");boolean[] closed={false};try{var in=new ByteArrayInputStream("abc".getBytes()){@Override public void close()throws IOException{closed[0]=true;super.close();}};var d=SourceHttp.copy(in,f,3,new SourceHttp.Token(),4);assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",d.sha256());assertTrue(closed[0]);assertEquals(3,f.length());assertEquals(16L*1024*1024,SourceHttp.IMAGE_LIMIT);assertEquals(128L*1024*1024,SourceHttp.DOWNLOAD_LIMIT);}finally{f.delete();}}
    @Test public void declaredUnknownOversizeAndTruncatedStreamsLeaveNoFile()throws Exception{for(int mode=0;mode<3;mode++){File f=File.createTempFile("image-http-",".part");try{SourceHttp.copy(new ByteArrayInputStream(new byte[mode==2?2:5]),f,mode==0?5:mode==1?-1:3,new SourceHttp.Token(),4);fail();}catch(IOException expected){}assertFalse(f.exists());}}
}
