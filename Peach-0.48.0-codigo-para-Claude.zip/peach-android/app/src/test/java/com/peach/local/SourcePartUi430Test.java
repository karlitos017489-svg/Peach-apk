package com.peach.local;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.lifecycle.ViewModelProvider;
import java.util.*;
import java.util.concurrent.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowDialog;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land") @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class SourcePartUi430Test {
 LibraryDatabase db;
 @Before public void setup(){var app=RuntimeEnvironment.getApplication();db=androidx.room.Room.inMemoryDatabaseBuilder(app,LibraryDatabase.class).allowMainThreadQueries().build();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",db);}
 @After public void cleanup()throws Exception{idle();db.close();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);SourceDiscoveryActivity.transport=F95Search.direct();PixeldrainActivity.transport=PixeldrainReview.direct();}
 void idle()throws Exception{LibraryDatabase.IO.submit(()->{}).get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}
 static View find(View root,String label){if(root instanceof TextView t&&t.getText().toString().equals(label))return root;if(root instanceof ViewGroup g)for(int i=0;i<g.getChildCount();i++){View result=find(g.getChildAt(i),label);if(result!=null)return result;}return null;}
 @Test public void accountScreenShowsNativeImportDisconnectAndOfficialLoginWithoutNetwork()throws Exception{try(var c=Robolectric.buildActivity(AccountActivity.class).setup().visible()){idle();View root=c.get().findViewById(android.R.id.content);for(String site:List.of("fanbox","patreon","subscribestar.com","subscribestar.adult","f95zone")){assertNotNull(find(root,"Iniciar sesión en "+site));assertNotNull(find(root,"Importar Cookie propia de "+site));assertNotNull(find(root,"Desconectar "+site));}assertTrue(db.library().sources().isEmpty());}}
 @Test public void sharedLinkWaitsForReviewAndConfirmationBeforeAddingLocalSource()throws Exception{SourceDiscoveryActivity.transport=(u,b,s,t)->{throw new AssertionError("No search on share");};Intent i=new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,"https://www.patreon.com/cw/Artist");try(var c=Robolectric.buildActivity(SourceDiscoveryActivity.class,i).setup().visible()){c.get().draft.worker.submit(()->{}).get(30,TimeUnit.SECONDS);idle();assertTrue(db.library().sources().isEmpty());find(c.get().getWindow().getDecorView(),"Revisar enlace sin consultar").performClick();idle();assertTrue(db.library().sources().isEmpty());AlertDialog dialog=(AlertDialog)ShadowDialog.getLatestDialog();dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick();c.get().draft.worker.submit(()->{}).get(30,TimeUnit.SECONDS);idle();assertEquals(1,db.library().sources().size());assertEquals("patreon",db.library().sources().get(0).provider);assertEquals("artist",db.library().sources().get(0).ref);}}
 @Test public void rotationKeepsDiscoveryDraftAndDoesNotReplaySearch()throws Exception{int[] calls={0};SourceDiscoveryActivity.transport=(u,b,s,t)->{calls[0]++;return "";};try(var c=Robolectric.buildActivity(SourceDiscoveryActivity.class).setup().visible()){c.get().draft.worker.submit(()->{}).get(30,TimeUnit.SECONDS);idle();c.get().query.setText("Own geología");var retained=c.get().draft;c.recreate();c.get().draft.worker.submit(()->{}).get(30,TimeUnit.SECONDS);idle();assertSame(retained,c.get().draft);assertEquals("Own geología",c.get().query.getText().toString());assertEquals(0,calls[0]);}}
 @Test public void externalServiceScreenCannotUseCallerUrlOrFetchOnOpen()throws Exception{int[] calls={0};PixeldrainActivity.transport=(u,e,m,t)->{calls[0]++;throw new java.io.IOException();};Intent i=new Intent(RuntimeEnvironment.getApplication(),PixeldrainActivity.class).putExtra("publicationId","missing").putExtra("url","https://foreign.test/not-used");try(var c=Robolectric.buildActivity(PixeldrainActivity.class,i).setup().visible()){c.get().draft.worker.submit(()->{}).get(30,TimeUnit.SECONDS);idle();assertEquals(0,calls[0]);assertFalse(c.get().query.isEnabled());assertFalse(c.get().apply.isEnabled());}}
 @Test public void sourcesExposePartTwoRoutesAlongsideExistingMediaAndQueueControls()throws Exception{try(var c=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){new ViewModelProvider(c.get()).get(SourcesActivity.Draft.class).worker.submit(()->{}).get(30,TimeUnit.SECONDS);idle();for(String text:List.of("Cuentas y sesiones","Descubrir / filtrar fuentes","Cola de descargas","Abrir video o GIF"))assertNotNull(find(c.get().getWindow().getDecorView(),text));}}
}
