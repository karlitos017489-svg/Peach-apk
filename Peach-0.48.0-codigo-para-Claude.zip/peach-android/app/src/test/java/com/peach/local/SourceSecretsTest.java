package com.peach.local;
import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.concurrent.*;
import javax.crypto.spec.SecretKeySpec;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE)
public class SourceSecretsTest {
    File file;SourceSecrets vault;
    @Before public void open()throws Exception{file=new File(Files.createTempDirectory("peach-secret-test-").toFile(),"own.bin");vault=new SourceSecrets(file,()->new SecretKeySpec(new byte[16],"AES"));}
    @After public void close(){vault.clear();file.getParentFile().delete();}
    @Test public void ciphertextRoundTripDoesNotContainPlaintextAndClearRemovesIt()throws Exception{assertNull(vault.read());vault.write(WebSourceUrlsTest.KEY);assertFalse(new String(Files.readAllBytes(file.toPath()),java.nio.charset.StandardCharsets.ISO_8859_1).contains(WebSourceUrlsTest.KEY.key()));assertEquals(WebSourceUrlsTest.KEY,vault.read());vault.clear();assertNull(vault.read());}
    @Test public void repeatedEncryptionUsesDistinctNonceAndCiphertext()throws Exception{vault.write(WebSourceUrlsTest.KEY);byte[] a=Files.readAllBytes(file.toPath());vault.write(WebSourceUrlsTest.KEY);assertFalse(java.util.Arrays.equals(a,Files.readAllBytes(file.toPath())));assertEquals(WebSourceUrlsTest.KEY,vault.read());}
    @Test public void tamperingAndWrongKeyNeverFallBackToPlaintext()throws Exception{vault.write(WebSourceUrlsTest.KEY);byte[] a=Files.readAllBytes(file.toPath());a[a.length-1]^=1;Files.write(file.toPath(),a);try{vault.read();fail();}catch(IOException expected){assertFalse(expected.toString().contains(WebSourceUrlsTest.KEY.key()));}vault.write(WebSourceUrlsTest.KEY);byte[] other=new byte[16];other[0]=1;var wrong=new SourceSecrets(file,()->new SecretKeySpec(other,"AES"));try{wrong.read();fail();}catch(IOException expected){}}
    @Test public void unavailableKeystoreWritesNoPlaintextFile()throws Exception{SourceSecrets bad=new SourceSecrets(file,()->{throw new GeneralSecurityException("Unavailable");});try{bad.write(WebSourceUrlsTest.KEY);fail();}catch(IOException expected){}assertFalse(file.exists());}
    @Test public void distinctInstancesSerializeAtomicReadsAndWrites()throws Exception{var second=new SourceSecrets(file,()->new SecretKeySpec(new byte[16],"AES"));vault.write(WebSourceUrlsTest.KEY);ExecutorService e=Executors.newFixedThreadPool(2);try{var a=e.submit(()->{for(int i=0;i<15;i++)try{vault.write(WebSourceUrlsTest.KEY);}catch(IOException x){throw new AssertionError(x);}});var b=e.submit(()->{for(int i=0;i<15;i++)try{assertEquals(WebSourceUrlsTest.KEY,second.read());}catch(IOException x){throw new AssertionError(x);}});a.get(10,TimeUnit.SECONDS);b.get(10,TimeUnit.SECONDS);}finally{e.shutdownNow();assertTrue(e.awaitTermination(10,TimeUnit.SECONDS));}}
}
