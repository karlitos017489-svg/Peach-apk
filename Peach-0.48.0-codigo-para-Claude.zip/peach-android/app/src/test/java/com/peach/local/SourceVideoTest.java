package com.peach.local;

import android.content.Intent;
import android.net.Uri;
import android.os.Looper;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.media3.common.PlaybackException;
import androidx.room.Room;
import java.io.*;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.concurrent.TimeUnit;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.shadows.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land")
@SQLiteMode(SQLiteMode.Mode.LEGACY) @GraphicsMode(GraphicsMode.Mode.NATIVE)
public class SourceVideoTest {
    LibraryDatabase db;SourcesActivity activity;SourcesActivity.AttachmentFetcher previous;
    @Before public void before(){db=Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",db);previous=SourcesActivity.attachmentFetcher;}
    @After public void after()throws Exception{if(activity!=null){var d=new androidx.lifecycle.ViewModelProvider(activity).get(SourcesActivity.Draft.class);d.token.cancel();d.worker.shutdown();assertTrue(d.worker.awaitTermination(30,TimeUnit.SECONDS));}SourcesActivity.attachmentFetcher=previous;LibraryDatabase.IO.submit(()->{}).get(30,TimeUnit.SECONDS);db.close();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);}
    void idle()throws Exception{var d=new androidx.lifecycle.ViewModelProvider(activity).get(SourcesActivity.Draft.class);for(int i=0;i<3;i++){d.worker.submit(()->{}).get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}}
    Button button(android.view.View view,String label){if(view instanceof Button b&&b.getText().toString().equals(label))return b;if(view instanceof android.view.ViewGroup group)for(int i=0;i<group.getChildCount();i++){Button b=button(group.getChildAt(i),label);if(b!=null)return b;}return null;}
    @Test public void saveUsesConcreteMimeAndUriPermissionsForVideoImageAndUnknown(){
        for(String[] pair:new String[][]{{"sample.MP4","video/mp4"},{"sample.webm","video/webm"},{"photo.jpg","image/jpeg"},{"own.xyz","application/octet-stream"}}){Intent i=SourceFiles.create(pair[0]);assertEquals(Intent.ACTION_CREATE_DOCUMENT,i.getAction());assertEquals(pair[1],i.getType());assertEquals(pair[0],i.getStringExtra(Intent.EXTRA_TITLE));assertTrue((i.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION)!=0);}
    }
    @Test public void nameRecoversKnownSuffixWithoutInventingVideoContainer(){
        assertEquals("clip.mp4",SourceFiles.name("clip.bin","https://example.org/own.mp4"));
        assertEquals("clip.webm",SourceFiles.name("clip","https://example.org/own.webm"));
        assertEquals("clip.bin",SourceFiles.name("clip.bin","https://example.org/hash"));
        assertEquals("own.mov",SourceFiles.name("own.mov","https://example.org/own.mp4"));
        assertFalse(SourceFiles.name("../bad\nname.mp4","").contains("/"));
    }
    @Test public void localPickerAllowsVideosSavedWithOldGenericMime(){Intent i=SourceFiles.pickVideo();assertEquals(Intent.ACTION_OPEN_DOCUMENT,i.getAction());assertEquals("*/*",i.getType());assertTrue(i.hasCategory(Intent.CATEGORY_OPENABLE));}
    @Test public void localPlaybackRejectsRemoteAndFilePaths(){for(String u:new String[]{"https://example.org/a.mp4","file:///sdcard/a.mp4","content:/x",""}){assertNull(SourceFiles.localVideo(new Intent().setData(Uri.parse(u)).putExtra("localVideo",true)));try{SourceFiles.play(RuntimeEnvironment.getApplication(),Uri.parse(u),"own");fail();}catch(IllegalArgumentException expected){}}}
    @Test public void localIntentProducesPlayableTransientEntryWithoutCatalogInsert(){Intent i=SourceFiles.play(RuntimeEnvironment.getApplication(),Uri.parse("content://own.fixture/video"),"old.bin");MediaEntry m=SourceFiles.localVideo(i);assertEquals(PlayerActivity.class.getName(),i.getComponent().getClassName());assertEquals("old.bin",m.name);assertEquals(MediaRules.VIDEO,m.mediaType);assertTrue(MediaRules.playable(m));assertTrue(db.library().allMedia().isEmpty());assertNull(SourceFiles.localVideo(new Intent().setData(i.getData())));}
    @Test public void actualVideoIsPreparedBeforePickerWithVerifiedMime()throws Exception{
        SourcesActivity.attachmentFetcher=(u,f,t)->SourceHttp.copyAttachment(u,new ByteArrayInputStream(Files.readAllBytes(new File("src/androidTest/assets/sample.mp4").toPath())),f,-1,t);
        try(var c=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){activity=c.get();idle();PublicationContent content=new PublicationContent();content.attachments=new JSONArray().put(new JSONObject().put("name","own.bin").put("url","https://api-cdn.rule34.xxx/images/1/0123456789abcdef0123456789abcdef.mp4").put("kind","video").put("downloadable",true)).toString();activity.attachments(content);var d=(AlertDialog)ShadowDialog.getLatestDialog();d.getListView().performItemClick(null,0,0);((AlertDialog)ShadowDialog.getLatestDialog()).getListView().performItemClick(null,1,1);idle();var i=Shadows.shadowOf(activity).getNextStartedActivityForResult().intent;assertEquals("video/mp4",i.getType());assertEquals("own.mp4",i.getStringExtra(Intent.EXTRA_TITLE));}
    }
    @Test public void existingGenericDownloadCanBeSelectedAndOpenedWithoutAnySourceRequest()throws Exception{
        SourcesActivity.attachmentFetcher=(u,f,t)->{throw new AssertionError("Unexpected download");};
        try(var c=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){activity=c.get();idle();
            button(activity.getWindow().getDecorView(),"Abrir video o GIF").performClick();
            var next=Shadows.shadowOf(activity).getNextStartedActivityForResult();assertEquals(Intent.ACTION_OPEN_DOCUMENT,next.intent.getAction());
            Uri uri=Uri.parse("content://own.fixture/existing.bin");Shadows.shadowOf(activity.getContentResolver()).registerInputStreamSupplier(uri,()->new ByteArrayInputStream(new byte[]{0,0,0,16,102,116,121,112,105,115,111,109,0,0,0,0}));activity.getActivityResultRegistry().dispatchResult(next.requestCode,android.app.Activity.RESULT_OK,new Intent().setData(uri));idle();
            var play=button(activity.getWindow().getDecorView(),"Reproducir descarga");assertTrue(play.isEnabled());play.performClick();assertEquals(uri,Shadows.shadowOf(activity).getNextStartedActivity().getData());assertTrue(db.library().allMedia().isEmpty());
        }
    }
    @Test public void cancelledDocumentPickerDoesNotEnablePlayback()throws Exception{
        try(var c=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){activity=c.get();idle();button(activity.getWindow().getDecorView(),"Abrir video o GIF").performClick();var next=Shadows.shadowOf(activity).getNextStartedActivityForResult();activity.getActivityResultRegistry().dispatchResult(next.requestCode,android.app.Activity.RESULT_CANCELED,null);idle();assertFalse(button(activity.getWindow().getDecorView(),"Reproducir descarga").isEnabled());assertEquals(Intent.ACTION_OPEN_DOCUMENT,Shadows.shadowOf(activity).getNextStartedActivity().getAction());assertNull(Shadows.shadowOf(activity).getNextStartedActivity());}
    }
    @Test public void verifiedMp4TravelsToSafThenNativePlayerWithoutScanOrNetwork()throws Exception{
        byte[] mp4=Files.readAllBytes(new File("src/androidTest/assets/sample.mp4").toPath());
        StringBuilder hash=new StringBuilder();for(byte b:MessageDigest.getInstance("SHA-256").digest(mp4))hash.append(String.format(java.util.Locale.ROOT,"%02x",b&255));String url="https://file.pawchive.pw/data/"+hash.substring(0,2)+"/"+hash.substring(2,4)+"/"+hash+".mp4";
        SourcesActivity.attachmentFetcher=(u,f,t)->SourceHttp.copyAttachment(u,new ByteArrayInputStream(mp4),f,mp4.length,t);
        try(var c=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){activity=c.get();idle();Uri uri=Uri.parse("content://own.fixture/saved-video");ByteArrayOutputStream out=new ByteArrayOutputStream();Shadows.shadowOf(activity.getContentResolver()).registerOutputStream(uri,out);var draft=new androidx.lifecycle.ViewModelProvider(activity).get(SourcesActivity.Draft.class);draft.pendingName="own.mp4";draft.pendingKind="video";draft.download(uri,url);draft.updates.setValue(1);assertArrayEquals(mp4,out.toByteArray());assertEquals(uri.toString(),draft.lastVideoUri);Button play=button(activity.getWindow().getDecorView(),"Reproducir descarga");assertNotNull(play);assertTrue(play.isEnabled());play.performClick();Intent next=Shadows.shadowOf(activity).getNextStartedActivity();assertEquals(uri,next.getData());assertNotNull(SourceFiles.localVideo(next));assertTrue(db.library().allMedia().isEmpty());assertTrue(SourcesActivity.Draft.activeDownloads.isEmpty());}
    }
    @Test public void failedDownloadNeverEnablesNewVideoPlayback()throws Exception{
        SourcesActivity.attachmentFetcher=(u,f,t)->{throw new IOException("own fixture failure");};try(var c=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){activity=c.get();idle();var d=new androidx.lifecycle.ViewModelProvider(activity).get(SourcesActivity.Draft.class);d.pendingName="own.mp4";d.pendingKind="video";try{d.download(Uri.parse("content://own.fixture/nope"),"https://api-cdn.rule34.xxx/images/1/0123456789abcdef0123456789abcdef.mp4");fail();}catch(IOException expected){}assertTrue(d.lastVideoUri.isEmpty());assertFalse(button(activity.getWindow().getDecorView(),"Reproducir descarga").isEnabled());assertTrue(SourcesActivity.Draft.activeDownloads.isEmpty());}
    }
    @Test public void media3RecognizesOwnMp4BytesWithGenericBinDocumentName()throws Exception{
        byte[] bytes=Files.readAllBytes(new File("src/androidTest/assets/sample.mp4").toPath());
        var source=new androidx.media3.datasource.ByteArrayDataSource(bytes);
        try{source.open(new androidx.media3.datasource.DataSpec(Uri.parse("content://own.fixture/legacy.bin")));
            var input=new androidx.media3.extractor.DefaultExtractorInput(source,0,bytes.length);
            assertTrue(new androidx.media3.extractor.mp4.Mp4Extractor().sniff(input));
        }finally{source.close();}
    }
    @Test public void playerLoadsAuthorizedStandaloneVideoWithoutCatalogEntryAndPreservesRotationPosition(){
        Intent intent=SourceFiles.play(RuntimeEnvironment.getApplication(),Uri.parse("content://own.fixture/video"),"own.mp4");android.os.Bundle state=new android.os.Bundle();state.putLong("position",4200);state.putBoolean("ready",false);
        try(var c=Robolectric.buildActivity(PlayerActivity.class,intent).create(state)){PlayerActivity a=c.get();assertEquals("own.mp4",((TextView)a.findViewById(R.id.playerTitle)).getText().toString());assertEquals(4200L,(long)org.robolectric.util.ReflectionHelpers.getField(a,"resume"));assertTrue((boolean)org.robolectric.util.ReflectionHelpers.getField(a,"localVideo"));assertTrue(db.library().allMedia().isEmpty());}
    }
    @Test public void errorsDistinguishAccessContainerAndDecoderWithoutLeakingUris(){
        String secret="https://private.invalid/own.mp4?api_key=own-secret";
        for(int code:new int[]{PlaybackException.ERROR_CODE_IO_NO_PERMISSION,PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND,PlaybackException.ERROR_CODE_IO_READ_POSITION_OUT_OF_RANGE,PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES,PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,PlaybackException.ERROR_CODE_DECODING_FAILED,PlaybackException.ERROR_CODE_UNSPECIFIED}){String message=PlaybackMessages.error(new PlaybackException(secret,new IOException(secret),code));assertTrue(message.contains("Código:"));assertFalse(message.contains("own-secret"));assertFalse(message.contains("private.invalid"));}
        assertTrue(PlaybackMessages.error(new PlaybackException("",null,PlaybackException.ERROR_CODE_IO_NO_PERMISSION)).contains("Android no permite"));assertTrue(PlaybackMessages.error(new PlaybackException("",null,PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED)).contains("códec"));
    }
}
