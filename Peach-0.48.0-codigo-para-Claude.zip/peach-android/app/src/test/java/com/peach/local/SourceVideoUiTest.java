package com.peach.local;

import android.content.Intent;
import android.net.Uri;
import android.os.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.lifecycle.ViewModelProvider;
import androidx.media3.datasource.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowDialog;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land")
@SQLiteMode(SQLiteMode.Mode.LEGACY) @GraphicsMode(GraphicsMode.Mode.NATIVE)
public class SourceVideoUiTest {
    LibraryDatabase db;byte[] own;Publication p;PublicationContent body;int calls;
    List<ActivityController<SourceVideoActivity>> screens=new ArrayList<>();
    @Before public void before()throws Exception{
        db=androidx.room.Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",db);
        own=SourceVideosTest.own();p=GalleryProvidersTest.publication("rule34video");body=GalleryProvidersTest.content(p,new JSONArray().put(SourceVideosTest.video(SourceVideosTest.urls().get("rule34video"))));db.library().insertPublication(p);db.library().putPublicationContent(body);
        // Robolectric supplies a new Application/cache per method; Jetpack's cached
        // factory otherwise retains an Application from a previous method.
        var application=RuntimeEnvironment.getApplication();var previousFactory=ViewModelProvider.AndroidViewModelFactory.getInstance(application);
        for(var f:ViewModelProvider.AndroidViewModelFactory.class.getDeclaredFields())if(f.getType()==android.app.Application.class){f.setAccessible(true);var old=(android.app.Application)f.get(previousFactory);System.out.println("Fixture application cache: current="+application.getCacheDir()+", previous factory="+old.getCacheDir());}
        boolean reset=false;for(var f:ViewModelProvider.AndroidViewModelFactory.class.getDeclaredFields())if(java.lang.reflect.Modifier.isStatic(f.getModifiers())&&f.getType()==ViewModelProvider.AndroidViewModelFactory.class){f.setAccessible(true);f.set(null,new ViewModelProvider.AndroidViewModelFactory(application));reset=true;}assertTrue("Refresh test Application factory",reset);
        RuntimeEnvironment.getApplication().getSharedPreferences("source-video",0).edit().clear().commit();clean();SourceVideoActivity.fetcher=this::fetch;
    }
    SourceHttp.Download fetch(String u,File f,SourceHttp.Token t,long limit)throws IOException{calls++;return SourceHttp.copyAttachment(u,new ByteArrayInputStream(own),f,own.length,t,limit);}
    void clean()throws Exception{File root=new VideoCache(RuntimeEnvironment.getApplication().getCacheDir()).root;if(root.exists())GalleryProvidersTest.remove(root);}
    void idle()throws Exception{LibraryDatabase.IO.submit(()->{}).get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}
    void settle(SourceVideoActivity a)throws Exception{for(int i=0;i<2;i++){a.draft.worker.submit(()->{}).get(30,TimeUnit.SECONDS);idle();}}
    ActivityController<SourceVideoActivity> screen(String id){var c=Robolectric.buildActivity(SourceVideoActivity.class,new Intent(RuntimeEnvironment.getApplication(),SourceVideoActivity.class).putExtra("publicationId",id).putExtra("url","https://untrusted.invalid/own.mp4")).setup().visible();screens.add(c);return c;}
    @After public void after()throws Exception{
        for(var c:screens){var d=c.get().draft;c.pause().stop().destroy();assertTrue(d.worker.awaitTermination(30,TimeUnit.SECONDS));}
        SourceVideoActivity.fetcher=(u,f,t,l)->SourceHttp.download(u,f,t,l);idle();assertTrue(VideoCache.PINS.isEmpty());assertTrue(VideoCache.PARTS.isEmpty());assertTrue(VideoCache.PREPARING.isEmpty());db.close();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);clean();
    }
    @Test public void openingScreenOnlyReadsImportedMetadataAndIgnoresCallerUrl()throws Exception{
        var c=screen(p.id);settle(c.get());assertEquals(0,calls);assertEquals(1,c.get().draft.selection.videos().size());assertNull(Shadows.shadowOf(c.get()).getNextStartedActivity());
        var missing=screen("missing");settle(missing.get());assertEquals(0,calls);assertNull(missing.get().draft.selection);assertFalse(missing.get().prepare.isEnabled());assertFalse(missing.get().draft.status.contains("untrusted.invalid"));
    }
    @Test public void importedVideoAndMixedMediaActionsKeepImageAndSaveRoutes()throws Exception{
        try(var c=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){
            idle();c.get().content(p,body,null);AlertDialog dialog=(AlertDialog)ShadowDialog.getLatestDialog();assertEquals("Ver videos",dialog.getButton(AlertDialog.BUTTON_POSITIVE).getText().toString());assertEquals("Guardar adjunto",dialog.getButton(AlertDialog.BUTTON_NEUTRAL).getText().toString());dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick();idle();Intent i=Shadows.shadowOf(c.get()).getNextStartedActivity();assertEquals(SourceVideoActivity.class.getName(),i.getComponent().getClassName());assertEquals(p.id,i.getStringExtra("publicationId"));assertNull(i.getData());
            var both=GalleryProvidersTest.publication("fanbox");var b=GalleryProvidersTest.content(both,new JSONArray().put(SourceGalleryTest.image(SourceGalleryTest.A)).put(SourceVideosTest.video("https://downloads.fanbox.cc/own.mp4")));c.get().content(both,b,null);dialog=(AlertDialog)ShadowDialog.getLatestDialog();assertEquals("Ver medios",dialog.getButton(AlertDialog.BUTTON_POSITIVE).getText().toString());dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick();idle();dialog=(AlertDialog)ShadowDialog.getLatestDialog();dialog.getListView().performItemClick(null,0,0);idle();assertEquals(SourceGalleryActivity.class.getName(),Shadows.shadowOf(c.get()).getNextStartedActivity().getComponent().getClassName());
            c.get().content(p,body,"1");dialog=(AlertDialog)ShadowDialog.getLatestDialog();assertEquals("Consultar cuerpo",dialog.getButton(AlertDialog.BUTTON_POSITIVE).getText().toString());dialog.dismiss();
        }assertEquals(0,calls);
    }
    @Test public void selectedVideoPreparesThenLaunchesPlayerWithOnlyOpaqueIdentityAndNoSafPicker()throws Exception{
        var c=screen(p.id);settle(c.get());c.get().prepare.performClick();settle(c.get());assertEquals(c.get().draft.status+"; offline="+c.get().offline.isChecked(),1,calls);assertNotNull(c.get().draft.status,c.get().draft.ready);
        var launch=Shadows.shadowOf(c.get()).getNextStartedActivityForResult();assertEquals(PlayerActivity.class.getName(),launch.intent.getComponent().getClassName());assertNull(launch.intent.getData());assertNull(launch.intent.getAction());assertEquals(p.id,launch.intent.getStringExtra(SourceVideoPlayback.PUBLICATION));assertTrue(VideoCache.key(launch.intent.getStringExtra(SourceVideoPlayback.KEY)));
        for(String k:launch.intent.getExtras().keySet()){String value=launch.intent.getStringExtra(k);assertFalse(value.contains("https://"));assertFalse(value.contains("file://"));assertFalse(value.contains("OWN_TEST"));}
        c.get().getActivityResultRegistry().dispatchResult(launch.requestCode,android.app.Activity.RESULT_CANCELED,null);idle();c.get().prepare.performClick();settle(c.get());assertEquals(1,calls);assertNotNull(Shadows.shadowOf(c.get()).getNextStartedActivityForResult());assertTrue(db.library().allMedia().isEmpty());assertEquals(0,db.library().usageCount());
    }
    @Test public void offlineMissNeverFetchesAndCheckedCopyCanBeReplayedOffline()throws Exception{
        var c=screen(p.id);settle(c.get());c.get().offline.setChecked(true);c.get().prepare.performClick();settle(c.get());assertEquals(0,calls);assertNull(c.get().draft.ready);assertTrue(c.get().draft.status.contains("Sin conexión"));
        c.get().offline.setChecked(false);c.get().prepare.performClick();settle(c.get());var launch=Shadows.shadowOf(c.get()).getNextStartedActivityForResult();assertEquals(1,calls);c.get().getActivityResultRegistry().dispatchResult(launch.requestCode,android.app.Activity.RESULT_CANCELED,null);idle();c.get().offline.setChecked(true);c.get().prepare.performClick();settle(c.get());assertEquals(1,calls);
    }
    @Test public void rotationDuringPreparationKeepsOneJobAndOnlyNewScreenLaunchesPlayer()throws Exception{
        CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);SourceVideoActivity.fetcher=(u,f,t,l)->{entered.countDown();try{release.await(10,TimeUnit.SECONDS);}catch(InterruptedException e){throw new InterruptedIOException();}return fetch(u,f,t,l);};
        var c=screen(p.id);settle(c.get());SourceVideoActivity old=c.get();old.prepare.performClick();assertTrue(old.draft.status,entered.await(10,TimeUnit.SECONDS));var draft=old.draft;
        try{c.recreate();assertSame(draft,c.get().draft);}finally{release.countDown();}settle(c.get());assertEquals(c.get().draft.status+"; offline="+c.get().offline.isChecked(),1,calls);assertNotNull(c.get().draft.status,c.get().draft.ready);assertTrue(old.isDestroyed());assertFalse(old.resumed);assertNotNull(Shadows.shadowOf(c.get()).getNextStartedActivityForResult());assertNull(Shadows.shadowOf(c.get()).getNextStartedActivityForResult());
    }
    @Test public void leavingPreparationCancelsAndDoesNotLaunchInBackground()throws Exception{
        CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);SourceVideoActivity.fetcher=(u,f,t,l)->{entered.countDown();try{release.await(10,TimeUnit.SECONDS);}catch(InterruptedException e){throw new InterruptedIOException();}return fetch(u,f,t,l);};
        var c=screen(p.id);settle(c.get());c.get().prepare.performClick();assertTrue(entered.await(10,TimeUnit.SECONDS));c.pause().stop();release.countDown();c.start().resume().visible();settle(c.get());assertNull(c.get().draft.ready);assertFalse(c.get().draft.autoplay);assertNull(Shadows.shadowOf(c.get()).getNextStartedActivity());assertTrue(c.get().draft.status.contains("cancelada"));
    }
    @Test public void playerUsesVerifiedPrivateFileAndRetainsPinAndPositionAcrossRotation()throws Exception{
        var v=SourceVideos.select(p,body).videos().get(0);var cache=new VideoCache(RuntimeEnvironment.getApplication().getCacheDir());SourceVideoPlayback playback=null;
        try(var lease=cache.acquire(v,false,new SourceHttp.Token(),this::fetch)){
            Bundle state=new Bundle();state.putLong("position",4200);state.putBoolean("ready",false);
            Intent intent=SourceVideoPlayback.intent(RuntimeEnvironment.getApplication(),p.id,lease.key).setData(Uri.parse("file:///untrusted/outside.mp4"));
            try(var c=Robolectric.buildActivity(PlayerActivity.class,intent).create(state).start().resume().visible()){
                playback=new ViewModelProvider(c.get()).get(SourceVideoPlayback.class);playback.worker.submit(()->{}).get(30,TimeUnit.SECONDS);idle();assertNotNull(playback.error,playback.media);assertEquals(Uri.fromFile(lease.file).toString(),playback.media.uri);assertEquals(2,(int)VideoCache.PINS.get(lease.file));
                FileDataSource data=new FileDataSource();try{data.open(new DataSpec(Uri.parse(playback.media.uri)));var input=new androidx.media3.extractor.DefaultExtractorInput(data,0,own.length);assertTrue(new androidx.media3.extractor.mp4.Mp4Extractor().sniff(input));}finally{data.close();}
                c.recreate();idle();assertSame(playback,new ViewModelProvider(c.get()).get(SourceVideoPlayback.class));assertEquals(4200L,(long)org.robolectric.util.ReflectionHelpers.getField(c.get(),"resume"));assertEquals(2,(int)VideoCache.PINS.get(lease.file));assertTrue(db.library().allMedia().isEmpty());assertEquals(0,db.library().usageCount());
            }
            assertTrue(playback.worker.awaitTermination(30,TimeUnit.SECONDS));assertEquals(1,(int)VideoCache.PINS.get(lease.file));
        }
    }
    @Test public void restoredPlaybackRejectsMissingReferenceAndNeverDownloadsOrAcceptsFilePaths()throws Exception{
        var app=RuntimeEnvironment.getApplication();for(String key:List.of("../../outside.mp4","a".repeat(64))){
            SourceVideoPlayback vm=new SourceVideoPlayback(app);try{vm.load(p.id,key);vm.worker.submit(()->{}).get(30,TimeUnit.SECONDS);idle();assertNull(vm.media);assertFalse(vm.error.isEmpty());assertFalse(vm.error.contains("OWN_TEST"));}finally{vm.onCleared();assertTrue(vm.worker.awaitTermination(30,TimeUnit.SECONDS));}
        }
        var v=SourceVideos.select(p,body).videos().get(0);SourceVideoPlayback vm=new SourceVideoPlayback(app);try{vm.load(p.id,VideoCache.keyFor(v.url()));vm.worker.submit(()->{}).get(30,TimeUnit.SECONDS);idle();assertNull(vm.media);assertEquals(0,calls);}finally{vm.onCleared();assertTrue(vm.worker.awaitTermination(30,TimeUnit.SECONDS));}
    }
}
