package com.peach.local;
import java.io.*;
import java.nio.file.Files;
import java.util.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class SourceVideosTest {
    static byte[] own()throws Exception{return Files.readAllBytes(new File("src/androidTest/assets/sample.mp4").toPath());}
    static Map<String,String> urls()throws Exception{
        var urls=GalleryProvidersTest.urls(own());urls.replaceAll((p,u)->p.equals("pawchive")||p.equals("cumst")||p.equals("rule34xxx")||p.equals("f95zone")?u.replace(".png",".mp4"):u);
        urls.put("rule34video","https://rule34video.com/get_file/1/own/own.mp4/?download=true&signature=OWN_TEST");return urls;
    }
    static JSONObject video(String url)throws Exception{return SourceGalleryTest.image(url).put("kind","video").put("name","Own.bin");}
    static SourceVideos.Selection selection(String provider,JSONArray a)throws Exception{var p=GalleryProvidersTest.publication(provider);return SourceVideos.select(p,GalleryProvidersTest.content(p,a));}
    @Test public void sevenProviderContractsRemainSeparateAndOldPawFlagsAreRecognized()throws Exception{
        var urls=urls();for(var own:urls.entrySet()){
            JSONArray all=new JSONArray();for(String url:urls.values())all.put(video(url));var s=selection(own.getKey(),all);assertEquals(1,s.videos().size());assertEquals(own.getValue(),s.videos().get(0).url());assertEquals(6,s.omitted());
            assertEquals(own.getKey().equals("pawchive")?1:0,selection(own.getKey(),new JSONArray().put(video(own.getValue()).put("downloadable",false))).videos().size());
        }
    }
    @Test public void preservesOrderImmutabilityPartialityAndSkipsImagesAndReferences()throws Exception{
        String a=urls().get("fanbox"),b="https://downloads.fanbox.cc/own-second.mp4";
        var s=selection("fanbox",new JSONArray().put(video(a)).put(video(a)).put(video(b)).put(video(b).put("kind","image")).put(video("https://example.org/no.mp4")));
        assertEquals(List.of(a,b),s.videos().stream().map(SourceVideos.Video::url).toList());assertEquals(2,s.omitted());assertTrue(s.partial());try{s.videos().clear();fail();}catch(UnsupportedOperationException expected){}
    }
    @Test public void rejectsUnknownExcludedMismatchedOrMalformedImportedContent()throws Exception{
        for(String provider:List.of("kemono","coomer","simpcity","unknown"))try{selection(provider,new JSONArray());fail();}catch(IOException expected){}
        for(String provider:List.of("patreon","subscribestar"))assertTrue(selection(provider,new JSONArray().put(video(urls().get("fanbox")))).videos().isEmpty());
        var p=GalleryProvidersTest.publication("fanbox");var c=GalleryProvidersTest.content(p,new JSONArray());c.publicationId="other";try{SourceVideos.select(p,c);fail();}catch(IOException expected){}
        for(String bad:List.of("{}","[true]","[{\"kind\":\"video\"}]","["+String.join(",",Collections.nCopies(1001,"{}"))+"]")){
            c=GalleryProvidersTest.content(p,new JSONArray());c.attachments=bad;try{SourceVideos.select(p,c);fail();}catch(IOException expected){}
        }
    }
    @Test public void backupSeventeenRetainsImportedVideosWithoutPrivateCacheOrMediaRows()throws Exception{
        var db=androidx.room.Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().build();
        try{var p=GalleryProvidersTest.publication("pawchive");var c=GalleryProvidersTest.content(p,new JSONArray().put(video(urls().get("pawchive")).put("downloadable",false)));db.library().insertPublication(p);db.library().putPublicationContent(c);
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();BackupStore.write(db.library(),bytes);assertEquals(19,new JSONObject(bytes.toString("UTF-8")).getInt("version"));db.library().deletePublication(p.id);BackupStore.read(db,new ByteArrayInputStream(bytes.toByteArray()));
            assertEquals(1,SourceVideos.load(db,p.id).videos().size());assertEquals(c.attachments,db.library().publicationContent(p.id).attachments);assertFalse(bytes.toString("UTF-8").contains("peach-video-1"));assertTrue(db.library().allMedia().isEmpty());assertEquals(0,db.library().usageCount());
        }finally{db.close();}
    }
}
