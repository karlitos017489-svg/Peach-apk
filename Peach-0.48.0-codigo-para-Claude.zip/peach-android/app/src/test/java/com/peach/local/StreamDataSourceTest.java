package com.peach.local;
import android.net.Uri;
import androidx.media3.common.*;
import androidx.media3.common.util.ParsableByteArray;
import androidx.media3.datasource.*;
import androidx.media3.extractor.*;
import androidx.media3.extractor.mp4.Mp4Extractor;
import java.io.*;
import java.util.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28)
public class StreamDataSourceTest {
    byte[] own;VideoStream.Session session;RangeFactory network;
    static final class RangeFactory implements SourceHttp.ConnectionFactory {
        final byte[] own;final List<VideoStreamTest.Reply> replies=new ArrayList<>();final List<Long> positions=new ArrayList<>();
        RangeFactory(byte[] own){this.own=own;}
        public javax.net.ssl.HttpsURLConnection open(String url)throws IOException {
            try{var r=new VideoStreamTest.Reply(url,200,own,"\"own-v1\""){
                boolean configured;
                @Override public int getResponseCode(){if(!configured){configured=true;String range=getRequestProperty("Range");long offset=range==null?0:Long.parseLong(range.substring(6,range.length()-1));positions.add(offset);if(offset>=own.length&&range!=null){status=416;bytes=new byte[0];declared=0;headers.put("Content-Range","bytes */"+own.length);}else if(offset>0){status=206;bytes=Arrays.copyOfRange(own,(int)offset,own.length);declared=bytes.length;headers.put("Content-Range","bytes "+offset+"-"+(own.length-1)+"/"+own.length);}}return status;}
            };replies.add(r);return r;}catch(Exception e){throw new IOException(e);}
        }
        int consumed(){return replies.stream().mapToInt(r->r.consumed).sum();}
    }
    @Before public void before()throws Exception{own=SourceVideosTest.own();network=new RangeFactory(own);session=new VideoStream.Session(VideoStreamTest.URL,()->true,network,MediaRedirectsTest.PUBLIC);session.resume();}
    @After public void after(){session.close();assertTrue(session.active.isEmpty());for(var r:network.replies)assertTrue(r.closed);}
    StreamDataSource data(){return new StreamDataSource(session);}
    DataSpec spec(long position,long length){return new DataSpec.Builder().setUri(StreamDataSource.uri(session.key)).setPosition(position).setLength(length).build();}
    static final class Capture implements ExtractorOutput {
        int videoSamples;Format video;SeekMap map;
        public TrackOutput track(int id,int type){return new TrackOutput(){
            public void format(Format f){if(type==C.TRACK_TYPE_VIDEO)video=f;}
            public int sampleData(DataReader input,int length,boolean allowEnd,int part)throws IOException{byte[] b=new byte[Math.min(4096,length)];return input.read(b,0,b.length);}
            public void sampleData(ParsableByteArray data,int length,int part){data.skipBytes(length);}
            public void sampleMetadata(long time,int flags,int size,int offset,TrackOutput.CryptoData crypto){if(type==C.TRACK_TYPE_VIDEO)videoSamples++;}
        };}
        public void endTracks(){}public void seekMap(SeekMap map){this.map=map;}
    }
    void firstSample(Mp4Extractor extractor,Capture capture)throws Exception {
        StreamDataSource source=data();long length=source.open(spec(0,C.LENGTH_UNSET));DefaultExtractorInput input=new DefaultExtractorInput(source,0,length);PositionHolder seek=new PositionHolder();int iterations=0;
        try{assertTrue(extractor.sniff(input));input.resetPeekPosition();while(capture.videoSamples==0&&iterations++<3000){int result=extractor.read(input,seek);assertNotEquals(Extractor.RESULT_END_OF_INPUT,result);if(result==Extractor.RESULT_SEEK){source.close();source=data();long available=source.open(spec(seek.position,C.LENGTH_UNSET));input=new DefaultExtractorInput(source,seek.position,available<0?-1:seek.position+available);}}assertTrue(capture.videoSamples>0);}finally{source.close();}
    }
    @Test public void realMp4ExtractorOutputsVideoSamplesBeforeWholeFileIsRead()throws Exception {
        Mp4Extractor extractor=new Mp4Extractor();Capture capture=new Capture();extractor.init(capture);try{firstSample(extractor,capture);assertNotNull(capture.video);assertEquals("video/avc",capture.video.sampleMimeType);assertNotNull(capture.map);assertTrue(capture.map.isSeekable());assertTrue(network.consumed()>4096);assertTrue("Must start before all bytes arrive: "+network.consumed(),network.consumed()<own.length);}finally{extractor.release();}
    }
    @Test public void realExtractorCanJumpToIndexedVideoSampleUsingRange()throws Exception {
        Mp4Extractor extractor=new Mp4Extractor();Capture capture=new Capture();extractor.init(capture);try{firstSample(extractor,capture);var seek=capture.map.getSeekPoints(2_000_000).first;assertTrue(seek.position>0);int before=capture.videoSamples;StreamDataSource source=data();long available=source.open(spec(seek.position,C.LENGTH_UNSET));DefaultExtractorInput input=new DefaultExtractorInput(source,seek.position,seek.position+available);extractor.seek(seek.position,seek.timeUs);PositionHolder holder=new PositionHolder();int loops=0;try{while(capture.videoSamples==before&&loops++<3000){int result=extractor.read(input,holder);assertNotEquals(Extractor.RESULT_END_OF_INPUT,result);if(result==Extractor.RESULT_SEEK){source.close();source=data();available=source.open(spec(holder.position,C.LENGTH_UNSET));input=new DefaultExtractorInput(source,holder.position,holder.position+available);}}assertTrue(capture.videoSamples>before);assertTrue(network.positions.stream().anyMatch(n->n>0));assertTrue(network.consumed()<own.length);}finally{source.close();}}finally{extractor.release();}
    }
    @Test public void boundedRequestStopsAtRequestedLengthAndHeadersAndUriRemainOpaque()throws Exception {
        StreamDataSource source=data();try{assertEquals(20,source.open(spec(0,20)));byte[] bytes=new byte[100];assertEquals(20,source.read(bytes,0,bytes.length));assertArrayEquals(Arrays.copyOf(own,20),Arrays.copyOf(bytes,20));assertEquals(C.RESULT_END_OF_INPUT,source.read(bytes,0,100));assertEquals(StreamDataSource.uri(session.key),source.getUri());assertTrue(source.getResponseHeaders().isEmpty());assertEquals(4096,network.consumed());}finally{source.close();}assertNull(source.getUri());
    }
    @Test public void uriInjectionHttpHeadersAndMethodsAreRejectedWithoutNetwork()throws Exception {
        List<DataSpec> bad=List.of(new DataSpec(Uri.parse(VideoStreamTest.URL)),new DataSpec(Uri.parse("file:///outside.mp4")),new DataSpec(Uri.parse(StreamDataSource.uri(session.key)+"?url=OWN_SECRET")),new DataSpec.Builder().setUri(StreamDataSource.uri(session.key)).setHttpRequestHeaders(Map.of("Authorization","OWN_SECRET")).build(),new DataSpec.Builder().setUri(StreamDataSource.uri(session.key)).setHttpMethod(DataSpec.HTTP_METHOD_POST).setHttpBody(new byte[]{1}).build());
        for(var request:bad){StreamDataSource source=data();try{VideoStreamTest.problem(VideoStream.Reason.REQUEST,()->source.open(request));}finally{source.close();}}assertTrue(network.replies.isEmpty());
    }
    @Test public void transferListenersCountDeliveredBytesAndCloseOnlyOnce()throws Exception {
        int[] count=new int[4];StreamDataSource source=data();source.addTransferListener(new TransferListener(){public void onTransferInitializing(DataSource d,DataSpec s,boolean n){assertTrue(n);count[0]++;}public void onTransferStart(DataSource d,DataSpec s,boolean n){count[1]++;}public void onBytesTransferred(DataSource d,DataSpec s,boolean n,int b){count[2]+=b;}public void onTransferEnd(DataSource d,DataSpec s,boolean n){count[3]++;}});
        try{source.open(spec(0,C.LENGTH_UNSET));assertEquals(12,source.read(new byte[12],0,12));}finally{source.close();source.close();}assertArrayEquals(new int[]{1,1,12,1},count);assertEquals(4096,network.consumed());
    }
    @Test public void exactEndAndBeyondEndFollowTheMedia3PositionContract()throws Exception {
        StreamDataSource first=data();try{first.open(spec(0,C.LENGTH_UNSET));}finally{first.close();}StreamDataSource end=data();try{assertEquals(0,end.open(spec(own.length,C.LENGTH_UNSET)));assertEquals(-1,end.read(new byte[1],0,1));}finally{end.close();}
        StreamDataSource beyond=data();try{try{beyond.open(spec(own.length+1,C.LENGTH_UNSET));fail();}catch(IOException e){assertTrue(DataSourceException.isCausedByPositionOutOfRange(e));}}finally{beyond.close();}
    }
    @Test public void internalIcyHintIsAcceptedAndDiscardedWithoutAuthorizingOtherHeaders()throws Exception {
        for(String name:List.of("Icy-MetaData","icy-metadata")){StreamDataSource source=data();try{source.open(new DataSpec.Builder().setUri(StreamDataSource.uri(session.key)).setHttpRequestHeaders(Map.of(name,"1")).build());assertEquals(12,source.read(new byte[12],0,12));}finally{source.close();}}
        for(var reply:network.replies){assertNull(reply.getRequestProperty("Icy-MetaData"));assertNull(reply.getRequestProperty("Authorization"));assertNull(reply.getRequestProperty("Cookie"));}
        int before=network.replies.size();for(var headers:List.of(Map.of("Icy-MetaData","0"),Map.of("Icy-MetaData","1","Authorization","OWN_SECRET"),Map.of("Icy-MetaData","1","Range","bytes=7-"),Map.of("Cookie","OWN_SECRET"),Map.of("Referer","https://secret.invalid/OWN_SECRET"))){StreamDataSource source=data();try{VideoStreamTest.problem(VideoStream.Reason.REQUEST,()->source.open(new DataSpec.Builder().setUri(StreamDataSource.uri(session.key)).setHttpRequestHeaders(headers).build()));}finally{source.close();}}assertEquals(before,network.replies.size());
    }
}
