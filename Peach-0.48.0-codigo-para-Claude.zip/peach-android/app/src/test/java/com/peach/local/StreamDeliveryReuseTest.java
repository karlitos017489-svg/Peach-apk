package com.peach.local;
import java.io.*;
import java.net.*;
import java.util.*;
import org.junit.*;
import static org.junit.Assert.*;

public class StreamDeliveryReuseTest {
    static final String ORIGINAL=MediaRedirectsTest.ORIGINAL,CDN=MediaRedirectsTest.CDN;
    byte[] own;VideoStream.Session session;
    @Before public void before()throws Exception{own=SourceVideosTest.own();}
    @After public void after(){if(session!=null){session.close();assertEquals("",session.delivery);assertTrue(session.active.isEmpty());}}
    VideoStreamTest.Reply hop(String target)throws Exception{var r=new VideoStreamTest.Reply(ORIGINAL,302,new byte[0],null);r.location=target;return r;}
    VideoStreamTest.Reply file(String url,int status,int offset)throws Exception{var r=new VideoStreamTest.Reply(url,status,status==200?own:status==206?Arrays.copyOfRange(own,offset,own.length):new byte[0],"\"own-v1\"");if(status==206)r.headers.put("Content-Range","bytes "+offset+"-"+(own.length-1)+"/"+own.length);return r;}
    RedirectHttpTest.Factory make(VideoStreamTest.Reply... replies){var factory=new RedirectHttpTest.Factory(replies);session=new VideoStream.Session(ORIGINAL,()->true,factory,MediaRedirectsTest.PUBLIC);session.resume();return factory;}
    @Test public void seekReusesValidatedDeliveryInMemoryAndAvoidsRepeatedOriginRoundTrip()throws Exception {
        VideoStreamTest.Reply first=file(CDN,200,0),next=file(CDN,206,10000);var f=make(hop(CDN),first,next);try(var i=session.open(0)){}try(var i=session.open(10000)){byte[] b=new byte[12];i.read(b,0,b.length);assertArrayEquals(Arrays.copyOfRange(own,10000,10012),b);}assertEquals(List.of(ORIGINAL,CDN,CDN),f.requests);assertEquals(4096,first.consumed);assertEquals("bytes=10000-",next.getRequestProperty("Range"));assertNull(next.getRequestProperty("Cookie"));assertNull(next.getRequestProperty("Authorization"));assertFalse(SourceHttp.downloadable(CDN));
    }
    @Test public void expiredDeliveryGetsOneRefreshViaTheOriginalAdmittedReference()throws Exception {
        VideoStreamTest.Reply expired=file(CDN,403,0),fresh=file(CDN,206,10000);var f=make(hop(CDN),file(CDN,200,0),expired,hop(CDN),fresh);try(var i=session.open(0)){}try(var i=session.open(10000)){assertEquals(8,i.read(new byte[8],0,8));}assertEquals(List.of(ORIGINAL,CDN,CDN,ORIGINAL,CDN),f.requests);assertEquals(0,expired.reads);assertTrue(expired.closed);
    }
    @Test public void renewedTargetStillFailsRepresentationGuardInsteadOfMixingBytes()throws Exception {
        String changed="https://cdn.own-fixture.test/own/new.mp4?sig=OWN_NEW";var last=file(changed,206,10000);make(hop(CDN),file(CDN,200,0),file(CDN,410,0),hop(changed),last);try(var i=session.open(0)){}VideoStreamTest.problem(VideoStream.Reason.CHANGED,()->session.open(10000));assertEquals(0,last.reads);assertTrue(last.closed);
    }
    @Test public void cached429DoesNotRefreshOriginOrBypassSessionWait()throws Exception {
        var rate=file(CDN,429,0);rate.headers.put("Retry-After","300");var f=make(hop(CDN),file(CDN,200,0),rate);try(var i=session.open(0)){}VideoStreamTest.problem(VideoStream.Reason.WAIT,()->session.open(10000));VideoStreamTest.problem(VideoStream.Reason.WAIT,()->session.open(10000));assertEquals(3,f.requests.size());assertTrue(rate.closed);
    }
    @Test public void everyReusedTargetIsResolvedAgainAndPrivateDnsIsBlockedBeforeConnection()throws Exception {
        var first=file(CDN,200,0);var f=make(hop(CDN),first);try(var i=session.open(0)){}session.close();assertEquals("",session.delivery);
        int[] dns={0};var freshFactory=new RedirectHttpTest.Factory(hop(CDN),file(CDN,200,0));session=new VideoStream.Session(ORIGINAL,()->true,freshFactory,host->new InetAddress[]{InetAddress.getByName(++dns[0]==1?"93.184.216.34":"10.0.0.1")});session.resume();try(var i=session.open(0)){}VideoStreamTest.problem(VideoStream.Reason.NETWORK,()->session.open(10000));assertEquals(2,freshFactory.requests.size());assertEquals(2,dns[0]);
    }
    @Test public void deliveryReuseDoesNotAdmitOtherProvidersApisOrInitialCdnUrls()throws Exception {
        var f=new RedirectHttpTest.Factory();for(String origin:List.of(VideoStreamTest.URL,"https://api.fanbox.cc/post.info?postId=1",CDN))try{SourceHttp.openDelivery(origin,CDN,new SourceHttp.Token(),f,MediaRedirectsTest.PUBLIC,10000,"");fail();}catch(IOException expected){}assertTrue(f.requests.isEmpty());assertFalse(SourceVideos.admitted("rule34video",CDN,true));
    }
}
