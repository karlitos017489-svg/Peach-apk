package com.peach.local;
import android.content.Intent;
import android.net.Uri;
import android.os.*;
import androidx.lifecycle.ViewModelProvider;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land")
@SQLiteMode(SQLiteMode.Mode.LEGACY) @GraphicsMode(GraphicsMode.Mode.NATIVE)
public class StreamUiTest {
    SourceVideoUiTest fixture;List<VideoStream.Session> sessions;List<StreamDataSourceTest.RangeFactory> networks;
    List<ActivityController<PlayerActivity>> players;
    @Before public void before()throws Exception{fixture=new SourceVideoUiTest();fixture.before();sessions=Collections.synchronizedList(new ArrayList<>());networks=Collections.synchronizedList(new ArrayList<>());players=new ArrayList<>();
        SourceVideoStream.sessions=(video,app)->{var network=new StreamDataSourceTest.RangeFactory(fixture.own);var session=new VideoStream.Session(video.url(),()->!app.getSharedPreferences("source-video",0).getBoolean("offline",false),network,MediaRedirectsTest.PUBLIC);networks.add(network);sessions.add(session);return session;};
    }
    void awaitClosed(VideoStream.Session session)throws Exception{long end=System.nanoTime()+5_000_000_000L;while(System.nanoTime()<end){synchronized(session){if(session.active.isEmpty())return;}Shadows.shadowOf(Looper.getMainLooper()).idle();Thread.sleep(5);}synchronized(session){assertTrue("Media3 loader must release canceled transfers",session.active.isEmpty());}}
    @After public void after()throws Exception{for(var c:players){var vm=new ViewModelProvider(c.get()).get(SourceVideoStream.class);c.pause().stop().destroy();assertTrue(vm.worker.awaitTermination(30,TimeUnit.SECONDS));}for(var s:sessions){assertTrue(s.closed);awaitClosed(s);}
        SourceVideoStream.sessions=(video,app)->new VideoStream.Session(video.url(),()->!app.getSharedPreferences("source-video",0).getBoolean("offline",false));fixture.after();}
    String key()throws Exception{return VideoCache.keyFor(SourceVideos.select(fixture.p,fixture.body).videos().get(0).url());}
    ActivityController<PlayerActivity> player(long position)throws Exception{Bundle state=new Bundle();state.putLong("position",position);state.putBoolean("ready",false);var c=Robolectric.buildActivity(PlayerActivity.class,SourceVideoStream.intent(RuntimeEnvironment.getApplication(),fixture.p.id,key()).setData(Uri.parse("https://untrusted.invalid/OWN_SECRET.mp4"))).create(state).start().resume().visible();players.add(c);SourceVideoStream vm=new ViewModelProvider(c.get()).get(SourceVideoStream.class);vm.worker.submit(()->{}).get(30,TimeUnit.SECONDS);fixture.idle();return c;}
    @Test public void onlineButtonLaunchesOpaqueIdentityWithoutFullPreparationOrSaf()throws Exception{
        var c=fixture.screen(fixture.p.id);fixture.settle(c.get());assertTrue(c.get().online.isEnabled());assertEquals(0,fixture.calls);assertTrue(sessions.isEmpty());c.get().online.performClick();fixture.idle();var launch=Shadows.shadowOf(c.get()).getNextStartedActivityForResult();assertNotNull(launch);assertEquals(PlayerActivity.class.getName(),launch.intent.getComponent().getClassName());assertEquals(fixture.p.id,launch.intent.getStringExtra(SourceVideoStream.PUBLICATION));assertEquals(key(),launch.intent.getStringExtra(SourceVideoStream.KEY));assertEquals(2,launch.intent.getExtras().size());assertNull(launch.intent.getData());assertNull(launch.intent.getAction());assertEquals(0,fixture.calls);assertNull(c.get().draft.ready);assertTrue(sessions.isEmpty());assertTrue(VideoCache.PARTS.isEmpty());
        c.get().getActivityResultRegistry().dispatchResult(launch.requestCode,android.app.Activity.RESULT_CANCELED,null);fixture.idle();assertTrue(c.get().online.isEnabled());assertTrue(c.get().prepare.isEnabled());
    }
    @Test public void offlineModeDisablesStreamingAndKeepsVerifiedCopyChoice()throws Exception{
        var c=fixture.screen(fixture.p.id);fixture.settle(c.get());c.get().offline.setChecked(true);assertFalse(c.get().online.isEnabled());assertTrue(c.get().prepare.isEnabled());c.get().online.performClick();fixture.idle();assertNull(Shadows.shadowOf(c.get()).getNextStartedActivity());assertEquals(0,fixture.calls);
        SourceVideoStream vm=new SourceVideoStream(RuntimeEnvironment.getApplication());try{vm.load(fixture.p.id,key());vm.worker.submit(()->{}).get(30,TimeUnit.SECONDS);fixture.idle();assertNull(vm.media);assertTrue(vm.error.contains("Sin conexión"));assertTrue(sessions.isEmpty());}finally{vm.onCleared();assertTrue(vm.worker.awaitTermination(30,TimeUnit.SECONDS));}
    }
    @Test public void metadataResolutionMakesNoNetworkRequestOrPrivateVideoFile()throws Exception{
        SourceVideoStream vm=new SourceVideoStream(RuntimeEnvironment.getApplication());try{vm.load(fixture.p.id,key());vm.worker.submit(()->{}).get(30,TimeUnit.SECONDS);fixture.idle();assertNotNull(vm.error,vm.media);assertEquals("peach-stream",Uri.parse(vm.media.uri).getScheme());assertFalse(vm.media.uri.contains("https://"));assertEquals(1,networks.size());assertTrue(networks.get(0).replies.isEmpty());assertFalse(vm.session.enabled);assertEquals(0,fixture.calls);assertTrue(fixture.db.library().allMedia().isEmpty());assertEquals(0,fixture.db.library().usageCount());File root=new VideoCache(RuntimeEnvironment.getApplication().getCacheDir()).root;assertTrue(!root.exists()||root.list()!=null&&root.list().length==0);}finally{vm.onCleared();assertTrue(vm.worker.awaitTermination(30,TimeUnit.SECONDS));}
    }
    @Test public void rotationRetainsSessionPositionAndPauseWithoutCreatingHistoryEntries()throws Exception{
        var c=player(4200);var vm=new ViewModelProvider(c.get()).get(SourceVideoStream.class);assertNotNull(vm.error,vm.media);var session=vm.session;c.recreate();fixture.idle();assertSame(vm,new ViewModelProvider(c.get()).get(SourceVideoStream.class));assertSame(session,vm.session);assertEquals(1,sessions.size());assertEquals(4200L,(long)org.robolectric.util.ReflectionHelpers.getField(c.get(),"resume"));assertFalse((boolean)org.robolectric.util.ReflectionHelpers.getField(c.get(),"ready"));assertEquals(android.view.View.GONE,c.get().findViewById(R.id.subtitle).getVisibility());assertTrue(fixture.db.library().allMedia().isEmpty());assertEquals(0,fixture.db.library().usageCount());
    }
    @Test public void leavingPlayerStopsNetworkAndReturningNeedsNoFullDownload()throws Exception{
        var c=player(0);var vm=new ViewModelProvider(c.get()).get(SourceVideoStream.class);assertNotNull(vm.media);c.pause().stop();assertFalse("Leaving pauses session immediately",vm.session.enabled);synchronized(vm.session){for(var token:vm.session.active)assertTrue("Remaining loader cleanup already canceled",token.cancelled);}awaitClosed(vm.session);c.start().resume().visible();fixture.idle();assertTrue(vm.session.enabled);assertEquals(0,fixture.calls);assertTrue(VideoCache.PINS.isEmpty());assertTrue(VideoCache.PARTS.isEmpty());assertEquals(0,fixture.db.library().usageCount());
    }
    @Test public void missingOrChangedReferenceAndInvalidKeyNeverUseIntentUrl()throws Exception{
        for(String id:List.of("missing",fixture.p.id))for(String key:List.of("../../outside", "a".repeat(64))){SourceVideoStream vm=new SourceVideoStream(RuntimeEnvironment.getApplication());try{vm.load(id,key);vm.worker.submit(()->{}).get(30,TimeUnit.SECONDS);fixture.idle();assertNull(vm.media);assertFalse(vm.error.isEmpty());assertFalse(vm.error.contains("https://"));}finally{vm.onCleared();assertTrue(vm.worker.awaitTermination(30,TimeUnit.SECONDS));}}
        assertTrue(sessions.isEmpty());assertEquals(0,fixture.calls);
    }
    @Test public void streamingMessagesKeepDecoderDiagnosisAndHideNetworkSecrets(){
        var codec=new androidx.media3.common.PlaybackException("OWN_SECRET",new IOException("https://secret.invalid/OWN_SECRET"),androidx.media3.common.PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED);String message=SourceVideoStream.message(codec);assertTrue(message.contains("códec"));assertFalse(message.contains("OWN_SECRET"));
        var cause=new VideoStream.Problem(VideoStream.Reason.SEEK);var network=new androidx.media3.common.PlaybackException("OWN_SECRET",new IOException(cause),androidx.media3.common.PlaybackException.ERROR_CODE_IO_UNSPECIFIED);message=SourceVideoStream.message(network);assertTrue(message.contains("salto"));assertFalse(message.contains("OWN_SECRET"));assertTrue(message.contains("Código:"));
    }
}
