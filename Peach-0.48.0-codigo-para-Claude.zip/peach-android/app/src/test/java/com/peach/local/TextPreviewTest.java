package com.peach.local;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import org.junit.Test;
import static org.junit.Assert.*;

public class TextPreviewTest {
    @Test public void readsUtf8BomAndBothUtf16ByteOrders() throws Exception {
        String source="Geología · 日本語";
        for(var charset:java.util.List.of(StandardCharsets.UTF_8,StandardCharsets.UTF_16LE,StandardCharsets.UTF_16BE)) {
            byte[] body=source.getBytes(charset),bom=charset==StandardCharsets.UTF_8?new byte[]{(byte)239,(byte)187,(byte)191}:charset==StandardCharsets.UTF_16LE?new byte[]{(byte)255,(byte)254}:new byte[]{(byte)254,(byte)255};
            var bytes=new java.io.ByteArrayOutputStream();bytes.write(bom);bytes.write(body);
            var result=TextPreview.read(new ByteArrayInputStream(bytes.toByteArray()));assertEquals(source,result.text());assertFalse(result.truncated());
        }
    }
    @Test public void invalidEncodingIsRejectedAndMarkupRemainsPlainText() throws Exception {
        try{TextPreview.read(new ByteArrayInputStream(new byte[]{(byte)255,0,1}));fail();}catch(java.io.IOException expected){}
        String markup="<script>alert('x')</script>";assertEquals(markup,TextPreview.read(new ByteArrayInputStream(markup.getBytes(StandardCharsets.UTF_8))).text());
    }
    @Test public void previewStopsAtCharacterAndByteLimitsWithoutSplittingSurrogatePairs() throws Exception {
        String input="a".repeat(TextPreview.MAX_CHARS-1)+"😀"+"z".repeat(20000);
        var result=TextPreview.read(new ByteArrayInputStream(input.getBytes(StandardCharsets.UTF_8)));assertTrue(result.truncated());assertEquals(TextPreview.MAX_CHARS-1,result.text().length());
        byte[] huge=new byte[TextPreview.MAX_BYTES+100];java.util.Arrays.fill(huge,(byte)'a');ByteArrayInputStream stream=new ByteArrayInputStream(huge);
        var limited=TextPreview.read(stream);assertTrue(limited.truncated());assertEquals(TextPreview.MAX_CHARS,limited.text().length());assertEquals(99,stream.available());
    }
    @Test public void readsEmptyTextAndRejectsTruncatedUtf8WhenInputWasComplete() throws Exception {
        assertEquals("",TextPreview.read(new ByteArrayInputStream(new byte[0])).text());
        try{TextPreview.read(new ByteArrayInputStream(new byte[]{(byte)0xe2,(byte)0x82}));fail();}catch(java.io.IOException expected){}
    }
}
