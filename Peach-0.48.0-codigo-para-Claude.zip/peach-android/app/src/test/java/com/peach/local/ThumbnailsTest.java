package com.peach.local;

import android.net.Uri;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,manifest=Config.NONE)
public class ThumbnailsTest {
    @Test public void missingFrameReleasesRetrieverOnApi28WithoutCallingApi29Close() throws Exception {
        // Robolectric has no registered frame for this source. Cleanup must still work on API 28.
        assertNull(Thumbnails.frame(RuntimeEnvironment.getApplication(),Uri.parse("content://fixture/no-frame")));
    }
}
