package com.peach.local;

import android.os.Looper;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.room.Room;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowDialog;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land") @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class TrackingUiTest {
    LibraryDatabase db;
    @Before public void open(){db=Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",db);}
    @After public void close()throws Exception{idle();db.close();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);}
    void idle()throws Exception{for(int i=0;i<3;i++){LibraryDatabase.IO.submit(()->{}).get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}}
    AlertDialog dialog(){Shadows.shadowOf(Looper.getMainLooper()).idle();return (AlertDialog)ShadowDialog.getLatestDialog();}
    View find(View v,java.util.function.Predicate<View> p){if(p.test(v))return v;if(v instanceof ViewGroup g)for(int i=0;i<g.getChildCount();i++){View f=find(g.getChildAt(i),p);if(f!=null)return f;}return null;}
    @Test public void createsPublicationFromNativeControlsAndAddsOneDesiredWork()throws Exception{try(var controller=Robolectric.buildActivity(OrganizationActivity.class).setup().visible()){var a=controller.get();idle();((Spinner)a.findViewById(R.id.organizationSection)).setSelection(8);a.findViewById(R.id.organizationCreate).performClick();EditText title=(EditText)find(dialog().getWindow().getDecorView(),v->v instanceof EditText e && "Título de la publicación".contentEquals(e.getContentDescription()));title.setText("Entrega local");dialog().getButton(AlertDialog.BUTTON_POSITIVE).performClick();idle();assertEquals(1,db.library().publications().size());((ListView)a.findViewById(R.id.organizationList)).performItemClick(null,0,0);dialog().getButton(AlertDialog.BUTTON_POSITIVE).performClick();dialog().getListView().performItemClick(null,2,2);idle();assertEquals(1,db.library().wants().size());assertEquals("Entrega local",db.library().wants().get(0).title);assertEquals(1,((Spinner)a.findViewById(R.id.organizationSection)).getSelectedItemPosition());}}
    @Test public void desireStateFiltersAndSectionSurviveRecreation()throws Exception{String id=new WantStore(db).create("Futura","A","",null);new WantStore(db).track(id,"2099-01-01","wanted");try(var c=Robolectric.buildActivity(OrganizationActivity.class).setup().visible()){idle();var a=c.get();((Spinner)a.findViewById(R.id.organizationSection)).setSelection(1);idle();((Spinner)a.findViewById(R.id.organizationTrackingFilter)).setSelection(1);idle();assertEquals(0,((ListView)a.findViewById(R.id.organizationList)).getAdapter().getCount());((Spinner)a.findViewById(R.id.organizationTrackingFilter)).setSelection(2);idle();assertEquals(1,((ListView)a.findViewById(R.id.organizationList)).getAdapter().getCount());c.recreate();idle();assertEquals(1,((Spinner)c.get().findViewById(R.id.organizationSection)).getSelectedItemPosition());assertEquals(2,((Spinner)c.get().findViewById(R.id.organizationTrackingFilter)).getSelectedItemPosition());}}
    @Test public void cancellingReconciliationDoesNotAcquireUntilConfirmed()throws Exception{String id=new WantStore(db).create("Obra","A","",null);MediaEntry m=new MediaEntry();m.id="a";m.name="a.mp4";m.nfoDetails="{\"code\":\"A\"}";db.library().insertMedia(m);try(var c=Robolectric.buildActivity(OrganizationActivity.class).setup().visible()){idle();var a=c.get();((Spinner)a.findViewById(R.id.organizationSection)).setSelection(1);a.findViewById(R.id.organizationReconcile).performClick();idle();assertEquals("wanted",db.library().want(id).state);dialog().getButton(AlertDialog.BUTTON_NEGATIVE).performClick();assertEquals("wanted",db.library().want(id).state);a.findViewById(R.id.organizationReconcile).performClick();idle();dialog().getButton(AlertDialog.BUTTON_POSITIVE).performClick();idle();assertEquals("acquired",db.library().want(id).state);assertEquals("a",db.library().want(id).mediaId);}}
    @Test public void linkedTextPublicationOpensTheNativeReaderRoute()throws Exception{String id=new PublicationStore(db).create("Texto","P","Autor","","unknown","work","");MediaEntry m=new MediaEntry();m.id="text";m.name="notas.txt";m.mediaType=MediaRules.OTHER;db.library().insertMedia(m);new PublicationStore(db).attach(id,m.id);try(var c=Robolectric.buildActivity(OrganizationActivity.class).setup().visible()){idle();var a=c.get();((Spinner)a.findViewById(R.id.organizationSection)).setSelection(8);idle();((ListView)a.findViewById(R.id.organizationList)).performItemClick(null,0,0);dialog().getButton(AlertDialog.BUTTON_POSITIVE).performClick();dialog().getListView().performItemClick(null,6,6);android.content.Intent next=Shadows.shadowOf(a).getNextStartedActivity();assertEquals(ReaderActivity.class.getName(),next.getComponent().getClassName());assertEquals("text",next.getStringExtra("mediaId"));}}
}
