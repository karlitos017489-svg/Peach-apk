package com.peach.local;

import android.os.Bundle;
import androidx.room.Room;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class UsageTrackerTest {
    LibraryDatabase db;MediaEntry a,b;
    @Before public void open(){db=Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().build();a=VersionIndexTest.row("a","a.mp4");b=VersionIndexTest.row("b","b.mp4");db.library().insertMedia(a);db.library().insertMedia(b);}
    void idle()throws Exception{LibraryDatabase.IO.submit(()->{}).get(20,TimeUnit.SECONDS);}
    @After public void close()throws Exception{idle();db.close();}
    @Test public void reservationAndCancelledFailureDoNotRecordAnOpen()throws Exception{UsageTracker t=new UsageTracker(db,null);t.prepare("a");t.touch("error");t.finish();idle();assertEquals(0,db.library().usageCount());}
    @Test public void repeatedOpenStaysOneVisitAndNextFileClosesPrevious()throws Exception{UsageTracker t=new UsageTracker(db,null);t.open(a,"video");t.open(a,"video");t.checkpoint(800,1000,"",0,0,"active",false);t.open(b,"video");idle();assertEquals(2,db.library().usageCount());UsageSession previous=db.library().usageBackup(10).stream().filter(s->s.mediaId.equals("a")).findFirst().orElseThrow();assertEquals("closed",previous.status);assertEquals(800,previous.position);}
    @Test public void rotationDuringLoadingReusesReservedTokenEvenIfOldCallbackArrivesLate()throws Exception{UsageTracker old=new UsageTracker(db,null);old.prepare("a");Bundle state=new Bundle();old.save(state);UsageTracker next=new UsageTracker(db,state);old.open(a,"video");next.open(a,"video");idle();assertEquals(1,db.library().usageCount());}
    @Test public void rotationAfterOpeningDoesNotDuplicateOrResurrectClearedVisit()throws Exception{UsageTracker old=new UsageTracker(db,null);old.open(a,"video");Bundle state=new Bundle();old.save(state);idle();UsageTracker next=new UsageTracker(db,state);next.open(a,"video");idle();assertEquals(1,db.library().usageCount());db.library().clearUsage();next.open(a,"video");next.checkpoint(20,1000,"",0,0,"active",false);idle();assertEquals(0,db.library().usageCount());}
    @Test public void anotherProcessEpochStartsNewVisitAndDoesNotClaimOldOneIsClosed()throws Exception{UsageTracker old=new UsageTracker(db,null);old.open(a,"video");Bundle state=new Bundle();old.save(state);state.putString("usageProcess","other-process");UsageTracker next=new UsageTracker(db,state);next.open(a,"video");idle();assertEquals(2,db.library().usageCount());}
    @Test public void checkpointsAfterFinishCannotOverwriteNextDocument()throws Exception{UsageTracker t=new UsageTracker(db,null);t.open(a,"video");t.finish();t.checkpoint(999,1000,"",0,0,"ended",true);t.open(b,"video");idle();assertEquals(0,db.library().usageBackup(10).stream().filter(s->s.mediaId.equals("b")).findFirst().orElseThrow().position);}
}
