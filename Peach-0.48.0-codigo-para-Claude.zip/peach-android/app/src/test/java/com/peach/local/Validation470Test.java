package com.peach.local;

import android.content.*;
import android.net.Uri;
import android.os.*;
import androidx.room.Room;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.*;
import java.util.concurrent.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.shadows.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28) @SQLiteMode(SQLiteMode.Mode.LEGACY) @GraphicsMode(GraphicsMode.Mode.NATIVE)
public class Validation470Test {
    Context app;LibraryDatabase users;DeviceChecks checks;
    @Before public void setup(){app=RuntimeEnvironment.getApplication();users=Room.inMemoryDatabaseBuilder(app,LibraryDatabase.class).allowMainThreadQueries().build();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",users);MediaEntry row=new MediaEntry();row.id="USER-ORIGINAL";row.name="personal.mp4";row.uri="content://user/private";row.title="USER PRIVATE TITLE";row.mediaType=MediaRules.VIDEO;users.library().insertMedia(row);users.library().toggleFavorite(row.id);checks=new DeviceChecks(app,(f,m,t)->"Injected media probe",(c,f,d,t)->"Injected RAR probe");}
    @After public void stop(){users.close();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);}
    DeviceChecks.Report run()throws Exception{ExecutorService worker=Executors.newSingleThreadExecutor();try{return worker.submit(()->checks.run(new DeviceChecks.Token(),(r,c)->{})).get(30,TimeUnit.SECONDS);}finally{worker.shutdown();assertTrue(worker.awaitTermination(30,TimeUnit.SECONDS));}}
    @Test public void ownChecksPreserveUserDatabaseAndNeverIncludePrivateTitlesUrisOrAccountValues()throws Exception {var report=run();assertEquals(8,report.rows().size());assertTrue(report.json(),report.rows().stream().anyMatch(r->r.key().equals("database")&&r.state().equals("passed")));assertTrue(report.rows().stream().anyMatch(r->r.key().equals("storage")&&r.state().equals("passed")));assertEquals(1,users.library().allMedia().size());assertTrue(users.library().get("USER-ORIGINAL").favorite);assertFalse(report.json().contains("USER PRIVATE"));assertFalse(report.json().contains("content://user"));assertTrue(new JSONObject(report.json()).getBoolean("testProbesInjected"));assertTrue(Arrays.stream(Objects.requireNonNull(app.getCacheDir().list())).noneMatch(n->n.startsWith("peach-check-")));}
    @Test public void cancellingBeforeRunMarksEveryCheckNotRunAndDoesNotInventSuccess()throws Exception {var token=new DeviceChecks.Token();token.cancel();var report=checks.run(token,(r,c)->{});assertTrue(report.cancelled());assertEquals(8,report.rows().size());assertTrue(report.rows().stream().allMatch(r->r.state().equals("not_run")));}
    @Test public void cancelFromMediaProbeStopsSubsequentChecksAndPreservesEarlierResults()throws Exception {AtomicInteger calls=new AtomicInteger();var engine=new DeviceChecks(app,(f,m,t)->{calls.incrementAndGet();t.cancel();t.check();return "never";},(c,f,d,t)->{fail("No RAR after cancel");return "never";});var report=engine.run(new DeviceChecks.Token(),(r,c)->{});assertTrue(report.cancelled());assertEquals(1,calls.get());assertEquals("cancelled",report.rows().get(5).state());assertEquals("not_run",report.rows().get(6).state());assertEquals("not_run",report.rows().get(7).state());}
    @Test public void individualFailureIsReportedWithoutSecretMessageAndOtherChecksContinue(){List<DeviceChecks.Row> rows=new ArrayList<>();var token=new DeviceChecks.Token();DeviceChecks.step(rows,"own","Own",token,(r,c)->{},()->{throw new IOException("https://private.invalid/?secret=OWN_PRIVATE");});DeviceChecks.step(rows,"next","Next",token,(r,c)->{},()->"done");assertEquals("failed",rows.get(0).state());assertFalse(rows.get(0).detail().contains("OWN_PRIVATE"));assertFalse(rows.get(0).detail().contains("://"));assertEquals("passed",rows.get(1).state());}
    @Test public void timeoutIsInconclusiveAndCannotBeCountedAsPassed(){List<DeviceChecks.Row> rows=new ArrayList<>();DeviceChecks.step(rows,"own","Own",new DeviceChecks.Token(),(r,c)->{},()->{throw new java.util.concurrent.TimeoutException();});assertEquals("inconclusive",rows.get(0).state());}
    @Test public void reportPersistsAndRestoresExactResultAndAtomicRecovery()throws Exception {var report=run();CheckReports store=new CheckReports(app);store.save(report);assertEquals(report.json(),store.load().json());android.util.AtomicFile file=new android.util.AtomicFile(new File(app.getNoBackupFilesDir(),"peach-device-check/last.json"));FileOutputStream partial=file.startWrite();partial.write("BROKEN".getBytes());partial.close();assertEquals(report.json(),new CheckReports(app).load().json());}
    @Test public void exportingOwnReportVerifiesExactNewDocument()throws Exception {var report=run();Uri uri=Uri.parse("content://own.check/report");ByteArrayOutputStream out=new ByteArrayOutputStream();Shadows.shadowOf(app.getContentResolver()).registerOutputStream(uri,out);Shadows.shadowOf(app.getContentResolver()).registerInputStreamSupplier(uri,()->new ByteArrayInputStream(out.toByteArray()));CheckReports.export(app,uri,report);assertEquals(report.json(),out.toString("UTF-8"));}
    @Test public void failedReadbackDeletesOnlySelectedNewReportAndKeepsPrivateRecovery()throws Exception {var report=run();var store=new CheckReports(app);store.save(report);AtomicReference<Uri> removed=new AtomicReference<>();ShadowContentResolver.registerProviderInternal("own.check.delete",new DownloadFlowTest.DeletingProvider(){@Override public Bundle call(String m,String a,Bundle x){if(m.equals("android:deleteDocument"))removed.set(x.getParcelable("uri"));return super.call(m,a,x);}});Uri uri=Uri.parse("content://own.check.delete/document/new");Shadows.shadowOf(app.getContentResolver()).registerOutputStream(uri,new ByteArrayOutputStream());Shadows.shadowOf(app.getContentResolver()).registerInputStream(uri,new ByteArrayInputStream("truncated".getBytes()));try{CheckReports.export(app,uri,report);fail();}catch(IOException expected){}assertEquals(uri,removed.get());assertEquals(report.json(),store.load().json());}
    @Test public void reportIsBoundedAndMalformedSavedJsonDoesNotStartAnyCheck()throws Exception {File f=new File(app.getNoBackupFilesDir(),"peach-device-check/last.json");f.getParentFile().mkdirs();Files.write(f.toPath(),"{bad".getBytes());try{new CheckReports(app).load();fail();}catch(IOException expected){}try{new CheckReports(app).save(new DeviceChecks.Report("x".repeat(DeviceChecks.MAX_REPORT+1),List.of(),false));fail();}catch(IOException expected){}}
}
