package com.peach.local;

import android.content.Context;
import androidx.room.Room;
import java.io.*;
import java.util.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class VersionReviewStoreTest {
    LibraryDatabase db;VersionReviewStore store;
    @Before public void open(){Context context=RuntimeEnvironment.getApplication();db=Room.inMemoryDatabaseBuilder(context,LibraryDatabase.class).allowMainThreadQueries().build();store=new VersionReviewStore(db);
        for(String[] pair:new String[][]{{"a","Obra part1 1080p.mp4"},{"b","Obra part2 1080p.mp4"},{"c","Obra 720p.mp4"}})db.library().insertMedia(VersionIndexTest.row(pair[0],pair[1]));}
    @After public void close(){db.close();}
    VersionIndex.Proposal proposal(){return VersionIndex.scan(db.library().allMedia()).get(0);}
    @Test public void previewDoesNotWriteAndGroupRetainsIndependentProgress(){var plan=proposal();assertTrue(db.library().groups().isEmpty());db.library().progress("a",100,0,5,false);db.library().toggleFavorite("b");
        var saved=store.apply(plan,List.of("a","b","c"),"Mi obra",false);assertFalse(saved.reused());assertEquals(3,db.library().groupItems(saved.id()).size());assertEquals(100,db.library().get("a").position);assertEquals(0,db.library().get("b").position);assertTrue(db.library().get("b").favorite);assertTrue(db.library().playlists().isEmpty());}
    @Test public void groupRepeatReusesExactMembershipAndDoesNotRenameManualGroup(){var plan=proposal();var first=store.apply(plan,List.of("a","b"),"Manual",false);var second=store.apply(plan,List.of("b","a"),"Otro nombre",false);assertEquals(first.id(),second.id());assertEquals("Manual",second.name());assertTrue(second.reused());assertEquals(1,db.library().groups().size());}
    @Test public void reviewedSubsetMayExcludeAllMarkedVersionsAndKeepTwoOrdinaryFiles(){db.library().insertMedia(VersionIndexTest.row("d","Obra.mp4"));db.library().insertMedia(VersionIndexTest.row("e","Obra.mkv"));var plan=proposal();var saved=store.apply(plan,List.of("d","e"),"Para revisar",false);assertEquals(Set.of("d","e"),new HashSet<>(db.library().groupItems(saved.id()).stream().map(i->i.mediaId).toList()));assertTrue(db.library().playlists().isEmpty());}
    @Test public void partsAreSavedNumericallyAndReusedWithoutChangingExistingLists(){var plan=proposal();var first=store.apply(plan,List.of("b","a"),"Partes",true);assertEquals(List.of("a","b"),db.library().playlistItems(first.id()).stream().map(i->i.mediaId).toList());assertEquals(first.id(),store.apply(plan,List.of("a","b"),"Segunda",true).id());assertTrue(db.library().groups().isEmpty());}
    @Test public void staleNameDurationUriAndMissingAbortWithoutPartialWrites(){var plan=proposal();
        for(String change:List.of("name='Renombrado.mp4'","duration=9000","uri='content://changed/a'","missing=1")){
            db.getOpenHelper().getWritableDatabase().execSQL("UPDATE media SET "+change+" WHERE id='a'");
            try{store.apply(plan,List.of("a","b"),"No",false);fail();}catch(IllegalArgumentException expected){assertTrue(expected.getMessage().contains("cambió"));}
            assertTrue(db.library().groups().isEmpty());db.getOpenHelper().getWritableDatabase().execSQL("UPDATE media SET name='Obra part1 1080p.mp4',duration=0,uri='content://fixture/a',missing=0 WHERE id='a'");
        }}
    @Test public void subsetValidationRejectsUnknownRepeatedSingleAndMixedPartsAtomically(){var plan=proposal();for(List<String> ids:List.of(List.of("a"),List.of("a","a"),List.of("a","unknown"))){try{store.apply(plan,ids,"No",false);fail();}catch(IllegalArgumentException expected){}}try{store.apply(plan,List.of("a","b","c"),"No",true);fail();}catch(IllegalArgumentException expected){}assertTrue(db.library().groups().isEmpty());assertTrue(db.library().playlists().isEmpty());}
    @Test public void scopeQueryUsesLiteralFolderCharactersAndIncludesOnlyDescendants(){MediaEntry c=db.library().get("c");db.library().forgetMedia("root");c.folder="A%_";db.library().insertMedia(c);MediaEntry a=VersionIndexTest.row("a","Obra 1080p.mp4");a.folder="A%_ / Hijo";db.library().insertMedia(a);MediaEntry b=VersionIndexTest.row("b","Obra 720p.mp4");b.folder="AXY / Hijo";db.library().insertMedia(b);assertEquals(Set.of("a","c"),new HashSet<>(db.library().reviewMedia("root","A%_",20).stream().map(m->m.id).toList()));assertEquals(1,db.library().reviewMedia("root","",1).size());}
    @Test public void existingBackupRoundTripPreservesReviewedGroupsAndOrderedPartsAndUndo(){var plan=proposal();var group=store.apply(plan,List.of("a","b","c"),"Obra",false);var parts=store.apply(plan,List.of("b","a"),"Partes",true);
        try{ByteArrayOutputStream out=new ByteArrayOutputStream();BackupStore.write(db.library(),out);db.library().deleteGroup(group.id());db.library().deletePlaylist(parts.id());BackupStore.read(db,new ByteArrayInputStream(out.toByteArray()));assertEquals(3,db.library().groupItems(group.id()).size());assertEquals(List.of("a","b"),db.library().playlistItems(parts.id()).stream().map(i->i.mediaId).toList());db.library().deleteGroup(group.id());db.library().deletePlaylist(parts.id());assertEquals(3,db.library().allMedia().size());}catch(Exception e){throw new AssertionError(e);}}
}
