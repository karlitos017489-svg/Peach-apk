package com.peach.local;

import android.content.Intent;
import android.os.Looper;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowDialog;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land") @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class VersionsUiTest {
    LibraryDatabase db;
    @Before public void open(){var context=RuntimeEnvironment.getApplication();db=androidx.room.Room.inMemoryDatabaseBuilder(context,LibraryDatabase.class).allowMainThreadQueries().setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",db);
        LibraryRoot root=new LibraryRoot();root.uri="root";root.label="Tarjeta";root.state=0;db.library().addRoot(root);
        for(String[] pair:new String[][]{{"a","Obra part1 1080p.mp4"},{"b","Obra part2 1080p.mp4"},{"c","Obra 720p.mp4"}})db.library().insertMedia(VersionIndexTest.row(pair[0],pair[1]));}
    @After public void close()throws Exception{idle();db.close();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);}
    void idle()throws Exception{for(int i=0;i<3;i++){LibraryDatabase.IO.submit(()->{}).get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}}
    Intent intent(){return new Intent(RuntimeEnvironment.getApplication(),VersionsActivity.class).putExtra("root","root").putExtra("folder","Películas");}
    void scan(VersionsActivity screen)throws Exception{idle();screen.findViewById(R.id.versions_scan).performClick();idle();assertEquals(1,((ListView)screen.findViewById(R.id.versions_list)).getAdapter().getCount());}
    AlertDialog review(VersionsActivity screen){((ListView)screen.findViewById(R.id.versions_list)).performItemClick(null,0,0);return (AlertDialog)ShadowDialog.getLatestDialog();}
    void toggle(AlertDialog dialog,int i){ListView list=dialog.getListView();list.setItemChecked(i,!list.isItemChecked(i));list.performItemClick(null,i,i);}
    @Test public void scanIsReadOnlyAndExplicitSaveCreatesUsableGroup()throws Exception{try(var controller=Robolectric.buildActivity(VersionsActivity.class,intent()).setup().visible()){
        VersionsActivity screen=controller.get();scan(screen);assertTrue(db.library().groups().isEmpty());AlertDialog dialog=review(screen);assertEquals(3,dialog.getListView().getAdapter().getCount());assertFalse(dialog.getButton(AlertDialog.BUTTON_NEUTRAL).isEnabled());
        ((EditText)dialog.findViewById(R.id.versions_name)).setText("Versiones elegidas");dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick();idle();assertEquals(1,db.library().groups().size());assertEquals("Versiones elegidas",db.library().groups().get(0).name);assertEquals(3,db.library().groupItems().size());assertFalse(dialog.isShowing());assertTrue(db.library().playlists().isEmpty());}}
    @Test public void chooseOnlyPartsRetainsDraftAcrossRecreationAndSavesNumericOrder()throws Exception{try(var controller=Robolectric.buildActivity(VersionsActivity.class,intent()).setup().visible()){
        VersionsActivity screen=controller.get();scan(screen);AlertDialog dialog=review(screen);var plan=VersionIndex.scan(db.library().allMedia()).get(0);int whole=-1;for(int i=0;i<plan.members().size();i++)if(plan.members().get(i).part()==0)whole=i;assertTrue(whole>=0);toggle(dialog,whole);assertTrue(dialog.getButton(AlertDialog.BUTTON_NEUTRAL).isEnabled());((EditText)dialog.findViewById(R.id.versions_name)).setText("En dos partes");
        controller.recreate();idle();dialog=(AlertDialog)ShadowDialog.getLatestDialog();assertEquals("En dos partes",((EditText)dialog.findViewById(R.id.versions_name)).getText().toString());assertFalse(dialog.getListView().isItemChecked(whole));assertTrue(dialog.getButton(AlertDialog.BUTTON_NEUTRAL).isEnabled());dialog.getButton(AlertDialog.BUTTON_NEUTRAL).performClick();idle();assertEquals(1,db.library().playlists().size());assertEquals(List.of("a","b"),db.library().playlistItems(db.library().playlists().get(0).id).stream().map(i->i.mediaId).toList());assertTrue(db.library().groups().isEmpty());}}
    @Test public void stalePreviewShowsFailureAndCancelDoesNotWrite()throws Exception{try(var controller=Robolectric.buildActivity(VersionsActivity.class,intent()).setup().visible()){
        VersionsActivity screen=controller.get();scan(screen);AlertDialog dialog=review(screen);db.getOpenHelper().getWritableDatabase().execSQL("UPDATE media SET name='Cambiado.mp4' WHERE id='a'");dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick();idle();assertTrue(((TextView)screen.findViewById(R.id.versions_status)).getText().toString().contains("cambió"));assertTrue(db.library().groups().isEmpty());assertTrue(dialog.isShowing());dialog.getButton(AlertDialog.BUTTON_NEGATIVE).performClick();assertTrue(db.library().groups().isEmpty());}}
    @Test public void searchFiltersWholeProposalsAndScopeChangeInvalidatesPreview()throws Exception{try(var controller=Robolectric.buildActivity(VersionsActivity.class,intent()).setup().visible()){
        VersionsActivity screen=controller.get();scan(screen);EditText search=screen.findViewById(R.id.versions_search);search.setText("720p");assertEquals(1,((ListView)screen.findViewById(R.id.versions_list)).getAdapter().getCount());assertEquals(3,review(screen).getListView().getAdapter().getCount());((AlertDialog)ShadowDialog.getLatestDialog()).getButton(AlertDialog.BUTTON_NEGATIVE).performClick();search.setText("ausente");assertEquals(0,((ListView)screen.findViewById(R.id.versions_list)).getAdapter().getCount());search.setText("");((EditText)screen.findViewById(R.id.versions_folder)).setText("Otra");assertEquals(0,((ListView)screen.findViewById(R.id.versions_list)).getAdapter().getCount());}}
    @Test public void selectedFolderKeepsLiteralLeadingAndTrailingSpaces()throws Exception{db.getOpenHelper().getWritableDatabase().execSQL("UPDATE media SET folder=' Películas '");try(var controller=Robolectric.buildActivity(VersionsActivity.class,intent().putExtra("folder"," Películas ")).setup().visible()){
        scan(controller.get());assertEquals(" Películas ",((EditText)controller.get().findViewById(R.id.versions_folder)).getText().toString());}}
    @Test public void mainExplorerRoutesToReviewWithoutBreakingWantsEntry()throws Exception{var context=RuntimeEnvironment.getApplication();androidx.work.testing.WorkManagerTestInitHelper.initializeTestWorkManager(context,new androidx.work.Configuration.Builder().setExecutor(Runnable::run).setTaskExecutor(Runnable::run).build());
        try(var controller=Robolectric.buildActivity(MainActivity.class).setup().visible()){
            MainActivity screen=controller.get();idle();screen.findViewById(R.id.explore).performClick();AlertDialog dialog=(AlertDialog)ShadowDialog.getLatestDialog();ListView list=dialog.getListView();int index=-1;for(int i=0;i<list.getAdapter().getCount();i++)if(list.getAdapter().getItem(i).toString().equals("Revisar versiones y partes"))index=i;assertTrue(index>=0);list.performItemClick(null,index,index);Intent started=Shadows.shadowOf(screen).getNextStartedActivity();assertEquals(VersionsActivity.class.getName(),started.getComponent().getClassName());
            screen.findViewById(R.id.explore).performClick();dialog=(AlertDialog)ShadowDialog.getLatestDialog();list=dialog.getListView();index=-1;for(int i=0;i<list.getAdapter().getCount();i++)if(list.getAdapter().getItem(i).toString().equals("Lista de deseos"))index=i;assertTrue(index>=0);list.performItemClick(null,index,index);started=Shadows.shadowOf(screen).getNextStartedActivity();assertEquals(OrganizationActivity.class.getName(),started.getComponent().getClassName());assertEquals(1,started.getIntExtra("section",-1));
        }finally{idle();androidx.work.testing.WorkManagerTestInitHelper.closeWorkDatabase();}}
}
