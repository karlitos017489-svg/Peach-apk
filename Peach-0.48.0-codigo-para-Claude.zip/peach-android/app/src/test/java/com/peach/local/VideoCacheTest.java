package com.peach.local;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28)
public class VideoCacheTest {
    File base;VideoCache cache;byte[] own;int calls;
    @Before public void before()throws Exception{base=Files.createTempDirectory("own-video-cache-").toFile();cache=new VideoCache(base);own=SourceVideosTest.own();}
    @After public void after()throws Exception{assertTrue(VideoCache.PARTS.isEmpty());assertTrue(VideoCache.PREPARING.isEmpty());assertTrue(VideoCache.PINS.isEmpty());GalleryProvidersTest.remove(base);}
    SourceVideos.Video video(String suffix){return new SourceVideos.Video("Own.bin","https://downloads.fanbox.cc/"+suffix+".mp4","fanbox");}
    SourceHttp.Download fetch(String u,File f,SourceHttp.Token t,long limit)throws IOException{calls++;return SourceHttp.copyAttachment(u,new ByteArrayInputStream(own),f,own.length,t,limit);}
    VideoCache.Lease acquire(String name,boolean offline)throws Exception{return cache.acquire(video(name),offline,new SourceHttp.Token(),this::fetch);}
    @Test public void ownMp4HasVerifiedPrivateCopyAndOfflineNeverFetches()throws Exception{
        try(var a=acquire("one",false)){assertFalse(a.cached);assertArrayEquals(own,Files.readAllBytes(a.file.toPath()));assertEquals("mp4",a.stamp.extension());assertEquals(own.length,a.stamp.bytes());assertTrue(a.file.getName().matches("[a-f0-9]{64}\\.mp4"));}
        try(var a=cache.acquire(video("one"),true,new SourceHttp.Token(),(u,f,t,l)->{fail();return null;})){assertTrue(a.cached);}assertEquals(1,calls);
        try{acquire("missing",true);fail();}catch(VideoCache.Problem expected){assertTrue(expected.getMessage().contains("Sin conexión"));}assertEquals(1,calls);
    }
    @Test public void headerHashSizeAndNetworkFailuresDoNotPromotePartials()throws Exception{
        for(int bad=0;bad<5;bad++){final int mode=bad;
            try{cache.acquire(video("bad"+bad),false,new SourceHttp.Token(),(u,f,t,l)->{
                if(mode==4)throw new IOException("https://private.invalid/?secret=OWN");byte[] bytes=mode==0?new byte[]{1,2,3}:mode==1?"GIF89a-own".getBytes():own;Files.write(f.toPath(),bytes);
                return new SourceHttp.Download(mode==2?bytes.length+1:bytes.length,mode==3?"0".repeat(64):GalleryCache.checksum(f));
            });fail();}catch(IOException expected){}assertEquals(0,cache.root.list().length);
        }
    }
    @Test public void cancelAfterTransferCleansOwnedPartAndNeverReturnsPlayableLease()throws Exception{
        SourceHttp.Token token=new SourceHttp.Token();try{cache.acquire(video("cancel"),false,token,(u,f,t,l)->{var r=fetch(u,f,t,l);t.cancel();return r;});fail();}catch(InterruptedIOException expected){}assertEquals(0,cache.root.list().length);
    }
    @Test public void corruptionIsRejectedOfflineAndExplicitPreparationCanRecover()throws Exception{
        File file;try(var a=acquire("tamper",false)){file=a.file;}Files.write(file.toPath(),new byte[]{1,2,3});try{acquire("tamper",true);fail();}catch(IOException expected){}assertFalse(file.exists());try(var a=acquire("tamper",false)){assertArrayEquals(own,Files.readAllBytes(a.file.toPath()));}assertEquals(2,calls);
    }
    @Test public void pawExpectedHashIsRequiredOnlineAndAgainstForgedOfflineSidecar()throws Exception{
        String real=GalleryCache.hex(GalleryCache.digest(own));var good=new SourceVideos.Video("Own.bin",SourceVideosTest.urls().get("pawchive"),"pawchive");
        try(var a=cache.acquire(good,false,new SourceHttp.Token(),this::fetch)){assertEquals(real,a.stamp.sha());}
        String wrong="aabb"+"0".repeat(60);var bad=new SourceVideos.Video("Own.bin","https://file.pawchive.pw/data/aa/bb/"+wrong+".mp4","pawchive");
        try{cache.acquire(bad,false,new SourceHttp.Token(),(u,f,t,l)->{Files.write(f.toPath(),own);return new SourceHttp.Download(own.length,real);});fail();}catch(IOException expected){}
        String key=VideoCache.keyFor(bad.url());Files.write(new File(cache.root,key+".mp4").toPath(),own);Files.write(cache.meta(key).toPath(),("peach-video-1\n"+own.length+"\n"+real+"\nmp4").getBytes(StandardCharsets.US_ASCII));
        try{cache.acquire(bad,true,new SourceHttp.Token(),this::fetch);fail();}catch(VideoCache.Problem expected){}assertFalse(cache.meta(key).exists());
    }
    @Test public void pinnedCopiesSurviveEvictionAndCannotBeDiscardedWhilePlaying()throws Exception{
        cache=new VideoCache(base,2L*own.length);VideoCache.Lease a=acquire("A",false),c=null;try{
            File old;try(var b=acquire("B",false)){old=b.file;}c=acquire("C",false);assertTrue(a.file.exists());assertFalse(old.exists());
            try{cache.discard(a.key);fail();}catch(VideoCache.Problem expected){assertTrue(a.file.exists());}
            try{acquire("D",false);fail();}catch(VideoCache.Problem expected){}assertEquals(3,calls);
        }finally{a.close();a.close();if(c!=null)c.close();}cache.discard(VideoCache.keyFor(video("A").url()));assertTrue(cache.files().stream().mapToLong(File::length).sum()<=cache.budget);
    }
    @Test public void offlineHitDoesNotWaitBehindAnUnrelatedNetworkPreparation()throws Exception{
        try(var a=acquire("old",false)){}cache=new VideoCache(base,3L*own.length);CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);ExecutorService worker=Executors.newSingleThreadExecutor();
        Future<VideoCache.Lease> task=worker.submit(()->cache.acquire(video("new"),false,new SourceHttp.Token(),(u,f,t,l)->{entered.countDown();try{if(!release.await(10,TimeUnit.SECONDS))throw new IOException();}catch(InterruptedException e){throw new InterruptedIOException();}return fetch(u,f,t,l);}));
        VideoCache.Lease old=null,created=null;try{assertTrue(entered.await(10,TimeUnit.SECONDS));old=acquire("old",true);assertTrue(old.cached);
            try{acquire("third",false);fail();}catch(VideoCache.Problem expected){}release.countDown();created=task.get(10,TimeUnit.SECONDS);assertTrue(old.file.exists());assertTrue(created.file.exists());
        }finally{release.countDown();if(old!=null)old.close();if(created!=null)created.close();worker.shutdownNow();assertTrue(worker.awaitTermination(10,TimeUnit.SECONDS));}
    }
    @Test public void boundedCountEvictsUnusedCopiesAndPreservesUnknownFiles()throws Exception{
        cache.root.mkdirs();File unknown=new File(cache.root,"keep.txt");Files.write(unknown.toPath(),new byte[]{1});File stale=new File(cache.root,"selected-video-abandoned.part");Files.write(stale.toPath(),new byte[]{1});
        for(int i=0;i<10;i++)try(var a=acquire("count"+i,false)){}
        assertEquals(VideoCache.MAX_FILES,cache.files().size());assertFalse(stale.exists());assertTrue(unknown.exists());assertFalse(new File(base,"Own.bin").exists());
    }
    @Test public void http429WaitsAcrossInstancesWithoutAutomaticRetry()throws Exception{
        try{cache.acquire(video("wait"),false,new SourceHttp.Token(),(u,f,t,l)->{calls++;throw new SourceHttp.Failure("https://secret.invalid/OWN",429,300);});fail();}catch(SourceHttp.Failure expected){}
        try{new VideoCache(base).acquire(video("wait"),false,new SourceHttp.Token(),this::fetch);fail();}catch(SourceHttp.Failure expected){assertEquals(429,expected.status);}assertEquals(1,calls);
    }
    @Test public void productionRedirectPipelinePreparesOwnMp4WithoutCdnSecretsInMetadata()throws Exception{
        var v=new SourceVideos.Video("Own.bin",SourceVideosTest.urls().get("rule34video"),"rule34video");String cdn=MediaRedirectsTest.CDN;var first=new RedirectHttpTest.Reply(v.url(),302,cdn,new byte[0]);var second=new RedirectHttpTest.Reply(cdn,200,null,own);var factory=new RedirectHttpTest.Factory(first,second);
        try(var a=cache.acquire(v,false,new SourceHttp.Token(),(u,f,t,l)->SourceHttp.download(u,f,t,l,factory,MediaRedirectsTest.PUBLIC))){assertArrayEquals(own,Files.readAllBytes(a.file.toPath()));String metadata=new String(Files.readAllBytes(cache.meta(a.key).toPath()),StandardCharsets.US_ASCII);assertFalse(metadata.contains("https"));assertFalse(metadata.contains("OWN_TEST"));assertFalse(metadata.contains("OWN_ONLY"));assertEquals(2,factory.requests.size());assertNull(second.getRequestProperty("Cookie"));assertNull(second.getRequestProperty("Authorization"));}
        assertTrue(first.closed&&second.closed&&second.inputClosed);
    }
    @Test public void sevenProviderPipelinesDownloadOwnBytesThenReopenOffline()throws Exception{
        for(var row:SourceVideosTest.urls().entrySet()){
            var v=new SourceVideos.Video("Own.bin",row.getValue(),row.getKey());try(var a=cache.acquire(v,false,new SourceHttp.Token(),this::fetch)){assertArrayEquals(own,Files.readAllBytes(a.file.toPath()));}
            try(var a=cache.acquire(v,true,new SourceHttp.Token(),(u,f,t,l)->{fail();return null;})){assertTrue(a.cached);}
        }
    }
    @Test public void publicMessagesNeverExposeUnknownNetworkExceptionOrCallerPaths(){
        String secret="https://secret.invalid/own?api_key=OWN_SECRET";assertFalse(VideoCache.message(new IOException(secret),new SourceHttp.Token()).contains("OWN_SECRET"));assertFalse(VideoCache.message(new SourceHttp.Failure(secret,403,0),new SourceHttp.Token()).contains("secret.invalid"));assertFalse(VideoCache.key("../../video"));
    }
}
