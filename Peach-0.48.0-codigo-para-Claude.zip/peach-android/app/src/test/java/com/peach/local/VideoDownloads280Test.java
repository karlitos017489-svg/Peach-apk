package com.peach.local;
import org.junit.Test;
import static org.junit.Assert.*;
@org.junit.runner.RunWith(org.robolectric.RobolectricTestRunner.class)
@org.robolectric.annotation.Config(sdk=28,manifest=org.robolectric.annotation.Config.NONE)
public class VideoDownloads280Test {
    @Test public void publicQualityAnchorsReplaceJsonLdPageReference()throws Exception{
        String html="<script type='application/ld+json'>{\"@type\":\"VideoObject\",\"name\":\"Own public fixture\",\"contentUrl\":\"https://rule34video.com/embed/1/\"}</script>"+
            "<a href='/get_file/1/own/own_1080p.mp4/?download=true'>MP4 1080p</a><a href='/get_file/1/own/own_720p.mp4/?download=true&amp;token=OWN_PUBLIC_FIXTURE'>MP4 720p</a><a href='https://evil.invalid/own.mp4?download=true'>MP4 480p</a>";
        var c=WebSourceConnectorTest.connector(html).detail("rule34video","own","1","https://rule34video.com/video/1/own/",new SourceHttp.Token());var files=c.getJSONArray("attachments");assertEquals(2,files.length());for(int i=0;i<files.length();i++){assertTrue(files.getJSONObject(i).getBoolean("downloadable"));assertTrue(files.getJSONObject(i).getString("name").endsWith(".mp4"));assertFalse(files.getJSONObject(i).getString("url").contains("embed"));}
    }
    @Test public void unresolvedJsonLdIsClearlyReferenceWithoutFakeBinExtension()throws Exception{String html="<script type='application/ld+json'>{\"@type\":\"VideoObject\",\"contentUrl\":\"https://rule34video.com/embed/1/\"}</script>";var f=WebSourceConnectorTest.connector(html).detail("rule34video","own","1","https://rule34video.com/video/1/own/",new SourceHttp.Token()).getJSONArray("attachments").getJSONObject(0);assertFalse(f.getBoolean("downloadable"));assertEquals("Referencia de video #1",f.getString("name"));}
    @Test public void downloadFlagAndBoundedPublicTokenStayOnStrictVideoPath()throws Exception{String base="https://rule34video.com/get_file/1/own/own.mp4/";assertTrue(WebSourceUrls.downloadable(base+"?download=true"));assertTrue(WebSourceUrls.downloadable(base+"?download=true&token=OWN_PUBLIC_FIXTURE&expires=123"));SourceHttp.attachmentRedirect(base+"?download=true",base+"?download=true");for(String u:new String[]{base+"?download=true&api_key=x",base+"?download=true&download=true",base+"?download=true&token=%0A",base+"?download=true&redirect=https%3A%2F%2Fevil.invalid",base+"?download=false",base+"?download=true#x",base.replace("rule34video.com","evil.invalid")+"?download=true","https://rule34video.com/embed/1/?download=true","https://api-cdn.rule34.xxx/images/1/"+"0".repeat(32)+".mp4?download=true"})assertFalse(WebSourceUrls.downloadable(u));try{SourceHttp.attachmentRedirect(base+"?download=true",base);fail();}catch(java.io.IOException expected){}}
}
