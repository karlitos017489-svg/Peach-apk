package com.peach.local;
import java.io.*;
import java.util.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class VideoVariantQualityTest {
    static final String BASE="https://rule34video.com/get_file/1/own/";
    static JSONObject video(String name,String tail)throws Exception{return SourceVideosTest.video(BASE+tail+".mp4").put("name",name);}
    static JSONObject variant(String name,long bytes)throws Exception{return new JSONObject().put("name",name).put("bytes",bytes);}
    @Test public void legacyCardIsPreviewAndHighestDeclaredDownloadIsSelectedWithoutReordering()throws Exception {
        var p=GalleryProvidersTest.publication("rule34video");var c=GalleryProvidersTest.content(p,new JSONArray().put(video("Own1080","preview")));c.type="list";assertEquals("preview",SourceVideos.select(p,c).videos().get(0).variant().role());
        c.type="rule34video-detail";c.attachments=new JSONArray().put(video("Vista previa #1","preview")).put(video("Vídeo #1 · MP4 360p 1 MB.mp4","low")).put(video("Vídeo #1 · MP4 1080p4 MB.mp4","high")).toString();var s=SourceVideos.select(p,c);assertEquals(3,s.videos().size());assertTrue(s.videos().get(0).url().contains("preview"));assertEquals(2,VideoVariants.best(s.videos()));assertEquals(1080,s.videos().get(2).variant().height());assertTrue(VideoVariants.label(s.videos().get(0)).contains("Vista previa"));
    }
    @Test public void cumstRetainsVideoAlternativesInsteadOfSelectingAnImageOrLargestPreview()throws Exception {
        var file=CumstConnectorTest.file().put("originalFilename","Own.mp4").put("variants",new JSONArray().put(variant("poster.jpg",99999999)).put(variant("preview.mp4",9000000)).put(variant("low-480p.mp4",1000000)).put(variant("high-1080p.mp4",5000000)));
        var body=CumstConnector.content(CumstConnectorTest.post("1").put("attachments",new JSONArray().put(file)),true);var a=body.getJSONArray("attachments");assertEquals(3,a.length());assertTrue(a.getJSONObject(0).getString("url").endsWith("high-1080p.mp4"));for(int i=0;i<a.length();i++){assertEquals("video",a.getJSONObject(i).getString("kind"));assertFalse(a.getJSONObject(i).getString("url").endsWith("poster.jpg"));}assertEquals(a.getJSONObject(0).getString("variantGroup"),a.getJSONObject(2).getString("variantGroup"));assertEquals("preview",a.getJSONObject(2).getString("videoRole"));
    }
    @Test public void cumstPreservesEveryPrimaryBeforeOptionalAlternativesWithinTheExistingBudget()throws Exception {
        JSONArray files=new JSONArray();for(int i=0;i<100;i++)files.put(CumstConnectorTest.file().put("storageKey","own/file-"+i).put("originalFilename","own.mp4").put("variants",new JSONArray().put(variant("own-1080p.mp4",100)).put(variant("own-480p.mp4",20))));var body=CumstConnector.content(CumstConnectorTest.post("1").put("attachments",files),true);var a=body.getJSONArray("attachments");assertEquals(100,a.length());Set<String> groups=new HashSet<>();for(int i=0;i<a.length();i++){assertTrue(a.getJSONObject(i).getString("url").endsWith("own-1080p.mp4"));groups.add(a.getJSONObject(i).getString("variantGroup"));}assertEquals(100,groups.size());assertTrue(body.getString("text").contains("variantes adicionales omitidas"));
    }
    @Test public void cumstLockedVariantsAndManifestsAreNotOfferedAsVideoAlternatives()throws Exception {
        var file=CumstConnectorTest.file().put("originalFilename","Own.mp4").put("variants",new JSONArray().put(variant("own-2160p.mp4",9000).put("locked",true)).put(variant("own-720p.mp4",200)).put(variant("index.m3u8",10000)));var body=CumstConnector.content(CumstConnectorTest.post("1").put("attachments",new JSONArray().put(file)),true);var a=body.getJSONArray("attachments");assertEquals(1,a.length());assertTrue(a.getJSONObject(0).getString("url").endsWith("own-720p.mp4"));
    }
    @Test public void bestChoiceStaysWithinTheFirstNonPreviewAttachmentGroup()throws Exception {
        var p=GalleryProvidersTest.publication("cumst");String one="a".repeat(64),two="b".repeat(64);JSONArray a=new JSONArray();for(Object[] data:new Object[][]{{"one-low",one,480,100L},{"two",two,2160,9999L},{"one-high",one,1080,500L}}){String n=(String)data[0];a.put(VideoVariants.mark(SourceVideosTest.video(CumstUrls.media("own/key",n+".mp4")),"unknown",(int)data[2],(long)data[3],(String)data[1]));}var s=SourceVideos.select(p,GalleryProvidersTest.content(p,a));assertEquals(2,VideoVariants.best(s.videos()));assertEquals(0,VideoVariants.height("video ID1080987654"));
    }
    @Test public void rule34ApiKeepsFileUrlInsteadOfSampleAndPreviewUrls()throws Exception {
        String original="https://api-cdn.rule34.xxx/images/1/"+"a".repeat(32)+".mp4";JSONObject post=new JSONObject().put("id",1).put("file_url",original).put("sample_url",original.replace("a".repeat(32),"b".repeat(32))).put("preview_url",original.replace("a".repeat(32),"c".repeat(32))).put("height",1080).put("tags","own");var page=WebSourceConnector.api("own",CumstConnectorTest.response(new JSONArray().put(post)),new SourceCredentials.ApiKey("123","OWN_SECRET"));var a=page.page().candidates().getJSONObject(0).getJSONArray("attachments");assertEquals(1,a.length());assertEquals(original,a.getJSONObject(0).getString("url"));assertEquals("published",a.getJSONObject(0).getString("videoRole"));assertEquals(1080,a.getJSONObject(0).getInt("videoHeight"));
    }
    @Test public void additiveVariantMetadataSurvivesBackupSeventeenWithoutNewMediaRows()throws Exception {
        var db=androidx.room.Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().build();try{var p=GalleryProvidersTest.publication("rule34video");var a=VideoVariants.mark(video("MP4 1080p","high"),"download",1080,9000,"a".repeat(64));var c=GalleryProvidersTest.content(p,new JSONArray().put(a));c.type="rule34video-detail";db.library().insertPublication(p);db.library().putPublicationContent(c);ByteArrayOutputStream out=new ByteArrayOutputStream();BackupStore.write(db.library(),out);assertEquals(19,new JSONObject(out.toString("UTF-8")).getInt("version"));db.library().deletePublication(p.id);BackupStore.read(db,new ByteArrayInputStream(out.toByteArray()));var s=SourceVideos.load(db,p.id);assertEquals(1080,s.videos().get(0).variant().height());assertEquals(9000,s.videos().get(0).variant().bytes());assertTrue(db.library().allMedia().isEmpty());assertEquals(0,db.library().usageCount());}finally{db.close();}
    }
}
