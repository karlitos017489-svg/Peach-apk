package com.peach.local;
import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE) @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class VideoVersionReviewTest {
    LibraryDatabase db;Publication p;PublicationContent c;AtomicInteger calls;
    static final String POST="https://rule34video.com/video/1/own/";
    static String html(){return "<script type='application/ld+json'>{\"@type\":\"VideoObject\",\"name\":\"Own\"}</script><a href='"+VideoVariantQualityTest.BASE+"low.mp4?download=true'>MP4 360p 1 MB</a><a href='"+VideoVariantQualityTest.BASE+"high.mp4?download=true'>MP4 1080p 4 MB</a>";}
    @Before public void before()throws Exception{db=androidx.room.Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();p=GalleryProvidersTest.publication("rule34video");p.sourceRef="own";p.externalId="1";p.url=POST;p.title="Personal title";p.notes="Own notes";c=GalleryProvidersTest.content(p,new JSONArray().put(VideoVariantQualityTest.video("Vista previa #1","preview")));c.type="list";db.library().insertPublication(p);db.library().putPublicationContent(c);calls=new AtomicInteger();}
    @After public void after(){db.close();}
    SourceHttp.Transport transport(){return(u,e,m,t)->{calls.incrementAndGet();assertEquals(POST,u);return CumstConnectorTest.response(html());};}
    @Test public void oneDetachedPublicationCanBeQueriedWithoutCurrentSourcePageAndAppliedAfterReview()throws Exception {
        var review=VideoVersionReview.query(db,p.id,transport(),new SourceHttp.Token());assertEquals(1,calls.get());assertEquals(c.attachments,db.library().publicationContent(p.id).attachments);assertEquals(2,review.selection().videos().size());assertEquals(1,VideoVariants.best(review.selection().videos()));VideoVersionReview.apply(db,review,new SourceHttp.Token());assertEquals("rule34video-detail",db.library().publicationContent(p.id).type);assertEquals(p.title,db.library().publication(p.id).title);assertEquals(p.notes,db.library().publication(p.id).notes);assertTrue(db.library().sources().isEmpty());assertTrue(db.library().allMedia().isEmpty());assertEquals(0,db.library().usageCount());
    }
    @Test public void staleReviewCannotOverwriteNewerContentOrChangedSourceIdentity()throws Exception {
        var review=VideoVersionReview.query(db,p.id,transport(),new SourceHttp.Token());c.text="Own newer body";c.checkedAt++;db.library().putPublicationContent(c);try{VideoVersionReview.apply(db,review,new SourceHttp.Token());fail();}catch(IOException expected){}assertEquals(c.text,db.library().publicationContent(p.id).text);review=VideoVersionReview.query(db,p.id,transport(),new SourceHttp.Token());p.externalId="2";p.url="https://rule34video.com/video/2/other/";db.library().updatePublication(p);try{VideoVersionReview.apply(db,review,new SourceHttp.Token());fail();}catch(IOException expected){}assertEquals(c.text,db.library().publicationContent(p.id).text);
    }
    @Test public void deletedOrUnsupportedPublicationDoesNotQueryOrGetRecreatedByApply()throws Exception {
        var review=VideoVersionReview.query(db,p.id,transport(),new SourceHttp.Token());db.library().deletePublication(p.id);try{VideoVersionReview.apply(db,review,new SourceHttp.Token());fail();}catch(IOException expected){}try{VideoVersionReview.query(db,p.id,transport(),new SourceHttp.Token());fail();}catch(IOException expected){}assertEquals(1,calls.get());assertNull(db.library().publication(p.id));p.provider="rule34xxx";p.sourceRef="own";assertFalse(VideoVersionReview.canQuery(p));
    }
    @Test public void emptyAndPreviewOnlyRefreshCannotReplaceAStoredPlayableVersion()throws Exception {
        c.type="rule34video-detail";c.attachments=new JSONArray().put(VideoVariantQualityTest.video("Vídeo #1 · MP4 1080p","old" )).toString();db.library().putPublicationContent(c);String old=c.attachments;
        for(String value:List.of("<script type='application/ld+json'>{\"@type\":\"VideoObject\"}</script>","<script type='application/ld+json'>{\"@type\":\"VideoObject\",\"contentUrl\":\""+VideoVariantQualityTest.BASE+"preview.mp4\"}</script>")){var review=VideoVersionReview.query(db,p.id,(u,e,m,t)->CumstConnectorTest.response(value),new SourceHttp.Token());try{VideoVersionReview.apply(db,review,new SourceHttp.Token());fail();}catch(IOException expected){}assertEquals(old,db.library().publicationContent(p.id).attachments);}
    }
    @Test public void pausedSourceAndPersisted429StopQueriesBeforeNetwork()throws Exception {
        var store=new SourceStore(db,transport());String source=store.create("rule34video","own","Own source",null);c.sourceId=source;db.library().putPublicationContent(c);store.edit(source,"Own source",null,true);try{VideoVersionReview.query(db,p.id,transport(),new SourceHttp.Token());fail();}catch(IOException expected){}assertEquals(0,calls.get());store.edit(source,"Own source",null,false);
        try{VideoVersionReview.query(db,p.id,(u,e,m,t)->{calls.incrementAndGet();throw new SourceHttp.Failure("OWN_SECRET",429,300);},new SourceHttp.Token());fail();}catch(IOException expected){assertFalse(expected.getMessage().contains("OWN_SECRET"));}assertTrue(db.library().source(source).cooldownUntil>System.currentTimeMillis());try{VideoVersionReview.query(db,p.id,transport(),new SourceHttp.Token());fail();}catch(IOException expected){}assertEquals(1,calls.get());assertEquals(c.attachments,db.library().publicationContent(p.id).attachments);
    }
    @Test public void cumstRefreshUsesItsExistingApiAndRetainsAlternativesWithoutMediaRequests()throws Exception {
        db.library().deletePublication(p.id);p.provider="cumst";p.sourceRef="patreon/123";p.externalId="own-1";p.url=CumstUrls.postUrl(p.sourceRef,p.externalId);db.library().insertPublication(p);c.type="list";db.library().putPublicationContent(c);JSONObject post=CumstConnectorTest.post("own-1");post.put("attachments",new JSONArray().put(CumstConnectorTest.file().put("originalFilename","own.mp4").put("variants",new JSONArray().put(VideoVariantQualityTest.variant("own-480p.mp4",100)).put(VideoVariantQualityTest.variant("own-1080p.mp4",900)))));
        var review=VideoVersionReview.query(db,p.id,(u,e,m,t)->{calls.incrementAndGet();assertEquals(CumstUrls.detail(p.sourceRef,p.externalId),u);return CumstConnectorTest.response(post);},new SourceHttp.Token());assertEquals(1,calls.get());assertEquals(2,review.selection().videos().size());VideoVersionReview.apply(db,review,new SourceHttp.Token());assertEquals(2,SourceVideos.load(db,p.id).videos().size());
    }
    @Test public void pahealRefreshUsesMainMediaWithoutFollowingAnExternalReference()throws Exception {
        db.library().deletePublication(p.id);p.provider="rule34paheal";p.sourceRef="own";p.externalId="1";p.url="https://rule34.paheal.net/post/view/1";db.library().insertPublication(p);c.attachments="[]";db.library().putPublicationContent(c);String media="https://r34i.paheal-cdn.net/aa/bb/aabb"+"c".repeat(28);String html="<video id='main_image'><source src='"+media+"' type='video/mp4'></video>";
        var review=VideoVersionReview.query(db,p.id,(u,e,m,t)->{calls.incrementAndGet();assertEquals(p.url,u);return CumstConnectorTest.response(html);},new SourceHttp.Token());assertEquals(1,calls.get());assertEquals(media,review.selection().videos().get(0).url());VideoVersionReview.apply(db,review,new SourceHttp.Token());assertEquals("paheal-detail",db.library().publicationContent(p.id).type);
    }
    @Test public void cancellationBeforeQueryAndDuringResponseNeverWritesOrDownloads()throws Exception {
        SourceHttp.Token before=new SourceHttp.Token();before.cancel();try{VideoVersionReview.query(db,p.id,transport(),before);fail();}catch(IOException expected){}assertEquals(0,calls.get());SourceHttp.Token during=new SourceHttp.Token();try{VideoVersionReview.query(db,p.id,(u,e,m,t)->{calls.incrementAndGet();t.cancel();return CumstConnectorTest.response(html());},during);fail();}catch(IOException expected){}assertEquals(c.attachments,db.library().publicationContent(p.id).attachments);assertEquals(1,calls.get());
    }
}
