package com.peach.local;
import android.os.*;
import androidx.appcompat.app.AlertDialog;
import java.util.concurrent.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowDialog;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land") @SQLiteMode(SQLiteMode.Mode.LEGACY) @GraphicsMode(GraphicsMode.Mode.NATIVE)
public class VideoVersionUiTest {
    SourceVideoUiTest fixture;int calls;SourceHttp.Transport previous;
    @Before public void before()throws Exception{fixture=new SourceVideoUiTest();fixture.before();fixture.p.sourceRef="own";fixture.p.externalId="1";fixture.p.url=VideoVersionReviewTest.POST;fixture.db.library().updatePublication(fixture.p);fixture.body.type="list";fixture.body.attachments=new JSONArray().put(VideoVariantQualityTest.video("Vista previa #1","preview")).toString();fixture.db.library().putPublicationContent(fixture.body);previous=SourcesActivity.transport;SourcesActivity.transport=(u,e,m,t)->{calls++;assertEquals(VideoVersionReviewTest.POST,u);return CumstConnectorTest.response(VideoVersionReviewTest.html());};}
    @After public void after()throws Exception{SourcesActivity.transport=previous;fixture.after();}
    @Test public void previewIsExplicitAndQueryRequiresReviewBeforeReplacingIt()throws Exception {
        var c=fixture.screen(fixture.p.id);fixture.settle(c.get());assertEquals("Ver vista previa en línea",c.get().online.getText().toString());assertTrue(c.get().status.getText().toString().contains("vista previa"));assertEquals(0,calls);assertTrue(c.get().versions.isEnabled());c.get().versions.performClick();fixture.settle(c.get());assertEquals(1,calls);assertEquals(fixture.body.attachments,fixture.db.library().publicationContent(fixture.p.id).attachments);assertEquals(0,fixture.calls);AlertDialog dialog=(AlertDialog)ShadowDialog.getLatestDialog();assertEquals("Usar versiones",dialog.getButton(AlertDialog.BUTTON_POSITIVE).getText().toString());dialog.getButton(AlertDialog.BUTTON_NEGATIVE).performClick();fixture.idle();assertEquals(fixture.body.attachments,fixture.db.library().publicationContent(fixture.p.id).attachments);
        c.get().versions.performClick();fixture.settle(c.get());dialog=(AlertDialog)ShadowDialog.getLatestDialog();dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick();fixture.settle(c.get());assertEquals(2,calls);assertEquals(1080,c.get().draft.selection.videos().get(c.get().draft.index).variant().height());assertEquals("Ver en línea",c.get().online.getText().toString());assertEquals(0,fixture.calls);assertNull(Shadows.shadowOf(c.get()).getNextStartedActivity());
    }
    @Test public void offlineModePreventsMetadataRefreshAsWellAsPlayback()throws Exception {
        var c=fixture.screen(fixture.p.id);fixture.settle(c.get());c.get().offline.setChecked(true);assertFalse(c.get().versions.isEnabled());c.get().versions.performClick();fixture.settle(c.get());assertEquals(0,calls);assertEquals(fixture.body.attachments,fixture.db.library().publicationContent(fixture.p.id).attachments);
    }
    @Test public void rotationDuringQueryKeepsOneWorkAndReviewOnlyOnTheNewScreen()throws Exception {
        CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);SourcesActivity.transport=(u,e,m,t)->{calls++;entered.countDown();try{release.await(5,TimeUnit.SECONDS);}catch(InterruptedException ex){throw new java.io.InterruptedIOException();}return CumstConnectorTest.response(VideoVersionReviewTest.html());};var c=fixture.screen(fixture.p.id);fixture.settle(c.get());c.get().versions.performClick();assertTrue(entered.await(5,TimeUnit.SECONDS));var draft=c.get().draft;try{c.recreate();assertSame(draft,c.get().draft);}finally{release.countDown();}fixture.settle(c.get());assertEquals(1,calls);assertNotNull(c.get().reviewDialog);assertTrue(c.get().reviewDialog.isShowing());assertEquals(fixture.body.attachments,fixture.db.library().publicationContent(fixture.p.id).attachments);c.get().reviewDialog.getButton(AlertDialog.BUTTON_NEGATIVE).performClick();fixture.idle();
    }
    @Test public void leavingQueryCancelsWithoutOpeningAReviewOrWritingTheContent()throws Exception {
        CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);SourcesActivity.transport=(u,e,m,t)->{calls++;entered.countDown();try{release.await(5,TimeUnit.SECONDS);}catch(InterruptedException ex){throw new java.io.InterruptedIOException();}return CumstConnectorTest.response(VideoVersionReviewTest.html());};var c=fixture.screen(fixture.p.id);fixture.settle(c.get());c.get().versions.performClick();assertTrue(entered.await(5,TimeUnit.SECONDS));c.pause().stop();release.countDown();c.start().resume().visible();fixture.settle(c.get());assertNull(c.get().draft.versionReview);assertNull(c.get().reviewDialog);assertEquals(fixture.body.attachments,fixture.db.library().publicationContent(fixture.p.id).attachments);assertEquals(0,fixture.calls);
    }
}
