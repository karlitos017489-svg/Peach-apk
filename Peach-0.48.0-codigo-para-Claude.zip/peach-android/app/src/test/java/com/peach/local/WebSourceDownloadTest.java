package com.peach.local;
import java.io.*;
import java.nio.file.*;
import org.junit.*;
import static org.junit.Assert.*;
public class WebSourceDownloadTest {
    static final String[] URLS={"https://r34i.paheal-cdn.net/aa/bb/aabb0000000000000000000000000000","https://api-cdn.rule34.xxx/images/12/00000000000000000000000000000000.png","https://attachments.f95zone.to/2026/10/own.png","https://rule34video.com/get_file/1/own/own.mp4"};
    @Test public void auditedMediaCopiesOwnBytesAndComputesShaWithoutInventedMd5Verification()throws Exception{for(String u:URLS){File f=File.createTempFile("web-own-",".tmp");try{var d=SourceHttp.copyAttachment(u,new ByteArrayInputStream("abc".getBytes()),f,3,new SourceHttp.Token());assertEquals(PawchiveDownloadTest.HASH,d.sha256());assertArrayEquals("abc".getBytes(),Files.readAllBytes(f.toPath()));}finally{f.delete();}}}
    @Test public void mismatchCancellationAndSizeFailureDeletePrivatePartial()throws Exception{for(String u:URLS)for(int mode=0;mode<3;mode++){File f=File.createTempFile("web-own-",".tmp");SourceHttp.Token t=new SourceHttp.Token();if(mode==0)t.cancel();long expected=mode==1?4:3,limit=mode==2?2:4;PawchiveDownloadTest.rejects(()->SourceHttp.copyAttachment(u,new ByteArrayInputStream("abc".getBytes()),f,expected,t,limit));assertFalse(f.exists());}}
    @Test public void referenceOnlyMediaAndCrossProviderRedirectsStayDisabled()throws Exception{for(String u:new String[]{"https://example.org/own.mp4","https://boomio-cdn.com/a.mp4","https://attachments.f95zone.to/../a.png"}){assertFalse(SourceHttp.canSave(u,true));PawchiveDownloadTest.rejects(()->SourceHttp.attachmentRedirect(URLS[0],u));}PawchiveDownloadTest.rejects(()->SourceHttp.attachmentRedirect(URLS[0],URLS[1]));PawchiveDownloadTest.rejects(()->SourceHttp.attachmentRedirect(URLS[1],URLS[1].replace("12/","13/")));}
}
