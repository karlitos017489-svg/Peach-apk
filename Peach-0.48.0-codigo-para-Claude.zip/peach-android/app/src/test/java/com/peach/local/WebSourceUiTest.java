package com.peach.local;

import android.os.Looper;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.room.Room;
import java.util.concurrent.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowDialog;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land") @SQLiteMode(SQLiteMode.Mode.LEGACY)
public class WebSourceUiTest {
    LibraryDatabase db;SourcesActivity activity;SourceHttp.Transport previous;int calls;
    byte[] fixture(String url){try{String host=SourceHttp.https(url).getHost(),p=host.equals("f95zone.to")?"f95zone":host.equals("rule34video.com")?"rule34video":host.equals("rule34.paheal.net")?"rule34paheal":"rule34xxx";return WebSourceConnectorTest.body(p,1).getBytes(java.nio.charset.StandardCharsets.UTF_8);}catch(Exception e){throw new AssertionError(e);}}
    @Before public void open(){db=Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(),LibraryDatabase.class).allowMainThreadQueries().setQueryExecutor(Runnable::run).setTransactionExecutor(Runnable::run).build();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",db);previous=SourcesActivity.transport;SourcesActivity.transport=(u,e,m,t)->{calls++;return new SourceHttp.Response(200,fixture(u),"","");};}
    @After public void close()throws Exception{if(activity!=null){var draft=new androidx.lifecycle.ViewModelProvider(activity).get(SourcesActivity.Draft.class);draft.token.cancel();draft.worker.shutdown();assertTrue(draft.worker.awaitTermination(30,TimeUnit.SECONDS));}SourcesActivity.transport=previous;db.close();org.robolectric.util.ReflectionHelpers.setStaticField(LibraryDatabase.class,"instance",null);}
    void idle()throws Exception{var d=new androidx.lifecycle.ViewModelProvider(activity).get(SourcesActivity.Draft.class);for(int i=0;i<3;i++){d.worker.submit(()->{}).get(30,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}}
    AlertDialog dialog(){Shadows.shadowOf(Looper.getMainLooper()).idle();return (AlertDialog)ShadowDialog.getLatestDialog();}
    View find(View v,java.util.function.Predicate<View> p){if(p.test(v))return v;if(v instanceof ViewGroup g)for(int i=0;i<g.getChildCount();i++){View found=find(g.getChildAt(i),p);if(found!=null)return found;}return null;}
    Button button(String label){return (Button)find(activity.getWindow().getDecorView(),v->v instanceof Button b && label.contentEquals(b.getText()));}
    @Test public void allFourSelectorsCreateDistinctSourcesWithoutNetwork()throws Exception{try(var c=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){activity=c.get();idle();for(String p:java.util.List.of("rule34paheal","rule34xxx","rule34video","f95zone")){button("Añadir fuente").performClick();Spinner providers=(Spinner)find(dialog().getWindow().getDecorView(),v->v instanceof Spinner s && "Proveedor de contenido".contentEquals(s.getContentDescription()));providers.setSelection(SourceProviders.KEYS.indexOf(p));Shadows.shadowOf(Looper.getMainLooper()).idle();EditText ref=(EditText)find(dialog().getWindow().getDecorView(),v->v instanceof EditText e && ("Referencia "+p).contentEquals(e.getContentDescription()));assertNotNull(ref);ref.setText(WebSourceConnectorTest.ref(p));dialog().getButton(AlertDialog.BUTTON_POSITIVE).performClick();idle();}assertEquals(4,db.library().sources().size());assertEquals(0,calls);}}
    @Test public void threePublicProvidersImportViaVisibleControlsAndRecreationDoesNotRefetch()throws Exception{var store=new SourceStore(db,SourcesActivity.transport);for(String p:java.util.List.of("rule34paheal","rule34video","f95zone"))store.create(p,WebSourceConnectorTest.ref(p),p,null);try(var c=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){activity=c.get();idle();for(String p:java.util.List.of("rule34paheal","rule34video","f95zone")){var d=new androidx.lifecycle.ViewModelProvider(activity).get(SourcesActivity.Draft.class);int index=-1;for(int i=0;i<d.sources.size();i++)if(d.sources.get(i).provider.equals(p))index=i;Spinner list=(Spinner)find(activity.getWindow().getDecorView(),v->v instanceof Spinner s && "Fuente de contenido".contentEquals(s.getContentDescription()));list.setSelection(index);idle();button("Consultar novedades").performClick();idle();button("Importar página revisada").performClick();dialog().getButton(AlertDialog.BUTTON_POSITIVE).performClick();idle();}assertEquals(3,calls);assertEquals(3,db.library().publications().size());c.recreate();activity=c.get();idle();assertEquals(3,calls);}}
    @Test public void apiConfigurationIsLocalMaskedAndMissingKeyStopsNetwork()throws Exception{new SourceStore(db,SourcesActivity.transport).create("rule34xxx","own_tag","API propia",null);try(var c=Robolectric.buildActivity(SourcesActivity.class).setup().visible()){activity=c.get();idle();button("Credenciales API").performClick();EditText key=(EditText)find(dialog().getWindow().getDecorView(),v->v instanceof EditText e && "Clave API".contentEquals(e.getContentDescription()));assertNotNull(key);assertFalse(key.isSaveEnabled());assertTrue((key.getInputType() & android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD)!=0);assertTrue((dialog().getWindow().getAttributes().flags & android.view.WindowManager.LayoutParams.FLAG_SECURE)!=0);dialog().getButton(AlertDialog.BUTTON_NEGATIVE).performClick();button("Consultar novedades").performClick();idle();assertEquals(0,calls);assertEquals("[]",db.library().sources().get(0).cachedPage);assertNotNull(find(activity.getWindow().getDecorView(),v->v instanceof TextView t && t.getText().toString().contains("Credenciales API")));}}
}
