package com.peach.local;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

public class ZipBookTest {
    @Rule public TemporaryFolder temp=new TemporaryFolder();
    private File zip(String... names) throws Exception {
        File file=temp.newFile();try(ZipOutputStream out=new ZipOutputStream(new FileOutputStream(file))){for(String name:names){out.putNextEntry(new ZipEntry(name));out.write(("contenido "+name).getBytes(java.nio.charset.StandardCharsets.UTF_8));out.closeEntry();}}return file;
    }
    private void rejects(File file) throws Exception {try(ZipBook book=new ZipBook(file)){fail("Archive accepted");}catch(java.io.IOException expected){}}
    private int signature(byte[] bytes,int value){for(int i=0;i+4<=bytes.length;i++)if((bytes[i]&255)==(value&255) && (bytes[i+1]&255)==((value>>>8)&255) && (bytes[i+2]&255)==((value>>>16)&255) && (bytes[i+3]&255)==((value>>>24)&255))return i;throw new AssertionError();}
    @Test public void indexesEveryFileAndNaturallySortsPicturesWithoutExtractingTheWholeArchive() throws Exception {
        File file=zip("fotos/10.jpg","fotos/2.jpg","fotos/1.jpg","notas.txt","video.mp4","nested.zip");File output=temp.newFolder();
        try(ZipBook book=new ZipBook(file)) {
            assertEquals(List.of("fotos/1.jpg","fotos/2.jpg","fotos/10.jpg","nested.zip","notas.txt","video.mp4"),book.items().stream().map(ArchiveBook.Item::name).toList());
            assertEquals("",book.item("nested.zip").kind());assertEquals(0,output.list().length);
            File entry=book.read("notas.txt",output);assertEquals("contenido notas.txt",new String(Files.readAllBytes(entry.toPath()),java.nio.charset.StandardCharsets.UTF_8));assertEquals(List.of("entry"),List.of(output.list()));
            try{book.read("video.mp4",output);fail();}catch(java.io.IOException expected){}
        }
    }
    @Test public void traversalAbsoluteAndControlNamesAreRejectedBeforeMaterialization() throws Exception {
        for(String name:List.of("../escape.png","a/../escape.png","/absolute.png","C:\\escape.png","a\\..\\escape.png","a/./b.png","bad\nname.png"))rejects(zip(name));
    }
    @Test public void duplicateNamesAndCorruptEntryCrcAreRejected() throws Exception {
        File file=zip("img1.png","img2.png");byte[] bytes=Files.readAllBytes(file.toPath());
        String encoded=new String(bytes,java.nio.charset.StandardCharsets.ISO_8859_1).replace("img2.png","img1.png");Files.write(file.toPath(),encoded.getBytes(java.nio.charset.StandardCharsets.ISO_8859_1));rejects(file);
        file=zip("notes.txt");bytes=Files.readAllBytes(file.toPath());int at=signature(bytes,0x02014b50);for(int i=16;i<20;i++)bytes[at+i]=0;Files.write(file.toPath(),bytes);File output=temp.newFolder();
        try(ZipBook book=new ZipBook(file)){try{book.read("notes.txt",output);fail();}catch(java.io.IOException expected){}assertEquals(0,output.list().length);}
    }
    @Test public void zip64SplitArchivesAndOversizedCentralDirectoryAreRejected() throws Exception {
        for(int mode=0;mode<3;mode++) {
            File file=zip("notes.txt");byte[] bytes=Files.readAllBytes(file.toPath());int at=signature(bytes,0x06054b50);
            if(mode==0){bytes[at+10]=(byte)255;bytes[at+11]=(byte)255;bytes[at+8]=(byte)255;bytes[at+9]=(byte)255;}
            if(mode==1)bytes[at+4]=1;if(mode==2)bytes[at+15]=2;
            Files.write(file.toPath(),bytes);rejects(file);
        }
    }
    @Test public void boundedReadStopsLargeExpansionEvenWhenDeclaredSizeIsFalse() throws Exception {
        File file=temp.newFile();byte[] block=new byte[1024*1024];
        try(ZipOutputStream out=new ZipOutputStream(new FileOutputStream(file))){out.putNextEntry(new ZipEntry("big.txt"));for(int i=0;i<65;i++)out.write(block);out.closeEntry();}
        File output=temp.newFolder();try(ZipBook book=new ZipBook(file)){try{book.read("big.txt",output);fail();}catch(java.io.IOException expected){}}
        byte[] bytes=Files.readAllBytes(file.toPath());int at=signature(bytes,0x02014b50);for(int i=24;i<28;i++)bytes[at+i]=0;bytes[at+24]=1;Files.write(file.toPath(),bytes);
        try(ZipBook book=new ZipBook(file)){try{book.read("big.txt",output);fail();}catch(java.io.IOException expected){}}assertEquals(0,output.list().length);
    }
    @Test public void rejectsMoreThanTenThousandEntriesAndAcceptsEmptyZip() throws Exception {
        File file=temp.newFile();try(ZipOutputStream out=new ZipOutputStream(new FileOutputStream(file))){for(int i=0;i<=ZipBook.MAX_ENTRIES;i++){out.putNextEntry(new ZipEntry("f"+i));out.closeEntry();}}rejects(file);
        File empty=zip();try(ZipBook book=new ZipBook(empty)){assertTrue(book.items().isEmpty());}
    }
    @Test public void naturalOrderHandlesLongNumbersAndSupportedReaderFamilies() {
        var names=new java.util.ArrayList<>(List.of("foto10.png","foto2.png","foto1.png"));names.sort(DocumentRules::naturalCompare);assertEquals(List.of("foto1.png","foto2.png","foto10.png"),names);
        assertTrue(DocumentRules.naturalCompare("x"+"9".repeat(80),"x1"+"0".repeat(80))<0);
        assertEquals(DocumentRules.PDF,DocumentRules.kind("book.PDF"));assertEquals(DocumentRules.ZIP,DocumentRules.kind("album.cbz"));assertEquals(DocumentRules.RAR,DocumentRules.kind("album.rar"));assertTrue(DocumentRules.readable("album.cbr"));assertFalse(DocumentRules.readable("album.arj"));
    }
}
