# Ejemplo propio de intercambio

Extrae este ZIP en una carpeta propia. En Peach añade/escanea esa carpeta (la raíz que
contiene `documentos`). Abre Menú → Importación y sincronización → Elegir intercambio,
y selecciona `Peach-ejemplo-intercambio.json`. Vincula «Ejemplo propio» con esa carpeta.
Revisa favorito, título y etiquetas por campo; los conflictos conservan lo local salvo
que elijas Entrante. Aplica solo lo que desees. No importa automáticamente los medios;
el TXT se reconoce al escanear la carpeta. No hay contraseñas o cuentas en este ejemplo.
La fecha fija del ejemplo no es una fecha real de uso. Puedes probar Deshacer si no has
hecho nuevos cambios en la biblioteca. No uses este archivo como base de otra persona.
