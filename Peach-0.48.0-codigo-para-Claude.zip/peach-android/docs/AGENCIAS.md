# Agencias y afiliaciones en 0.11.0

En **Identidades y alias** aparece **Agencias** como sexto tipo de ficha. Comparte
nombre, notas, favorito, alias exactos y referencias locales con las identidades
anteriores. No es un estudio, etiqueta ni archivo. Funciona sin medios ni conexión.

## Uso

1. En el selector de tipos elegir Agencias y pulsar Crear. La ficha se crea con ese tipo.
2. Abrir la ficha y **Organizar → Miembros de la agencia → Añadir miembro**. Se pueden
   elegir personas del reparto o creadores ya registrados. Se crea la afiliación por
   sus UUID, sin adivinarla a partir de nombres, etiquetas o coincidencias de archivos.
3. Desde una persona o creador, **Organizar → Afiliación a agencia** muestra su agencia,
   fuente, confianza registrada y fecha. Elegir agencia permite asignarla. Un cambio
   a otra agencia muestra antes el resultado y permite conservar la anterior.
4. Quitar afiliación o Retirar miembro elimina solo esa relación. No elimina personas,
   agencias, medios, listas, deseos o progreso. Cada persona/creador tiene como máximo
   una afiliación vigente. No se mantiene una cronología de cambios de agencia.
5. En una agencia, **Ver archivos** reúne los de sus miembros actuales. Se consideran
   coincidencias exactas NFO/catálogo y vínculos manuales de esas personas/creadores;
   un archivo con dos miembros se cuenta una vez en el resultado. Un coprotagonista
   que aparece en el mismo archivo no se incorpora como miembro de la agencia.

La ficha muestra miembros actuales y procedencia de los vínculos a archivos. El filtro
de agencia se conserva al recrear la biblioteca y se actualiza al cambiar afiliaciones.
Audio/imagen conservan ese ámbito mediante la selección común de identidades.
Los archivos no se enlazan directamente a una agencia. El selector de vínculo a archivo
no ofrece agencias; su ficha explica que sus archivos se obtienen por miembros.

El buscador de identidades encuentra agencias por nombre/alias. Para filtrar medios
por agencia se utiliza la ficha y Ver archivos. La búsqueda textual general de medios
por nombre de agencia todavía no está integrada, a diferencia del original.

## Modelo y procedencia

Room v10 añade únicamente entity_memberships. Su clave es memberId; memberId y agencyId
referencian catalog_entities con eliminación en cascada. Eliminar una persona retira
su afiliación; eliminar una agencia retira sus afiliaciones y conserva a sus miembros.
Renombrar/añadir alias conserva UUID y afiliaciones. Se rechazan agencias como miembros,
autoafiliaciones, estudios/series/etiquetas como miembros y vínculos de archivo con rol agency.

Una edición manual guarda source/origin manual, confianza 1 y fecha UTC. No afirma una
verificación online: refleja la asignación explícita realizada por el usuario. Al importar
se conservan source, confidence y checked_at del catálogo y una referencia al origen.
La confianza no se recalcula ni se convierte a 1. No hay extracción de afiliaciones
desde metadata_json, rastreo de sitios, integración de cuentas o logotipos de agencias.

Se sigue la semántica del original fijo de22796c04919aaa057d77930c33c81313765569:
migración 0025_agency_entities.sql y casos de tests/test_agency_entity.py. Las pruebas
verifican esa estructura de afiliación vigente, unión de archivos y separación del roster
frente a coprotagonistas. Android permite también una asignación explícita a creator.
No se ha ejecutado el servidor ni la suite Python original sobre una base personal.

## Importación y copias

El intercambio peach-catalog-transfer v1 añade **entity_membership** como tabla opcional,
con member_id, agency_id, source, confidence y checked_at. Los JSON anteriores que no
la incluyen siguen leyéndose como cero afiliaciones; si la declaran malformada se rechazan.
La proyección SQLite la lee si existe. Se comprueban IDs, referencias, duplicados por
miembro, números finitos entre 0 y 1 y longitudes de texto.

La vista previa muestra afiliaciones nuevas, conservadas, en conflicto o de tipo no
compatible, con su procedencia. Confirmar añade solo las nuevas con fichas compatibles.
Una afiliación existente se conserva, incluso si procede del mismo catálogo. Una agencia
distinta genera conflicto; no se sustituye silenciosamente. Las filas incompatibles se
conservan como datos de la instantánea. Solo conservar catálogo sigue sin crear el grafo.
No es sincronización ni incluye reversión de lote. Reimportar tras retirar manualmente
una relación puede añadirla otra vez si está en el origen y ya no hay otra vigente.

Las instantáneas guardadas en 0.10 no incluían esa tabla. Pueden recuperar sus agencias
como fichas revisables, pero para obtener afiliaciones del original hay que abrir una
copia/intercambio que sí las contenga. No se inventan las relaciones que faltan.

La copia personal pasa a **v7**, que incluye afiliaciones y procedencia. Se siguen
leyendo v1–v6. Las copias anteriores conservan las afiliaciones existentes; v7 reemplaza
las de las identidades entrantes, incluidas las que quedan sin afiliación, y conserva las
de personas ajenas a la copia. IDs ajenos, duplicados, tipo/ciclo o confianza inválidos
revierten toda la restauración, incluido estado personal, fichas y posiciones previas.
Se mantiene el límite global de 8 MiB. No se incluyen medios, permisos SAF o credenciales.

## Validación y límites

Migración desde v9 exportado con estado previo conservado, regresiones anteriores,
importación con DDL original de 0025 y datos sintéticos, CRUD/cascadas, unión sin
duplicados, coautorías, copias y rollback, vista previa obsoleta y controles nativos
se prueban localmente. Se compila un caso de Room/afiliaciones sobre Android real;
su ejecución sigue pendiente. PRUEBAS.md contiene los resultados del APK final.

No hay dependencias de ejecución nuevas ni permiso INTERNET. Quedan pendientes la
búsqueda textual general por agencia, logotipos/fotos de ficha, captación/rechazo de
afiliaciones online, candidatos por afirmación, historial, publicaciones y otros dominios.
El progreso del proyecto se mantiene en COMPATIBILIDAD_ORIGINAL.md.
