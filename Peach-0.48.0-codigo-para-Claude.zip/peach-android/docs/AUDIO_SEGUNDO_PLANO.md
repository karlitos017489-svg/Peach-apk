# Audio en segundo plano — Peach Local 0.18.0

Al abrir un audio de la biblioteca, Peach usa AudioActivity como pantalla y
AudioService como propietario del reproductor. Es un servicio interno Android,
no un servidor externo. No requiere computadora, Termux o un host Peach.

## Uso

- Abra un audio desde Todos, Audio, una carpeta, lista, grupo o ámbito de identidad.
- Use los controles para reproducir, pausar, buscar y cambiar de pista. Atrás vuelve
  a la biblioteca conservando la reproducción; bloquear la pantalla no solicita pausa.
- Los controles multimedia de Android permiten pausar o continuar y cambiar de pista.
  Tocar la notificación abre la sesión actual, sin seleccionar otra vez el archivo inicial.
- **Detener audio** guarda posición, vacía la cola y solicita cerrar el servicio.
  Cerrar o recrear únicamente la pantalla no libera el reproductor del servicio.

La apariencia y disponibilidad de controles en la pantalla bloqueada dependen de
Android y de los ajustes de notificaciones. El funcionamiento físico, bloqueo real,
Bluetooth, audio focus, batería y políticas de Samsung siguen pendientes de verificación.
Las pruebas locales de protocolo no certifican esos resultados de hardware.

## Cola y progreso

Se conservan los filtros, búsqueda, carpeta, lista y orden de la selección; los
ámbitos de catálogo/identidad/grupo se resuelven con los índices existentes.
La cola de esta pantalla contiene solo audios con URI content del catálogo, hasta
5.000. Si excede el límite, se pide filtrar en vez de truncar silenciosamente.
Un audio elegido explícitamente puede abrirse aunque quede fuera del filtro o
figure como ausente; el lector real comprobará si todavía hay acceso al documento.
Los demás ausentes se omiten. Las URI suministradas por controladores no se usan.

Una lista mixta conserva su organización y orden en la biblioteca. Iniciarla desde
un audio crea una cola de audios; los videos se abren desde su propio reproductor.
El recorrido iniciado desde un video mantiene su cola AV anterior y se pausa al
salir. Esta entrega no mueve video a un servicio ni convierte su audio en una
sesión musical independiente.

El servicio guarda posición/duración cada cinco segundos mientras reproduce y al
pausar, cambiar, detener o cerrar. Un paso automático a la siguiente pista marca
la anterior completada y deja posición cero. Se reutiliza la regla AV de 95 % y
el contador se incrementa una vez por visita a una pista preparada; volver a la
misma sesión o recrear la pantalla no añade aperturas. Reabrir la pista actual
pausada conserva la pausa y la posición, sin iniciarla otra vez automáticamente.
No se crea reader_progress para audio.

Room sigue en v12 y la copia JSON en v10 (lectura v1–v10), sin migración. La copia
incluye el progreso ya guardado y las listas, no audio, permisos SAF o la cola activa
del servicio. No hay arranque de reproducción al reiniciar Android o forzar cierre.
Tras la muerte del proceso, se abre el archivo desde la biblioteca y se recupera
el último checkpoint disponible; no se garantiza el último segundo si Android mata
el proceso sin callback. Las autorizaciones SAF previas se conservan al actualizar.

## Arquitectura y límites

Se añade androidx.media3:media3-session:1.8.0, alineado con ExoPlayer/UI existentes.
MediaSessionService publica la sesión/notificación y MediaController conecta la
pantalla de forma asíncrona. El reproductor ExoPlayer vive en el hilo principal del
servicio; consultas y persistencia van al ejecutor Room existente. Las selecciones
llevan una generación para que una consulta antigua o una detención no reinicie audio.
Una selección no válida no reemplaza la cola que ya estaba reproduciendo.

Se declaran FOREGROUND_SERVICE, FOREGROUND_SERVICE_MEDIA_PLAYBACK y WAKE_LOCK.
La notificación de sesión multimedia está exenta de POST_NOTIFICATIONS; no se pide
ese permiso ni permisos amplios de archivos. El wake lock local pertenece a ExoPlayer
mientras corresponde, no es un bloqueo permanente creado por Peach.

La sesión admite el UID propio y controladores que Android identifica como confiables.
Solo el UID propio puede seleccionar desde el catálogo o ejecutar Detener audio.
Los comandos para reemplazar la cola, fijar una URI o añadir una superficie de video
no se publican a los controladores. La selección privada se resuelve por IDs/ámbito
local y no abre enlaces recibidos de otra app. No se añade exploración Android Auto,
MediaLibraryService, casting, acceso a cuentas o reproducción automática tras reboot.

ExoPlayer gestiona audio focus y el evento de desconexión de auriculares. El modo
WAKE_MODE_LOCAL no añade un Wi-Fi lock. Si Android deniega iniciar el servicio en
primer plano, se solicita pausa y se comunica el error al controlador activo.
Las restricciones del sistema y de proveedores SAF pueden impedir la reproducción.
Un proveedor cloud puede necesitar Internet aunque Peach no solicite una URL remota.

Al quitar la tarea desde Recientes se conserva la política de Media3 para reproducción
activa: si ya está en primer plano y reproduce, continúa. Si está pausada o detenida,
se vacía la cola y se libera la sesión. Media3 también dispone de tiempo de inactividad
para abandonar primer plano; no se presenta como servicio inmortal o agenda de fondo.
**Detener audio** es la forma explícita de cerrar la cola, sin esperar ese plazo.

## Pruebas y fuentes

AudioSelectionTest comprueba selección/ámbitos, orden de lista, datos personales,
fuentes content, límites, filtros y rechazo de entradas. AudioProgressTest ejercita
el protocolo Player y la persistencia; AudioSessionTest usa MediaSession y un
MediaController reales sobre FakeAudioPlayer, sin afirmar decodificación por esos
casos. AudioUiTest comprueba ciclo de vida, recreación y ruta de apertura.
El WAV se sigue analizando realmente mediante el extractor Media3 en la suite previa.

AudioIntegrationTest compila un caso con WAV sintético de veinte segundos y el
servicio Android real: cerrar/reabrir pantalla, pausar y detener. Está **sin ejecutar**.
Tampoco es una prueba de pantalla bloqueada o de la interfaz de notificación real.
Se corrigió una aserción instrumentada antigua que todavía esperaba INTERNET
denegado, incompatible con las fuentes opcionales añadidas desde 0.13; sigue sin
presentarse como prueba ejecutada. PRUEBAS.md recoge los resultados finales.

Referencias primarias consultadas y código fuente 1.8.0 revisado:

- https://developer.android.com/media/media3/session/background-playback
- https://developer.android.com/media/media3/session/connect-to-media-app
- https://developer.android.com/media/media3/session/control-playback
- https://developer.android.com/develop/ui/views/notifications/notification-permission#exemptions-media-sessions
- https://dl.google.com/dl/android/maven2/androidx/media3/media3-session/1.8.0/media3-session-1.8.0-sources.jar

Media3 Session y AndroidX Media usan Apache-2.0, cuyo texto ya está empaquetado.
El grafo efectivo, hashes y permisos se guardan en evidence/0.18.0. No se incorporó
Junrar: su licencia incluye una restricción UnRAR adicional y sigue pendiente
resolver una opción para RAR/CBR compatible con la distribución de este proyecto.
No se declara incompatibilidad Android de todos los lectores RAR ni un dictamen legal.
