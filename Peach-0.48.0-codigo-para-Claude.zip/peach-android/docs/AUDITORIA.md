# Auditoría y arquitectura de Peach Local

Estado actual: 0.18.0. La comparación vigente está en COMPATIBILIDAD_ORIGINAL.md.
Las secciones de versiones anteriores conservan las decisiones y su alcance histórico.

## Lectura local: decisiones de 0.8.0

Se conservan las cinco familias del catálogo original y las identidades documentales.
La capacidad de abrir un contenido se decide aparte de su clasificación. PDF y los
textos siguen siendo other; ZIP/CBZ forman parte de archive. Las entradas no se
convierten en nuevos assets ni se les asigna el progreso temporal de audio/video.

Se reutilizan PdfRenderer/ParcelFileDescriptor de Android, ZipFile/CRC32 de Java,
CharsetDecoder y el lector de imágenes/ZoomImageView existentes. No se añaden paquetes
de ejecución, motor PDF empaquetado, intérpretes o servidores. La API de PdfRenderer
se consulta en su referencia oficial y se usa en un trabajador sobre descriptor
seekable. Las páginas se cierran una a una antes de abrir la siguiente.

Una sesión privada acota copia de origen, índice, entrada descomprimida, texto y
bitmap. La comprobación previa del final ZIP limita metadatos antes de crear ZipFile;
la biblioteca estándar interpreta y descomprime el archivo. Se rechazan ZIP64,
volúmenes, nombres duplicados o rutas no admitidas y se comprueba tamaño/CRC de la
entrada seleccionada. Los nombres internos nunca se convierten en rutas de salida.
Los archivos originales no se escriben. Un bloqueo protege cachés activas de la
limpieza de sesiones huérfanas; la sesión libera sus recursos al cerrarse.

Room v7 añade reader_progress y JSON v5 lo incorpora a la copia personal, con lectura
de versiones anteriores. El estado se actualiza tras una vista satisfactoria; un error
no reemplaza la posición válida. El filtro Con progreso admite lectura sin alterar
los milisegundos del reproductor. Las relaciones y ediciones anteriores se conservan.

Los ZIP/textos e imágenes se ejecutan con lectores reales en pruebas locales. Los
recorridos PDF usan un backend de prueba explícito y las pruebas del renderizador
Android real se compilan por separado. No se afirma ejecución real PDF ni aislamiento
adicional del proceso. Formatos, límites, recursos y evidencia están en LECTURA_LOCAL.md
y PRUEBAS.md. Referencias consultadas:
- https://developer.android.com/reference/android/graphics/pdf/PdfRenderer
- https://developer.android.com/reference/java/util/zip/ZipFile

## Identidades y deseos: decisiones de 0.7.0

Se revisaron el esquema canónico de entidades y alias del original, entities.py y
las fronteras del dominio wants.py. Se conservan sus tipos de identidad y la
distinción entre obra deseada y archivo físico; no se importa automáticamente su
normalización, fusión de entidades o reconciliación de códigos.

La adaptación usa IDs UUID y alias exactos declarados por el usuario. Los metadatos
NFO se consultan como relaciones derivadas; los vínculos manuales se guardan por
documento/identidad/función y no son sustituidos al escanear. Las referencias externas
se almacenan como proveedor/ID/URL opcional sin transportar datos a una API. La lista
de deseos admite obras sin archivo y una asociación explícita a documento/identidad.

Room v6 añade cinco tablas con cascadas o SET NULL según propiedad. JSON v4 incluye
la organización nueva y mantiene lectura de v1/v2/v3. Se validan conflictos y tipos
dentro de la transacción completa. No se añaden dependencias de ejecución, permisos
de red, componentes de escritorio ni intérpretes. El módulo usa Room, controles
Android nativos y los lectores existentes; no copia la interfaz web ni ejecuta el
backend original. Alcance y uso: IDENTIDADES_Y_DESEOS.md; evidencia: PRUEBAS.md.

Referencia: `https://github.com/peach-mitao/peach`, rama `master`, commit
`de22796c04919aaa057d77930c33c81313765569`, consultado el 24 de octubre de 2026.
El árbol original se conserva sin modificaciones. Esta adaptación tiene un repositorio Git separado.

Se leyeron todos los documentos del paquete de traspaso y el README del cliente anterior.
Se inspeccionaron sus fuentes Java, manifest y Gradle: solo conectaban un WebView con un servidor.
En upstream se revisaron AGENTS.md, README.en.md, pyproject.toml, frontend/package.json,
docs/ARCHITECTURE.md, el inventario REUSE y los módulos scan.py, library_nfo.py,
subtitles.py, platform.py, media_probe.py, browser_transport.py y downloads_clouddrive.py.
Se examinaron los consumidores del frontend y las pruebas de los dominios correspondientes.

## Decisión

Aplicación Android nativa: Java 17, Room/SQLite, Storage Access Framework (SAF),
WorkManager, Media3/ExoPlayer y RecyclerView. No incorpora WebView, intérprete Python,
servidor HTTP ni proceso externo. El manifest de la app no solicita INTERNET.
Los medios se leen a través de URI `content:` autorizadas por el usuario.

Java permite usar Room con su procesador oficial y el mismo conjunto de API Android
que Kotlin sin añadir otro compilador ni un puente de ejecución. La separación entre
persistencia, escaneo y reproducción permite añadir módulos Kotlin después si aportan
valor. Esta elección no implica que Kotlin o Compose sean incompatibles.

No se conserva el cliente remoto anterior; se reutiliza únicamente su icono, con aviso MIT.
La adaptación se distribuye bajo AGPL-3.0-or-later, con el texto de licencia original.
Las funciones se reimplementan para Android; no se presenta este trabajo como un port
íntegro del backend ni como una versión oficial de sus autores.

## Comparación de rutas

| Criterio | Python embebido + frontend | Núcleo Android elegido |
|---|---|---|
| Python 3.14 | Chaquopy 17 sí lo admite; no es por sí solo un bloqueo | No necesario |
| Dependencias exactas originales | Varias requieren nuevas compilaciones nativas o adaptadores | Bibliotecas Android oficiales con versiones fijas |
| Almacenamiento | os.scandir/Path y rutas Windows no consumen SAF directamente | URI y permisos persistentes SAF |
| Reproducción | Servidor HTTP, respuesta Range, navegador, posibles procesos FFmpeg | Media3 lee documentos y usa MediaCodec |
| Ciclo de vida | Gestionar intérprete, servidor y trabajos bajo límites Android | WorkManager y Activity nativos |
| Paridad inicial | Potencial de reutilización elevado, coste de adaptación elevado | Biblioteca local primero; integraciones se portan por dominio |
| Riesgo operativo | Runtime, ruedas C/Rust, herramientas y servicios de escritorio | Códecs del dispositivo y proveedores de documentos |

## Dependencias Python verificadas

El archivo `evidence/python-wheels.json` registra consultas de las **25 dependencias
directas exactas**, URLs y resultados. Una rueda `none-any` solo prueba portabilidad
del paquete Python; no prueba la de sus dependencias transitivas ni la de sus llamadas
al sistema. La ausencia de rueda no demuestra que una compilación cruzada sea imposible.

| Dependencias del commit | Hallazgo y sustitución |
|---|---|
| FastAPI 0.143.2, Starlette 1.8.0, Uvicorn 0.54.0 | Python puro; su servidor no es necesario para acceder a Room y reproducir documentos |
| Pydantic 2.14.1 | Paquete Python portable, pero depende de pydantic-core nativo; no basta instalar el frontend Python |
| pyahocorasick 2.3.1 | Sin rueda Android en PyPI para esta versión; búsqueda local nativa para el catálogo inicial |
| grpcio 1.84.0 | Sin rueda Android exacta en PyPI; CloudDrive2 también requiere un servicio separado |
| Pillow 12.3.0 | Sin rueda Android exacta en PyPI; BitmapFactory y MediaMetadataRetriever sustituyen imágenes y miniaturas |
| curl_cffi 0.16.3 | **Sí tiene** ruedas Android arm64 cp313/cp314; no se descarta por ausencia de soporte |
| resvg-py 0.5.0 | **Sí tiene** ruedas Android abi3 arm64/x86_64; no se necesita rasterizar SVG remotos en el núcleo offline |
| watchdog 6.0.0, zeroconf 0.151.5 | Sin rueda Android exacta en PyPI; el observador de archivos y anuncio LAN originales no sustituyen SAF |
| pystray 0.19.5 | Rueda Python pura; los backends de bandeja de Windows/macOS/X11 no son interfaz Android |
| browserexport 0.4.4 | Python puro; Android no concede leer las bases privadas de otros navegadores |
| APScheduler 3.11.3, filelock 4.2.0 | Bibliotecas portables; trabajos y transacciones pasan a WorkManager y Room |
| beautifulsoup4 4.15.0, bencode2 0.3.38, tldextract 5.4.0, torznab 0.2.1 | Python puro; adaptadores online fuera del primer núcleo local |
| itsdangerous 2.2.0, httpx 0.28.1, m3u8 6.0.0, protobuf 7.36.2, sentry-sdk 2.72.0, socksio 1.0.0 | Ruedas portables; autenticación de servidor, transportes y telemetría no se incluyen |
| Opcionales OpenCV, NumPy, OpenCC, PyInstaller, Cocoa | No forman parte de la ejecución Android inicial; cada función necesitaría evaluación aparte |

Chaquopy publica Python 3.14, pero su índice inspeccionado no ofrecía cp314 para
grpcio/Pillow; las versiones observadas llegaban a grpcio 1.67.0 y Pillow 11.0.0 cp313.
pyahocorasick, pydantic-core, watchdog y zeroconf devolvieron 404 en sus rutas consultadas.
Esto no es un inventario universal de todos los proveedores de ruedas.
No se ha ejecutado un backend completo de Peach bajo Chaquopy y no se afirma que haya pasado esa prueba.

## Acoplamientos del código original

- `scan.py` usa `os.scandir`, rutas de disco y `asset.path` en formato Windows.
  `platform.py` traduce montajes; una URI SAF no es una ruta montada. Se introduce un
  catálogo Android independiente con identidad por proveedor + document ID.
- `library_nfo.py` agrupa sidecars por directorio y limita XML a 1 MiB, rechazando
  DTD/entidades. La adaptación conserva esas medidas y usa el parser XML del sistema.
  El emparejamiento inicial se limita a mismo nombre y `movie.nfo` si hay un solo video.
- `subtitles.py` usa emparejamiento por nombre/idioma/identificador y conversión WebVTT.
  Android entrega SRT/VTT/ASS/SSA directamente a Media3. No se porta todo el motor de
  normalización por código; no se convierten subtítulos gráficos.
- `media_probe.py` ejecuta ffprobe con subprocess. Android usa MediaMetadataRetriever
  para miniaturas y Media3 para duración/pistas, sin prometer transcodificación universal.
- `browser_transport.py` arranca un navegador de escritorio mediante subprocess.
  Esa integración requiere otro diseño; no se incorpora un navegador oculto.
- `downloads_clouddrive.py` llama a CloudDrive2 por gRPC. Exigir ese servicio rompería
  el funcionamiento autónomo del núcleo local.
- React 19.3.1 y sus controladores consultan `/api/...`. Copiar los recursos a una
  WebView no proporciona la base de datos, los handlers ni el acceso SAF.

## Datos y operaciones

La versión 0.2.0 guarda tres tablas: media, roots y scan_queue. La versión 0.3.0 añade
playlists y playlist_items, y campos personales separados en media. Room exporta los
esquemas v1/v2/v3 y valida las migraciones explícitas MIGRATION_1_2 y MIGRATION_2_3.
0.4.0 añade únicamente nfoDetails (JSON de campos importados) a media sin reconstruir las tablas
anteriores ni usar fallback destructivo. Los resultados están en PRUEBAS.md.

El trabajador enumera cada carpeta una vez y guarda, en una misma transacción, medios,
subcarpetas pendientes y el checkpoint. Al pausar o interrumpirse se conserva la cola;
Continuar procesa lo pendiente. Actualizar inicia otra generación para las ubicaciones
completadas. Las filas ausentes solo se marcan no disponibles tras completar una raíz;
no se borran medios, favoritos o historial por una microSD desconectada o fallo parcial.
La lectura incremental sigue enumerando nombres para detectar cambios; no es un watcher
en tiempo real ni una sincronización por hash de contenido.

No se solicitan permisos de escritura sobre las carpetas. El acceso se limita a lectura
de los directorios elegidos. La copia JSON de estado se escribe únicamente tras una
elección explícita del usuario y no contiene videos, cookies o claves. Los identificadores
de documentos sí pueden revelar nombres/rutas; la copia debe tratarse como información privada.
Restaurar requiere volver a autorizar e indexar las mismas carpetas.

Se indexan las familias video, imagen, audio, archive y other del escáner original.
ISO, STRM y RMVB quedan en catálogo con aviso y sin reproducción. Los comprimidos
no se extraen y otros documentos no tienen visor. Los contenedores reproducibles
dependen de Media3 y los códecs del dispositivo. La matriz de diferencias vigente
está en COMPATIBILIDAD_ORIGINAL.md.

## Fuentes primarias

- https://github.com/peach-mitao/peach/tree/de22796c04919aaa057d77930c33c81313765569
- https://chaquo.com/chaquopy/doc/current/versions.html
- https://chaquo.com/chaquopy/doc/current/changelog.html
- https://chaquo.com/pypi-13.1/
- https://developer.android.com/training/data-storage/shared/documents-files
- https://developer.android.com/media/media3/exoplayer/hello-world
- https://developer.android.com/jetpack/androidx/releases/media3
- https://developer.android.com/training/data-storage/room
- https://developer.android.com/topic/libraries/architecture/workmanager

Las APIs de Android restringen seleccionar ciertas raíces y carpetas de Android/data,
Android/obb y Descargas. Usar una subcarpeta de Videos/Películas y una carpeta de la
microSD expuesta por el selector; la selección de un proveedor cloud no garantiza
disponibilidad offline. La prueba física de ABI, códecs y microSD de SM-X230 sigue
siendo una validación separada.

## Ampliación 0.4.0

Se volvió a inspeccionar src/peach/library_nfo.py del mismo commit original. Se mantienen
los tres tipos NFO, el límite de 1 MiB, el rechazo de DTD/entidades y el trabajo offline.
Se amplían campos importados y compatibilidad de nombres localtitle/name, outline y
releasedate/aired. La identidad de catálogo sigue siendo la URI documental; un código
NFO no fusiona videos ni traslada su progreso. No se porta aún el emparejamiento avanzado
por código, el grafo de entidades ni la agrupación de versiones del original. No se
añadieron dependencias de ejecución. Los campos y límites exactos están en NFO.md.

Fuentes de formato y migraciones consultadas el 24 de octubre de 2026:
- https://kodi.wiki/view/NFO_files/Movies
- https://developer.android.com/training/data-storage/room/migrating-db-versions

## Ampliación 0.6.0: contenido y organización

Se restauró el código completo de la entrega 0.5.0 desde su ZIP y git bundle, con
comprobación SHA-256, en un repositorio separado. Un árbol local parcial anterior
se conservó aparte. Se releyeron scan.py, el esquema canónico de entidades,
catalog_versions.py y las fronteras de arquitectura/reutilización del original fijo.
La matriz COMPATIBILIDAD_ORIGINAL.md identifica las fuentes y diferencias concretas.

Se reutilizan Room, claves externas, LiveData, los lectores NFO, Media3 y los controles
nativos existentes. No se añaden dependencias de ejecución, servidor, intérprete ni
procesos externos. Room v5 crea media_groups y media_group_items; las migraciones
anteriores se encadenan. Las listas de nombres NFO quedan en nfoDetails._catalog sin
mezclarse con preferencias o identidades de documentos. El explorador es una proyección
exacta de metadatos; no pretende implementar el grafo canónico del original.

Los grupos manuales se distinguen de playlists y no cambian progreso ni datos importados.
Las copias v3 incluyen grupos y conservan lectura v1/v2; cualquier grupo malformado
revierte toda la restauración. Se registra archive y other, además de video/image/audio,
sin abrir referencias STRM, montar ISO, ejecutar documentos ni extraer comprimidos.
Las colas AV excluyen esas filas. Cada límite se muestra en su ficha.

## Catálogo mixto en 0.5.0

Room v4 añade mediaType con valor predeterminado video mediante MIGRATION_3_4.
Se mantiene la identidad por documento y las migraciones anteriores; no hay
fallback destructivo. El escáner incorpora audio/imágenes y separa las portadas
usadas. El visor usa BitmapFactory, ExifInterface y Matrix de Android; las pruebas
añaden gráficos nativos Robolectric sin incorporar esas bibliotecas al APK.
No se añaden dependencias de ejecución. El audio comparte Media3 y el progreso
existentes; sigue siendo de primer plano. No se incorpora un servicio externo.
El detalle de formatos, funcionamiento y límites está en IMAGENES_Y_AUDIO.md.

## Ampliación 0.9.0: puente de catálogo

Se releyeron las migraciones 0000/0001/0002/0017/0023/0025/0030/0032 del mismo commit.
0025 incorpora agency, aún no modelado como ficha local; se conserva su registro sin
convertirlo de tipo. La aplicación usa SQLiteDatabase OPEN_READONLY sobre copia privada,
listas explícitas de tablas/columnas, validación de integridad y límites. Rechaza WAL
para no interpretar un archivo principal incompleto como una copia autónoma. Se utiliza
JSON propio de intercambio y no se carga Python, SQL del archivo ni el servidor original.
Se mantienen todas las dependencias de ejecución fijadas; no hay adiciones. Room v8
crea catalog_snapshots; copia v6 conserva instantáneas con correspondencias.
Las pruebas incluyen SQL original sin modificar y datos sintéticos. No se ha recibido
un ledger personal ni se ha ejecutado la integración en un Android completo.
Referencia de API: https://developer.android.com/reference/android/database/sqlite/SQLiteDatabase

## Ampliación 0.10.0: consulta del catálogo

Se reutilizan la proyección SQLite/JSON y las instantáneas revisadas de 0.9.0, los
campos originales de asset y las relaciones de asset_entity. No cambian dependencias
de ejecución. Room v9 añade media.catalogMetadata como capa de consulta derivada,
con origen/asset/ruta y campos/términos; se reconstruye desde instantáneas en migración,
restauración y cierre de escaneo. La copia sigue siendo v6 y no duplica el índice.
El escáner existente incorpora su carpeta base en folder: el importador descuenta
la base documental conocida del checkpoint raíz para comparar rutas relativas.
Las pruebas nuevas usan el DocumentsProvider y DocumentScanner para ese contrato.
La consulta cacheada es acotada y avisa si es parcial; no altera NFO ni archivos.
Referencia de migraciones: https://developer.android.com/training/data-storage/room/migrating-db-versions

## Ampliación 0.11.0: agencias

Se releyó 0025_agency_entities.sql y tests/test_agency_entity.py del commit original
fijo. El original conserva una membresía vigente por miembro y obtiene los archivos
de la agencia mediante sus miembros. Android conserva esa separación, con relación
explícita a personas/creadores y sin asset_entity de agencia. La migración Room 9→10
solo crea entity_memberships; copia v7 añade las afiliaciones, con lectura v1–v6.
Se amplía el intercambio v1 con tabla opcional y revisión sin sobrescribir afiliaciones.
No se añaden dependencias de ejecución/red. DDL original de 0025 se conserva sin
cambios para las pruebas, con hash y atribución. No se ejecutó el servidor original
ni se recibió un ledger personal. AGENCIAS.md contiene alcance y diferencias.

## Publicaciones y seguimiento: decisiones 0.12.0

Se inspeccionan wants.py, follow_store.py y migraciones 0018/0042 del commit fijo.
Se conservan publicación, deseo y documento como modelos distintos. Publicaciones
se guardan en Room; no hay API/red ni nuevo paquete de ejecución. El estado de
adquisición se distingue de la disponibilidad física local. Las fechas aproximadas
no se presentan como exactas. Los contadores conservan la ventana de 90 días y tres
búsquedas antiguas sin resultado, registradas explícitamente por el usuario.

A diferencia de la reconciliación automática del original, una comparación conservadora
de códigos declarados genera revisión previa y lote reversible. Se omiten resultados
ambiguos y documentos ausentes. Aplicar recalcula la revisión en una transacción.
La proyección de solo lectura amplía su lista de tablas/campos; metadata_json, medios
remotos y credenciales siguen excluidos. Instantáneas antiguas no inventan tablas.
Room v11 añade publicaciones y columnas de seguimiento; copia v8 conserva lectura
v1–v7. Evidencia y límites en PUBLICACIONES_Y_SEGUIMIENTO.md y PRUEBAS.md.

## Primera fuente directa: decisiones 0.13.0

Se revisó el registro real follow_providers.py y el conector FANBOX en follow_sources.py
y fanbox.py. Se elige el canal oficial público porque el contrato de lista, cursores,
detalle y un adjunto respondió sin cuenta en la comprobación del entorno. No se
incorpora el registro entero como si todos los adaptadores estuvieran implementados.

HttpsURLConnection nativo con HTTPS/hosts acotados, límites y cancelación; JSON del
sistema, Room y controles nativos. Sin paquetes de ejecución nuevos ni WebView.
INTERNET se añade para acciones explícitas, sin alterar la utilidad offline del núcleo.
La verificación JDK de la misma frontera no sustituye la pila TLS/SAF del Android real.

Se separan la página pendiente, ficha personal y cuerpo remoto guardado. La revisión
conserva estados/notas/vínculos y no deja que un resumen nuevo borre cuerpo detallado.
Descargar requiere destino elegido, pasa por un temporal privado acotado y no crea
assets falsos. Room v12 añade dos tablas sin recrear dominios anteriores; copia v9.
La limpieza de temporales conserva las descargas activas. FUENTES_FANBOX.md y
PRUEBAS.md identifican límites, riesgos de interrupción SAF y evidencia real.

## Segundo proveedor público: decisiones 0.14.0

Se revisó PatreonConnector del original, que analiza las tarjetas del HTML público,
y la documentación oficial que requiere autorización de creador para la API de posts.
Se implementa ese dominio acotado sin cuenta/cookies, APIs privadas, API v1 o WebView.
HTML se recibe por el transporte propio y jsoup1.23.2/MIT solo lo analiza en memoria.
Se elige la versión publicada actual consultada y se incorpora su licencia. No se usa
el cliente de red de jsoup.

La prueba viva detectó tarjetas públicas transmitidas en div hidden con id S:...,
que el sitio inserta con scripts. El parser reconoce solo esos fragmentos HTML de
tarjeta, excluye nodos ocultos ordinarios/scripts/bootstrap y no ejecuta JavaScript.
Las fechas no declaradas quedan desconocidas, los adelantos parciales y sin adjuntos.
No se supone que una tarjeta permita obtener el cuerpo completo.

Se generalizan proveedor y página normalizada sin cambiar los UUID FANBOX. No hace
falta migración Room: las tablas v12 ya guardan provider/ref. Copia v10 distingue el
alcance ampliado, conserva lectura de v1–v9 y mantiene validación/rollback.
El host de desarrollo introdujo un temporal .rsync-tmp en el directorio D8; aislar
intermedios y registros fuera del workspace con un init script resolvió el build.
Esa configuración opcional no cambia la aplicación.


## Lectura TAR/GZIP: decisiones0.15.0

Se conserva ZIP y se generaliza su índice/lectura en ArchiveBook, sin modificar
Room v12 o copia v10. Commons Compress 1.28.0 interpreta TAR, con preflight propio
que acota cabeceras/metadatos antes de construir su índice. PAX/GNU se admiten
parcialmente; sparse y overrides PAX de tamaño se rechazan. Solo flags de archivo
regular0/NUL permiten lectura: isFile de Commons también acepta entradas especiales.
Enlaces/otros tipos permanecen como filas sin lector. Rutas nunca eligen destinos.
GZIPInputStream expande una copia privada y comprueba su trailer antes de publicar;
TAR.GZ conserva esa copia para acceso por posición. LECTURA_TAR_GZIP.md registra
límites y coste temporal/espacio. Se conservaron licencias/NOTICE exactos como assets,
porque el paquete omite nombres META-INF genéricos. No se añaden codecs opcionales.

El usuario comunicó rechazo en Patreon/panpiano y CAPTCHA en Chrome con0.14. No se
capturó el código preciso401/403 o proveedor del CAPTCHA de la petición Android.
El mismo conector respondió en JDK; no prueba acceso desde Android. No se considera
Patreon operativo en ese entorno, ni se implementa transferencia de sesión de Chrome,
resolución de CAPTCHA o un navegador integrado. El rechazo ahora muestra su código.
Se continúa con otras funciones a petición del usuario; se conserva la incidencia.


## Lectura 7z y validación del usuario 0.16.0

Se reutiliza ArchiveBook/ReaderSession y se añade XZ for Java 1.12/0BSD para LZMA y
LZMA2 de Commons Compress 1.28.0. El constructor de Commons limita una estimación
del índice y algunos decodificadores; su salida de cabecera comprimida necesitaba
un límite adicional antes de reservar memoria. Se validan firma/CRC/offsets y hasta
4 MiB de cabecera cruda/expandida mediante preflight propio. Cabecera codificada
limitada a un flujo/carpeta/codec COPY/LZMA/LZMA2; formas complejas se rechazan.
El método correcto de la versión inspeccionada es setMaxMemoryLimitKiB: el método
deprecado setMaxMemoryLimitKb divide por1024. Se fijan64 MiB, se acota tamaño declarado
acumulado y se usan canales de solo lectura con interrupción/plazo/presupuesto.
No se extraen rutas; enlaces/reparse/anti-items quedan sin lector. Empty entries
usan un flujo vacío explícito, evitando estado de un decodificador previo.
Cada selección reabre el índice/decodificador para aislar errores; los sólidos pueden
requerir descomprimir entradas precedentes. LECTURA_7Z.md registra costes y límites.

El usuario aceptó generalmente0.15 y reportó resultados de Patreon al apagar su VPN.
La relación causal exacta con la política del servidor no fue capturada. El bloqueo
previo ya no se reproduce en ese uso; no se hizo un cambio de CAPTCHA en el software.
Se corrigió además un espacio introducido por formato en el commit de referencia de
algunos documentos: de22796c04919aaa057d77930c33c81313765569. Los hashes de código
original y el commit realmente inspeccionado no cambiaron.

## EPUB: decisiones de 0.17.0

Se reutilizan ZipBook/ArchiveFiles para CRC y caché fija, XML Android para OCF/OPF
y jsoup existente para obtener texto local de XHTML, sin red o ejecución HTML.
El spine define el orden; las imágenes se seleccionan aparte. La integración usa
ReaderSession, controles nativos y reader_progress existente, sin migración.
Se eligió un subconjunto de texto para mantener autonomía sin empaquetar un
motor web; maquetación EPUB completa continúa pendiente. No se añaden dependencias.
DTD/entidades se rechazan antes de analizar metadatos, incluso UTF-16; recursos
externos, xml:base y cualquier encryption.xml se rechazan según el caso. Límites
y rechazos conservadores, incluida ofuscación de fuentes, en LECTURA_EPUB.md.
El parser no valida conformidad EPUB y la suite propia no es una certificación.

## Audio en segundo plano 0.18.0

Media3 Session 1.8.0 conserva la versión del núcleo existente, con transitive AndroidX
Media 1.7.0/Apache-2.0. Se revisó el código de conexión, permisos y política de servicio
de la versión resuelta. La sesión publica comandos de transporte, pero no sustitución
de URI/cola o superficie de video; el UID propio selecciona IDs resueltos desde Room.
AudioProgress es el único dueño de checkpoint/contador de esa sesión. La consulta
serializada lleva generación y no reanuda tras Detener o una selección posterior.
Sin migración, servidor externo, boot receiver, MediaLibraryService o casteo.
El servicio usa wake mode local y notificación multimedia exenta de permiso POST.
La validación de controladores/UI con Player determinista no afirma decodificación
ni ciclo de vida físico; queda un caso instrumentado compilado con WAV propio.
Los límites y referencias están en AUDIO_SEGUNDO_PLANO.md. RAR/CBR sigue pendiente;
Junrar no se integró debido a la restricción adicional UnRAR aún por resolver para
esta distribución AGPL, sin emitir un dictamen de compatibilidad universal.


## Revisión de versiones y partes 0.19.0

Se volvió a leer catalog_versions.py y las funciones pertinentes de catalog_rules.py
al commit fijo de22796c04919aaa057d77930c33c81313765569, sin ejecutar el servidor.
El SHA-256 de catalog_versions coincide con la auditoría inicial. El original separa
edición, resolución, procesamiento, duración, identidad de código y conjuntos de partes.
Android incorpora una revisión nativa más acotada: indicios de sufijos, carpeta exacta,
conflictos NFO explícitos y guardado ordinario después de selección. No se declara
paridad con el particionado/plegado automático del original. No hay dependencias,
permisos, JNI o cambios de esquema/copia nuevos. Ver VERSIONES_Y_PARTES.md y la
evidencia original-version-audit.json. RAR/CBR y los demás dominios siguen pendientes.


## Historial 0.20.0

Se leyó web_activity.py al commit fijo del original, sin ejecutar el servidor. Sus
agregados play_seconds/max_reached/leave_ratio/seek_count y preferencias no se anuncian
como implementados. Android añade una cronología de visitas propia, desde aperturas
válidas y checkpoints; no convierte posición en tiempo visto. Room12→13 crea una tabla
con FK CASCADE e índices; copia11 importa1–11 y conserva historial con copias antiguas.
Retención10.000, páginas100, consulta IO/lectura transaccional, snapshot de título y
último estado, no presencia en vivo. No se agregan dependencias o permisos. Los tokens
se reservan antes de cargas asíncronas, se conservan al recrear en el mismo proceso y
no reinsertan registros borrados en checkpoints. Ver HISTORIAL_USO.md y evidencia.
