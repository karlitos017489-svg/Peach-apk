# Calidad, variantes y vistas previas — 0.35.0

La app reproduce un archivo ofrecido por la fuente. Una vista previa o archivo pequeño
no se transforma en un original HD por cambiar el ajuste del reproductor. Esta entrega
ayuda a distinguirlos y elegir entre variantes reconocidas, conservando la opción manual.

## Uso

Publicación importada → Ver videos. La lista indica Vista previa, Versión de descarga,
Archivo publicado o Variante, con altura/tamaño declarados cuando existen. Los valores
declarados proceden del sitio o nombre de variante; no son una medición del códec. Una
variante sin esos datos muestra calidad no declarada. El reproductor añade dimensiones
cuando Media3 las comunica, junto con estado de carga e indicador de buffering.

Se preselecciona la mayor altura reconocida en p del primer grupo de videos sin una
vista previa conocida. Empates usan bytes declarados; mayor tamaño por sí solo no prueba
calidad. No cambia automáticamente a otro archivo independiente del mismo post. Puedes
elegir una variante menor para reducir datos. La selección manual se conserva al rotar.
No hay transcodificación, reescalado o calidad adaptativa como YouTube.

**Consultar versiones** está disponible para publicaciones compatibles Rule34Video,
cum.st y Paheal. Hace una consulta explícita al detalle/API de esa publicación, incluso
si ya no está en la página pendiente de la fuente. No descarga los videos. Revisa lo
encontrado y pulsa **Usar versiones** para actualizar ese cuerpo y sus adjuntos. Conservar
actuales, cancelar, salir, fallo o una revisión obsoleta conservan el cuerpo anterior.
La ficha personal, notas, vínculos y archivos guardados no se sustituyen.

Sin conexión bloquea la consulta. Se respetan pausa/espera de una fuente vinculada y
429 persiste esa espera. La revisión no se aplica si cambió publicación/cuerpo, no hay
videos compatibles o solo se recibieron previews frente a versiones no preview actuales.
Solo Usar versiones escribe; abrir la pantalla, seleccionar o consultar no importa.

## Alcance por fuente

- Rule34Video: el data-preview del listado se identifica como vista previa, también en
  publicaciones antiguas por procedencia/nombre. Los enlaces MP4/WebM de descarga del
  detalle conservan calidades reconocidas y orden; la selección inicial prefiere la mayor
  altura declarada. Un contentUrl sin calidad no se certifica como original completo.
- cum.st: conserva alternativas de video compatibles del mismo adjunto en lugar de una
  única variante elegida por tamaño. Prefiere videos frente a un póster/miniatura mayor,
  deja previews conocidas aparte y omite archivos/variantes marcados locked. No convierte
  un manifiesto HLS en video progresivo. Nombres, bytes y rutas usan el contrato existente;
  no supone dimensiones nuevas de una API cuyo esquema completo sigue sin recuperarse.
- Paheal: Consultar versiones recupera el medio principal mediante su detalle admitido;
  no inventa calidades que no estén publicadas.
- Rule34.xxx: mantiene file_url de la API; sample_url/preview_url no lo sustituyen. Si
  la API declara altura numérica se muestra. No incorpora otro endpoint, credencial o
  consulta individual nueva. Si solo existe un archivo pequeño, no ofrece un HD ficticio.

La clasificación de preview por nombre es un indicio y no analiza la duración para
decidir si un clip es completo. Un clip corto puede ser el contenido entero y un sitio
puede publicar únicamente una muestra. El usuario puede abrir una preview explícitamente.
Las variantes/imágenes/archivos de otras fuentes mantienen los recorridos anteriores.

Se conserva el máximo existente de100 adjuntos por cuerpo. cum.st reserva primero una
variante principal por cada adjunto original y usa el espacio restante para alternativas
de video. Si no caben todas, lo indica; no elimina la principal de otro adjunto para
añadir más calidades al primero. Imágenes/otros archivos conservan una variante principal.
No se omiten silenciosamente publicaciones enteras por introducir alternativas opcionales.

## Demoras y entrega de datos

La sesión Rule34Video puede reutilizar en RAM su destino de entrega ya validado para
los siguientes rangos. Revalida HTTPS/DNS público en cada apertura y conserva ETag,
tamaño y huella de representación. Reduce el recorrido controlado origen→CDN→origen→CDN
a origen→CDN→CDN. No significa una mejora medida en milisegundos del CDN real.

La URL de entrega permanece solo en esa sesión y se borra al cerrarla; no entra en Room,
copias JSON, archivo de caché o Intent. No se autoriza como URL inicial de otra fuente.
Si responde403/404/410 se permite un único regreso al origen ya admitido para renovar
la entrega. Cambios de representación/destino siguen fallando sin mezclar bytes.429 no
usa ese regreso para evitar una espera. Otros proveedores/API conservan su política.

La red, el índice del contenedor, códec, bitrate y servidor pueden seguir causando
demoras. El búfer anterior no se reduce para simular un inicio más rápido. Continúa
en32MiB objetivo/5–15s, máximo16GiB de recurso online, sin copia de video en disco;
las descargas completas conservan límites y comprobaciones anteriores.

## Conservación y validación

Room13 y JSON17, lee1–17, permanecen iguales. Los nuevos campos de variante son opcionales
dentro del JSON de adjuntos y sobreviven al roundtrip; lectores anteriores pueden
ignorarlos. No hay nueva actividad/proveedor/permiso/dependencia, cuentas, hosts o inserción
de fichas/historial ficticios. La búsqueda de versiones y la reproducción son acciones
separadas. No se consulta/importa en segundo plano.

PRUEBAS.md documenta pruebas con HTML/JSON/MP4 propios y HTTPS/DNS simulados, no descarga
de los videos del usuario o disponibilidad real de cada fuente. La aceptación de0.34
no es prueba física de0.35. Gofile y demás paridad original siguen pendientes.
