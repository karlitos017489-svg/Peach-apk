# Cola de descargas — 0.32.0

La cola funciona dentro de la aplicación Android. No requiere un servidor Peach,
Windows o Termux. Añade adjuntos de publicaciones ya importadas y conserva sus
fragmentos comprobados al pausar o cerrar normalmente la app. Abrir la cola o
restaurar el proceso no inicia solicitudes: hay que pulsar **Continuar cola**.

## Uso

1. Importa una publicación y abre su detalle en Fuentes. Pulsa **Cola de descargas**.
2. Pulsa **Añadir adjuntos** y selecciona los compatibles; **Todos** marca el lote.
3. Pulsa **Continuar cola**. Cada fila muestra bytes y porcentaje cuando la fuente
   declara el tamaño. Sin tamaño conocido muestra bytes, sin porcentaje inventado.
4. Puedes pausar una fila o toda la cola. Al salir de esta pantalla también se pausa.
   Al volver, pulsa **Continuar cola**. Girar la tablet conserva el mismo trabajo.
5. Los videos e imágenes completos se abren desde su fila con el reproductor o visor
   nativos. Los otros archivos se guardan en una carpeta y se abren desde Biblioteca.
6. Para conservar originales fuera del almacenamiento privado, pulsa **Elegir carpeta**
   una vez y después **Guardar completas**. Copia los archivos ya comprobados sin
   descargarlos otra vez. Elige una subcarpeta, por ejemplo Peach, que Android permita.

La cola también se abre desde el menú de Biblioteca. Esa entrada permite administrar
lo añadido; para añadir otro lote vuelve al detalle de su publicación importada.
Preparar un reintento no inicia la red: confirma después con **Continuar cola**.
Un error de una fila no impide procesar las siguientes. HTTP429 conserva una espera
solicitada por la fuente; Continuar no la elimina.

## Límites y conservación

- Hasta128 trabajos, una transferencia activa,2GiB por archivo y4GiB de copias privadas
  de la cola. Hay además reserva de64MiB de espacio libre. No se trata de una cuota
  global que incluya cachés, Biblioteca y originales exportados.
- Mantén la pantalla de cola abierta para descargar. Esta entrega no garantiza
  descargas en segundo plano, con la pantalla apagada o después de detener la app.
- Los datos operativos están en noBackupFilesDir, separados de Room13 y copia JSON17.
  Se conservan tras cierres y actualizaciones normales; borrar datos o desinstalar los
  elimina. No se exportan ni se restauran con la copia personal del catálogo.
- No retira trabajos automáticamente. Retirar una fila elimina su copia privada y
  libera espacio; los archivos ya guardados en la carpeta elegida permanecen.
- Guardar adjunto, galería y preparación individual de video anteriores se conservan;
  usan sus flujos y cachés propios. No se unifican automáticamente con esta cola.
- Abrir directamente desde la cola no inventa fichas o visitas del catálogo. Añade o
  actualiza la carpeta en Biblioteca para usar su organización y progreso persistentes.

## Reanudación comprobada

La cola guarda el estado en AtomicFile y usa nombres privados derivados solo de un
UUID. El manifiesto conserva ID de publicación, clave hash del adjunto, bytes, estado,
ETag fuerte y hash del destino final, sin persistir la URL resuelta del CDN. Antes de
descargar vuelve a resolver el adjunto en Room y a comprobar el contrato del proveedor.
Si la publicación o el adjunto ya no existe, falla esa fila sin consultar otro enlace.

Antes de continuar valida SHA-256 del prefijo guardado y trunca bytes posteriores que
no estuvieran confirmados. Usa Range/If-Range con ETag fuerte y el mismo destino final;
Pawchive puede usar su SHA esperado inmutable. Una respuesta206 exige Content-Range,
offset, tamaño y representación compatibles. Un200 sustituye el fragmento desde cero;
206 incompatible o416 reinicia una vez. Sin validador suficiente reinicia. No promete
continuar en todos los servidores ni conserva un archivo corrupto como si fuera válido.

Se sincroniza archivo antes del punto de control cada4MiB cuando el proveedor SHA del
sistema admite clonar el digest. Si no, omite esos puntos periódicos y guarda al pausar,
fallar o completar. Tras un cierre abrupto puede perderse progreso posterior al último
punto durable. Un archivo completo pasa tamaño/SHA, cabecera si corresponde y SHA
esperado Pawchive antes de promoverse. Reconocer un contenedor no garantiza todo códec.

HTTP usa las mismas rutas iniciales y políticas de redirección anteriores, con HTTPS
y comprobaciones DNS de entrega existentes. No incorpora cuentas, nuevos servidores,
cookies, evasión de CAPTCHA o resolución de referencias externas.

## Guardado y apertura

Guardar completas solicita una carpeta SAF y crea un documento nuevo por archivo,
con sufijo UUID para distinguirlo. Lleva un registro del documento recién creado;
si la copia falla intenta retirar solamente ese documento. Compara longitud cuando
el proveedor la expone. Si Android revoca el acceso o el proveedor no permite borrar,
puede requerir elegir de nuevo la carpeta o limpiar el incompleto manualmente.
Tras un cierre durante el guardado intenta limpiar el destino pendiente antes de otro
lote. No garantiza recuperación ante cualquier fallo del proveedor o corte de energía.

La apertura usa un ContentProvider privado, no exportado y sin permisos URI cedidos.
Acepta únicamente UUID de trabajos completos y modo lectura. Mientras el reproductor
o visor mantiene un descriptor abierto se bloquea retirar esa copia; al cerrarse el
descriptor se libera. El Intent interno no lleva una URL remota o ruta arbitraria.
No se añade servicio, permiso ni dependencia. El audio en segundo plano existente no
se utiliza como un servicio de descargas.

Los resultados reales y límites de validación figuran en PRUEBAS.md y
evidence/0.32.0. Se usan medios propios y HTTP simulado; no acreditan disponibilidad
actual de cada fuente o reproducción física de cada códec en la SM-X230.
