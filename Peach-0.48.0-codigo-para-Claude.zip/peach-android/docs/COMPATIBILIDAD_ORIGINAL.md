# Actualización 0.48.0: interfaz y navegación

El núcleo parte de 0.47, aceptada por el usuario. 0.48 reúne consulta y publicaciones en Fuentes, añade vistas previas admitidas, reorganiza Ajustes y renueva tarjetas/reproductor. Conserva los límites de las fuentes y formatos descritos debajo. No constituye paridad universal. 1170 JVM aprobadas; Android75aprobadas/1omitida, más repetición visual3/3. La prueba en la SM-X230 y la aceptación de 0.48 están pendientes. [Alcance](REDISENO_048.md) · [Informe](INFORME_048.md).

# Cobertura del contenido y las funciones de Peach original

Referencia fija: peach-mitao/peach, commit de22796c04919aaa057d77930c33c81313765569.
Revisión del29 de octubre de2026. Implementación Android: 0.47.0.
0.40 aceptada. RAR5 sólido acotado en0.41; nombres Unicode heredados RAR4 en0.40; descompresión RAR4/RAR5 compatible con libarchive3.8.10 en servicio
Android aislado no exportado; lector de almacenados conservado, CRC, recursos acotados.
No se afirma soporte universal/RAR4 sólidos/contraseñas/volúmenes/RAR7 comprimido, ejecución universal en todas las ABI. En 0.47 sí se ejecutó instrumentación
Android API28/x86_64; las otras ABI solo se compilaron. Ver LECTURA_RAR_COMPRIMIDA.md.
Entrega agrupada en seis partes: parte1/0.42 aceptada; parte2/0.43 aceptada; parte3/0.44 aceptada; partes 4/0.45 y 5/0.46 aceptadas; parte 6/0.47 para prueba, con límites en PARTE_6_VALIDACION.md.

El objetivo acordado es incorporar y gestionar la biblioteca y las capacidades del
original que sean compatibles con Android en un APK autónomo. El contenido lo aporta
el usuario mediante carpetas o futuras importaciones/conexiones autorizadas. El
repositorio original no contiene una biblioteca de medios que se pueda empaquetar.

Esta matriz separa registro de un archivo, lectura de su contenido y funciones de
organización. Catalogar una extensión no prueba su decodificación. No se considera
terminado el proyecto por tener un reproductor, una galería o un APK compilado.

## Referencias inspeccionadas

- `src/peach/scan.py`: familias VIDEO, IMAGE, AUDIO, ARCHIVE, other; sidecars y escaneo.
- `migrations/0002_canonical_entities.sql`: entity, entity_alias, entity_external_ref,
  asset_entity; performer, studio, tag, creator, series.
- `src/peach/catalog_versions.py`: edición, resolución, procesamiento, duración y
  evidencia del nombre; versiones y conjuntos de partes derivados por consulta.
- `src/peach/library_nfo.py`, `subtitles.py`, `media_probe.py`: metadatos, sidecars,
  subtítulos y herramientas de medios.
- `docs/ARCHITECTURE.md`, `docs/REUSE.md`, README y los puntos de entrada web_catalog,
  web_entity, web_follow, web_feeds, web_activity, web_playlists, web_folders,
  web_organize, wants y los adaptadores downloads_clouddrive/downloads_pikpak.

No se ha ejecutado el servidor original ni se ha importado un ledger personal del usuario.
0.9 proyecta catálogos SQLite/JSON en pruebas con datos sintéticos y SQL del original;
IMPORTACION_CATALOGO.md documenta exactamente sus tablas, campos y restricciones.
Las rutas citadas pertenecen a esa revisión fija, no a una afirmación sobre futuras
versiones del repositorio.

## Familias de archivos

| Familia original | Extensiones originales | Android 0.44.0 | Límite |
|---|---|---|---|
| Video habitual | mp4, m4v, mkv, avi, wmv, mov, ts, flv, mpg, m2ts | Catálogo, NFO, subtítulos, reproducción Media3 | Códec/contenedor del dispositivo; extensión no garantiza reproducción |
| Video de formato especial | rmvb | Catálogo y organización | Reproducción pendiente |
| Referencia de video | strm | Catálogo y organización | No lee/ejecuta el enlace; falta transporte Android probado |
| Imagen de disco | iso | Catálogo y organización | No monta ni reproduce el disco |
| Imagen | jpg, jpeg, png, gif, bmp, webp | Catálogo y visor nativo | Vista fija hasta2048px; animación GIF/WebP hasta1024px en Android28+, fotograma fijo en26/27 |
| Audio | mp3, flac, wav, m4a, ogg, opus | Catálogo y reproducción Media3; sesión de audio en segundo plano desde 0.18 | Validación nativa/controles/batería en dispositivo pendiente; metadatos musicales completos, resumption tras reboot y casting pendientes |
| Archivo comprimido ZIP | zip | Catálogo, organización e índice interno; álbum de imágenes y lectura de PDF/texto seleccionados en 0.8 | 512 MiB de origen, 64 MiB por entrada, 10.000 entradas; sin ZIP64/cifrado/volúmenes/AV o comprimidos anidados |
| TAR / TAR.GZ / GZIP | tar, gz; Android añade tgz | Índice, álbum de imágenes y lectura de PDF/texto compatibles en 0.15 | Límites de 512 MiB de origen/TAR expandido,64 MiB por entrada,10.000 cabeceras; sin sparse, overrides PAX de tamaño, reproducción AV interna o anidados |
| Archivo 7z | 7z | Índice, imágenes y PDF/texto seleccionados en 0.16 | Java LZMA/LZMA2, memoria de decodificador 64 MiB, cabeceras 4 MiB y total declarado 512 MiB; sin contraseñas, volúmenes, SFX, anidados o extracción general |
| RAR / CBR | rar; cbr añadido en Android | Índice, búsqueda, imágenes y PDF/texto seleccionados; almacenar y compresión compatible desde0.39, nombres Unicode heredados RAR4 en0.40 | Fuente512MiB/entrada64MiB; RAR5 sólido hasta128MiB declarados/diccionario16MiB en0.41; sin RAR4 sólido, volúmenes, contraseñas, ANSI ambiguo o RAR7 comprimido; ver LECTURA_RAR_SOLIDO.md |
| EPUB | other; no familia independiente | Texto nativo EPUB2/3, capítulos por spine e imágenes separadas desde 0.17 | Sin CSS/DRM, fuentes ofuscadas, inline, NCX/nav o EPUB anidado; subconjunto limitado, no certificación EPUB |
| Otros archivos | other en el escáner original | Catálogo general y lector PDF/texto compatible en 0.8 | PDF nativo pendiente de ejecución de sus pruebas Android; sin edición/formularios/búsqueda PDF; otros visores aún pendientes |
| Sidecars | NFO, carátulas, subtítulos | NFO y subtítulos leídos; portadas usadas asociadas | Se omiten NFO/TBN y subtítulos como filas independientes; no equivalencia total de reglas de artwork |

Android añade webm, mpeg, 3gp; heic/heif; aac, amr y otras extensiones de audio.
También clasifica CBZ como ZIP legible y CBR como RAR parcialmente legible (almacenar y compresión compatible; nombres Unicode RAR4 en0.40).
HEIF/HEIC y los códecs siguen dependiendo del sistema. Cada archivo comprimido se
cuenta una vez; no se cuenta cada archivo dentro del paquete. Actualizar incorpora
las familias nuevas sin volver a crear los identificadores de los medios existentes.
El inventario se limita a las carpetas que se autoricen mediante SAF.

## Estructura y organización

| Dominio original | Estado Android | Trabajo restante |
|---|---|---|
| asset / ubicaciones / carpetas | Catálogo Room y URI SAF, varias raíces, ausencia temporal conservada | 0.9 añade mapeo explícito de rutas de catálogos SQLite/JSON a raíces SAF escaneadas; faltan sincronización completa y traducciones de otros dominios |
| NFO, títulos, reparto, estudio, fechas y códigos | Importación local ampliada, búsqueda, ficha, ediciones separadas | Emparejamiento avanzado, conservación completa de campos no modelados y escritura NFO |
| Personas, estudios, artistas, series, colecciones, etiquetas | Exploración exacta; fichas tipadas con UUID, nombre, notas, favorito, alias, referencias y relaciones en 0.7 | 0.9 importa fichas/alias/referencias/relaciones compatibles con vista previa y rechazo de conflictos; historial de afirmaciones y candidatos aún pendiente |
| creator y cuentas seguidas | Fichas creator locales y roles de creación/dirección/música | Publicaciones locales/importadas desde 0.12; FANBOX público en 0.13, tarjetas Patreon en 0.14 y SubscribeStar en 0.22; otras fuentes/cuentas aún pendientes; el usuario confirmó consultas Patreon al desactivar su VPN; artista musical no identifica por sí solo una cuenta online |
| Varias versiones / partes de una obra | Grupos manuales; 0.19 propone por nombre/carpeta con resolución/edición/códec/procesamiento y revisión; listas de partes explícitas consecutivas | Sin identidad canónica de obra/versión, equivalencia de contenido, deduplicación, inferencia de primer archivo sin marca o plegado del mosaico; reconocimiento más limitado que el original |
| Listas ordenadas | Crear, editar, ordenar, secuencia AV; imágenes en visor aparte | Portadas compuestas y filtros guardados del original |
| Favoritos, visto y progreso | Persistentes por documento; favoritos de entidades desde 0.7 | Otros tipos de preferencia y feedback avanzado |
| Historial y estadísticas | Última apertura/contador previos; desde 0.20 visitas locales a AV/imágenes/lecturas, cronología paginada, búsqueda/filtros, último punto y finales AV | No reconstruye visitas antiguas, mide tiempo efectivo/seek_count/ratios o importa la actividad completa del ledger original |
| Datos personales y recuperación | Copia JSON v18, lee v1–v18; incluye visitas, instantáneas/correspondencias del catálogo, lectura y organización; migraciones explícitas hasta Room v13 | 0.9 guarda/exporta proyección seleccionada del catálogo y registros sin archivo; faltan portabilidad integral y formato de retorno importable por Peach original |
| Lectura de documentos/álbumes | PDF, ZIP/CBZ y texto desde 0.8; TAR/GZIP en 0.15, 7z en 0.16 y EPUB de texto en 0.17, con reanudación independiente | Formatos comprimidos pendientes, EPUB completo/ofimática, funciones PDF avanzadas y validación nativa de PDF en dispositivo |
| Reorganizar archivos, papelera, reversión | 0.42: vista previa y permisos de escritura, mover/renombrar por proveedor, papelera restaurable, NFO con respaldo y registro de recuperación | Proveedor SAF compatible, sin transacción distribuida ni movimiento entre proveedores; no mueve auxiliares automáticamente ni borra medios definitivamente; verificar en dispositivo |
| Pared de reproducción y vistas avanzadas | Mosaico nativo | Pared inmersiva, agrupación visual de tarjetas y navegación equivalente |
| Lista de deseos / obras fuera de la biblioteca | Seguimiento local 0.12: fechas/estados, publicaciones de origen, búsquedas registradas, reconciliación revisada y deshacer lote | Normalización completa, búsqueda real de recursos, descargas y reconciliación automática |

Explorar metadatos por sí solo no crea fichas. Las identidades se crean explícitamente
y cada ficha conserva su UUID. Sus alias exactos reúnen nombres a petición del usuario;
un conflicto entre fichas del mismo tipo rechaza el cambio. Los nombres distintos se
mantienen distintos, incluso si solo cambia una mayúscula. Los NFO releídos guardan los nombres
como listas: «Rivera, Ana» sigue siendo un nombre. Los registros antiguos usan los
campos aplanados hasta Actualizar. Las etiquetas personales usan comas/saltos de línea.
Un grupo manual puede contener cualquier familia y varios documentos con el mismo
nombre. No comparte progreso ni deduplica archivos. Las versiones AV se eligen;
no se reproducen consecutivamente por pertenecer al mismo grupo.

## Fuentes y funciones conectadas

| Dominio original | Estado Android | Condición para incorporarlo |
|---|---|---|
| Medios locales y medios ya descargados | Núcleo independiente y offline | Archivo disponible mediante SAF; un proveedor cloud puede necesitar red propia |
| Montajes 115, OneDrive, CloudDrive2/OpenList | Sin montaje de escritorio en APK | Evaluar acceso Android directo o importación; no exigir el host original |
| PikPak y descargas remotas | Pendiente | Adaptador, autenticación, almacenamiento de tokens, límites y pruebas con cuenta autorizada |
| Fuentes seguidas y publicaciones de creadores | FANBOX público en 0.13; Patreon 0.14 implementa tarjetas; el usuario confirmó resultados sin VPN en 0.15; revisión/caché local, galería nativa FANBOX 0.21, tarjetas SubscribeStar 0.22, nueve fuentes desde0.26, galería de seis fuentes en0.30, video privado completo0.31, cola/lotes/reanudación condicional0.32 y video progresivo corregido0.34, calidad0.35, Gofile0.36 y sesión/enlaces F95 opcionales0.37 | Cuentas, cuerpos/adjuntos Patreon, agenda, HLS/DASH/calidad adaptativa, galería avanzada y descargas en segundo plano |
| Cola de adjuntos importados | Lotes explícitos, progreso, pausa y reanudación condicionada al servidor; exportación SAF de completas sin redescargar en0.32 | Pantalla abierta,128 trabajos/2GiB por archivo/4GiB privado; no motor en segundo plano; solo referencias compatibles incorporadas explícitamente |
| Descubrimiento, novedades y metadatos online | Pendiente | Transporte nativo probado, procedencia, caché y revisión de conflictos |
| Búsqueda de subtítulos y recursos | Subtítulos locales implementados; búsqueda online pendiente | Adaptadores y pruebas; no basta copiar las URLs del backend |
| Marcadores y enlaces del navegador | Pendiente | Importación explícita de archivos; Android no permite leer bases privadas de otras apps |
| Preferencias, feedback e IA | Pendiente | Modelos de datos, candidatos revisables y presupuesto de memoria/cómputo; servicios opcionales por separado |
| Sincronización entre dispositivos | Pendiente | Intercambio seleccionado SQLite/JSON disponible en 0.9; sincronización bidireccional, conflictos por campo y permisos entre dispositivos pendientes |
| Diagnóstico remoto/telemetría del original | No incluido | No es requisito para compatibilidad; sin analítica. INTERNET se añade para FANBOX opcional |

Una función que consulta una fuente online necesita acceso a esa fuente. Esto no
autoriza introducir un servidor Peach obligatorio ni una dependencia de Windows.
Las limitaciones anteriores son trabajo pendiente, no motivos para declarar paridad.

## Orden de trabajo

**Decisión posterior a0.24:** el usuario confirmó el funcionamiento de la corrección
de adjuntos y excluyó Kemono y Coomer del plan. La siguiente fuente solicitada es
cum.st (OnlyHaven), implementado en0.25 con contrato observado en un cliente de referencia; validación online pendiente.
La propuesta anterior de Coomer queda cancelada. PLAN_FUENTES.md conserva la decisión,
la comprobación preliminar y el alcance pendiente; FUENTES_CUMST.md describe la implementación actual.

1. Consolidar las familias locales, organización y lectura compatible, con migraciones y pruebas (0.6/0.7/0.8).
2. Ampliar las fichas/alias/relaciones y deseos locales: importación del grafo, procedencia
   histórica, publicaciones y estados. Conservar archivos, publicaciones y obras como conceptos distintos.
3. Añadir importación/exportación revisable y funciones locales de lectura pendientes.
   Ampliar comprimidos más allá de ZIP/CBZ y evaluar STRM sin prometer un decodificador universal.
4. Incorporar fuentes opcionales por proveedor; mantener utilizable el núcleo sin red.
5. Cerrar diferencias de reproducción, historial, interfaz, rendimiento y hardware. 0.18 añade sesión de audio en segundo plano; no cierra los demás pendientes.

Cada entrega debe incluir APK, fuente y pruebas documentadas. La matriz se actualizará
según comportamiento implementado y verificado, sin porcentajes de avance inventados.

## Importación acotada en 0.9.0

Catálogo de Peach original abre SQLite autónomo en modo DELETE o JSON de intercambio;
no requiere ejecutar el original. Se conservan campos seleccionados de asset, asset_tag,
entity, entity_alias, entity_external_ref, asset_entity, playlist y playlist_item.
El registro sin archivo sigue consultable y exportable, sin una URI reproducible inventada.
La importación añade organización compatible después de revisión; no cambia NFO, estado
AV, lectura ni preferencias actuales. Conserva fuentes/confianza como datos de origen.
En 0.9 las agencias (migración 0025) permanecían solo en la instantánea.
0.11 añade fichas de agencia y afiliaciones revisables; roles no modelados siguen como datos.
0.12 incorpora una proyección seleccionada de wants y publicaciones. No importa íntegramente preferencias, actividad, metadata_json,
credenciales o procesos. El JSON exportado no es una base ledger que el original ya lea.
No se declara paridad ni migración completa. Véase IMPORTACION_CATALOGO.md.

## Consulta integrada en 0.10.0

Los campos seleccionados de catálogos vinculados participan en búsqueda, fichas y
filtros principales; creator tiene faceta propia. Los nombres se conservan atómicos
y se cuentan una vez por documento. Las fichas muestran cada origen y desacuerdos;
NFO y ediciones personales mantienen prioridad. Un título único puede completar
el título de archivo sin NFO. La capa es reconstruible desde las instantáneas,
sin sustituirlas, e incluye un aviso para índices parciales de más de 512 KiB.
Room v9 añade solo la columna derivada; copias siguen en v6. Se corrige la comparación
de rutas relativas al descontar la base conocida del checkpoint raíz del escáner.
METADATOS_CATALOGO.md detalla prioridades, actualización y límites. Siguen pendientes
agencias/membresías, publicaciones, deseos completos, revisión por campo, varios
mapeos en un lote, reversión y sincronización integral del original.

## Agencias y afiliaciones 0.11.0

Agency es una ficha nativa con alias/referencias/favorito. entity_membership del original
se incorpora como afiliación vigente por persona/creador, con fuente/confianza/fecha,
gestión manual y revisión de conflictos al importar. La ficha y el ámbito de agencia
reúnen archivos de sus miembros sin duplicar documentos ni incorporar coprotagonistas
a su roster. No hay vínculos directos agencia→archivo. Room v10 y copia v7 conservan
los dominios anteriores. AGENCIAS.md distingue esa implementación de historial,
captación/rechazo online, logotipos y búsqueda textual general por nombre de agencia,
todavía pendientes. Publicaciones, deseos completos y proveedores continúan abiertos.

## Publicaciones y deseos 0.12.0

Publicaciones nativas separadas de obras y documentos, con precisión de fecha, semántica,
variante y estado; proyección revisada de follow_source/follow_item/want_item. Los deseos
incorporan estados, fecha, registro de búsquedas con ventana 90 días/3 fallos antiguos,
coincidencias por código declarado tras revisión y deshacer de lotes locales. Room v11
y copia v8; migraciones y lectura de copias v1–v7. Publicaciones y seguimiento conservan
la procedencia y no crean una URI de reproducción donde no existe archivo.

Se preserva lo existente al reimportar. No hay suscripción online operativa, adjuntos
múltiples, búsqueda/descarga real ni normalización completa de códigos del original.
La reconciliación de Android requiere revisión y no corre automáticamente al escanear.
PUBLICACIONES_Y_SEGUIMIENTO.md y PRUEBAS.md detallan las diferencias. Los apartados
0.9–0.11 anteriores describen su alcance histórico; no sustituyen esta actualización.

## Fuente FANBOX y contenido público 0.13.0

Primera fuente directa del registro de proveedores original: FANBOX público/gratuito,
con consultas explícitas de lista, índice real de cursores y cuerpo. No hay petición
automática al iniciar, cuenta ni host Peach. El usuario revisa una página antes de
incorporarla, con UUID reutilizado por identidad externa inequívoca y ficha personal
conservada. Los cuerpos detallados no se sustituyen por resúmenes de lista posteriores.

Se listan adjuntos y se permite descargar uno a un documento elegido para los hosts
FANBOX admitidos. No se crea un documento reproducible ficticio; actualizar/autorizar
la carpeta lo incorpora al catálogo. Room v12 y copia v9 añaden fuentes y cuerpos.
La biblioteca sigue utilizable sin red; el APK añade INTERNET para las fuentes opcionales.

FUENTES_FANBOX.md documenta formato, límites, parcialidad, cancelación, errores y copia.
PRUEBAS.md distingue la comprobación pública real de contrato en JDK de la instrumentación
Android todavía pendiente. No hay paridad de todos los proveedores, suscripciones,
contenidos remotos, medios embebidos, descargas avanzadas o funciones restantes.
Los apartados de versiones anteriores conservan su alcance histórico.

## Tarjetas públicas Patreon 0.14.0

Patreon se añade como segundo adaptador del registro original. Lee exclusivamente
HTML público/fragmentos SSR de tarjetas, sin ejecutar scripts o leer estados de
sesión/bootstrap. Se conservan como adelantos parciales, sin afirmar que el cuerpo
completo sea gratuito o accesible. No se implementan adjuntos o historial Patreon.

La clave incluye proveedor/ref/ID y mantiene las de FANBOX. La revisión conserva las
fichas personales, permite actualizar adelantos y protege cuerpos detallados anteriores.
Room sigue en v12, copia v10 con lectura v1–v9. Jsoup1.23.2/MIT añade análisis HTML
nativo en memoria; el transporte sigue siendo el HTTPS acotado de la app.
FUENTES_PATREON.md y PRUEBAS.md identifican el contrato público comprobado en JDK y
la instrumentación Android todavía pendiente. No es integración completa de Patreon
ni del resto de Peach. Las secciones anteriores mantienen su alcance histórico.


## Lectura TAR y GZIP 0.15.0

Lectura nativa sin red de TAR, TAR.GZ/TGZ y GZIP con índice de archivos, orden natural,
álbum de imágenes y PDF/texto seleccionados. GZIP simple toma el nombre externo sin
.gz, no el nombre de su cabecera. Se reconocen USTAR, nombres largos GNU y PAX
acotado. Enlaces y entradas especiales solo se listan, no se siguen ni materializan.
Se aceptan prefijos relativos ./, rechazando rutas peligrosas y alias duplicados.
No hay reproducción AV dentro del paquete, extracción general o anidados.

Room permanece en v12 y copia en v10. Los datos no se recrean. Se reutiliza progreso
por documento/entrada, búsqueda de índice y controles nativos. Se añade Commons
Compress 1.28.0 y sus dependencias Java; no se incluyen códecs nativos opcionales.
LECTURA_TAR_GZIP.md documenta límites, integridad y alcance probado.
La nota histórica de bloqueo se actualiza: el usuario confirmó resultados de Patreon al desactivar la VPN en 0.15. No se implementó una solución de CAPTCHA.


## 7z local 0.16.0

El índice 7z usa Commons Compress 1.28.0 con XZ for Java 1.12 (0BSD). Se abre una
copia privada de la URI SAF, con índice buscable, imágenes y PDF/texto compatibles.
Un decodificador nuevo por selección evita reutilizar un flujo fallido o vacío.
Room v12 y copia v10 se conservan. El contenido de los archivos no se añade a copias.
LECTURA_7Z.md documenta límites y subconjunto de cabeceras compatibles; RAR/CBR
continúa pendiente. Las pruebas nativas siguen compiladas sin ejecución directa.

El usuario aceptó generalmente 0.15 y confirmó resultados de Patreon sin VPN. Esto
actualiza el estado observado del conector, no amplía su acceso a cuerpos privados
o implementa verificación humana. evidence/user-validation-0.15.0.json conserva el alcance.

## EPUB nativo de texto 0.17.0

El contenedor sigue siendo other. Se abre el primer XHTML principal según el spine,
con capítulos anterior/siguiente/salto, texto seleccionable y tamaño de letra.
El índice busca rutas y permite abrir imágenes locales en una secuencia separada.
Se reutilizan ZipBook, XML Android, jsoup y reader_progress; Room 12/copia 10 no cambian.
No hay motor web, red, CSS, DRM, fuentes ofuscadas, NCX/nav propio, imágenes inline
o EPUB anidado. Los rechazos conservadores y límites están en LECTURA_EPUB.md.
La suite propia no certifica conformidad EPUB; ejecución nativa pendiente.

El usuario aceptó generalmente 0.17 con «Todo correcto, sigue». No se infiere
validación individual de formatos o ejecución de instrumentación.

## Audio con sesión Android 0.18.0

AudioActivity controla AudioService mediante MediaController/MediaSessionService.
La cola contiene solo audios de la selección local; guarda progreso y no reinicia
al reconectar la pantalla. Controles de Android, pausa/continuación y Detener audio.
Se añaden permisos normales de reproducción en primer plano y wake lock; no servidor
externo, arranque al reiniciar o permisos amplios de archivos. Room 12/copia 10 siguen
iguales. La reproducción de video conserva su pantalla y recorrido anterior.
La suite local no sustituye pruebas físicas de foco, bloqueo, notificación, Bluetooth
o batería. AUDIO_SEGUNDO_PLANO.md explica el alcance. Última aceptación general 0.18.


## Revisión de versiones y partes 0.19.0

VersionIndex produce indicios de nombres y candidatos por raíz/carpeta y nombre base.
VersionsActivity permite revisar y seleccionar; VersionReviewStore revalida cada
archivo en transacción y crea grupos o listas ordinarios. Las partes requieren una
sola firma y secuencia explícita 1..N sin duplicados/huecos; un total declarado debe
coincidir. La repetición reutiliza la organización con la misma pertenencia/orden.
No cambia archivos ni progreso, ni reduce el conteo de documentos del mosaico.

No es la proyección canónica catalog_versions completa: no usa tamaños de video
medidos, no infiere equivalencia de archivos completos y partes, no agrupa entre
carpetas, no asume que igual código equivale a igual contenido y no enlaza ni concatena
medios. La duración guardada y las marcas del nombre tienen procedencia visible.
Room 12/copia 10 se conservan. VERSIONES_Y_PARTES.md detalla el subconjunto y límites.
El usuario aceptó generalmente 0.19 con «Todo correcto sigue con lo demas». No se
infiere prueba individual de cada función o instrumentación ejecutada.


## Visitas e historial 0.20.0

usage_sessions es una cronología Android local, no una copia completa del ledger de
actividad original. El original web_activity.w_activity acumula play_seconds, ratios
y seek_count; Android aún no mide esas métricas ni feedback avanzado. Esta etapa
conserva las últimas10.000 visitas por fecha de inicio guardada, sus títulos y puntos
recientes, sin estimar minutos desde la posición. Audio sigue al servicio; lectores
registran entradas/páginas/desplazamiento; imágenes registran visitas tras decodificar.

Room12→13 añade únicamente tabla/índices y conserva datos anteriores. Copia11 añade
historial con UUID, restaura por identidad sin duplicar y conserva registros actuales
al leer copias1–10. El borrado del historial no cambia progreso o archivos; quitar una
ubicación borra sus sesiones por FK. HISTORIAL_USO.md y PRUEBAS.md detallan límites.
El usuario comunicó aceptación general de0.20 y posteriormente0.21. No se infiere
instrumentación o prueba de hardware a partir de la suite JVM/Robolectric.

## Galería pública FANBOX 0.21.0

La vista de imágenes importadas es un primer subconjunto de `_raw_media_items` y
`_media_projection` de `src/peach/web_follow.py` en el commit de referencia. El original
proyecta imagen/vídeo, conserva índices para follow-stream, medios ocultos, miniaturas,
dimensiones, recursos/proveedores y excepciones de autor; no se declara equivalencia.

Android selecciona imágenes del cuerpo guardado por ID de publicación, conserva orden
y elimina URLs duplicadas. Consulta solo la imagen elegida, zoom nativo y caché
verificada offline. Continúan pendientes vídeo remoto, ocultación por imagen, portadas,
mosaicos, galerías multiproveedor/cuentas, descargas por lotes y reanudación.
Sin dependencias, permisos, Room13 o copia11 nuevos. GALERIA_FANBOX.md detalla los límites.

## SubscribeStar 0.22.0 y prioridad de fuentes

Tercer conector: tarjetas del HTML público servido a visitantes de SubscribeStar.com y
SubscribeStar.adult, con identidades separadas por host/creador y proveedor. Un nombre
sin host usa.com. Selector nativo, consulta explícita, revisión/importación, actualización
de adelantos sin sobrescribir ficha personal/cuerpo detallado y lectura offline.
Título, fecha aproximada sin zona horaria inventada y texto visible acotado. Sin sesión,
JavaScript, cuerpo completo, adjuntos, galería, vídeo o historial remoto de este proveedor.

Referencia original: SubscribeStarConnector en src/peach/follow_sources.py, mismo commit
fijo. La prueba pública real recuperó6 tarjetas de un creador de tutoriales Linux en.com,
por JDK HTTPS: no equivale a Android/.adult probado. Sin dependencias/permisos ni cambios
de Room13. Copia12 lee1–12; versiones anteriores de la app rechazan la copia nueva.
FUENTES_SUBSCRIBESTAR.md y PRUEBAS.md detallan todos los límites.

El usuario pidió priorizar las demás fuentes del original. Próximas etapas se centran en
conectores adicionales tras auditar sus contratos y acceso; no posponerlos hasta terminar
los lectores locales. El registro fijo original contiene11 fuentes de seguimiento y
Gofile como origen de medios, no como fuente de seguimiento. No se declara equivalencia
completa por añadir nombres al selector.

## Pawchive 0.23.0: implementación con validación online pendiente

Por instrucción del usuario se prioriza Pawchive y se pospone Kemono, cuya caída fue
reportada por el usuario. No hay contacto ni fallback automático a Kemono. El cuarto
conector implementa JSON público, referencias servicio/ID,50 publicaciones por página,
paginación explícita por offsets, cuerpo consultado a petición, metadatos de adjuntos
solo como referencias, revisión/importación y lectura offline de lo importado.

Pruebas con datos propios y compilación no equivalen a integración online verificada:
la petición directa de API desde este entorno devolvió HTML «Site Unavailable» en lugar
de JSON; el runner JDK de producción también rechazó el formato. No se han validado
cuentas/creadores reales o descargas de Pawchive. API/swagger_schema devolvió530 en
la herramienta web; la portada pública sí fue recuperable. No se deduce caída mundial.

No se anuncian descargas, galería o reproducción de los adjuntos de esta fuente; sus
hosts no se añaden al transporte de medios. Room13 intacto, copia13 lee1–13, sin nuevos
permisos/dependencias. FUENTES_PAWCHIVE.md y PRUEBAS.md detallan alcance y restricciones.

## Guardado directo Pawchive 0.24.0

Corrige la incidencia de0.23: los adjuntos estaban marcados como referencias y el mensaje
«Servidor externo no incorporado» se interpretaba como dependencia de un servidor propio.
Se habilita descarga HTTPS directa de file.pawchive.pw con ruta/hash canónicos, hasta128MiB,
longitud y SHA-256 esperados del nombre, temporal privado y copia SAF tras verificar.
No servidor Peach/Windows/Termux. Mensaje nuevo distingue direcciones sin soporte directo.

Las166 referencias antiguas del JSON proporcionado se reconocen sin mutar sus flags o
exigir nuevas consultas. No se empaquetan datos del usuario. El JSON demuestra50 filas
y2 detalles consultados en la tablet; no prueba descarga completa por este entorno.
Un flag falso sigue siendo válido como referencia conservadora; uno verdadero debe
corresponder a una URL admitida. No hay bypass de URL/host por importar una copia.

Room13 sin cambios, copia14 lee1–14; versiones anteriores rechazan14 antes de modificar.
Sin nuevos permisos/dependencias. Redirecciones Pawchive se limitan al mismo host y hash,
sin salto a FANBOX/Kemono u otros nodos. Siguen pendientes lotes/reanudación, archivos
mayores de128MiB y galería/vídeo remoto Pawchive. Las verificaciones nativas y de descarga
real por este entorno siguen separadas de pruebas de flujo con bytes propios.

## cum.st (OnlyHaven) 0.25.0

Quinto proveedor independiente, solicitado en lugar de Coomer; Kemono y Coomer quedan
excluidos del plan. Registro y claves propios, sin alias, fallback, migración automática
entre sitios o peticiones a esos dos dominios. Se auditó el cliente gallery-dl1.32.18:
rutas lista/detalle y forma de publicaciones/variantes difieren de Pawchive. El esquema
oficial completo no fue recuperable. La API directa devolvió formato inesperado desde
este entorno, sin probar indisponibilidad global. No hay validación online nueva.

Consulta explícita de50 publicaciones, offset, cuerpo parcial, revisión/importación,
preservación de fichas/cuerpos y texto/referencias offline. Adjuntos de e1.cum.st/media
con ruta relativa admitida, variante de mayor tamaño declarado, guardado SAF hasta128MiB.
No se intenta acceder a archivos marcados locked. Longitud/SHA calculado, sin inventar
un hash esperado del sitio. Redirecciones solo a la misma URL exacta; no nodos alternos.
Sin galería/video remoto cum.st, cuentas/DMs, búsqueda global, embeds, lotes/reanudación,
medios>128MiB o compatibilidad de todas las variantes. FUENTES_CUMST.md detalla límites.

Room13 intacto; copia15 lee1–15 y conserva los dominios previos. Sin dependencias o
permisos nuevos. Pruebas con datos/bytes propios y APK compilado no equivalen a ejecución
Android o consulta real verificada. La aceptación comunicada de0.24 no se extiende a0.25.

## Entrega conjunta0.26.0 y exclusión adicional de SimpCity

Por petición del usuario se incorporan juntas las cuatro fuentes pendientes: Rule34
Paheal (etiqueta/HTML), Rule34.xxx (etiqueta/DAPI con clave propia), Rule34Video (autor/HTML
y VideoObject) y F95zone (últimas24 respuestas públicas /latest). Kemono, Coomer y
SimpCity quedan excluidos del selector/transporte/plan. Son nueve conectores Android
con alcances distintos, no equivalencia íntegra de los proveedores del original.

Consulta explícita, candidatos, revisión/importación, texto/metadatos offline, detalle
Paheal/Video seleccionado y guardado individual hasta128MiB en rutas/hosts admitidos.
Otras variantes, nodos, servicios externos, cookies/privados, masked/Gofile, galerías
multiproveedor, vídeo remoto y funciones avanzadas siguen pendientes. No hay WebView,
servidor Peach, Termux/Windows o peticiones al iniciar. No se omiten esas diferencias.

Rule34.xxx usa una clave local cifrada con AndroidKeyStore/AES-GCM, fuera de la copia
JSON y sin URLs autenticadas persistidas. Sin clave no hace solicitudes. API429 aplica
espera a todas sus fuentes. Room13 idéntico; copia16 lee1–16, sin permisos/dependencias
nuevos. Datos y fichas previos conservados; no se mezclan publicaciones por ID entre sitios.

569 pruebas locales y APK compilado no prueban acceso online: el runner JDK con referencias
sintéticas no obtuvo páginas reconocibles desde este entorno, y no se aportó clave API.
Pruebas Android27 compiladas/0 ejecutadas. El usuario confirmó0.25;0.26 aún sin aceptación.
FUENTES_CONJUNTAS.md y PRUEBAS.md documentan contratos, límites, fallos y validación.


## Corrección del flujo de video0.27

Documento guardado con MIME concreto cuando su extensión es conocida; nombres genéricos
recuperan extensión conocida de su URL sin inventar contenedores. Fuentes permite abrir
un archivo elegido mediante SAF o el último video guardado con éxito. Reproductor nativo
Media3 existente, sin servidor, sin WebView, sin petición a la fuente al abrir y sin
inserción automática en Room. Posición/pausa se conservan al recrear; progreso persistente
y visitas de catálogo requieren su incorporación normal a Biblioteca. La selección previa
no se conserva al terminar el proceso: puede elegirse otra vez, sin redescargar.

Fallback solo entre decodificadores que Android ya ofrece cuando uno falla al inicializar;
no añade soporte universal de códecs. Errores distinguen acceso, archivo no encontrado,
lectura, contenedor y decodificador. Reproducción real del video problemático sigue pendiente,
porque no se recibió su error exacto ni se dispone de la tablet conectada.

Verificación0.27:582 pruebas locales/90 clases aprobadas, lint0 errores/42 advertencias.
28 pruebas Android compiladas y0 ejecutadas. Firma original, permisos, dependencias
y esquemas anteriores comprobados. docs/PRUEBAS.md contiene el alcance y los resultados.


## Descargas y animación0.28

Flujo privado → verificación → selector SAF → copia → comprobación de longitud si el
proveedor la expone. Descargas de fuentes hasta2GiB y1hora, reservas de espacio y
streaming acotado. El límite interno anterior de128MiB y galería de16MiB permanecen
para sus usos; Fuentes usa la política grande. No lotes/reanudación o garantía de
continuidad en segundo plano. Los destinos anteriores de0 bytes no se recuperan ni
se borran automáticamente. Limpieza de copia fallida depende del proveedor SAF.

Reconocimiento de cabeceras (máximo4KiB) para evitar que una extensión BIN obligue a
tratar un GIF como video. No es validación universal de contenedores o códecs. Apertura
local directa de imágenes; GIF/WebP animados mediante ImageDecoder en Android28+,
con pausa/reanudación y vista limitada a1024px. API26/27 conservan fotograma estático.
No se añade una biblioteca o WebView. Las fichas/visitas de catálogo continúan separadas
de la apertura directa. Claves de usuario fuera de backups como antes.

Rule34Video: enlaces MP4/WebM de descarga pública del HTML y calidades disponibles,
sin usar una referencia embed/JSON-LD como supuesto archivo. Rutas get_file estrictas,
hosts exactos anteriores y download=true; parámetros públicos adicionales acotados,
sin parámetros de credenciales o redirección. No endpoints arbitrarios o cambios de
archivo mediante redirecciones. Hasta8 enlaces, consulta explícita del cuerpo; las
referencias importadas previamente se renuevan consultando/reimportando. Copia17 lee1–17.
La reproducción física en la SM-X230 y los bytes concretos del usuario siguen pendientes.

Verificación0.28 final:601 pruebas locales/94 clases aprobadas, lint0 errores/51 avisos.
30 pruebas instrumentadas compiladas y0 ejecutadas. Firma original, dependencias,
permisos y esquemas comprobados. El caso físico del usuario aún debe confirmarse.

Animación0.28: lectura desde ByteBuffer mapeado con descriptores cerrados. Proveedores
no posicionables usan una copia en memoria limitada a64MiB; para animaciones mayores
se necesita una copia local posicionable. Los resultados de guardado SAF esperan
una recarga de pantalla en curso, conservando el temporal preparado.


## Redirección de entrega0.29

Rule34Video: una URL inicial admitida de archivo puede seguir hasta3 saltos a HTTPS
público. El destino se valida como entrega transitoria, no como una URL inicial que
haya que añadir al registro de fuentes. No se almacenan los destinos firmados. DNS
local/privado y rangos especiales se rechazan; IPv6 global unicast y NAT64 público
se admiten conservando TLS/hostname verification del sistema. No hay evasión de
CAPTCHA, cuenta, DRM o resolución JavaScript. Otras familias conservan su política
anterior, incluyendo hash esperado Pawchive y aislamiento de la clave API Rule34.xxx.

El mismo error0.28 se reprodujo con sus fuentes originales y HTTP simulado. La cadena
corregida se comprobó con conexiones simuladas, un MP4 propio y copia SAF de pruebas.
Sin recuperación de URL o medios del usuario ni validación del servidor/CDN real.
Room13/copia17, permisos/dependencias y límites de0.28 permanecen sin cambios.

Validación0.29: 620 pruebas locales/97 clases aprobadas; lint0 errores/49 avisos.
30 pruebas Android compiladas y0 ejecutadas. Mismo mensaje0.28 reproducido con fuentes
originales y HTTP simulado; caso físico/online todavía pendiente.


## Galería de imágenes de seis fuentes0.30

El usuario confirmó que0.29 resolvió el fallo previo de redirección en su tablet.
Esa confirmación no se presenta como ejecución propia de pruebas instrumentadas o
validación de todos los servidores/códecs.

SourceGallery admite imágenes ya consultadas e importadas de FANBOX, Pawchive, cum.st,
Rule34 Paheal, Rule34.xxx y F95zone, usando las rutas iniciales existentes y comprobando
el proveedor de cada imagen. Las tarjetas de Patreon/SubscribeStar y las referencias
Rule34Video no ganan un transporte de imágenes por aparecer en el selector. Los enlaces
externos y otros hosts siguen como referencias. La bandera falsa antigua Pawchive se
reevalúa de la misma forma que Guardar adjunto; otras banderas falsas se conservan.

Galería privada de16MiB por imagen,64MiB/128 imágenes en disco, sin precarga, con hash,
decodificación real y cancelación. Pawchive exige también el SHA esperado de su ruta
tanto al descargar como al abrir caché. Animación GIF/WebP por cabecera en Android28+,
vista hasta1024px, con pausa/reanudación/cambio de imagen y rotación; Android26/27
conservan primer fotograma. Las imágenes fijas mantienen EXIF/vista2048px.

Room13/copia17 intactos. No se escriben fichas/visitas locales al recorrer una galería,
no se consultan cuentas o medios privados y no se añaden permisos/dependencias/servidor.
El cache es descartable y no se guarda en JSON. Para un original permanente se usa
Guardar adjunto. Videos guardados conservan la apertura nativa de0.29; video remoto,
Gofile/masked, lotes/reanudación y los demás pendientes siguen abiertos.

La evidencia completa de0.30 y los resultados exactos están en PRUEBAS.md y
evidence/0.30.0; los bytes de pruebas son propios y la HTTP es simulada.


## Videos desde publicaciones0.31

Por petición del usuario se continúa bloque por bloque.0.30 aceptada según su prueba.
0.31 añade preparación explícita de un adjunto compatible de tipo video del cuerpo
importado y apertura con el reproductor nativo existente. No pide primero una carpeta:
usa una copia privada completa, verificada por longitud/SHA/cabecera y, en Pawchive,
por su hash esperado. No reproduce mientras descarga ni entrega la URL remota a Media3.
Se conservan las rutas iniciales y políticas de redirección de cada proveedor, sin
ampliar servidores, cuentas o referencias externas.

Caché de copias completas hasta2GiB/8 archivos, con límite de transferencia reducido
por videos fijados y otras preparaciones. Las copias en uso por las pantallas/reproductor
no se eliminan por la limpieza de la app. La entrada al reproductor lleva ID de
publicación y clave de selección hash; resuelve nuevamente Room y verifica la copia
sin acceso a red. Media3 lee únicamente su archivo privado validado. Rotación retiene
su propiedad mediante ViewModel; al terminar se libera. Sin conexión impide preparar
archivos ausentes. Android puede limpiar esta caché; Guardar adjunto conserva originales.

Sin nuevo permiso/proveedor/servicio, sin inserciones ficticias en catálogo/historial.
Room13/copia17 intactos. Preparación se cancela al abandonar su pantalla; no cola,
lotes, reanudación o garantía de continuidad en segundo plano. Formatos reconocidos
para la copia privada: MP4/WebM/MKV/MOV; reconocer cabecera no certifica contenedor/códec.
Los demás adjuntos conservan el guardado manual y la apertura local anteriores.

Ver VIDEOS_PUBLICACIONES.md, PRUEBAS.md y evidence/0.31.0 para pruebas y límites.
El proyecto sigue abierto: streaming progresivo, cuentas/cuerpos/servidores pendientes,
Gofile/masked, interfaz avanzada, formatos y compatibilidad integral no están cerrados.


## Cola y lotes0.32 — alcance parcial

El usuario aceptó0.31 y autorizó el bloque siguiente. Cola operativa persistente de128
adjuntos compatibles importados, una transferencia activa,2GiB/archivo y4GiB de copias
privadas. Progreso en bytes, porcentaje solo con tamaño conocido, pausa individual/global,
continuación explícita y recuperación tras cierre sin red automática. ETag fuerte y
Range/If-Range, SHA del prefijo y huella del destino; Pawchive usa también su SHA esperado.
Sin validador suficiente o ante cambio de representación reinicia de forma conservadora.

La pantalla de cola debe permanecer abierta; salir pausa, rotar conserva ViewModel.
No equivale al motor de descargas en segundo plano del original. Guardado de completas
por lote a una carpeta SAF elegida una vez, sin redescargar. Registro del documento
nuevo permite intentar limpiar copias fallidas/interrumpidas sin borrar otros archivos;
la limpieza depende del proveedor Android. Apertura nativa de imágenes/videos completos
mediante proveedor privado de solo lectura, sin ceder permisos URI ni rutas arbitrarias.
Retirar copia privada conserva originales exportados; no inserta visitas/fichas ficticias.

Room13/copia17, permisos, servicios y dependencias anteriores intactos. El estado de
cola vive separado en noBackupFilesDir, no en la copia personal. Se pierde al borrar
datos/desinstalar; no es restauración entre dispositivos. No se incorporan hosts/cuentas
ni convierten referencias externas en descargas. Nueve conectores existentes; Kemono,
Coomer y SimpCity excluidos. Galerías/video individual/Guardar adjunto se conservan.

COLA_DESCARGAS.md y PRUEBAS.md registran detalles, resultados y límites. Continúan
pendientes Gofile y otros enlaces externos/masked, streaming progresivo, cuerpos/cuentas
adicionales, interfaz, sincronización, formatos y validación de compatibilidad completa.


## Reproducción progresiva0.33 — Ver en línea

0.32 aceptada por el usuario. Ante su consulta sobre ver videos sin preparar primero
un archivo completo se prioriza este bloque antes de auditar Gofile. Streaming de
adjuntos compatibles ya importados: Media3/ProgressiveMediaSource con transporte propio
vinculado a ID/clave, sin URL/ruta del llamador, red al pulsar el botón y búfer en RAM.
No crea archivo de video en disco, ficha o visita ficticia del catálogo. Mantiene
preparación completa, cola y guardado individual con sus verificaciones anteriores.

Hasta16GiB de recurso en línea, objetivo de búfer32MiB/5–15s, no cuota total del proceso.
Cabecera pequeña comprobada; saltos206 validados con ETag fuerte/destino/tamaño o
identidad Pawchive. No se verifica SHA completo antes de mostrar imágenes en este modo;
para eso se usa descarga completa. Algunos MP4 necesitan saltos para empezar. Si la
fuente ignora Range no se descarga todo el prefijo para aparentar un salto. Formato/códec
siguen condicionados al sistema y servidor. Sin HLS/DASH/calidad adaptativa, transcodificación
o cuentas nuevas. No amplía hosts ni convierte referencias externas en medios admitidos.

Salir cancela la conexión; rotar conserva identidad/posición/pausa, pudiendo volver a
pedir datos. Sin conexión bloquea transporte. No carga en segundo plano o restaura video
como si fuera offline. Manifiesto, permisos, servicios, proveedores, dependencias,
Room13/JSON17 intactos. La galería y lectores locales conservan sus flujos anteriores.

Pruebas con MP4 propio y HTTPS/DNS simulados: el extractor real emite muestras y salta
por su índice antes de leer el archivo entero. No se afirma primer fotograma/decodificación
física o disponibilidad de cada CDN. STREAMING.md/PRUEBAS.md registran límites y resultados.
Gofile/masked, cuerpos/cuentas, interfaz, formatos, sincronización y paridad restante
siguen pendientes; Kemono/Coomer/SimpCity excluidos. El proyecto permanece abierto.


## Corrección de integración progresiva0.34

La captura del usuario mostró un mensaje de acceso denegado con código Media3 2000.
No expone el estado HTTP, proveedor o URL, por lo que no prueba una denegación del
servidor. Se reprodujo el mismo mensaje con StreamDataSource0.33 intacto y el cargador
real Media3: ProgressiveMediaPeriod añade Icy-MetaData:1 y la app rechazaba cualquier
cabecera. Las pruebas anteriores del extractor no recorrían esa integración completa.

0.34 consume solo esa indicación interna y no la envía a HTTP. El resto de cabeceras,
URI, método/cuerpo y offset ajenos siguen rechazados. Diferencia REQUEST local de
ACCESS real401/403 y conserva estados HTTP saneados. No añade cookies, cuentas, hosts,
permisos o dependencias, ni evita una denegación real. La prueba nueva prepara un
periodo progresivo y obtiene muestras H.264 por SampleStream. Datos/HTTPS simulados;
reproducción física y acceso al medio del usuario pendientes. Se mantiene Room13/copia17,
streaming sin archivo de video en disco y funciones de preparación/cola/galería previas.

PRUEBAS.md y evidence/0.34.0 conservan reproducción fallida0.33, bytecode Media31.8.0,
corrección, pruebas y límites. No se declara aceptada0.33.0.32 sigue como última aceptada.
Gofile y el resto de compatibilidad siguen pendientes; el proyecto permanece abierto.


## Calidad y versiones0.35

Consulta explícita y revisable del detalle de Rule34Video/Paheal o API existente cum.st,
sin descarga de medios durante la consulta. Protege datos personales y cuerpo anterior
ante cancelación, revisión obsoleta o reemplazo vacío/solo preview frente a archivo actual.
cum.st conserva alternativas de video bajo el máximo anterior de100 adjuntos, reservando
principales antes de extras y omitiendo locked. Rule34.xxx conserva file_url. Etiquetas y
altura/tamaño declarados no prueban duración/resolución real. Sin HD artificial, nuevas
credenciales, HLS/DASH o transcodificación. Ver CALIDAD_Y_VERSIONES.md. Gofile y todos los
trabajos pendientes anteriores siguen abiertos; esta entrega no declara paridad completa.


## Gofile y enlaces externos0.36

Gofile no es una décima fuente. Se adapta follow_gofile.py del commit fijo: transporte
API separado con Bearer propio, una página explícita, archivos/controles de acceso y
revisión antes de incorporar adjuntos a una publicación importada. API Premium documentada;
sin clave no hay solicitud. Sin cookies de otra fuente, invitados automáticos o credenciales
incluidas. La clave se cifra con AndroidKeyStore/AES-GCM fuera de copias.429 persiste entre
pantallas y cambios de clave. Nueva actividad no exportada, sin nuevos permisos o runtime.

Medios directos admitidos store*.gofile.io/download, sin query/credenciales/traversal,
DNS público y sin redirección a otro archivo/host. Galería, streaming, preparación, guardar
y cola nativos reutilizados. La API consulta metadatos; no descarga medios al consultar o
incorporar. Conserva ficha/notas, otros adjuntos, cuerpo, archivos e historial; protege
cambios concurrentes, resultados vacíos y máximo100. Reconsultar el origen conserva extras
resueltos. Room13 igual; copia18 lee1–18 y valida nuevas referencias.0.35 no lee copia18.

Gates de contraseña/acceso, API sin Premium, nodos/rutas firmadas/con cookies, sesiones
F95/masked, otros servicios y recorrido recursivo siguen pendientes o se informan como
límite. No se probó una cuenta real ni medio upstream; la consulta sin clave a UUID ficticio
recibió401/error-token. Ver GOFILE.md, PRUEBAS.md y GUIA_GOFILE_036.md. El proyecto sigue abierto.


## F95: sesión opcional y enlaces0.37

Se adapta F95ZoneConnector del commit original fijo: importar cabecera Cookie propia ya
obtenida, guardarla cifrada aparte y usarla solo en rutas exactas f95zone.to. No password,
extracción de navegador, login nativo o CAPTCHA. Sin sesión continúa transporte público;
con ella GET /latest puede usar el transporte separado, redirecciones solo mismo hilo.
Cambio/borrado invalida revisiones y validadores condicionales sin borrar caché/cuerpos.

Publicación importada → Enlaces F95 → un POST masked explícito con cuerpo fijo → revisar
→ incorporar destino. No consulta el servidor devuelto. Gofile carpeta usa después su
clave/API independiente; adjuntos F95 directos de contrato anterior pueden abrirse con
funciones nativas, Pixeldrain sigue referencia. Datos/cuerpo/originales preservados,
100 adjuntos, cancelación/offline/pausa/429 persistido y revisión concurrente protegidos.
Videos F95 directos y img src admitidos se clasifican para medios nativos.

Room13/copia18 y rutas descargables/dependencias/permisos/servicios/proveedores anteriores
intactos; metadato opcional de procedencia y una actividad no exportada. Basado en fuente/
snapshot originales: actual masked.js devolvió195 bytes HTML Site Unavailable con HTTP200,
no JS. No sesión, cuenta, POST masked real o medio upstream probado. Pruebas con datos
propios/HTTPS simulado; instrumentación solo compilada. Ver F95_SESION_Y_ENLACES.md y PRUEBAS.md.

Sigue abierto login/acceso actual real, formatos, organización de archivos, sincronización,
servicios opcionales, interfaz/rendimiento y validación final. PENDIENTES.md identifica
seis frentes, no seis entregas garantizadas. Siguiente prioridad prevista: evaluar RAR/CBR.

## Avance0.38 — RAR/CBR almacenados

RarBook propio, sin dependencias nuevas: RAR4 portable/RAR5 UTF-8, método almacenar,
CRC32, índice natural/búsqueda, imagen/texto/PDF, navegación y posición.512MiB fuente/
total declarado,64MiB por selección,10.000 cabeceras/8MiB índice. Rechazo explícito de
SFX/volúmenes/sólidos/cabeceras cifradas/rutas inseguras; comprimidos/cifrados/links/sin
CRC/extras desconocidos solo en índice. No descomprime o sigue enlaces. Room13/copia18
conservados. Fixtures propios cruzados con libarchive3.7.4 host (no Android). Junrar8.1.2
sí anuncia RAR hasta7; no se incorpora por decisión de licencia. libarchive3.8.2 BSD es
alternativa preferida pendiente de integración NDK, límites de memoria y pruebas.
No se declara paridad completa ni compatibilidad universal CBR.

## Avance0.39 — descompresión RAR compatible

Motorlibarchive3.8.10 BSD en cuatro ABIs, servicio no exportado/UID aislado; IPC AIDL por
descriptores, sin rutas, cookies o servidor externo. Java indexa y revalida antes de
la selección; CRC/tamaño nativos más Java antes de publicar. Cuota malloc160MiB y
asignación64MiB, no máximo de RAM total; RLIMIT_FSIZE64MiB en el proceso. Cancelación y
watchdog solicitan terminar proceso propio; no prometer tiempos absolutos ante fallos
del sistema. RAR4 métodos31–35 y RAR5 versión0 métodos1–5/diccionario64MiB; variante
no compatible queda en índice/rechazo explícito. Casos reales propios generados por RAR
para Linux se decodifican con el motor JNI host; Binder Android/ABIs compilados siguen
sin ejecución física. Unicode heredado RAR4, sólidos, volúmenes, password y RAR7
comprimido pendientes. Room13/copia18 conservados; original/nota/posición intactos.


## Avance0.40 — nombres Unicode heredados RAR4

Parser acotado de las cuatro instrucciones del nombre heredado. Lectura almacenada y
comprimida compatible por nombre Unicode exacto, hasta4096bytes UTF-8. Sin cambios de
motor nativo, cuotas, transporte, dependencias, manifiesto, Room13 o copia18.
Muestras propias con acentos, ñ, japonés y pares UTF-16; rechazo de malformados,
rutas inseguras y duplicados después de decodificar. ANSI ambiguo sigue pendiente.
Ver LECTURA_RAR_UNICODE.md y PRUEBAS.md. Esto no cierra el frente RAR ni la paridad.


## Avance0.41 — RAR5 sólido compatible

Subconjunto por el motor aislado previo: algoritmo0/métodos1–5, entradas regulares
comprimidas no vacías hasta64MiB, mismo diccionario hasta16MiB, total declarado128MiB.
Primer archivo independiente; rutas/cabeceras revalidadas y CRC/tamaño seleccionado.
Al procesar entradas previas, el motor descarta sus bytes y no verifica su CRC.
No se certifica el contenedor completo. RAR4 sólido y otras variantes siguen pendientes.
Binarios nativos, permisos, Room13/copia18 y dependencias intactos. Ver PRUEBAS.md y
LECTURA_RAR_SOLIDO.md. Siguiente frente: organización SAF; los seis frentes siguen abiertos.


## Parte1 agrupada — 0.42

Organización física revisada con conservación de mediaId/progreso/listas, escaneo que
reconoce la URI actual, papelera por UUID excluida de escaneos y recuperación explícita.
NFO: campos comunes compatibles, combinación que conserva nodos desconocidos/roles,
respaldo antes de escribir, comprobación posterior y restauración/retirada revisada.
No exporta secretos o estado de uso; no se presenta como exportación integral del ledger.
Duplicados por SHA-256 y propuestas por código NFO con revalidación; guardar grupos
sin fusionar/eliminar registros, y listas de partes explícitas consecutivas revisadas
por código incluso entre carpetas. La identidad canónica completa del original no se
presume por tener estos grupos. PARTE_1_ORGANIZACION.md detalla los límites y pruebas.
Nueva cadencia: parte1 APK para probar; después partes2–6 completas por entrega.


## Parte2 agrupada — 0.43

El usuario confirmó0.42. Sesiones opcionales cifradas por sitio, acceso oficial limitado
al login/importación propia y sin extraer cookies de otras apps. Cuerpos HTML visibles
Patreon/SubscribeStar con identidad y revisión; siempre parciales, no APIs privadas o
acceso a suscripciones inferido. FANBOX admite con sesión solo acceso no restringido
devuelto por la API; archivos de video se clasifican para medios nativos.
Compartir/pegar enlaces y filtros locales no hacen red. Búsqueda F95 con formulario
CSRF propio de cada consulta, resultados revisables sin consultar el hilo al añadir.
Pixeldrain individual desde enlace importado, consulta metadata/revisión/añadir,
SHA esperado comprobado en descarga completa/cola/cachés. Sin listas o evasión de gates.

Descargas optativas por servicio foreground dataSync con notificación, pausa,
propiedad única, recuperación de fragmento y manejo de timeout. Sin arranque por
boot/proceso/agenda, sin garantía contra batería/forzar detención. Room13/dependencias/
assets/4.so intactos, copia19 lee1–19, cuentas/medios fuera de ella. Se añaden permisos
normales de notificación/dataSync. Compartir text/plain es la única actividad nueva
exportada; no consulta al abrir. Parte1 sin cambios de fuente.

PARTE_2_FUENTES/GUIA_PARTE_2_043/PRUEBAS detallan límites, pruebas ejecutadas y las
compiladas sin dispositivo. Persisten restricciones reales de cuentas y servidores,
login federado externo, hosts no auditados, historial Patreon/SubscribeStar, contenido
solo JS, HLS/DASH/DRM y otras variantes no admitidas. No equivalencia universal de APIs
ni promesa de acceso completo a los nueve sitios. Siguientes partes3–6 tras la prueba.


## Parte3 agrupada — 0.44

ZIP64 de un volumen dentro de512MiB/10.000entradas/16MiBíndice/64MiBselección,
almacenar/Deflate/CP437 sinflagUnicode; no cifrado/volúmenes. 7z contraseña propia
solo cabecera plana, coders y KDF2²⁰ acotados; sinpersistencia. RAR5 sólido amplía
diccionario16→64MiB con motor/binarios/cuotas anteriores, total128MiB. RAR4 sólido,
RAR cifrado/volúmenes/RAR7 y ANSI ambiguo siguen noadmitidos; fuente del motor revisada.
EPUB NAV/NCX, títulos/jerarquía/fragmento, fallbackspine y fuentes ofuscadas estándar
omitidas sin descifrado; noCSS/inline/DRM. Búsqueda en texto visible; PDF search16páginas
por acción y contraseñaAPI35+, sinOCR. Info de pistas reales y subtítulos Unicode/
Windows1252 explícito con transporte content ligado,8MiB. Ocho contenedores propios
producen muestras por extractores Media3; esto no prueba códec/ABI/Binder de tablet.
Ver PARTE_3_FORMATOS.md y PRUEBAS.md. Las filas y avances antiguos conservan su alcance
histórico; esta actualización sustituye sus «sinZIP64/NCX/contraseñas7z/PDF» únicamente
con el subconjunto descrito. El resto de límites sigue abierto. Partes4–6 pendientes.


## Parte4 agrupada — 0.45

Estado actual de portabilidad: nuevo peach-local-exchange1, conserva estado19 más
metadatos/NFO/addedAt; hashes opacos en referencias tipadas de medios, mapa explícito
entre raíces/rutas/tamaños/familias (no prueba de bytes). Revisión3way por campo, bases
por origen, secuencias monótonas y rechazo de versiones antiguas/forks/basecambiada;
registros nuevos sin identidad inventada, ausencias sin borrar, relaciones/listas atómicas.
Diario privado de recuperación exacta y validación Room independiente; se mantienen
cuentas, originales y permisos. Docs PARTE_4_INTERCAMBIO/GUIA_PARTE_4_045/PRUEBAS contienen
límites y evidencia. La fila antigua de sincronización «pendiente» queda sustituida
solo por este intercambio manual bidireccional mediante archivos, no tiempo real,
medios, API de cloud o formato de retorno universal al ledger. Las copias clásicas
v1–19 y proyecciones SQLite/JSON originales anteriores permanecen.
Nube condicional SAF desde proveedor instalado/autorizado; no montajes o clientesAPI
115/CloudDrive/OpenList/PikPak/OneDrive. No se garantiza cada proveedor. Se conservan
fuentes/lectores/organización/Room13/copia19/permisos/deps/nativos/firma. Parte4requiere
prueba propia; partes5–6 siguen pendientes. No se declara paridad integral del original.


## Parte 5 / 0.46: interfaz y guardado directo

El usuario confirma 0.45. La parte 5 añade navegación sencilla, filtros desplegables,
temas claro/oscuro/sistema, seis colores, fondo e intensidad, tarjetas/lista y movimiento;
volumen por reproductor, sin alterar el volumen del sistema. Conserva herramientas y
lectores anteriores, Room 13, copias 19 e intercambio 1, transportes y nueve fuentes.

Guardado directo usa un documento nuevo del proveedor elegido en Android. No crea
copia completa en Peach, pero Drive/proveedor puede almacenarla temporalmente o subir
después. No es un cliente propio Google API, subida remota certificada, reanudación
directa ni trabajo automático. Hasta 2 GiB, una transferencia y cancelación al salir;
rotación conserva la operación y el diario permite revisar destinos incompletos. La
cola y preparación previas siguen disponibles. Limpieza explícita de cachés protege
leases de videos, preparaciones, cola, originales, cuentas y biblioteca. PARTE_5_INTERFAZ
y GUIA_PARTE_5_046 documentan límites. Falta validación en tablet/proveedor real y la
parte 6; no se declara paridad universal o proyecto terminado.

## Validación 0.47 / parte 6

No cambia admisión de formatos, modelos del original o contratos de las nueve fuentes.
Conserva datos, motores y dependencias de 0.46. Las correcciones de fondo/volumen/nube y
la comprobación con ocho muestras no amplían compatibilidad: un frame H.264/AAC a buffer
no certifica todos los perfiles, contenedores, salida física ni formatos pendientes.
Informe privado, ejecución manual, sin archivos/cuentas/red del usuario. La aceptación
de 0.46 la comunica el usuario; las pruebas propias y sus límites figuran en PRUEBAS.md.

0.47 corrige ejecución del asignador RAR en ABI Android y lectura ZIP64 mediante
Commons ya dependiente; se conservan límites de admisión y fuente libarchive.
1152 JVM/Robolectric en 161 clases, 0 fallos/errores/omitidas. Android: 73 compiladas, 72 ejecutadas y 72 aprobadas, 1 omitida(s), 0 fallos/errores; los 73 casos terminaron.
Emulador oficial Android 9/API28 x86_64 por software, sin KVM. No Samsung/ARM64, Drive/cuentas reales, batería o salida física certificadas. Android16/API36 se intentó sin completar arranque; no se ejecutaron tests allí.
