# F95: sesión opcional y enlaces masked — 0.37.0

Esta entrega adapta el protocolo del conector F95 del original fijo, con transporte
separado y revisión explícita. No convierte un enlace protegido o una carpeta Gofile
en un video ficticio. Las consultas públicas anteriores siguen disponibles sin sesión.

## Sesión propia opcional

Fuentes → selecciona F95 → **Sesión F95**. También está en **Enlaces F95** de una
publicación importada. La configuración admite la cabecera Cookie de una sesión propia
que ya tengas, hasta8KiB y64 pares; requiere xf_user o xf_session no vacía, sin saltos
de línea, cabeceras adicionales, duplicados o valores de cookie ambiguos. Puede pegarse
con prefijo Cookie:. Se conserva como un secreto, no como contenido de la publicación.

Es una importación avanzada opcional. La app no obtiene cookies de Chrome, no incluye
un navegador, no pide tu contraseña y no inicia sesión o resuelve CAPTCHA. No necesita
PC/Termux/servidor Peach para ejecutarse. Si no tienes esa cabecera, no necesitas buscarla
o enviarla al chat para seguir usando Peach; este bloque no proporciona todavía un
inicio de sesión nativo completo. La sesión puede caducar o no ser aceptada por el sitio.

Guardar no consulta internet ni certifica acceso. AES-GCM/AndroidKeyStore con alias y
archivo exclusivos, IV nuevo, AtomicFile y bloqueo entre instancias. Datos en
noBackupFilesDir, nunca en copia JSON/Intent/logs, sin fallback a texto plano. Diálogo
FLAG_SECURE, sin prellenar o guardar estado del campo, con limpieza al cerrarlo.
Borrar conserva publicaciones/archivos y la espera vigente. Cambiar/borrar invalida
revisiones de las fuentes F95 y limpia ETag/Last-Modified/fecha de validación, conservando
su caché para lectura local; la siguiente consulta necesita validación nueva.

Una sesión configurada se usa solo para GET de rutas de hilo admitidas en f95zone.to.
Sin sesión se conserva el transporte público anterior. Los redirects GET admiten el
mismo hilo/host, máximo3 saltos; no login, otro hilo, dominio o adjunto. Se comprueba
HTTPS/DNS público por apertura y no se importa Set-Cookie. Las respuestas HTML/cabeceras
se limpian de valores conocidos de sesión antes de entrar en caché. No se crean visitas
o fichas de medios por consultar una página. Sigue siendo la vista /latest, últimas24
respuestas reconocidas, no un historial remoto completo o el cuerpo íntegro de todo hilo.

## Resolver un enlace, revisar e incorporar

Abre el contenido guardado de una publicación F95 y pulsa **Enlaces F95**. La pantalla
lee referencias masked del contenido importado; abrir no hace red. Acepta únicamente
HTTPS f95zone.to/masked/segmento ASCII acotado, sin puerto, query, fragmento o rutas
codificadas ambiguas. Un enlace de otro proveedor, publicación o ruta no se consulta.

Selecciona uno y pulsa **Resolver enlace**. Requiere sesión propia disponible y Sin
conexión desactivado. Hace un único POST al enlace original con cuerpo fijo
xhr=1&download=1 y X-Requested-With: XMLHttpRequest, como el conector original. Cookie
solo a f95zone.to, sin Bearer Gofile/Rule34 ni headers de otra fuente. No sigue redirects
POST o consulta el destino devuelto. No ejecuta JavaScript, cambia huellas o reintenta.

Solo un JSON reconocido con status=ok y msg de URL admitida produce una revisión:

- Carpeta Gofile: referencia canónica; todavía no es un archivo reproducible.
- Archivo directo de attachments.f95zone.to bajo las rutas anteriores: puede usarse
  después con galería/video/guardar/cola nativos, según formato y permisos del servidor.
- pixeldrain.com/u/ID: solo referencia; no se añade descarga/API Pixeldrain en este bloque.

Otros destinos, URLs con credenciales/parámetros, eco de valores de sesión, error de
acceso o CAPTCHA conservan la referencia original y no descargan nada. Los formatos
de masked adicionales todavía no se admiten por inferencia.

Pulsa **Incorporar destino revisado → Incorporar** para añadirlo. Se validan publicación,
cuerpo, enlace original, sesión vigente y pausa de fuente; revisión obsoleta, sesión
retirada/cambiada, cancelación o máximo100 adjuntos conservan el contenido anterior.
No se borra la referencia masked, notas, título, otros adjuntos o archivos guardados.
Duplicado no crea otra fila. Reimportar la fuente conserva destinos ya resueltos.

Para Gofile, el botón **Enlaces Gofile** abre la consulta independiente de0.36, solo con
publicaciónID. Necesita su propia clave/cuenta apta según la API Gofile. La cookie F95
no se envía al API Gofile ni al archivo; las funciones y límites Gofile anteriores siguen.
Resolver e incorporar enlaces no descargan medios. Videos o imágenes directos dentro
del hilo ahora se clasifican correctamente, incluido img src admitido; no se amplían
hosts de imágenes/archivos o sus permisos usando la sesión F95.

## Esperas, cancelación y límites

Sin conexión bloquea Resolver. Pausar la fuente bloquea consultas y aplicación revisada.
Salir cancela la consulta; rotar conserva un único trabajador, sin aplicación o navegación
automática. HTTP429 se procesa antes de leer el cuerpo, persiste una espera F95 de hasta24h
por respuesta y afecta también sus fuentes de hilo. Sigue vigente tras cerrar, cambiar o
borrar sesión; no bloquea FANBOX, Gofile u otros proveedores. No hay retry automático.

401/403 no prueban por sí solos una contraseña incorrecta: sesión vencida, permiso o
verificación pueden impedir acceso. Diagnósticos sin respuesta cruda, cookie o URL con
secretos. Solicitudes15s de conexión/lectura y lectura60s, HTML/JSON2MiB,20.000 nodos HTML
previos y32 niveles JSON para resolver. No imágenes/thumbnails o archivos por precarga.

Room13 y copia18, lee1–18, se conservan. f95MaskedOriginal es metadato opcional de un
adjunto ya admitido; no añade una ruta descargable nueva o secreto a la copia. Se valida
al restaurar. Una copia18 de esta versión mantiene el contrato anterior de URLs y campos
obligatorios. No cambio de dependencias/permisos/servicios/proveedores. Nueva pantalla
F95LinksActivity no exportada. Nueve fuentes; Kemono/Coomer/SimpCity excluidos.

## Evidencia y límites de la validación

Referencia original:
https://github.com/peach-mitao/peach/blob/de22796c04919aaa057d77930c33c81313765569/src/peach/follow_sources.py

Snapshot original:
https://github.com/peach-mitao/peach/blob/de22796c04919aaa057d77930c33c81313765569/docs/reference-snapshots/f95-masked-gofile-media.md

Se auditó F95ZoneConnector: cookie opcional en /latest y resolución POST independiente,
sin enviar sesión a destinos. El snapshot de28-agosto-2026 registra ese protocolo y
CAPTCHA como posible resultado. La comprobación actual de
https://f95zone.to/assets/js/masked.js devolvió HTTP200 pero195 bytes HTML de Site
Unavailable, no el JS del snapshot de1255 bytes. No se considera protocolo vivo verificado
por ese HTTP200. Huellas y resultados en evidence/0.37.0/audit-resources.json.

Pruebas con páginas/JSON/cookies propios y HTTPS/DNS simulados. No se usó una sesión del
usuario, inició sesión real, hizo un POST masked real o descargó medios upstream.
PRUEBAS.md documenta resultados; pruebas Android compiladas separadas no equivalen a
ejecución en SM-X230. Cuentas/CAPTCHA, versión actual del sitio, rutas adicionales,
inicio de sesión nativo completo y validación física siguen pendientes.
