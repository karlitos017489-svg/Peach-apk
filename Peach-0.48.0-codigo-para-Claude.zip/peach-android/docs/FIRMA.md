# Firma de las compilaciones de desarrollo

0.2.0, 0.3.0, 0.4.0 y 0.5.0 usan com.peach.local y el mismo certificado debug. Huella SHA-256:

```
9fc537c4c8d0461a8565414c7a30169e592120cd314b500bee7c707f8a748484
```

La clave de desarrollo se conserva por separado como respaldo privado con el nombre
Peach-Local-clave-firma-debug.jks. No forma parte de este repositorio, del ZIP de código
ni del APK, y no debe publicarse. Se necesita la clave original para que siguientes
compilaciones se instalen como actualización conservando la aplicación.

El Gradle de esta entrega usa la configuración debug estándar del SDK. Otro equipo
o un runner de CI puede generar su propio certificado; obtener un APK desde Actions
no garantiza que actualice sobre la instalación del usuario. Antes de distribuir una
actualización se debe comprobar su huella con apksigner y el versionCode.

Un release público requiere una estrategia de firma estable distinta de esta etapa
de depuración. No se creó una clave de release ni se publicó la aplicación en una
tienda. El respaldo actual permite continuar las actualizaciones de desarrollo.

Para seleccionar explícitamente el respaldo original al compilar, defina
PEACH_DEBUG_KEYSTORE con su ruta privada fuera del repositorio. Si no está definida,
Gradle conserva la configuración debug estándar del SDK. Nunca incluya el archivo
JKS en el código ni cambie de clave para una actualización. La configuración usa
las credenciales estándar de Android Debug; lo privado es el material de la clave.
