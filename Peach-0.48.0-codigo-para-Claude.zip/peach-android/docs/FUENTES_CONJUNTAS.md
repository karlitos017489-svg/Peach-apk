# Cuatro fuentes juntas · 0.26.0

El usuario pidió una sola entrega para probar las fuentes restantes juntas y excluyó
también SimpCity. El selector queda con nueve proveedores: FANBOX, Patreon, SubscribeStar,
Pawchive, cum.st, Rule34 Paheal, Rule34.xxx, Rule34Video y F95zone. Kemono, Coomer y
SimpCity están excluidos del selector, de las rutas de transporte y del plan vigente.
Gofile es un origen de medios en el original, no otra fuente de seguimiento incorporada.

No se declara compatibilidad completa por añadir estos cuatro conectores. Tienen
consulta/revisión/importación implementadas y pruebas con datos propios. Las consultas
reales desde este entorno no recuperaron páginas reconocibles de las tres fuentes
públicas; Rule34.xxx no se consultó porque no hay clave del usuario. No se prueba caída
global o fallo de la tablet, ni se presenta una fixture como respuesta real del sitio.

## Cómo añadirlas

Instala sobre0.25 sin desinstalar. Fuentes → Añadir fuente. Guardar/abrir no hace
peticiones: pulsa Consultar novedades cuando quieras conectarte. Revisa/importa para
conservar resultados en Publicaciones. Lo importado se lee sin conexión.

| Fuente | Referencia de entrada | Alcance de esta entrega |
|---|---|---|
| Rule34 Paheal | Una etiqueta exacta o URL /post/list/etiqueta/1 | Tarjetas/etiquetas, páginas anteriores, detalle seleccionado y archivo directo admitido |
| Rule34.xxx | Una etiqueta exacta o búsqueda de lista del sitio, sin credenciales en la URL | API oficial con tu clave,24 filas/página, etiquetas y archivos de rutas admitidas; no fecha de subida inventada desde change |
| Rule34Video | Autor o URL /models/autor/ | Listas paginadas, duración/fecha relativa declaradas, detalle VideoObject consultado explícitamente y medios directos admitidos |
| F95zone | Número del hilo o URL /threads/titulo.ID/ | Últimas24 respuestas públicas visibles de /latest, citas eliminadas, texto/enlaces/adjuntos; sin historial remoto de todo el hilo |

Paheal y Rule34.xxx no tienen un título narrativo por publicación: se muestra la
etiqueta seguida del ID. No se deduplica una obra por coincidir las etiquetas. En
Rule34Video, una fecha relativa queda como texto y la fecha de publicación desconocida;
no se convierte una estimación en una fecha exacta. En F95 se usa datetime si existe.

Consultar cuerpo en Paheal/Rule34Video es otra petición seleccionada, sin sondear todos
los elementos de la página. Revisa/importa otra vez para conservar ese detalle; una
lista posterior no sustituye el detalle importado. Rule34.xxx no añade una falsa
consulta de cuerpo: su ficha contiene los metadatos DAPI. F95 conserva texto público
acotado, sin sesión, descifrado de masked o expansión automática de enlaces externos.

## Clave propia de Rule34.xxx

La documentación oficial exige user_id y api_key. Genera/consulta tu clave desde las
opciones de tu cuenta en el sitio oficial. En la app, selecciona una fuente Rule34.xxx
y pulsa Credenciales API. No necesitas enviarla por el chat ni usar un servidor Peach.
La clave es un token opaco ASCII visible hasta512 caracteres; se codifica como parámetro
y no se inventa una longitud mínima. El user_id se valida como entero positivo.

Se cifra con AES-GCM y una clave AndroidKeyStore. El archivo cifrado queda en el
directorio Android excluido de copias, con formato autenticado, IV nuevo por escritura,
escritura atómica y exclusión mutua entre instancias. No hay fallback a texto plano.
La copia JSON no contiene claves, archivo cifrado o sesiones. Reinstalar o cambiar de
tablet puede exigir volver a configurar la clave; restaurar la copia no la reconstruye.
El diálogo oculta la clave, evita guardarla en el estado de la vista y usa FLAG_SECURE.
Borrar clave conserva publicaciones y archivos. Solo se usa una clave local para ese
sitio. Cambiarla invalida las revisiones anteriores de sus fuentes.

El sitio exige parámetros de consulta para autenticar la DAPI: solo se envían al host
API exacto, de forma transitoria. No se guardan esas URLs en Room, copia, logs o informes.
No se reenvía la clave al CDN, a otras fuentes o a redirecciones. Los errores del
transporte/API se normalizan para ocultar la dirección con credenciales. API429 aplica
espera a todas las fuentes de etiquetas que usan esa clave, sin cambiar de clave o
reintentar automáticamente. F95 no recibe claves, cookies o contraseña de este proveedor.

## Guardado de archivos

Guardar adjunto es explícito y usa el selector Android. Hasta128MiB por archivo,
120s total y15s de conexión/lectura. Temporal privado, longitud HTTP, SHA-256 calculado,
cierre/limpieza en error o cancelación; después se copia al destino. El proveedor SAF
puede dejar un destino vacío/parcial al fallar y no se promete atomicidad universal.
Actualizar o autorizar la carpeta destino incorpora el archivo guardado al catálogo.

Se admiten únicamente HTTPS, sin puerto, credenciales, fragmentos o parámetros, con
hosts/rutas acotados:

- Paheal: r34i.paheal-cdn.net/aa/bb/md5, prefijo de directorios coherente.
- Rule34.xxx: api-cdn.rule34.xxx/images/directorio/md5.ext compatible.
- F95: archivos con extensión compatible en attachments.f95zone.to, sin traversal.
- Rule34Video: /get_file/ID/...mp4 o webm en rule34video.com o boomio-cdn.com exactos.

Redirecciones de estos archivos solo a la misma URL exacta. Nodos adicionales, rutas
firmadas/con parámetros, streaming adaptativo, JavaScript/enlaces cifrados, servicios
de archivos externos o recursos que exijan sesión quedan como referencias. No se
abre un navegador integrado ni se inventa un servidor obligatorio. F95 masked no se
resuelve, ni se hace POST o se adquieren cookies automáticamente.

El SHA calculado es una huella del archivo recibido, no una comparación contra un
SHA esperado publicado por estas fuentes. Los hashes MD5 de referencias no se anuncian
como identidad verificada de bytes. Pawchive mantiene su comprobación SHA esperado.
Se usa extensión declarada/MIME o URL cuando está disponible, incluidas las tarjetas
Paheal antiguas data-ext y las actuales data-mime; desconocida queda bin,
sin adivinar el formato. Un detalle Paheal conserva una extensión ya conocida si la
misma URL no vuelve a declarar su tipo. El visor local depende del formato/códec.

## Contratos y conservación

Referencia original fija: peach-mitao/peach,
de22796c04919aaa057d77930c33c81313765569, follow_providers.py/follow_sources.py.
Rule34XxxConnector usa DAPI; Rule34VideoConnector usa HTML KVS y VideoObject JSON-LD;
Rule34PahealConnector usa las tarjetas shm-thumb y detalle main_image; F95ZoneConnector
usa /latest y artículos XenForo con data-content=post-ID. No se ejecutan sus scripts.
Se adapta un subconjunto Android propio; no el servidor, sus secretos o un WebView.

JSON/HTML2MiB y UTF-8 estricto, máximo20.000 nodos,100 filas HTML y24 DAPI/F95.
Caché1MiB; texto lista4000/detalle200000; máximo100 adjuntos. Siempre parcial.
Paheal y Rule34Video avanzan una página por acción, hasta5000.404 anterior o un
contenedor vacío reconocible termina y conserva la última caché. Un desafío/login HTML
sin estructura reconocible no se trata como historial vacío. API usa pid0..4999,
limit24; corta/vacía anterior termina,400/404 es error. 304 requiere caché compatible.
F95 solo /latest, con redirecciones HTTPS al mismo hilo; no a otra cuenta/host/hilo.

UUID por proveedor/ref/post, fichas personales y detalles anteriores conservados,
pausa/cancelación/revisión vigente y rollback de copias. No se crea un documento
reproducible por consultar una URL. Room13 intacto; copia16 lee1–16,8MiB. Versiones
anteriores rechazan16 antes de modificar estado. Sin permisos/dependencias nuevos.
Las pruebas Android, incluidas las de Keystore, se compilan pero no se ejecutaron.

Pendientes: validación online y Android real, sesiones/cuentas F95, masked/Gofile,
galerías multiproveedor, vídeo remoto, variantes/nodos adicionales, autocomplete,
clasificación avanzada, filtrado de compilaciones/recursos y deduplicación canónica
del original; lotes/reanudación/>128MiB. El proyecto permanece abierto.

Documentación oficial de la DAPI: https://api.rule34.xxx/ . Esta app no muestra anuncios,
no tiene paywall y no implementa rotación o compartición de claves para eludir límites.
