# cum.st (OnlyHaven) · 0.25.0

Quinto proveedor independiente. **Implementado con pruebas propias; validación online
pendiente.** La documentación oficial indexada anuncia API pública de lectura; no se
recuperó el esquema completo. Se auditó el código del cliente gallery-dl1.32.18, que
referencia esa documentación y utiliza lista/detalle, captions y variantes de archivos.
La petición directa de producción desde este entorno rechazó el formato recibido.
No prueba caída global ni funcionamiento real en Android. source-api-audit.json y el
runner scripts/run-cumst-smoke.py conservan la procedencia y el alcance de la prueba.

## Uso

Fuentes → Añadir fuente → cum.st (OnlyHaven) · API pública. Introduce servicio/ID o la
página HTTPS del creador, por ejemplo patreon/123 (ID sintético), o
https://cum.st/creators/patreon/123 . Servicios admitidos: patreon, onlyfans y fansly.
Guardar/abrir no consulta red. Consultar novedades solicita una página. Revisa e importa
para conservarla en Publicaciones. Consultar cuerpo es otra petición explícita: revisa
e importa de nuevo. Una lista posterior no sustituye el cuerpo detallado guardado.

Guardar adjunto → elige el adjunto propuesto → destino del selector Android. Se propone
una variante por adjunto, la de mayor bytes declarado por la fuente; no se certifica que
sea el original, la mejor calidad o el formato reproducible. Tras guardar, Actualizar o
añadir la carpeta destino lo incorpora al catálogo. Un metadato no crea un documento
reproducible ficticio. Lo ya importado/descargado es utilizable offline según su formato.

## Contrato y límites

- HTTPS exacto cum.st, API canónica de lista/detalle, sin cookies, cuentas, credenciales,
  JavaScript, WebView o servidor Peach. Sin redirección API. No headers FANBOX.
- Lista /api/v1/servicio/user/ID/posts?o=0&n=50; siguiente o=50,100..., máximo5000 páginas.
  Envelope posts:[...], hasta50. Se usa el orden predeterminado de la fuente, sin
  filtros/sort inventados. Página corta/vacía anterior termina; error400/404 no se
  transforma en fin confirmado y conserva la página pendiente/caché anterior.
- JSON2MiB, UTF-8 estricto, conexión/lectura15s, lectura total60s. 304 requiere página
  local compatible;429 impone cooldown sin borrar candidatos. Revisión invalida si
  cambia la fuente/biblioteca. No agenda, sondeo, reintento automático o crawling masivo.
- Identidad: service requerido e igual al seleccionado; creatorId, cuando existe, debe
  coincidir. Si falta/null se usa el contexto de la ruta solicitada, como en el cliente
  auditado. Post ID ASCII hasta128; creador hasta64, strings preservados sin convertir
  grandes IDs a float. Duplicados/identidades ajenas rechazan la página completa.
- captionHtml a texto nativo sin scripts/nodos ocultos conocidos; href HTTPS se muestra
  como referencia, no se ejecuta. caption alternativo conserva texto literal. Texto de
  lista4000/detalle200000 con aviso de recorte. Siempre partial: no afirma cuerpo completo,
  incluye embeds/inline o acceso al servicio original. Fecha published Unix segundos o
  fecha textual compatible; added (fecha de importación) no se inventa como publicación.
- Hasta100 adjuntos y32 variantes cada uno; formato estructural inválido rechaza la
  consulta. locked=true nunca se descarga. Ausentes/sin variantes o rutas no admitidas
  se omiten con aviso de parcialidad; no se sintetizan URLs arbitrarias. Duplicados se
  reúnen por URL. El nombre visible de140 caracteres no es una ruta local.
- Medios: https://e1.cum.st/media/{storageKey}/{variant.name}, segmentos ASCII acotados,
  sin traversal, porcentajes, parámetros, fragmentos, credenciales, puertos o alias.
  storageKey máximo300 caracteres/8 segmentos; variant.name un segmento máximo160.
  Otros formatos/servidores quedan pendientes. No basta que un host termine en cum.st.
- Guardado individual hasta128MiB, límite total120s, longitud HTTP y SHA-256 calculado,
  temporal privado y SAF tras finalizar. **No se conoce un hash esperado de la fuente:**
  el checksum calculado no certifica identidad contra un hash externo. Pawchive conserva
  su comprobación de SHA esperado. No headers FANBOX a estos medios. Redirección solo
  a la misma URL exacta, no a otro archivo, nodo o proveedor.
- Cancelación/error limpia temporales y cierra flujos. El proveedor SAF puede dejar un
  destino vacío/parcial; no se declara éxito ni se promete escritura atómica universal.

## Datos y trabajo pendiente

UUID por proveedor/servicio/creador, publicaciones distintas de Pawchive aunque coincidan
IDs. No alias o migración automática desde Coomer. Kemono y Coomer excluidos del plan,
selector y transporte. Fichas personales/cuerpos anteriores se conservan al reimportar.
No cambios de Room13, permisos o dependencias. Copia15 lee1–15,8MiB; versiones anteriores
de la app rechazan15 antes de escribir. Las rutas true de descarga se validan también
al restaurar, y la caché cum.st no acepta adjuntos de otra fuente.

Pendiente: comprobar API/medios reales y comportamiento nativo; esquema oficial completo,
búsqueda global/directorio de creadores, perfiles/links, versiones de posts, galerías y
vídeo remoto cum.st, inline/embeds, nodos/rutas adicionales, cuentas/DMs y marcadores del
sitio, lotes/reanudación/>128MiB. El APK no incorpora gallery-dl, Python o su código; se
consultó como evidencia de protocolo y se implementó el subconjunto en Java propio.
La referencia original fija sigue de22796c04919aaa057d77930c33c81313765569; cum.st es
una adaptación adicional solicitada por el usuario. No se declara paridad completa.


## Actualización0.35 — alternativas de video

El contrato auditado y su alcance público siguen iguales. Ahora se mantienen variantes
de video compatibles en vez de elegir una sola por bytes: primero no preview, altura
numérica p reconocida en nombre y tamaño declarado. Se evita preferir un póster mayor.
Se omiten variantes locked y manifiestos; nombres/bytes/rutas siguen el contrato existente,
sin suponer dimensiones nuevas. Máximo100 adjuntos: principales de cada original primero,
extras después con aviso si no caben. Imágenes/otros conservan una variante principal.
Consultar versiones recupera un post por la API ya usada, revisa antes de aplicar y no
consulta medios. Room13/JSON17, alternativas opcionales dentro del cuerpo. Las menciones
a copia15/límite128MiB/galería-video/lotes pendientes arriba describen0.25; los bloques
posteriores implementaron copia17, guardado2GiB, galería, video, cola y streaming con sus
límites documentados. Esquema oficial completo/API real/cuentas siguen pendientes.
