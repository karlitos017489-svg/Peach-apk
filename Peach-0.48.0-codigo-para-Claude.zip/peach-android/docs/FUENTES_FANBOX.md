# Fuentes FANBOX públicas — Peach Local 0.13.0

Esta es la primera fuente operativa del APK. Menú → Fuentes de contenido permite
registrar un creador FANBOX, consultar novedades/páginas antiguas y revisar antes
de incorporar publicaciones. La biblioteca local sigue funcionando sin conexión.

La fuente utiliza HTTPS directamente desde Android. No requiere Windows, Termux,
un host Peach o navegador integrado. Se añade el permiso normal INTERNET; las
consultas y descargas se inician únicamente por una acción del usuario. No hay
consulta al abrir la biblioteca, servicio programado, cuenta conectada ni reintento
automático. No se añadieron dependencias de ejecución.

## Uso

1. Fuentes de contenido → Añadir fuente. Escribir el identificador o la URL del
   creador; por ejemplo `official` o `https://official.fanbox.cc/` para el canal
   oficial de la plataforma. Elegir nombre e identidad local opcional. Guardar
   registra la configuración y no consulta la red.
2. Consultar novedades solicita una página de hasta 10 publicaciones del creador.
   Se admiten solo publicaciones con isRestricted=false y feeRequired=0 explícitos.
   No se importan los títulos de las otras publicaciones como si fueran gratuitas.
3. Tocar una publicación muestra el resumen guardado, fuente, fecha y si falta cuerpo.
   Consultar cuerpo solicita su detalle público. Texto y lista de adjuntos quedan en
   la página pendiente local; no se descargan imágenes automáticamente.
4. Importar página revisada incorpora las publicaciones nuevas compatibles y sus
   cuerpos consultados. Las fichas existentes conservan título, notas, estado,
   identidad y documento. Un cuerpo detallado anterior se conserva si la consulta
   nueva solo contiene el resumen de lista.
5. Página más antigua usa los cursores reales devueltos por FANBOX. Conserva el
   índice mientras avanza y no inventa offsets. Consultar novedades inicia de nuevo
   el recorrido de historial. La página pendiente es la última consultada: revisar
   e importar antes de reemplazarla por otra si se quiere conservar sus registros.
6. Publicaciones → ficha → Organizar → Leer contenido consultado abre la copia
   importada sin consultar la red. Se puede leer aunque se haya eliminado la fuente.
7. Guardar adjunto abre el selector Android para crear un archivo. La descarga solo
   comienza tras elegir destino. Se descarga primero a un temporal privado, con
   límite y comprobación de longitud/SHA-256; después se copia al documento elegido.
   Para abrirlo en la biblioteca, actualizar una carpeta ya autorizada o añadir la
   carpeta destino. Guardar no crea una tarjeta o URI de reproducción ficticia.

Elegir almacenamiento interno o microSD para conservar los archivos físicamente
sin conexión. Un proveedor cloud del selector puede necesitar su propia conexión.

## Contenido compatible y límites

El lector de FANBOX conserva texto de publicaciones text/image/file/article y los
bloques de texto/imagen/archivo en orden. Los archivos pueden ser PDF, comprimidos,
imágenes o videos: guardarlos no garantiza que el lector/códec Android los admita.
Las publicaciones video, embeds, HTML y bloques no modelados se muestran como texto
con indicación parcial; no se ejecutan scripts, HTML, iframes o reproductores externos.
No hay reproducción remota automática ni álbum de imágenes remotas en esta etapa.

Se listan adjuntos HTTPS. Solo se descargan directamente desde downloads.fanbox.cc
y pixivfanbox.akamaized.net. Otros hosts quedan como referencias. Los nombres se
limpian de separadores/controles, se acotan y conservan su extensión declarada. Nunca
se convierten en una ruta privada. No se extraen comprimidos descargados automáticamente.
Los medios adjuntos no forman parte de la copia JSON.

| Límite | Valor |
|---|---:|
| Fuentes locales | 100 |
| Publicaciones nativas | 10.000 |
| Respuesta JSON | 2 MiB |
| Página pendiente normalizada | 1 MiB por fuente |
| Índice de páginas | 5.000 cursores, máximo 1 MiB |
| Texto por cuerpo | 200.000 unidades UTF-16, sin cortar un par sustituto |
| Adjuntos por cuerpo | 100 |
| Descarga seleccionada | 128 MiB |
| Espera de conexión / lectura | 15 s cada una |
| Bucle de lectura JSON / descarga | 60 s / 120 s, más conexiones y redirecciones acotadas |
| Redirecciones | Hasta 3, manteniendo los hosts admitidos |
| Copia personal completa | 8 MiB |

Se rechazan respuestas fuera de formato, demasiado grandes y detalles que ya no
sean públicos/gratuitos o pertenezcan a otra publicación/creador. Un error conserva
la página anterior y no avanza el cursor. HTTP429 guarda un plazo Retry-After acotado,
sin reintentar automáticamente. Cancelar desconecta la solicitud activa. Una fuente
pausada no consulta, aunque su caché sigue disponible. La creación y lectura local de
fuentes no contactan al proveedor.

Los temporales privados se eliminan al terminar o fallar, y los huérfanos de una
terminación del proceso se limpian al volver a cargar Fuentes. Los temporales activos
se protegen de esa limpieza. Si el proveedor falla o el proceso termina mientras se
copia al documento de destino, puede quedar un archivo incompleto en ese destino;
no se elimina automáticamente un documento del usuario. No se afirma atomicidad de
escritura en cualquier proveedor SAF o cloud. Una red lenta también puede requerir
volver a seleccionar el destino.

## Persistencia y revisión

Room v12 añade follow_sources y publication_content. Las tablas anteriores no se
recrean. La fuente conserva creador/nombre/identidad, pausa, revisión, página pendiente,
cursores y diagnóstico. Cada cuerpo importado conserva texto, adjuntos, estado parcial
y fecha real de su consulta; consultar otra publicación no cambia la fecha de los
cuerpos que no se consultaron. Borrar una fuente conserva publicaciones/cuerpos,
retirando su FK de fuente. Borrar una publicación elimina únicamente su cuerpo y las
relaciones correspondientes, conservando medios y obras deseadas.

La revisión se recalcula en la transacción al aplicar. Cambios en fuente, cuerpo o
ficha obligan a revisar de nuevo. Una publicación ya importada con igual proveedor,
ref y externalId reutiliza su UUID. Varias fichas con esa misma identidad se muestran
como conflicto; no se fusionan automáticamente. Las filas nuevas usan UUID estables
por creador e ID externo. Dos títulos iguales no se convierten en una misma obra.

Copias v9 incluyen fuentes y contenido importado; leen v1–v8. Las copias anteriores
conservan la configuración y cuerpos existentes. V9 valida referencias y colecciones
con rollback completo. Una colección de cuerpos vacía en v9 limpia solo los cuerpos
de publicaciones incluidas en esa copia. Restaurar fuentes no inicia consultas.
Los permisos SAF y los medios se siguen respaldando por separado.

## Contrato público verificado y alcance real

Se inspeccionaron follow_providers.py, follow_sources.py y fanbox.py del original
peach-mitao/peach, commit de22796c04919aaa057d77930c33c81313765569. Los endpoints son
los utilizados por su conector: post.listCreator, post.paginateCreator y post.info.
No se incorpora el backend Python, CurlCffi ni impersonación de un navegador.

El 25 de octubre de 2026 se ejecutó SourceHttp/FanboxConnector con HTTPS de JDK sobre
el creador oficial: 10 candidatos gratuitos, 34 páginas de historial, cuerpo article,
6 adjuntos y descarga de muestra de 3.099.329 bytes verificada por SHA-256. El artículo
y la imagen no se empaquetan en las pruebas o entregables. La muestra se borró al
terminar. Solo se conservan conteos, hashes, ID público y marca de tiempo.

Esta comprobación confirma el contrato de ese momento desde el entorno de desarrollo;
no certifica la pila TLS, el selector de documentos ni una descarga en el SM-X230.
Las pruebas instrumentadas de persistencia siguen compiladas y pendientes. Un bloqueo
o cambio de API posterior puede hacer que la fuente requiera una actualización.

Referencias primarias consultadas:
- https://official.fanbox.cc/
- https://fanbox.pixiv.help/hc/ja/articles/360000230401
- https://api.fanbox.cc/post.listCreator?creatorId=official&limit=10
- https://api.fanbox.cc/post.paginateCreator?creatorId=official

## Repetir la comprobación opcional de desarrollo

Con JDK17 y el JAR externo org.json:json:20240303 de Maven Central (SHA-256 fijado por
el script), ejecutar:

```
python3 scripts/run-fanbox-smoke.py --json-runtime /ruta/json-20240303.jar --creator official
```

Añadir `--download-first` comprueba una descarga pública temporal, que después elimina.
JSON-java se usa solo por este comando, no es una dependencia del APK. El JDK restringe
Origin por defecto y el comando habilita ese encabezado para enviar la petición.
Esa propiedad solo afecta a la comprobación JDK, no se establece en el APK; la
validación del transporte en Android real sigue pendiente. No se desactiva TLS.
PEACH_JAVA_TRUST_STORE permite indicar el almacén CA del entorno de desarrollo.
HTTPS_PROXY se usa solo cuando ya está configurado en dicho entorno. Las pruebas
unitarias normales son sintéticas y no hacen estas consultas externas.

## Pendiente del objetivo completo

FANBOX autenticado/de suscripción, otros proveedores del original, seguimiento
programado, reanudación de descargas parciales, selección en lote, galería remota,
adjuntos externos/Gofile y agrupaciones avanzadas siguen pendientes. Tampoco se ha
cerrado la validación Android real, los formatos restantes o las demás diferencias
registradas en COMPATIBILIDAD_ORIGINAL.md. Esta entrega no equivale a todo Peach.
