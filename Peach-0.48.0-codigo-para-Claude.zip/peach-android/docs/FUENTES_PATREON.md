> Actualización posterior del usuario (25 de octubre de 2026): confirmó funcionamiento
> general de 0.15.0 y comunicó que las consultas de Patreon volvieron a mostrar
> resultados al desactivar su VPN. Por tanto, el rechazo previamente comunicado
> ya no permanece reproducido en su uso actual. La relación con la VPN es una
> observación del usuario, sin captura de tráfico o diagnóstico del servidor.
> No se implementó transferencia de cookies ni una solución de CAPTCHA.
> No se infieren cuerpos completos, suscripciones, adjuntos Patreon, todas las
> funciones individuales o instrumentación ejecutada. Se conserva el historial
> de la incidencia y el alcance limitado del conector.

## Incidencia histórica; actualización posterior indicada arriba

> Incidencia posterior en la tablet (25 de octubre de 2026): el usuario comunicó
> «Dice que la fuente denegó el acceso público», al consultar Patreon/panpiano.
> Chrome en la misma tablet abrió el perfil después de completar un CAPTCHA.
> El rechazo de la app corresponde a HTTP401 o403; la versión0.14 no los distingue.
> Es compatible con la verificación humana observada, pero no se capturaron los
> encabezados Android para confirmar el proveedor del CAPTCHA o su causa exacta.
> Resolverlo en Chrome no transfiere su sesión al transporte de Peach.
> Patreon queda bloqueado en ese entorno y no se registra aceptación general de0.14.
> Una comprobación JDK del mismo creador recuperó una tarjeta pública; no sustituye
> el resultado de Android. No hay solución de CAPTCHA implementada o verificada.

# Patreon público — Peach Local 0.14.0

Menú → Fuentes de contenido → Añadir fuente permite elegir **Patreon · tarjetas
públicas**. El conector incorpora las tarjetas que el sitio entrega a un visitante
anónimo. Pueden ser adelantos de publicaciones con acceso restringido: una tarjeta
no acredita acceso al cuerpo, a adjuntos o a una suscripción.

El original también limita su conector Patreon a tarjetas del HTML público. Su API
oficial de posts requiere autorización/scopes de creador; esta entrega no conecta
cuentas, no introduce cookies/tokens y no llama a APIs privadas o a la API v1 retirada.
No hay navegador integrado, JavaScript ejecutado o dependencia de un host Peach.

## Uso

1. Añadir fuente → elegir Patreon. Introducir el nombre/URL del creador; por ejemplo
   `patreonforcreators` corresponde al canal oficial Patreon for Creators. Se admiten
   páginas con /cw/ y la forma numérica /user?u=ID; el sitio puede redirigir esta última
   a su URL canónica. Nombre e identidad local son opcionales/seleccionables como en FANBOX.
2. Guardar solo registra la fuente. Consultar novedades pide su página pública por
   HTTPS. Un lector HTML nativo extrae las tarjetas y marca cada una como parcial.
3. Revisar e importar la página conserva sus tarjetas en Publicaciones y su texto
   como contenido consultado. Las fichas existentes mantienen nombre, notas, estado,
   documento e identidad. Solo se actualiza la copia del adelanto público.
4. Leer contenido consultado permite ver esa tarjeta sin conexión. No se ofrece
   Consultar cuerpo ni Guardar adjunto para Patreon. Tampoco se anuncian páginas
   históricas que este conector no implemente.

La biblioteca local sigue disponible sin conexión. Las consultas de fuentes solo
se inician con sus controles explícitos, sin agenda o reintentos automáticos.
Los controles de FANBOX, su historial, sus cuerpos gratuitos y sus descargas
individuales se mantienen; FUENTES_FANBOX.md conserva ese alcance.

## Lectura y procedencia

Se reconocen enlaces de publicaciones antiguas /posts/slug-ID y actuales
/CREADOR/posts/slug-ID, incluida la variante /cw/CREADOR/posts/slug-ID. Se validan
host, ruta, creador e ID, rechazando consultas/credenciales en la URL del post y
rutas de cuenta/API. Los slugs pueden contener caracteres Unicode.

Se analiza HTML servido públicamente, incluidos fragmentos de transmisión del
servidor que el sitio coloca temporalmente en contenedores div hidden con id S:...
antes de mostrarlos en su página. Solo se usa su HTML de tarjetas. Scripts, JSON de
bootstrap/sesión, plantillas y nodos ocultos ordinarios se excluyen. No se ejecuta
el código que el sitio utiliza para insertar esos fragmentos. Las tarjetas no se
convierten en cuerpos completos ni sus imágenes de portada en adjuntos descargables.

Varios enlaces de una misma tarjeta se deduplican por ID. Se prefiere un título de
su contenedor próximo con un único h3; no se toma el encabezado de un grupo con varias
tarjetas. Si falta título, se usa el slug/ID como etiqueta, sin inferir una obra.
Fecha exacta solo si hay un time datetime válido; expresiones como Yesterday o un
mes/día incompleto no se convierten en fechas exactas. En esos casos figura desconocida.

Se admiten hasta 100 tarjetas, 5.000 enlaces inspeccionados y 2 MiB de HTML; los
títulos se acotan a 300 caracteres y el adelanto a 4.000 más el aviso de parcialidad.
No se leen documentos enlazados o recursos de la página al analizar HTML. Si el sitio
no entrega una página canónica reconocible o no hay tarjetas reconocibles, se conserva
la página pendiente anterior. Puede tratarse de ausencia de tarjetas, rediseño o bloqueo;
no se afirma que el creador no tenga contenido.

## Dos proveedores y compatibilidad

FANBOX y Patreon usan adaptadores separados y una página normalizada común. La clave
de fuente y la de publicaciones incluyen el proveedor; el mismo texto de creador/ID
en dos sitios no los fusiona. Los UUID FANBOX de 0.13 no cambian. Una referencia
externa importada equivalente en su proveedor reutiliza el UUID de esa publicación;
varias fichas equivalentes se mantienen como conflicto, sin fusión automática.

Se actualiza el resumen cuando vuelve a llegar un resumen de su mismo proveedor. Un
cuerpo detallado guardado se conserva si solo llega una tarjeta/resumen posterior.
Los datos personales de la ficha siguen separados del contenido de la fuente.
La revisión se recalcula transaccionalmente al aplicar.

Room continúa en v12: las columnas ya distinguen provider/ref y no se necesita una
migración de tablas. La copia personal pasa a v10 y contiene ambos proveedores;
se leen v1–v9. Las copias v1–v8 conservan fuentes/cuerpos actuales; v9 conserva sus
reglas previas de restauración para fuentes y cuerpos incluidos. Una fuente ajena
que no está en la copia no se elimina; una colección de cuerpos vacía sí limpia
los cuerpos de publicaciones incluidas según esas reglas. Restaurar no consulta la red.
El límite completo de copia permanece en 8 MiB y nunca incluye medios o permisos SAF.

## Dependencias y comprobación

Se añade una dependencia de ejecución: jsoup1.23.2, MIT, Java8+, analizador HTML
compatible con Android con desazucarado. Se utiliza únicamente Jsoup.parse sobre un
String ya recibido por el transporte acotado de la app. No se usa Jsoup.connect.
La app mantiene Java17, minSdk26 y su configuración existente de desazucarado.
Licencia completa en licenses/MIT-jsoup.txt y procedencia en THIRD_PARTY_NOTICES.md.

El 25 de octubre de 2026, el transporte/parser de desarrollo JDK reconoció una tarjeta
real del canal público patreonforcreators, explícitamente parcial y sin fecha declarada.
No obtuvo cuerpos completos ni adjuntos y no guardó el HTML real en los entregables.
También se volvió a comprobar FANBOX: 10 candidatos gratuitos, 34 páginas, detalle
article y 6 descriptores de adjunto, sin repetir la descarga de medios de 0.13.
Estas comprobaciones no son ejecución del APK en SM-X230. PRUEBAS.md conserva la
batería local, la firma y las pruebas instrumentadas todavía pendientes de ejecución.

La comprobación opcional puede repetirse con JDK17 y los JAR fijados por SHA-256:

```
python3 scripts/run-patreon-smoke.py --json-runtime /ruta/json-20240303.jar --html-runtime /ruta/jsoup-1.23.2.jar --creator patreonforcreators
```

JSON-java es solo una herramienta externa para ese comando; no es dependencia del
APK. El comando no realiza consultas durante las pruebas unitarias normales.
El comando FANBOX anterior sigue disponible con su interfaz y su JAR JSON habituales.

## Pendiente

Autenticación oficial, cuerpos/adjuntos autorizados por cuenta, historial Patreon,
otros proveedores, galerías remotas, descargas en lote/reanudables y las diferencias
restantes del original siguen abiertas. No se considera integrado todo Patreon ni
terminado Peach por añadir sus tarjetas públicas.

Referencias primarias:
- https://docs.patreon.com/
- https://support.patreon.com/hc/en-us/articles/360033339832
- https://www.patreon.com/cw/patreonforcreators
- https://jsoup.org/news/release-1.23.2
- https://github.com/peach-mitao/peach (commit de22796c04919aaa057d77930c33c81313765569)
