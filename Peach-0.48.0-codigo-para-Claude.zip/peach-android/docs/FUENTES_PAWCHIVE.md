# Pawchive · 0.23.0 · validación online pendiente

**Estado real:** conector implementado y pruebas sintéticas; la consulta de la API desde
este entorno devolvió HTML «Site Unavailable», no JSON. El método JDK de producción
rechazó el formato. Esto no certifica su funcionamiento online ni demuestra caída global:
la portada se recuperó con la herramienta web, y el iframe de documentación devolvió530.
No se ha validado en la tablet o con medios reales. Si la API responde así, la app muestra
un error y conserva la caché. No se promete acceso a creadores reales hasta comprobarlo.

En Fuentes → Añadir fuente elige Pawchive · API pública. Introduce servicio/ID (por
 ejemplo patreon/12345, ID sintético) o la página HTTPS del creador. No basta un nombre.
Guardar/abrir no hace peticiones. Consultar novedades solicita una página de hasta50
publicaciones; Página más antigua se habilita si la API devolvió50 y existe siguiente
offset. Revisa/importa antes de conservar datos en Publicaciones. Consultar cuerpo
es otra petición explícita; vuelve a revisar e importar. Lo importado se lee offline.

## Contrato y decisiones

Se adapta KemonoConnector, provider pawchive, de follow_sources.py en el commit original
fijo de22796c04919aaa057d77930c33c81313765569. Solo Pawchive: no fallback o conexión a
Kemono/Coomer. Mantiene servicio e ID de creador separados. El usuario pidió priorizar
Pawchive y reportó caída de Kemono; no se presenta ese reporte como comprobación propia.

HTTPS exacto pawchive.pw, rutas API canónicas de lista/detalle, servicio ASCII minúscula
hasta32 e ID ASCII hasta64, sin /, %, query, fragmento o . / .. como segmento. Post ID
ASCII hasta128, sin rutas. No se admiten URLs arbitrarias, credenciales o redirecciones
API. SourceHttp añade Accept:text/css solo a esta API, según el contrato inspeccionado;
sigue exigiendo JSON, sin cookies, Origin/Referer FANBOX o sesiones privadas.
Mismos límites2MiB/15s de conexión y lectura/plazo60s, UTF-8 estricto y cancelación.

Acepta array o {posts:[...]}, hasta50, servicio/user/id validados en cada fila; duplicados
o filas ajenas/malformed rechazan la página completa. Un título vacío usa ID. Fecha
con zona se conserva exacta; sin zona aproximada; inválida queda desconocida. No inventa
UTC. No filtra publicaciones por palabras del título ni prueba recursos con peticiones
adicionales. No implementa el filtrado/enriquecimiento de recursos del original.

Las páginas siguen offsets0,50,100..., máximo5000 páginas. pageUrls conserva únicamente
la siguiente URL calculada del contrato, no cursores FANBOX. Página corta termina;
400/404 o lista vacía en una petición anterior termina sin borrar la última página.
Lista vacía en novedades es error conservador. 304 solo con página cero previa compatible;
429 guarda cooldown y conserva candidatos. Revisión de fuente/token vigentes antes de
persistir. Nuevas consultas invalidan revisiones anteriores. No hay sondeo periódico.

Detalle valida servicio/user/post y acepta objeto directo o wrapper post, combinando
metadatos de adjuntos. HTML se convierte a texto, sin scripts/plantillas/nodos ocultos
conocidos; los href HTTPS se conservan como referencias legibles, sin abrirlos. Lista
hasta4000 caracteres y detalle200000, con aviso de recorte dentro del límite. Siempre
partial: no certifica cuerpo completo del servicio original, embeds o contenido oculto.
Tipo pawchive-detail se conserva si después llega solo un resumen de lista.

Adjuntos: hasta100 metadatos únicos, nombre140, rutas hash conocidas /aa/bb/sha256.ext
con prefijo de hash coincidente; se convierten a referencias del host file.pawchive.pw.
No se usa ese nombre como ruta local ni se solicita el archivo. Otras formas se omiten;
el cuerpo permanece parcial. No se verifica el hash del contenido por leer su nombre.
**downloadable=false**: Guardar adjunto los muestra como solo referencia; los hosts no se
habilitan en SourceHttp.download ni en la galería. Nada se descarga al consultar/importar.
No hay imágenes/vídeo remotos, Gofile expander, cuentas, autenticación o galería Pawchive.

## Persistencia y compatibilidad

IDs incluyen proveedor+servicio/creador+post y no mezclan sitios. Reimportar conserva
ficha personal/cuerpo detallado previo. No crea MediaEntry/progreso/historial ficticio.
Room13 idéntico. Copia13 lee1–13,8MiB; incluye configuración/candidatos/texto/referencias,
sin credenciales o medios. Versiones anteriores rechazan13 antes de modificar estado.
Sin nuevas dependencias o permisos; vistas Android, sin Termux/WebView/servidor Peach.

Pruebas cubren formatos/identidad/límites, páginas y final sin pérdida, estado personal,
rollback de copias, cancelación/429/304 y pantalla. Fixture JSON propio, sin datos reales.
La prueba Android se compila, no se ejecuta. PRUEBAS.md conserva conteos reales y fallos.
El paso pendiente es validar directamente la API y después su transporte de medios;
no declarar la fuente funcional online solo por compilar o aprobar datos sintéticos.

## Actualización0.24: consultas confirmadas por el usuario y guardado directo

El texto anterior documenta el estado0.23. El usuario aportó su JSON:50 filas Pawchive,
2 cuerpos y166 adjuntos de file.pawchive.pw. Queda acreditado que hubo consultas en su
tablet. No se generaliza la respuesta no JSON de nuestro entorno a su conexión.

0.24 habilita Guardar adjunto para ese host exacto y rutas/hash admitidos, sin servidor
intermedio. Requiere conexión a la fuente y un destino elegido en Android. Hasta128MiB;
verifica longitud y SHA-256 del contenido frente al hash de la URL antes de copiar a SAF.
Pawchive no recibe encabezados FANBOX. Redirecciones solo al mismo host/hash; sin nodos,
proxies o sitios alternativos. URLs con credenciales, parámetros, esquema/host/ruta
no admitidos siguen bloqueadas. Referencias antiguas false son utilizables por capacidad
al tocar Guardar; no hay mutación masiva o consulta automática. Consultas nuevas generan
flag true. Copia14 lee1–14, mantiene false como conservador y rechaza true en URL ajena.

Privado temporal se elimina en éxito/fallo/cancelación. La copia SAF comprueba cancelación
y cierra flujos; el proveedor puede dejar un destino vacío/parcial si falla o se cancela.
No se declara éxito en esos casos y no se promete escritura atómica en cualquier proveedor.
Después de guardar, Actualizar o añadir la carpeta destino permite abrir el archivo en
la biblioteca. No crea una fila ficticia solo por consultar o guardar una referencia.

El mensaje anterior se reemplaza por «Esta dirección todavía no admite descarga directa
en la app; se conserva la referencia. No necesitas configurar un servidor Peach» para
las direcciones no soportadas. No hay que instalar un servidor, Termux o Windows.

El JSON aportado no se modifica ni empaqueta; la auditoría del código nuevo acepta las
166 referencias existentes sin red. En ese JSON no hay publicaciones importadas: para
conservarlas en Publicaciones, pulsa Importar página revisada tras consultar el cuerpo.
Los casos de transferencia usan texto propio; no certifican descarga real desde la
fuente o la tablet. Siguen pendientes galería/vídeo remoto Pawchive, lotes/reanudación y
adjuntos de más128MiB. La galería FANBOX anterior conserva su alcance.
