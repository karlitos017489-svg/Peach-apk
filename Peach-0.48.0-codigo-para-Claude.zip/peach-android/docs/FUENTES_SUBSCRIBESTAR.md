# SubscribeStar · tarjetas públicas · 0.22.0

En Fuentes → Añadir fuente selecciona SubscribeStar · tarjetas públicas. Escribe el
creador o su página HTTPS y guarda. Un nombre sin dominio usa SubscribeStar.com;
para el otro sitio hace falta la URL o dominio/creador. Son identidades separadas,
aunque coincida el nombre. Guardar/abrir no consulta la red. Pulsa Consultar novedades,
revisa las tarjetas y elige Importar página revisada. Después se leen desde Publicaciones
→ Organizar → Leer contenido consultado, incluso sin red. Pausar/eliminar conservan
publicaciones ya importadas según el comportamiento existente.

La tarjeta contiene texto visible servido al visitante. Siempre es un **adelanto
parcial**; que la página lo muestre no certifica cuerpo completo ni suscripción gratuita.
Puede faltar título, fecha o parte del texto. Título ausente usa ID de publicación.
Fecha de reloj del sitio se guarda aproximada, sin inventar UTC/zona; si no se reconoce
es desconocida. No se consultan por separado posts, medios, comentarios, APIs privadas,
cuentas o páginas históricas. No hay login, cookies, WebView o scripts. No se trasladan
suscripciones del usuario ni se completa CAPTCHA. Una fuente bloqueada puede seguir
bloqueada en la red/tablet; la caché anterior se conserva.

## Arquitectura

SubscribeStarUrls fija esquema HTTPS, host exacto.com/.adult con www opcional, creador
ASCII de1–80 letras/dígitos/_/-, normalizado a minúsculas y dominio canónico sin www.
Rechaza páginas de cuenta/reservadas, credenciales, query/fragmento, subdominios ajenos,
puertos noHTTPS, codificación de rutas o páginas de post como creador. Redirecciones
solo al mismo sitio y creador; nunca.com↔.adult. postUrl fija host y ID numérico1–30.
El ID de fuente/publicación conserva proveedor+host/creador; no cambia UUID FANBOX/Patreon.

SourceHttp reutiliza HTTPS nativo,3 redirecciones, timeout15s, respuesta2MiB y plazo60s,
MIME HTML, UTF-8 estricto, cancelación y errores429/Retry-After. No añade hosts de medios
a la lista de descarga. No envía Origin/Referer FANBOX a las páginas HTML. Sin credenciales.
El transporte no usa mecanismos para evadir verificación de fuente.

SubscribeStarConnector requiere identidad canonical u og:url de ese creador/sitio.
Lee div.post[data-id], a.post-user, .post-date a, .post-title h2 y .post-content, como
el original. Valida creador del autor y permalink por ID; omite entradas ajenas o sin
texto visible, elimina scripts/plantillas/nodos hidden y clases is-hidden, comentarios
y edición. No ejecuta CSS/JS o datos data-safe-html/bootstrap. Deduplica ID conservando
orden, título300 y resumen4000 caracteres; hasta100 tarjetas y1000 nodos de posts.
Mayor límite o página no reconocible es error y conserva la consulta anterior, sin
resultado vacío engañoso. No se afirma recuperar todos los posts que muestra la web.

SourceStore guarda candidatos solo tras éxito, token y revisión de fuente vigentes;
la importación explícita revalida. Conserva título/notas/estado/vínculos personales,
y no sustituye un cuerpo detallado previo por tarjeta. No crea medios ni historial
de archivos ficticios. 304 requiere caché previa compatible; 429 conserva candidatos
y cooldown persistente. Biblioteca local permanece utilizable sin servidor externo.

Room13 y su esquema no cambian. Copia pasa a12 para distinguir el nuevo proveedor;
lee1–12,8MiB total, rollback ante fuente/caché inválida. Copias anteriores siguen
leyéndose; versiones anteriores de la app rechazan12 antes de escribir. No exporta
credenciales o bytes de medios; no añade permisos ni dependencias.

## Evidencia y límites

Se inspeccionó SubscribeStarConnector de follow_sources.py del original, commit fijo
de22796c04919aaa057d77930c33c81313765569. El registro admite ambos hosts; la separación
por host se conserva. No se ejecutó el servidor original. La adaptación conserva un
subconjunto público de metadatos y texto; las miniaturas del original quedan pendientes.

La prueba pública explícita de SourceHttp.direct + SubscribeStarConnector consultó una
página.com de tutoriales Linux:6 tarjetas normalizadas. Se registra conteo/ID/precisión,
no cuerpos descargados. Es JDK HTTPS; no demuestra comportamiento nativo Android o.adult.
El HTML de pruebas/fixture Android es sintético propio. El APK principal no lo contiene.
PRUEBAS.md y evidence/0.22.0 conservan resultados reales y lo no ejecutado.

Pendientes: sesión autorizada si se incorpora, cuerpos completos/medios públicos, imágenes,
vídeo, paginación histórica, mayor cobertura y otros conectores del original. Añadir esta
fuente no termina el proyecto ni permite acceder a suscripciones sin autorización.
