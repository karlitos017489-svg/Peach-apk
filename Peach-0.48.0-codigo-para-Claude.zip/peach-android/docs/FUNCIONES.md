# Alcance de la adaptación Android

Este documento describe la implementación. La columna «implementado» no sustituye
los resultados de ejecución de `PRUEBAS.md` ni confirma una prueba física en SM-X230.

| Función del producto | Estado en esta versión | Ejecución y límites |
|---|---|---|
| Biblioteca local de videos, imágenes, audio, comprimidos y otros archivos | Catálogo implementado | Reproducción/lectura según formato; importa campos seleccionados de SQLite/JSON; no todo el ledger |
| Acceso a carpetas y microSD | Implementado mediante SAF | Solo ubicaciones que el selector permita; validación física pendiente |
| Persistencia, búsqueda y filtros | Implementados | Títulos, nombres, carpetas, etiquetas, artistas, estudio, año y campos NFO ampliados |
| Reindexado y recuperación de trabajo | Implementados | Checkpoints por directorio, reenumera para detectar cambios; no vigilancia instantánea |
| Mosaico y miniaturas | Implementados | RecyclerView, caché de 8 MiB y dos lectores; algunas fuentes/códecs muestran icono |
| Videos MP4 y otros contenedores | Implementado con Media3 | Soporte efectivo depende de contenedor y códecs del dispositivo |
| Subtítulos de texto y pistas | Implementados | SRT/VTT/ASS/SSA, emparejamiento acotado y selección manual; estilos y codificación limitados por Media3 |
| Subtítulos gráficos y conversión universal | Pendientes | No se incluye FFmpeg ni OCR |
| NFO y ediciones personales | Implementación parcial | Lectura ampliada de movie/episodedetails/musicvideo, ficha desplazable y búsqueda de metadatos; título/etiquetas editables con prioridad local y reversión al origen; detalles en NFO.md |
| Carátulas | Implementación local | mismo nombre, -poster y poster/folder/cover para una carpeta de un solo video |
| Exploración por personas/estudios/series/etiquetas | Implementada en 0.6.0 | Índice de términos exactos, sin inferir identidades canónicas; listas NFO estructuradas |
| Grupos de obras/versiones | Manuales y revisión de indicios en 0.19 | Propuestas por nombre/carpeta, marcas de edición/resolución/códec/procesamiento; selección explícita, conflicto NFO excluido, lista de partes consecutivas. No deduplica ni confirma identidad de contenido; VERSIONES_Y_PARTES.md |
| Identidades, alias y referencias externas | Implementación local en 0.7.0 | UUID/tipo/ficha/favorito, alias exactos, referencias como texto; importación seleccionada SQLite/JSON y rechazo de conflictos desde 0.9 |
| Relaciones por función y procedencia | Implementadas en 0.7.0 | Coincidencias NFO/etiquetas personales derivadas y vínculos manuales persistentes; sin historial de afirmaciones/candidatos |
| Lista de deseos | Seguimiento local en 0.12 | Estados/fechas, búsquedas registradas y revisión por código con deshacer; sin búsqueda real o descarga |
| Publicaciones | Locales e importadas en 0.12 | Fecha/precisión, fuente, variante, estado, deseo y archivo opcional; sin cuentas o actualización online |
| ZIP/CBZ | Lectura local en 0.8.0 | Índice buscable, álbum de imágenes, PDF/texto seleccionados y reanudación; límites de caché/tamaño, sin ZIP64/cifrado/volúmenes |
| PDF y texto | Lector en 0.8.0 | PDF por páginas con motor Android; TXT/MD/CSV/JSON/XML/LOG en texto plano; validación nativa PDF pendiente en dispositivo |
| EPUB | Texto nativo0.17 | Capítulos en orden spine, índice, reanudación e imágenes aparte; sin CSS/DRM/fuentes ofuscadas o motor EPUB completo |
| 7z | Lector local0.16 | Índice e imágenes/PDF/texto; límites y exclusiones en LECTURA_7Z.md |
| TAR/GZIP y TAR.GZ/TGZ | Lector local0.15 | Índice, imágenes y PDF/texto compatibles, límites y progreso; sin AV/anidados/extracción general |
| RAR/CBR, otros documentos e ISO/STRM/RMVB | Catálogo | Ficha y organización; lectura interna de esos comprimidos, montaje o reproducción de referencias pendientes |
| Favoritos, visto y progreso | Implementados | Persistentes; marca visto al terminar o alcanzar el 95 % |
| Historial y estadísticas | Visitas locales en 0.20 | Audio/video, imágenes y lecturas; cronología, filtros/búsqueda y últimos puntos; hasta 10.000 visitas, sin reconstruir las anteriores. No mide tiempo efectivo o busca saltos; HISTORIAL_USO.md |
| Copias de seguridad | Implementadas, formato v11 | Añade visitas; lee v1–v11. Incluye lectura/organización/catálogos, máximo 8 MiB y documentos coincidentes. Las copias antiguas conservan el historial actual |
| Reorganizar/renombrar archivos y papelera | Pendientes | El escáner solo solicita lectura y no altera los originales |
| Listas de reproducción | Implementadas en 0.3.0 | Crear, renombrar, reordenar, añadir/quitar; secuencia Media3 con identidad y progreso por video |
| Navegación por carpetas y ordenación | Implementadas en 0.3.0 | Carpetas con videos indexados, raíz SAF separada y descendencia; título, incorporación, reproducción u orden de lista |
| Pared inmersiva y agrupaciones avanzadas | Pendientes | La interfaz usa mosaico, listas y filtros |
| Galería de imágenes | Implementada en 0.5.0 | Visor nativo con zoom, orientación EXIF, navegación y favoritos; vista reducida hasta 2048 px, animaciones como imagen fija |
| Biblioteca de audio | Sesión Android en 0.18 | Media3, cola de audios, progreso, controles y Detener audio; ciclo de vida local probado, validación física de segundo plano/notificación pendiente |
| Montajes CloudDrive2 y servicio 115 de escritorio | Fuera del núcleo autónomo | No se exige un host o servicio de escritorio para usar Peach Local |
| PikPak y otras APIs remotas autorizadas | Pendientes, opcionales | Necesitan diseño de autenticación, almacenamiento de tokens y pruebas por proveedor |
| Fuentes seguidas, descubrimiento y metadatos online | FANBOX público y tarjetas HTML públicas Patreon | Consulta explícita, revisión y copia local; sin agenda/cuentas; cuerpo y descarga solo FANBOX compatible |
| Descarga de adjuntos FANBOX | Individual en 0.13 | A documento SAF elegido, hosts admitidos y máximo 128 MiB; sin reanudación o lotes |
| Navegador de escritorio e historial de otras apps | Sin equivalente directo | Android protege datos privados de otras apps; una importación explícita sería otra función |
| IA/reconocimiento y preferencias avanzadas | Pendientes | Faltan evaluación de modelos, coste, memoria, credenciales y licencias |
| Telemetría | No incluida | INTERNET se usa para consultas de fuentes y descargas opcionales FANBOX |
| Sincronización de escritorio | Pendiente | El catálogo Android usa URI, no las rutas Windows del ledger original |

## Próximas etapas verificables

1. 0.10.0 tiene confirmación de funcionamiento comunicada por el usuario. Agrupar novedades
   y ejecutar pruebas automatizadas; quedan pendientes mediciones
   de hardware y los casos de microSD, rotación, batería e interrupciones.
2. Continuar con importación revisable del catálogo, vínculos con fuentes y formatos de lectura pendientes. Metadatos NFO,
   galería, audio en primer plano, edición, listas, exploración exacta y grupos manuales están implementados.
   Las fichas locales, los alias explícitos, las relaciones y la lista básica de deseos también están disponibles.
   El lector 0.8.0 incorpora PDF/ZIP/CBZ/texto; se distinguen sus pruebas reales y sus pruebas de controlador.
   Cada extensión debe incluir regresión sobre la versión anterior y migración cuando cambie el esquema.
3. Diseñar integraciones online optativas por proveedor, con autorización y aislamiento
   de credenciales. Deben poder desactivarse sin afectar biblioteca/reproducción local.
4. Medir memoria, batería, accesibilidad y bibliotecas grandes en hardware real; definir
   firma de distribución estable y política de actualizaciones antes de un release público.

El proyecto sigue abierto mientras falte aceptación y las funciones priorizadas de
etapas posteriores. Disponer de un APK debug y pruebas documentadas es un hito de
entrega, no una afirmación de paridad funcional completa con Peach de escritorio.

El inventario por familias, dominios y fuentes está en COMPATIBILIDAD_ORIGINAL.md.

## Catálogo original 0.9.0

Importación nativa revisable de campos seleccionados de copias SQLite autónomas o JSON
de intercambio, rutas relativas exactas a raíces SAF, fichas/alias/referencias/vínculos
y listas nuevas compatibles. Inventario buscable con registros sin archivo; instantáneas
y exportación de la proyección JSON. No reemplaza datos personales ni el catálogo Room
por una base Windows. IMPORTACION_CATALOGO.md identifica dominios excluidos y límites.

## Consulta del catálogo 0.10.0

Metadatos seleccionados del catálogo vinculados a documentos disponibles: búsqueda
principal, ficha con procedencia/conflictos y términos exactos, incluida faceta Creador.
Room v9 añade caché de consulta reconstruible con límite explícito; copia v6 sin
duplicar derivados. Se preservan NFO, ediciones y estado personal. Migración de
instantáneas existentes y corrección de base de rutas del escáner. Detalles en
METADATOS_CATALOGO.md; no equivale a sincronización ni a importación de todas las tablas.

## Agencias 0.11.0

Fichas de agencia y afiliación vigente de reparto/creadores con UUID, procedencia y
validación. Gestión manual, cambio revisado, eliminación solo de relación, perfil y
ámbito de archivos deduplicado por miembros. Importación opcional entity_membership,
conflictos conservados para revisión y copias v7; migración Room 9→10. Sin búsqueda
textual general por agencia, historial ni captación de roster online. Véase AGENCIAS.md.

## Publicaciones y seguimiento 0.12.0

Publicaciones y deseos con estado/fecha/procedencia y registros de búsqueda; proyección
original opcional follow_source/follow_item/want_item, revisión de coincidencias y
deshacer lote. Room v11 y copia v8 con lectura v1–v7. No activa fuentes online ni
descarga adjuntos. PUBLICACIONES_Y_SEGUIMIENTO.md separa lo implementado del original.

## Fuentes 0.13.0

FANBOX público/gratuito, páginas reales, cuerpos/adjuntos y descarga individual sin
cuenta ni host de escritorio. Room v12/copia v9; lectura v1–v8. FUENTES_FANBOX.md
explica el uso y las diferencias con los demás proveedores o la agenda del original.

## Patreon 0.14.0

Tarjetas públicas parciales, revisión/copia local y fuente separada por proveedor,
sin cuentas, cuerpos completos o adjuntos Patreon. Misma Room v12, copia v10.
FUENTES_PATREON.md explica formatos y comprobación real del contrato público.


## TAR/GZIP 0.15.0 y bloqueo Patreon (estado histórico)

Archivo local TAR/TAR.GZ/TGZ/GZIP → lector con índice buscable y apertura de entradas
compatibles. Se conservan los datos y el progreso del contenedor, Room v12/copia v10.
Ver LECTURA_TAR_GZIP.md y PRUEBAS.md. Sin red o extracción general.
Patreon/panpiano falló en la tablet; CAPTCHA completado en Chrome no habilita el
conector nativo. Esa fuente sigue pendiente, sin aceptación general de 0.14.
0.15 muestra el código401/403 cuando se recibe, sin inferir que cualquier rechazo
sea un CAPTCHA y sin reintentar automáticamente.


## Actualización 0.16.0

7z local añade índice buscable y lectura de archivos regulares de imagen/PDF/texto,
con límites y progreso del contenedor. RAR/CBR sigue pendiente. Ver LECTURA_7Z.md.
El usuario comunicó resultados de Patreon tras desactivar la VPN: el bloqueo anterior
ya no se reproduce en su uso actual. No hay solución de CAPTCHA o cuentas privadas.

## Actualización 0.17.0

EPUB2/3 como texto nativo por capítulos, imágenes seleccionables aparte, índice y
progreso. Sin maquetación CSS, DRM, fuentes ofuscadas o lector EPUB completo.
No hay dependencia nueva o migración; límites en LECTURA_EPUB.md. En el momento de esa entrega, la aceptación
general previa correspondía a0.16; el estado actual figura en PRUEBAS.md.

## Audio 0.18.0

Sesión y servicio internos Android para audio local en segundo plano. La pantalla
solo controla la reproducción; salir/recrear no libera el motor ni duplica aperturas.
Ver AUDIO_SEGUNDO_PLANO.md para colas, permisos, límites y hardware pendiente.


## Revisión de versiones y partes 0.19.0

Propuestas por nombre dentro de la misma raíz/carpeta, indicios con procedencia,
selección revisada y guardado transaccional. Grupos ordinarios y listas numéricas
para partes explícitas consecutivas de una misma firma. Reutiliza organización
idéntica y la copia existente. No deduplica, empalma, pliega el mosaico o confirma
identidad de contenido. VERSIONES_Y_PARTES.md documenta límites y rechazos.
La aceptación general más reciente comunicada es0.18; la nueva0.19 aún no tiene
validación física. No se infiere ejecución instrumentada.


## Historial 0.20.0

Visitas locales desde esta entrega, separadas de contadores y progreso. Audio pertenece
al servicio; el resto se registra tras una apertura válida. Reserva de token antes de
carga asíncrona, reuso al recrear en el mismo proceso, posición/entrada y último estado.
Cronología de100 filas, búsqueda Unicode literal, tipo/fechas y borrado. Room13/copia11;
no se crean eventos retroactivos ni se estima tiempo efectivo desde posiciones.
Última aceptación general0.19; 0.20 todavía no tiene aceptación física comunicada.
