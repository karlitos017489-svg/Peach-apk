# Galería nativa FANBOX · 0.21.0 (histórico)

El alcance actual de0.30, incluidas seis fuentes y animación, está en
[GALERIA_FUENTES.md](GALERIA_FUENTES.md). Los límites y resultados siguientes
describen la entrega histórica0.21.

Abre **Publicaciones → Organizar → Leer contenido consultado**, toca la tarjeta del
cuerpo guardado y elige **Ver imágenes**. Si solo hay un resumen, consulta el cuerpo
público desde su fuente, revisa e importa primero. Una vista previa sin importar conserva
Consultar cuerpo y Guardar adjunto, y explica que hay que importar para usar la galería.

Anterior/siguiente eligen una imagen; pellizco, doble toque y botones permiten ampliar,
reducir y ajustar. Detalles muestra fuente, nombre, URL, adjuntos omitidos y advertencia
de cuerpo parcial. Son textos nativos; no se ejecuta HTML o JavaScript. No se necesita
un equipo, Termux, servidor Peach o Windows. Abrir una imagen sin caché sí necesita Internet.

**Sin conexión** impide la petición de imagen, incluso al reintentar. Persiste entre
aperturas y recreaciones. Una imagen ya conservada se verifica antes de decodificar;
una ausente o dañada muestra un mensaje. Desmarca el modo y pulsa Reintentar para
consultarla. No hay precarga, lotes ni reintentos automáticos. Un 429 respeta Retry-After
entre instancias durante este proceso (hasta24h); el temporizador no sobrevive al proceso.
La caché válida sigue disponible sin red durante la espera.

## Datos y arquitectura

SourceGallery resuelve solo un ID de publicación de Room en una transacción; comprueba
provider fanbox, coincidencia del cuerpo, tipo image, bandera downloadable y servidor
permitido. Orden guardado y deduplicación por URL exacta; otros adjuntos se omiten.
Límite defensivo2Mi caracteres/1000 adjuntos; no amplía el conector FANBOX original,
que acepta hasta100 y rechaza más sin guardar una consulta parcial.

SourceGalleryActivity no es exportada; ignora extras URL. El trabajo de caché/red/decode
se hace fuera del hilo UI. El token desconecta la conexión y cancela el Future al cambiar
imagen, parar o destruir la pantalla. Una generación impide que un resultado antiguo
reemplace la selección; sus bitmaps sin mostrar se liberan. Rotación conserva la URL
seleccionada como hash y vuelve a resolver el cuerpo; si cambió, usa la primera imagen.
No crea MediaEntry, historial ficticio ni progreso de archivos locales.

SourceHttp.image conserva HTTPS y las mismas políticas de3 redirecciones, lista de hosts
(downloads.fanbox.cc y pixivfanbox.akamaized.net), sin cookies/credenciales, timeouts15s,
plazo de copia120s, límite por cabecera y flujo, longitud esperada y SHA-256. MIME image/*,
excepto SVG; vacío/octet-stream requieren después decodificación válida. No se modifica
el límite128MiB de Guardar adjunto. Errores de fuente se muestran sin sortear controles.

GalleryCache usa cacheDir/peach-source-gallery, nombre SHA-256 de URL exacta y sidecar
SHA-256 del contenido. El nombre de adjunto nunca es ruta. Límite16MiB por imagen,
64MiB de payload total y128 imágenes, eliminación por antigüedad de uso. Reserva espacio
para la selección y requiere24MiB libres; metadata añade unos bytes, no es cuota global
para todos los archivos de la aplicación. Solo limpia sus archivos/temporales conocidos.
Un lock común serializa escrituras/evicción/decodificación; no son peticiones UI bloqueantes.
Valida hash y decode antes de promover temporales; cancela/falla sin medios parciales.

ImageFiles lee dimensiones antes de decodificar, muestrea hasta2048 píxeles por lado y
aplica EXIF. GIF/WebP muestran primer fotograma; formatos Android dependen del dispositivo.
No promete memoria global constante, animación, vídeo remoto o cualquier formato de imagen.
Una falta de memoria en un cache hit conserva el archivo válido para otro intento.

La caché es descartable: Android puede limpiarla y una URL firmada nueva tiene otro hash.
No se incluyen bytes en copias JSON v11 ni en el catálogo SAF. Room13 y su esquema siguen
iguales; al restaurar una copia, las referencias permiten consultar de nuevo pero no
recuperan imágenes ausentes sin red. Para conservar un original usa Guardar adjunto.

## Cobertura y pruebas

Es parte de la galería del original, no toda su interfaz de seguimiento: quedan cuentas,
otros proveedores, ocultación de medios, vídeo, portadas, mosaicos y lotes. El usuario
aceptó0.20 generalmente; aún no probó físicamente esta versión. PRUEBAS.md documenta
los resultados JVM, compilación de instrumentación y comprobación pública JDK separadas.
