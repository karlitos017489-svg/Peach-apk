# Galería de fuentes · Peach Local0.30.0

La galería abre las imágenes compatibles de una publicación ya consultada e importada.
Usa **Publicaciones → Organizar → Leer contenido consultado**, toca el cuerpo guardado
y elige **Ver imágenes**. Si todavía es una vista previa de Fuentes, consulta el cuerpo
cuando corresponda, revisa e importa primero. No hace falta volver a consultar un
cuerpo importado que ya contenga las referencias compatibles.

Anterior/Siguiente recorre las imágenes en su orden guardado. Pellizco, doble toque,
Ampliar/Reducir/Ajustar controlan el zoom. Detalles conserva nombre, origen, referencia,+número de adjuntos omitidos y aviso de cuerpo parcial. No ejecuta HTML/JavaScript.

## Fuentes que pueden aportar imágenes

| Fuente | Contrato de imagen ya admitido |
|---|---|
| FANBOX | downloads.fanbox.cc y pixivfanbox.akamaized.net |
| Pawchive | file.pawchive.pw/data con SHA-256 esperado y prefijos coincidentes |
| cum.st | Variante admitida en e1.cum.st/media |
| Rule34 Paheal | Ruta con hash en r34i.paheal-cdn.net; no necesita extensión en el nombre |
| Rule34.xxx | Ruta de imagen admitida en api-cdn.rule34.xxx; sin clave API en la solicitud de imagen |
| F95zone | Adjunto público compatible en attachments.f95zone.to |

Cada imagen se verifica contra el proveedor de la publicación. Un enlace válido de
otra fuente no pasa por coincidir con una lista global. Solo entran adjuntos de tipo
image y con descarga admitida. Las referencias antiguas Pawchive con bandera falsa
se reevalúan como en Guardar adjunto; otras banderas falsas se mantienen. No se
modifica la lista guardada al abrir la galería.

Patreon/SubscribeStar conservan sus tarjetas públicas. Rule34Video mantiene sus
descargas de video y reproducción local; no obtiene un transporte de imágenes de
esta ampliación. Hay nueve proveedores de metadatos, seis con rutas de imágenes
compatibles. Otros servidores, embeds, sesiones, masked/Gofile y referencias externas
siguen pendientes. Kemono, Coomer y SimpCity permanecen excluidos.

## Caché, conexión y animación

Solo se descarga la imagen seleccionada, hasta16MiB, a la caché privada. No hay
precarga, lotes o reintentos automáticos. El modo **Sin conexión** impide peticiones,
incluso al reintentar. Se conserva esa preferencia y la selección al recrear la
pantalla. Una imagen ausente o dañada informa que no está disponible sin conexión.

La caché usa nombres hash, verifica longitud, SHA-256 y decodificación antes de
mostrar/promover archivos. Pawchive también exige el hash de su referencia, tanto
al consultar como al abrir caché. Las demás fuentes no aportan aquí un hash externo
de identidad: el SHA local comprueba conservación de bytes, no autoría del servidor.
Se conservan las políticas de redirección de cada proveedor y TLS normal.

Hasta64MiB de payload/128 imágenes, eliminación por antigüedad de uso,16MiB por
imagen y reserva de24MiB libres. Metadatos y animaciones activas añaden recursos;
estos números no son una cuota global de RAM ni de toda la aplicación. Android puede
limpiar la caché. Para conservar el original, usa **Guardar adjunto**, fuera de esta
caché. Las copias JSON conservan referencias, no los bytes de las imágenes.

Las imágenes fijas mantienen EXIF y vista muestreada hasta2048px por lado. GIF/WebP
se reconocen por sus bytes, aunque el nombre sea BIN. En Android9/API28 o posterior,
se decodifican con ImageDecoder y se animan si contienen animación; vista hasta1024px.
El drawable lee de un ByteBuffer mapeado inmutable y los descriptores se cierran antes
de animar. La selección cancela trabajos previos, y los resultados tardíos no sustituyen
la imagen actual. La animación se detiene al pausar/cambiar/cerrar y se reanuda al volver.
Android8/API26–27 conserva el fotograma estático. El formato final depende de Android.

## Conservación y comprobación

La entrada a la pantalla es un ID importado de Room, nunca una URL del Intent.
No crea MediaEntry, visitas ficticias, progreso local o cambios de estado/ficha.
Room13 y copia17 se mantienen, con permisos y dependencias anteriores.

PRUEBAS.md y evidence/0.30.0 contienen los resultados. Las pruebas propias usan un
PNG, un GIF y un WebP de colores, metadatos sintéticos y conexiones HTTPS simuladas.
No prueban el acceso real de cada servidor o cada formato en la tablet.

Referencia oficial del decodificador y propiedad del buffer:
[Android ImageDecoder](https://developer.android.com/reference/android/graphics/ImageDecoder).
