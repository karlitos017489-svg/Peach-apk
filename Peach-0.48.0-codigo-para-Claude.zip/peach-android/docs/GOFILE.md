# Gofile y enlaces externos — 0.36.0

Gofile es un origen de archivos enlazados desde publicaciones, no una décima fuente
de seguimiento. Las nueve fuentes existentes y las exclusiones Kemono/Coomer/SimpCity
se conservan. Esta adaptación consulta el API documentado con una clave propia,
independiente de las credenciales de FANBOX, F95 o Rule34.xxx.

## Uso nativo

Abre el contenido guardado de una publicación y pulsa **Enlaces Gofile**. La pantalla
lee únicamente sus referencias importadas; abrirla no hace red. Reconoce enlaces
HTTPS gofile.io/www.gofile.io/d/código de seis u ocho caracteres, o UUID, sin parámetros,
fragmentos o credenciales. Los enlaces F95 masked, otros hosts o formatos no admitidos
permanecen referencias; no se presenta una página compartida como un video ya obtenido.

**Configurar clave Gofile** permite introducir el token propio del perfil del sitio.
La documentación actual marca el listado API como Premium: una clave de otro nivel
puede recibir error-notPremium. Esta integración no crea cuentas, adquiere cookies o
calcula firmas del cliente web para intentar otro acceso. Sin clave no hay solicitud.
La clave es opcional para Peach; la biblioteca local y las demás fuentes siguen autónomas.
No hace falta computadora, Termux, servidor Peach ni enviar la clave por chat.

Selecciona una carpeta y pulsa **Consultar archivos**. Hace un GET al API exacto para
esa página, hasta100 entradas. Las subcarpetas se añaden al selector y se consultan
manualmente, sin recorrido recursivo automático. Página siguiente/anterior también
son acciones explícitas; la consulta no descarga imágenes, thumbnails o videos.
Se respetan Sin conexión y la pausa/espera de la fuente vinculada.

Revisa nombres, tipos y tamaños declarados. **Incorporar archivos revisados → Incorporar**
añade o actualiza solo esos adjuntos en la publicación. Conserva texto, ficha personal,
notas, vínculos, historial, otros adjuntos y archivos exportados. Un archivo del mismo
grupo/ID Gofile puede renovar su dirección sin duplicarse. Resultado vacío, contenido
cambiado, clave cambiada/eliminada, cancelación o exceso del máximo100 adjuntos no
escriben un reemplazo parcial. Actualizar posteriormente el cuerpo desde la fuente o
Consultar versiones conserva los adjuntos Gofile ya incorporados.

Vuelve a la publicación para usar **Ver medios/Ver videos/Ver imágenes**, **Guardar
adjunto** o **Cola de descargas**. Video usa el reproductor nativo, preparación completa
o streaming progresivo anteriores; imágenes usan la galería y caché anteriores.
Documentos/otros archivos pueden guardarse y después catalogarse desde su carpeta SAF
para usar el lector compatible. No se añade lectura remota de comprimidos/documentos.
Si el servidor cambia una dirección, una selección/parte de descarga antigua puede
requerir consulta y selección nuevas; no se mezclan automáticamente archivos distintos.

## Contrato y aislamiento

API: GET https://api.gofile.io/contents/{id}?page=N&pageSize=100, una solicitud por acción,
sin redirecciones o reintentos. Clave solo en Authorization: Bearer, nunca URL, Room,
copia, Intent o logs. El transporte dedicado no recibe cookies ni headers de otra
fuente; no invoca endpoints de subida, borrado, importación o creación de directlinks.
TLS del sistema, validación de DNS público antes de conectar,15s de conexión/lectura,
60s de lectura acotada,2MiB de JSON/UTF-8 y profundidad máxima32. Hasta5000 páginas y
200 carpetas conocidas en el selector de una pantalla; cada nueva consulta es manual.

Se reconocen status de error aun con HTTP200.401/403 y rechazo de token, Premium,
contenido no encontrado y gates de acceso se diferencian sin mostrar el cuerpo crudo.
429 HTTP o error-rateLimit persisten una espera global Gofile, máximo24h por respuesta.
Se conserva al cerrar, cambiar o borrar clave, evitando que esas acciones reinicien
la espera. No es un bloqueo global de las otras fuentes. No hay reintento automático.

Los archivos deben venir en el listado autorizado con ID, tipo y link/downloadLink
admitido. canAccess/canDownload=false o contraseña sin acceso confirmado los excluyen.
Carpetas protegidas sin acceso devuelven un diagnóstico; entrada de contraseña y
autenticación F95 no se incorporan. Tamaño/resolución declarados no prueban el original.

Descarga directa: HTTPS en host store*.gofile.io acotado y ruta
/download/web/ID/nombre o /download/ID/nombre, con identidad coherente. Sin parámetros,
usuario/contraseña, fragmentos, puerto explícito, traversal o segmentos codificados
ambiguos. No se acepta cualquier subdominio, CDN externo, login o API como archivo.
DNS público vuelve a comprobarse por apertura. Una redirección solo puede conservar
la misma URL exacta; no se reenvía clave API, Cookie, Origin o Referer a archivos.
Si un archivo requiere otra autenticación o URL firmada no admitida, se conserva la
referencia y se informa del fallo; no se guarda como0bytes o se simula reproducción.

Descargas completas hasta2GiB, cola128 trabajos/4GiB privados y galería16MiB por imagen
conservan límites previos. Streaming conserva16GiB/recurso y objetivo32MiB RAM, sin
copia completa en disco. SHA calculado de una copia completa no es un hash esperado
de Gofile: no se compara su md5 declarado ni se certifica identidad criptográfica externa.
En streaming no se comprueba SHA completo antes de mostrar. No hay HLS/DASH, transcodificación,
HD artificial, resolución de masked/CAPTCHA o ejecución de JavaScript en un WebView.

## Datos, clave y compatibilidad

Room13/esquemas y dependencias iguales. Nueva actividad nativa no exportada, sin nuevo
permiso, servicio o proveedor. **CopiaJSON18, lee1–18**: incorpora el contrato nuevo de
adjuntos Gofile y valida grupo/ID/dirección al restaurar. Las versiones hasta0.35 no
leen18; no se recomienda volver a ellas para restaurar una copia nueva. Actualizar la
app no requiere reimportar ni cambia el esquema de la base de datos.

Token separado cifrado con AES-GCM/AndroidKeyStore, IV nuevo, AtomicFile, exclusión mutua
y sin fallback a texto plano. Queda en noBackupFilesDir, con alias y archivo distintos
de Rule34.xxx. Diálogo sin prellenar, FLAG_SECURE, campo sin estado guardado y limpieza
al cerrar. Borrar clave conserva contenido/archivos y espera. Copia18 no incluye tokens,
archivos cifrados o estado operativo de espera/cola/caché. Las referencias y nombres
sí pueden ser personales; la copia continúa siendo un archivo privado del usuario.

## Evidencia y pendientes

Referencia original fija: peach-mitao/peach de22796c04919aaa057d77930c33c81313765569,
src/peach/follow_gofile.py y tests/test_follow_gofile.py. Se inspeccionaron también
sus snapshots de Gofile/F95. Android reimplementa el subconjunto en Java, sin Python,
servidor, importación de cookies del navegador o credenciales incluidas en el APK.

Fuentes primarias consultadas el28 de octubre de2026:

- https://gofile.io/api
- https://gofile.io/js/pages/api.js — documentación actual y ejemplo de respuesta.
- https://gofile.io/js/services/contents.js — parámetros, gates y paginación.
- https://github.com/peach-mitao/peach/blob/de22796c04919aaa057d77930c33c81313765569/src/peach/follow_gofile.py
- https://github.com/peach-mitao/peach/blob/de22796c04919aaa057d77930c33c81313765569/docs/reference-snapshots/f95-masked-gofile-media.md

La página API devuelve un shell JavaScript; se recuperaron sus módulos oficiales
con HTTP200 para leer el contrato. Huellas/tamaños en evidence/0.36.0/audit-resources.json.
Una consulta real sin clave y con UUID ficticio recibió401/error-token; no acredita un
listado autenticado o acceso a medios. No se creó cuenta ni probó una clave del usuario.
Las pruebas de listado, revisión, almacenamiento y Media3 usan fixtures propios y
HTTPS/DNS simulados. PRUEBAS.md registra resultados exactos y los fallos corregidos.

Pendientes: validación física, API con cuenta autorizada real, rutas/nodos adicionales,
enlaces firmados/con cookies, contraseñas, sesión F95 y masked, otros sitios de archivos,
recorrido recursivo/lotes Gofile y demás paridad original. No se declara terminado Peach.
