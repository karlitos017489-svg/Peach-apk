# Comprobación breve de calidad0.35

Instala sobre0.34 sin desinstalar. Tus publicaciones y archivos guardados se conservan.

1. Abre una publicación de Rule34Video o cum.st que antes mostraba solo una muestra.
   En Ver videos, revisa las etiquetas. Si está marcada Vista previa, ese botón abre
   explícitamente la muestra; no la presenta como un original completo.
2. Pulsa **Consultar versiones** con Sin conexión desactivado. Revisa y pulsa **Usar
   versiones**. La consulta no descarga el video ni se aplica antes de confirmarla.
3. Elige la calidad declarada deseada y **Ver en línea**. La mayor altura reconocida
   se preselecciona para el primer grupo; también puedes elegir una versión menor.
   Comprueba carga, imagen/sonido y dimensiones cuando aparezcan.

Basta una publicación de Rule34Video y, si ya tienes una, otra de cum.st. No repitas
todas las fuentes ni instales el APK de pruebas. En Rule34.xxx se conserva el archivo
file_url publicado; si no hay alternativas o HD, la app no puede fabricarlos.

La fuente puede ofrecer solo una vista previa o baja resolución. Consultar versiones
puede no encontrar otro archivo. Los datos/alturas declarados no garantizan resolución
o duración real; el tiempo de inicio también depende del servidor y el contenedor.
Para conservar una copia completa verificada/offline siguen Preparar y reproducir,
Guardar adjunto y Cola de descargas. No hace falta borrar o volver a crear tu catálogo.

Si falla, basta la fuente, la etiqueta elegida y el mensaje/código. No envíes claves,
contraseñas o URLs firmadas. Alcance en CALIDAD_Y_VERSIONES.md y resultados en PRUEBAS.md.
