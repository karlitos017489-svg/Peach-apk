# Comprobación mínima de Peach Local0.32.0

Instala el APK sobre0.31 sin desinstalar, para conservar tus datos. No hace falta
instalar el APK de pruebas incluido en el ZIP ni repetir las nueve fuentes.

1. Abre una publicación importada con dos adjuntos compatibles y entra en **Cola de
   descargas**. Añade ambos. Hasta pulsar **Continuar cola** no debe empezar a bajar.
2. Inicia la cola, pausa un archivo que todavía esté descargando y vuelve a continuar.
   Si el servidor confirma el fragmento, continúa; si no, reinicia ese archivo desde
   cero. En ambos casos debe terminar completo, sin un supuesto archivo listo de0bytes.
3. Abre un video o imagen terminado. En **Elegir carpeta** selecciona una subcarpeta
   permitida y pulsa **Guardar completas**. Debe copiar ambos sin otra descarga.
4. Retira una copia privada desde la cola y comprueba que el archivo guardado en tu
   carpeta permanece. Salir y volver no inicia la red hasta pulsar Continuar cola.

Usa archivos propios o a los que tengas acceso. Mantén abierta la pantalla de cola
durante la descarga. Hasta128 trabajos,2GiB por archivo,4GiB de copias privadas y una
transferencia activa. Sin tamaño declarado se muestran bytes y no porcentaje.

Si aparece un problema, basta el mensaje exacto, si ocurrió al descargar/continuar/
guardar/abrir y la fuente. No envíes contraseñas, claves API o URLs firmadas. La cola
no recupera archivos antiguos vacíos ni hace compatibles todos los códecs de Android.

La copia personal JSON conserva catálogo y configuración compatibles, pero no los
fragmentos/trabajos operativos de la cola. No borres datos ni desinstales para actualizar.
El alcance técnico está en COLA_DESCARGAS.md; la evidencia propia, en PRUEBAS.md.
