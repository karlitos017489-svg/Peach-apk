# Peach Local0.28.0 — BIN, GIF y descargas grandes

1. Instala sobre0.27 sin desinstalar, conservando fuentes y datos.
2. En Rule34Video vuelve a Consultar cuerpo desde la fuente. Así se renuevan los
   adjuntos antiguos BIN. Si aparece una calidad MP4/WebM admitida, elígela.
3. Guardar adjunto descarga y comprueba primero. Después aparece el selector para
   elegir dónde guardarlo. Durante descargas grandes mantén abierta la app; puedes
   cancelar. Límite2GiB, con espacio necesario para temporal y copia.
4. Tras guardar pulsa Reproducir descarga. Para archivos anteriores usa Abrir video
   o GIF, elige el archivo y pulsa Reproducir descarga. Un GIF abre el visor de imagen
   animada; un BIN con cabecera de video reconocible abre el reproductor.
5. Un archivo que ya tenga0 bytes debe descargarse nuevamente: no contiene datos.
   La app no elimina tus archivos anteriores. Si se conserva solo una referencia,
   aún no existe una descarga directa admitida para esa dirección.

No hace falta volver a consultar todas las fuentes. Prueba un video MP4, un GIF y la
descarga grande que antes fallaba. Si aparece un error, envía el texto/código y la
fuente. No hacen falta claves API ni subir el contenido. La validación física sigue pendiente.

La limpieza de una copia fallida depende de que Android permita borrar ese documento
nuevo. No se promete reanudación, descargas por lotes ni todos los códecs/servidores.
