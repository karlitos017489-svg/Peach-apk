# Peach Local0.30.0 · guía breve

Instala Peach-Local-0.30.0-debug.apk sobre0.29 sin desinstalar.

La galería admite imágenes compatibles ya consultadas e importadas de FANBOX,
Pawchive, cum.st, Rule34 Paheal, Rule34.xxx y F95zone. No vuelve a descargar todas
las fuentes ni requiere computadora, Termux o servidor Peach.

1. En Publicaciones, abre una publicación importada que tenga imágenes compatibles.
   Organizar → Leer contenido consultado → toca el cuerpo → Ver imágenes.
2. Recorre con Anterior/Siguiente. Usa pellizco, doble toque o los botones para zoom.
   GIF/WebP se animan cuando contienen animación compatible; al salir se detienen.
3. Para comprobar la caché, después de ver una imagen activa Sin conexión y reabre
   esa misma imagen. No se consulta la red en ese modo. Una imagen aún no vista puede
   faltar; Android puede limpiar la caché. Desactiva ese modo para consultar otra.

Basta una publicación para la comprobación mínima; no necesitas repetir todas las
fuentes ni instalar el APK de pruebas. Las638 pruebas locales ya están ejecutadas.
Las32 instrumentadas están compiladas, sin ejecutar en dispositivo desde este entorno.

Si no aparece Ver imágenes, puede faltar consultar/importar el cuerpo, no haber
imágenes compatibles o existir solo una referencia externa. Las tarjetas públicas de
Patreon/SubscribeStar no incorporan adjuntos completos por este cambio. Los videos
conservan Guardar adjunto → Reproducir descarga y Abrir video o GIF para archivos locales.

Caché16MiB por imagen,64MiB/128 imágenes. Usa Guardar adjunto para conservar el original;
la caché es descartable y no se incluye en copias JSON. No se modifican tus fichas,
carpetas o visitas. El proyecto sigue en desarrollo.
