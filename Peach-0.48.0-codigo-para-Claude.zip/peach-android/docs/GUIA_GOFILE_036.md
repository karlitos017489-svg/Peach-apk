# Comprobación breve0.36

Instala sobre0.35 sin desinstalar ni borrar datos. Se conserva tu biblioteca.

1. Abre el contenido guardado de una publicación que tenga un enlace directo a una
   carpeta Gofile y pulsa **Enlaces Gofile**. Abrir no consulta internet.
2. Si ya tienes una clave de cuenta Gofile apta para el API, introdúcela únicamente
   en **Configurar clave Gofile** dentro de la app. No la envíes por chat. Gofile
   documenta que listar por API requiere Premium; no hace falta contratarlo para
   seguir usando las demás funciones de Peach.
3. Elige la carpeta y pulsa **Consultar archivos**. Revisa y pulsa **Incorporar
   archivos revisados → Incorporar**. Todavía no descarga videos o imágenes.
4. Vuelve a la publicación. Sus adjuntos compatibles ya pueden usarse con Ver medios,
   Guardar adjunto y Cola de descargas. Para video permanece Ver en línea.

Si no tienes esa clave, basta comprobar que abrir no consulta, Sin conexión bloquea
Consultar y consultar sin clave pide configurarla sin alterar la publicación. No hace
falta repetir las nueve fuentes o instalar el APK de pruebas. API rechazada/Premium,
archivo con sesión o enlace F95 masked no se presentan como archivos ya recuperados.

La cuenta, red y servidor reales no se verificaron desde aquí con tus datos. Si hay
un fallo, indica únicamente etapa y mensaje; no compartas token o URL privada.
CopiaJSON18 lee1–18; versiones anteriores de Peach no leen la copia nueva. GOFILE.md
explica alcance y PRUEBAS.md documenta la validación ejecutada.
