# Probar la parte 1 — Peach 0.42.0

1. Instala el APK sobre tu versión actual, sin desinstalar ni borrar datos.
2. Usa primero copias de un video o audio y sus archivos auxiliares.
3. Pausa el escaneo y espera a que termine. Abre Menú → Organizar archivos / papelera.
4. Selecciona el archivo y autoriza lectura/escritura de su misma carpeta raíz.
5. Prueba Renombrar → Vista previa → Aplicar. En Historial / papelera, Deshacer.
6. Elige una carpeta destino del mismo proveedor y prueba Mover y Deshacer.
7. Prueba Papelera y Deshacer: debe volver el archivo con sus favoritos/progreso.
8. Prueba Escribir NFO, revisa el XML y aplica. Deshacer debe restaurar el NFO previo
   exactamente, o retirar el recién creado. El historial permite exportar respaldos.
9. Revisa Contenido idéntico / Código NFO. Solo guarda grupos o listas tras revisar.

La vista previa no modifica archivos. Se mueve solo el archivo seleccionado:
subtítulos, NFO y portadas no se trasladan automáticamente. Los movimientos requieren
que Android permita mover dentro del mismo proveedor; una carpeta sin esa capacidad
se rechaza. No hay borrado definitivo de medios. Conserva la app instalada para
mantener historial y respaldos. Si aparece revisión pendiente, usa Reconciliar estado
antes de repetir: comprueba ubicaciones sin volver a ejecutar el cambio físico.

Esta es la parte 1 de 6. Al confirmar la prueba, sigue la parte 2 (fuentes/cuentas/
descargas), luego formatos, sincronización, interfaz y validación final.
