# Probar la parte 2 — Peach0.43.0

1. Instala sobre0.42 **sin desinstalar ni borrar datos**.
2. Fuentes → Cuentas y sesiones: si lo necesitas, inicia sesión en la página oficial
   del sitio y pulsa Guardar sesión, o importa una Cookie propia. No mandes cookies,
   claves o contraseñas por chat. Guardar no garantiza vigencia o suscripción.
3. Patreon/SubscribeStar: consulta novedades, toca una tarjeta y **Consultar cuerpo**.
   Revisa e importa. El texto visible continúa marcado parcial. Desde la publicación
   importada prueba sus medios compatibles; una portada no se convierte en adjunto.
4. FANBOX: sin sesión conserva los gratuitos; con sesión solo incluye acceso que la
   API devuelve explícitamente permitido. Prueba un archivo de video si el post lo tiene.
5. Descubrir / filtrar fuentes: aplica filtros locales o comparte/pega un enlace.
   Revisar y añadir solo guarda la fuente. Buscar títulos F95 requiere sesión propia;
   revisar un resultado no consulta su hilo automáticamente.
6. En una publicación con enlace individual Pixeldrain: **Enlaces Pixeldrain → Consultar
   archivo seleccionado → Incorporar archivo revisado**. Después usa Guardar adjunto,
   Cola o Ver medios. Depende de los límites/Premium/CAPTCHA del sitio. No admite listas.
7. Cola de descargas: elige adjuntos y **Descargar en segundo plano → Iniciar**. Prueba
   salir de la pantalla y pausar desde la notificación. Puedes volver a la cola y
   continuar manualmente. No arranca sola al reiniciar o forzar detención.
8. Comprueba que Biblioteca, favoritos, progreso y organización de la parte1 siguen bien.

Android puede interrumpir segundo plano por batería o tiempo; se conserva el fragmento
comprobado. La copia JSON ahora es19 y una app anterior no puede restaurarla. Cuentas,
claves y archivos se respaldan por separado. Detalles y límites en PARTE_2_FUENTES.md.
