# Probar Peach Local 0.44.0 · Parte 3 de 6

Instala sobre 0.43 sin desinstalar ni borrar datos. Conserva biblioteca, notas, listas,
fuentes y cuentas. Esta versión no necesita una computadora para funcionar.

1. Abre un ZIP/CBZ o ZIP64 compatible desde la biblioteca: Contenido permite escoger
   imagen o texto. ZIP64 mantiene 512 MiB por archivo y 64 MiB por entrada.
2. Abre un EPUB: Opciones → Índice del libro muestra los títulos NAV/NCX disponibles;
   elige una sección. Opciones → Buscar en el texto visible localiza una coincidencia.
   Contenido sigue mostrando capítulos e imágenes por archivo.
3. Abre un PDF. En Android 15+, Opciones → Buscar dentro del PDF busca 16 páginas por
   tanda. Selecciona una página o Siguientes 16. Un escaneo sin texto necesita OCR,
   que no está incluido.
4. Para PDF protegido o 7z compatible: Opciones → Contraseña de PDF / 7z. No se guarda;
   al rotar/reabrir debes volver a introducirla. PDF exige Android 15+. 7z exige cabecera
   sin compresión/cifrado; ZIP y RAR con contraseña siguen fuera del alcance.
5. En video o audio pulsa Info para ver las pistas detectadas y qué admite el decoder.
   En video, CC permite añadir SRT/VTT/ASS/SSA y elegir Unicode o Windows-1252. Los
   subtítulos encontrados al escanear siguen presentes; puedes elegir la pista con el
   control de subtítulos del reproductor.
6. Comprueba que las fuentes, cuentas y descargas de la parte 2 siguen funcionando.

El ZIP de muestras es opcional: contiene archivos propios pequeños para comprobar
ZIP64, EPUB2/3, PDF, 7z y contenedores. La contraseña de las muestras PDF/7z es
`test-only`. No es una cuenta, clave de firma o contraseña personal. Importa/escanea la
carpeta que autorices en Android; no se incorporan automáticamente a tu biblioteca.

Los RAR5 sólidos compatibles amplían diccionario hasta 64 MiB. RAR4 sólido, volúmenes,
contraseñas RAR, RAR7 comprimido y ANSI ambiguo siguen sin lector. No se promete leer
cualquier archivo o códec. No se añaden DRM, OCR, EPUB con CSS ni transcodificación.

La búsqueda/password PDF y la actualización real todavía requieren tu prueba en la
tablet. El informe distingue pruebas automatizadas, JNI Linux y tests Android solo
compilados. Si aparece un fallo, informa formato, acción y mensaje; no compartas
contraseñas o archivos privados para explicarlo.

Una vez confirmada esta parte, quedan las entregas 4 (importación/sincronización),
5 (interfaz/rendimiento) y 6 (validación/correcciones). Se corrigen primero los errores
que encuentres aquí. No hay APK intermedio por cada subfunción.
