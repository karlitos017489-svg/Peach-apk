# Probar Peach Local 0.45.0 · Parte 4 de 6

Instala sobre 0.44 sin desinstalar ni borrar datos. El menú nuevo es **Importación y
sincronización**. Las copias clásicas y el catálogo original permanecen en sus rutas.

## Guardar una versión

1. Pulsa Exportar nueva versión y da un nombre al origen, por ejemplo «Tablet».
2. El paquete se prepara antes del selector. Guarda el JSON donde elijas: carpeta local,
   USB o proveedor de documentos/nube que ya aparezca en Android.
3. Espera «guardada y comprobada». Cada exportación crea un archivo nuevo; no reemplaza
   otro intercambio compartido. Conserva las versiones que necesites y elige la más nueva.

Incluye notas, estado, metadatos, listas, entidades, deseos, fuentes/publicaciones,
lectura/historial y catálogos compatibles. No lleva medios, permisos o sesiones. El
JSON no está cifrado: puede contener notas, historial, cuerpos y enlaces personales.
La nube es opcional y la gestiona el proveedor que elijas; Peach no exige cuenta cloud.

## Llevar datos a otra biblioteca o dispositivo

1. Añade y escanea primero las carpetas que contienen los archivos en el equipo receptor.
2. Elige el JSON con Elegir intercambio para revisar. Todavía no se aplica nada.
3. En Vincular carpetas y documentos, asigna cada carpeta de origen a su carpeta local.
   Una ruta y tamaño iguales son una propuesta; no una comprobación del contenido por hash.
   Revisa los documentos no vinculados o elige un vínculo individual si corresponde.
4. Abre Revisar cambios por campo. En primer encuentro, diferencias existentes conservan
   lo local por defecto. Elige Entrante solo en lo que quieras traer; las adiciones nuevas
   compatibles se proponen. Usa filtro y Anteriores/Siguientes para recorrer la revisión.
5. Pulsa Aplicar cambios elegidos y revisa el resultado. Si cambió archivo/biblioteca/
   ubicación/escaneo/base, genera una revisión nueva. No mueve o borra tus originales.

Los documentos sin correspondencia permanecen en el JSON para otra revisión; no se
finge que estén disponibles. Se protegen listas incompletas y vínculos a archivos locales
ajenos al mapa. Datos incompatibles rechazan la aplicación completa, sin cambios parciales.

## Sincronizar en ambos sentidos

Después de importar en B, exporta una versión de B e impórtala en A. Continúa usando los
mismos orígenes. Las siguientes revisiones comparan con la última versión importada:
cambios independientes se proponen; cambios en el mismo campo se resuelven local/entrante.
No es automático ni en segundo plano. No propaga borrado de registros por faltar en un
archivo ni suma contadores. No permite que un paquete viejo deshaga versiones recientes.

En Orígenes de sincronización puedes olvidar una base: no elimina datos, pero reinicia
la comparación de ese origen. Se mantienen hasta cuatro. Si de verdad quieres restaurar
una versión antigua, olvida su base explícitamente y revisa de nuevo todas las diferencias.
El checksum no identifica al autor: usa archivos que hayas elegido intercambiar.

## Recuperación y ejemplo opcional

Deshacer última importación funciona solo mientras la biblioteca conserve el estado
posterior a esa operación. Si ya hiciste cambios nuevos, se rechaza para conservarlos.
Cuentas, originales, cola y permisos no se borran. No desinstales para probar.

El ZIP de ejemplo incluye un TXT y un JSON propio. Extráelo, escanea la carpeta que
contiene `documentos`, selecciona el JSON y vincula «Ejemplo propio». Revisa favorito,
título y etiquetas; las diferencias no se fuerzan por defecto. No incluye contraseñas.

Las pruebas propias distinguen Room/JVM/proveedor simulado de Android real. Actualización,
SAF/nube reales y permisos de la SM-X230 todavía requieren tu prueba. No se afirma acceso
API a 115/PikPak/OneDrive u otros servicios ni copia del ledger original completo.

Tras confirmar esta parte, quedan las entregas 5 (interfaz/rendimiento) y 6 (validación/
correcciones). Se corrigen antes los problemas que encuentres en esta parte.
