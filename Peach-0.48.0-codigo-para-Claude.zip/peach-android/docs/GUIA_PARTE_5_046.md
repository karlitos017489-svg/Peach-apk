# Probar Peach 0.46.0 · Parte 5 de 6

Instala encima de 0.45, sin desinstalar ni borrar datos. Se conserva la firma original.

## Lo que verás

Biblioteca tiene búsqueda, el botón Filtros y cuatro accesos abajo: Biblioteca,
Fuentes, Descargas y Ajustes. El botón + Carpeta añade ubicaciones. En ⋮ siguen las
herramientas de listas, grupos, identidades, publicaciones, historial, copias y archivos.
Filtros despliega tipos, estado, ubicación/lista, orden y exploración de metadatos.

En Ajustes puedes elegir tema claro/oscuro/del sistema, seis colores, tamaño de tarjetas
o vista de lista, transiciones suaves/deslizamiento/sin animaciones y un fondo propio.
El fondo se usa en Biblioteca y tiene intensidad ajustable para mantener legibles los
textos. Elige una imagen de hasta 16 MiB. Peach guarda una copia reducida del fondo;
puedes retirar el original después. Quitar fondo vuelve al color del tema. Los lectores
y el video mantienen sus controles propios. Los ajustes son locales de esta tablet.

Almacenamiento y caché muestra las copias temporales y espacio libre de Peach.
Limpiar retira caché libre; no borra tu biblioteca, cuentas, documentos ni descargas de
la cola. Los videos abiertos o en preparación se conservan. Una imagen/video temporal
retirado necesitará red para consultarse de nuevo. Drive administra su propia caché.

## Descargar un archivo directamente a Google Drive

1. Ten instalada la app del proveedor y tu cuenta configurada. La disponibilidad de
   Drive en el selector depende de Android y del proveedor.
2. Abre la publicación de una fuente y Guardar adjunto. Elige el archivo y después
   Guardar directo en nube o carpeta. En Videos también hay un botón directo para
   la variante que seleccionaste; comprueba si es original o vista previa.
3. Pulsa Elegir destino y guardar. En el selector de Android abre el menú lateral,
   elige Google Drive, su carpeta y Guardar. Cada transferencia crea un destino nuevo.
   Si Drive no aparece, revisa su app/cuenta; puedes elegir otro proveedor disponible.
4. Mantén la pantalla abierta hasta que diga Archivo entregado al proveedor. Peach
   transfiere sin crear un archivo completo en su propia caché. No tienes que moverlo
   manualmente desde Descargas. El proveedor puede usar espacio temporal propio.
5. Comprueba en Drive que terminó la subida. Peach no tiene acceso a la confirmación
   interna del servidor: cerrar el flujo del proveedor no certifica sincronización
   remota. No se promete un archivo sin uso de almacenamiento de Android/Drive.

Hasta 2 GiB por archivo, una transferencia directa activa y sin reanudación. Rotar
conserva el trabajo; salir de la pantalla lo cancela. Puedes pulsar Cancelar transferencia.
Si se interrumpe, comienza de nuevo. Se comprueba tamaño e integridad declarada por
la fuente; un archivo puede seguir siendo incompatible con un códec de tu tablet.
No se añade acceso a enlaces o contenido que la fuente antes no permitía descargar.
El nombre y tipo iniciales proceden de la fuente. Si su nombre viene como BIN o sin
sufijo, Preparar copia permite corregirlo desde los bytes antes de elegir el destino.

## Si queda un archivo incompleto

Peach intenta retirar solo el destino recién creado. Si Android/proveedor no lo permite
o el proceso se detuvo, entra a Ajustes → Almacenamiento y caché → Revisar transferencias
a nube y pulsa Revisar archivos interrumpidos. Comprueba el archivo en Drive antes de retirarlo. Retirar
incompleto intenta eliminar ese destino; Conservar archivo retira solo el aviso.
Si se perdió el permiso, revisa/elimina ese archivo desde Drive. No se hace limpieza
remota automática al iniciar Peach y no se reanuda una descarga sin tu acción.

Preparar copia y elegir destino conserva el flujo anterior con una copia temporal
comprobada. La cola de Descargas sigue ofreciendo pausa/reanudación y segundo plano
con sus límites previos; es distinta del flujo directo. Sus archivos no se borran al
limpiar la caché de imágenes y videos.

## Volumen

En video y audio, pulsa Vol. para abrir la barra de 0 a 100 %, Silenciar y Restaurar
sonido. En video el botón también queda disponible a pantalla completa. Este ajuste
controla solo el reproductor; los botones físicos controlan el volumen de Android.
Se recuerda el último nivel y no amplifica más allá del volumen multimedia del sistema.

Prueba estos cambios en la SM-X230. Las pruebas locales usan medios propios y un
proveedor simulado; todavía no se ha ejecutado esta versión en tu tablet ni con tu
cuenta real de Drive. Los fallos que encuentres se corrigen dentro de esta parte.
Después queda la parte 6: validación Android y correcciones finales.
