# Probar Peach 0.47.0 · Parte 6 de 6

Instala el APK encima de 0.46, sin desinstalar ni borrar datos. La firma es la misma.
Las partes 1–5 fueron aceptadas por ti. Esta entrega reúne comprobación local y
correcciones; tu prueba final en la Samsung sigue siendo necesaria.

| Qué validar | Dónde | Resultado esperado |
|---|---|---|
| Actualización y datos | Abre Biblioteca tras instalar | Carpetas, favoritos, listas y progreso anteriores siguen presentes. No vuelvas a conceder carpetas si ya funcionan. |
| Comprobación local | Biblioteca → Ajustes → Comprobar funcionamiento; también Biblioteca → ⋮ → Comprobar funcionamiento | Abrir no ejecuta pruebas. Pulsa Iniciar comprobación; aparecen ocho resultados con detalle. |
| Informe | Misma pantalla → Guardar informe | El selector de Android te deja elegir un nuevo documento JSON. El informe se conserva también dentro de Peach. |
| Rotación y cancelación | Durante la comprobación, gira la tablet; después prueba Cancelar comprobación | Rotar conserva la operación. Cancelar deja un resultado parcial y las pendientes como No comprobado. Salir cancela. |
| Fondo sin deformación | Ajustes → Elegir imagen de fondo; elige una imagen horizontal y gira la tablet en Biblioteca | Conserva proporciones con recorte centrado; puede recortar bordes. Quitar fondo lo elimina y no reaparece al reiniciar. |
| Volumen al salir | Abre un audio o video → botón Volumen; vuelve atrás con el diálogo abierto | Se cierra con el reproductor, sin ventana flotante ni cierre inesperado. Vuelve a abrir y comprueba volumen/silencio. |
| Guardado directo | Fuentes → publicación → Guardar adjunto → Guardar directo en nube o carpeta; en Videos también está el botón directo | Elige un nuevo archivo en Drive si aparece en tu selector; al terminar comprueba desde Drive que abre. Prueba primero un archivo pequeño. |
| RAR/CBR comprimido | Abre un archivo compatible desde Biblioteca → lector; si no tienes uno, usa la comprobación local | La muestra RAR5 debe dar Correcto; el lector abre las entradas compatibles sin cerrar el motor. Se conservan límites de formatos. |
| Uso anterior | Biblioteca, lector, audio/video, Fuentes y Descargas | Las funciones que ya aceptaste siguen funcionando. |

La comprobación usa muestras propias: firma, archivos privados, biblioteca temporal y
recuperación, PNG, PDF, una salida H.264, una salida AAC y RAR5 comprimido. No abre tus
archivos ni usa cuentas/red, y no emite sonido. Correcto solo acredita esa muestra;
Revisar requiere revisar el detalle; No comprobado no cuenta como aprobado. El informe
incluye modelo y versión de Android; tú decides si compartirlo. No se envía solo.

La comprobación de audio/video usa buffers y no mide altavoces, pantalla ni todos los
códecs. Abre además tus archivos habituales y prueba audífonos si los usas. Nube depende
del proveedor instalado/autorizado; este puede guardar caché o terminar la subida
después. Peach informa entrega al proveedor, no confirmación del servidor de Google.
Al salir se cancela una transferencia directa; girar conserva la operación.

Si encuentras un problema, indica la fila de esta tabla, los pasos y el texto del error.
Si falla la comprobación local, puedes adjuntar el JSON guardado. Para un fallo de Drive,
comprueba también el archivo en la app de Drive. No hace falta enviar credenciales.
Las incompatibilidades anteriores se conservan en COMPATIBILIDAD_ORIGINAL.md.
