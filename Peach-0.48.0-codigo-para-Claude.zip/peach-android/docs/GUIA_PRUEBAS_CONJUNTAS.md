# Una instalación · cuatro fuentes

0.26.0 se instala sobre0.25 sin desinstalar. Las pruebas automáticas ya cubren parsers,
datos, copias y errores. Esta guía limita la comprobación manual a acceso real, la
clave propia y el comportamiento Android que no se pudo ejecutar desde este entorno.
No hacen falta APKs separados o variantes menores para cada fuente.

1. En Fuentes → Añadir fuente registra una referencia que tú ya conozcas de cada sitio:
   etiqueta Paheal, etiqueta Rule34.xxx, autor Rule34Video e ID/URL de hilo F95zone.
   No uses las referencias sintéticas de las fixtures como ejemplos de contenido real.
2. En la fuente Rule34.xxx, Credenciales API permite guardar user_id y tu clave del
   sitio. No los compartas en el chat. Se configuran una vez para sus etiquetas.
3. Pulsa Consultar novedades en cada fuente. Si responde, revisa e importa una página.
   Lo esperado es ver registros con su proveedor correcto en Publicaciones, sin mezclar
   IDs, perder notas/títulos previos o descargar todos los medios automáticamente.
4. En Paheal y Rule34Video, Consultar cuerpo obtiene un detalle elegido. Revisa/importa
   otra vez y comprueba que siga disponible al volver sin conexión. En Rule34.xxx la
   ficha es metadata DAPI; F95 muestra respuestas públicas de latest, no todo el hilo.
5. Guarda un adjunto que la app marque como admitido en una carpeta Android. Tras
   Actualizar/autorizar esa carpeta, ábrelo desde el catálogo si su formato es compatible.
   Más128MiB, otro nodo/ruta, enlaces de servicios externos, masked o sesión requerida
   pueden quedar como referencia. Eso no requiere configurar un servidor Peach.

Para cada fuente distingue tres resultados: consulta/importación correcta, respuesta
del sitio bloqueada/no reconocida, o archivo guardado/abierto. Un error conservador
que preserva la caché comprueba el manejo del fallo, pero no significa que la conexión
a esa fuente ya funcione. No hace falta compartir la copia completa, claves o enlaces
privados: bastan el nombre del proveedor y el mensaje exacto si aparece un problema.

Kemono, Coomer y SimpCity están excluidos. FUENTES_CONJUNTAS.md conserva límites de
hosts, paginación, texto y credenciales. La aceptación general de0.25 no se aplica
automáticamente a la entrega0.26 ni ejecuta por sí sola las pruebas instrumentadas.
