# Comprobación breve0.38 — RAR/CBR parcial

Instala el APK sobre0.37 sin desinstalar ni borrar datos. No necesitas cookie F95,
cuenta nueva, servidor, PC o Termux para esta actualización.

No hace falta repetir las pruebas de las nueve fuentes. Opcionalmente usa los archivos
propios de samples dentro del ZIP: album-rar4.cbr y album-rar5.rar. Son texto e imágenes
sintéticas, sin contenido externo. Añade/escanea la carpeta con el permiso SAF habitual.
Abre uno en biblioteca, avanza de images/2.png a images/10.png y busca notes.txt o
notas/ñ.txt en Contenido. Cierra y abre para comprobar que conserva tu posición.

Si usas otro CBR y sale «comprimida», su método todavía está pendiente; la0.38 **solo
lee entradas almacenadas sin compresión**. No es necesario modificar tus archivos.
El índice permite consultar sus nombres y muestra el motivo de las entradas no legibles.
Un archivo sólido/multivolumen/cifrado/SFX o con variante no compatible puede rechazarse.

Estas comprobaciones en tablet son opcionales para validar el dispositivo real; el
informe distingue860 pruebas locales ejecutadas y50 Android compiladas sin ejecución.
No introduzcas cookies para probar este bloque ni envíes credenciales al chat.
