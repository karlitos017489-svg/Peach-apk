# Comprobación breve0.39 — RAR/CBR comprimido

Instala sobre0.38 sin desinstalar. No necesitas Cookie F95, PC, Termux o servidor.
No hace falta repetir las nueve fuentes. Si quieres comprobar el bloque, en samples del
ZIP del proyecto están own-rar4-m3.cbr y own-rar5-m3.cbr, con medios sintéticos propios.
Añade/escanea su carpeta y ábrelos en la biblioteca. En Contenido selecciona page.bmp
(imagen roja/azul) y notes.txt; cierra/reabre para comprobar la posición. Puedes usar tus
archivos compatibles sin extraer muestras. El lector no cambia los originales.

Si indica variante no compatible, sólidos, volúmenes, cifrado, Unicode heredado RAR4
o RAR7 comprimido siguen pendientes; no es una solicitud de servidor externo.
Error de CRC/memoria preserva el archivo y la vista anterior.0.39 no admite todos losRAR.

La suite local tiene881 pruebas aprobadas;52 Android solo compiladas. Las nuevas prueban
el motor Android aislado cuando se ejecuten realmente. La comprobación en tablet cubre
esa parte del entorno que no se puede verificar con el motor Linux o los dobles de IPC.
El ZIP pequeño de descarga contiene el mismo APK firmado. Extrae e instala eseAPK.
