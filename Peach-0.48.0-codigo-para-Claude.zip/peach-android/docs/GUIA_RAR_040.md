# Comprobación breve — Peach Local 0.40.0

Instala el APK como actualización sobre0.39, sin desinstalar ni borrar datos.
Biblioteca, fuentes, descargas, sesiones y copias conservan el formato anterior.

Si tienes un RAR/CBR con nombres antiguos que antes rechazaba por «Unicode heredado»,
ábrelo desde la biblioteca. Comprueba que el índice muestra correctamente los nombres
y que puedes abrir una imagen o texto, avanzar y volver. No necesitas una cuenta,
cookie, computadora ni convertir tus archivos para esta función.

El ZIP del proyecto contiene muestras propias opcionales en `samples/rar040`, con
texto de geología e imagen roja/azul. `legacy-stored.cbr` comprueba la copia directa;
`legacy-compressed.cbr` comprueba el motor aislado. No es necesario descargarlas
para usar o actualizar Peach.

Sólidos, volúmenes, contraseñas, nombres ANSI ambiguos y RAR7 comprimido siguen
pendientes. Una extensión CBR no garantiza que el método interno sea compatible.
Si algo falla, el texto del aviso y el tipo de archivo permiten acotar el problema;
no hace falta compartir sesiones ni contenido privado.
