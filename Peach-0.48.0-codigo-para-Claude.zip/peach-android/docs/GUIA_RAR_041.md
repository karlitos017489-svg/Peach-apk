# Comprobación breve — Peach Local 0.41.0

Instala sobre0.40 sin desinstalar ni borrar datos. Se conserva la firma original.

Abre un RAR/CBR sólido RAR5 compatible desde la biblioteca. Comprueba el índice,
selecciona una imagen o texto posterior, vuelve a una entrada anterior y cierra el
lector. Puede tardar más al cambiar: necesita reconstruir el diccionario compartido.
El archivo original no se modifica. No requiere cuenta o conexión a internet.

Muestra propia opcional en el ZIP del proyecto:
`samples/rar041/own-solid-rar5-m3.cbr`, con textos de geología e imagen roja/azul.
No necesitas descargar el proyecto para instalar o seguir usando la aplicación.

Este bloque no abre RAR4 sólidos ni todos los RAR5 sólidos. Subconjunto: entradas
comprimidas no vacías hasta64MiB, mismo diccionario hasta16MiB y total declarado128MiB;
sin contraseñas o volúmenes. El aviso explica si se excede el alcance.
Abrir una entrada verifica su contenido; no certifica los archivos anteriores.

El resto de lectores, fuentes y descargas mantiene sus funciones anteriores.
