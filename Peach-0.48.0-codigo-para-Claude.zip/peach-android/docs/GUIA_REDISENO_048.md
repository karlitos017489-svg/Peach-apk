# Peach 0.48.0 · Guía del nuevo diseño

Instala la APK **encima de 0.47.0**, sin desinstalar ni borrar datos.

## Qué cambió y dónde está

| Lo que quieres hacer | Dónde está ahora |
| --- | --- |
| Abrir un archivo local | **Biblioteca → toca su portada** |
| Ver detalles y organizar ese archivo | Botón pequeño **⋮** en la portada, o mantenla pulsada |
| Buscar, filtrar o cambiar orden en Biblioteca | Buscador y **icono de filtros** a su derecha |
| Añadir una carpeta | Botón **+** arriba de Biblioteca |
| Actualizar el escaneo o revisar carpetas | **⋮** arriba de Biblioteca |
| Consultar contenido de un sitio | **Fuentes**, en la barra inferior |
| Buscar un creador, etiqueta o enlace | Elige el sitio en **Buscar en**, escribe arriba y pulsa la lupa |
| Volver a una fuente guardada | Toca su nombre debajo del buscador |
| Leer una publicación | Toca su tarjeta: se abre **dentro de Fuentes** |
| Reproducir un video de esa publicación | **Reproducir**, dentro de la publicación |
| Ver sus imágenes | **Ver imágenes** o su vista previa |
| Guardar un archivo en Drive o una carpeta | Icono de descarga junto al archivo → **Directo a nube o carpeta** |
| Ver publicaciones ya guardadas | **Fuentes → Guardadas** |
| Volver de una publicación a tus resultados | Flecha de arriba o Atrás de Android |
| Cambiar el orden o filtrar esos resultados | Icono de filtros junto al título de la fuente |
| Cuentas, sesión F95 y clave API | Icono de opciones de Fuentes; también **Ajustes → Cuentas y sesiones** |
| Fondo, colores, tema y animaciones | **Ajustes → Apariencia** |
| Listas, grupos, identidades, deseos y organización | **Ajustes → Biblioteca** |
| Copias, sincronización y caché | Sus categorías en **Ajustes**; puedes usar su buscador |
| Iniciar o pausar las descargas | **Descargas** en la barra inferior |
| Carpeta de descargas y segundo plano | Botón de opciones arriba de **Descargas** |
| Volumen del reproductor | Icono del altavoz: abre un control compacto, con deslizador y silencio |

## Prueba rápida en tu tablet

1. Confirma que siguen tus carpetas, favoritos, listas y progreso después de actualizar.
2. En **Biblioteca**, abre un archivo tocando su portada. Revisa sus detalles con el pequeño ⋮. Comprueba que el ⋮ superior solo tiene escaneo, carpetas y Ajustes.
3. En **Fuentes**, elige uno de tus sitios y busca como lo hacías antes, con nombre, etiqueta o enlace compatible. Deben aparecer tarjetas, con imágenes cuando la fuente proporcione vistas previas compatibles. Verifica que identificas el sitio, creador y página que estás viendo.
4. Abre una publicación desde su tarjeta. Lee y reproduce o guarda desde ahí. Vuelve atrás: deben seguir los mismos resultados. Gira la tablet y comprueba que no te manda a otra sección.
5. Abre **Guardadas** en Fuentes para revisar publicaciones anteriores. Usa filtros y orden para encontrarlas.
6. En un video, muestra los controles y toca el altavoz. Prueba volumen, silencio, restaurar sonido y salir con el control abierto. Revisa también audio, subtítulos y pantalla completa.
7. Prueba en vertical y horizontal. En **Ajustes → Apariencia**, cambia tema/color/fondo y comprueba que tus opciones de personalización siguen funcionando.
8. Guarda un archivo pequeño hacia Drive, si aparece como proveedor en el selector de Android, y confirma que abre desde Drive.

## Sobre las vistas previas y la búsqueda

Las tarjetas muestran las imágenes que la fuente haya entregado y que Peach pueda abrir. Si no hay una imagen compatible, muestran una tarjeta de texto/archivo; una miniatura no convierte un adelanto en el video original ni desbloquea contenido restringido. Al abrir una publicación compatible, se consulta su cuerpo en la misma pantalla.

La búsqueda usa las capacidades que ya tiene cada sitio: etiquetas en Rule34, autor/creador o enlace en otros, títulos de hilos con sesión en F95. En Pawchive y cum.st puedes pegar el enlace o servicio/ID; también elegir tus fuentes guardadas por su nombre. No se anuncia un buscador global de creadores donde el conector no lo incorpora.

No hace falta importar una página completa para abrir una publicación. Al pedir su lector, reproductor u organización, Peach conserva solo esa publicación revisada y sus metadatos; los archivos se descargan únicamente con sus acciones correspondientes. Para conservar toda la página sin descargar sus archivos, usa **Opciones de Fuentes → Guardar página consultada**.
