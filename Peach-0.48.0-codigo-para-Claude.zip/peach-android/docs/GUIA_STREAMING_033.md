# Comprobación breve de Peach Local0.33.0

Instala sobre0.32 sin desinstalar. No necesitas instalar el APK de pruebas ni repetir
las nueve fuentes. Basta un video compatible de una publicación que ya hayas importado.

1. Fuentes → publicación importada → Ver videos → elegir video → **Ver en línea**.
   Desactiva Sin conexión si el botón está deshabilitado. Debe abrir el reproductor
   sin pedir carpeta o mostrar Preparando video completo.
2. Comprueba imagen/sonido, pausa y continúa. Intenta adelantar. Si el servidor no
   permite comprobar rangos, la app debe explicarlo y ofrecer preparación completa;
   no debe crear un BIN vacío o descargar todo el prefijo para aparentar un salto.
3. Gira la tablet: conserva posición y pausa, aunque puede volver a pedir datos.
   Sal del reproductor para detener la conexión. Ver en línea no conserva una copia
   offline; Preparar y reproducir y Cola de descargas siguen disponibles para eso.

Se reciben datos por internet y se usa memoria temporal. No significa consumo cero
ni calidad automática como YouTube. El servidor, formato y códec determinan si puede
comenzar pronto o necesita preparación completa. No se verifica el archivo entero
antes de mostrarlo en este modo. Para conservar/comprobar el original usa la descarga.

Si falla, basta el mensaje/código, la fuente y si ocurrió al empezar o adelantar.
No envíes contraseñas, claves o enlaces firmados. No se requieren archivos privados.
STREAMING.md detalla los límites y PRUEBAS.md contiene la evidencia propia.
