# Comprobar la corrección de Ver en línea0.34

Instala sobre0.33 sin desinstalar. No borres datos, caché o publicaciones, ni necesitas
volver a consultar/importar el contenido. La corrección está en la integración del
reproductor, no en el archivo guardado de la publicación.

Abre el mismo video de la captura: publicación importada → Ver videos → Ver en línea.
Comprueba comienzo de imagen/sonido y pausa. Basta ese caso; no repitas las nueve fuentes.
Si puedes, intenta después un salto, que sigue dependiendo del archivo y servidor.

La app ya acepta la indicación interna que añade Media3 al cargar el video. No la
transmite al servidor ni incorpora cookies, cuentas o direcciones nuevas. Un rechazo
interno se informa como problema de Peach; si el servidor devuelve realmente un estado
HTTP, ese número aparece en el mensaje, junto al código Media3.

Las pruebas propias reprodujeron el mensaje0.33 con un video propio y su producción
sin modificar; el recorrido corregido prepara un periodo progresivo real y entrega
muestras H.264. El acceso al video de tu captura y su reproducción física siguen
pendientes de comprobar en la tablet. Si falla, basta el mensaje/código nuevo y la fuente;
no envíes claves, contraseñas o enlaces firmados.

Streaming recibe datos y usa memoria temporal. Preparar y reproducir/Cola de descargas
mantienen copia completa/verificación/offline; Ver en línea no verifica el SHA completo
antes de mostrar. STREAMING.md y PRUEBAS.md documentan alcance y evidencia.
