# Peach Local0.31.0 · videos desde publicaciones

Instala Peach-Local-0.31.0-debug.apk sobre0.30 sin desinstalar.

1. Abre una publicación que tenga un video compatible ya consultado e importado:
   Publicaciones → Organizar → Leer contenido consultado → toca el cuerpo.
2. Pulsa Ver videos. Si hay imágenes y videos, usa Ver medios → Ver videos.
3. Elige un video y pulsa Preparar y reproducir. Espera la copia completa privada;
   después se abrirá el reproductor. No pide carpeta y no reproduce mientras descarga.

La preparación puede cancelarse. Mantén esa pantalla abierta mientras descarga;
rotar conserva el trabajo y la selección. Salir cancela la preparación activa.
Una copia válida se reutiliza al volver a elegir el mismo video.

Sin conexión solo abre copias válidas disponibles; no descarga. La caché es privada
hasta2GiB/8 archivos completos, con espacio compartido entre videos abiertos; Android
puede limpiarla. Retirar copia temporal permite consultar de nuevo si ya cerraste su
reproductor. Guardar adjunto mantiene la opción de conservar un original en una carpeta;
puede volver a descargarlo y no exporta automáticamente esta caché.

Para comprobar esta etapa basta un video: ábrelo desde su publicación y, tras volver,
activa Sin conexión y ábrelo otra vez. Puedes comprobar pausa/posición al girar la tablet.
No necesitas repetir todas las fuentes ni instalar el APK de pruebas.

662 pruebas locales aprobadas.34 instrumentadas compiladas y0 ejecutadas desde este
entorno, sin tablet/emulador conectado. Compatible no significa todos los formatos:
el reproductor sigue dependiendo de los códecs del dispositivo. Otros enlaces/formatos
conservan el guardado manual y apertura local anteriores. La cola y reanudación serán
el siguiente bloque; el proyecto sigue abierto.
