# Peach Local0.27.0 — videos ya descargados

1. Instala el APK sobre0.26, sin desinstalar.
2. Entra en Fuentes y pulsa Abrir video local.
3. Elige uno de los videos que ya guardaste. Si aparece como archivo genérico o .bin,
   también puedes seleccionarlo; no hace falta descargarlo de nuevo.
4. Pulsa Reproducir descarga. Se abre el reproductor nativo con ese documento.
5. Prueba reproducir y avanzar. Después de una descarga nueva admitida también puedes
   pulsar Reproducir descarga sin escanear primero su carpeta.

La opción directa no añade fichas/listas/estadísticas de catálogo. Para ello añade o
actualiza la carpeta en Biblioteca como antes. Si cierras el proceso, vuelve a elegir
el archivo; no necesitas redescargarlo. Los códecs dependen de Android y del archivo.

Si sigue fallando, mantén pulsado el error para copiar su código y envíalo junto con
el nombre de la fuente. Si no muestra error y solo hay audio o pantalla negra, indica
eso. No envíes claves API ni el video. La causa real continúa pendiente de confirmar.
