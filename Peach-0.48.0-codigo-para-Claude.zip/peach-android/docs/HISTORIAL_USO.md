# Historial de uso — Peach Local 0.20.0

Abra **⋮ → Historial de uso**. La cronología recoge visitas nuevas de audio/video,
imágenes y lecturas. Una visita se empieza cuando el reproductor está preparado o
el visor/lector muestra contenido válido; un archivo que falla antes no añade una
apertura ficticia. El historial comienza en0.20; los contadores y fechas anteriores
se conservan, pero no permiten reconstruir sesiones pasadas.

## Consultar y administrar

- Cada fila muestra inicio, tipo, título de esa visita y último estado guardado.
- Puede filtrar Video/Audio/Imagen/Lectura, buscar títulos y elegir todo/Hoy/7/30 días.
  Fechas según calendario y zona horaria del dispositivo, no bloques fijos de24 horas.
- La búsqueda normaliza Unicode NFC/minúsculas; %/_ son texto literal, no comodines.
  Busca el título histórico, limitado a300 unidades UTF-16, no cuerpos o nombres nuevos.
- Páginas de100 registros, de más recientes a antiguos. Los totales corresponden al
  filtro: sesiones, documentos distintos y sesiones que alcanzaron un final AV.
- Toque una fila para ver último punto, duración AV, entrada y página/capítulo/desplazamiento
  de lectura. **Abrir documento** usa el documento actual y su progreso actual; no mueve
  el progreso al punto histórico. Solo se ofrece si el catálogo aún permite abrirlo.
- **Borrar registro** quita esa visita. **Vaciar historial** pide confirmación y quita
  todas. No cambian archivos, favoritos, progreso, títulos personales o contadores.
  Una copia anterior puede recuperar registros.

Hasta10.000 visitas globales por fecha de inicio guardada; crear otra descarta las
más antiguas, sin borrar documentos. No es un historial ilimitado. Quitar una carpeta
borra sus documentos del catálogo y sus visitas; la pantalla de Carpetas lo indica.
La ausencia temporal de un archivo conserva los registros. La hora guardada depende
del reloj del dispositivo; no se corrige una fecha de inicio equivocada del sistema.

## Qué representa una visita

Audio usa el token del servicio, no el de cada pantalla/controlador. Reconectar,
recrear su pantalla o volver al mismo audio pausado no crea otro registro. Al cambiar
de pista se cierra el anterior; volver a ese archivo después puede crear otra visita.
Detener guarda/cierra. El checkpoint sigue el guardado AV de5 segundos y eventos de
pausa/cambio/final/error. No es una nueva dependencia de un servidor: el servicio es Android.

Video usa la visita de su pantalla actual, guardando al pausar/cambiar/salir y con el
checkpoint AV existente. Lectura conserva una visita para el documento completo al
cambiar entrada/capítulo/página; guarda al mostrar contenido y al pausar. Imágenes
crean visitas al decodificar cada documento y al navegar. Zoom o favoritos no son
visitas adicionales. Los estados terminales de final/error sobreviven al cierre.

El token se reserva antes de cargar y se guarda en el estado de pantalla; esto evita
que callbacks tardíos y una recreación en el mismo proceso dupliquen una apertura.
No se escribe una sesión solo por reservar un token. Un proceso nuevo crea otra
visita al abrir correctamente; el anterior conserva su último registro, sin inventar
un cierre que Android no notificó. Repetir el mismo archivo dentro de la visita
actual permanece en ella; no es una clasificación de cada intento/replay individual.

Los checkpoints actualizan filas existentes: si borra una visita mientras reproduce,
no reaparece por el siguiente guardado. La próxima visita distinta sí puede registrarse.
La columna updatedAt no retrocede si el reloj cambia hacia atrás durante la visita.

**El último estado no indica reproducción en vivo.** No se calculan horas vistas,
tiempo efectivo, porcentaje de atención, pausas exactas, número de saltos, intervalos
continuos o duración de lectura desde una posición o entre dos fechas. «Final AV»
se marca al alcanzar el final/transición automática, no solo por superar95 %. El
visto/progreso anterior conserva su regla95 % independiente. No se da por terminada
una lectura o imagen por haberla abierto.

## Datos y recuperación

Room v13 añade usage_sessions con FK a media e índices de mediaId/inicio+UUID.
La migración12→13 no altera tablas existentes ni genera visitas retroactivas. Las
cadenas anteriores siguen migrando. El título es una instantánea con límite300 y
un índice de búsqueda derivado; entry conserva hasta4096 unidades, página hasta100.000
y desplazamiento hasta10.000.000. No se añade URI de apertura al historial.

La copia JSON v11 incluye las visitas y se siguen leyendo v1–v10. Leer una copia
antigua conserva el historial actual. En v11 se validan tipos/límites/UUID y la
identidad mediaId/tipo/inicio, sin duplicados por UUID. Si un UUID ya existe, se conserva
el checkpoint más reciente; la misma fecha conserva el actual. Una identidad distinta
aborta la restauración completa. Documentos no indexados se omiten después de validar
su registro. La restauración no convierte sesiones en contadores ni altera el progreso
por ellas; los otros campos de la copia mantienen su comportamiento previo.

El límite total de copia sigue siendo8 MiB: el historial cuenta para ese tamaño y
podría hacer que una copia muy grande se rechace. No se trunca silenciosamente una
exportación para ocultarlo. La fusión se acota finalmente a las10.000 visitas recientes.
No hay exportación/importación integral de la actividad del ledger original.

No se añaden permisos, cuentas, red, analítica, dependencias o servicios nuevos.
El original web_activity.w_activity mantiene métricas agregadas más amplias que aún
faltan aquí. PRUEBAS.md separa pruebas JVM/Robolectric de instrumentación compilada
sin ejecutar. La aceptación general más reciente es0.19; 0.20 aún no está validada
físicamente. No se atribuye una prueba de hardware o salida de audio al Player simulado.
