# Identidades, relaciones y deseos en Peach Local 0.7.0

Estas funciones se conservan en 0.8.0. La copia actual es JSON v5 y añade posiciones
de lectura; se sigue importando v4. El lector se describe en LECTURA_LOCAL.md.

**Explorar metadatos y grupos → Identidades y alias** abre fichas locales con ID
propio, tipo, nombre principal, notas, favorito, alias y referencias externas.
También se accede desde ⋮. Las fichas no necesitan un archivo para existir.

## Identidades y alias

Los tipos siguen los dominios performer, studio, creator, series y tag del original:
reparto; estudios; creación/dirección/música; series/colecciones; etiquetas/géneros.
Se elige el tipo al crear la ficha. El tipo queda fijo; una persona que aparezca en
distintos dominios puede tener fichas separadas. El nombre principal puede cambiarse
y su escritura anterior se conserva como alias dentro de la misma identidad.

Los nombres y alias se comparan exactamente, distinguiendo mayúsculas, puntuación
y acentos. No se transliteran ni se fusionan automáticamente. Un nombre/alias no
puede pertenecer a dos identidades del mismo tipo; un conflicto rechaza el cambio
completo. El mismo nombre en tipos diferentes está permitido. «Rivera, Ana» es un
solo nombre si se ha releído el NFO con la estructura añadida en 0.6.0.

En una ficha, **Organizar** permite editar nombre/notas, marcar favorito, añadir o
retirar alias, vincular archivos con una función, retirar vínculos manuales, gestionar
referencias externas, añadir una obra a deseos y eliminar la identidad. La búsqueda
de esta pantalla encuentra también alias y notas. La sección selecciona todas las
identidades, un tipo específico o la lista de deseos; búsqueda/sección se conservan
al recrear la pantalla.

Desde **Detalles de un archivo → Editar / organizar → Vincular a una identidad**
se elige una ficha y su función. Crear una ficha desde ese flujo añade un vínculo
con la función general de su tipo. En las fichas existentes puede elegirse, por
ejemplo, Dirección o Artista musical para una identidad creator.

Si se ha abierto un término de metadatos en la biblioteca, el formulario de identidad
propone ese nombre y su tipo compatible al entrar desde ⋮. Es una propuesta de
formulario; no crea fichas ni registra una identidad sin una acción explícita.

## Procedencia de las relaciones

Cada relación indica una de estas procedencias:

- **Metadatos NFO**: coincidencia exacta del nombre principal o un alias con un término
  de reparto/estudio/dirección/artistas/series/colección/etiquetas/géneros del catálogo.
  Se deriva al consultar la ficha. No se escribe como vínculo manual ni se modifica el NFO.
- **Etiqueta personal**: coincidencia con las etiquetas personales de un archivo.
  Tiene prioridad sobre sus etiquetas importadas, igual que en el explorador anterior.
- **Vínculo manual**: asociación explícita de documento, identidad y función. Permanece
  al reescanear aunque cambie el nombre importado. Puede retirarse independientemente.

Retirar un alias puede retirar coincidencias NFO, pero conserva los vínculos manuales.
Quitar un vínculo manual no oculta una relación que todavía esté descrita por el NFO.
Los documentos se cuentan una vez aunque tengan varias funciones o procedencias.
La ficha muestra hasta 100 relaciones; **Ver archivos** abre todos los documentos
relacionados en la biblioteca. Búsqueda, filtros, favoritos y orden funcionan en ese
ámbito. El ámbito de identidad se conserva al recrear la biblioteca y se transmite
al visor de imágenes y a la cola de audio. Toda la biblioteca retira el ámbito.

Las relaciones importadas son una proyección de los metadatos actuales. Todavía no
son un registro histórico de cada fuente, confianza, revisión o versión de una
afirmación del ledger original. No se generan candidatos por IA ni se declaran
aprobadas identidades inferidas. Las fichas y los alias se crean mediante acciones
explícitas del usuario; los nombres coincidentes no fusionan documentos o progreso.

## Referencias externas

Una referencia contiene proveedor, identificador y URL HTTPS opcional. Se puede
crear, editar y eliminar sin red; varios identificadores del mismo proveedor son
válidos. Actualizar la misma pareja proveedor/ID reemplaza su URL. Los identificadores
no activan una conexión ni una búsqueda y los enlaces se muestran como texto seleccionable.
No se consulta el sitio, no se verifica esa identidad contra una API y no se abre un
navegador automáticamente. No hay claves, login o tokens de proveedores en este módulo.

## Obras deseadas

En **Lista de deseos**, registre un título, código opcional y notas sin importar
que exista un archivo. Desde una ficha de identidad, **Añadir obra a deseos** deja
además esa asociación. La entrada tiene su propio UUID y no se mezcla con listas
de reproducción ni con grupos de versiones.

En **Organizar** de la obra puede editarse, vincularse a un documento del catálogo,
retirarse ese vínculo o eliminarse la entrada. La vinculación es explícita; el código
se conserva como texto y no provoca coincidencias o descargas automáticas. La lista
distingue Pendiente de conseguir y Vinculada a un archivo. Una raíz temporalmente
inaccesible conserva el registro documental y sus vínculos.

Todavía faltan las fases y reglas completas del original: fecha de estreno, publicación
de origen, normalización/reconciliación automática de códigos, intentos de búsqueda,
abandono temporal, descargas y seguimiento de fuentes. Esta es una lista local usable,
no una afirmación de paridad del dominio wants original.

## Datos y recuperación

Room v6 crea cinco tablas: catalog_entities, entity_aliases, media_entity_links,
entity_references y want_items. Las claves externas eliminan hijos de una identidad
y ponen a NULL la referencia opcional de un deseo. Eliminar una identidad conserva
medios, progreso, listas, grupos y deseos; eliminar una raíz de Peach elimina sus
registros y vínculos documentales, y conserva la obra deseada sin archivo vinculado.
Los archivos originales nunca se escriben ni se borran mediante este módulo.

Las copias JSON v4 contienen estas fichas, alias, vínculos manuales, referencias y
deseos junto al estado previo. Importan v1/v2/v3 sin cambiar la organización nueva.
En v4 se reemplazan por UUID las fichas entrantes y sus hijos; otras fichas/deseos
se conservan. Alias conflictivos, tipos, funciones, referencias o colecciones inválidos
provocan rollback de toda la copia, incluido el progreso que se hubiera leído antes.
Los vínculos a documentos no indexados se omiten; una obra deseada con ese vínculo
se conserva como pendiente. Para recuperarlos, indexe las carpetas antes de restaurar.

Límites por copia: 8 MiB; 5.000 identidades, 20.000 alias, 50.000 vínculos manuales,
20.000 referencias externas y 5.000 deseos. Siguen vigentes los límites de estado,
listas y grupos de ORGANIZACION.md. La copia no incluye los medios, permisos SAF,
metadatos NFO completos ni la base de escritorio. Es una copia de información personal.

El APK continúa autónomo y sin permiso INTERNET. Este módulo no introduce servidor,
Termux, WebView, Python embebido ni nuevas dependencias de ejecución.
