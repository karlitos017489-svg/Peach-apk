# Imágenes y audio en Peach Local 0.5.0

Esta entrega agrupa galería, audio, filtro por tipo y migración. La versión 0.4.0
ya fue aceptada por el usuario en SM-X230. Se automatizan las comprobaciones locales
antes de pedir otra instalación; no se exige repetir cada prueba de versiones previas.

## Acceso y catálogo

El control superior permite Videos, Imágenes, Audio o Todos los medios. Al actualizar
desde 0.4.0 se conserva inicialmente la vista Videos; la elección nueva se guarda.
Use **⋮ → Actualizar** una vez para añadir imágenes y audio de las carpetas autorizadas,
o añada otra carpeta. Solo se solicita lectura mediante el selector Android.

Room v4 agrega mediaType con valor predeterminado video. La migración no reescribe
identificadores, URI, NFO, títulos/etiquetas personales, listas, favoritos, visto ni
progreso. Los esquemas anteriores conservan sus migraciones. La clasificación se
actualiza durante el escaneo y no forma parte de la copia personal JSON v2: procede
del archivo indexado. Las copias v1/v2 siguen siendo compatibles.

| Tipo | Extensiones indexadas | Apertura |
|---|---|---|
| Video | mp4, m4v, mkv, webm, mov, avi, ts, m2ts, mpg, mpeg, wmv, flv, 3gp | Media3, como antes; contenedor/códecs compatibles necesarios |
| Imagen | jpg, jpeg, png, webp, bmp, gif, heic, heif | Visor nativo; depende de los decodificadores disponibles en Android |
| Audio | mp3, m4a, aac, wav, flac, ogg, oga, opus, amr | Media3; el contenido y los códecs deben ser compatibles |

Que una extensión se indexe no garantiza que el dispositivo decodifique cualquier
contenido con ese nombre. HEIF/HEIC depende del Android instalado. GIF y WebP animados
se muestran como imagen fija. No se incorporan FFmpeg, conversiones universales,
RAW, SVG, archivos comprimidos ni documentos remotos STRM.

## Galería

- Toque una tarjeta de imagen para abrirla. Hay anterior/siguiente, favoritos, ficha,
  ampliación/reducción y ajuste a pantalla; también pellizco, arrastre y doble toque.
- La navegación respeta carpeta, búsqueda, filtro y orden con los que se abrió. Una
  lista mixta se recorre como secuencia de imágenes, por separado de audio/video.
  Los medios marcados no disponibles se omiten salvo la selección explícita.
- La carga ocurre fuera de la interfaz. Se leen dimensiones antes de decodificar,
  se limita la vista a un máximo de 2048 píxeles por lado y las miniaturas a 640.
  El zoom actúa sobre esa vista reducida, hasta 6×; no es un visor de resolución
  original ilimitada. Se rechazan dimensiones declaradas superiores a 1,000,000 px.
- Se aplican las ocho orientaciones EXIF, incluidos reflejos. Si el formato no admite
  esos metadatos, se usa la orientación codificada del archivo.
- Cambiar de imagen invalida la carga anterior. Una respuesta antigua no puede
  sustituir la imagen actual. Al recrear la pantalla se conserva el identificador
  actual, aunque el zoom vuelve al ajuste inicial.
- Abrir una imagen correctamente incrementa sus aperturas y última apertura, pero no
  crea una posición temporal ni la marca vista automáticamente. El estado visto puede
  cambiarse manualmente desde Editar / organizar. Los favoritos son los mismos del catálogo.

## Audio

- Se reproduce en el mismo motor local Media3 con controles de pausa, desplazamiento,
  anterior/siguiente y progreso individual guardado. La pantalla identifica el audio
  y oculta el selector manual de subtítulos. No mantiene encendida la pantalla por audio.
- Sin una lista seleccionada, la cola usa los audios del ámbito de biblioteca abierto.
  Dentro de una lista usa su orden manual de audio/video y omite las imágenes.
- Al salir del reproductor o bloquear la tablet, se pausa y guarda la posición.
  Todavía no hay servicio en segundo plano, notificación musical, controles externos
  persistentes, repetición/aleatorio ni ecualizador.
- El escaneo inicial usa el nombre del archivo y el NFO coincidente, si existe, para
  el catálogo. No importa automáticamente etiquetas ID3/álbum del audio al catálogo.
  El reproductor obtiene duración y pistas al abrir el archivo.

## Portadas y listas mixtas

Las imágenes utilizadas efectivamente como portada no se duplican como fotos sueltas.
Los nombres del mismo archivo y -poster tienen prioridad. Una carpeta de un solo video
admite poster/folder/cover; el audio admite esas portadas genéricas también en álbumes
con varios audios. Una carpeta que solo contiene fotos indexa incluso cover.jpg.
No se modifican ni eliminan esos archivos; otros diseños de carátulas no se infieren.

Las listas almacenan identificadores globales y pueden contener videos, imágenes y
audio. Borrar una lista conserva los archivos. La reproducción de audio/video y la
navegación de imágenes son secuencias distintas; no hay una presentación alternada
automática de fotos y videos. Los cambios personales se conservan al reescanear.

## Validación y siguientes etapas

PRUEBAS.md distingue unidades, SQLite, proveedor simulado, gráficos nativos de
Robolectric y extractor WAV de las pruebas físicas de Samsung. La automatización no
certifica sonido, MediaCodec, microSD, batería ni todos los gestos del dispositivo real.
Se conserva la batería instrumentada para un entorno Android completo operativo.

Se entregan juntos el APK y las evidencias. La comprobación física siguiente puede
limitarse a abrir una imagen propia, probar zoom y reproducir un audio propio; las
pruebas generales anteriores no necesitan repetirse sin una regresión concreta.

Fuentes primarias consultadas:
- https://developer.android.com/media/media3/exoplayer/supported-formats
- https://developer.android.com/topic/performance/graphics/load-bitmap
- https://robolectric.org/javadoc/latest/org/robolectric/shadows/ShadowNativeBitmapFactory.html
