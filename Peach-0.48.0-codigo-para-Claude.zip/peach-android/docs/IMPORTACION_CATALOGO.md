# Catálogo original: importación revisable en 0.9.0

La pantalla **⋮ → Catálogo de Peach original** lee una copia SQLite autónoma de
ledger.db o un JSON `peach-catalog-transfer` versión 1. Todo el proceso ocurre dentro
del APK. No se conecta al programa de Windows ni necesita que esté ejecutándose.
No cambia la base original, las carpetas o los medios. La importación es opcional.

La referencia sigue siendo el commit de22796c04919aaa057d77930c33c81313765569.
Se revisaron migraciones 0000, 0001, 0002 y 0017 para la proyección; también 0023,
0025, 0030 y 0032 para títulos, agencias, región y referencias múltiples. No se
promete aceptar todos los esquemas de otras revisiones del original.

## Preparar y revisar

1. Para vincular archivos, autorizar primero una carpeta en Peach Local y completar
   su escaneo. El importador consulta ese índice y no amplía permisos SAF.
2. Elegir la copia o JSON. Usar un **nombre único de origen**, conservando exactamente
   ese nombre al reimportar la misma biblioteca. Bibliotecas diferentes necesitan
   nombres diferentes: los IDs numéricos del original no son globales.
3. Para conservar solo el inventario, seleccionar **Solo conservar catálogo**. Esto
   guarda la instantánea sin crear fichas, relaciones o listas en la biblioteca activa.
4. Para importar organización, indicar la ruta base que corresponde exactamente a
   la carpeta elegida. Ejemplo: `R:\Media` corresponde a la raíz SAF autorizada;
   `R:\Media\Set\a.mp4` buscará `Set / a.mp4` dentro de ella.
5. **Vista previa** muestra archivos vinculables, ausentes, conflictos de ruta/tamaño,
   fichas y listas nuevas o conservadas. Buscar consulta también los campos de detalle,
   incluidos códigos; tocar una fila permite leer sus datos. Antes de generar la vista
   previa se pueden consultar todos los registros proyectados, incluyendo fuentes y
   confianza de alias/relaciones. Después de importar, **Catálogos guardados** los recupera.
6. **Importar lo revisado** solicita confirmar ese resultado concreto. No descarga
   contenido ni activa fuentes externas. Cambiar una opción invalida la vista previa;
   cambios relevantes en la biblioteca obligan a generarla otra vez al aplicar.

Una coincidencia exige raíz, ruta relativa completa y nombre exactos. Se traducen
separadores de Windows, sin plegar mayúsculas ni Unicode. No se usan códigos, títulos,
nombre de archivo aislado o tamaño como identidad. Cuando ambos tamaños son conocidos,
una diferencia bloquea el vínculo. Una coincidencia de ruta/tamaño no verifica bytes
ni prueba que dos archivos tengan el mismo contenido.

Se rechazan componentes `.`/`..`, controles y rutas ambiguas; no se escriben rutas del
origen en el almacenamiento compartido. Varias filas locales para una ruta o varios
assets para un documento se mantienen sin vínculo. La ausencia no crea una URI falsa
ni una tarjeta reproducible; el registro se conserva en la instantánea.

## Datos incluidos y aplicación

La proyección permite estos campos, cuando estén presentes:

| Tabla | Campos |
|---|---|
| asset | id, location, path, name, medium, size, creator, studio, series, code, duration, width, height, catalog_title, original_title, release_date, region |
| asset_tag | asset_id, tag, source, confidence |
| entity | id, kind, canonical_name |
| entity_alias | entity_id, alias, source, confidence |
| entity_external_ref | entity_id, provider, external_kind, external_id |
| asset_entity | asset_id, entity_id, role, source, confidence |
| playlist | id, profile_id, name, source_kind |
| playlist_item | playlist_id, asset_id, position |

Solo se proyectan esas tablas/columnas. Se excluyen tablas de cuentas y proveedores,
campos de contraseña/tokens, metadata_json arbitrario, SQL, archivos y permisos SAF.
Los nombres, rutas y datos seleccionados siguen siendo datos personales del catálogo.

Al confirmar, se crean identidades compatibles de reparto, estudio, creador, serie y
etiqueta; sus alias exactos, referencias proveedor/ID sin URL y relaciones a documentos
vinculados. La revisión convierte las relaciones compatibles en vínculos explícitos.
Fuente/confianza y external_kind permanecen en la instantánea; la ficha local no es un
historial de afirmaciones ni ofrece la aprobación por afirmación del original.
Los tipos aún no modelados se conservan como registros consultables y no se convierten
a otro tipo. Desde 0.11 agency sí tiene ficha y afiliaciones; véase AGENCIAS.md. Relaciones de función incompatible se omiten.

Una colisión de nombre o alias con otra identidad del mismo tipo bloquea la ficha y
sus vínculos. Dos fichas entrantes que reclaman el mismo nombre también se omiten;
no se elige una por orden ni se fusionan automáticamente. Las fichas conservan UUID
derivado de origen/tabla/ID original. Los tipos distintos pueden compartir un nombre.

Las listas nuevas mantienen el orden relativo de sus miembros vinculados; se omiten
los ausentes. Se conservan profile_id y source_kind como procedencia en la instantánea,
sin crear perfiles Android. Una lista ya existente con ese ID no se reemplaza ni se
rellena: se preservan sus cambios locales. Esto limita importaciones de listas que
abarcan varias raíces; su conjunto completo sigue consultable en la instantánea.

La operación añade organización. No sustituye títulos/etiquetas personales, NFO,
favoritos, visto, tiempos AV, historial o posiciones de lectura. Reimportar conserva
alias y listas editados; relaciones explícitas presentes en el origen se pueden añadir
de nuevo. No es sincronización bidireccional ni ofrece deshacer la importación en bloque.
No hay importación de deseos/publicaciones/actividad/preferencias completas en esta fase.

## Persistencia y portabilidad

Room v8 añade únicamente catalog_snapshots. Guarda la última proyección por nombre de
origen, momento de importación y correspondencias originales a IDs de documentos.
Al aplicar otro mapeo se conservan correspondencias anteriores para assets aún presentes
en el origen. Reasignar un asset actualiza su correspondencia registrada; no retira
vínculos anteriores. No es historial de cambios ni resolución automática de conflictos.
Olvidar una carpeta elimina sus relaciones activas, conservando el inventario importado.

**Exportar JSON** guarda la proyección seleccionada, sin URI/permisos Android. Puede
abrirse otra vez en esta pantalla. No es una base ledger ni un formato que el Peach
original ya importe. La copia personal JSON v6 incluye instantáneas y correspondencias,
además de estado y organización anteriores; sigue leyendo v1–v5. Al restaurar no se
conceden permisos ni se importan medios; los IDs sin documento pueden seguir como
procedencia de la instantánea. Un registro inválido revierte toda la restauración.

Los datos cargados y opciones sobreviven a la recreación de la pantalla mediante
ViewModel. Antes de confirmar son un borrador en memoria; una terminación del proceso
puede descartarlo. El catálogo importado vive en Room. La copia temporal de origen se
elimina al acabar o fallar la lectura; una muerte del proceso puede dejar caché privada
que el sistema puede limpiar. No hay caché de credenciales ni acceso a la base original.

## Límites y validación

- Entrada SQLite/copias temporales: 128 MiB. Se exigen cabecera SQLite, tablas ordinarias,
  apertura de solo lectura e integridad quick_check. No se ejecuta SQL suministrado.
- La copia debe ser autónoma, con cabecera en modo DELETE. Se rechaza una base en modo
  WAL, incluso si puede haber sido checkpointed: seleccionar solo ledger.db no demuestra
  que incluya los cambios de su WAL. Un JSON de intercambio es la otra vía admitida.
- JSON/proyección: 4 MiB; 50.000 assets, 5.000 identidades, 1.000 listas; 50.000 filas
  por otra tabla, 150.000 totales; campos de texto hasta 4.096 caracteres, nombres/alias
  de identidad hasta 300. Se validan tipos enteros, relaciones y duplicados exactos.
- Hasta 20 orígenes. La copia personal completa conserva su máximo de 8 MiB: muchos
  catálogos pueden excederlo; se informa el error, sin declarar guardada una copia parcial.
- Sin dependencias de ejecución nuevas, permiso INTERNET ni motor Python/servidor.

Las pruebas locales usan SQLite temporal con migraciones SQL auténticas de la revisión
fija, datos sintéticos y archivos verificables. No se recibió una base personal del
usuario. Se compila además una prueba de integración SQLite para Android; su ejecución
en un Android completo sigue pendiente. Resultados finales en PRUEBAS.md.

## Consulta integrada a partir de 0.10.0

Los campos vinculados también se muestran y buscan en la biblioteca principal, con
procedencia y prioridades de METADATOS_CATALOGO.md. La vista previa informa que un título
único del catálogo puede completar un título de archivo sin NFO. El escáner, los NFO
y las ediciones originales conservan sus columnas. La comparación de rutas descuenta
la base documental conocida del escaneo; no la confunde con una subcarpeta homónima.
Room v9 añade el índice reconstruible; las instantáneas y copias v6 se mantienen.

## Afiliaciones en 0.11

La tabla opcional entity_membership conserva IDs de miembro/agencia, fuente, confianza
y comprobación. La vista previa conserva una afiliación existente y muestra conflictos
con agencias distintas; solo añade nuevas tras revisión. Los JSON v1 anteriores sin
esta tabla siguen leyéndose. Las copias personales v7 incluyen afiliaciones; se leen
v1–v6. Las instantáneas anteriores que no proyectaban esa tabla no permiten inventar
el roster: para incorporarlo se necesita una copia que contenga esos datos.

## Publicaciones y deseos 0.12.0

Tablas opcionales nuevas: follow_source (id, entity_id, provider, ref, label, url,
semantics), follow_item (id, source_id, external_id, title, url, published_at,
published_precision, release_key, variant_kind, variant_label, status, asset_id,
first_seen_at) y want_item (id, code, code_key, follow_item_id, origin, title, link,
release_date, state, search_count, last_search_at, last_search_outcome, last_search_note,
acquired_asset_id, acquired_at, acquired_source, acquired_batch, created_at, updated_at).

La instantánea conserva estos campos; el modelo nativo aplica el subconjunto descrito
en PUBLICACIONES_Y_SEGUIMIENTO.md. code_key/link/acquired_source quedan en la proyección,
no se convierten en reglas automáticas ni URL reproducible. Las fuentes no activan una
suscripción. media_url, thumb_url, metadata_json, etag y credenciales están excluidos.

El modo Solo catálogo no crea publicaciones ni deseos nativos. Con mapeo a raíz
escaneada, las filas compatibles nuevas se incorporan aun si su archivo no coincide;
se distinguen el estado adquirido y la disponibilidad del documento. Reimportar conserva
filas nativas existentes; conflictos de código no se fusionan. Las filas incompatibles
quedan consultables en la instantánea. UUID por origen/ID; límite por proyección 5.000
fuentes, 10.000 publicaciones y 5.000 deseos, además de 4 MiB y límites globales.

Los JSON anteriores sin las tablas opcionales siguen admitidos. Para traer publicaciones
que faltan en una instantánea vieja hay que volver a abrir el origen con esas tablas.
Las pruebas usan definiciones SQL originales 0018/0042 sin cambios y comprueban hashes
de la base antes/después de leerla; no hay un ledger personal aportado por el usuario.
