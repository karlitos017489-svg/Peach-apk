# Peach Local 0.48.0 · Rediseño para probar

Base: 0.47.0 / 5b3aa88, aceptada por el usuario. Versión 48, minSdk26/target36, firma original y APKv2/zipalign16KiB. APK: 12,133,031 bytes, SHA256 `405680ae08294b9868658317caa183eebe37943abfe70b9c165c5fcbdd2e9e92`.

La navegación principal y las tarjetas se renovaron con la referencia visual del usuario: fondo oscuro, portadas, títulos con espacio, iconos y barra inferior. Fuentes integra búsqueda, tarjetas y publicación; Ajustes agrupa las herramientas anteriores y las encuentra por nombre. Reproductor con control central redondo, iconos, carátula de audio y volumen compacto. Descargas pliega sus opciones secundarias. Guía: GUIA_REDISENO_048.md; alcance: REDISENO_048.md.

## Validación ejecutada

- 1170 JVM/Robolectric, 163 clases, 0 fallos/errores/omitidas; las 1152 anteriores conservadas y 18 nuevas. Se actualizan solo dos destinos esperados de navegación en Appearance460Test, conservando sus comprobaciones. Nuevas pruebas de búsqueda, lectura en la misma pantalla, vuelta/rotación, error sin pérdida de caché, fichas manuales, ajustes, aislamiento entre fuentes, guardado de una sola ficha, datos personales, miniaturas acotadas y rechazo de destinos ajenos.
- Lint: 0 errores, 185 avisos; sin nuevas supresiones. Compilación principal y de instrumentación completadas.
- Android: 76 casos completos, 75 aprobados, 1 omitido, 0 fallos/errores. Los 73 casos anteriores siguen presentes. La omisión es la búsqueda/contraseña PDF de API35+, fuera del API28 de este emulador.
- Tres casos nuevos también se repitieron con comprobaciones visuales reforzadas: 3/3 aprobados. Tarjeta pulsada mediante UiAutomator, publicación dentro de Fuentes, rotación, iconos/navegación y reproductor Media3 real con silencio/restauración y cierre del volumen antes de Stop. Capturas de fuentes, publicación, biblioteca, ajustes, descargas y volumen.
- Suite completa Android con test APK `538e4e8c2ad1c68499b7d39af6464cddcdc7351f6b4a4f8884ce6b59a3f7da32`; repetición visual final con test APK `11d1762518a5bf5fe220ad6617ac4d429b451bb6602a38d942f29a7daccf1c5d`. El APK principal fue el mismo en ambas, y coincide con la entrega por SHA256.
- Actualización real 0.47→0.48 en perfil desechable del emulador: DB/WAL/SHM y preferencias de apariencia idénticas antes/después por SHA256, con 1105 medios propios y favorito/progreso verificados previamente. No se instaló en la tablet del usuario.
- 45 archivos previos de base/DAO/copia/intercambio/transporte/credenciales/cola/esquemas/assets/nativos conservados byte a byte. Mismas dependencias y permisos; dos actividades internas no exportadas añadidas.

## Límites y registro de incidencias

Emulador oficial 37.2.13, Android9/API28 x86_64, 640×960, CPU TCG sin KVM y Swiftshader. No certifica Samsung/ARM64/Android16, Drive/cuentas privadas, medios upstream, batería o audio físico.

Se conserva la evidencia intermedia. La primera compilación del diseño detectó IDs de recursos y un modificador final en el ViewModel; corregidos. Las pruebas nuevas corrigieron dos errores de compilación del fixture (var compuesto y lambda con excepción). La revisión visual detectó tinte excesivo en el buscador y texto estrecho del filtro; corregidos. Un lint RestrictedApi al limpiar el tinte de AppCompat se resolvió con la API pública, sin supresión. El entorno se reinició tras una interrupción; se recuperó el checkpoint y se repitieron pruebas/compilación.

Las primeras capturas Android estaban tapadas por «System UI isn't responding» del emulador. No se dieron por válidas visualmente: se añadió una comprobación que pulsa Wait solo ante ese aviso del sistema, exige que desaparezca y rechaza capturas tapadas. Se repitieron los tres casos con pulsación real de tarjeta y captura tras estabilizar el dibujo. La suite de 76 casos ya había pasado; la repetición visual reforzó esos tres casos sin cambiar el APK principal.

Se mantienen los límites originales documentados de fuentes, cuentas, formatos y nube. Las tarjetas muestran miniaturas reales admitidas cuando las hay; no desbloquean archivos ni garantizan una portada para cada publicación. Los datos y fondos deben confirmarse en la SM-X230. 0.48 queda entregada para prueba, no aceptada aún.
