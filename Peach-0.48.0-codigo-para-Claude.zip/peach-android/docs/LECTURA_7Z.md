# Lectura 7z — Peach Local 0.16.0

Abrir un .7z catalogado usa el lector nativo con índice buscable. Seleccionar imagen,
PDF o texto compatible abre una vista local; las imágenes se ordenan naturalmente.
Se conserva entrada/página/desplazamiento, favorito y leído del contenedor. No se
crea una fila por entrada. ZIP, TAR y GZIP conservan sus lectores anteriores.

## Subconjunto y límites

Origen SAF hasta512 MiB, copia privada de solo lectura. Hasta10.000 entradas y512 MiB
acumulados de tamaños descomprimidos declarados. Entrada seleccionada hasta64 MiB.
Cabecera cruda hasta4 MiB; si está comprimida se acepta una carpeta/un flujo/un codec
COPY, LZMA o LZMA2 con salida hasta4 MiB. Se rechazan otros esquemas de cabecera,
SFX, datos añadidos, partes/volúmenes, cabeceras cifradas o recuperación de dañados.
El formato general7z admite más combinaciones que este subconjunto conservador.

Se usa un límite de64 MiB para la estimación del índice y decodificadores LZMA/LZMA2.
No es una cuota global de RAM: la app, listas, imágenes, PDF y otras estructuras
consumen memoria adicional; otros codecs pueden no respetar ese parámetro.
El motor no incorpora Zstandard u otros codecs nativos opcionales. La presencia de
clases en una dependencia no garantiza lectura de cada archivo7z del mundo.

Los archivos sólidos pueden requerir decodificar entradas previas aunque solo se
materialice la seleccionada. Cada selección abre un decodificador nuevo, con coste
de relectura. El total declarado se limita para acotar ese trabajo. El canal comprueba
interrupción, plazo90s y bytes leídos; no se promete interrumpir instantáneamente
cada operación de CPU o código interno. Las copias propias también comprueban límites.

Nombres absolutos, rutas con . o .., controles, entradas sin nombre o duplicadas se
rechazan. Enlaces Unix, reparse de Windows, anti-items y entradas especiales no se
siguen ni abren; solo se indexan. Los nombres internos nunca eligen destinos.
No hay reproducción AV interna, anidados o extracción general. No se incorpora
contraseña: una entrada cifrada puede figurar en el índice, pero su lectura se rechaza.
Las entradas vacías se abren como texto vacío cuando su extensión es compatible.

Se comprueban CRC de cabecera inicial/índice; los CRC de datos declarados se verifican
al leer por Commons. Si un archivo omite CRC, no se afirma integridad de contenido.
Un error no reemplaza la vista temporal válida ni publica entry-part; los datos se
escriben solo en nombres fijos dentro de la sesión. Al cerrar se limpia la copia,
conservando sesiones activas de otras lecturas. Nunca se modifican los originales.

## Dependencias y estado

Se añade org.tukaani:xz:1.12, Java8+ y licencia0BSD, para los decodificadores Java.
Se conserva Commons Compress1.28.0. XZ Utils no es XZ for Java: no se empaquetan
7zz, ejecutables, JNI o bibliotecas .so. Licencia exacta de la distribución oficial
en licenses/xz-1.12-COPYING.txt y assets/licenses/. Su JAR multiversión mantiene base
Java8; la compatibilidad del paquete Android se verifica por compilación y pruebas
instrumentadas aún no ejecutadas. No se declara prueba física de API26/API36.

Room sigue en v12, copia personal en v10; mismas identidades y posiciones por entrada.
La copia incluye posiciones, no los archivos comprimidos o permisos SAF. El límite
existente de copia personal permanece en8 MiB. RAR/CBR sigue pendiente.
PRUEBAS.md distingue unidades, instrumentación compilada y validación comunicada.
