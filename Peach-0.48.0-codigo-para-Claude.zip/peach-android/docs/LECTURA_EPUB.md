# EPUB local en Peach Local 0.17.0

El lector abre un subconjunto de EPUB 2.x/3.x como **texto nativo sin maquetación**.
Funciona offline sobre archivos de carpetas SAF autorizadas, sin WebView, computadora,
Termux, proceso Python o servidor Peach. No incorpora libros de terceros.

## Uso

1. Autorice la carpeta del libro y actualice el catálogo. EPUB conserva la familia
   **Otros archivos**; aparece también en **Todos**.
2. Toque el libro. Se abre el primer capítulo XHTML principal en el orden del spine
   del paquete, aunque sus nombres o el orden ZIP sean diferentes.
3. Use Anterior/Siguiente o **Capítulo** para navegar, y Ampliar/Reducir para cambiar
   la letra. El texto es seleccionable; se recuerdan entrada, capítulo y desplazamiento.
4. **Contenido** abre un índice buscable por ruta de capítulos e imágenes declaradas.
   Las imágenes locales compatibles se abren por separado con zoom hasta 2048 px.
   Dentro del texto aparece un marcador con el alt de la imagen cuando existe.

El índice usa rutas del manifiesto, no títulos NCX/nav. Las imágenes forman una
secuencia distinta de los capítulos; se cambia entre ambas desde Contenido.
Favorito, leído y contador pertenecen al libro completo. Llegar al final no lo marca
leído automáticamente. Room sigue en v12 y la copia JSON en v10; la copia conserva
posición y organización, no libros ni permisos SAF. No hay migración nueva.

## Arquitectura y contenido visible

ZipBook valida el contenedor y CRC/tamaño de los recursos leídos. Se requieren
mimetype application/epub+zip, META-INF/container.xml y el primer paquete OPF con
namespace/version reconocidos. El manifiesto identifica recursos; el spine elige
los capítulos principales. Se excluye linear="no". Un capítulo principal ausente,
externo, SVG o sin MIME XHTML impide abrir el libro en esta entrega. No se resuelven
fallbacks del manifiesto. No es un validador de conformidad EPUB.

Los metadatos se analizan con XML de Android, sin DTD, entidades declaradas o
resolución externa. Se aceptan UTF-8 con BOM opcional y UTF-16 LE/BE con BOM;
se rechazan secuencias inválidas. Referencias locales pueden contener nombres
codificados, fragmentos y .. que permanezcan dentro del contenedor. No se admiten
rutas absolutas, consultas, esquemas, autoridades, barras inversas o xml:base.

jsoup 1.23.2, ya usado por Patreon, analiza en memoria el XHTML. No se invoca su
cliente de red. Se conserva el texto y separaciones de bloques sin cortar palabras
entre etiquetas inline. Se retiran cabecera, scripts, estilos, nodos hidden/aria-hidden,
iframes, objetos, SVG/MathML y audio/video. Los enlaces solo aportan su texto.
No se descarga ningún recurso del libro ni se ejecuta HTML o JavaScript.

## Límites y compatibilidad pendiente

| Recurso | Límite o comportamiento |
|---|---|
| Origen | 512 MiB, copia temporal privada desde SAF |
| ZIP | 10.000 entradas y directorio central de 16 MiB; sin ZIP64, cifrado o volúmenes |
| mimetype / cada XML de metadatos | 100 bytes / 1 MiB |
| Manifiesto / spine | 10.000 IDs / 1.000 referencias, incluidas las no lineales |
| Capítulo XHTML elegido | 2 MiB descomprimidos; un capítulo mayor se rechaza |
| Recorrido del cuerpo | 50.000 nodos visitados; análisis DOM anterior acotado por bytes, sin cuota global de RAM |
| Texto visible | Hasta 200.000 unidades UTF-16; vista parcial avisada sin cortar un par sustituto al final |
| Imagen elegida | 64 MiB de entrada y vista hasta 2048 px |
| Caché | Nombres fijos privados, reserva de 64 MiB, sin extracción de carpetas ni escritura de originales |

No hay CSS, fuentes del libro, paginación fiel, tablas con maquetación, imágenes
inline, escritura vertical, ruby completo, navegación por enlaces/anclas, búsqueda
dentro del texto, NCX/nav personalizado, SVG, MathML, audio/video o scripts.
Se conservan saltos básicos, no todos los espacios de maquetación del original.
EPUB anidado dentro de ZIP/TAR/7z permanece sin lector.

**Cualquier META-INF/encryption.xml se rechaza**, incluso si solo describe fuentes
ofuscadas de un libro sin DRM. No se eluden contraseñas o DRM. Esta elección conservadora
reduce compatibilidad y queda pendiente de ampliar con pruebas específicas.

Una selección fallida conserva el último texto/imagen visible y su posición válida;
se puede volver a elegir un capítulo correcto. La sesión libera ZIP y temporales al
cerrarse. Los límites de entrada no garantizan un consumo global fijo de memoria.

## Dependencias, evidencia y referencias

No se añade una dependencia de ejecución: se reutilizan ZipFile/CRC32, XML Android,
jsoup MIT y el lector/Room existentes. Los EPUB de prueba contienen texto propio y
PNG sintético, con fechas ZIP fijas y hashes en epub170/provenance.json.
El generador está en scripts/generate-epub-fixtures.py. No son un corpus de
certificación EPUB ni demuestran compatibilidad con todos los libros reales.

PRUEBAS.md distingue unidades ejecutadas, APK instrumentado compilado y pruebas
físicas pendientes. Referencias de arquitectura, consultadas el 25 de octubre de 2026:

- https://www.w3.org/TR/epub-33/ (OCF, manifest y spine).
- https://jsoup.org/apidocs/org/jsoup/Jsoup.html (parse(String), análisis local).
