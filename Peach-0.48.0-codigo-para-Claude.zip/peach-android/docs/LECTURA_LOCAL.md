# Lectura local en Peach Local 0.8.0

Desde 0.17 se añade EPUB de texto nativo con imágenes separadas: ver LECTURA_EPUB.md.
Desde 0.16 se añade 7z: ver LECTURA_7Z.md.
Desde 0.15 se añaden TAR, TAR.GZ/TGZ y GZIP; ver LECTURA_TAR_GZIP.md.
Se abren dentro del APK los PDF, ZIP/CBZ y textos TXT, MD, CSV, JSON, XML y LOG.
Desde el mosaico se toca el archivo o se usa **Detalles → Abrir lectura**.
No se abre un navegador ni otra aplicación y no hay servidor o descarga de contenido.

## PDF

El lector usa PdfRenderer del sistema Android sobre una copia temporal privada y
un descriptor seekable. La apertura y el renderizado se ejecutan en un trabajador,
con una sola página abierta a la vez. Se puede avanzar, retroceder, ir a una página,
ampliar/arrastrar y ajustar la vista. La última página se conserva al reabrir.

La vista es una imagen con lado máximo de 2048 px; el zoom amplía esa imagen.
No incluye búsqueda/selección de texto PDF, anotaciones, edición, formularios,
enlaces interactivos o impresión. Los PDF protegidos por contraseña no están
admitidos. El motor es el de Android, ejecutado en el proceso de la app; no se
incluye un motor propio ni un proceso aislado adicional. Su memoria y compatibilidad
dependen también del documento y de la versión del sistema.

Los recorridos del controlador PDF se prueban con un backend de prueba explícito.
Las dos pruebas instrumentadas del renderizador Android real se compilan y quedan
pendientes de ejecución. No se presenta una imagen producida por el backend de
prueba como prueba de renderizado PDF real en la tablet.

## ZIP y CBZ

El lector muestra un índice de todos los archivos del ZIP. Los nombres se ordenan
naturalmente: 1, 2, 10. Al abrir un álbum se elige su primera imagen; si no hay
imágenes, se intenta el primer PDF/texto compatible. **Contenido** permite buscar
y seleccionar otra entrada. Las entradas sin lector integrado permanecen visibles.

Anterior/siguiente e Ir a página recorren las imágenes del álbum o las páginas del
PDF seleccionado. Para cambiar de un texto/PDF a otra entrada se utiliza Contenido.
Se leen imágenes compatibles con ImageFiles, PDF y los formatos de texto indicados.
GIF/WebP animados se muestran como imagen fija, como en la galería independiente;
HEIF/HEIC dependen del sistema. No se reproducen audio/video dentro de ZIP ni se
abren archivos comprimidos anidados. No se ejecuta el contenido de una entrada.

Se usa ZipFile de Java. La app copia únicamente la entrada seleccionada a un nombre
fijo dentro de su caché; nunca usa una ruta del ZIP como ruta de salida. Se rechazan
rutas absolutas, componentes . y .., caracteres de control y nombres duplicados.
El tamaño descomprimido se limita también durante la lectura y se verifica tamaño/CRC
de la entrada completa seleccionada. No se extrae todo el ZIP ni se escriben sus carpetas.

Se admiten ZIP/CBZ estándar compatibles con el lector de Java. ZIP64, volúmenes
divididos y archivos cifrados no se admiten en esta etapa. Nombres con codificaciones
ZIP heredadas que no sean compatibles pueden impedir la apertura. RAR/CBR permanece catalogados y organizables, pero todavía sin lectura interna.

El archivo comprimido conserva una única fila e identidad en el catálogo. No se
crea una fila por imagen/entrada. Favoritos, leído, listas, grupos y relaciones se
aplican al archivo contenedor; no a cada entrada individual.

## Texto

Se muestra texto seleccionable, sin interpretar HTML o ejecutar scripts. Se admite
UTF-8, con BOM opcional, y UTF-16 LE/BE con BOM. Las secuencias inválidas se rechazan;
no se adivina una codificación ANSI. Ampliar/Reducir cambia el tamaño de letra entre
12 y 32 sp; Ajustar recupera 16 sp. La vista avisa si es parcial.

Se leen hasta 1 MiB + un byte de detección y se muestran hasta 200.000 caracteres.
Un texto mayor se muestra como vista parcial. El desplazamiento guardado es una
posición de pantalla: puede ajustarse al cambiar el tamaño de letra, orientación
o contenido del archivo. La app no modifica ni guarda una versión editada del texto.

## Estado personal

El lector comparte favorito y visto/leído con la biblioteca. **Marcar leído** es una
acción manual; llegar a una última página no marca automáticamente una obra completa.
La apertura se cuenta una vez después de la primera vista satisfactoria. Recrear la
pantalla conserva el estado y no añade otra apertura.

La posición usa una tabla reader_progress independiente del tiempo de audio/video:
documento, nombre de entrada ZIP, página, desplazamiento de texto y fecha. En un ZIP
se recuerda la entrada por nombre, no solo por número de orden. Si ya no existe, se
elige otra compatible. No se restaura una imagen de un archivo que ya no esté en él.
El filtro **Con progreso** incluye documentos que tengan posición de lectura guardada.

Una vista fallida conserva el último contenido válido y no reemplaza su posición.
Los controles siguen correspondiendo a esa vista. Una raíz temporalmente
inaccesible conserva su estado. Quitar una raíz de Peach borra sus registros y las
posiciones asociadas; los archivos de origen se conservan.

## Caché y límites

Los PDF/ZIP se copian desde la URI SAF a una sesión privada para disponer de acceso
aleatorio; no se copia a Descargas ni a la carpeta original. Se admite hasta 512 MiB
por PDF/ZIP y hasta 64 MiB descomprimidos por entrada seleccionada. El índice ZIP
admite hasta 10.000 entradas y 16 MiB de directorio central. Una imagen/PDF se presenta
con lado máximo 2048 px; no se promete que ello limite toda la memoria del motor nativo.

Se comprueba espacio libre durante la copia, reservando 64 MiB para el origen temporal
y, desde 0.17, 64 MiB también para una entrada (se reutiliza ArchiveFiles). Se cierra la sesión al salir y se elimina su caché. Las
sesiones huérfanas se limpian al abrir otro documento; un bloqueo de archivo protege
las sesiones activas. Un cierre abrupto del proceso puede dejar temporalmente una
copia privada hasta la siguiente limpieza o hasta que Android libere la caché.

La navegación y la decodificación se serializan en un trabajador; una respuesta antigua
no sustituye una petición posterior. Al cerrar se solicita cancelación, se cierra el
flujo activo y se encola la liberación de PDF/ZIP/caché. Las copias y comprobaciones
periódicas tienen límites finitos; la respuesta de un proveedor SAF externo también
depende de ese proveedor. El núcleo sigue funcionando con archivos locales sin red.

## Actualización y copias

Room v7 añade únicamente reader_progress con clave externa al documento; se conservan
las migraciones desde v1 a v6. Las copias JSON v5 incluyen esas posiciones y continúan
leyendo v1/v2/v3/v4 sin cambiar las posiciones existentes. Se mantienen los UUID,
ediciones, listas, grupos, identidades, referencias y deseos de la versión anterior.

Una posición inválida o duplicada en una copia v5 revierte toda su restauración.
Los documentos no indexados o que ya no sean legibles por este módulo se omiten.
Se admiten hasta 50.000 posiciones, dentro del límite global de copia de 8 MiB.
La copia no contiene PDFs, textos, medios, contenido de ZIP ni permisos SAF.

Las pruebas ejecutadas y las pendientes se documentan por separado en PRUEBAS.md.
Esta ampliación no declara lectura universal de archivos ni paridad completa con
Peach original; COMPATIBILIDAD_ORIGINAL.md conserva las diferencias pendientes.
