# RAR/CBR local — 0.38.0

Nota de versión: este documento describe el bloque histórico. Para nombres Unicode
heredados RAR4 admitidos desde0.40, consulta LECTURA_RAR_UNICODE.md.

Este bloque añade lectura nativa Android de un **subconjunto**, no un descompresor RAR
completo. No usa red, servidor, Termux, otra aplicación ni cuenta F95. CBR es una
extensión de archivo RAR de cómic; cambiar una extensión no cambia sus métodos internos.

## Qué funciona

Desde la biblioteca, abrir un .rar o .cbr con firma RAR4 o RAR5 en el inicio exacto.
Índice natural (2 antes de 10), búsqueda y lectura de imágenes, texto y PDF contenidos
en entradas regulares **almacenadas sin compresión**, con tamaño y CRC32 verificables.
Las imágenes usan el zoom y render de hasta 2048 px anterior. El PDF conserva el lector
Android; texto mantiene sus límites anteriores. Navegación, favorito/leído, historial
y posición por entrada funcionan igual que los otros lectores. No modifica el archivo.

RAR5 permite nombres UTF-8 portables y versiones0/1 del método almacenar (contenedor
RAR5 y metadatos RAR7 compatibles); esto no prueba descompresión RAR7. RAR4 admite nombres
ASCII y UTF-8 cuando el indicador Unicode contiene el nombre directamente. No interpreta
su codificación Unicode comprimida heredada o nombres ANSI ambiguos: los rechaza antes
de publicar el índice. No se implementa un algoritmo de compresión o creador RAR.

## Límites expresos

- Fuente local hasta 512 MiB; total expandido **declarado** hasta 512 MiB, sin expandir el
  archivo completo. Hasta10.000 cabeceras,8MiB de cabeceras acumuladas; RAR5 hasta2MiB
  por cabecera. Vista seleccionada hasta 64 MiB y reserva de64MiB en disco.
- CRC de cabeceras al indexar; CRC32 del contenido seleccionado antes de publicar la
  vista. No verifica datos de entradas no abiertas. No calcula todos los hashes de un RAR.
- Entradas comprimidas, cifradas, enlaces/redirecciones, archivos especiales, sin CRC
  o metadatos extra no reconocidos quedan **solo en el índice**, con explicación.
- Archivos sólidos, divididos/multivolumen, cabeceras cifradas, SFX, cabeceras desconocidas,
  rutas inseguras/duplicadas, daños o datos después del fin se rechazan. Algunas variantes
  válidas del formato quedan fuera de este subconjunto conservador.
- No extrae carpetas, sigue links, abre vídeos internos, ejecuta scripts, lee archivos
  comprimidos anidados o pide contraseñas. Los nombres internos nunca son rutas de salida.
- Copia fuente a caché privada igual que los otros lectores. Lee solo cabeceras y la
  entrada seleccionada; revalida el índice con descriptor nuevo por operación. Usa
  nombres fijos entry-part/entry, elimina parciales y conserva vista previa ante error.
  Cancelación/interrupción; plazo de 90 s para indexar y otro de 90 s para copiar la
  selección, no una garantía de 90 s para toda la pantalla. Sin hilos de descompresión.

No todos los CBR existentes funcionarán. Si informa «comprimida», no es un fallo de red,
ni falta una cookie: el descompresor aún no está integrado. No necesitas convertir tus
archivos para instalar o seguir usando las funciones existentes de Peach.

## Dependencias y decisión de arquitectura

Se auditó Junrar8.1.2: su README anuncia RAR hasta7, contraseñas y multivolumen. Por tanto
**no es correcto describirlo como RAR4 solamente**. Su licencia UnRAR añade una restricción
sobre recrear el compresor RAR. Se decidió no incorporar ese código a esta adaptación
AGPL sin resolver expresamente su compatibilidad. No se afirma que usarlo esté prohibido
para todos los proyectos; se documenta la decisión de esta distribución.

libarchive3.8.2 tiene licencia BSD y lectores RAR/RAR5 con límites. Es la alternativa
preferida para evaluar la descompresión posterior. Añadirlo aquí exige NDK/JNI/ABIs,
licencias, límites de diccionario y memoria antes de asignación, cancelación incluso
durante decodificación, CRC, aislamiento de fallos y pruebas Android. No se ha integrado
ni se promete compatibilidad total por existir esa biblioteca. El toolchain actual no
incluye NDK; el APK0.38 no añade código nativo ni bibliotecas runtime.3.8.2 es la versión consultada
para esta auditoría de formato/licencia, no una elección definitiva para los binarios:
antes de integrar se debe fijar una versión con las correcciones de seguridad vigentes.

RarBook es un parser propio de cabeceras y copia acotada de entradas almacenadas. Se
consultó la especificación pública RAR5 de RARLAB y la estructura RAR4 de libarchive3.8.2;
no se incorporó código UnRAR/Junrar ni su descompresor. La URL histórica technote.txt no
se recuperó: no se presenta como fuente leída. URLs, tamaños y SHA256 de recursos
realmente recuperados constan en evidence/0.38.0/audit-resources.json.

Referencias primarias:

- https://www.rarlab.com/technote.htm
- https://github.com/junrar/junrar/tree/v8.1.2 (README.md y LICENSE)
- https://github.com/libarchive/libarchive/blob/v3.8.2/COPYING
- https://github.com/libarchive/libarchive/blob/v3.8.2/libarchive/archive_read_support_format_rar.c

## Pruebas y continuidad

Los fixtures propios RAR4/RAR5 contienen texto e imágenes sintéticas previas del proyecto,
sin archivos del usuario. scripts/fixtures/rar038.py permite reproducirlos; un lector
independiente **libarchive3.7.4 del host**, solo herramienta de test, recuperó todos sus
contenidos y los comparó byte a byte con los originales. Primera ejecución detectó que
el fixture RAR5 vacío omitía el indicador de datos; se corrigió el fixture y se repitió
con éxito. Esto valida el corpus básico, no el motor nativo libarchive Android futuro.

Las pruebas JVM/Robolectric cubren parser, daños, índices, límites, CRC, cache, imágenes
API26/28, PDF con backend explícito de test, UI/rotación, copia18 e historial. La suite
Android incluye decodificación de PNG y Room aislado; solo se considera ejecutada si hay
registro de dispositivo. PRUEBAS.md conserva el resultado real y sus límites.

Room13, copia18 (lee1–18), permisos, componentes, dependencias, assets de producción,
servicios, nueve fuentes, streaming y descargas anteriores se conservan. Kemono/Coomer/
SimpCity siguen excluidos.0.37 aceptada por el usuario;0.38 requiere aceptación propia.
El proyecto permanece abierto. Próximo bloque previsto: descompresión RAR con libarchive,
si supera auditoría de memoria/licencia/integración, o una etapa técnica previa claramente
documentada. Login nativo F95 sigue pendiente y no se sustituye con pedir cookies al chat.
