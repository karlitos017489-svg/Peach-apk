# RAR/CBR comprimido — Peach Local 0.39.0

Nota de versión: este documento describe el bloque histórico. Para nombres Unicode
heredados RAR4 admitidos desde0.40, consulta LECTURA_RAR_UNICODE.md.

0.38 aceptada por el usuario. Este bloque añade el descompresor libarchive 3.8.10 al
APK, sin PC, Termux, servidor externo, navegador integrado o descarga de un motor al
abrir un archivo. No equivale a compatibilidad universal con todos los RAR.

## Uso

Abre un .rar o .cbr de la biblioteca. El índice y la búsqueda anteriores siguen;
imágenes, texto y PDF compatibles usan los mismos lectores, zoom, navegación y posición.
Las entradas almacenadas mantienen el lector Java de0.38. Las comprimidas admitidas
se preparan una por una en un proceso Android aislado y se muestran después de comprobar
su tamaño y CRC32. El archivo original y sus nombres no se modifican.

Se admiten compresión RAR4 (métodos31–35, variantes reconocidas por el parser y motor)
y RAR5 versión de algoritmo0 (métodos1–5, diccionario hasta64MiB), sin cifrado, sólidos o
volúmenes. Las pruebas propias cubren niveles1/3/5 de ambos contenedores; no establecen
que toda combinación/filtro/archivo RAR existente sea compatible. RAR7 almacenado conserva
el soporte anterior; **RAR7 comprimido no se declara admitido**.

Continúan pendientes contraseñas/cabeceras cifradas, sólidos, multivolumen/SFX, Unicode
comprimido heredado o ANSI ambiguo RAR4, extras/variantes sin CRC verificable y casos
no soportados por libarchive. Algunas entradas quedan solo en índice con explicación;
los límites estructurales o del contenedor pueden rechazar el archivo completo.
Los adjuntos/links no admitidos no se transforman en archivos ficticios.

## Arquitectura y límites

RarBook valida primero las cabeceras Java: firmas iniciales RAR4/RAR5, CRC, nombres
seguros/únicos, estructuras acotadas,512MiB fuente/total expandido declarado,10.000
cabeceras,8MiB acumulados/2MiB cada RAR5. No se pide al código nativo interpretar una
ruta arbitraria o crear directorios del archivo. Índice revalidado antes de cada lectura.
Una selección hasta64MiB, reserva de64MiB en caché privada; no AV ni comprimidos anidados.

RarClient vincula un servicio **no exportado y android:isolatedProcess=true**, separado
con proceso:rar. Comunicación AIDL limitada a ID de solicitud, descriptores de origen
solo lectura/salida solo escritura, nombre acotado, tamaño y CRC. No se envían rutas,
URLs, sesión, base de datos, Cookie o clave de API. El UID aislado no tiene los permisos
de red del proceso principal ni acceso ordinario a sus datos privados. No hay permiso
nuevo, servicio de red, inicio automático, servicio persistente o servidor fuera de la
aplicación. El motor se carga únicamente en el servicio aislado; lectura almacenada no
necesita invocarlo. Se verifica el UID del llamante y se serializa una operación nativa.

El wrapper JNI solo habilita lectores RAR/RAR5 y filtro none. Limita fuente/lecturas/
selección, rechaza enlaces/archivos especiales/cifrado, verifica de nuevo tamaño/CRC y
escribe exclusivamente al descriptor proporcionado. No se usa extracción por nombres.
Los mensajes devueltos son códigos constantes, sin errores nativos crudos o contenido.

Los malloc/calloc/realloc/strdup/strndup del código enlazado se envuelven con una cuota
**160MiB acumulados simultáneos y64MiB por asignación**, con comprobaciones antes de
asignar, alineación y limpieza. No es un máximo de RAM de todo Android/JVM/libc: sus
estructuras adicionales consumen memoria fuera de esa cuota. RAR5 puede necesitar dos
buffers de diccionario; un archivo válido que exceda el presupuesto falla de forma
controlada. Android reduce además RLIMIT_FSIZE del proceso de motor a64MiB.

Comprobaciones de plazo nativo85s en callbacks y bucle de salida; watchdog del cliente
solicita terminar el proceso a90s. La vinculación puede consumir hasta10s adicionales.
Cancelación explícita envía el ID activo; el servicio detiene su propio proceso, no el
principal. Rotar/destruir la pantalla cancela la sesión anterior y la siguiente reabre
su posición guardada. No se afirma un límite absoluto ante cualquier bloqueo del sistema
operativo/JNI/Binder; la pantalla principal permanece en otro proceso. El lector previo
puede terminar una preparación mientras la actividad está pausada; no se añade un
trabajador permanente o reproducción/descarga en segundo plano.

El cliente comprueba otra vez el archivo con Java antes de renovar entry. Error, muerte
del proceso, cancelación, CRC/tamaño inválido o presupuesto excedido eliminan entry-part
y conservan la vista/posición válidas anteriores. Los descriptores se cierran, se desvincula
el servicio y se libera el turno; el archivo de origen no se sobrescribe.

## Dependencia, licencia y compilación

Fuente fijada **libarchive3.8.10**, estable publicada14-octubre-2026 según su sitio oficial.
Se revisaron sus lectores RAR y RAR5 y se usa esta versión corregida, no3.8.2 consultada
solo como referencia en0.38. Licencia BSD/per-file; BLAKE2 elige CC0. Avisos en assets y
fuente completa sin modificar en third_party/libarchive/libarchive-3.8.10.tar.gz.
No se incorpora código Junrar/UnRAR ni la herramienta RAR usada para crear pruebas.

SHA256 tarball: a1bffbe5152cfe869751179e7b16648c87c461cb8c46eee75062efbe164cc57c.
NDK r30/30.0.16248370, API26, arm64-v8a/armeabi-v7a/x86_64/x86, ELF PT_LOAD16KiB;
solo libc/libm/libdl. No nuevas dependencias Java/Maven ni modificación de sus versiones.
La alineación del APK se comprueba por separado; compilar/alinear no equivale a ejecutar
en dispositivo de16KiB. Binarios precompilados incluidos para construir el APK sin NDK.

Reconstrucción nativa (GNUmake/gcc para host; JDK17 y NDK para Android):

```sh
python3 scripts/native/build-rar.py --ndk /ruta/android-ndk-r30 --jdk /ruta/jdk17 --build-root /tmp/peach-rar-native
```

Para la suite local configura PEACH_RAR_HOST_LIBRARY=/tmp/peach-rar-native/host/libpeach_rar.so.
El host verifica el mismo wrapper/motor con JNI Linux; no ejecuta la ABI Android o Binder
real. El código de ayuda de test para abrir rutas solo se compila con PEACH_HOST_TEST en
Linux y se comprueba que sus símbolos NO existan en los cuatro binarios Android.
El instalador estándar del NDK preserva sus enlaces simbólicos; extracción ZIP manual
con Python debe restaurarlos. El NDK y los compresores de fixtures no se distribuyen.

## Evidencia

scripts/fixtures/rar039.py genera medios propios (PNG sintético anterior, BMP y texto
geológico propio) con RAR6.24 para RAR4 y RAR7.23/-ma5 para RAR5, niveles1/3/5, sin sólidos.
Hay una muestra mayor para forzar el límite de memoria, sin datos del usuario.
El motor real Linux recupera contenidos byte por byte; otras pruebas validan IPC simulado,
Binder/servicio con dobles controlados, cancelación/watchdog, CRC, índices, sesión/imagen.
Dos pruebas Android nuevas recorren el servicio real cuando se ejecuten en dispositivo.
PRUEBAS.md distingue ejecutadas, compiladas y las limitaciones de la verificación.

Fuentes primarias consultadas:
- https://www.libarchive.org/ (estable3.8.10 y licencia)
- https://www.libarchive.org/downloads/libarchive-3.8.10.tar.gz (fuente auditada)
- https://developer.android.com/ndk/downloads (NDKr30 y checksum oficial)
- https://developer.android.com/guide/practices/page-sizes
- https://developer.android.com/develop/background-work/services/bound-services
- https://www.rarlab.com/download.htm (RAR7.23; solo herramienta de fixtures)

Room13/copia18 y datos personales conservados. Nueve fuentes, exclusiones Kemono/Coomer/
SimpCity vigentes. Login F95 nativo y seis frentes de paridad siguen abiertos; no se pide
Cookie para probar este bloque.0.39 no está aceptada hasta la comprobación del usuario.
