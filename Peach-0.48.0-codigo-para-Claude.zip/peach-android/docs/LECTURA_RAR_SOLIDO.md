# RAR5 sólido — Peach Local 0.41.0

El usuario confirmó0.40. Este bloque abre un subconjunto de RAR5 sólidos desde el
lector local RAR/CBR existente, usando el mismo motor libarchive3.8.10 y servicio
Android aislado. No exige cuenta, red, PC o conversión del archivo.

Un archivo sólido comparte el diccionario entre varias entradas. Al pedir una imagen
o texto posterior, el motor empieza desde el inicio y reconstruye ese diccionario
procesando entradas anteriores. Sus bytes se descartan dentro del motor: no se guardan
en carpetas ni se publica una extracción completa. Por eso cada cambio de entrada
puede tardar más. No se guarda un diccionario nativo entre solicitudes.

## Subconjunto admitido

- Firma RAR5 y cabecera principal sólida; algoritmo0, métodos1–5, sin cifrado,
  volúmenes o SFX. Entradas regulares comprimidas de1byte a64MiB, con CRC32.
- Mismo diccionario declarado para todos los archivos, hasta16MiB. La primera entrada
  debe iniciar un diccionario independiente; las siguientes pueden depender de él.
- Hasta128MiB descomprimidos **declarados en todo el contenedor sólido**, origen hasta
  512MiB. Siguen10.000cabeceras/8MiB acumulados/2MiB por cabecera RAR5.
- Todo archivo regular, aunque no tenga visor por su extensión, debe cumplir esas
  reglas antes de iniciar el motor. Una entrada incompatible impide abrir ese sólido.
  Los nombres UTF-8, rutas seguras y duplicados se validan como antes.

RAR4 sólido sigue sin soporte: el lector RAR4 fijado lo rechaza expresamente. RAR5
sólido con archivos vacíos, entradas almacenar, diccionarios distintos o mayores,
dependencias adicionales o bloques de servicio, cifrado/volúmenes, RAR7 comprimido o extras no reconocidos
queda fuera. No se promete abrir todos los CBR ni todos los RAR5 sólidos válidos.

## Integridad y recursos

Se comprueban CRC de cabeceras al indexar y al revalidar. La condición de contenedor
sólido se incluye en la identidad del índice para detectar su cambio antes de abrir.
La entrada solicitada conserva CRC/tamaño nativos y otra comprobación Java antes de
publicar `entry`; errores o cancelación eliminan parcial y conservan original/vista.

**No se comprueba el CRC del contenido descartado de las entradas anteriores.** El
motor fijado omite esa comprobación durante el salto sólido. Por tanto, abrir una
entrada correcta no certifica que las anteriores o todo el archivo estén íntegros.
Una prueba propia altera solo el CRC de la primera entrada: otra entrada puede abrir
correctamente; seleccionar la entrada alterada debe fallar. No se oculta ese alcance.

El máximo128MiB es una admisión por tamaños declarados, no una medición de todo lo
procesado internamente en C. Se conservan además la cuota nativa160MiB/asignación64MiB,
plazo de callbacks85s y watchdog90s, vinculación10s y salida64MiB. No equivalen a un
máximo de RAM total ni a un plazo absoluto ante bloqueos de sistema/JNI/Binder.
No cambia el wrapper C, los cuatro binarios, el IPC o los controles del servicio.

## Evidencia

Tres muestras propias RAR5 sólidas creadas con RAR oficial6.24, niveles1/3/5, diccionario
4MiB, texto de geología y BMP rojo/azul. El lector oficial comprobó cada entrada y sus
bytes, incluidos los nombres Unicode. Tres mutaciones controladas permiten probar
CRC seleccionado, CRC descartado y contenido dañado. La herramienta externa no se
redistribuye. Generador: scripts/fixtures/rar041.py; hashes y tamaños en evidence/0.41.0.

Pruebas JNI Linux reales leen entradas en distinto orden, repiten solicitudes y
comprueban cuota/limpieza. ReaderSession con dobles prueba ruteo/render/cierre; las
pruebas Android de servicio real requieren dispositivo y se contabilizan por separado.
No se ejecutan cuentas, CDNs ni medios privados. PRUEBAS.md conserva los resultados.

Referencia primaria: fuente BSD ya fijada en third_party/libarchive,
`libarchive/archive_read_support_format_rar5.c`, funciones process_head_main,
process_head_file y rar5_read_data_skip. Lector RAR4: archive_read_support_format_rar.c.
https://github.com/libarchive/libarchive/blob/v3.8.10/libarchive/archive_read_support_format_rar5.c
