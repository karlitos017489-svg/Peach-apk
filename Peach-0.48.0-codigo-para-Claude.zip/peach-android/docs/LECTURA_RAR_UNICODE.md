# Nombres Unicode RAR4 — Peach Local 0.40.0

0.39 aceptada por el usuario. Este bloque amplía la lectura local RAR/CBR existente:
admite el campo de nombre Unicode heredado de RAR4, tanto en entradas almacenadas
como en las comprimidas compatibles con el motor de0.39. No cambia el archivo original.

Los nombres como `notas/niñez.txt`, `日本語/地層.txt` e imágenes con acentos ya pueden
identificarse sin convertir el archivo o sustituir sus nombres. También se comprueban
pares UTF-16 para caracteres fuera del plano básico, como emoji, con pruebas propias.
Los nombres RAR5 UTF-8 y RAR4 ASCII/UTF-8 directo conservan el comportamiento anterior.
No se adivina la página de códigos de nombres ANSI sin indicador Unicode.

## Contrato

Rar4Names interpreta las cuatro operaciones del nombre heredado: byte literal,
byte con parte alta compartida, literal UTF-16 y secuencia del prefijo con corrección
opcional. El nombre mostrado es la forma Unicode completa; un prefijo ANSI distinto
no se usa como sustituto para seleccionar una entrada.

Entrada hasta4096bytes, salida hasta4096bytes UTF-8. Truncados, referencias fuera del
prefijo, UTF-8 no válido y sustitutos UTF-16 aislados devuelven un error controlado.
No se normalizan letras o acentos: el nombre canónico conserva su escritura exacta.
Las barras se normalizan como antes; después se comprueban rutas, controles y nombres
duplicados. Los nombres internos nunca se convierten en rutas de salida.

Antes de abrir se revalida el índice. El descompresor aislado recibe el mismo nombre
UTF-8 y debe encontrarlo exactamente, con verificación de tamaño/CRC antes de publicar
la vista. Los almacenados siguen la copia Java anterior; no invocan el motor nativo.
Se mantienen las cuotas, cancelación, separación de procesos y limpieza de0.39.

No se amplía el soporte de datos comprimidos: sólidos, volúmenes, contraseñas,
RAR7 comprimido y variantes/extras sin contrato comprobado siguen pendientes.
Fuente512MiB, selección64MiB y los demás límites anteriores siguen vigentes.
No hay dependencias, permisos, componentes, cambios Room13 o copia18 nuevos.

## Referencia y muestras

La lógica se contrastó con el lector BSD de la fuente libarchive3.8.10 ya fijada
en `third_party/libarchive`, función de nombre RAR4 en
`libarchive/archive_read_support_format_rar.c` (FHD_UNICODE).
Referencia primaria del proyecto: https://github.com/libarchive/libarchive/blob/v3.8.10/libarchive/archive_read_support_format_rar.c
El código Java es un parser acotado; no incorpora UnRAR/Junrar ni un nuevo motor.

Cuatro muestras propias en `app/src/test/resources/rar040`: dos archivos creados con
RAR oficial6.24, almacenar/nivel3, y dos con cabeceras Unicode sintéticas y contenido
propio ya comprimido en0.39. Contienen texto de geología y una imagen BMP roja/azul.
El lector oficial comprobó los bytes de las cuatro muestras. Para emoji, su selector
usó comodín por una limitación del nombre mostrado en RAR6.24/Linux: eso no demuestra
fidelidad del nombre; la selección Unicode exacta se prueba con JNI/libarchive.
Herramienta de fixtures externa, no incluida en el APK ni en el proyecto.

`scripts/fixtures/rar040.py` permite reproducir las muestras con esa herramienta.
`docs/evidence/0.40.0/fixtures.json` conserva tamaños, hashes y alcance de comprobación.
PRUEBAS.md distingue los resultados ejecutados de los que requieren Android real.
