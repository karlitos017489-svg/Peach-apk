# TAR y GZIP — Peach Local 0.15.0

Al abrir un TAR, TAR.GZ/TGZ o GZIP catalogado, se utiliza el lector nativo existente.
El índice incluye los archivos; buscar filtra sus nombres, y tocar una imagen, PDF o
texto compatible lo abre. Las imágenes forman un álbum con orden natural (2 antes
de 10); se conserva entrada/página/desplazamiento al volver. Favorito y leído pertenecen
al documento contenedor. Las entradas no se convierten en medios separados.

## Formatos

- TAR: USTAR, nombres largos GNU y PAX acotado, con nombres Unicode y prefijos ./.
  Solo los archivos regulares se pueden abrir. Enlaces simbólicos/duros, FIFO u otros
  tipos se listan sin lector y nunca se siguen. No se crean directorios del paquete.
- TAR.GZ y TGZ: se comprueba/expande GZIP en una copia temporal privada antes de
  preparar el índice TAR. También se copia el origen desde SAF para acceso local.
- GZIP simple: un flujo sin índice de varios archivos. El nombre externo sin .gz
  decide el lector: notas.txt.gz, foto.png.gz o documento.pdf.gz. Un .gz sin sufijo
  reconocible puede listarse, pero no se adivina el formato a partir de la cabecera.
  Los miembros GZIP concatenados se leen como un solo flujo, según GZIPInputStream.
  El nombre interno de la cabecera GZIP no se usa como ruta o nombre de salida.

Se abren las mismas imágenes y textos que en ZIP; PDF usa PdfRenderer. Los textos
son planos, no se ejecutan HTML/scripts. No hay reproducción de audio/video dentro
del comprimido, anidados, extracción general, RAR/CBR o7z en esta entrega.
La clasificación TGZ como comprimido se añade al actualizar el escaneo.

## Límites e integridad

Origen de hasta 512 MiB. TAR expandido de hasta 512 MiB y GZIP simple/entrada elegida
de hasta 64 MiB. El texto visible sigue acotado a 1 MiB/200.000 caracteres y las imágenes
a 2048 px. Se reserva espacio libre antes de escribir; TAR.GZ necesita espacio para
origen, TAR expandido y entrada, además del margen. Los temporales son privados y
se retiran al cerrar o al recuperar sesiones abandonadas; otras sesiones activas
mantienen sus cachés.

TAR admite como máximo10.000 cabeceras físicas, incluidos directorios/metadatos;
metadatos de hasta 64 KiB cada uno y4 MiB en total, con hasta 8 extensiones consecutivas.
Se comprueba checksum de cabecera, límites/offsets, bloques finales completos y
relleno final de ceros. Se rechazan truncamientos, TAR concatenados, rutas inseguras,
nombres duplicados (incluidos alias con ./), sparse y overrides PAX de tamaño.
Estos límites conservadores pueden rechazar TAR válidos de otras herramientas.
TAR no tiene CRC de cada archivo: el checksum de cabecera no prueba la integridad
del contenido regular. Se verifica su tamaño al leerlo.

GZIPInputStream comprueba CRC/tamaño del flujo al terminar de expandir. Un error o
exceso de tamaño no publica la salida parcial. La extracción seleccionada escribe
solo entry-part y luego entry dentro de la sesión; el TAR usa source/unpacked
fijos. Los nombres internos nunca eligen el destino. Los bucles propios comprueban
interrupción y un plazo de 90 s; no se promete interrumpir instantáneamente cada
operación interna de la biblioteca o de un proveedor SAF.

## Dependencias y datos

Commons Compress 1.28.0 (Apache-2.0) analiza TAR; transitivas Commons IO 2.20.0,
Lang3 3.18.0 y Codec 1.19.0. Se auditó el grafo efectivo y se conservan licencias/avisos.
No se añaden XZ, Brotli, ASM o zstd-jni opcionales; la presencia de clases de otros
formatos en una dependencia no implica soporte de esos formatos en la app.
GZIP utiliza java.util.zip del sistema. ZIP conserva su backend previo.

Room continúa en v12, copia personal en v10. Se reutiliza reader_progress, sin
migración de tablas ni cambio de identidad de documentos. La copia incluye la
posición, no el contenido comprimido ni permisos SAF. No se escriben los originales.
Las pruebas y límites de validación Android real están en PRUEBAS.md.
