# Consulta integrada del catálogo en 0.10.0

Los campos importados de Peach original se consultan desde las fichas, la búsqueda
principal y el explorador de términos. Se utiliza el catálogo ya importado: no hay
una conexión adicional, servidor ni intérprete. Los registros sin archivo local
continúan en la pantalla Catálogo de Peach original; no se inventan archivos reproducibles.

## Orígenes y prioridades

Se conservan tres capas independientes:

| Capa | Conservación y uso |
|---|---|
| Archivos/NFO | Las columnas del escáner y nfoDetails conservan sus valores. Actualizar relee los archivos sin reemplazar la capa de catálogos |
| Catálogos importados | La instantánea sigue siendo el origen. catalogMetadata es un índice de consulta reconstruible, con nombre de origen, ID de asset, ruta y campos/términos |
| Edición personal | userTitle y userTags conservan prioridad. No se sustituyen al importar, reescanear, migrar o reconstruir el índice |

El título visible usa la edición personal cuando exista. Si todavía era solo el
nombre del archivo y no hay NFO registrado, puede usar un título de catálogo único.
También se completa un título vacío con ese título único. Cualquier NFO registrado
protege el título no vacío, incluso cuando coincide con el nombre del archivo: los
registros antiguos no distinguen de forma suficiente quién aportó ese título.
Las ediciones personales y los títulos de archivo/NFO permanecen almacenados.

Los campos de detalle ausentes pueden completarse con un valor único de catálogo.
El año se deriva solamente de fechas ISO válidas de precisión año, mes o día. La
fecha literal, aunque sea inválida, permanece como dato de origen. Duración, ancho
y alto registrados se muestran como datos del catálogo; no sustituyen duración
medida, posición AV ni orientación/decodificación del archivo.

Si varios catálogos aportan valores distintos de título, código, fecha, año, estudio,
serie, región, duración o dimensiones, la ficha muestra la diferencia y los bloques
de cada origen. No se elige uno para completar esos campos. Valores idénticos se
consideran un solo valor a este efecto; una edición/NFO existente conserva prioridad.
La revisión/corrección por campo y el historial de afirmaciones siguen pendientes.

## Búsqueda y filtros

- Se buscan los títulos/códigos/fechas y otros campos del origen, su nombre y ruta,
  creador, estudio, serie, etiquetas y nombres relacionados compatibles. No se lee
  otra vez cada instantánea al escribir una consulta: cada MediaEntry cachea su proyección.
- La exploración reúne términos NFO y del catálogo, con deduplicación exacta por
  documento. Dos fuentes con el mismo nombre no duplican el contador de archivos.
- La faceta **Creadores** conserva creator como campo propio. «Luz, Mar» o «Rivera,
  Ana» siguen siendo nombres enteros; no se dividen por comas en el catálogo importado.
- Las etiquetas personales, incluida la cadena vacía, tienen prioridad en el filtro
  de etiquetas. Los datos de origen siguen visibles en sus bloques y consultables por
  búsqueda textual: editar etiquetas no borra hechos de una instantánea.
- Las coincidencias de nombres con una identidad se señalan como **Catálogo importado**,
  separadas de NFO y vínculos manuales. Son una proyección por nombre exacto, sin fusionar
  UUID ni convertir el índice en una resolución automática de identidad.
- La tarjeta, orden por título, lector y colas de audio/imagen comparten las mismas
  funciones de presentación. El contenido y los identificadores de las colas conservan
  sus reglas previas, incluida la separación entre AV, imágenes y documentos.

En Detalles, **Catálogo · nombre** identifica asset y ruta originales y sus campos.
Se muestran ambos valores cuando el NFO o la edición personal difieren. El bloque
no ofrece edición de archivos ni una aprobación automática de nuevas fuentes online.

## Persistencia y reconstrucción

Room v9 añade media.catalogMetadata con predeterminado `[]`. La migración 8→9
reconstruye la consulta a partir de las instantáneas y correspondencias guardadas
en 0.9. No borra medios ni requiere reimportar cada catálogo para esos IDs conocidos.
Las cadenas de migración anteriores se conservan, sin fallback destructivo.

Reimportar un origen sustituye únicamente su proyección actual; otros orígenes siguen
presentes. Si una correspondencia cambia de documento, su proyección se retira del
anterior. Esto no retira vínculos explícitos o listas creados en importaciones anteriores:
la importación de organización sigue siendo aditiva, como se describe en IMPORTACION_CATALOGO.md.

La copia personal mantiene versión 6 y lectura v1–v6. No exporta este índice derivado
como estado personal; lo reconstruye de las instantáneas/correspondencias al restaurar
v6. Restaurar una copia anterior conserva el catálogo actual. La transacción incluye
la reconstrucción: un error no deja un estado personal restaurado a medias.

Al completar un escaneo, se reconstruye el índice de los documentos disponibles en
Room. Si se olvida una raíz y se vuelve a escanear con los mismos IDs documentales,
las correspondencias guardadas pueden recuperar esa consulta. Un ID distinto necesita
un mapeo explícito nuevo. No se transfieren permisos SAF dentro de las copias.

## Corrección de rutas del escáner

El escáner conserva la carpeta elegida como parte de la ruta visible, por ejemplo
`Videos / Set`. El importador obtiene la base documental del checkpoint raíz del
escaneo y descuenta exactamente esa base para comparar `Set/a.mp4` con el origen.
No adivina la base por el nombre actual de la carpeta. Una subcarpeta que también
se llame Videos permanece en la ruta relativa. Se conservan las comprobaciones
anteriores de raíz completa, tamaños conocidos, duplicados, mayúsculas y traversal.

La entrega 0.9 comprobó rutas relativas sintéticas pero no este prefijo producido
por el escáner real. 0.10 incorpora el caso con DocumentsProvider/DocumentScanner.
No se pide repetir la batería de uso anterior por esta corrección.

## Límites

El índice de consulta se limita a 512 KiB por documento, manteniendo identificación
de los orígenes omitidos. Si un registro excede ese espacio, la ficha indica **Índice
resumido** y dirige a Catálogo de Peach original para consultar/exportar la instantánea
completa. No se trunca la instantánea al construir este índice. Cuando el índice es
parcial no se usa un valor aparentemente único para completar títulos o campos:
podrían faltar otros valores. Búsqueda/filtros del índice pueden ser parciales en ese caso.

Los límites SQLite/JSON y de copias de la etapa anterior siguen vigentes. La suite
local no certifica el comportamiento de CursorWindow ni memoria/rendimiento de todos
los catálogos grandes sobre Android real. No se ha recibido una base personal del
usuario ni se han ejecutado las pruebas instrumentadas en este host.

No se añaden dependencias de ejecución ni permisos de red. Agencia/membresías,
publicaciones/deseos completos, edición de NFO, listas entre varias raíces, reversión
de importaciones y sincronización integral siguen abiertos. La matriz identifica el
trabajo restante y PRUEBAS.md contiene los resultados verificados de esta entrega.
