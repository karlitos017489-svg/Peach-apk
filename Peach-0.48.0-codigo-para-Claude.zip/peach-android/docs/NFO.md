# Metadatos locales en 0.4.0

Peach Local lee el NFO al indexar o usar **⋮ → Actualizar**. El archivo debe estar junto
al video con el mismo nombre base: `Ruta-de-campo.mp4` y `Ruta-de-campo.nfo`.
`movie.nfo` se usa como alternativa únicamente si la carpeta contiene un solo video.
Las raíces XML admitidas son `movie`, `episodedetails` y `musicvideo`.

Toque **Detalles** en la tarjeta o mantenga pulsado el video. La ficha es nativa,
desplazable y su texto puede seleccionarse. Desde **Editar / organizar** se mantienen
las mismas acciones personales de 0.3.0.

| Datos | Elementos XML leídos |
|---|---|
| Título | title; si falta, localtitle o name; si faltan todos, nombre del archivo |
| Sinopsis | plot; si falta, outline |
| Año | year; si falta, año de una fecha YYYY, YYYY-MM o YYYY-MM-DD |
| Fecha | premiered; si falta, releasedate o aired |
| Estudio | studio, admite varios |
| Reparto | actor/name; también actor/role para mostrar personajes |
| Etiquetas | tag y genre, sin duplicados exactos |
| Título original y frase | originaltitle y tagline |
| Dirección, guion, país, géneros | director, credits, country y genre, admiten varios |
| Duración NFO | runtime, minutos numéricos positivos; no reemplaza la duración de reproducción |
| Clasificación | mpaa, texto de la fuente |
| Colección | set/name o set de texto simple |
| Código | code o num; si falta, uniqueid de tipo javboss/jav/javid/dvdid/num/code |
| Identificadores | uniqueid con su atributo type; id antiguo solo si no hay uniqueid con valor |
| Serie, temporada y episodio | showtitle, season y episode; se admite temporada 0 |
| Artistas musicales | artist, admite varios |
| Valoración | ratings/rating/value, max y name; prefiere default=true válido; alternativa rating antiguo sobre 10 |

La búsqueda incluye esos campos, además de título/etiquetas personales, nombre,
carpeta, reparto, estudio y año. Distingue acentos; ignora mayúsculas/minúsculas.
No busca dentro de la sinopsis. Las colecciones y códigos son datos de ficha/búsqueda;
no crean agrupaciones ni cambian la identidad del video.

Los elementos principales se leen como hijos directos de la raíz. Así, el nombre o la
sinopsis de una colección y los campos del reparto no sustituyen los del video.
Un NFO con campos ausentes continúa siendo útil; los opcionales vacíos no se muestran.
Los valores numéricos no válidos se omiten. Las valoraciones respetan su escala y no
se convierten en una calificación personal del usuario.

## Conservación de los datos

- Room v3 añade la columna nfoDetails, inicialmente `{}`, mediante ALTER TABLE.
  Las migraciones desde v1/v2 conservan registros, listas, favoritos, visto, progreso,
  ediciones, raíces y checkpoints; no usan recreación destructiva.
- Después de instalar, use Actualizar una vez para cargar los campos nuevos. La
  migración no escanea automáticamente los documentos.
- Título/etiquetas editados siguen teniendo prioridad. La ficha muestra también sus
  valores de origen cuando hay una modificación local. Usar datos del archivo elimina
  únicamente esas dos modificaciones, como en 0.3.0.
- Los campos ampliados se importan; todavía no tienen editor personal. Actualizar
  vuelve a leerlos. Si el NFO desaparece o resulta inválido, se limpian sus datos
  importados; los personales se conservan. Un NFO inválido cuenta como advertencia.
- Las copias personales continúan en formato v2 y leen v1. No incluyen los datos de
  origen del NFO: se recuperan al indexar la carpeta. Restaurar no modifica esos campos.
- Se ignoran playcount, watched, resume, lastplayed y userrating del NFO; no pueden
  sobrescribir el progreso, el visto ni las preferencias guardadas en Peach.

## Límites y ejemplo

Se mantiene el límite de 1 MiB por NFO y el rechazo de DTD/entidades externas. Cada
campo de texto importado queda limitado a 16,384 caracteres más una elipsis. No se
descargan carátulas, trailers ni metadatos remotos; no se interpretan rutas del NFO
para acceder a otros documentos. El APK principal sigue sin permiso INTERNET.

El paquete `Peach-Local-ejemplo-NFO-0.4.0.zip` contiene un video sintético, un NFO de
datos ficticios y un subtítulo propio. Extráigalo en una carpeta local y añádala a
Peach. Busque `CAM-001`, `Ana` o `Expediciones`, y abra Detalles. El NFO declara 90
minutos a propósito: al reproducir el clip debe mantenerse su duración real.
Este material de prueba no se incluye en el APK principal.

Formato de referencia: https://kodi.wiki/view/NFO_files/Movies. La lectura de Peach
es un subconjunto; no representa compatibilidad completa con Kodi o el backend original.

La revisión de 0.4.0 también corrige el cierre del lector de miniaturas en API 27/28:
usa release() explícito en lugar de close(), incorporado en API 29. El marcador
visual sigue disponible cuando no se puede obtener una miniatura. La prueba JVM
no acredita decodificación física de video.
