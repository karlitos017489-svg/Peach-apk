# Exploración y grupos en Peach Local 0.6.0

Estas funciones se conservan en 0.7.0. Las copias actuales usan JSON v4, añadiendo
identidades y deseos; se sigue leyendo v3. Véase IDENTIDADES_Y_DESEOS.md para esas
funciones y para el ámbito de identidad compartido con biblioteca/visor/audio.

El botón **Explorar metadatos y grupos** ofrece reparto, estudios, artistas musicales,
dirección, series, colecciones, etiquetas, géneros y años. Cada nombre muestra el
número de archivos relacionados. El buscador del diálogo filtra los nombres; al
elegir uno se abre el mosaico con coincidencia exacta y todos los tipos de archivos.
Se pueden aplicar después búsqueda, tipo, favorito y orden. La selección se conserva
al volver a abrir; **Ver biblioteca → Toda la biblioteca** la retira.

En **Detalles → Editar / organizar → Explorar metadatos de este archivo** se puede
saltar desde la ficha a los archivos con el mismo reparto, estudio, serie o etiqueta.
Las etiquetas personales tienen prioridad; vaciarlas elimina los términos visibles
de ese archivo. **Usar datos del archivo** recupera las etiquetas importadas.

## Grupos y versiones

Desde **Detalles → Editar / organizar → Añadir a un grupo / versiones**, cree un
grupo o elija uno existente. Los grupos se abren desde Explorar. Para añadir otros
archivos, vuelva a Toda la biblioteca, abra su ficha y elija el mismo grupo.
**⋮ → Administrar grupo actual** permite renombrarlo o eliminarlo. La ficha de un
archivo abierto dentro del grupo permite **Quitar de este grupo**.

Los grupos son asociaciones explícitas del usuario. Sirven para reunir versiones,
partes o materiales relacionados, sin inferir identidad por nombre o código. Un
archivo puede estar en varios grupos y listas. Cada documento conserva su progreso,
favorito, metadatos y disponibilidad. Las listas definen secuencia; un grupo no inicia
automáticamente la reproducción de otras versiones AV. El visor recorre las imágenes
del grupo; una cola musical abierta por metadatos solo incluye los audios de esa vista.

Eliminar un grupo conserva los archivos y sus registros. Quitar una raíz de Peach
elimina los registros de esa raíz y sus asociaciones, como indica el diálogo; los
archivos originales no se alteran. Una ubicación temporalmente inaccesible conserva
las asociaciones. El reescaneo no reconstruye ni borra los grupos manuales.

## Copias y compatibilidad

Room v5 añade media_groups y media_group_items, con claves externas e índice por
documento. La migración 4→5 crea estas tablas sin modificar media ni sus identidades;
siguen disponibles todas las migraciones 1→2→3→4→5. No hay fallback destructivo.

Las copias JSON v3 añaden grupos y miembros. Se siguen leyendo v1/v2; restaurarlas
conserva los grupos ya existentes. v3 reemplaza nombre/miembros de los grupos con el
mismo ID y conserva los demás. Los miembros aún no indexados se omiten. Nombres/IDs
inválidos y miembros que no sean cadenas provocan rollback de toda la importación.
Límites: 8 MiB, 50.000 registros de estado, 1.000 listas y 1.000 grupos por copia,
50.000 miembros por lista/grupo. La copia no contiene medios, NFO ni permisos SAF.

Las listas estructuradas de términos NFO se almacenan dentro de nfoDetails, en el campo
interno _catalog, fuera de la ficha visible. Actualizar vuelve a leer NFO existentes.
Los metadatos sin listas estructuradas siguen siendo explorables mediante el texto
previo separado por comas. No se importan automáticamente alias ni identidades del
ledger original; véase COMPATIBILIDAD_ORIGINAL.md para las diferencias pendientes.
