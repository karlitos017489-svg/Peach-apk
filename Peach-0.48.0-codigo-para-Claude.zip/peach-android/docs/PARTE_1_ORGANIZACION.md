# Parte 1 de 6 — Organización de archivos · 0.42.0

El usuario cambia la cadencia: una entrega agrupada por cada parte de la lista acordada,
con comprobación del APK al terminar cada parte. No entregar un APK por cada subfunción.
Esta entrega reúne organización física, NFO y revisión de coincidencias/partes.
No se hicieron operaciones sobre archivos personales del usuario desde este entorno.

## Uso

Menú principal → **Organizar archivos / papelera**, o ficha de un archivo →
**Editar / organizar → Organizar archivo / escribir NFO**. Selecciona el archivo,
autoriza su raíz original para lectura/escritura y solicita la vista previa.
Android muestra su selector; se requiere la misma raíz ya añadida, sin ampliar permisos
silenciosamente. Para mover, elige además una carpeta de destino autorizada.

La vista previa por sí sola no escribe. **Aplicar** revalida origen, destino y metadatos,
guarda el registro operativo y realiza la acción. Abrir/restaurar la pantalla nunca
repite operaciones pendientes automáticamente. El escaneo debe estar pausado y finalizado.

### Renombrado, movimiento y papelera

- Renombrar conserva la extensión y comprueba nombres vacíos, rutas, controles y
  conflictos. Se rechaza un nombre ya ocupado; no se elige un reemplazo automáticamente.
- Mover usa la operación nativa del proveedor SAF, entre carpetas de ese mismo proveedor.
  Requiere capacidades de mover/crear y permisos de ambas raíces. No implementa copia y
  borrado entre proveedores. Un proveedor de solo lectura o sin esa capacidad queda fuera.
- Se mueve únicamente el archivo seleccionado. NFO, subtítulos y portadas auxiliares
  permanecen en su ubicación; esto se anuncia en la vista previa. No se hace un lote
  implícito con otros documentos. Después puedes escribir el NFO junto a la nueva ubicación.
- Papelera crea una carpeta identificada por UUID dentro de la raíz original y mueve
  allí el archivo. Lo marca como no disponible y excluye esa carpeta de escaneos futuros.
  Conserva sus bytes: no hay borrado definitivo de medios ni vaciado automático.
- Se calcula SHA-256 antes del cambio y se verifica el destino. Un resultado incierto
  queda para revisión. No se elimina una copia de origen para simular un movimiento.
- Mantiene el ID de biblioteca y sus favoritos, progreso, listas, grupos y vínculos.
  El escáner relaciona los documentos por su ubicación actual para no crear una identidad
  nueva si el proveedor cambia el ID documental al renombrar o mover.

En **Historial / papelera**, selecciona el registro y **Deshacer**. Se comprueban los
bytes actuales y el nombre de origen; se rechazan cambios externos o conflictos.
Las acciones del mismo archivo se deshacen desde la más reciente. Un registro que
necesita revisión ofrece **Reconciliar estado**, que verifica ubicaciones y actualiza
el catálogo, sin volver a ejecutar la operación física.

### Escritura y recuperación NFO

Disponible para audio/video. La vista previa muestra el XML completo y si se crea o
actualiza `nombre.nfo`. Exporta los campos compatibles actuales, incluyendo título y
etiquetas personales, código, serie y episodio. No exporta sesiones, claves, favoritos,
visitas o posición. El límite NFO es1MiB y el de un campo16384caracteres.

Al actualizar, conserva los bytes originales como respaldo antes de abrir la escritura.
Combina campos comunes con el NFO existente y conserva nodos no modelados, identificadores,
valoraciones y roles de actores sin cambio de nombre. XML con entidades/DTD, tipo
incompatible o contenido demasiado grande se rechaza antes de escribir. El NFO nuevo
contiene el subconjunto modelado por la aplicación, no un ledger completo del original.

Se lee otra vez el resultado para comprobarlo. Deshacer restaura el respaldo exacto
si el NFO no ha cambiado después. Si una escritura quedó incompleta, el historial permite
exportar el respaldo y, tras una nueva confirmación y comprobación del contenido actual,
restaurarlo. Para un NFO nuevo incompleto, ofrece retirarlo explícitamente, sin tocar el
audio o video. Una operación de recuperación interrumpida permanece registrada.

### Duplicados, obras, versiones y partes

**Contenido idéntico** agrupa candidatos por tamaño y compara SHA-256; no basta el nombre.
**Código NFO** propone coincidencias que pueden corresponder a versiones diferentes,
incluso en carpetas distintas. El código es evidencia, no certificación de contenido.
Cada propuesta requiere seleccionar miembros y guardar un grupo explícitamente.
Se revalidan metadatos/bytes antes de guardar; no borra archivos, fusiona registros o
comparte su progreso. Reutiliza grupos con exactamente los mismos miembros.

La revisión por nombre anterior continúa. Además, una propuesta por código NFO puede
crear una lista de partes de video entre carpetas: marcas explícitas consecutivas desde1,
misma firma de versión y totales coherentes. Rechaza huecos, números repetidos o mezcla
de versiones; conserva orden numérico y reutiliza listas idénticas. Las marcas del nombre
siguen siendo indicios, no mediciones del códec o la resolución real.

## Límites operativos

Archivo hasta16GiB con tamaño conocido. Verificación en bloques64KiB y comprobación de
plazo1h entre lecturas; un proveedor que bloquea no tiene un plazo absoluto garantizado.
La cancelación se admite en preparación/revisión. Un cambio físico iniciado se verifica
hasta terminar, o queda registrado si falla. No se promete una transacción atómica entre
un proveedor externo y Room, ni protección contra ediciones simultáneas de otras apps.

Revisión de hasta20.000 registros, lectura prevista total16GiB,500propuestas y200miembros
por propuesta; indica omisiones/revisión parcial. El selector inicial muestra hasta2.000
archivos; cualquier archivo puede abrirse directamente desde su ficha de biblioteca.

Registro operativo AtomicFile, máximo500operaciones/16MiB, en almacenamiento privado
excluido de copias. **Archivar** descarta deshacer y respaldo con confirmación, sin tocar
el archivo. Una papelera activa no se archiva. Borrar datos/desinstalar pierde el registro
y los respaldos privados; los medios trasladados permanecen en sus carpetas físicas.
La copia JSON de biblioteca no deshace movimientos ni sustituye este registro local.

Room13/esquemas y formato de copia18 permanecen. Solo se añade una actividad no exportada;
no permisos, dependencias, servicios, borrado de medios, ejecución automática o backend.
PRUEBAS.md distingue pruebas simuladas, instrumentación compilada y comprobación real.

## Siguientes partes

2. Fuentes, cuentas, enlaces y descargas.
3. Formatos y lectores pendientes compatibles con Android.
4. Importación/exportación, sincronización y servicios opcionales.
5. Interfaz, navegación, accesibilidad y rendimiento.
6. Validación Android, correcciones y documentación de incompatibilidades.

Cada parte podrá necesitar correcciones después de la prueba del usuario; no se promete
compatibilidad imposible para un proveedor, cuenta o formato. Se mantiene el APK autónomo.
