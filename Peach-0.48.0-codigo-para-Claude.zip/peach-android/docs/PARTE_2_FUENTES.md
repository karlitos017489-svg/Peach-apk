# Parte 2 de 6 — Fuentes, cuentas, enlaces y descargas · 0.43.0

28 de octubre de2026, America/Hermosillo. El usuario confirmó la parte1/0.42 y
pidió continuar con una entrega completa agrupada de la parte2. Se conservan las
nueve fuentes. Kemono, Coomer y SimpCity permanecen excluidos. APK autónomo para
SM-X230, sin PC, Termux o servidor Peach obligatorio. No se crea una suscripción
ni se amplían los permisos de una cuenta por guardar una sesión.

## Cuentas opcionales

Fuentes → Cuentas y sesiones permite iniciar sesión en una pantalla del sitio
o importar una cabecera Cookie propia: FANBOX, Patreon, SubscribeStar.com,
SubscribeStar.adult y F95. Los dos dominios SubscribeStar se mantienen separados.
Rule34.xxx conserva su user_id/clave API propios; Gofile conserva su token aparte.
Pawchive/cum.st/Paheal/Rule34Video siguen usando sus contratos públicos anteriores.

La pantalla de acceso es una WebView limitada al inicio de sesión oficial, con
JavaScript necesario para esa página, sin puente JavaScript, archivos locales,
contenido mixto, depuración WebView, descargas o reproductores web. Biblioteca,
consultas, lectura y medios continúan nativos. No se interceptan contraseñas,
MFA o CAPTCHA. Estos pasos los completa el usuario en el sitio. Google/Apple y
otros dominios de autenticación externos no se incorporan: puede hacerse el acceso
externo e importar una sesión propia. Algunos sitios rechazan WebView o exigen
verificación de navegador; no se promete que todos los flujos puedan completarse.
TLS inválido se cancela. Solo hay una superficie de acceso activa a la vez.

Guardar captura exclusivamente cookies del almacén WebView de esta app para el
sitio elegido, nunca cookies de Chrome u otras apps. Las cookies y almacenamiento
de esa superficie se limpian al salir; durante el acceso los administra WebView.
La sesión persistente se cifra con AndroidKeyStore/AES-GCM y AAD por sitio, en
noBackupFilesDir. No hay respaldo en texto plano ni inclusión en JSON o paquetes.
No se muestran o rellenan secretos guardados. Guardar no comprueba vigencia:
la siguiente consulta puede seguir siendo pública, fallar o requerir renovación.
Desconectar conserva cuerpos y archivos ya incorporados y no cierra otras apps.

Las consultas autenticadas aceptan rutas exactas de metadatos y redirecciones al
mismo recurso. No llevan Cookie a CDNs o al destino de un enlace externo. Solo los
adjuntos de downloads.fanbox.cc y uploads del host SubscribeStar exacto pueden
requerir la sesión de su propio sitio; no se propaga al CDN de entrega. ETag y
respuesta se limpian de ecos de secretos largos; los errores no incluyen Cookie,
contraseña, URL firmada o causa remota. HTTP429 conserva espera por sitio incluso
al cambiar o borrar sesión. Cambiar cuenta invalida revisiones y validadores de
sus fuentes; una consulta que detecta el cambio antes de aplicar no se incorpora.
No puede retirarse retroactivamente una solicitud que el servidor ya recibió.

## Cuerpos y adjuntos

Patreon y SubscribeStar conservan sus tarjetas públicas. Ahora **Consultar cuerpo**
puede leer el HTML visible servido para un post individual, comprobar post/autor,
extraer texto y adjuntos compatibles y dejar una revisión para importar. Se excluyen
scripts/bootstrap/estado de sesión, nodos ocultos, formularios, iframes, comentarios
y contenedores de paywall reconocibles. No se ejecuta ese HTML ni se deduce que
una vista previa sea un cuerpo completo. El resultado sigue marcado **parcial**.
Un rediseño, renderizado solo por JavaScript o acceso insuficiente puede impedirlo;
se conserva la tarjeta o cuerpo anterior. No se consultan APIs privadas Patreon.
Su API OAuth formal necesita un cliente/ámbito apropiado y no equivale a leer las
suscripciones a cualquier creador; no se incorpora un secreto de cliente o backend.

Los medios admitidos proceden del cuerpo, no de portadas de la tarjeta:

- Patreon: hosts c1–c999.patreonusercontent.com, ruta /4/patreon-media/p/post/;
  permite query firmada HTTPS, no se reutiliza como cookie o credencial API.
- SubscribeStar: uploads del dominio propio, o /uploads/posts/ de los hosts exactos
  d3ts7pb9ldoin4.cloudfront.net y star-uploads.s3-us-west-2.amazonaws.com.
- Redirecciones de esos medios solo a la misma URL. Otros hosts/variantes quedan
  como referencias y no se convierten en una descarga arbitraria.

FANBOX sin cuenta conserva su filtro gratuito explícito. Con sesión configurada,
solo admite además posts que el servidor marca isRestricted=false y feeRequired
no negativo; el cuerpo debe existir y coincidir con el creador/ID. No se elimina
una restricción de la API. Archivos FANBOX .mp4/.webm/.mkv/.mov/.m4v se clasifican
como video para las funciones nativas. Embeds externos, video no devuelto como
archivo y nodos no modelados siguen como referencias/parcialidad.

Los adjuntos compatibles entran en galería, video progresivo, preparación,
guardado y cola existentes. No se borran archivos o notas personales al refrescar;
una nueva tarjeta no reemplaza un detalle ya importado. Room13 se conserva.

## Descubrir, compartir y filtrar

Fuentes → Descubrir / filtrar fuentes ofrece filtros locales por proveedor,
texto/nombre/referencia y estado (activa, pausada, error/espera). Compartir un enlace
HTTPS desde otra app o pegarlo crea solo una propuesta normalizada. **Revisar enlace**
y **Añadir** guardan configuración sin consultar internet ni incorporar publicaciones.
No hay autolectura de enlaces del portapapeles o de bases privadas del navegador.
Se rechazan varios enlaces en una propuesta y los sitios excluidos.

**Buscar títulos en F95** usa la sesión propia y el contrato XenForo del original:
GET /search/ para obtener un _xfToken nuevo, POST /search/search con consulta por
título, seguido de resultados del mismo origen. Máximo120caracteres/100resultados,
respuesta2MiB,3redirecciones,15s conexión/lectura. No sigue un hilo al buscar;
seleccionar un resultado pide revisión para añadir su fuente. Cuenta cambiada,
cancelación, login, redirección externa y429 no reemplazan resultados válidos.
La búsqueda depende de la autorización y verificación que exija F95; no las evade.
No se afirma búsqueda global de los nueve sitios ni agenda automática de novedades.

## Pixeldrain

Se añade como servicio de un enlace presente en una publicación importada, no como
una décima fuente. **Enlaces Pixeldrain** consulta una vez /api/file/ID/info y muestra
nombre, tamaño y disponibilidad de SHA-256. Incorporar requiere revisión y revalida
la publicación/enlace para añadir sin borrar otros adjuntos o datos personales.
URL directa construida únicamente como https://pixeldrain.com/api/file/ID.
Sin claves, cookies, lista recursiva, rutas alternativas o redirecciones automáticas.
Solo archivos individuales /u/ID, no /l/listas ni filesystem privado.

Se rechazan can_download=false, availability o abuse_type no vacíos, hash inválido,
archivo vacío/mayor2GiB y manifiestos adaptativos. CAPTCHA/Premium/límites del servicio
siguen siendo condiciones reales: la app no sustituye esas verificaciones ni usa
otro dominio. HTTP429 guarda espera. Consultar metadatos no descarga el medio.
El SHA-256 esperado se conserva con el adjunto y se comprueba en descarga completa,
cola y cachés nativas de video/imagen, incluidas relecturas. Guardar verifica antes
de abrir el selector SAF. Un video en línea no verifica todo su hash antes de mostrar.
El SHA comunicado por el servidor prueba coincidencia con ese dato, no seguridad
del contenido. Una copia ya descargada de cola conserva su propia identidad/historial.

## Descargas en segundo plano

La cola anterior conserva su modo **Continuar cola** con pantalla abierta. Ahora
**Descargar en segundo plano → Iniciar** solicita explícitamente un servicio
foreground dataSync, con notificación de progreso real, abrir cola y **Pausar**.
El permiso de notificaciones se solicita en Android33+; si se deniega, Android
puede mostrar el servicio solo en su administrador de tareas. No es un permiso
de acceso a archivos ni una autorización para iniciar descargas automáticamente.

Un identificador de dueño en memoria evita dos motores y bloquea cambiar de modo
mientras una transferencia sigue activa. No se persiste ese consentimiento:
terminar proceso, forzar detención o reiniciar exige continuar manualmente.
No hay receptor de arranque, START_STICKY, tarea programada o reintento periódico.
Salir de la actividad no pausa una cola cuyo dueño sea el servicio explícito.
Pausa desde notificación/pantalla, timeout y destrucción cancelan red y conservan
el último fragmento durable; la recuperación anterior verifica ese fragmento.

Android15+ limita dataSync en segundo plano y puede invocar onTimeout; se solicita
pausa y stopSelf inmediatamente. Batería, conectividad, almacenamiento y políticas
de Samsung también pueden interrumpirlo. No se promete ejecución infinita o contra
una detención del sistema. WakeLock acotado6h y liberación al destruir; cada descarga
mantiene su plazo/validación anterior. No cambia128trabajos/2GiB por archivo/4GiB
privados, una transferencia, rangos/If-Range verificados o presupuesto compartido.
Guardar completas a SAF sigue siendo una acción explícita, no una exportación remota.

## Persistencia, compatibilidad y límites

Copia personal19, lee1–19. Marcar una versión nueva evita que0.42 interprete nuevas
referencias/tipos sin reconocerlos. Cuentas, claves, credenciales, WebView, fragmentos,
dueños de servicio y medios no entran en esa copia. Room13/esquemas, dependencias,
assets y cuatro bibliotecas RAR Android se conservan. Se añaden una aplicación
inicializadora sin red, actividades de cuentas/acceso/descubrimiento/Pixeldrain y
el servicio interno. Solo Descubrir se exporta para ACTION_SEND text/plain y no
ejecuta solicitudes al abrir. Nuevos permisos: notificaciones y foreground dataSync.
No se añaden cámara, micrófono, contactos o acceso general a almacenamiento.

Esta parte no convierte las nueve fuentes en APIs universales: historial y
paginación de Patreon/SubscribeStar siguen limitados al contrato público anterior;
login federado externo, páginas solo JS, hosts de medios no auditados, DRM y
servicios sin acceso permitido no se presentan como compatibles. Los formatos
HLS/DASH requieren un manifiesto/servidores/admisión propios: los nueve contratos
admitidos aquí siguen publicando archivos MP4/WebM compatibles o referencias
externas; no se inventa reproducción adaptativa ni se envían sesiones a Mux/iframes.
Un fallo real de esas variantes necesita nueva evidencia; no se oculta como HD.

PRUEBAS.md distingue JVM/Robolectric, transporte simulado, comprobaciones públicas,
instrumentación compilada y prueba física pendiente. La aceptación0.42 no prueba
los nuevos accesos de0.43. Tras probar esta parte y corregir sus defectos, sigue
parte3 (formatos/lectores),4(import/export/sync),5(interfaz/rendimiento),6(validación).


## Referencias primarias de contrato

- Original fijo: https://github.com/peach-mitao/peach/tree/de22796c04919aaa057d77930c33c81313765569
  (follow_sources.py, búsqueda XenForo y conectores públicos; no se ejecuta su servidor).
- Patreon API/ámbitos: https://docs.patreon.com/ . La lectura de cuerpo implementada
  usa HTML visible autorizado, no convierte OAuth en acceso universal a suscripciones.
- Pixeldrain API/info/hash/rangos/gates: https://pixeldrain.com/api .
- Android dataSync/timeout: https://developer.android.com/develop/background-work/services/fgs/timeout .
- CookieManager de la propia WebView: https://developer.android.com/reference/android/webkit/CookieManager .

La comprobación pública final JDK21 reconoció una tarjeta Patreon y2522caracteres de
cuerpo parcial, y seis tarjetas SubscribeStar.com y1277caracteres del detalle parcial
seleccionado. Cero descriptores de medios en esos dos cuerpos concretos, cero medios
solicitados y sin cuentas. No se atribuye ese resultado a sesiones de pago, otros
creadores o ejecución Android. El HTML y texto real no se empaquetan.
