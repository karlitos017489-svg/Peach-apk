# Parte 3 de 6 · Peach Local 0.44.0

29 de octubre de 2026, America/Hermosillo. El usuario confirmó «Todo funciona» para
0.43/parte 2 y autorizó seguir. Se mantiene una entrega agrupada y un APK para probar
antes de pasar a la parte 4. Este alcance amplía lectores; no significa que cualquier
formato, archivo cifrado o códec sea compatible. No se usa PC, Termux o servidor en Android.

## Comprimidos

ZIP/CBZ ahora admite ZIP64 de un solo volumen dentro de los límites anteriores del
lector: origen 512 MiB, selección 64 MiB, 10.000 entradas e índice central 16 MiB.
ZIP64 no eleva esas cuotas. Se comprueban EOCD, localizador, registro ZIP64, coherencia
de valores clásicos/64 bits, discos, tamaño real de directorio, registros centrales,
campos extra 64 bits y desbordamientos antes de abrir ZipFile. Solo almacenar/Deflate;
cifrado, Deflate64, volúmenes y otros métodos se rechazan explícitamente. Rutas inseguras,
nombres repetidos, CRC y límites de expansión mantienen su rechazo/limpieza. Los nombres
sin flag Unicode usan CP437 del formato; no se adivina Windows-1252. No extracción general,
enlaces, AV interno o archivos anidados. El origen nunca se modifica.

7z permite introducir contraseña propia solo para una apertura con cabecera plana
sin cifrar ni comprimir. El motor Java anterior aporta AES; no se añaden bibliotecas.
Antes de pasar contraseña al decodificador, un lector de metadatos recorre los coders
reales del MainStreamsInfo, sin AdditionalStreamsInfo, con una entrada/salida por coder,
propiedades acotadas, hasta 16 coders por carpeta y máximo 2²⁰ rondas por derivación
(o el modo directo 63 definido por 7z). No basta buscar una firma binaria. Cabeceras
codificadas/cifradas, coders alternativos/complejos o costes superiores quedan fuera.
Se conservan fuente/expansión declarada 512 MiB, selección 64 MiB, memoria de decoder
64 MiB y cabeceras 4 MiB. La contraseña queda en memoria de la apertura, no en preferencias,
Room, JSON, logs o archivos. Se borra el array propio al cerrar; no se afirma borrado
forense de todas las copias internas del framework/JCE. Rotar o reabrir pide introducirla
otra vez. Un error conserva el archivo seleccionado anteriormente y elimina el parcial.

RAR5 sólido amplía el diccionario máximo de 16 a 64 MiB; conserva 128 MiB declarados
por contenedor, entradas comprimidas no vacías hasta 64 MiB, mismo diccionario y primera
entrada independiente. Algoritmo 0/métodos 1–5, CRC/tamaño seleccionado, motor aislado y
cuotas nativas anteriores. Los cuatro .so no cambian. Los bytes de entradas previas se
reconstruyen/descartan y no se certifica su CRC ni todo el archivo. Las muestras de 32/64
MiB derivan de nuestros RAR5 anteriores cambiando solo declaración de diccionario y CRC
de cabeceras; el JNI Linux real comprueba lectura exacta de todas las entradas en orden
inverso. Esto no se presenta como corpus de archivos nuevos producido por WinRAR64 MiB
ni ejecución de las ABI/Binder Android.

Se revisó el motor libarchive 3.8.10 fijado: RAR4 sólido devuelve explícitamente
«RAR solid archive support unavailable» en archive_read_support_format_rar.c. RAR cifrado,
volúmenes y RAR7 comprimido no tienen implementación compatible en este APK. ANSI RAR4
ambiguo tampoco se convierte silenciosamente a otro nombre. No se aflojan esas barreras
ni se cambia de licencia/motor para anunciar soporte que no existe. RAR4/5 anteriores,
Unicode heredado, TAR/GZIP y 7z sin contraseña conservan sus lectores y límites.

## EPUB

El orden de lectura sigue el spine. Se añade índice EPUB 3 NAV y EPUB 2 NCX con títulos,
jerarquía y destinos dentro de capítulos admitidos. Hasta 1.000 destinos, profundidad 32,
metadato 1 MiB, etiqueta/fragmento 300 caracteres. Una selección puede saltar al texto
visible del id/anchor local. Índice inválido, remoto, con DTD, fuera del contenedor o
no perteneciente al spine se descarta completo; el libro conserva sus capítulos.
Sin consultas, navegador, ejecución HTML, scripts, recursos remotos o enlaces externos.

Se omiten fuentes declaradas con ofuscación estándar IDPF/Adobe porque el lector de
texto no carga tipografías del EPUB. Se comprueba que los destinos son fuentes del
manifiesto. No se descifran ni extraen esas fuentes. Texto/imágenes cifrados, DRM y
algoritmos no reconocidos siguen rechazados. Las imágenes se abren aparte mediante
Contenido; no se promete CSS, maquetación completa, imagen inline, MathML/SVG o EPUB con
DRM. Texto seleccionable, tamaño de letra, capítulos/posición e imágenes anteriores
conservados. Búsqueda literal en el texto visible actual con salto y primera coincidencia
marcada; no búsqueda completa de todos los capítulos ni del texto truncado.

## PDF

En Android 15/API35 o posterior, Opciones admite contraseña propia y búsqueda de texto
con PdfRenderer/LoadParams del sistema. Contraseña incorrecta no se interpreta como
archivo vacío ni se elimina el original. En versiones anteriores conserva lectura PDF
sin contraseña y explica el requisito. La contraseña no se guarda/restaura al rotar.

La búsqueda recorre 16 páginas por acción, muestra páginas y número de coincidencias,
permite continuar las siguientes 16 y abrir un resultado. No OCR: los PDF escaneados
pueden no tener texto. Sin edición, formularios, anotaciones o uso de enlaces PDF.
Renderizado nativo previo hasta 2048 px, zoom y paginación conservados. Los nuevos tests
Android nativos están compilados y pendientes de ejecución; el test de UI/búsqueda
JVM usa un adaptador explícito y no se confunde con el PdfRenderer de un dispositivo.

## Video, audio y subtítulos

Info en el reproductor muestra las pistas realmente leídas por Media3: MIME/códec,
dimensiones o canales/frecuencia declarados en la pista, selección y disponibilidad
del decoder. No atribuye HD a la extensión ni informa una resolución inventada.

Pruebas con extractores de producción y ocho archivos propios: MP4, MOV y MKV con H.264;
WebM/VP8; AVI/MPEG-4 Part 2 con etiqueta XVID; FLV/H.264; TS/H.264; programa MPEG-2.
Se obtienen muestras de video y formatos; no se ejecuta el códec hardware del SM-X230.
El primer ejemplo MPG usaba pack MPEG-1, no reconocido por sniff de Media3: se documentó
el fallo y se generó programa MPEG-2; no se declara soporte de todo MPG. WMV/ASF, RMVB,
ISO y STRM no adquieren reproductor. No FFmpeg/VLC/transcodificación en el APK, nuevos
hosts, HLS/DASH o DRM. Los formatos de audio anteriores siguen en Media3/sistema.

Subtítulos externos SRT/VTT/ASS/SSA: UTF-8 estricto o UTF-16 con BOM, normalizados en
memoria antes del parser real. Para subtítulos antiguos se puede elegir Windows-1252
al añadirlos; no adivina codificación. Máximo 8 MiB de origen, texto de salida acotado,
lectura fuera del hilo UI, cancelación y solo URI content autorizada ligada a identidad
opaca. No descarga URLs de subtítulos. El transporte progresivo de fuentes conserva su
motor anterior. Subtítulos ya asociados se tratan como Unicode; si son 1252 se añaden
manualmente como alternativa. ASS conserva el subconjunto de estilos/efectos de Media3,
no un motor ASS completo. No búsqueda online de subtítulos en esta parte.

## Conservación y referencias

Sin cambios de Room13/esquemas, copia19/lectura1–19, permisos, manifiesto, componentes,
fuentes/cuentas/descargas ni organización. Firma original para actualizar sin desinstalar.
Dependencias runtime y assets/.so iguales a0.43; fixtures solo en test/proyecto/muestras.

Contratos primarios usados: [PKWARE APPNOTE6.3.10](https://pkware.cachefly.net/webdocs/casestudies/APPNOTE.TXT),
[EPUB3.3 navegación](https://www.w3.org/TR/epub-33/#sec-nav),
[PdfRenderer](https://developer.android.com/reference/android/graphics/pdf/PdfRenderer),
[PdfRenderer.Page](https://developer.android.com/reference/android/graphics/pdf/PdfRenderer.Page),
[Media3 formatos](https://developer.android.com/media/media3/exoplayer/supported-formats).
La decisión 7z se contrastó con fuentes de commons-compress1.28.0 (AES256SHA256Decoder/
SevenZFile) de su artefacto sources oficial Maven; RAR usa el tar libarchive3.8.10
vendorizado con SHA256 a1bffbe5152cfe869751179e7b16648c87c461cb8c46eee75062efbe164cc57c.
No se empaquetan textos de especificaciones o medios externos.
