# Parte 4 de 6 · Peach Local 0.45.0

29 de octubre de 2026, America/Hermosillo. El usuario confirmó «Todo funciona» en
0.44/parte 3 y autorizó seguir. Se entrega esta parte agrupada para comprobar en la
SM-X230; no se presume aceptación nueva. Android autónomo, sin PC/Termux/backend Peach.

## Paquete portable y alcance de los datos

Menú → Importación y sincronización permite exportar una versión nueva del formato
`peach-local-exchange` v1, leerla y revisar cambios. Contiene el estado compatible de
copia v19, inventario relativo y metadatos adicionales de archivos: títulos/etiquetas
personales, favorito/visto/progreso/contadores; listas/grupos; identidades, alias,
referencias/relaciones y afiliaciones; deseos/seguimiento; publicaciones/cuerpos y
configuración de fuentes; lectura/historial y proyecciones de catálogos originales.
Añade título/tags/reparto/estudio/descripción/año/NFO y fecha de primera incorporación.

No es una copia de archivos o del sistema: no incluye medios, descargas/cachés/cola,
contraseñas/cookies/claves, permisos Android, ubicaciones URI utilizables en otro equipo,
subtítulos manuales con URI, carátulas con URI, preferencias del dispositivo, papelera
ni diarios de operaciones físicas. No convierte todo el ledger original en un formato
Android de ida y vuelta. El importador SQLite/JSON de Peach original y su exportación
de proyecciones seleccionadas continúan disponibles en la pantalla nativa previa.
No ejecuta SQL importado ni modifica la base original; no reconstruye campos del ledger
no modelados. Las copias clásicas v1–19 siguen en el menú anterior y conservan su aviso
de reemplazo por IDs locales: el formato portable nuevo se identifica por separado.

El JSON portable no está cifrado. Puede contener notas, historial, cuerpos guardados y
enlaces personales, incluidos cuerpos que el usuario obtuvo con su cuenta. «Sin
credenciales» significa que no se lee/exporta el vault de cuentas; no significa que las
notas o enlaces contenidos sean públicos o que se deba compartir el paquete con cualquiera.
El usuario elige el destino de cada archivo y su intercambio.

## Vínculos de archivos y límites de identidad

Los IDs de medios y carpetas se sustituyen por tokens SHA-256 opacos; todas las referencias
tipadas se remapean: estado, listas/grupos, lectura/historial, vínculos de entidades,
deseos/publicaciones y bindings de catálogos. No se reemplazan strings arbitrarios que
coincidan con un ID. Los permisos originales jamás se convierten en permisos nuevos.
Las rutas del catálogo original se conservan como metadatos de la proyección y pueden
revelar nombres de carpetas, sin conceder acceso a esos documentos.

En el otro dispositivo se añaden/escanean carpetas antes de revisar. Vinculación explícita
entre raíz del paquete y raíz local: ruta relativa exacta, tamaño y familia, con escaneo
completo y archivo disponible. Duplicados por ruta, tamaños/familias distintos y varios
medios remotos para el mismo documento local no se eligen automáticamente. El usuario
puede proponer un vínculo individual, sometido también a esas comprobaciones. Solo un
paquete cuyo origen coincide con la identidad propia sugiere las mismas raíces por token;
la revisión y Aplicar siguen siendo necesarios. No crea medios ficticios o grants.

Ruta/tamaño NO prueban igualdad de bytes; no se calcula un hash de cada película para
exportar. No adivina nombres tras renombrados entre dispositivos ni sincroniza los medios.
Lo no vinculado sigue en el paquete para reabrir después de escanear/vincular; no entra
como archivo accesible. Listas/grupos con miembros sin vincular protegen la lista local,
y no se crean listas parciales sin avisar. Se conservan vínculos de entidades a medios
locales fuera de la correspondencia. Los nuevos deseos/publicaciones pueden conservar
sus metadatos sin un medio vinculado. Revisa la tabla de vínculos y los cambios elegidos.

## Sincronización manual por campo

Cada instalación mantiene una identidad de origen y un contador persistido, independiente
del reloj, que aumenta al preparar una exportación. El número puede tener huecos si se
cancela guardar. Paquete íntegro/JSON exacto/UTF-8 estricto y SHA-256 canónico propio;
control de campos, tipos, límites, profundidad y referencias mediante validación
separada con Room en memoria. La suma detecta alteraciones: no es firma/autenticación del
remitente. Seleccionar un archivo no demuestra quién lo creó; no se promete confianza
criptográfica entre usuarios ni defensa contra un autor que fabrique números mayores.

Primera revisión: campos distintos de un registro ya existente son conflictos y conservan
lo local por defecto; registros nuevos compatibles se proponen como adiciones. Después
se compara actual local, versión entrante y última versión importada de ese origen:
si solo cambió el entrante se propone; si el entrante no cambió, conserva lo local;
si cambiaron ambos, requiere elegir local/entrante por campo. No se suman contadores ni
se deduplican personas por nombre. Las relaciones y miembros ordenados son unidades;
posición/duración y posición de lectura se eligen juntas. Visitas de historial son
atómicas y la misma identidad conserva su actualización más reciente. El catálogo y sus
bindings se eligen juntos. No mezcla arbitrariamente fragmentos incompatibles.

No hay borrado de registros por ausencia remota/tombstones. Los cambios de membresía
explícitos sí pueden revisarse cuando los documentos necesarios están vinculados.
No hay fusión de texto o merge automático de miembros de listas. Una combinación que
rompa nombres únicos, referencias o límites rechaza la transacción completa. No aplica
un «subconjunto aproximado» ni ignora un campo desconocido. La creación de listas/grupos
conserva su fecha; una lista ya existente mantiene su fecha de creación local.

Se rechaza una versión anterior al último contador aceptado, aunque traiga una fecha
más reciente; también contenido diferente con el mismo contador. Olvidar una base es
una acción explícita y hace que la próxima revisión vuelva a tratar diferencias como
primer encuentro. No borra la biblioteca. Máximo cuatro bases locales por origen. Este
intercambio es bidireccional al exportar/importar versiones en ambos sentidos; no es
una sesión automática, continua, agenda, servicio ni sincronización remota de descargas.

Al aplicar se relee el documento elegido para comprobar que no cambió; se revalida la
base local y el estado de biblioteca/inventario, incluidos URI actual, permisos indirectos
por su inventario, metadatos, generación/estado de escaneo. La comprobación no afirma que
los permisos del SO sigan concedidos: esos los verifica Android al abrir documentos.
Si cambian datos, ubicación, escaneo o base, se exige revisión nueva. Se serializan los
commits de intercambio dentro del proceso. No hay garantía de consistencia instantánea
entre clientes/nodos de un proveedor cloud: se comprueba lo que expone el documento leído.

## Recuperación

Antes de terminar el commit se escribe con AtomicFile la imagen anterior y huella posterior
en noBackupFilesDir. Error de validación/diario/cancelación previa al commit revierte la
transacción; no se anuncia éxito parcial. Deshacer última importación solo restaura el
estado propio si coincide exactamente la huella posterior, para no tapar cambios nuevos.
Retira de la base las filas añadidas por esa importación y restaura los datos anteriores;
no borra originales, permisos o cuentas. Una importación sin cambios no reemplaza la
última recuperación útil. El estado de fuentes no modificado conserva sus revisiones y
validadores; no se activa ninguna consulta o descarga por importar.

Room y archivos de recuperación no constituyen una transacción distribuida: si el commit
termina pero falla escribir la nueva base del origen, se informa «datos aplicados» y se
conserva Deshacer. Volver a revisar no suma los cambios otra vez. Los archivos privados no
sobreviven a borrar datos/desinstalar; un commit de SQLite fallido o un cierre justo en
el límite se reconoce después por huellas, no se promete recuperación de cualquier fallo
del sistema. La interrupción de un ContentProvider no tiene plazo absoluto garantizado.

## Guardado y nube opcional

Se prepara el paquete privado antes de abrir ACTION_CREATE_DOCUMENT. Cada guardado crea
un archivo/version nuevo; no se sobreescribe el documento compartido previo. Se copia en
worker, cierra y relee el resultado antes de anunciar éxito. Un destino truncado/incorrecto
no se da por guardado; se intenta retirar solo ese destino recién creado, no otros archivos.
Si el proveedor no permite retirarlo, puede quedar una copia fallida para revisar. El
paquete preparado permanece para reintentar y permite completar un resultado del selector
tras recrear el proceso sin poner megabytes en Bundle. Girar conserva borrador/elecciones;
abrir o girar no relee la nube ni aplica. Tras muerte de proceso se vuelve a elegir la
importación: no se restaura autorización de aplicar automáticamente.

Local/USB u otros documentos del selector funcionan por SAF. Una nube es opcional y
requiere un proveedor de documentos instalado, disponible y autorizado por el usuario;
el proveedor gestiona su cuenta. No cliente/API nuevos de OneDrive, Drive, 115, CloudDrive,
OpenList o PikPak; no se afirma integración de cada servicio por mostrar el selector.
Si no aparece un proveedor no se simula su acceso. No hay subida automática o sobrescritura
con CAS inexistente en SAF. Exporta a una versión nueva y el otro equipo elige esa versión.

## Cuotas y conservación

Estado v19 hasta8MiB dentro de paquete16MiB; 50.000 medios,1.000 raíces y límites previos
por dominio; 180.000filas/depth40/600.000tokens de texto, revisión hasta20.000cambios;
listas de revisión paginadas de100 con filtro. Valores largos muestran vista parcial,
valor íntegro en el paquete. Metadatos textuales acotados16.000caracteres/NFO64KiB.
Diario local hasta64MiB y cuatro bases de hasta16MiB; preparación hasta16MiB. Son cuotas
de datos y parsers, no promesa de memoria máxima del proceso. Un intercambio que supere
límites se rechaza, no se trunca o aplica en secreto. Bibliotecas grandes pueden requerir
un flujo de división/selección aún no incluido, o usar la proyección de catálogo existente.

Room13/esquemas/BackupStore/copia19, dependencias y bibliotecas nativas conservados.
Una actividad interna nueva, sin permisos/servicios/proveedores/exportaciones nuevos en
el APK principal. El proveedor propio de prueba solo existe en el APK instrumentado.
Se conserva la firma para actualizar sobre0.44. Nueve fuentes y exclusiones previas.
Partes5(interfaz/rendimiento) y6(validación/correcciones) pendientes tras esta prueba.

Referencias primarias de SAF revisadas: [Document providers](https://developer.android.com/guide/topics/providers/document-provider)
y [Documentos compartidos](https://developer.android.com/training/data-storage/shared/documents-files).
El alcance original sigue fijo en peach-mitao/peach de22796c04919aaa057d77930c33c81313765569;
los adaptadores del servidor original no se presentan como APIs Android implementadas.
