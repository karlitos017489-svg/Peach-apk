# Parte 5 de 6 · Interfaz, personalización y almacenamiento

Base aceptada por el usuario: Peach 0.45.0 / parte 4. La aceptación general fue
«Todo funciona», sin inferir ejecución propia en su tablet. El 29 de octubre de 2026
(America/Hermosillo) autorizó parte 5 y solicitó descarga directa de fuentes hacia
Google Drive, diseño minimalista y sencillo, colores, fondos, animaciones y volumen.

## Implementación en revisión para 0.46.0

Biblioteca con cuatro accesos visibles: Biblioteca, Fuentes, Descargas y Ajustes.
Búsqueda principal y filtros desplegables. Se conservan filtros, carpetas, listas,
identidades, publicaciones, organización, historial, lectores y las herramientas del
menú, con sus identificadores anteriores. Temas claro, oscuro y del sistema; seis
colores con variantes legibles; tamaños de tarjetas y una vista horizontal de lista.
Fondo privado de Biblioteca, intensidad ajustable; imagen de entrada hasta 16 MiB,
reducida a 1440 píxeles por lado y guardada como JPEG. No se exige permiso permanente
al original. El fondo anterior se conserva si la imagen nueva no puede prepararse.

Movimiento opcional: desactivado, fundido o entrada deslizante, expansión de filtros
y respuesta de botones. Se respeta la desactivación global de animaciones de Android.
Los lienzos de video, imagen y lectura conservan controles propios y un marco oscuro
legible. No se personaliza la representación de las páginas de un documento como fondo.
El volumen del reproductor controla la ganancia de Media3 entre 0 y 100 %, con silencio
y restauración. Es independiente del volumen multimedia de Android; no amplifica por
encima de él. Botón disponible también con la barra de video oculta; audio usa su
MediaController actual. Ajuste conservado en esta tablet.

## Guardar directo en un proveedor de nube o carpeta

Desde Guardar adjunto se elige entre transferencia directa y preparación habitual.
Los videos importados ofrecen también un botón directo para la variante seleccionada.
Se conserva la admisión de enlaces, sesiones permitidas y redirecciones de SourceHttp;
no se añade un proxy que entregue credenciales o enlaces al proveedor de nube.

El selector ACTION_CREATE_DOCUMENT crea un destino nuevo antes de consultar el medio.
Si Drive está instalado y ofrece el destino en Android, el usuario puede seleccionarlo.
La app escribe el flujo HTTPS al OutputStream del documento con bloques de hasta 64 KiB,
prefijo de 4 KiB y digest incremental. No crea un archivo completo de medios en Peach.
No añade un cliente OAuth/API propio de Google Drive, cuotas o credenciales de terceros.
El proveedor puede usar su propia copia temporal, retener datos sin conexión o subirlos
más tarde. Cerrar el flujo correctamente significa entregado al proveedor, NO confirmación
del servidor de Google. La app lo indica y no anuncia una subida remota certificada.

Límite 2 GiB y una transferencia directa activa por proceso, sin reanudación ni
segundo plano prometido. Mantener la pantalla abierta. Salir cancela; rotar conserva
la operación mediante ViewModel. Reiniciar el proceso no inicia red automáticamente.
Checks de longitud declarada/real, MIME/prefijo contra páginas de error y SHA-256
cuando la fuente lo declara (incluido Pawchive y Pixeldrain). No equivalen a prueba
de todos los códecs ni a hash leído de vuelta del servidor cloud.

Ante fallo/cancelación se intenta retirar exclusivamente el documento nuevo. Puede
quedar un archivo incompleto si el proveedor no permite borrarlo, perdió el permiso,
no responde o se detuvo el proceso. Diario privado de hasta 16 referencias, escrito
antes de transferir: Revisar archivos interrumpidos permite retirar ese destino o
conservarlo y quitar el aviso, después de comprobarlo en el proveedor. Sin limpieza
automática de nube al abrir la app. Si no hay permiso tras reinicio, revisar el archivo
directamente en Drive. Una interrupción durante una escritura bloqueada depende del
proveedor; no se promete un plazo absoluto de cancelación.

## Rendimiento y conservación

La biblioteca agrupa notificaciones de datos para evitar renders repetidos; búsqueda
mantiene debounce. Miniaturas de 8 MiB, dos trabajadores y cola de 48 trabajos, con
solicitudes repetidas compartidas mediante referencias débiles. RecyclerView conserva
solo seis vistas extra y desactiva sus animaciones cuando el usuario lo pide.
Los fondos y la limpieza trabajan fuera del ejecutor de consultas/guardado de progreso.
Almacenamiento muestra las cachés y el espacio libre de la app. Limpieza explícita:
miniaturas en memoria, imágenes temporales y videos no abiertos/preparándose. Respeta
leases del reproductor, la cola persistente, originales SAF, cuentas, biblioteca y
permisos. El proveedor administra su propio espacio. Sin benchmark físico o promesa
de velocidad/RAM total a partir de estos límites internos.

Room 13, copia 19, esquema de intercambio 1, nueve fuentes y exclusiones de
Kemono/Coomer/SimpCity conservados. APK autónomo SM-X230, sin PC/Termux/backend.
Verificación final: 1132 pruebas JVM/157 clases sin fallos, errores u omitidas;
69 pruebas Android compiladas, ninguna ejecutada; lint 0 errores/138 avisos.
Firma original, v2 y alineación 16 KiB verificadas. No dispositivo o nube real probados.
PRUEBAS.md y evidence/0.46.0 distinguen el avance y los resultados finales.
