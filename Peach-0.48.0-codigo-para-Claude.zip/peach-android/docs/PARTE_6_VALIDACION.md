# Parte 6 de 6 · Validación y correcciones · 0.47.0

29 de octubre de 2026, America/Hermosillo. El usuario aceptó 0.46 / parte 5 y autorizó
continuar. 0.47 se entrega para prueba; todavía no está aceptada en la tablet.

Fondos: AtomicFile recupera escrituras interrumpidas, retirada completa de auxiliares,
revisión independiente de tamaño/fecha y recorte centrado que preserva proporciones.
Volumen: diálogo retirado antes de liberar reproductor/controlador al salir. Un segundo
destino directo rechazado se limpia fuera de la UI, sin liberar la transferencia activa.

RAR: se elimina la recursión entre TLS emulado y asignador limitado, usando claves
pthread de libc. Cuatro ABI reconstruidas con NDKr30/API26, fuente libarchive3.8.10,
cuotas/CRC/tiempos/descriptor-only IPC y servicio aislado conservados. ZIP/ZIP64 usa
Commons Compress ya dependiente para evitar el fallo de offsets de ZipFile en Android
antiguo; preflight ZipDirectory, cuotas, nombres, métodos y CRC se conservan.

Ajustes y menú de Biblioteca → Comprobar funcionamiento. Abrir solo consulta el último
informe propio. Iniciar ejecuta ocho muestras propias: firma/versión, archivos privados,
Room temporal/copia/intercambio, PNG, PDF, una salida H.264, una salida AAC y RAR5 sólido.
No lee tu biblioteca/archivos personales ni cuentas/red/fuentes/nube; no emite sonido.
Rotar conserva la operación; salir cancela. Cancelar deja resultado parcial. Timeout
queda No comprobado, nunca Correcto. Los bloqueos nativos/proveedor no tienen garantía
de plazo absoluto; RAR conserva watchdog anterior. MediaCodec usa buffers sin superficie
ni AudioTrack; no certifica salida física, todos los códecs/perfiles o reproducción completa.

Informe privado AtomicFile, exportación explícita a nuevo documento con relectura.
Fallo retira solo el nuevo destino cuando puede y conserva el informe local. Incluye
app/modelo/Android/ABI/tiempos/resultados; no títulos/rutas personales, credenciales,
seriales o cuentas. No envío automático. Solo probes de tests marcan testProbesInjected;
la app normal y las pruebas nativas usan motores reales.

La suite histórica de instrumentación usa la base principal de su perfil de pruebas.
Su APK es exclusivamente para emulador/perfil desechable. La comprobación del APK normal
usa una Room temporal aislada y sí está diseñada para la instalación del usuario.

## Resultados

1152 JVM/Robolectric en 161 clases, 0 fallos/errores/omitidas. Android: 73 compiladas, 72 ejecutadas y 72 aprobadas, 1 omitida(s), 0 fallos/errores; los 73 casos terminaron.

Emulador oficial Android 9/API28 x86_64 por software, sin KVM. No Samsung/ARM64, Drive/cuentas reales, batería o salida física certificadas. Android16/API36 se intentó sin completar arranque; no se ejecutaron tests allí.

Se verificó actualización firmada 0.46→0.47 con1105 medios propios y favorito/progreso
comprobados antes. DB/WAL/SHM y preferencias de apariencia conservaron SHA256 exactos.
Esto no certifica permisos externos SAF, cuentas reales o KeyStore durante actualización.
Sigue GUIA_PARTE_6_047.md en la tablet. La sexta entrega no cierra incompatibilidades
anteriores o paridad universal. Nueve fuentes; Kemono/Coomer/SimpCity excluidos.
