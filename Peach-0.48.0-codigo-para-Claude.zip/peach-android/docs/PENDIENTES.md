# Estado actual: rediseño 0.48.0 para prueba

0.47 fue aceptada por el usuario. La nueva 0.48 requiere validar navegación, fuentes y reproductor en la SM-X230. Consulta [pendientes de 0.48](PENDIENTES_048.md) y su [guía](GUIA_REDISENO_048.md). Los límites históricos que siguen no se eliminan por el rediseño.

# Peach Local: cuánto falta

Estado al 29 de octubre de 2026. El usuario confirmó partes 1–5 / 0.42–0.46.
0.47 entrega parte 6 de comprobación y correcciones para prueba. Última aceptación
comunicada: 0.46. La confirmación general del usuario no se atribuye a pruebas propias.
El objetivo sigue siendo APK autónomo SM-X230 con funciones originales compatibles.

La base de uso ya existe: biblioteca y escaneo SAF, organización/identidades/publicaciones,
copias, lectores e imágenes/audio/video nativos, nueve fuentes parciales, streaming,
preparación, cola y Gofile limitado. Ese funcionamiento no prueba paridad completa.
No se dispone de una medición que justifique un porcentaje o una fecha final.

## Entregas agrupadas acordadas

| Parte | Estado y alcance |
|---|---|
| 1. Organización de archivos | Implementada en0.42 y aceptada por el usuario: renombrado/movimiento con vista previa; papelera/restauración y registro; escritura NFO con respaldo; duplicados por bytes/código y revisión de partes. Alcance y límites SAF en PARTE_1_ORGANIZACION.md. No se afirma equivalencia integral con todos los modelos del ledger original. |
| 2. Fuentes, cuentas y descargas | Implementada en0.43 y aceptada por el usuario: sesiones y login oficial opcional/importación propia por sitio; cuerpos visibles siempre parciales Patreon/SubscribeStar y FANBOX con acceso permitido; búsqueda F95/filtros/enlaces compartidos; Pixeldrain individual revisado; cola en segundo plano explícito. Límites de cuentas, contratos, servidores y HLS/DASH/DRM en PARTE_2_FUENTES.md. No se afirma una API universal para los nueve sitios. |
| 3. Formatos y lectura | Implementada en0.44 y aceptada por el usuario, con límites: ZIP64; 7z con clave/cabecera plana; RAR5 sólido diccionario64MiB; EPUB NAV/NCX y fragmentos; búsqueda de texto/PDF y contraseña PDF API35+; subtítulos Unicode/1252 e Info de pistas reales. RAR4 sólido, RAR cifrado, volúmenes/RAR7, ANSI ambiguo, ZIP cifrado, cabeceras7z comprimidas/cifradas con clave, EPUB maquetado/DRM, OCR y códecs no disponibles siguen sin soporte. No se declaran cerrados por esta entrega. |
| 4. Importación y sincronización | Implementada en 0.45 y aceptada por el usuario: paquete portable del estado/metadatos modelados, mapa de archivos por raíz/ruta/tamaño/familia, conflictos por campo con base por origen, versiones nuevas manuales en ambos sentidos, rechazo de versiones/revisiones obsoletas y recuperación exacta. Nube opcional mediante proveedor SAF disponible. No sincroniza medios, permisos, secretos, bajas por ausencia o el ledger completo; no API propia de115/PikPak/OneDrive ni ejecución automática. Límites y diferencias en PARTE_4_INTERCAMBIO.md. |
| 5. Interfaz y rendimiento | Implementada en 0.46 y aceptada por el usuario: navegación visible, filtros desplegables, temas y seis colores, fondo privado/intensidad, tarjetas y lista, movimiento configurable, volumen Media3, guardado directo a nuevo destino SAF y recuperación de incompletos, miniaturas compartidas y limpieza de caché con protección de videos en uso. Google Drive requiere proveedor instalado/autorizado; puede usar caché propia y subir después. Sin API propia, confirmación de servidor, reanudación directa ni benchmark físico. Alcance en PARTE_5_INTERFAZ.md. |
| 6. Validación y correcciones | 0.47 para prueba: RAR nativo y ZIP64 corregidos, fondos atómicos y recorte proporcionado, cierre de volumen, limpieza de segundo destino fuera de UI; diagnóstico explícito de ocho componentes e informe exportable. Falta la validación final en SM-X230, actualización real, cuentas/Drive y comportamiento físico. Se ejecutaron los 73 casos en API28/x86_64: 72 aprobados y 1 omitido(s) por API; detalle en PRUEBAS.md. |

El usuario sustituye la entrega por subbloques por una entrega agrupada de cada parte.
Las correcciones que encuentre al probar una parte se resuelven dentro de esa parte.
La estimación previa de15–20subbloques era provisional, no un conteo de entregas
pendientes. No equivale a una fecha o porcentaje final. El proyecto sigue abierto.

## Orden de trabajo

Partes 1–5 / 0.42–0.46 confirmadas. Probar parte 6 / 0.47 con GUIA_PARTE_6_047.md y
corregir sus defectos. La sexta entrega no cierra las incompatibilidades pendientes.
Respetar alcance compatible con Android
y documentar límites concretos; no introducir backend Peach, PC o Termux obligatorios.

La referencia de compatibilidad sigue fija en peach-mitao/peach
de22796c04919aaa057d77930c33c81313765569; COMPATIBILIDAD_ORIGINAL.md detalla campos/formatos
y antecedentes. PLAN_FUENTES.md conserva decisiones y aceptaciones. PRUEBAS.md distingue
pruebas ejecutadas, instrumentación solo compilada y lo que sigue sin comprobar.

El contenido lo aportan carpetas y fuentes autorizadas del usuario. El repositorio
original no trae una biblioteca de medios que se pueda meter íntegra dentro del APK.
Kemono, Coomer y SimpCity permanecen excluidos por decisión del usuario.
