# Peach 0.48.0 · Pendientes después del rediseño

La versión 0.47 fue aceptada por el usuario. 0.48 se entrega para probar el nuevo diseño.

- Validar en la Samsung SM-X230 el aspecto, tamaño de texto, orientación, controles, búsqueda, vueltas y reproducción con los archivos habituales.
- Verificar sus datos conservados al actualizar y el flujo real hacia Google Drive mediante el proveedor instalado/autorizado.
- Confirmar las vistas previas ofrecidas por cada fuente con sus sesiones y archivos reales. No se garantiza una imagen cuando el sitio no devuelve una compatible. La búsqueda mantiene las capacidades particulares de cada conector.
- Probar búsqueda/clave PDF en Android15+ y las combinaciones de códec/servidor/acceso no disponibles en el emulador.
- Corregir las incidencias que aparezcan en esta nueva entrega antes de considerarla aceptada.

Los pendientes y límites originales de la entrega 0.47 siguen vigentes; este rediseño no constituye paridad universal con Peach original. Consultar también PENDIENTES.md y la auditoría de compatibilidad histórica del proyecto.
