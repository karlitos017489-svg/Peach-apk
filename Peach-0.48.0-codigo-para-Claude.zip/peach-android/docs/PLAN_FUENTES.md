# Plan vigente de fuentes · Peach Local

Decisión del usuario: 25 de octubre de 2026, America/Hermosillo.
Base implementada: APK 0.24.0, commit bc9faaafda13b141a02166a9c4ab9fe2e2098a31.

## Decisión que sustituye el plan anterior

Kemono y Coomer quedan excluidos del plan de integración por instrucción expresa del
usuario. El usuario informa que llevan meses caídos y sin contenido nuevo; no se
presenta ese informe como una verificación propia de indisponibilidad mundial.
La propuesta anterior de incorporar Coomer como quinta fuente queda cancelada.

La siguiente fuente solicitada es **cum.st**, que se presenta como **OnlyHaven**.
No se incorpora automáticamente, como alias de Coomer o como fallback de Pawchive.
No se añadirán peticiones a Kemono/Coomer. Esas dos fuentes no están en el selector
ni en el transporte del APK 0.24.0; no hay código de conector que retirar.

## Punto de partida confirmado

El usuario confirma que 0.24.0 ya funciona después de corregir el guardado de adjuntos
Pawchive. Es aceptación funcional comunicada por el usuario, no ejecución de las
pruebas instrumentadas ni certificación individual de todos los formatos.

Continúan cuatro proveedores implementados, cada uno con el alcance documentado:
FANBOX, Patreon, SubscribeStar y Pawchive. El núcleo sigue siendo Android autónomo,
sin computadora, Termux, Windows, servidor Peach obligatorio o WebView como aplicación.

## Comprobación preliminar de cum.st

- Portada oficial consultada: https://cum.st/ . Identifica el servicio como OnlyHaven.
- Documentación oficial localizada: https://cum.st/swagger/index.html . El índice
  recuperado por búsqueda anuncia OnlyHaven API 1.0.0, OpenAPI3, acceso público de
  lectura sin autenticación y autorización para frontends alternativos.
- El mismo índice muestra rutas `/api/v1/creators`, `/api/v1/posts` y
  `/api/v1/media/lookup`. No se deducen de esos nombres sus parámetros, respuestas,
  paginación o compatibilidad con los JSON de Pawchive/Coomer.
- La herramienta web pudo recuperar la portada, pero no la documentación completa.
  La petición HTTPS directa de documentación desde este entorno recibió HTTP200,
  text/html,195 bytes, con «Site Unavailable». No se recibió un esquema OpenAPI.
  Esto es una limitación de la comprobación desde este entorno, no prueba de caída
  global. No se han solicitado publicaciones, archivos multimedia o cuentas.

La referencia original auditada (peach-mitao/peach, commit
de22796c04919aaa057d77930c33c81313765569) usa `coomer.st` en su conector compartido.
No contiene una integración OnlyHaven/cum.st verificada. Cambiar el dominio de ese
conector sin auditar el contrato no acredita compatibilidad.

## Siguiente etapa autorizada

1. Obtener y revisar el contrato oficial completo: identidades servicio/creador/post,
   parámetros y paginación, fechas, respuestas, límites, errores y servidores de medios.
2. Implementar un proveedor propio para cum.st y mantener separadas sus identidades.
   Reutilizar únicamente lógica cuyo contrato haya sido comprobado. No migrar o mezclar
   fuentes de otros sitios por tener el mismo nombre de creador o número de post.
3. Añadir consulta explícita, revisión/importación y lectura offline de los metadatos
   y cuerpos compatibles. No anunciar acceso completo por listar tarjetas.
4. Habilitar adjuntos solo después de comprobar rutas/hosts/redirecciones e integridad;
   conservar como referencias los casos aún no soportados, con un mensaje preciso.
5. Probar errores/cancelación, aislamiento entre proveedores, conservación de fichas y
   cuerpos anteriores, copias/rollback y pantalla. Compilar el APK y documentar qué
   pruebas se ejecutaron y cuáles requieren dispositivo. No pedir APK intermedio
   únicamente para comprobar este cambio de plan.

cum.st todavía no está incorporado en 0.24.0. Este documento registra la sustitución
y la auditoría preliminar; no es una entrega de un conector operativo. El proyecto
sigue abierto y no se declara paridad con Peach original.

## Actualización: implementación0.25.0

Se implementó el quinto proveedor cumst con el subconjunto de contrato auditado en
gallery-dl1.32.18. La documentación oficial completa no se recuperó. El runner de
producción sigue rechazando el formato devuelto por la API desde este entorno; por
tanto no hay validación online. No se presenta como caída global o fallo del usuario.

Lista de50/offset, detalle parcial, revisión/importación, conservación de fichas y
cuerpos, guardado SAF individual de variantes admitidas en e1.cum.st/media hasta128MiB.
No cuentas/DMs, marcadores online, galería/video remoto, nodos adicionales, lotes o
reanudación. Room13/copia15. FUENTES_CUMST.md, PRUEBAS.md y la verificación de0.25
documentan resultados exactos y limitaciones. El usuario confirmó0.24;0.25 pendiente
de aceptación. Kemono/Coomer siguen excluidos. El proyecto permanece abierto.

Verificación de la entrega0.25: APK compilado y firma original comprobada;525 pruebas
locales/83 clases aprobadas, lint0 errores/49 advertencias.25 pruebas Android compiladas,
0 ejecutadas. API/medios online siguen sin validar desde este entorno. No se transfiere
la aceptación de0.24 a la entrega nueva.

## Decisión0.26: una sola entrega para las fuentes restantes

El usuario pidió agrupar Rule34 Paheal, Rule34.xxx, Rule34Video y F95zone para probarlas
juntas. SimpCity también queda excluido, junto con Kemono y Coomer. 0.25 aceptada por
el usuario. No declarar soporte completo u online por tener los cuatro selectores.

Trabajo0.26: cuatro conectores acotados, clave propia Rule34.xxx cifrada en la tablet
y fuera de copias, revisión/importación y conservación de fuentes anteriores. Room13
intacto, copia16. Este bloque está implementado;569 pruebas locales y compilación aprobadas.
API/medios reales y27 pruebas instrumentadas siguen pendientes de validación/ejecución.


## Actualización0.27: consultas aceptadas y video descargado pendiente

26 de octubre de2026, America/Hermosillo. El usuario pudo instalar0.26 y comunica
que ya pudo consultar todas las fuentes. También comunica que los videos descargados
no se reproducen. Es aceptación de consulta informada por el usuario, no certificación
de cada códec, descarga o ejecución de pruebas Android. La reproducción sigue siendo
un defecto abierto hasta validar el caso real; todavía no se conoce su código de error.

0.27 corrige el MIME de los documentos guardados y añade apertura nativa del documento
seleccionado o recién guardado, sin requerir escaneo previo. Permite reutilizar descargas
anteriores, mantiene la importación opcional por carpeta y habilita fallback a otros
decodificadores disponibles en Android. Mejora los errores de acceso/contenedor/códec
sin exponer URLs o claves. No incorpora FFmpeg/VLC ni garantiza todos los formatos.
Kemono, Coomer y SimpCity siguen excluidos. El proyecto continúa abierto.


## Actualización0.28: BIN, GIF y archivos vacíos

26 de octubre de2026, America/Hermosillo. El usuario informa que0.27 todavía no abre
algunos videos BIN, tampoco GIF y que una descarga superior al límite deja un destino
de0 bytes. La captura recibida muestra metadatos y un nombre BIN generado, no un código
de decodificador ni los bytes originales. No se declara reparado físicamente el caso.

Se corrigió la selección de enlaces públicos MP4/WebM de Rule34Video frente al contentUrl
de JSON-LD que podía ser una referencia. Se admiten download=true y parámetros públicos
acotados en rutas/hosts de medios exactos, sin ejecutar scripts ni seguir enlaces externos.
Las referencias no resueltas ya no se presentan como un archivo BIN reproducible.

El flujo descarga y comprueba primero en privado; solo después abre el selector de
destino. Usa un límite de2GiB, comprobación de espacio, cancelación y limpieza. Reconoce
formatos por cabeceras acotadas; un GIF abre el visor de imágenes, con animación nativa
en Android28+. Si el proveedor informa longitud0 o incompleta tras copiar, no se anuncia
éxito ni se habilita reproducción y se intenta borrar solo ese destino recién creado.
No se eliminan archivos anteriores del usuario; los de0 bytes deben descargarse de nuevo.

Room13 intacto; copia17 lee1–17 y evita que aplicaciones anteriores intenten interpretar
las nuevas referencias de descarga. Credenciales excluidas. Continúan nueve fuentes;
Kemono/Coomer/SimpCity excluidos. El proyecto permanece abierto. Validación y límites
exactos en PRUEBAS.md y evidence/0.28.0; las pruebas Android requieren ejecución física.

La validación final también corrigió la propiedad del descriptor de animación y el
resultado de SAF recibido durante una recarga. Fuente de GIF desde ByteBuffer mapeado;
fallback en memoria64MiB solo para proveedores no posicionables. Ver informe actual.


## Actualización0.29: redirección de servidor de medios

26 de octubre de2026, America/Hermosillo. El usuario comunica que0.28 muestra
«Dirección de adjunto no admitida» al intentar guardar en Rule34Video. El APK adjunto
coincide con la entrega original por SHA-256. La captura no muestra la URL de destino
ni un error de reproducción. No se da por aceptada0.28 en descargas de esa fuente.

Se reprodujo el mismo error con el SourceHttp original0.28 sin modificar, compilado
en un JVM separado y con una respuesta302 simulada a un CDN de prueba. No hubo
peticiones a archivos del usuario. El menú admite el enlace inicial, pero el transporte
anterior exige que el destino también cumpla esa gramática inicial y lo rechaza.

0.29 mantiene esa gramática para configurar/guardar enlaces. Solo una descarga que ya
parte de un archivo Rule34Video admitido puede seguir hasta3 saltos HTTPS de entrega
a un destino público, comprobando su resolución DNS y conservando TLS normal. Los
destinos resueltos son transitorios; no se convierten en fuentes ni se guardan en Room
o copias. No se relajan las rutas API/Pawchive/cum.st/otras familias ni se transfieren
claves/cookies. Se exige una cabecera de medio reconocible antes de guardar ese video.
Errores del servidor informan host/estado sin mostrar URL firmada o sus parámetros.

Room13/copia17 intactos. Se conservan GIF, preparación privada/SAF y2GiB de0.28.
El proyecto sigue abierto y el archivo/servidor real todavía requiere confirmación
en la SM-X230. La reproducción de HTTP en pruebas es simulada, no validación online.


## Confirmación0.29 y siguiente bloque0.30

26 de octubre de2026, America/Hermosillo. El usuario respondió «Listo ya funciono»
a la entrega0.29 y autorizó continuar. Se acepta el caso previo de redirección en su
tablet según su informe; no se convierte en ejecución propia de instrumentación o
prueba exhaustiva de todos los códecs/CDNs.

0.30 amplía la galería a imágenes compatibles ya importadas de FANBOX, Pawchive, cum.st,
Rule34 Paheal, Rule34.xxx y F95zone. Conserva las rutas iniciales y separa proveedores.
Pawchive conserva su hash esperado al consultar y abrir caché; referencias antiguas
con bandera falsa se reevalúan sin modificar el cuerpo. GIF/WebP se animan en API28+
con pausa/reanudación y rotación; API26/27 muestran fotograma estático. Caché privada
16MiB/imagen,64MiB/128 imágenes, solo selección explícita, modo sin conexión.

Nueve proveedores de metadatos no significan nueve proveedores de imágenes: Patreon y
SubscribeStar siguen como tarjetas públicas, y Rule34Video conserva sus descargas/video
local sin añadir transporte de imágenes. Room13/copia17 sin cambios; se mantienen
excluidos Kemono/Coomer/SimpCity. Galería avanzada, video remoto, Gofile/masked,
lotes/reanudación, cuerpos/cuentas pendientes y resto de compatibilidad permanecen
abiertos. La validación propia de0.30 usa datos/medios propios y HTTP simulada; ver
PRUEBAS.md para resultados exactos. Aceptación física nueva todavía pendiente.


## Confirmación0.30 y bloque0.31: videos desde publicaciones

26 de octubre de2026, America/Hermosillo. El usuario confirmó «Si funciono todo» para
0.30. Después pidió trabajar bloque por bloque, autorizando el siguiente bloque de
videos desde publicaciones. Es aceptación general informada, sin inferir prueba
individual de cada fuente/códec o ejecución propia de instrumentación.

0.31 permite elegir un video compatible importado, preparar y verificar su copia
privada completa y abrir el reproductor nativo sin selector de carpeta. No hay
streaming mientras descarga. Se reutiliza SourceHttp y sus contratos/redirecciones;
Pawchive conserva el hash esperado. El reproductor recibe solo publicación/clave,
resuelve Room y verifica una copia offline; Media3 nunca recibe esa URL remota.

Caché completa2GiB/8 archivos, límite reducido por archivos abiertos y preparaciones.
La limpieza de la app respeta las copias en uso, retenidas al rotar por ViewModel.
Modo Sin conexión; sin precarga/consulta automática; cancelación al salir de la
preparación. Caché descartable por Android, fuera de JSON. Guardar adjunto permanece
para conservar originales; no se borran archivos del usuario. Room13/copia17 intactos.

Pruebas con MP4 propio y HTTP/DNS simulados; las pruebas instrumentadas requieren
Android conectado. PRUEBAS.md registra resultados y fallos intermedios de fixtures.
Esta versión nueva todavía no tiene aceptación física. El siguiente bloque será
cola/progreso/lotes y reanudación de descargas; aún no se implementa. Siguen pendientes
streaming progresivo, Gofile/masked, cuentas/cuerpos adicionales, interfaz, formatos,
sincronización y validación completa. Kemono/Coomer/SimpCity siguen excluidos.


## Confirmación0.31 y bloque0.32: cola de descargas

27 de octubre de2026, America/Hermosillo. El usuario confirmó «Todo correcto, sigue con
siguiente bloque» para0.31. Se mantiene el trabajo bloque por bloque, sin pedir APKs
intermedios de cada prueba. Es aceptación informada, no ejecución propia en la tablet.

0.32 implementa cola operativa de128 adjuntos importados, progreso real, pausa por fila
o global, reintento explícito y recuperación de fragmentos. Reanuda solo con evidencia
compatible del servidor (ETag fuerte/If-Range/destino o SHA inmutable Pawchive); ante
cambio/no confirmación reinicia. Hasta2GiB/archivo,4GiB de copias privadas, una transferencia.
Abrir/restaurar no hace red; salir pausa, rotar conserva trabajo. Sin promesa de segundo
plano. Guardar completas copia un lote a una carpeta SAF sin redescargar. Visor/reproductor
nativos para completas; retirada privada no borra originales ya exportados.

Estado operativo fuera de Room13/JSON17, en noBackupFilesDir. No entra en la copia
personal ni sobrevive a borrar datos/desinstalar. Sin permisos/dependencias/servicios
nuevos; proveedor interno privado de solo lectura y sin cesión de permisos URI. Mantiene
las nueve fuentes, rutas y credenciales anteriores. Kemono/Coomer/SimpCity excluidos.

Evidencia con archivos propios y HTTP/DNS simulados en PRUEBAS.md/evidence/0.32.0.
Aceptación física de0.32 pendiente. El siguiente bloque previsto audita enlaces externos,
empezando por Gofile, antes de implementar solo el contrato compatible y verificable.
Streaming progresivo, cuentas/cuerpos, interfaz, formatos, sincronización y la paridad
restante permanecen abiertos. No se declara terminado Peach por entregar esta cola.


## Confirmación0.32 y prioridad0.33: Ver en línea

27 de octubre de2026, America/Hermosillo. El usuario confirmó que0.32 funcionó y pidió
continuar. También preguntó por ver archivos como YouTube sin tener que descargarlos
completos. Se explicó consumo de internet/búfer temporal y se comunicó la prioridad de
reproducción progresiva antes del bloque de enlaces externos. No se presupone validación
física propia o compatibilidad con todos los servidores por aceptar0.32.

0.33 añade Ver en línea a videos compatibles importados. Reproductor Media3 nativo,
transporte HTTPS de proveedor anterior, ID/clave opacos, búfer en RAM y sin archivo de
video en disco o selector de carpeta. Salir detiene conexión; rotar conserva posición/
pausa pero puede pedir datos otra vez. Hasta16GiB de recurso, objetivo32MiB de búfer,
no cuota total de RAM. Solo saltos confirmados por servidor/formato. Sin calidad
adaptativa/HLS/DASH/transcodificación, cuentas o nuevos hosts.

Streaming no verifica SHA completo antes de mostrar, incluido Pawchive. Preparación
completa/cola/guardar mantienen sus verificaciones, límites y copia offline. No se
inventan fichas/visitas de catálogo. Manifiesto/permisos/dependencias/Room13/JSON17
intactos. Pruebas propias con MP4 y HTTPS/DNS simulados, extractor real; ejecución
Android física pendiente. Resultado exacto y fallos corregidos en PRUEBAS.md.

Aceptación de0.33 pendiente. Siguiente auditoría prevista: Gofile y enlaces externos/
masked, solo implementar contratos compatibles verificables. Se conservan nueve fuentes
y las exclusiones Kemono/Coomer/SimpCity. El resto de cuerpos/cuentas, interfaz, formatos,
sincronización y compatibilidad integral sigue abierto; no se declara terminado Peach.


## Incidencia0.33 y corrección0.34 antes de Gofile

27 de octubre de2026, America/Hermosillo. El usuario envió captura de Ver en línea con
mensaje de acceso y código ERROR_CODE_IO_UNSPECIFIED2000. No se da por aceptada0.33.
No se deduce de la captura HTTP403, necesidad de cuenta o proveedor concreto.

Se identificó y reprodujo el mismo mensaje con StreamDataSource0.33 sin modificar:
Media3 añade Icy-MetaData:1 a su DataSpec y la app rechazaba todas las cabeceras antes
de la red.0.34 consume esa indicación interna sin transmitirla, conservando los demás
rechazos de URI/método/cuerpo/offset/cabeceras. REQUEST local se distingue de ACCESS
HTTP real y se muestra el estado saneado, sin URLs/credenciales. No añade hosts,
cookies, cuentas, permisos o dependencias. La regresión usa el cargador y SampleStream
reales con video propio y HTTPS simulado. Pruebas y fallos conservados en PRUEBAS.md.

0.32 permanece como última aceptación del usuario.0.34 requiere probar el mismo video;
no se presume acceso al CDN real ni reproducción física desde este entorno. Se prioriza
cerrar este defecto antes de Gofile/masked. Nueve fuentes y exclusiones Kemono/Coomer/
SimpCity conservadas. La finalidad sigue siendo APK Android autónomo con capacidades
originales compatibles; cuentas/cuerpos, interfaz, formatos, sincronización y demás
paridad permanecen abiertas. No se declara terminado Peach.


## Confirmación0.34 y bloque0.35: calidad y vistas previas

28 de octubre de2026 UTC. El usuario confirmó funcionamiento de0.34 y señaló demoras,
baja calidad o previews. Su aclaración abarca varios: Rule34Video, cum.st y otro Rule34;
no volver a preguntarle qué fuente ni asumir que solo ocurre en una.

0.35 distingue previews conocidas, muestra altura/tamaño declarados, conserva alternativas
cum.st, preselecciona mayor altura reconocida dentro del primer grupo no preview y permite
selección manual. Consultar versiones recupera un detalle individual existente de
Rule34Video/Paheal/cum.st sin medios y exige revisión/Usar versiones antes de escribir.
Conserva ficha/notas/archivos, pausa/429, cancelación, revisión obsoleta y cuerpo previo ante
resultado vacío o downgrade a previews. Rule34.xxx mantiene file_url, no sample/preview.

Rule34Video reutiliza en RAM un destino admitido durante la sesión, con nueva validación
HTTPS/DNS y representación en cada rango.403/404/410 permiten un retorno al origen;
429 no. Destino nunca persistido. Buffering y dimensiones comunicadas por Media3 visibles.
No prometer HD si la fuente no ofrece otro archivo ni una latencia real medida.

Room13/JSON17, límites/permisos/manifest/dependencias/firma se conservan. Campos opcionales
de variante dentro del JSON de adjuntos; roundtrip probado.765 pruebas JVM/116 clases
aprobadas,0 fallos/errores/omitidas;44 Android compiladas,0 ejecutadas. PRUEBAS.md y evidence
registran resultados reales con fixtures propios/HTTPS simulado, no medios del usuario.
0.35 pendiente de aceptación física; guía mínima, no repetir nueve fuentes.

Siguiente bloque previsto: auditoría Gofile/enlaces externos/masked, implementando solo
contratos compatibles verificables. Nueve fuentes y exclusiones Kemono/Coomer/SimpCity
conservadas. Cuentas/cuerpos, interfaz, formatos y sincronización/paridad siguen abiertas.


## Confirmación0.35 y bloque0.36: Gofile y enlaces externos

28 de octubre de2026, America/Hermosillo. El usuario confirmó «Si todo funciona, sigue
con lo demás» para0.35. No volver a preguntar por fuentes/calidad aceptadas. Se conserva
la modalidad bloque por bloque, pruebas automáticas y una entrega APK completa por bloque.

Se auditó follow_gofile.py/tests/snapshots del commit original fijo y módulos oficiales
actuales Gofile. Gofile es recurso externo, no décima fuente. La API documentada de
listado requiere token propio/Premium; no se inventa acceso anónimo. Una consulta sin
clave a UUID ficticio devolvió401/error-token, sin cuenta creada o medios descargados.

0.36: contenido guardado → Enlaces Gofile → clave propia cifrada opcional → consulta de
una página → revisión → incorporar archivos. Abrir no consulta, consultar/incorporar no
descarga medios. Subcarpetas/páginas explícitas, no recursión automática. Transporte
separado Bearer al API exacto, nunca archivos/otra fuente; sin redirecciones API, invitados,
firmas web o cookies externas. Error Premium/token/acceso/404 y espera429 persistida,
incluso ante cuerpo ilegible y tras cambiar/borrar clave. Offline/pausa/cancelación.

Aplicación aditiva transaccional valida identidad/cuerpo/clave vigentes, máximo100,
resultado no vacío. Conserva ficha, notas, cuerpo, adjuntos previos, archivos e historial.
Actualizar cuerpo/Consultar versiones mantiene Gofile sin ocultar downgrade nativo.
Archivos store*.gofile.io/download, ID coherente, HTTPS/DNS público, sin query/credenciales/
traversal o redirect a otro archivo/host. Galería, video, streaming, preparación, guardar
y cola existentes; no clave al CDN ni garantía de códec/duración/HD real.

Room13 y dependencias iguales. CopiaJSON18 lee1–18, valida nuevas referencias;0.35 no
lee18. Token cifrado en noBackup, separado de Rule34.xxx, sin plaintext fallback. Nueva
actividad no exportada, sin nuevo permiso/servicio/proveedor. Firma original conservada.
800 JVM/120 clases sin fallos/errores/omitidas;46 Android compiladas,0 ejecutadas. Pruebas
con datos propios/HTTPS/DNS simulado; falta cuenta autorizada/CDN real/Android físico.
Resultados y fallos intermedios en PRUEBAS.md/evidence0.36; guía mínima sin repetir9fuentes.
0.36 todavía requiere aceptación del usuario; no se afirma ejecución física desde aquí.

Se mantienen nueve conectores y exclusiones Kemono/Coomer/SimpCity. Pendientes: F95
sesión/masked/contraseñas, otros servicios/enlaces firmados o con cookies, cuerpos/cuentas,
interfaz, formatos, sincronización y demás paridad original. No declarar terminado Peach.


## Confirmación0.36 y bloque0.37: sesión F95 y masked

28 de octubre de2026, America/Hermosillo. Usuario confirmó «Listo funciona» para0.36 y
pidió el siguiente bloque/preguntó cuánto falta. Se explicó que no hay porcentaje o fecha
fiables: seis frentes grandes, cada uno puede requerir varios bloques. PENDIENTES.md los
ordena: fuentes/accesos/metadatos, formatos, organización, sincronización/servicios,
interfaz/rendimiento y validación. No es un solo bloque para terminar toda la paridad.

0.37 adapta el protocolo F95ZoneConnector fijado y su snapshot. Configuración avanzada
opcional de Cookie propia ya disponible, cifrada AES-GCM/AndroidKeyStore/AtomicFile aparte,
noBackup, sin texto plano. Sin extracción de Chrome, contraseña, login nativo o CAPTCHA.
Cookie solo a f95zone.to en hilos admitidos/POST masked exacto; nunca Gofile/archivos/otras
fuentes. GET puede seguir solo mismo hilo, POST no redirects. Cambio/borrado conserva caché
pero invalida planes/ETag/LastModified/fecha; espera vigente se conserva.

Enlaces F95 desde una publicación importada: abrir sin red, un enlace seleccionado,
resolver con sesión propia, revisar e incorporar aditivamente. Sin consulta del destino,
medios, fichas/historial ficticios o reemplazo de datos personales. Gofile carpeta conserva
su clave independiente; Pixeldrain referencia; adjunto directo F95 de ruta anterior puede
usar medios/guardar/cola nativos. Máximo100, cancelación/offline/pausa/cambio de cuerpo o
sesión, duplicados y429 global F95 persistido protegidos. Clasificación video/img-src F95
corregida. Reimportar origen conserva destinos resueltos y Gofile anterior.

832 pruebas JVM/124 clases aprobadas,0 fallos/errores/omitidas;48 Android compiladas,
0 ejecutadas.32 JVM y2 Android nuevas, datos propios/HTTPS/DNS simulados. Actual script
masked.js respondió HTTP200/195 bytes HTML Site Unavailable, no el JS. No cuenta/sesión/
POST masked real o medios upstream probados. PRUEBAS.md detalla validación y límites.
Room13/JSON18 lee1–18 y rutas descargables/dependencias/permisos/servicios/proveedores
anteriores conservados; una actividad no exportada. Firma original; no servidor Peach.
0.37 todavía requiere aceptación del usuario; no convertir tests simulados en prueba física.

Nueve fuentes y exclusiones Kemono/Coomer/SimpCity siguen. Falta cerrar los seis frentes,
incluido inicio de sesión nativo/contratos vivos actuales y otras fuentes/cuerpos. Tras
este recorrido, siguiente prioridad prevista evaluar RAR/CBR bajo Android, licencia y
memoria antes de implementarlo. No se declara terminado Peach ni se exige contratar
servicios o compartir credenciales para validar una actualización.


## Confirmación0.37 y bloque0.38: lectura RAR/CBR parcial

28 de octubre de2026, America/Hermosillo. El usuario confirmó «Listo funciona» para0.37
y autorizó siguiente bloque. Después preguntó dónde obtener la Cookie; se explicó que
procede de sesión propia y que el login nativo aún no existe. No pedir cookies/capturas
por chat ni exigir una computadora o importar sesión para probar este bloque de lectura.

0.38 añade RarBook propio: cabeceras RAR4/RAR5 y método almacenar, **sin descompresión
RAR completa**. Índice natural/búsqueda, imágenes/texto/PDF, posición y controles del
lector anterior. Entradas comprimidas/cifradas/links/sin CRC/extras desconocidos solo en
índice con explicación. Sólidos/volúmenes/SFX/cabeceras cifradas/Unicode heredado no
portable y daños se rechazan.512MiB fuente/total declarado,64MiB entrada,10.000 cabeceras/
8MiB total/2MiB cabecera RAR5. CRC índice y selección, nombres nunca son rutas de salida,
cache privada/cancelación/parciales. No red, bibliotecas nativas o dependencia añadida.

Auditoría Junrar8.1.2 sí anuncia RAR hasta7 (no RAR4 solamente), pero licencia UnRAR con
restricción: no incorporada en esta adaptación AGPL. libarchive3.8.2 BSD preferida para
evaluar descompresión posterior con NDK, diccionarios/memoria/cancelación/aislamiento/
pruebas Android pendientes. No prometer todoRAR/CBR. Fuentes primarias y huellas en
evidence0.38; fixtures propios se cruzaron byte a byte con libarchive3.7.4 del host.

Room13/copia18 lee1–18, manifest/permisos/componentes/dependencias/assets/nativos y
funciones anteriores conservados. Validación real y límites en PRUEBAS.md/JSON; las
pruebas Android compiladas no significan ejecución en SM-X230. Firma original, instalar
sobre0.37 sin desinstalar.0.38 pendiente de aceptación propia; proyecto ABIERTO.

Siguiente prioridad prevista: descompresión RAR con libarchive o su etapa técnica
necesaria si la auditoría requiere subdividir. Siguen seis frentes PENDIENTES.md, varios
bloques posibles, sin porcentaje/fecha fiables. Login F95 y fuentes/cuerpos completos
siguen pendientes. Nueve fuentes; Kemono/Coomer/SimpCity excluidos.

Validación final0.38: 860 JVM/127 clases aprobadas,
0fallos/errores/omitidas;28 nuevas. Lint0errores/55 avisos, sin nuevas
supresiones.50Android compiladas/0ejecutadas. Primera dirigida27/27; primer full859
con2expectativas antiguas RAR-nolector fallidas, actualizadas manteniendo control ARJ
sinlector y añadiendo ruteoCBR; full final860/860. Firma original/v2/16KiB, clases
Peach325→331/0eliminadas, runtimegraph356 y assets/nativos previos idénticos. Evidencia
completa en PRUEBAS.md/JSON/XML/logs. No cuenta/sesión/media upstream o dispositivo real.


## Confirmación0.38 y bloque0.39: descompresión RAR/CBR compatible

28 de octubre de2026, America/Hermosillo. Usuario confirmó que consiguió descargar0.38
y todo funciona; autorizó siguiente bloque. Se entregará APK más ZIP pequeño con el
mismoAPK para descarga y paquete completo de fuente/pruebas. No volver a exigir PC o
cookies; no repetir las nueve fuentes. Los anteriores fallos de descarga mostraban
error en ChatGPT; VPN era una posibilidad, no una causa confirmada.

libarchive3.8.10 estable fijada, BSD/per-file/BLAKE2CC0, fuente completa9.3MB y avisos en
APK. NDKr30/API26, cuatroABIs/ELF16KiB, solo libc/libm/libdl. RAR4 métodos31–35 y RAR5
algoritmo0/métodos1–5/diccionario<=64MiB, en RarService no exportado/proceso aislado.
Lectura almacenar Java anterior sigue. RarBook indexa/revalida; IPC AIDL por FD fuente
sololectura/salida soloescritura, ID/nombre acotado/tamaño/CRC. Sin rutas/URLs/sesión/DB.
UID llamante verificado, solo una operación. CRC/tamaño nativos y otra vez Java antes de
publicar caché entry; error/cancelación conserva original/vista/progreso, borra parcial.
Cuota malloc160MiB/asignación64MiB, no RAM total; RLIMIT_FSIZE64MiB. Watchdog90s pide
terminar proceso propio, controles nativos85s y bind10s; no tiempo absoluto prometido
ante bloqueos de sistema/JNI/Binder. Rotación/destrucción cancela sesión anterior.

RAR7 comprimido, sólidos, volúmenes/SFX, contraseñas, Unicode comprimido heredado RAR4/
ANSI ambiguo y extras sinCRC siguen pendientes. No afirmar soporte universalRAR/CBR.
Motor real JNI Linux produjo exactamente texto/2PNG/BMP de6archivos propios RAR4/RAR5
creados con RAR oficial1/3/5;24selecciones, casos de cuota/CRC/daños/relecturas. RAR trial
solo herramienta externa, jamás APK/proyecto. BinariosAndroid sin helpers de rutas test.

881JVM/131clases aprobadas,0fallos/errores/omitidas;21nuevas en4clases.52Android
compiladas/0ejecutadas,2nuevas para servicio real/medios propios. No adb/KVM, ABI Android/
Binderreal/cuenta/CDN/medio privado no ejecutados. Lint0errores/56avisos, sin nuevas
supresiones. Compilaciones intermedias y45/1,49/1 dirigidas documentadas/corregidas en
PRUEBAS.md sin eliminar controles: lifecycle ServiceController, fixture cuota pequeña
y PNG que sí estaba comprimido. Full881/881; licenciaassets ampliada después y nuevo
ensamblado/lint aprobado. Firma original/v2/alineaciónAPK16KiB.

Room13/esquemas/BackupStore/copia18 lee1–18 y runtimegraph356 conservados. Manifest solo
nuevo servicio no exportado/aislado; permisos iguales. Avisos ampliados/nueva licencia
y4.so añadidos; clasesPeach331→342,0eliminadas. Nunca regenerar firma o incluirkey.
0.39 requiere aceptación propia. Nueve fuentes, Kemono/Coomer/SimpCity excluidos. Login
F95 nativo sigue pendiente. Proyecto ABIERTO, seis frentes grandes/sinporcentaje o fecha
fiables. Próxima prioridad: cerrar compatibilidadRAR restante segúnviabilidad, validar
Android y continuar los frentes pendientes.


## Confirmación0.39 y bloque0.40: nombres Unicode RAR4

28 de octubre de2026, America/Hermosillo. El usuario confirmó que descargó0.39,
la probó y todo funciona; pidió continuar. Aceptación informada, no ejecución propia
de instrumentación ni validación exhaustiva de todo RAR.

0.40 admite nombres Unicode heredados RAR4 para entradas almacenadas/comprimidas
ya compatibles. Cuatro instrucciones, UTF-16 válido/UTF-8 exacto hasta4096bytes;
sin adivinar ANSI. Índice y motor seleccionan el mismo nombre. Rutas/duplicados después
de decodificar, revalidación, CRC/límites y conservación de original/vista previos.
No se amplían métodos de datos: sólidos, volúmenes/SFX, contraseñas, ANSI ambiguo,
RAR7 comprimido y variantes/extras sin CRC siguen pendientes. No soporte universal.

906 JVM/134 clases,0fallos/errores/omitidas;25nuevas. Dirigida74/74.
54 Android compiladas/0ejecutadas,2nuevas. JNI Linux real,
4muestras propias,bytes comprobados también por RAR oficial; emoji del lector oficial
por comodín, exactitud del nombre comprobada por JNI.5000campos cortos de prueba.
Lint0errores/67avisos. Fallos intermedios de caché/API de tests corregidos
y documentados, sin quitar controles/supresiones nuevas. Sin Android físico/cuentas/CDN.

Firma original/v2/zipalign16KiB, APK40/0.40.0. Room13/copia18/esquemas/manifiesto/
permisos/runtimegraph356 y assets/4.so idénticos a0.39;
motor/servicio/IPC sin cambios. ClasesPeach342→343,0eliminadas.
Entregar APK+ZIPpequeño idéntico y proyecto/pruebas; nunca incluir clave.
0.40 pendiente de comprobación propia del usuario. Nueve fuentes, exclusiones y seis
frentes se mantienen. Próximo: evaluar sólidos con límites y validar Android real,
después continuar frentes. Proyecto ABIERTO, sin porcentaje o fecha inventados.


## Confirmación0.40 y bloque0.41: RAR5 sólido acotado

28 de octubre de2026, America/Hermosillo. Usuario confirmó0.40 y autorizó continuar;
preguntó cuánto falta. Se explicó: seis áreas grandes, no seis APK ni un porcentaje/
fecha fiables. Aceptación general informada, no instrumentación propia ejecutada.

0.41 admite subconjunto RAR5 sólido por motor/servicio previo: algoritmo0/métodos1–5,
entradas regulares comprimidas no vacías1byte–64MiB, mismo diccionario<=16MiB, primer
archivo independiente y total declarado<=128MiB. Rechaza archivo si contiene miembro
regular incompatible o bloque de servicio. RAR4 sólido, otras variantes RAR5 sólido,
vacíos/almacenar, contraseñas, volúmenes/SFX, ANSI ambiguo/RAR7 comprimido pendientes.
Rutas/duplicados/cabeceras/índice revalidados, condición sólida incluida en el índice.

Para seleccionar procesa desde inicio, reconstruye diccionario y descarta anteriores.
CRC/tamaño solo de selección, C y Java antes de publicar. NO CRC del contenido de
predecesores; NO certificación de todo RAR.128MiB es tamaño declarado, no contador
de todos los bytes internos. Mismos controles nativos/cancelación/watchdog:160MiB/
64MiB,callback85s/watchdog90s/bind10s, sin promesa absoluta ante bloqueo de sistema.
Original/vista anterior conservados, parcial eliminado. Sin nuevo C/IPC/servicio/binarios.

930JVM/136clases,0fallos/errores/omitidas;24nuevas (Solid16,Native6,
Reader2). JNI Linux real,3muestras propias RAR oficial1/3/5,12selecciones comprobadas
también por herramienta oficial;24selecciones JNI en dos órdenes,15relecturas mixtas,
cuota/CRC/daños/cancelación. Dirigida95/95;full929/929 antes del control de servicios;
full final930/930. Sin retirar controles. Lint0errores/70avisos.
56Android compiladas/0ejecutadas,2nuevas. Sin dispositivo/
cuentas/CDN/privados. Resultados y limitaciones en PRUEBAS/LECTURA_RAR_SOLIDO.

Firmaoriginal/v2/zipalign16KiB, APK41/0.41.0. Room13/esquemas/copia18/BackupStore/
manifiesto/permisos/runtimegraph356/assets/4.so iguales a0.40.
ClasesPeach343→343,0eliminadas. Entregar APK+ZIP idéntico y
proyecto/pruebas; nunca clave.0.41 pendiente de comprobación del usuario. Nuevefuentes,
exclusiones y seisfrentes vigentes. Siguiente prioridad: organizaciónSAF, vista previa/
renombrado/movimiento/recuperación; variantesRARrestantes documentadas. No cambios
automáticos en archivos del usuario. Proyecto ABIERTO, sin porcentaje/fecha inventados.


## Entrega agrupada 0.42: parte 1 de 6, organización de archivos

28 de octubre de 2026, America/Hermosillo. Usuario solicita terminar cada parte
completa y entregar APK para probar: parte1 organización; parte2 fuentes/cuentas/
descargas; parte3 formatos/lectores; parte4 importación/exportación/sincronización;
parte5 interfaz/rendimiento; parte6 validación Android/correcciones. La cifra previa
15–20 subbloques no define entregas. Última aceptación física explícita0.40;
0.41 no se presume aceptada,0.42 pendiente de comprobación.

0.42 agrupa vista previa/Aplicar, renombrar/mover SAF nativo mismo proveedor,
papelera/deshacer/journal/reconciliación, escritura NFO con respaldo/merge/recuperación,
revisión SHA256 y códigoNFO, grupos y listas de partes entre carpetas. Mantiene ID y
estado individual. Sin borrado definitivo de medios, auxsidecars automáticos,
movimientos entre proveedores ni fusión canónica de identidades. Operación física
solo mediante acción explícita en app. Límites/recuperación en PARTE_1_ORGANIZACION.

966JVM/139clases,0fallos/errores/omitidas;36nuevas. Primera completa963/1fallo por
índice de menú alterado: corregida producción, pruebas anteriores intactas;3casos
extras de recuperación y dirigida44/44, completa final966/966. Lint0errores/70avisos
sin incremento.58Android compiladas/0ejecutadas;2nuevas proveedor/ContentResolver y
XML cuando se ejecuten, no autorización persistente real. Sin dispositivo/cuentas/
CDNs/medios privados ni operaciones sobre archivos personales desde este entorno.

Firma original/v2/zipalign16KiB, versión42/0.42.0. Room13/esquemas/LibraryDatabase/
BackupStore/copia18lee1–18/permisos/runtimegraph356/assets/4.so conservados.
Una actividad interna adicional,0clases previas eliminadas (343→357).
Entregar APK, ZIP pequeño APK idéntico, proyecto/pruebas/guía. Nunca incluir clave.
Tras prueba de parte1 y correcciones necesarias, seguir parte2. Proyecto ABIERTO.


## Confirmación parte1/0.42 y entrega agrupada parte2/0.43

28 de octubre de2026, America/Hermosillo. Usuario: «Si todo bien, sigue con la siguiente
parte». Se registra aceptación general0.42 informada; no instrumentación propia ni
comprobación particular de cada archivo. Se continúa parte2 agrupada, sin APKs intermedios.

Cuentas/sesiones por sitio cifradas AES-GCM/AAD, loginoficial opcional limitado al acceso
WebView sin puentes o importación propia. No contraseñas interceptadas ni cookies de
otras apps. Cuerpos visibles parciales Patreon/SubscribeStar con identidad/revisión,
FANBOX solo acceso devuelto permitido, medios nativos; sin APIs privadas o bypass.
CSRF/nueva búsqueda F95 por título, compartir/revisar enlaces y filtros locales.
Pixeldrainindividual desde publicación, metadata/revisión/añadir y SHA esperado en
completas/cola/cachés; no listas, otrosdominios o CAPTCHA. Cola foregrounddataSync
explícita, dueño único/notificación/pausa/timeout/noSticky/noboot, límites Android/batería.

1020JVM/145clases,0fallos/errores/omitidas;54nuevas. Dirigida50/50;
primera full1019/4 expectativasanteriores actualizadas por nueva función/backup19,
full1019/0; reinicio de entorno y recuperación; livecheck identificó selector autor
star_link en post individual, corregido sin relajar identidad y prueba adicional;
final1020/1020. Lint0errores/87avisos sin nuevas supresiones.
60Android compiladas/0ejecutadas,2nuevas propias. No sesiones
privadas, dispositivo, medios upstream, instalación o segundo plano físico probados.
PublicSmoke solo metadataeducativa, resultado exacto conservado; no atribuir un fallo
a caída global/VPNsin evidencia. Sin cuerpos reales en entregables.

Firmaoriginal/v2/16KiB,43/0.43.0,min26target36; Room13/esquemas/LibraryDatabase/parte1,
deps/grafo356/assets/4.so iguales a0.42. Copia19lee1–19, secretos/medios/cola excluidos.
Nueva aplicación inicializadora sin red, serviciointernodataSync,4actividades (solo
compartirtext/plain exportada, propuesta sin red), permisos notificaciones/dataSync.
Límites de cuentas/historial/DOM/servidores/HLS/DASH/DRM detallados en PARTE_2_FUENTES.
No paridad universal. EntregarAPK+ZIPidéntico+fuente/pruebas/guía. No incluir clave.
0.43 pendiente de prueba; trascorregirdefectos seguirparte3formatos,4sync,5UI,6validación.


## Confirmación parte2/0.43 y entrega agrupada parte3/0.44

29 de octubre de2026, America/Hermosillo. Usuario: «Todo funciona, sigue con el
siguiente bloque». Se registra aceptación general de0.43 informada, no ejecución
propia de pruebas físicas ni validación individual de cuentas/códecs. Se sigue parte3
en una entrega. ZIP64 acotado, clave7z cabecera plana/KDF limitado, RAR5 sólido
hasta64MiBdiccionario, EPUB NAV/NCX/fragmentos y fuentesofuscadas omitidas, PDF búsqueda/
contraseñaAPI35+, texto visible y subtítulos Unicode/1252, Info de pistas reales.
RAR4 sólido/RAR cifrado/volúmenes/RAR7/ANSI ambiguo, ZIP cifrado, 7z header codificado
con clave, EPUB maquetado/DRM, OCR y códecs indisponibles no se anuncian como soporte.
PARTE_3_FORMATOS/GUIA_PARTE_3_044/PRUEBAS registran límites y evidencia. Room13/copia19,
nuevefuentes/organización/cuentas/transporte, permisos/dependencias/assets/nativos y
firmaoriginal conservados.0.44 requiere prueba en tablet. Tras correcciones/aceptación,
seguir partes4importación/sync,5interfaz/rendimiento,6validación/correcciones. No volver
a APK por microfunción, no servidor/PC/Termux obligatorio. Kemono/Coomer/SimpCity excluidos.


## Confirmación parte3/0.44 y entrega agrupada parte4/0.45

29 de octubre de2026, America/Hermosillo. Usuario: «Todo funciona, sigue con el siguiente
bloque». Aceptación general de0.44 informada; no ejecución propia de pruebas físicas o
validación particular de todo formato. Se continúa parte4 agrupada con APK para probar.

Intercambio portable de estado19/metadatos/NFO/addedAt con IDs opacos, mapa explícito
raíces/ruta/tamaño/familia y revisión3way por campo, bases privadas por origen,
secuencias monótonas y rechazo de versiones antiguas/forks o revisión/base/inventario
cambiados. Datos no vinculados conservados en el paquete; protección de listas/vínculos;
sin borrado por ausencia, sin sumar contadores. Validación Room separada/transacción,
recuperación exacta privada y reporte de fallo después delcommit si no se guardó la base.
Nuevo archivo por exportación SAF, relectura/verificación/limpieza de solo destino nuevo;
nube opcional vía proveedor instalado/autorizado, no servicio/API cloud simulado.
No medios, permisos, cuentas/claves/cookies, colas, papelera o ajustes transferidos.
No sincronización automática/agenda, no servidor/PC/Termux, no ledgeroriginal entero.
NFO/lectores/source/transporte/organización/Room13/copia19/permisos/deps/assets/nativos/
firma originales conservados. Solo actividad interna nueva y menú. Proveedor de fixtures
soloAPKdetest. PARTE_4_INTERCAMBIO/GUIA_PARTE_4_045/PRUEBAS detallan alcance y evidencia.
0.45 requiere prueba de tablet; tras corregir/confirmar seguir5UI/rendimiento y6validación.
Nueve fuentes y exclusiones Kemono/Coomer/SimpCity siguen vigentes. Proyecto abierto.


## Confirmación parte 4 / 0.45 y autorización de parte 5 / 0.46

29 de octubre de 2026, America/Hermosillo. El usuario confirma «Todo funciona» para
0.45 y autoriza continuar. Pide guardar medios de las fuentes directamente en Google
Drive, interfaz minimalista para el consumidor promedio, fondos, colores, animaciones
y botón de volumen. Se trabaja parte 5 agrupada; no se considera entregada o aceptada.

0.46 entrega parte 5 para prueba: navegación Biblioteca/Fuentes/Descargas/Ajustes y
filtros desplegables, temas/colores/fondo/tarjetas/movimiento, volumen Media3 y transferencia
directa al nuevo destino SAF sin archivo completo de medios en Peach. Proveedor de nube
instalado/autorizado, sin API Google propia ni confirmación de servidor remoto; el
proveedor puede usar espacio temporal o subir después. Hasta 2 GiB, una transferencia,
cancelación al salir, retención al rotar y revisión de nuevos destinos incompletos sin
reiniciar red al abrir. Preparación tradicional y cola conservadas. Miniaturas acotadas
y compartidas, limpieza explícita con protección de videos en uso/preparándose y cola.
PARTE_5_INTERFAZ y GUIA_PARTE_5_046 detallan alcance. Métricas en PRUEBAS y verificación.
0.46 no está aceptada ni probada físicamente por este entorno. Tras corregir/confirmar
sigue parte 6 de validación Android y correcciones. No se declara paridad universal.
Nueve fuentes; Kemono, Coomer y SimpCity siguen excluidos. Proyecto abierto.


## Confirmación parte 5 / 0.46 y autorización de parte 6 / 0.47

29 de octubre de 2026, America/Hermosillo. El usuario informa «Ya revisé y funciona
todo» para 0.46 y autoriza el siguiente bloque. Se trabaja parte 6 agrupada: validación
y correcciones, manteniendo las cinco partes anteriores. Recuperación de fondos,
lifecycle de volumen y retirada fuera de UI de un segundo destino directo rechazado.
Comprobación local con muestras propias e informe privado/exportable, sin red, cuentas
o archivos personales. PARTE_6_VALIDACION.md detalla alcance y límites.

0.47 entrega parte 6 para prueba, todavía no aceptada por el usuario.
1152 JVM/Robolectric en 161 clases, 0 fallos/errores/omitidas. Android: 73 compiladas, 72 ejecutadas y 72 aprobadas, 1 omitida(s), 0 fallos/errores; los 73 casos terminaron.
Lint 0 errores/149 avisos. Firma original/v2/zipalign16KiB, min26/target36.
Emulador oficial Android 9/API28 x86_64 por software, sin KVM. No Samsung/ARM64, Drive/cuentas reales, batería o salida física certificadas. Android16/API36 se intentó sin completar arranque; no se ejecutaron tests allí.
Actualización del APK final046→047 conservó DB/WAL/SHM y preferencias por SHA256 exacto,
con1105medios propios y favorito/progreso verificados antes. No certifica grants SAF
externos, KeyStore durante actualización, cuentas privadas o proveedor Drive real.

RAR corregido: claves pthread evitan TLS recursivo, cuatro ABI reconstruidas, mismas
cuotas/CRC/aislamiento y libarchive3.8.10. ZIP64 usa Commons ya dependiente, mismos
preflight/límites/nombres/métodos/CRC. Fondo atómico/recorte, cierre de volumen y limpieza
fuera de UI del segundo destino rechazado. Comprobación manual de ocho muestras propias,
Room aislada, informe privado/exportable sin cuentas/red/archivos personales o sonido.

Fixtures Android protegidos MANAGE_DOCUMENTS, runner obtiene solo grants del proveedor
propio. Historial usa lectura de streams compatible API28; audio compara posición ya
pausada/estable y UI espera datos, conservando asserts. Fallos iniciales/evidencia en
PRUEBAS y docs/evidence/0.47.0. No se quitaron casos ni se rebajaron controles.
El entorno se interrumpió antes del primer cierre; se recuperó checkpoint y se repitió
suite completa con el APK actual. La instrumentación se ejecutó en perfil desechable;
su APK histórico usa la base principal de ese perfil. El diagnóstico normal es aislado.

Room13/DAO/copia19/intercambio1/transporte/grafo356/permisos/assets previos intactos.
Tres assets propios añadidos y una actividad interna no exportada. Nueve fuentes;
Kemono/Coomer/SimpCity excluidos. Guia GUIA_PARTE_6_047.md, alcance PARTE_6_VALIDACION.md.
Se llega a la sexta entrega acordada; faltan aceptación física, correcciones que aparezcan
y los pendientes originales documentados. No afirmar paridad universal o cierre definitivo.


## Confirmación 0.47 y rediseño completo autorizado 0.48

29 de octubre de 2026, America/Hermosillo. El usuario confirma «Listo todo funciona»
para 0.47. Es aceptación general informada, no ejecución propia en su Samsung ni
certificación individual de todas las fuentes/cuentas/formatos. Se completaron las seis
entregas agrupadas acordadas; persisten los límites originales documentados.

El usuario solicita ahora rehacer por completo el diseño y la distribución: referencia
visual oscura con portadas y barra inferior, búsqueda más sencilla por nombre/enlace,
vistas previas de resultados, publicaciones y contenido dentro de la misma sección de
Fuentes, pocos elementos en el menú de tres puntos y herramientas agrupadas en Ajustes.
También reproductor estilizado y volumen compacto. Autoriza mayor tamaño de APK.

Base recuperada: fuente final 0.47, commit 5b3aa88, no el snapshot antiguo 0.43. Se
conservan Room13, copia19, intercambio1, clave original, nueve fuentes y exclusiones.
0.48 está EN DESARROLLO, no entregada ni aceptada. Nuevos explorador nativo de fuentes,
ajustes buscables, tarjetas/barra/iconos y reproductor. El explorador usa el transporte
existente y guarda solo la publicación revisada cuando se abre su lector/reproductor;
no requiere importar toda la página ni saltar a Organización. Las miniaturas solo se
consultan al buscar/actualizar/abrir explícitamente; abrir la sección restaura datos
locales. Se añaden rutas separadas de miniaturas sin convertirlas en adjuntos de
descarga/streaming ni enviar cuentas a esos destinos. Detalle del alcance al terminar.

Primera regresión: 1152 JVM en 161 clases, 0 fallos/errores; antes de los últimos ajustes
y de las pruebas nuevas. Compilación principal e instrumentación inicial aprobadas.
Emulador Android9/API28 x86_64 arrancado, 640x960, TCG/Swiftshader, sin KVM. Pruebas
nuevas y revisión visual aún pendientes; no atribuirles éxito. Se guarda un checkpoint
de fuentes, no un APK de entrega.


## Entrega 0.48: navegación visual y fuentes integradas

29 de octubre de 2026, America/Hermosillo. Se termina el rediseño autorizado y se entrega
para prueba, todavía no aceptado por el usuario. Biblioteca con portadas y menú de cuatro
opciones; barra inferior y Ajustes buscables por categoría. Fuentes reúne consulta,
resultados y publicación en la misma actividad; al abrir medios guarda solo esa ficha
revisada. Orden/filtros y vuelta/rotación conservan contexto. Vistas previas reales
admitidas, referencias de portada separadas del contrato de descarga/streaming.
Reproductor y volumen compacto; Descargas con opciones secundarias plegadas.

1170 JVM/163 clases, 0 fallos/errores/omitidas; 18 nuevas, 1152 anteriores
conservadas. Lint0errores/185avisos. Android76casos completos:75aprobados,
1omitido(API35+PDF),0fallos/errores; tres casos de UI repetidos con comprobaciones
visuales reforzadas,3/3aprobados. EmuladorAPI28x86_64/TCG/Swiftshader, no Samsung.
La primera captura quedó tapada por ANR de SystemUI; se resolvió el aviso y la nueva
comprobación rechaza capturas tapadas y pulsa una tarjeta mediante UiAutomator.
APK principal idéntico entre ambas ejecuciones. Actualización047→048 conservó DB/WAL/SHM
y preferencias por SHA256, con1105medios propios/favorito/progreso del perfil de prueba.

Firma original/v2/16KiB,Room13/copia19/intercambio1 y 45 archivos estructurales/assets/
nativos byteidénticos; permisos/dependencias conservados. Dos actividades internas nuevas.
Nueve fuentes; Kemono/Coomer/SimpCity excluidos. Miniaturas y buscadores mantienen límites
de cada sitio; Drive depende del proveedor instalado. GuíaGUIA_REDISENO_048,alcance
REDISENO_048,informeINFORME_048,evidencia0.48.0. No afirmar paridad universal ni validación
propia de cuentas, hardwareSamsung o subidas reales. Corregir según la prueba del usuario.
