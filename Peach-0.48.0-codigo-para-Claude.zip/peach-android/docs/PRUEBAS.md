# Peach Local 0.47.0 · Parte 6 de 6

29 de octubre de 2026, America/Hermosillo. Base0.46/parte5 aceptada por el usuario;
0.47 para prueba. Instalar encima sin desinstalar ni borrar datos.

## Resultado

1152 JVM/Robolectric en 161 clases, 0 fallos/errores/omitidas. Android: 73 compiladas, 72 ejecutadas y 72 aprobadas, 1 omitida(s), 0 fallos/errores; los 73 casos terminaron.
Se conservan los 1132 casos anteriores y se añaden20: Validation4709, Lifecycle4706,
CheckUi4704 y Native4701. Lint0 errores/149 avisos; delta frente a0.46:
{"AndroidGradlePluginVersion": 1, "GradleDependency": 4, "NewerVersionAvailable": 1, "SetTextI18n": 5}. Sin nuevas supresiones.

Omisiones Android: Formats440IntegrationTest#nativePdfRendererRendersSearchesAndAcceptsOnlyCorrectOwnPasswordOnAndroid15.
El PDF con búsqueda/clave API35+ debe comprobarse en la tablet; el PDF de muestra normal
sí se creó/renderizó en la comprobación nativa. Emulador oficial Android 9/API28 x86_64 por software, sin KVM. No Samsung/ARM64, Drive/cuentas reales, batería o salida física certificadas. Android16/API36 se intentó sin completar arranque; no se ejecutaron tests allí.
El APK final probado coincide por SHA con el que se entrega. La suite histórica usa
solo un perfil desechable; el diagnóstico normal usa base temporal aislada.

Actualización real de paquete0.46→0.47 en el emulador:1105medios propios, favorito/progreso
verificados antes, DB/WAL/SHM y preferencias de apariencia idénticos por SHA256 después.
No equivale a actualización Samsung, permisos SAF externos, KeyStore de cuentas durante
actualización o Drive real. Las pruebas de cuentas usan sesiones falsas/claves propias.

## Cambios

Ver PARTE_6_VALIDACION.md. Recuperación/retirada atómica del fondo y recorte proporcionado;
diálogo de volumen antes de liberar motor; limpieza del segundo destino fuera de UI.
RAR elimina recursión de TLS emulado mediante claves pthread de libc, sin cambiar
libarchive3.8.10, cuotas160MiB/asignación64MiB, CRC, límite85s/cliente90s o aislamiento.
Cuatro ABI API26 reconstruidas con mismo NDKr30 y alineación16KiB; ejecución medida x86_64.
ZIP64 evita fallo de offsets de ZipFile Android usando Commons ya dependiente; mantiene
ZipDirectory, cuotas de índice/entradas, nombres, Store/Deflate y verificación CRC.

Ocho checks manuales de muestras propias; no red/cuentas/archivos del usuario/sonido.
Room de prueba aislada. Cancelar/salir dejan parcial, rotar conserva, timeout no aprueba.
Una salida de codec a buffer no equivale a pantalla/altavoz o todos los perfiles.
Informe privado AtomicFile, exportación JSON explícita con relectura y limpieza solo
del destino nuevo fallido. Modelo/Android/ABI, sin secretos/títulos/seriales; sin envío.

## Fallos y correcciones durante desarrollo

Compile inicial: RoomDatabase/PdfDocument no AutoCloseable, cierre finally. Dirigida37/2:
MIME JSON explícito y prueba Room en trabajador como producción, misma aserción de datos
intactos. Luego37/37. Instrumentación inicial se cerró por proveedores de fixtures sin
MANAGE_DOCUMENTS; se corrige protección y bootstrap de grants desde su APK propietario,
sin ampliar permisos de la app. Prueba RAR real reveló SIGSEGV: __emutls_get_address y
malloc limitado recursivos. Se corrige TLS y se reconstruyen cuatro ABI. Test JNI nuevo
concurrente: una cuota1MiB falla, otra160MiB produce bytes exactos, ocho rondas con hilos
reutilizados y ausencia de fugas. Primer fixture de éxito usaba<1MiB; se usa el grande
en ambos lados manteniendo la aserción>1MiB. Dirigida nativa15/1→15/15; cuatro Android
nuevas y ocho componentes aprobados tras corregir el motor.

Suite Android73 inicial: tres fallos y una omisión. ZIP64 se corrige en producción;
fixture de historial evita InputStream.readAllBytes inexistente en API28. Audio mide
posición estable no nula tras pausa asíncrona antes de recrear, con las mismas aserciones
de pausa/no reinicio/continuidad/ausencia de error y sin tolerancia numérica. Los tres
casos afectados pasaron. Suites JVM detectaron esperas insuficientes en Organization y
LibraryUi: se esperan los datos del adaptador con plazo10s, se conservan asserts exactos.
El entorno cayó antes del cierre anterior. Recuperado desde checkpoint; reconstrucción
inicial falló por faltar lanzador jlink del JRE, restaurado junto a herramientas JDK.
Después se repitieron suites completas. Evidencia inicial/final/XML/logs conservada;
no se quitaron casos, bajaron aserciones o suprimió lint para aprobar.

## Conservación y entrega

Room13/esquemas/DAO, BackupStore19/lecturas1–19, PortableState/Exchange1 y SourceHttp
byteidénticos. Grafo runtime 356 líneas idéntico. Assets
anteriores intactos; tres muestras diagnósticas propias nuevas con manifiesto SHA.
Ocho Java anteriores modificados, C de asignador y cuatro.so corregidos. ZipDirectory,
ArchiveFiles y DocumentRules sin cambios. Permisos iguales; una actividad interna no
exportada, sin servicios/proveedores principales nuevos. DEX Peach
440→456, ninguna clase anterior eliminada.
Firma original/v2, zipalign16KiB, min26/target36. Certificado SHA256:
9fc537c4c8d0461a8565414c7a30169e592120cd314b500bee7c707f8a748484.
APK 11295941bytes; SHA256 e70a8b706b4244cad3e2e413725acddd81fbc61f974c78b3ab60a9d2452aeb20.

Se entregan APK, ZIP con el mismo APK, guía, alcance, informe/verificación y proyecto
completo con bundle/evidencia/APK de instrumentación. Nunca clave privada. Seguir guía
para actualización, datos, fondo, volumen, diagnóstico y usos anteriores en SM-X230.
Drive/proveedor y salida física se validan allí. Proyecto abierto a correcciones y
pendientes originales; no paridad universal. Nueve fuentes, exclusiones vigentes.


## Rediseño 0.48.0


- 1170 JVM/Robolectric, 163 clases, 0 fallos/errores/omitidas; las 1152 anteriores conservadas y 18 nuevas. Se actualizan solo dos destinos esperados de navegación en Appearance460Test, conservando sus comprobaciones. Nuevas pruebas de búsqueda, lectura en la misma pantalla, vuelta/rotación, error sin pérdida de caché, fichas manuales, ajustes, aislamiento entre fuentes, guardado de una sola ficha, datos personales, miniaturas acotadas y rechazo de destinos ajenos.
- Lint: 0 errores, 185 avisos; sin nuevas supresiones. Compilación principal y de instrumentación completadas.
- Android: 76 casos completos, 75 aprobados, 1 omitido, 0 fallos/errores. Los 73 casos anteriores siguen presentes. La omisión es la búsqueda/contraseña PDF de API35+, fuera del API28 de este emulador.
- Tres casos nuevos también se repitieron con comprobaciones visuales reforzadas: 3/3 aprobados. Tarjeta pulsada mediante UiAutomator, publicación dentro de Fuentes, rotación, iconos/navegación y reproductor Media3 real con silencio/restauración y cierre del volumen antes de Stop. Capturas de fuentes, publicación, biblioteca, ajustes, descargas y volumen.
- Suite completa Android con test APK `538e4e8c2ad1c68499b7d39af6464cddcdc7351f6b4a4f8884ce6b59a3f7da32`; repetición visual final con test APK `11d1762518a5bf5fe220ad6617ac4d429b451bb6602a38d942f29a7daccf1c5d`. El APK principal fue el mismo en ambas, y coincide con la entrega por SHA256.
- Actualización real 0.47→0.48 en perfil desechable del emulador: DB/WAL/SHM y preferencias de apariencia idénticas antes/después por SHA256, con 1105 medios propios y favorito/progreso verificados previamente. No se instaló en la tablet del usuario.
- 45 archivos previos de base/DAO/copia/intercambio/transporte/credenciales/cola/esquemas/assets/nativos conservados byte a byte. Mismas dependencias y permisos; dos actividades internas no exportadas añadidas.

## Límites y registro de incidencias

Emulador oficial 37.2.13, Android9/API28 x86_64, 640×960, CPU TCG sin KVM y Swiftshader. No certifica Samsung/ARM64/Android16, Drive/cuentas privadas, medios upstream, batería o audio físico.

Se conserva la evidencia intermedia. La primera compilación del diseño detectó IDs de recursos y un modificador final en el ViewModel; corregidos. Las pruebas nuevas corrigieron dos errores de compilación del fixture (var compuesto y lambda con excepción). La revisión visual detectó tinte excesivo en el buscador y texto estrecho del filtro; corregidos. Un lint RestrictedApi al limpiar el tinte de AppCompat se resolvió con la API pública, sin supresión. El entorno se reinició tras una interrupción; se recuperó el checkpoint y se repitieron pruebas/compilación.

Las primeras capturas Android estaban tapadas por «System UI isn't responding» del emulador. No se dieron por válidas visualmente: se añadió una comprobación que pulsa Wait solo ante ese aviso del sistema, exige que desaparezca y rechaza capturas tapadas. Se repitieron los tres casos con pulsación real de tarjeta y captura tras estabilizar el dibujo. La suite de 76 casos ya había pasado; la repetición visual reforzó esos tres casos sin cambiar el APK principal.

Se mantienen los límites originales documentados de fuentes, cuentas, formatos y nube. Las tarjetas muestran miniaturas reales admitidas cuando las hay; no desbloquean archivos ni garantizan una portada para cada publicación. Los datos y fondos deben confirmarse en la SM-X230. 0.48 queda entregada para prueba, no aceptada aún.
