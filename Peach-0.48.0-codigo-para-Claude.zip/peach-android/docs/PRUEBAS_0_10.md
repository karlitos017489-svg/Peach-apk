# Confirmación posterior del usuario

El 24 de octubre de 2026 el usuario indicó: «Todo correcto, sigue». Se registra
aceptación general de 0.10.0 en SM-X230, sin inferir un ledger personal aportado,
casos específicos de importación ni ejecución de la suite instrumentada.

---

# Peach Local 0.10.0: consulta del catálogo y pruebas

Fecha: 24 de octubre de 2026, America/Hermosillo. APK nativo autónomo para Samsung
Galaxy Tab A11+ SM-X230. El usuario confirmó 0.9.0 con «Esta todo correcto, sigue»;
su aceptación general se conserva en PRUEBAS_0_9.md y el registro JSON correspondiente.
No se infiere una base personal suministrada, un caso concreto de importación probado
ni ejecución instrumentada a partir de esa confirmación. 0.10 aún no tiene aceptación
física comunicada por el usuario.

## Resultado final

**173 pruebas locales aprobadas, 0 fallos, 0 errores, 0 omitidas; 32 clases.**
Lint: **0 errores, 32 advertencias**. APK principal y de instrumentación compilados;
firmas verificadas con el certificado anterior; APK principal alineado. **10 pruebas
instrumentadas compiladas, 0 ejecutadas**. No hay acceso directo a la tablet ni un
Android completo operativo en este entorno; /dev/kvm no está presente. No se repitió
el intento anterior de emulador software ni se ejecutó GitHub Actions remotamente.

## Funciones entregadas

- Los metadatos seleccionados del catálogo importado se consultan en las fichas,
  búsqueda principal y exploración por términos de la biblioteca. Se añade Creadores
  como campo propio y se conservan nombres completos con comas.
- Nombre de origen, ID de asset y ruta identifican cada bloque de datos. Las diferencias
  entre catálogos se muestran sin escoger un valor para completar los campos afectados.
  Los NFO y las ediciones personales conservan prioridad.
- Un título único de catálogo puede completar un título vacío o uno que todavía era
  nombre de archivo sin NFO registrado. Las columnas originales no se sobrescriben;
  no se cambia el nombre del archivo. Tarjetas, ordenación y lectores comparten esa
  presentación. Tiempos/dimensiones del catálogo no sustituyen mediciones o progreso AV.
- Filtros reúnen términos NFO/catálogo con deduplicación por documento. Las etiquetas
  personales controlan el filtro de etiquetas. Los datos de origen siguen consultables
  y las coincidencias de identidades se distinguen como Catálogo importado.
- Room v9 añade media.catalogMetadata, una capa reconstruible desde las instantáneas
  y correspondencias existentes. Se reconstruye al migrar, restaurar v6 y completar
  el escaneo; se actualiza por origen al reimportar. Las copias permanecen en v6, con
  lectura v1–v6, y no duplican ese índice derivado como estado personal.
- Se corrige el mapeo relativo: descuenta la base documental del checkpoint raíz del
  escáner, conservando subcarpetas homónimas. La etapa anterior comprobaba rutas
  relativas sintéticas y no ese prefijo generado por el escáner real.

El índice está limitado a 512 KiB por documento. Si una parte no cabe se identifica
como Índice resumido, sin truncar su instantánea. No se usa una unicidad aparente de
un índice parcial para completar títulos o campos. La consulta principal puede ser
parcial en ese caso; los registros completos permanecen en Catálogo de Peach original.
METADATOS_CATALOGO.md documenta prioridades, reconstrucción y límites.

No se añaden dependencias de ejecución, permiso INTERNET, servidor o Python/Termux.
La comparación del árbol resuelto debugRuntimeClasspath con 0.9 no muestra cambios.
La matriz mantiene pendientes agencias/membresías, publicaciones/deseos completos,
varios mapeos por lote, actualización/reversión de organización, proveedores y formatos.
La entrega no declara paridad, sincronización integral ni portabilidad de todo el ledger.

## APK y actualización

| Dato | Resultado |
|---|---|
| Archivo | Peach-Local-0.10.0-debug.apk |
| Identificador | com.peach.local |
| versionName / versionCode | 0.10.0 / 10 |
| Tamaño | 7.649.713 bytes |
| Android mínimo / objetivo | API 26 / API 36 |
| Base / copia personal | Room v9 / JSON v6 |
| Firma | RSA 2048, APK v2; mismo certificado de 0.2–0.9 |
| Alineación | zipalign -c -P 16 4, salida 0 |
| INTERNET / MANAGE_EXTERNAL_STORAGE | Ausentes |
| .so, claves privadas y fixtures multimedia/SQL en APK principal | Ausentes |

SHA-256 del APK:

```
06ccf427e050ea19c39bd28345f53bde3280e2fbdeca1bd5f0842e10058ae29c
```

SHA-256 del certificado:

```
9fc537c4c8d0461a8565414c7a30169e592120cd314b500bee7c707f8a748484
```

Instalar encima de 0.9.0 sin desinstalar. La migración solo añade la columna derivada
y la completa desde instantáneas conocidas; no borra medios, listas, grupos, fichas,
deseos, posiciones AV/lectura o permisos SAF. También se prueban las cadenas previas.
No se ha instalado directamente esta versión sobre la tablet desde este entorno.
La clave privada original se seleccionó con PEACH_DEBUG_KEYSTORE, fuera de fuente/ZIP.
Se verificaron clases nuevas y la identidad del esquema v9 dentro del DEX final.

## Pruebas locales

| Clase | Casos |
|---|---:|
| AudioExtractorTest | 1 |
| CatalogBridgeTest | 11 |
| CatalogIndexTest | 5 |
| CatalogMetadataTest | 11 |
| CatalogMetadataUiTest | 3 |
| CatalogTransferTest | 6 |
| CatalogUiTest | 3 |
| DocumentScannerTest | 5 |
| EntityStoreTest | 11 |
| GroupStoreTest | 7 |
| ImageFilesTest | 6 |
| LibraryDatabaseTest | 12 |
| LibraryUiTest | 8 |
| LibraryViewTest | 6 |
| MediaRulesTest | 6 |
| MediaTypesTest | 6 |
| MigrationV3Test | 1 |
| MigrationV4Test | 1 |
| MigrationV5Test | 1 |
| MigrationV6Test | 1 |
| MigrationV7Test | 1 |
| MigrationV8Test | 1 |
| NfoDetailsTest | 4 |
| NfoReaderTest | 17 |
| OrganizationBackupTest | 9 |
| OrganizationUiTest | 5 |
| ReaderSessionTest | 4 |
| ReaderStoreTest | 5 |
| ReaderUiTest | 4 |
| TextPreviewTest | 4 |
| ThumbnailsTest | 1 |
| ZipBookTest | 7 |

Cobertura nueva significativa:

- Códigos/títulos/fechas/creador/estudio/reparto/etiquetas en búsqueda y términos, nombres
  atómicos y conteos sin duplicar un documento por varias fuentes.
- Prioridad de NFO y ediciones personales; conservación de favoritos, visto, posiciones,
  duración y contador. Un NFO registrado protege incluso un título igual al nombre
  del archivo. Reescanear conserva el índice y actualiza los campos NFO independientes.
- Fuentes que discrepan en título/código: ambas siguen buscables y visibles y ninguna
  reemplaza automáticamente el título original. Las relaciones derivadas se etiquetan
  como catálogo y creator conserva una función distinta de director/artista musical.
- Reimportación que reemplaza solo su capa y mantiene la de otro origen; reasignación
  de documento que retira su proyección anterior. No se declara reversión del grafo/listas.
- Restauración v6 desde instantáneas sin serializar el índice; reconstrucción de caché
  derivada corrupta y recuperación de un ID estable recreado tras olvidar la raíz.
- DocumentsProvider/DocumentScanner producen la carpeta base real; el mapeo obtiene la
  ruta relativa correcta y no elimina una subcarpeta homónima. Se conservan negativos
  de traversal, tamaños, duplicados y límites del importador de 0.9.
- 2.100 etiquetas largas sintéticas exceden el índice: queda acotado y marcado parcial,
  la instantánea conserva el último registro y no se elige un título por falsa unicidad.
- Fechas inválidas no generan faceta de año; una caché malformada no rompe la lectura
  del objeto y puede reconstruirse desde su origen conservado.
- Migración desde esquema v8 auténtico, con todos los dominios y una instantánea
  existente, que añade consulta sin cambiar estado personal. Se ejecutan además las
  migraciones y regresiones de las entregas anteriores.
- Interfaz: una importación cambia resultados de una búsqueda abierta sin recrear
  MainActivity, la tarjeta/ficha muestran datos del origen, Creadores se selecciona
  desde controles visibles y persiste al recrear; el lector usa el título importado
  y lee texto real sin mezclar posición de lectura y tiempo AV.

JDK17, Robolectric4.16.1 y API28 declarada, SQLite LEGACY. Los casos de imágenes y
ZIP/texto conservan sus pruebas reales del lector y gráficos nativos JVM. El PDF
local usa un doble explícito de su backend en las unidades; esto no prueba ejecución
de PdfRenderer Android. Tampoco certifica MediaCodec, ABI/códecs, microSD, batería,
CursorWindow, memoria, accesibilidad o rendimiento de todas las bibliotecas reales.
No se recibió una base personal del usuario.

## Instrumentación pendiente

Se compilan las 9 pruebas anteriores y una nueva de Room nativo: guardar catálogo,
construir consulta, cerrar/reabrir base y conservar título personal/progreso. Las
10 permanecen sin ejecución en Android completo. La presencia del método nuevo en
el DEX de instrumentación se verificó. El APK de pruebas está en el paquete de fuente;
no se pide descargar una app de prueba separada ni repetir la batería anterior.

## Compilación y registros

```bash
python3 scripts/run-gradle.py :app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:assembleDebugAndroidTest --console=plain
```

Gradle8.13, AGP8.13.0, JDK17 completo, SDK36, build-tools35.0.0. La recuperación del
toolchain necesitó reintentar descargas oficiales que agotaron el tiempo, verificadas
por sus hashes. Antes de completar platform-tools hubo un aviso de paquete ausente;
se instaló el paquete oficial y las compilaciones posteriores cerraron correctamente.
No se desactivó TLS ni se añadió una dependencia al funcionamiento del APK instalado.

Primera compilación conjunta: 170 unidades aprobadas y ambos APK, BUILD SUCCESSFUL
en 4m38s. Después se incluyeron las tres comprobaciones nuevas de interfaz. Cierre
100-final.log: **BUILD SUCCESSFUL in 40s**, 83 tareas, 5 ejecutadas y 78 actualizadas;
173 casos aprobados. No hubo una entrega de APK intermedio.

Lint: ButtonStyle14, SetTextI18n8, GradleDependency2, UsableSpace2, ExifInterface1,
NewerVersionAvailable1, SwitchIntDef1, DataExtractionRules1, Overdraw1 y
ClickableViewAccessibility1. No se suprimieron advertencias; las recomendaciones de
estilo, traducción, almacenamiento, accesibilidad y actualizaciones permanecen abiertas.
SwitchIntDef es el caso BLOB rechazado por default en el lector SQLite existente.
El recuento de avisos de versiones puede variar con la consulta de metadatos remotos;
no se atribuye su variación a actualizaciones de dependencias.

Se revisaron stderr y registros sin excepciones de hilos, NoSuchMethodError,
SQLiteException, CloseGuard o avisos de recursos sin cerrar inesperados. Los mensajes
del entorno y el caso de imagen inválida se conservan en XML/registros, sin ocultarlos.
La evidencia incluye resultados XML/HTML, lint, firma/permisos, esquemas, logs,
instrumentación y Git bundle. La matriz de compatibilidad conserva el trabajo restante.
