> Aceptación general posterior: el usuario indicó «Esta todo correcto, cuanto falta para meter el contenido de peach?» y después autorizó continuar con «OK sigue». Se registra funcionamiento general comunicado de 0.11.0 en SM-X230; no se infiere acceso directo, una importación personal concreta ni ejecución instrumentada. Fecha: 24 de octubre de 2026, America/Hermosillo.

# Peach Local 0.11.0: agencias y pruebas

Fecha: 24 de octubre de 2026, America/Hermosillo. APK nativo para Samsung Galaxy
Tab A11+ SM-X230. El usuario confirmó 0.10.0 con «Todo correcto, sigue». Esa aceptación
general está en PRUEBAS_0_10.md; no se infiere un ledger personal aportado, pruebas
específicas de importación o ejecución instrumentada. 0.11 aún no tiene aceptación
física comunicada por el usuario.

## Resultado

**188 pruebas locales aprobadas, 0 fallos, 0 errores, 0 omitidas, 35 clases.**
Lint: **0 errores y 41 advertencias**. APK principal y de pruebas compilados, firma
coincidente verificada y alineación aprobada. **11 pruebas instrumentadas compiladas,
0 ejecutadas**. No hay acceso directo a la tablet ni Android completo operativo;
/dev/kvm no está disponible. No se repitió el emulador software previamente fallido.
No se ejecutó GitHub Actions remotamente.

## Funciones de esta entrega

- Fichas de agencia con nombre/alias/notas/referencias/favorito, sin exigir medios.
- Afiliación vigente por persona del reparto o creador, mediante UUID. Asignación,
  cambio revisado y retirada sin modificar archivos o progreso. Procedencia explícita.
- Roster separado de coprotagonistas. La ficha y Ver archivos reúnen la biblioteca de
  miembros actuales por NFO/catálogo y vínculos manuales, deduplicando documentos.
- Ámbito de agencia conservado al recrear MainActivity y actualizado al cambiar
  afiliaciones. Las colas de imagen/audio utilizan la selección de identidades común.
- Importación revisable de entity_membership del original: fuente/confianza/fecha,
  filas nuevas, existentes, conflictos y tipos incompatibles. Una afiliación existente
  se conserva; una distinta no se reemplaza automáticamente. Solo catálogo no crea grafo.
- Room v10 añade entity_memberships con clave por miembro, FK en cascada y un índice
  por agencia. Copias JSON v7 incluyen afiliaciones; siguen leyendo v1–v6. Errores de
  afiliación revierten toda la restauración. Copias antiguas conservan afiliaciones actuales.

AGENCIAS.md detalla el uso, validación y diferencias. La referencia fija sigue siendo
peach-mitao/peach de22796c04919aaa057d77930c33c81313765569. Se revisaron la migración
0025_agency_entities.sql y tests/test_agency_entity.py. La prueba de proyección SQLite
utiliza las definiciones originales de entity_new y entity_membership extraídas de ese
SQL sin cambios; no ejecuta el servidor ni la suite Python sobre datos personales.
La fuente completa de esa migración y sus hashes/atribución acompañan las pruebas.

Las agencias no son roles de archivo. Se rechazan vínculos directos agency→media,
autoafiliación, agencia como miembro y miembro de tipo estudio/serie/etiqueta. Renombrar
conserva identidad/afiliaciones; eliminar agencia retira afiliaciones y conserva personas.
El modelo permite también creator por asignación explícita en Android.

Quedan pendientes búsqueda textual general de medios por nombre de agencia, logotipos,
captación/rechazo online, candidatos por afirmación e historial. El original tiene más
funciones de agencia. Publicaciones, deseos completos, proveedores y otros formatos
siguen pendientes. No se declara paridad, sincronización o migración completa.

## APK y actualización

| Dato | Resultado |
|---|---|
| APK | Peach-Local-0.11.0-debug.apk |
| Identificador | com.peach.local |
| versionName / versionCode | 0.11.0 / 11 |
| Tamaño | 7,890,229 bytes |
| Android mínimo / objetivo | API26 / API36 |
| Base / copia personal | Room v10 / JSON v7, lectura v1–v7 |
| Firma | RSA2048, APK v2 verificado; mismo certificado de entregas anteriores |
| Alineación | zipalign -c -P 16 4, salida 0 |
| Dependencias de ejecución nuevas | Ninguna |
| INTERNET / MANAGE_EXTERNAL_STORAGE | Ausentes |
| .so, claves privadas y fixtures multimedia/SQL en APK principal | Ausentes |

SHA-256 APK:

```
d714426ad50a0b1e001a5d2438a17ba20a4bc348f9e573fed2b59d18a6c5ef66
```

SHA-256 certificado:

```
9fc537c4c8d0461a8565414c7a30169e592120cd314b500bee7c707f8a748484
```

Instalar encima de 0.10.0 sin desinstalar. Migración 9→10 no reconstruye ni borra
medios, caché de catálogo, estado AV/lectura, listas, grupos, identidades o instantáneas;
crea la tabla vacía de afiliaciones. Las agencias de instantáneas antiguas se pueden
revisar/importar como fichas; una afiliación no proyectada en esa instantánea exige
un origen que sí contenga sus datos, sin inferirlos. No se observó directamente la
actualización física de la tablet. La clave original permanece fuera de fuente/ZIP.
Se verificaron clases nuevas, clases previas de lectores/reproducción e identidad del
esquema v10 en el DEX, además del caso nuevo en el APK de instrumentación.

## Pruebas locales

| Clase | Casos |
|---|---:|
| AgencyStoreTest | 11 |
| AgencyUiTest | 3 |
| AudioExtractorTest | 1 |
| CatalogBridgeTest | 11 |
| CatalogIndexTest | 5 |
| CatalogMetadataTest | 11 |
| CatalogMetadataUiTest | 3 |
| CatalogTransferTest | 6 |
| CatalogUiTest | 3 |
| DocumentScannerTest | 5 |
| EntityStoreTest | 11 |
| GroupStoreTest | 7 |
| ImageFilesTest | 6 |
| LibraryDatabaseTest | 12 |
| LibraryUiTest | 8 |
| LibraryViewTest | 6 |
| MediaRulesTest | 6 |
| MediaTypesTest | 6 |
| MigrationV3Test | 1 |
| MigrationV4Test | 1 |
| MigrationV5Test | 1 |
| MigrationV6Test | 1 |
| MigrationV7Test | 1 |
| MigrationV8Test | 1 |
| MigrationV9Test | 1 |
| NfoDetailsTest | 4 |
| NfoReaderTest | 17 |
| OrganizationBackupTest | 9 |
| OrganizationUiTest | 5 |
| ReaderSessionTest | 4 |
| ReaderStoreTest | 5 |
| ReaderUiTest | 4 |
| TextPreviewTest | 4 |
| ThumbnailsTest | 1 |
| ZipBookTest | 7 |

Cobertura nueva relevante:

- Una afiliación vigente, reasignación, retirada, fuente/fecha manual, conservación
  de favorito/visto/progreso/contador y rechazo de tipos/ciclos/rol agency de archivo.
- Unión por miembros, aliases y roles manuales; documento compartido contado una vez,
  coprotagonista sin membresía excluido del roster, movimiento entre agencias y cascadas.
- Mil miembros con dos mil alias que comparten un documento: el resultado contiene
  un archivo. El índice de alias se construye por pasada; no se afirma un rendimiento
  medido sobre microSD/tablet. La validación global carga identidades una vez.
- Copia v7 con afiliaciones/procedencia, v6 que las conserva, ausencia de afiliación
  entrante que la retira para ese miembro, validación de confianza/referencias/duplicados
  y rollback de todo el estado ante errores.
- Importación de agencias/membresías con confianza 0.7 y procedencia conservadas; conflicto
  con edición local que no se reemplaza; vista previa desactualizada que no escribe
  parcialmente; referencias ausentes/duplicados/tabla nula rechazados y tabla opcional
  ausente de JSON antiguo aceptada. Filas incompatibles siguen en la instantánea.
- DDL original 0025 en la lectura de SQLite y comprobación de que el origen conserva
  sus bytes. Migración de esquema v9 exportado con todos los dominios, cache de catálogo
  incluida, que añade afiliaciones vacías. Las migraciones/regresiones anteriores siguen.
- Controles nativos: crear desde sección Agencias con tipo correcto, añadir miembro,
  revisar/cancelar/confirmar reasignación y actualizar/conservar ámbito en MainActivity.

Entorno: JDK17, Robolectric4.16.1, API28 declarada y SQLite LEGACY. ZIP/texto e imágenes
conservan sus pruebas reales en JVM; PDF local conserva un backend doble explícito en
unidades, sin afirmar motor Android ejecutado. Estas pruebas no certifican MediaCodec,
ABI/códecs, microSD, batería, memoria/CursorWindow, accesibilidad o rendimiento físico.
No se recibió un ledger personal del usuario.

## Instrumentación y registros

La suite conserva diez casos y añade uno de Room nativo: afiliación persistente tras
cerrar/reabrir, ámbito por agencia y cascada al eliminar la agencia sin borrar media.
Los once casos están compilados y no ejecutados. El APK de instrumentación se entrega
como evidencia dentro del ZIP, sin pedir instalar una app de prueba separada.

Comando final, con SDK/firma según README y FIRMA.md:

```bash
python3 scripts/run-gradle.py :app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:assembleDebugAndroidTest --console=plain
```

Gradle8.13, AGP8.13.0, SDK36, build-tools35.0.0, JDK17 completo. Se conservan versiones
de dependencias; no se exige herramienta/servidor en la app instalada. La primera
compilación conjunta aprobó 184 casos (1m32s). Al incorporar interfaz se aprobaron 187
(1m18s). La revisión del índice/validación de afiliaciones y el caso grande produjo
el cierre **110-final2.log: BUILD SUCCESSFUL in 1m9s**, 83 tareas, 16 ejecutadas y
67 actualizadas; 188 casos. No se entregó un APK intermedio.

Lint: ButtonStyle14, GradleDependency11, SetTextI18n8, UsableSpace2, ExifInterface1,
NewerVersionAvailable1, SwitchIntDef1, DataExtractionRules1, Overdraw1 y
ClickableViewAccessibility1. No se suprimieron advertencias. El aviso SwitchIntDef
corresponde al BLOB rechazado por default en el lector SQLite existente. El recuento
de avisos de versiones puede variar con metadatos remotos y no implica cambiar librerías.
Los asuntos de estilo/traducción/almacenamiento/accesibilidad siguen documentados.

Se revisaron logs/stderr sin excepciones de hilos, NoSuchMethodError, SQLiteException,
CloseGuard ni avisos inesperados de recursos sin cerrar. Los mensajes conocidos de
Robolectric/SQLite y la imagen inválida se conservan en las evidencias, sin ocultarlos.
Se entregan XML/HTML de unidades, lint, firmas/permisos, esquemas, registros, APK de
pruebas y bundle Git. La matriz identifica las funciones que aún faltan al proyecto.
