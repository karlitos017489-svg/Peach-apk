> Aceptación general posterior: el usuario indicó «Esta todo correcto, sigue» el 25 de octubre de 2026 (America/Hermosillo). Se registra funcionamiento general comunicado de 0.12.0 en SM-X230, sin inferir importación personal concreta, acceso directo ni ejecución instrumentada.

# Peach Local 0.12.0 — publicaciones y seguimiento

Fecha: 24 de octubre de 2026, America/Hermosillo. Samsung Galaxy Tab A11+ SM-X230.
La aceptación general comunicada de 0.11.0 está en PRUEBAS_0_11.md y en
user-validation-0.11.0.json. No se infiere acceso directo, un ledger personal aportado
ni ejecución instrumentada. 0.12.0 todavía no tiene una prueba física comunicada.

## Resultado verificable

**216 pruebas locales aprobadas, 0 fallos, 0 errores, 0 omitidas, 39 clases.**
Lint: **0 errores y 34 advertencias**. APK principal y de pruebas compilados y
verificados. Firma coincidente con 0.11 y anteriores; zipalign aprobó ambos.
**12 pruebas instrumentadas compiladas, 0 ejecutadas.** No hay dispositivo conectado,
Android completo operativo ni /dev/kvm. No se repitió el emulador software fallido.
No se ejecutó GitHub Actions ni se contactó a proveedores o cuentas del usuario.

## Qué incorpora esta entrega

- Publicaciones locales separadas de obras deseadas y archivos. Fuente/proveedor,
  referencia, ID externo, URL como texto, fecha/precisión, semántica obra/entrega,
  clave, variante, estado, notas y vínculo opcional a identidad/documento.
- Crear/editar publicaciones y cambiar Nueva/Vista/Guardada/Ignorada. Ficha con
  procedencia y disponibilidad del documento. Añadir una publicación a deseos es
  idempotente; elimina su estado Ignorada. Eliminarla conserva deseos y medios.
- Deseos con wanted/given_up/acquired y fase Sin publicar calculada por fecha local.
  Registro explícito de búsquedas realizadas: sin resultado, encontrado o error.
  Las búsquedas antiguas sin resultado cuentan; tras tres se pausa. Los primeros
  90 días y los errores no suman. Encontrado reinicia el contador y reactiva sin
  fingir una adquisición. Reiniciar conserva el último resultado y no toca adquiridas.
- Reconciliación revisada por código declarado en NFO/catálogo, con candidato único.
  No usa títulos o nombres de archivo; no adivina normalizadores de proveedores.
  Archivos ausentes y coincidencias múltiples no se adquieren automáticamente.
  Confirmar recalcula la revisión dentro de una transacción. Los lotes locales se
  pueden deshacer; los cambios manuales posteriores quedan fuera del lote.
- Filtros de estado, búsqueda y recuperación de sección/filtro al recrear la pantalla.
  Abrir archivo vinculado utiliza lector, visor o reproductor nativo compatible.
- Importación de tablas opcionales follow_source/follow_item/want_item, con revisión,
  procedencia y archivos mapeados. Reimportar conserva registros nativos existentes;
  conflictos de código se muestran y no se fusionan. Adquirido del original no implica
  que exista archivo local. Solo catálogo conserva instantánea sin crear estos registros.
- Room v11 añade publicaciones y seguimiento a los deseos. Los deseos anteriores
  con archivo se inicializan como adquiridos. Copia personal v8, lectura de v1–v7,
  validación transaccional y preservación del seguimiento actual al restaurar copias
  antiguas. No cambian los identificadores de medios ni los archivos de origen.

Uso: **Menú → Publicaciones** o **Identidades y alias → Publicaciones**. Los deseos
siguen en **Menú → Lista de deseos**; ahí está **Revisar coincidencias con archivos**.
PUBLICACIONES_Y_SEGUIMIENTO.md explica límites, reglas, importación y deshacer.

## APK y actualización

| Dato | Resultado |
|---|---|
| Archivo | Peach-Local-0.12.0-debug.apk |
| Identificador | com.peach.local |
| versionName / versionCode | 0.12.0 / 12 |
| Tamaño | 7,695,513 bytes |
| Android mínimo / objetivo | API26 / API36 |
| Persistencia | Room v11, identityHash 70ffed7f4cf6352a006315a9f60d32c4 |
| Copia personal | JSON v8; importa v1–v8 |
| Firma | RSA2048, APK Signature Scheme v2 |
| Alineación | zipalign -c -P 16 4, salida 0 en ambos APK |
| Dependencias de ejecución nuevas | Ninguna |
| INTERNET / MANAGE_EXTERNAL_STORAGE | Ausentes |
| .so, claves privadas y fixtures SQL en APK principal | Ausentes |

SHA-256 APK principal:

```
376332af5e0b56048f6154a5c807ae97fe665c23b438fcc720e02d77fc96a12a
```

Certificado SHA-256:

```
9fc537c4c8d0461a8565414c7a30169e592120cd314b500bee7c707f8a748484
```

Instalar sobre 0.11.0, sin desinstalar, conserva el espacio de datos y ejecuta la
migración. Hacer una copia personal desde la app permite conservar el estado fuera
de ella. La copia no incluye medios ni autorizaciones SAF. No se afirma una instalación
0.12 observada en la tablet. La clave de firma queda fuera del fuente y del ZIP.

Se inspeccionó el DEX: PublicationStore, PublicationCatalog, TrackingBackup, AgencyStore,
ReaderActivity y la identidad de Room v11 están en el APK. El DEX de pruebas contiene
nativePublicationAndTrackingPersistAndUndoKeepsMediaProgress. Las verificaciones de
firma, permisos, paquete/SDK y alineación acompañan la evidencia.

## Cobertura de pruebas nuevas

28 casos nuevos, sumados a 188 anteriores:

| Clase | Casos | Cobertura |
|---|---:|---|
| TrackingStoreTest | 16 | Fases por fecha, ventana 89/90 días, tres fallos, error/encontrado/reinicio, adquisición explícita, idempotencia desde publicación, ignorar/eliminar, conservación sin archivo, candidatos únicos/ambiguos/ausentes/nombre engañoso, revisión obsoleta y cambios con mismo timestamp, deshacer por lote y cambios manuales, copia v8, copias v7, rollback, precisión aproximada, notas de 4000 caracteres |
| PublicationCatalogTest | 7 | Proyección y mapeo, origen/variante/precisión/estados, idempotencia y ediciones locales, adquirido sin archivo, solo catálogo, conflictos y revisión obsoleta, tablas antiguas/opcionales/invalidas, filas incompatibles, duplicados, fecha ausente como desconocida |
| TrackingUiTest | 4 | Crear publicación y deseo por controles nativos, filtros y recreación, cancelar/confirmar reconciliación, ruta nativa al lector desde publicación |
| MigrationV10Test | 1 | Base real del esquema exportado v10 con dominios previos, migración a v11, adquisición inicial de deseo con archivo y publicaciones vacías |

Se ampliaron las cadenas de migración desde v1–v9 hasta v11. CatalogTransferTest
extrae las definiciones auténticas de 0018_online_follow.sql y 0042_want_list.sql
sin cambiar esos recursos. Inserta publicaciones/deseos y un secreto sintético en
metadata_json, proyecta en solo lectura, comprueba el hash de la base antes/después
y verifica que los campos de secretos excluidos no salgan en la proyección.

En CatalogMetadataUiTest se hace síncrono el ejecutor de DiffUtil solo en el entorno
de prueba y se restaura al terminar. Elimina una carrera de su aserción inmediata;
la actualización de listas de la app sigue usando el ejecutor AndroidX normal.

La instrumentación nueva cubre persistir/reabrir Room, publicación→deseo, adquisición
revisada, deshacer y progreso del medio conservado. Está compilada, no ejecutada.
Los ZIP/textos/imágenes y otras pruebas locales anteriores se mantienen. Los recorridos
PDF JVM conservan su backend de prueba explícito: no ejecutan el motor PdfRenderer
real ni certifican códecs, GPU, microSD, batería o rendimiento del SM-X230.

## Compilación y registros

Herramientas: JDK17.0.21+9, Gradle8.13, AGP8.13.0, SDK36, build-tools35.0.0,
Robolectric4.16.1/API28/SQLiteLEGACY. No se actualizaron paquetes de ejecución.

Comando efectivo, con SDK/JDK y firma proporcionados por variables del entorno:

```
python3 scripts/run-gradle.py :app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:assembleDebugAndroidTest --console=plain
```

Última ejecución: **BUILD SUCCESSFUL en 1m39s**, 83 tareas (51 ejecutadas, 32 al día).
Los 216 casos de la ejecución final no están marcados como omitidos. Historial:

- 120-compile1: compilación inicial correcta.
- 120-build1: 209 casos, ocho fallos: tres aserciones del número de copia anterior,
  cuatro fixtures de raíz sin marcar completa y una carrera de actualización UI.
- 120-build2: 209 casos aprobados, ambos APK y lint correctos.
- 120-final: 214 casos aprobados; empaquetado falla por R$attr duplicado en caché D8.
- 120-final2: compilación limpia elimina esa caché; un caso esperaba que reiniciar una
  obra adquirida cambiara su estado. Se corrigió el caso para provocar un cambio real,
  conservando la regla del original de no alterar obras adquiridas al reiniciar búsquedas.
- 120-final3: 216 aprobados y compilación completa correcta. Registros conservados.

Se inspeccionaron stdout/stderr. No aparecen NoSuchMethodError, SQLiteException,
CloseGuard o recursos sin cerrar en la ejecución final. Persisten avisos conocidos
Invalid ID 0x0 del entorno Robolectric, el rechazo de imagen inválida de una prueba
negativa y el aviso de que SDK36 de Robolectric requiere JDK21. Las unidades se fijan
explícitamente a API28; ese aviso no equivale a una ejecución API36 ni a un fallo
Android de la app.

Lint final: 34 advertencias sin suprimir: ButtonStyle14, SetTextI18n8,
GradleDependency4, UsableSpace2, ExifInterface1, NewerVersionAvailable1,
SwitchIntDef1, DataExtractionRules1, Overdraw1, ClickableViewAccessibility1.
Los avisos de versiones disponibles dependen de la consulta de metadatos remotos;
su cambio de cantidad no significa haber actualizado dependencias. SwitchIntDef
corresponde a rechazar valores BLOB no soportados en la proyección de SQLite.

## Alcance pendiente

No hay proveedor conectado, seguimiento online programado, búsqueda real de recursos,
descargas, cuenta autenticada ni adjuntos múltiples. No se importan feed_discovery,
metadata_json completo, medios remotos, credenciales, toda la actividad o preferencias
del original. La normalización y reconciliación de códigos no tienen paridad completa.
El intercambio sigue siendo una proyección elegida, no sincronización bidireccional.

Continúan pendientes proveedores, otros formatos, audio en segundo plano, versiones
con evidencia, historial y vistas avanzadas, accesibilidad y validación de hardware.
COMPATIBILIDAD_ORIGINAL.md conserva la matriz. El proyecto sigue abierto; un APK
compilado con estas pruebas no representa la incorporación íntegra de Peach original.
