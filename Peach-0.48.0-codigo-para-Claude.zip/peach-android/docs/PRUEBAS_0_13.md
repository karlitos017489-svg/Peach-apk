> Aceptación general posterior: el usuario indicó «Listo funciona todo, sigue con lo demás» el 25 de octubre de 2026 (America/Hermosillo). Se registra funcionamiento general comunicado de 0.13.0 en SM-X230. No se infiere acceso directo, prueba individual de la fuente en Android, una importación personal concreta o instrumentación ejecutada.

# Peach Local 0.13.0 — primera fuente directa y pruebas

Fecha: 25 de octubre de 2026, America/Hermosillo. Tablet objetivo Samsung Galaxy
Tab A11+ SM-X230. El usuario aceptó generalmente 0.12.0 con «Esta todo correcto,
sigue»; PRUEBAS_0_12.md y user-validation-0.12.0.json conservan ese alcance. No se
infiere una importación personal, acceso directo ni instrumentación ejecutada.
En la emisión original de este informe aún no se había recibido aceptación de
0.13.0; la aceptación posterior figura al inicio del documento.

## Resultado

**251 pruebas locales aprobadas, 0 fallos, 0 errores, 0 omitidas, 45 clases.**
Lint: **0 errores y 36 advertencias**. APK principal y de pruebas compilados,
firmas coincidentes verificadas y zipalign correcto en ambos. **13 pruebas
instrumentadas compiladas, 0 ejecutadas.** No hay acceso a la tablet o Android
completo operativo; /dev/kvm está ausente. No se repitió el emulador software fallido.
No se ejecutó GitHub Actions ni se recibió un ledger personal del usuario.

Se comprobó además el contrato público de FANBOX con HTTPS de JDK usando SourceHttp
/FanboxConnector: 10 candidatos gratuitos, 34 páginas de historial, un cuerpo article
con 3.338 caracteres y 6 adjuntos; descarga temporal de 3.099.329 bytes con SHA-256
verificado. El archivo se eliminó al terminar. Esta comprobación no es ejecución del
APK ni instrumentación del transporte/SAF Android; ambos ámbitos quedan diferenciados.

## Funciones de esta entrega

- Menú → Fuentes de contenido: registrar creador FANBOX por identificador/URL, nombre
  e identidad opcional. Guardar/abrir una fuente no hace peticiones. Pausar, reanudar
  consultas y eliminar configuración conservando las publicaciones importadas.
- Consultas explícitas de novedades, índice real de cursores y páginas más antiguas.
  Solo publicaciones con feeRequired=0 e isRestricted=false explícitos. Las otras se
  omiten. No hay cuenta, cookies, navegador, host Peach ni consulta programada.
- Consulta individual de cuerpo: texto nativo, orden de bloques y adjuntos; parcialidad
  visible para formatos/bloques/embeds que no se resuelven. Sin ejecutar HTML/scripts.
- Página pendiente guardada en Room y revisión antes de incorporar al catálogo.
  Las fichas personales existentes conservan título, notas, estado y vínculos. Un
  resumen posterior no borra un cuerpo detallado guardado. Revisión recalculada en
  transacción y rechazo si cambió la fuente o la ficha. Conflictos no se fusionan.
- Publicaciones → Organizar → Leer contenido consultado abre la copia importada
  sin consultar la red, incluso después de eliminar la fuente.
- Guardar un adjunto individual en un documento elegido mediante el selector Android.
  HTTPS/hosts admitidos, temporal privado, tamaño/longitud/SHA-256, cancelación y
  limpieza. No se crea un medio ficticio: actualizar/añadir la carpeta lo incorpora.
- Caché conservada ante errores y 429 con plazo Retry-After sin reintento automático.
  Temporales activos protegidos; huérfanos de una interrupción se limpian al volver
  a Fuentes. Un fallo al escribir en SAF puede dejar un destino incompleto: no se
  afirma atomicidad de cualquier proveedor ni se borra un documento del usuario.
- Room v12 añade follow_sources y publication_content sin recrear dominios previos.
  Copia personal v9 con fuentes/cuerpos/adjuntos como metadatos; lectura de v1–v8,
  validación transaccional y conservación de esos datos al importar copias antiguas.

La app añade INTERNET para estas funciones opcionales. El catálogo local sigue
funcionando sin conexión. No se añadieron dependencias de ejecución; se reutilizan
HTTPS y JSON del sistema, Room y controles Android nativos. No se introduce WebView,
Python, Termux o un servidor Peach externo. FUENTES_FANBOX.md explica el uso y límites.

## APK y actualización

| Dato | Resultado |
|---|---|
| APK | Peach-Local-0.13.0-debug.apk |
| Identificador | com.peach.local |
| versionName / versionCode | 0.13.0 / 13 |
| Tamaño | 8,032,434 bytes |
| Android mínimo / objetivo | API26 / API36 |
| Persistencia | Room v12; identityHash 6a66b765ae5d8469cd3bbe3872c06019 |
| Copia personal | v9, lectura v1–v9; máximo global 8 MiB |
| Firma | RSA2048, APK v2; mismo certificado de entregas anteriores |
| Alineación | zipalign -c -P 16 4, salida 0 en ambos APK |
| Dependencias de ejecución nuevas | Ninguna |
| INTERNET | Añadido para consultas/descargas opcionales FANBOX |
| MANAGE_EXTERNAL_STORAGE | Ausente |
| .so, clave privada, fixtures SQL y JAR de comprobación externa en APK principal | Ausentes |

SHA-256 del APK:

```
3a8d4e37ff95702f2e1f0f4e8558cc839bc3168e6c27316d0fd8428eb4b6b106
```

Certificado SHA-256:

```
9fc537c4c8d0461a8565414c7a30169e592120cd314b500bee7c707f8a748484
```

Instalar sobre 0.12.0 sin desinstalar conserva el espacio de datos y ejecuta la
migración. Es aconsejable guardar una copia personal antes de actualizar. No hay
una instalación 0.13 observada en la tablet. La clave privada no está en el fuente,
ZIP o APK. El permiso INTERNET es normal de Android; no se añade acceso general al
almacenamiento. Los destinos de descarga se eligen por SAF.

Se inspeccionó el DEX para SourcesActivity, SourceHttp, FanboxConnector, SourceStore,
SourceBackup, PublicationContent, FollowSource, ReaderActivity, AgencyStore y la
identidad Room v12. El APK de pruebas contiene el caso nativo nuevo de fuentes.

## Cobertura nueva

35 casos nuevos, además de los 216 anteriores:

| Clase | Casos | Qué comprueba |
|---|---:|---|
| FanboxConnectorTest | 9 | URLs/creadores, público/gratuito explícito, cursores/hosts, orden de texto/adjuntos, nombres/extensiones y hosts externos solo como referencia, detalle restringido/ID/creador distintos, JSON inválido/HTML/duplicados/tamaño, texto acotado y parcialidad, 304 |
| SourceStoreTest | 14 | Sin red al crear/leer/pausar, consulta separada de importación, cuerpo offline y estados personales conservados, UUID previo por identidad externa y conflictos, revisión obsoleta, cursor real, error/cancelación/429/304, cambio concurrente, eliminación conservadora, copia v9 y v8, rollback y limpieza selectiva |
| SourceHttpTest | 4 | Hosts/puertos/credenciales y encabezados, bytes/longitud/SHA-256/cierre real de streams, cancelación/vacío/truncamiento/tamaño con temporales retirados, lectura API acotada |
| SourcesUiTest | 4 | Crear sin consultar, consulta e importación por confirmación, pausa/recreación sin petición extra, lectura offline tras eliminar fuente, selector nativo de destino sin iniciar descarga antes de elegir |
| SourceDocumentsTest | 3 | Copia real a OutputStream del ContentResolver de prueba y cierre, error del proveedor, huérfanos privados frente a archivos activos/otras cachés |
| MigrationV11Test | 1 | Esquema v11 auténtico exportado con publicaciones/seguimiento y dominios previos, migración a v12, conservación y tablas nuevas vacías |

Las cadenas de migración desde v1–v10 también se extienden hasta v12. Se mantienen
las pruebas anteriores de biblioteca, agencias, catálogo, lectura, metadatos, grupos,
backup y medios. Los casos sintéticos normales no requieren una fuente externa.

La instrumentación nueva persiste/reabre fuente/cuerpo y elimina configuración sin
perder la publicación. Usa una respuesta sintética y está compilada, no ejecutada.
Las 13 pruebas incluyen también PDF y otros dominios anteriores; no se certifican
motor PDF Android, TLS/SAF real, MediaCodec, microSD, batería o rendimiento del SM-X230.

## Comprobación pública real

La comprobación JDK consulta el canal oficial FANBOX, con las mismas funciones de
transporte/normalización del módulo. El JDK17 restringe Origin por defecto: un intento
inicial obtuvo 400 al omitirlo. Se contrastó esa restricción en el código fuente del
JDK y se permitió el encabezado solo en el comando de comprobación. Después respondieron
lista, páginas, cuerpo y adjunto, sin credenciales o alteración de validación TLS.
La propiedad JDK no se establece en el APK; validar transporte Android sigue pendiente.

La evidencia live-contract.json conserva timestamp UTC 2026-10-25T09:12:15Z,
creador official, post público 12383501 y conteos, sin el artículo o medios. Hash de
la descarga eliminada:

```
820ea5726fb02476ceb08f7981b4cda678e302a0b3a986bb729feca714b3c9b5
```

La herramienta opcional scripts/run-fanbox-smoke.py usa JSON-java20240303 externo
solo para ejecutar fuera de Android; JAR de 78.332 bytes, SHA-256 fijado por el script,
licencia Public Domain según su POM. No es dependencia Gradle o de ejecución del APK
ni se entrega el JAR. FUENTES_FANBOX.md documenta cómo repetirla explícitamente.

## Compilación y diagnóstico

JDK17.0.21+9, Gradle8.13, AGP8.13.0, SDK36/build-tools35.0.0,
Robolectric4.16.1/API28 y SQLiteLEGACY para Room. Comando final, con SDK/JDK y firma
original proporcionados por variables de entorno:

```
python3 scripts/run-gradle.py :app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:assembleDebugAndroidTest --console=plain
```

**BUILD SUCCESSFUL en 1m19s; 83 tareas, 16 ejecutadas y 67 al día.** Los 251 casos
de la ejecución final no están omitidos. Se conservan registros de desarrollo:

- 130-compile1: compilación Java inicial correcta.
- 130-build1: un helper de respuesta de prueba dejaba escapar JSONException de una
  interfaz que declara IOException; se precalculó la respuesta antes de inyectarla.
- 130-build2: 247 casos, un fallo del harness UI por pulsar antes de procesar el
  callback onShow del diálogo. Se corrigió el drenado del looper del helper de prueba.
- 130-ui-debug y 130-ui-fixed: diagnóstico y tres recorridos UI aprobados.
- 130-final: 250 aprobados, ambos APK y lint correctos en 2m29s.
- 130-final2: 251 aprobados después de añadir recuperación de temporales y ajustar
  extensiones de nombres/cancelación. Ambos APK y lint correctos.

No hay NoSuchMethodError, SQLiteException, CloseGuard o recursos sin cerrar en stdout/
stderr final. Permanecen avisos conocidos Invalid ID 0x0 del entorno Robolectric,
la imagen inválida de una prueba negativa y la advertencia SDK36 requiere JDK21 para
Robolectric. Las unidades se fijan a API28; ese aviso no certifica ni ejecuta API36.

Lint: ButtonStyle14, SetTextI18n8, GradleDependency7, UsableSpace2, ExifInterface1,
SwitchIntDef1, DataExtractionRules1, Overdraw1, ClickableViewAccessibility1. No se
suprimieron advertencias. Las de versiones disponibles dependen de metadatos remotos;
no se actualizaron dependencias por cambiar su cantidad. SwitchIntDef es el rechazo
intencional de BLOB en la proyección SQLite.

## Lo que falta

Solo FANBOX público es fuente operativa en esta entrega. Los otros proveedores del
registro original, cuentas/suscripciones, agenda, adjuntos externos/Gofile, galería
remota, descarga en lote o reanudación siguen pendientes. El lector conserva texto y
metadatos de adjuntos: no implica reproducir todos los embeds o formatos originales.
El catálogo sigue separado de la disponibilidad física de cada medio.

También faltan las demás diferencias de formatos, reproducción en segundo plano,
historial, versiones y UX/hardware registradas en COMPATIBILIDAD_ORIGINAL.md. No se
ha incorporado todo Peach ni se da por terminado el proyecto por este APK o el éxito
de la consulta de un proveedor. El usuario no necesita repetir las baterías sintéticas
que ya se ejecutaron; la validación Android real mantiene su alcance pendiente.
