> Incidencia posterior en la tablet (25 de octubre de 2026): el usuario comunicó
> «Dice que la fuente denegó el acceso público», al consultar Patreon/panpiano.
> Chrome en la misma tablet abrió el perfil después de completar un CAPTCHA.
> El rechazo de la app corresponde a HTTP401 o403; la versión0.14 no los distingue.
> Es compatible con la verificación humana observada, pero no se capturaron los
> encabezados Android para confirmar el proveedor del CAPTCHA o su causa exacta.
> Resolverlo en Chrome no transfiere su sesión al transporte de Peach.
> Patreon queda bloqueado en ese entorno y no se registra aceptación general de0.14.
> Una comprobación JDK del mismo creador recuperó una tarjeta pública; no sustituye
> el resultado de Android. No hay solución de CAPTCHA implementada o verificada.

# Peach Local 0.14.0 — Patreon público y pruebas

Fecha: 25 de octubre de 2026, America/Hermosillo. Tablet objetivo Samsung Galaxy
Tab A11+ SM-X230. El usuario aceptó generalmente 0.13.0 con «Listo funciona todo,
sigue con lo demás»; PRUEBAS_0_13.md conserva el alcance. No equivale a comprobar
cada ruta de red/SAF ni a tener acceso directo a la tablet. Al emitir este informe aún no se había comunicado ejecución física de0.14;
la incidencia posterior de Patreon figura al inicio.

## Resultado

**272 pruebas locales aprobadas, 0 fallos, 0 errores, 0 omitidas, 48 clases.**
Lint: **0 errores y 36 advertencias**. Ambos APK compilados, firma original
verificada y zipalign correcto. **14 pruebas instrumentadas compiladas, 0 ejecutadas.**
Sin dispositivo conectado ni /dev/kvm. No se ejecutó GitHub Actions.

El nuevo conector reconoció una tarjeta real del canal público oficial
patreonforcreators mediante HTTPS de JDK, explícitamente parcial, sin fecha exacta,
sin consultar cuerpo o adjuntos. FANBOX respondió de nuevo con 10 candidatos,
34 páginas de historial y un cuerpo article de 3.338 caracteres y 6 adjuntos.
No se descargó ningún adjunto en esta ejecución. La descarga real de 0.13 sigue
siendo evidencia histórica. Estas comprobaciones JDK no ejecutan el APK Android.

## Qué incorpora

- Menú → Fuentes de contenido → Añadir fuente: selector FANBOX / Patreon · tarjetas
  públicas. Registrar, abrir o recrear la pantalla no inicia consultas.
- Patreon usa solo el HTML público que entrega el sitio al visitante anónimo.
  Revisión antes de importar y lectura local del adelanto. Cada tarjeta figura
  como parcial; puede corresponder a una publicación de pago. Una fecha ausente
  permanece desconocida. Sin cuenta, cuerpo completo, historial o adjuntos Patreon.
- Se reconocen enlaces antiguos y actuales, Unicode en slugs y fragmentos SSR de
  tarjetas en contenedores S:... específicos. Se excluyen scripts, bootstrap JSON,
  plantillas y ocultos ordinarios. No se ejecuta JavaScript ni se cargan recursos.
- HTTPS acotado, redirecciones dentro del proveedor/creador aprobado, 2 MiB de HTML,
  hasta 100 tarjetas y 5.000 enlaces inspeccionados. Página sin tarjetas reconocibles,
  cambio de canónica, bloqueo o error conservan la caché pendiente previa.
- Identificadores separados por proveedor. Los UUID de FANBOX no cambian. Fichas
  personales existentes conservan título, notas, estado, identidad y documento.
  Resúmenes nuevos actualizan resúmenes previos; no reemplazan un cuerpo detallado.
- FANBOX conserva consultas gratuitas, cursores, cuerpos compatibles y descarga
  individual mediante selector Android. No hay consultas periódicas o automáticas.
- Room continúa en v12, sin cambio de tablas. Copia personal v10, lectura v1–v10,
  validación transaccional y límites existentes. Restaurar no consulta la red.

La app sigue siendo nativa y autónoma. El catálogo y contenido ya guardado funcionan
sin conexión; consultar sitios públicos requiere Internet. No depende de Windows,
Termux, WebView o un servidor Peach. No incluye medios ni artículos de terceros.
FUENTES_PATREON.md documenta el uso y sus límites.

## APK y actualización

| Dato | Resultado |
|---|---|
| APK | Peach-Local-0.14.0-debug.apk |
| Identificador | com.peach.local |
| versionName / versionCode | 0.14.0 / 14 |
| Tamaño | 8.257.260 bytes |
| Android mínimo / objetivo | API26 / API36 |
| Persistencia | Room v12; identityHash 6a66b765ae5d8469cd3bbe3872c06019 |
| Copia personal | v10; lectura v1–v10; máximo global 8 MiB |
| Firma | RSA2048, APK v2; mismo certificado anterior |
| Alineación | zipalign -c -P 16 4; salida 0 en ambos APK |
| Dependencia de ejecución nueva | org.jsoup:jsoup:1.23.2, MIT; sin transitivas propias |
| Permisos | Los mismos que 0.13; INTERNET ya estaba presente |
| MANAGE_EXTERNAL_STORAGE | Ausente |
| .so, claves privadas, SQL/SQLite y JAR de herramientas en APK | Ausentes |

SHA-256 del APK:

```
1ae1b1bfea276cf589304d6aaae73a38bc73032d824d92bade86c6a111a86adf
```

Certificado SHA-256:

```
9fc537c4c8d0461a8565414c7a30169e592120cd314b500bee7c707f8a748484
```

Instalar sobre 0.13.0 sin desinstalar permite conservar datos con el mismo paquete
y certificado. Se recomienda una copia personal previa. Al emitir el informe no se había observado la actualización; posteriormente el
usuario comunicó ejecutar0.14 y el rechazo de Patreon indicado al inicio. La clave privada no se incluye.

Se inspeccionó DEX: PatreonConnector, PatreonUrls, SourceProviders, SourcePage, jsoup
y la identidad Room v12 están presentes. El APK de pruebas contiene el nuevo caso
nativePatreonHtmlParserAndProviderNamespacesPersistWithoutNetwork. El APK principal
incluye META-INF/jsoup/LICENSE. El APK instrumentado mide 3.509.964 bytes y su SHA-256 es
773f01a9effdde17bfa7045d38897019a2fd2a21299566f030ff902cc22fbee3.

## Cobertura nueva

21 casos nuevos sobre los 251 anteriores:

| Clase | Casos | Cobertura |
|---|---:|---|
| PatreonConnectorTest | 11 | Normalización/rutas, identidad de post/creador, Unicode, parcialidad, fechas, exclusión de ocultos/scripts, deduplicación, tamaño, canónica, 304 y fragmentos SSR reales reproducidos con HTML sintético |
| PatreonSourceStoreTest | 8 | Espacios por proveedor y UUID FANBOX, operaciones no soportadas sin HTTP, actualización de adelantos, conservación de cuerpo/ficha, UUID importado, copias v10/v9, rollback, caché ante HTML incompatible |
| PatreonSourcesUiTest | 2 | Selector y alta sin HTTP; consulta/revisión/importación, lectura de tarjeta, controles adecuados y recreación sin petición extra |

Se mantienen todos los casos previos de lectura, catálogo, agencias, deseos, fuentes,
SAF simulado, descargas y migraciones. Los fixtures nuevos contienen HTML sintético,
no copias de páginas/artículos. La instrumentación nueva compila el parser jsoup
nativo y persiste/reabre ambas fuentes, sin red; todavía no se ejecutó en Android.

## Dependencias y contrato público

Se contrastó el conector del original en el commit
 de22796c04919aaa057d77930c33c81313765569: Patreon también extrae tarjetas públicas.
El proyecto original es AGPL-3.0-or-later. hashes de follow_sources.py y
follow_providers.py están en evidence/0.14.0/upstream-patreon.json.

jsoup1.23.2 se usa únicamente con Jsoup.parse sobre texto recibido por SourceHttp;
no se utiliza su cliente de red. Java17, minSdk26 y desazucarado existentes se
conservan. JAR 537.806 bytes, SHA-256
 e9d8c856856680427f096d156f02a414289985c930998fcb519ce5be39b42003.
Licencia MIT completa en licenses/MIT-jsoup.txt, avisos actualizados y grafo Gradle
completo incluido. org.jspecify ya pertenece a otra rama del grafo; jsoup no añade
una dependencia transitiva propia.

Patreon: checkedAt 2026-10-25T09:59:25.752451322Z, creador patreonforcreators,
1 tarjeta, post 138135962, 1 fecha desconocida, todas parciales, 0 cuerpos y 0
adjuntos solicitados. Un primer intento no reconoció las tarjetas porque estaban
en fragmentos SSR ocultos temporalmente. Se verificó la estructura servida, se
limitó la excepción a contenedores div hidden id S:... y se añadió regresión.
No se ejecuta su código de inserción. Solo hashes/longitudes del HTML real se guardan,
no ese HTML. El resultado depende del HTML público que el sitio entregue en cada momento.

FANBOX: checkedAt 2026-10-25T10:01:53.166408269Z, creador official,
post 12383501, 10 candidatos, 34 páginas, 3.338 caracteres y 6 descriptores.
Son comprobaciones externas JDK con SourceHttp y los conectores. Las herramientas
opcionales scripts/run-patreon-smoke.py y run-fanbox-smoke.py verifican sus JAR.
JSON-java20240303 es herramienta Public Domain externa, no dependencia de la app,
y ningún JAR de comprobación se entrega. El flag de Origin del JDK usado para
FANBOX no se establece en el APK. HTTPS/SAF Android real siguen pendientes.

## Compilación y diagnóstico

JDK17.0.21+9, Gradle8.13, AGP8.13.0, SDK36/build-tools35.0.0,
Robolectric4.16.1/API28 y SQLiteLEGACY para Room. Con SDK/JDK y firma en variables:

```
PEACH_BUILD_ROOT=/tmp/peach-local-build-140 python3 scripts/run-gradle.py --init-script scripts/build-outside-workspace.init.gradle :app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:assembleDebugAndroidTest --console=plain
```

**BUILD SUCCESSFUL en 1m14s; 83 tareas, 19 ejecutadas y 64 al día.**
Los XML finales contienen los 272 casos, no omitidos. El build externo previo
compiló en frío las 83 tareas en 2m12s con 271 casos; la última regresión SSR elevó
el total a 272. No se usa el app/build anterior del workspace.

Un intento previo pasó 268 unidades y falló al empaquetar: D8 encontró un archivo
.rsync-tmp transitorio desaparecido en intermedios sincronizados. Se conservó el diagnóstico relevante, se movieron las salidas a
/tmp mediante un init script optativo y se completaron ambos APK. No fue un error
funcional probado de la app. El host también puede reemplazar logs activos dentro
del workspace; los registros de build se copian desde fuera al cerrar el proceso.
No se oculta el fallo inicial ni se distribuye el log completo del daemon.

Se revisaron stdout/stderr finales: sin NoSuchMethodError, SQLiteException,
CloseGuard o recursos sin cerrar. Siguen los avisos conocidos Invalid ID0x0 de
Robolectric, imagen inválida de una prueba negativa y SDK36 requiere JDK21;
las unidades usan API28. No se afirma ejecución de API36 por este aviso.

Lint: ButtonStyle14, SetTextI18n8, GradleDependency5, UsableSpace2,
ExifInterface1, AndroidGradlePluginVersion1, NewerVersionAvailable1, SwitchIntDef1,
DataExtractionRules1, Overdraw1 y ClickableViewAccessibility1. No se suprimieron
advertencias. Las de versiones disponibles dependen de metadatos remotos.

## Pendiente y entrega

Patreon no incorpora cuerpos completos, suscripciones, paginación histórica o
adjuntos. Restan otros proveedores, autenticación oficial, agenda optativa,
galerías remotas, lotes/reanudación y adjuntos externos. También siguen las
diferencias de formatos, audio en segundo plano, historial/versiones y UX/hardware
registradas en COMPATIBILIDAD_ORIGINAL.md. Catalogar un formato no prueba decodificarlo.
No se ha incorporado todo Peach ni se declara terminado el proyecto.

El ZIP incluye fuente, historial Git completo, APK instrumentado compilado,
resultados XML/HTML y evidencia de build/lint/paquete. No incluye la clave, SDK,
JDK, medios externos ni páginas reales. La aceptación de 0.13 queda registrada
como general. No es necesario repetir las baterías sintéticas ejecutadas; la
validación Android real mantiene su alcance pendiente.
