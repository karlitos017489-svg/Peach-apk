> Actualización posterior del usuario (25 de octubre de 2026): confirmó funcionamiento
> general de 0.15.0 y comunicó que las consultas de Patreon volvieron a mostrar
> resultados al desactivar su VPN. Por tanto, el rechazo previamente comunicado
> ya no permanece reproducido en su uso actual. La relación con la VPN es una
> observación del usuario, sin captura de tráfico o diagnóstico del servidor.
> No se implementó transferencia de cookies ni una solución de CAPTCHA.
> No se infieren cuerpos completos, suscripciones, adjuntos Patreon, todas las
> funciones individuales o instrumentación ejecutada. El informe inferior conserva
> los resultados y límites históricos de su emisión.

# Peach Local 0.15.0 — lectura TAR/GZIP y pruebas

Fecha: 25 de octubre de 2026, America/Hermosillo. Tablet objetivo: Samsung Galaxy
Tab A11+ SM-X230. La última aceptación general registrada corresponde a 0.13.0.
El usuario comunicó rechazo de Patreon/panpiano en 0.14; Chrome abrió tras completar
un CAPTCHA. Se continúa con otras funciones por su instrucción «OK sigue con lo demás».
No se registra aceptación general de 0.14 ni se considera resuelto su bloqueo.
PRUEBAS_0_14.md y user-incident-0.14.0-patreon.json conservan el detalle.

## Resultado

**290 pruebas locales aprobadas,0 fallos, 0 errores, 0 omitidas, 49 clases.**
Lint: **0 errores y43 advertencias**. APK principal e instrumentado compilados,
firmados con el certificado original y alineación verificada. **15 pruebas
instrumentadas compiladas,0 ejecutadas**. No hay acceso directo a la tablet ni
/dev/kvm. No se ejecutó GitHub Actions. No hay aceptación física de 0.15 comunicada.

La entrega añade lectura local TAR, TAR.GZ/TGZ y GZIP. Permite explorar el índice,
abrir imágenes y PDF/texto compatibles, navegar el álbum y guardar posición por
entrada. Se conserva el lector ZIP previo, los datos, copias y otras funciones.
No depende de Internet, computadora, Termux, WebView o un servidor Peach.

## Funciones y límites

- TAR: USTAR y extensiones GNU de nombre largo/PAX acotadas, con nombres Unicode,
  prefijos ./ y orden natural. Índice buscable; solo archivos regulares se abren.
  Enlaces duros/simbólicos y entradas especiales se listan sin seguirlos.
- TAR.GZ/TGZ: expansión GZIP privada completa antes de preparar el índice TAR.
  GZIP simple: el nombre externo sin.gz determina la entrada (notas.txt.gz,
  foto.png.gz, documento.pdf.gz). No se usa el nombre interno de la cabecera.
  Miembros GZIP concatenados forman un solo flujo.
- Las imágenes forman un álbum, los PDF usan PdfRenderer y los textos son planos.
  Reanudación, favorito y leído corresponden al contenedor. Las entradas no crean
  documentos separados en el catálogo. Actualizar la carpeta clasifica TGZ como comprimido.
- Origen/TAR expandido hasta 512 MiB; entrada elegida/GZIP simple hasta 64 MiB.
  Hasta10.000 cabeceras TAR físicas,64 KiB de metadatos por cabecera,4 MiB acumulados
  y8 extensiones consecutivas. Textos hasta 1 MiB/200.000 caracteres; imágenes2048 px.
- Se rechazan rutas inseguras, alias duplicados, checksums de cabecera inválidos,
  offsets/tamaños truncados, finales incompletos, TAR concatenados, sparse y
  overrides PAX de tamaño. Pueden rechazarse TAR válidos fuera de este subconjunto.
  TAR no tiene CRC de datos: se verifica cabecera/tamaño, no integridad de cada byte.
- GZIP verifica su trailer al expandir. Límites, interrupción, espacio disponible y
  plazo de 90 s se comprueban en los bucles propios. No se promete cancelar al instante
  cada operación interna o de un proveedor SAF. Un error no publica salida parcial.
- Solo se escriben nombres fijos de caché privada. Los originales no se modifican.
  TAR.GZ requiere espacio para origen, TAR expandido y entrada, además de margen.
  Sesiones activas conservan sus cachés; al cerrar/recuperar se limpian temporales.

No hay reproducción AV dentro del comprimido, extracción general, anidados,
RAR/CBR o7z en esta entrega. LECTURA_TAR_GZIP.md explica uso y límites.
Room sigue en v12 y la copia personal en v10 (lectura v1–v10), sin migrar tablas
ni recrear documentos. La copia incluye posiciones, no archivos o permisos SAF.

## Incidencia Patreon

0.14 combinaba HTTP401/403 en «La fuente denegó el acceso público». El usuario
vio ese mensaje con panpiano; en Chrome completó un CAPTCHA y accedió. Un nuevo
ensayo JDK del mismo creador reconoció1 tarjeta parcial,0 cuerpos y0 adjuntos.
Ese resultado no representa la petición desde Android. No se capturaron código
exacto o encabezados nativos para confirmar el proveedor del CAPTCHA.

0.15 conserva el estado y muestra el código HTTP de un rechazo401/403. Explica que
puede requerir sesión o verificación que el conector no completa. No clasifica todo
403 como CAPTCHA, no transfiere cookies de Chrome y no introduce reintentos automáticos.
Patreon sigue bloqueado en el entorno comunicado. No se anuncia esta entrega como
solución de CAPTCHA. La biblioteca local y las otras funciones continúan disponibles.

Referencias de arquitectura contrastadas:
https://chromium.googlesource.com/chromium/src/+/HEAD/docs/security/custom-tabs-faq.md
(la app no accede a cookies/DOM de Custom Tabs) y
https://developers.cloudflare.com/cloudflare-challenges/reference/supported-browsers/
(limitaciones de clientes sin JavaScript y navegadores embebidos). No se identifica
Cloudflare como proveedor confirmado del desafío del usuario.

## APK y actualización

| Dato | Resultado |
|---|---|
| APK | Peach-Local-0.15.0-debug.apk |
| Identificador | com.peach.local |
| versionName/versionCode |0.15.0 /15 |
| Tamaño | 9,549,723 bytes |
| Android mínimo/objetivo | API26/API36 |
| Persistencia | Room v12, identityHash6a66b765ae5d8469cd3bbe3872c06019 |
| Copia personal | v10; lectura v1–v10 |
| Firma | RSA2048, APK v2, certificado original |
| Alineación | zipalign -c -P16 4: salida0 en ambos APK |
| Permisos | Idénticos a 0.14; sin MANAGE_EXTERNAL_STORAGE |
| .so, claves, fixtures SQL/SQLite y JAR externos en APK principal | Ausentes |
| Nuevas licencias/NOTICE explícitos |8 assets, comparados byte a byte con las copias originales |

SHA-256 del APK:

```
b3359bb609fa88187b9ee289dad44810a63cc2653363f9cf9aff70e65d98fe48
```

Certificado SHA-256:

```
9fc537c4c8d0461a8565414c7a30169e592120cd314b500bee7c707f8a748484
```

Instalar encima de 0.14 o0.13 sin desinstalar permite conservar datos con el mismo
paquete/certificado. Se recomienda una copia personal previa. La instalación de 0.15
no se ha observado en la tablet. No se distribuye la clave privada.

Se inspeccionó DEX para ArchiveBook, ArchiveFiles, TarBook, GzipBook, TarFile e
identidad Room. El APK principal no incluye los archivos sintéticos de prueba.
El APK instrumentado contiene el nuevo caso nativo, mide 3,495,670 bytes y tiene
SHA-256 7449cf06b108af730ae5bc762e4c92cf1ff367eee0dc2f818ff0ed1c8e36610f.

## Cobertura nueva

18 casos nuevos sobre los272 anteriores:

| Clase | Casos nuevos | Qué comprueban |
|---|---:|---|
| ArchiveBookTest |13 | Fixtures USTAR/PAX/GNU independientes; nombres largos/Unicode, orden natural, lectura seleccionada, enlaces/especiales/anidados no abribles, rutas/alias/duplicados, checksum/final/offsets, metadata/sparse/límites, TAR.GZ/TGZ CRC, GZIP simple/concatenado/cabecera insegura, expansión excesiva, cancelación y conservación de vista previa |
| ReaderSessionTest |3 | Imágenes realmente decodificadas y texto en TAR/TGZ/GZIP, navegación, sesiones/caché, cancelación; PDF con backend de prueba explícito |
| ReaderUiTest |2 | Índice/búsqueda/lectura/recreación de TGZ, reanudación sin duplicar apertura, copia/restauración de posición GZIP y ruta biblioteca→lector |

Se mantienen todas las pruebas anteriores, incluidas migraciones, ZIP, fuentes,
lectura, agencias, catálogo, listas, deseos y copias. Los XML finales contienen
290 casos,0 omitidos; se revisaron stdout/stderr. Sin NoSuchMethodError,
SQLiteException, CloseGuard, recursos sin cerrar o excepciones de hilo no esperadas.
Persisten los avisos conocidos de Robolectric: Invalid ID0x0, imagen inválida de una
prueba negativa y SDK36 requiere JDK21. Las unidades usan API28; no certifican API36.

Los TAR/GZIP de prueba fueron generados con Python tarfile/gzip, fecha fija y texto
propio/PNG sintético previo. scripts/generate-archive-fixtures.py permite regenerarlos; provenance.json guarda hashes.
No se copia una biblioteca de medios ni artículos externos.

La instrumentación nueva compila una comprobación de lectura TAR.GZ que genera PNG y
PDF con Android, verifica píxeles/páginas y ausencia de directorios extraídos. Está
**compilada, no ejecutada**. PDF real, HTTPS/SAF reales, microSD, códecs, memoria,
batería y rendimiento físico del SM-X230 siguen sin certificarse.

## Dependencias

Una dependencia directa nueva: Commons Compress 1.28.0 (Apache-2.0). Transitivas:
Commons IO 2.20.0, Lang3 3.18.0 y Codec 1.19.0. El grafo efectivo está en la evidencia.
No se añaden dependencias opcionales XZ, Brotli, ASM o zstd-jni. La presencia de
clases para otros formatos en el JAR no implica soporte del producto.
GZIP usa java.util.zip; ZIP mantiene su implementación previa.

Los cuatro JAR resueltos se cotejaron con checksums Maven y se registró SHA-256.
Licencias/NOTICE completos se conservan en licenses/ y assets/licenses/ porque
Android omite sus nombres META-INF genéricos. Se verificaron los8 assets en el APK.
Archivo archive-dependencies.json documenta hashes y URLs. Se revisaron las notas
oficiales de versión/seguridad de Apache, incluida la corrección histórica de
PAX timestamp anterior a 1.24; no se afirma ausencia de vulnerabilidades desconocidas.
https://commons.apache.org/proper/commons-compress/security.html

## Compilación y diagnóstico

JDK17.0.21+9, Gradle8.13, AGP8.13.0, SDK36/build-tools35.0.0,
Robolectric4.16.1/API28 y SQLiteLEGACY para Room. Con SDK/JDK/firma originales:

```
PEACH_BUILD_ROOT=/tmp/peach-local-build-150 python3 scripts/run-gradle.py --init-script scripts/build-outside-workspace.init.gradle :app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:assembleDebugAndroidTest --console=plain
```

**BUILD SUCCESSFUL en 1m20 s; 83 tareas, 19 ejecutadas y 64 al día.**
Salidas autoritativas en /tmp/peach-local-build-150/app; no se usa app/build antiguo.
Los logs activos permanecieron fuera del workspace hasta terminar.

- Compilación inicial del módulo correcta en 27 s.
- Primer harness de prueba usó Files.readString/writeString, no disponibles en la
  superficie Android de compilación; se sustituyeron por readAllBytes/write.
- Ensayo dirigido de 24 casos:1 fallo detectó que isFile de Commons incluye FIFO.
  La implementación pasó a aceptar únicamente flags0/NUL de archivo regular;
  se añadieron regresiones de prefijo ./, alias y nombre GZIP interno inseguro.
- Build completo:290 aprobadas y ambos APK en 2m8 s. La inspección de paquete detectó
  licencias META-INF omitidas; se añadieron copias explícitas como assets.
- Build final:290 aprobadas, ambos APK y lint correctos; assets cotejados.

Lint final: ButtonStyle14, GradleDependency12, SetTextI18n8, UsableSpace3,
ExifInterface1, NewerVersionAvailable1, SwitchIntDef1, DataExtractionRules1,
Overdraw1 y ClickableViewAccessibility1. Total43 advertencias,0 errores.
No se suprimieron advertencias. Las de versiones dependen de metadatos remotos;
el primer build dio41 y el final43. No se actualizaron otras dependencias por ese
cambio. UsableSpace no certifica disponibilidad real de todo proveedor SAF.

## Pendiente

Patreon CAPTCHA, otros proveedores/cuentas, agenda, medios remotos/adjuntos externos,
lotes y descargas reanudables siguen pendientes. También RAR/CBR/7z, ampliar TAR/PAX,
ZIP64/cifrado/volúmenes, audio en segundo plano, historial/versiones, EPUB/ofimática,
PDF avanzado, sincronización y UX/hardware. Se mantiene la matriz de compatibilidad.
No se ha incorporado todo Peach y el proyecto sigue abierto.

El ZIP incluye fuentes, historial Git, APK instrumentado compilado, resultados
XML/HTML, licencias y evidencia. Excluye clave, SDK/JDK, JAR de herramientas y
medios externos. No se requiere repetir las baterías sintéticas ejecutadas.
