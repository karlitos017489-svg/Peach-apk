# Validación comunicada de 0.16.0

El 25 de octubre de 2026 (America/Hermosillo) el usuario escribió:
«Todo funciona, sigue con lo demas». Se registra aceptación general en SM-X230.
No demuestra ejecución individual de todas las variantes 7z, instrumentación,
mediciones de rendimiento o acceso directo a su tablet. La instrumentación de la
entrega permanece compilada, no ejecutada desde este entorno.
Patreon conserva el resultado comunicado previamente al desactivar la VPN;
no se implementó una solución de CAPTCHA o acceso a publicaciones privadas.
La evidencia estructurada está en evidence/user-validation-0.16.0.json.

El informe de compilación original se conserva a continuación como registro histórico.

---

# Peach Local 0.16.0 — lector 7z y pruebas

Fecha: 25 de octubre de 2026, America/Hermosillo. Tablet objetivo Samsung Galaxy
Tab A11+ SM-X230. El usuario confirmó funcionamiento general de 0.15.0 y que las
consultas de Patreon volvieron a mostrar resultados después de desactivar su VPN.
Se registra esa observación sin atribuir una política concreta al servidor o afirmar
que se haya implementado una solución de CAPTCHA. PRUEBAS_0_15.md y la evidencia
user-validation-0.15.0.json conservan el alcance y la cita exacta.
No se infiere una prueba de cada formato/función, acceso directo a la tablet,
contenidos privados o ejecución de instrumentación. 0.16 aún no tiene aceptación física.

## Resultado

**306 pruebas locales aprobadas, 0 fallos, 0 errores, 0 omitidas y 50 clases.**
Lint: **0 errores y 36 advertencias**. Ambos APK compilados, firma original y
zipalign verificados. **16 pruebas instrumentadas compiladas, 0 ejecutadas.**
Sin /dev/kvm ni dispositivo Android conectado a este entorno. No se ejecutó
GitHub Actions. No se repitió un emulador software que había fallado previamente.

La nueva función es lectura local 7z: índice buscable, imágenes y PDF/texto
compatibles, navegación y reanudación. Se reutilizan el lector y el estado de los
contenedores. ZIP, TAR/GZIP y los dominios anteriores pasan sus regresiones.
El APK sigue siendo nativo y autónomo; no requiere computadora, Termux, Python,
WebView o un servidor Peach para usar su biblioteca local.

## Uso y alcance

Abrir un .7z catalogado utiliza el lector nativo. El índice muestra archivos,
permite buscar por nombre y abrir entradas compatibles. Las imágenes se ordenan
naturalmente; PDF usa el adaptador PdfRenderer y el texto se muestra sin ejecutar
HTML/scripts. Favorito, leído y progreso se guardan para el contenedor, sin crear
un medio por cada entrada o mezclar el progreso con reproducción AV.

Se admitieron en fixtures propios LZMA/LZMA2, COPY, archivos sólidos y no sólidos,
cabeceras públicas comprimidas o sin comprimir, Unicode y entradas vacías. Los
archivos sólidos pueden requerir decodificar entradas anteriores al seleccionar
una posterior. Se reabre el decodificador por selección, lo que añade relectura
pero evita reutilizar un flujo fallido o el estado de una entrada vacía.

| Límite | Alcance |
|---|---|
| Origen | 512 MiB, copiado desde URI SAF a caché privada |
| Índice | 10.000 entradas, cabecera cruda y expandida hasta 4 MiB cada una |
| Tamaño declarado acumulado | 512 MiB para todas las entradas |
| Entrada elegida | 64 MiB materializados |
| Memoria configurada | 64 MiB para estimación de índice y decodificadores LZMA/LZMA2; no es cuota global de RAM |
| Cabecera codificada | Una carpeta, un flujo y un codec COPY/LZMA/LZMA2; se rechazan esquemas más complejos |
| Lectura propia | Canal de solo lectura, interrupción, plazo de 90 s y presupuesto de bytes; no se garantiza interrupción instantánea de cada operación interna |
| Vista | Límites previos de imagen 2048 px y texto 1 MiB/200.000 caracteres |

Las listas, PDF, imágenes y otros componentes necesitan memoria adicional al límite
del decodificador. No todos los codecs de Commons respetan ese parámetro; no se
anuncia soporte de cada variante del formato. Cabeceras cifradas, contraseñas,
volúmenes, SFX, recuperación de dañados, AV interno, comprimidos anidados y extracción
general siguen fuera de alcance. RAR/CBR todavía no dispone de lector.

Se comprueban firma, CRC de cabecera inicial/índice, offsets y final sin datos
adicionales. Los CRC de datos declarados se verifican al leer; no se afirma integridad
cuando el formato no declara CRC. Una entrada vacía con CRC no cero se rechaza.
Nombres inseguros, vacíos o duplicados se rechazan. Enlaces Unix, puntos reparse de
Windows, anti-items y tipos especiales quedan sin lector: no se siguen rutas.
Solo se escriben nombres fijos en caché privada. Un fallo no reemplaza la vista
anterior ni publica entry-part. Al cerrar se retiran temporales, conservando las
sesiones activas de otras lecturas. Los originales no se escriben.
LECTURA_7Z.md explica el subconjunto y sus costes.

## Patreon y validación comunicada

El rechazo de 0.14/0.15 ya no se reproduce en el uso actual comunicado por el
usuario: volvió a ver resultados al apagar la VPN. La relación exacta con el
servidor no se capturó; no se identifica proveedor de CAPTCHA o causa de un 403
con certeza. Se actualizan informes y matriz conservando su historial.

No se añadió transferencia de cookies, inicio de sesión o resolución de CAPTCHA.
El conector continúa leyendo solo tarjetas públicas/parciales; no cuerpos privados,
suscripciones o adjuntos Patreon. Las consultas necesitan Internet; lo ya guardado
sigue disponible offline. No se repitieron consultas públicas externas para esta
entrega: se conservan las comprobaciones JDK históricas y el nuevo resultado del
usuario como ámbitos distintos. Las unidades usan respuestas sintéticas.

## Datos y APK

Room sigue en **v12**, identityHash 6a66b765ae5d8469cd3bbe3872c06019.
La copia personal permanece en **v10**, lectura v1–v10 y límite global de 8 MiB.
Se reutiliza reader_progress sin migraciones o nuevas identidades. Las copias
incluyen posición por entrada, no archivos 7z o permisos SAF.

| Dato | Resultado |
|---|---|
| APK | Peach-Local-0.16.0-debug.apk |
| Paquete | com.peach.local |
| Versión / código | 0.16.0 / 16 |
| Tamaño | 9,652,338 bytes |
| Android mínimo / objetivo | API26 / API36 |
| Firma | RSA2048, APK v2, certificado original |
| Alineación | zipalign -c -P16 4; salida 0 en ambos APK |
| Permisos | Iguales a 0.15 y 0.14; sin MANAGE_EXTERNAL_STORAGE |
| Ejecutables, .so, claves privadas, SQL/SQLite y JAR de herramientas en APK principal | Ausentes |
| Fixtures 7z en APK principal | Ausentes; el fixture Android está solo en el APK instrumentado |
| Nueva licencia | COPYING original 0BSD, comparado byte a byte con el asset empaquetado |

SHA-256 del APK:

```
02087db0e55879f6dfcdf9df616b13b98b83c324b84cbb4ad48ff713613fcff2
```

Certificado SHA-256:

```
9fc537c4c8d0461a8565414c7a30169e592120cd314b500bee7c707f8a748484
```

Se puede instalar sobre 0.15 sin desinstalar al conservar paquete/certificado y
versionCode creciente. Se recomienda una copia personal previa. No se ha observado
esa instalación concreta de 0.16 en la tablet. No se distribuye la clave privada.

Se inspeccionó DEX para SevenZipBook, ArchiveBook, TarBook/GzipBook, LZMA2InputStream,
TarFile y la identidad Room. El APK instrumentado contiene el nuevo caso 7z nativo,
mide 3,497,009 bytes y tiene SHA-256 9834416c41ccff8d172903a4022559a0809c8b5b5ed55a4498e55712bd2f6e5e.

## Cobertura nueva

16 casos nuevos sobre los 290 anteriores:

| Clase | Nuevos | Cobertura |
|---|---:|---|
| SevenZipBookTest | 11 | Fixtures independientes LZMA/LZMA2/COPY y sólidos; selección en ambos sentidos, vacíos, CRC dañado sin reemplazar vista, firma/cabecera/truncamiento, límites antes de reservar cabecera expandida, cifrado, memoria/diccionario/tamaños, rutas/duplicados/10.001 entradas, tipos especiales, cancelación/recuperación y CRC no cero en flujo vacío |
| ReaderSessionTest | 3 | Imágenes realmente decodificadas, texto, navegación, vacíos y limpieza; cifrado sin temporales; PDF con backend de prueba explícito |
| ReaderUiTest | 2 | Índice/búsqueda/lectura/recreación, contador sin duplicar, progreso separado de AV, copia/restauración y ruta biblioteca→lector |

Las 306 unidades finales no están omitidas. Se mantienen todos los casos previos
de ZIP, TAR/GZIP, fuentes, migraciones, catálogo, metadatos, agencias, seguimiento,
lectura y copias. Se revisaron stdout/stderr: sin NoSuchMethodError, SQLiteException,
CloseGuard, recursos sin cerrar o excepciones inesperadas de hilo. Persisten los
avisos conocidos de Robolectric Invalid ID0x0, imagen inválida de una prueba negativa
y el aviso SDK36 requiere JDK21. Las unidades se fijan a API28, no ejecutan API36.

El fixture Android nuevo usa un archivo LZMA2 sólido propio para comprobar imagen,
texto y ausencia de directorios extraídos con el runtime Android. Está compilado,
**no ejecutado**. Las pruebas PDF de JVM usan un backend explícito; no se certifica
PdfRenderer físico por esos casos. TLS/SAF reales, memoria/rendimiento/batería,
microSD y codecs del SM-X230 no se certifican con esta suite.

## Dependencias y fixtures

Se añade **org.tukaani:xz:1.12**, licencia **0BSD**, sin nuevas transitivas propias.
Se mantiene Commons Compress 1.28.0 y su grafo anterior. XZ for Java no es XZ Utils:
no se incluye una biblioteca nativa o 7zz en la app. El JAR multiversión conserva
código base Java8; la compatibilidad física de Android continúa pendiente de las
pruebas instrumentadas. La versión 1.12 corrige problemas publicados de 1.10/1.11,
según NEWS de su distribución; no se afirma ausencia de fallos desconocidos.

JAR resuelto: 168,792 bytes, SHA-256
3e158a87bd73d8afb4b6e8239c013b7d049c48563f45860ce99cd2e448cf4a6b. Se cotejó checksum Maven y el grafo efectivo.
COPYING se extrajo sin cambios del ZIP oficial y se conserva en licenses/ y
assets/licenses/. La fuente y licencia son https://tukaani.org/xz/java.html.
Hashes/URLs en evidence/0.16.0/xz-dependency.json. Los avisos Apache existentes
permanecen empaquetados; no se añaden JNI/Brotli/Zstandard opcionales.

Se inspeccionó el código de Commons correspondiente: usar setMaxMemoryLimitKiB,
no el método deprecado setMaxMemoryLimitKb que divide por 1024 en esa versión;
limitar aparte la salida de la cabecera comprimida antes de su reserva, y no pedir
un flujo de decodificador para entradas vacías. La auditoría se conserva por hash
en commons-sevenzip-audit.json, con referencia a la API oficial:
https://commons.apache.org/proper/commons-compress/apidocs/org/apache/commons/compress/archivers/sevenz/SevenZFile.Builder.html

Fixtures hechos con 7-Zip 26.05 oficial para Linux, solo herramienta de desarrollo.
Contienen texto propio, PNG sintético previo y ceros para tamaños declarados; no
medios de terceros. El ejecutable no se distribuye. Provenance.json registra hashes,
y scripts/generate-sevenzip-fixtures.py acepta un 7zz explícito para regenerarlos.
Los fixtures cifrados usan la contraseña pública test-only y sales aleatorias, por
lo que regenerarlos puede cambiar sus hashes. No contienen credenciales reales.

## Compilación y diagnóstico

JDK17.0.21+9, Gradle8.13, AGP8.13.0, SDK36/build-tools35.0.0,
Robolectric4.16.1/API28 y SQLiteLEGACY para Room. Con SDK/JDK/firma originales:

```
PEACH_BUILD_ROOT=/tmp/peach-local-build-160 python3 scripts/run-gradle.py --init-script scripts/build-outside-workspace.init.gradle :app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:assembleDebugAndroidTest --console=plain
```

**BUILD SUCCESSFUL en 1m39s; 83 tareas, 16 ejecutadas y 67 al día.**
Salidas autoritativas en /tmp/peach-local-build-160/app; no se usa app/build antiguo.
Los logs activos se escribieron fuera del workspace y se copiaron al terminar.

Compilación inicial correcta en 25s. Un ensayo dirigido pasó 9/10 casos: el generador
7zz había reducido el diccionario para archivos pequeños, por lo que ese fixture no
probaba el límite previsto. Se regeneró con un bloque sólido de diccionario real de
128 MiB y se comprobó la limitación antes de decodificar. Build completo posterior:
305 aprobadas y ambos APK en 2m1s. Se añadió la regresión/validación de CRC no cero en
flujo vacío y el build final aprobó 306. Una lectura del grafo simultánea contendió
con la caché Gradle y agotó su espera; repetida secuencialmente terminó correctamente.
No se repitió la suite solo para obtener el grafo.

Lint final: ButtonStyle14, SetTextI18n8, GradleDependency5, UsableSpace3,
ExifInterface1, NewerVersionAvailable1, SwitchIntDef1, DataExtractionRules1,
Overdraw1 y ClickableViewAccessibility1: 36 advertencias, 0 errores.
No se suprimieron avisos. Las advertencias de versiones dependen de metadatos
remotos; su número no es una medida de paridad o validación física.
Se corrigió además un espacio introducido por formato en el hash del commit original
de algunos documentos; no cambiaron los hashes del código original inspeccionado.

## Pendiente y entrega

RAR/CBR, más combinaciones 7z/TAR/ZIP, cifrado/volúmenes, EPUB/ofimática, PDF avanzado,
audio en segundo plano, historial/versiones, sincronización, otros proveedores/cuentas,
medios remotos y descargas avanzadas siguen pendientes en la matriz. Patreon conserva
el límite de tarjetas públicas, aunque el usuario confirmó su consulta sin VPN.
El proyecto no está terminado ni se ha incorporado todo Peach por esta entrega.

El ZIP incluye código, historial Git completo, APK instrumentado compilado,
resultados XML/HTML, licencias y evidencia. Excluye clave, SDK/JDK, ejecutable 7zz,
JAR de desarrollo y medios externos. Se actualizan los informes de 0.15 con su
aceptación y el resultado de VPN, conservando el historial de la incidencia.
No hace falta repetir las baterías sintéticas que se ejecutaron aquí.
