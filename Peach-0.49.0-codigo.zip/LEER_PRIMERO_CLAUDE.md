# Peach Android 0.48.0 · Contexto para Claude

El usuario quiere continuar modificando esta aplicación. El proyecto editable está en `peach-android/` y corresponde a la entrega 0.48.0, commit `0fcc96800b020b5f37248ab9fcfe400d23b1ee7e`.

## Estado 0.49.0 (más reciente)

Rediseño visual y reproductor de audio sobre 0.48. Ver `peach-android/docs/CAMBIOS_049.md`. Se entrega como "Peach Prueba" (`./gradlew :app:assembleDebug -PpeachPrueba`, paquete `com.peach.local.prueba`) para probar junto a la original. Cuando el usuario lo acepte, compilar sin `-PpeachPrueba` y con la clave original (`PEACH_DEBUG_KEYSTORE`); versionCode 49. Pruebas locales: `LANG=C.UTF-8` y `PEACH_RAR_HOST_LIBRARY` para los tests nativos.

## Objetivo y estado

- Aplicación Android nativa autónoma para Samsung Galaxy Tab A11+ SM-X230, Android16. Español de México. Funciona sin PC, Termux ni servidor Peach obligatorio en el uso cotidiano. El entorno de desarrollo sí necesita herramientas Android para compilar.
- Java, vistas Android/XML, Gradle8.13, Android Gradle Plugin8.13.0, compileSdk/targetSdk36, minSdk26, nivel de lenguaje Java17. Reproductor Media3, Room y módulos nativos de RAR ya incluidos.
- La versión0.47 fue aceptada por el usuario. La0.48 acaba de entregarse para probar el rediseño; aún no hay aceptación del usuario de esa entrega. No asumir que la probó en la tablet.
- La entrega0.48 registró1170 pruebas JVM/Robolectric aprobadas. En emulador Android9/API28 x86_64:75 aprobadas y1 omitida por requerir API35+, más repetición visual3/3. No equivale a certificación de hardware Samsung, cuentas reales o subidas a Drive.

## Preferencias del usuario

Quiere una interfaz terminada, sencilla, minimalista y con estilo, inspirada en una app de música oscura: portadas grandes, buena distribución y pocos botones. Fuentes debe mostrar vistas previas de los resultados y permitir leer las publicaciones desde esa misma sección. El menú general de tres puntos debe ser corto; las herramientas secundarias, agrupadas en Ajustes. Quiere fondos, colores y animaciones personalizables, un reproductor elegante y volumen compacto. Acepta que la APK aumente de tamaño.

El rediseño0.48 ya incorpora navegación Biblioteca/Fuentes/Descargas/Ajustes, explorador visual de fuentes, lectura de publicaciones en esa actividad, ajustes buscables y volumen compacto. Continuar desde este código; no sustituirlo por una web, una maqueta o una versión antigua.

## Dónde modificar

Todo lo siguiente está bajo `peach-android/app/src/main/`:

| Área | Archivos principales |
| --- | --- |
| Biblioteca y menú general | `java/com/peach/local/MainActivity.java`, `MediaAdapter.java`, `res/layout/activity_main.xml`, `media_card.xml`, `media_row.xml` |
| Exploración de fuentes y publicaciones | `java/com/peach/local/SourceBrowserActivity.java`, `SourceBrowserItems.java`, `SourcePreviewLoader.java`, `SourceThumbs.java` |
| Herramientas agrupadas | `java/com/peach/local/SettingsActivity.java` |
| Estilo, iconos y personalización | `java/com/peach/local/PeachDesign.java`, `UiAppearance.java`, `AppearanceActivity.java`, `WallpaperStore.java`, `res/drawable/ic_ui_*.xml` |
| Video, audio y volumen | `java/com/peach/local/PlayerActivity.java`, `AudioActivity.java`, `PlaybackVolume.java`, `res/layout/activity_player.xml`, `peach_player_control_view.xml` |
| Descargas y guardado a nube/carpeta | `java/com/peach/local/DownloadQueueActivity.java`, `DirectSaveActivity.java` |
| Persistencia, contratos y proveedores | `LibraryDatabase.java`, `LibraryDao.java`, `SourceStore.java`, `SourceHttp.java`, los conectores de fuentes |

Los nombres de Java de esa tabla, salvo que se indique otra carpeta, están en `java/com/peach/local/`.

`SourcesActivity.java` contiene la pantalla histórica y un ViewModel/operaciones que el explorador nuevo reutiliza. La navegación habitual entra por `SourceBrowserActivity`; no confundir ambas ni borrar la primera sin revisar sus dependencias.

## Compatibilidad que debe conservarse

- Mantener funciones, biblioteca, favoritos, carpetas, listas, notas, progreso, cuentas y personalización del usuario. No solucionar problemas mediante desinstalación o borrado de datos.
- `applicationId`: `com.peach.local`. Base Room13, copia19 e intercambio portable1. Cualquier cambio de formato necesita migración y compatibilidad deliberadas; no modificar esquemas o identidades para una corrección visual.
- Nueve fuentes existentes: FANBOX, Patreon, SubscribeStar, Pawchive, cum.st/OnlyHaven, Rule34 Paheal, Rule34.xxx, Rule34Video y F95zone. El usuario excluyó Kemono, Coomer y SimpCity.
- Mantener contratos de hosts, rutas, sesiones, verificaciones, cuotas y cancelación. No convertir un enlace de miniatura en una descarga/streaming ni inventar miniaturas o acceso a contenido no devuelto por la fuente.
- La nube usa el proveedor de documentos instalado/autorizado por Android. No hay integración Google Drive OAuth/API propia ni garantía de subida remota terminada solo por escribir al proveedor.
- Para una nueva actualización instalable, incrementar `versionCode` por encima de48 y conservar la firma original.

## Compilación y firma

Abrir `peach-android/` como proyecto Gradle en un entorno Android compatible. Usar las versiones fijadas en los archivos del proyecto; no actualizar dependencias por rutina.

En Linux/macOS, si el extractor no conserva el permiso del wrapper:

```sh
cd peach-android
chmod +x gradlew
./gradlew :app:assembleDebug
```

APK generado: `app/build/outputs/apk/debug/app-debug.apk`.

Para verificaciones, usar `:app:testDebugUnitTest`, `:app:lintDebug` y `:app:assembleDebugAndroidTest`; ejecutar instrumentación en un emulador/dispositivo cuando corresponda. Las pruebas JNI de host necesitan preparar su biblioteca y `PEACH_RAR_HOST_LIBRARY`; consultar `scripts/native/build-rar.py`. Las cuatro bibliotecas Android nativas ya vienen en `app/src/main/jniLibs/`.

La clave de firma original **no está incluida**. El proyecto admite `PEACH_DEBUG_KEYSTORE` para seleccionarla en un entorno de compilación autorizado. Una APK firmada con una clave diferente no puede actualizar la ya instalada, aunque conserve el mismo nombre y package. Puede devolverse el proyecto o un parche para que se compile y firme después con la clave original.

## Documentación y contenido del paquete

Comenzar por `docs/GUIA_REDISENO_048.md`, `docs/REDISENO_048.md`, `docs/INFORME_048.md`, `docs/PLAN_FUENTES.md` y `docs/PENDIENTES_048.md`. El historial de la documentación distingue entregas pasadas de la versión actual.

Este ZIP conserva sin modificar los archivos seleccionados del proyecto0.48: código, recursos, pruebas/fixtures, esquemas, scripts generales, bibliotecas nativas y licencias. Se excluyen APKs, bundle Git, SDKs/cachés, los registros/capturas de `docs/evidence/` y los scripts internos de sesión `scripts/work048/`. El archivo completo de proyecto y pruebas de la entrega original sigue disponible por separado. No hay clave de firma, cookies ni credenciales reales en este paquete.

Licencia del proyecto: conservar `LICENSE` y `THIRD_PARTY_NOTICES.md` y sus obligaciones de distribución.
