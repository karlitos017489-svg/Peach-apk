# Peach Local · 0.49.0 · Rediseño visual y reproductor de audio

0.48 entregada; 0.49 se prueba primero como app aparte "Peach Prueba" (`-PpeachPrueba`). Reproductor de audio con portada,
mini reproductor, accesos rápidos y fila Continuar en Biblioteca, panel de detalles, Apariencia renovada y navegación que conserva cada sección.
[Lista de cambios](docs/CAMBIOS_049.md). 1182 pruebas JVM aprobadas; pendiente de prueba en la SM-X230.

# Peach Local · 0.48.0 · Rediseño

0.47 aceptada por el usuario. Instalar **0.48.0 encima, sin desinstalar**. Nueva navegación visual, Fuentes con tarjetas y publicación en la misma pantalla, Ajustes buscables, reproductor renovado y volumen compacto.

[Guía del nuevo diseño](docs/GUIA_REDISENO_048.md) · [Alcance](docs/REDISENO_048.md) · [Informe y validación](docs/INFORME_048.md).

1170 pruebas JVM aprobadas; Android: 75 aprobadas y una omitida por requerir API35+, más repetición visual de tres casos. No certifica paridad universal o hardware Samsung.

## Documentación histórica de las entregas anteriores

# Peach Local · 0.47.0 · Parte 6 de 6

0.46 / parte 5 aceptada por el usuario. Instalar 0.47 encima sin desinstalar.
Esta entrega corrige RAR comprimido y ZIP64 en Android, fondos interrumpidos y proporciones, cierre del volumen al salir
y limpieza fuera de la interfaz de un segundo destino de nube rechazado. Añade
Ajustes → Comprobar funcionamiento: ocho comprobaciones explícitas con muestras propias,
resultado privado y exportación JSON a un destino elegido. No ejecuta pruebas al abrir.

Consultar [guía](docs/GUIA_PARTE_6_047.md), [alcance](docs/PARTE_6_VALIDACION.md) y
[pruebas](docs/PRUEBAS.md). Las cinco partes anteriores se mantienen. Firma original,
Room 13, copias 19, intercambio 1 y dependencias conservados. APK autónomo SM-X230,
sin PC, Termux o backend obligatorio. Nueve fuentes; exclusiones vigentes.

La sexta entrega requiere validación en la tablet. 1152 JVM/Robolectric en 161 clases, 0 fallos/errores/omitidas. Android: 73 compiladas, 72 ejecutadas y 72 aprobadas, 1 omitida(s), 0 fallos/errores; los 73 casos terminaron.
La emulación y sus muestras no certifican paridad universal, cuentas reales o nube.

La documentación histórica siguiente mantiene sus referencias a versiones anteriores.

# Peach Local para Android

Versión 0.45.0. Adaptación autónoma en desarrollo de la biblioteca y organización de Peach, orientada a la
Samsung Galaxy Tab A11+ SM-X230. No es una publicación oficial de peach-mitao.

Se ejecuta en Android, sin computadora, Termux, Python instalado ni servidor Peach.
El proyecto no incluye medios de terceros. Las pruebas generan un video sintético
H.264/AAC con FFmpeg y texto propio; la comprobación explícita de 0.47 incluye además muestras propias pequeñas en el APK principal.

## Parte4de6: importación y sincronización en0.45

0.44 confirmada por el usuario. Paquete portable de metadatos/estado con identidades
opacas de medios, correspondencias explícitas de carpetas/documentos, revisión y merge
por campo con base anterior por origen. Versiones monótonas, rechazo de revisión obsoleta,
validación independiente y Deshacer exacto. Guardado de versiones nuevas SAF con relectura,
nube opcional solo mediante proveedor instalado/autorizado. No medios/grants/cuentas,
agenda o APIs de nube nuevas. Room13/copia19/runtime/nativos conservados; actividad interna.
[Alcance y límites](docs/PARTE_4_INTERCAMBIO.md), [guía](docs/GUIA_PARTE_4_045.md),
[pruebas](docs/PRUEBAS.md).0.45 pendiente de prueba. Partes5–6 después de aceptación.

## Parte 3 de 6: formatos y lectores en0.44

0.43/parte2 aceptada por el usuario. Esta entrega amplía ZIP64 acotado, 7z con contraseña
para cabecera plana y derivación limitada, diccionarios RAR5 sólidos hasta64MiB, índice
EPUB NAV/NCX y fragmentos locales, omisión de fuentes ofuscadas estándar sin cargar fuentes,
búsqueda de texto visible y PDF/password API35+. Info muestra pistas reales y se normalizan
subtítulos Unicode con Windows-1252 explícito. Sin nuevos permisos, dependencias, componentes,
Room13 o copia19. Se mantienen límites reales: RAR4 sólido/RAR cifrado/volúmenes/RAR7,
DRM, OCR y EPUB maquetado no se anuncian como admitidos. Prueba física0.44 pendiente.
[Alcance](docs/PARTE_3_FORMATOS.md), [guía](docs/GUIA_PARTE_3_044.md), [pruebas](docs/PRUEBAS.md).

## Parte 2 de 6: fuentes, cuentas, enlaces y descargas en0.43

El usuario confirmó0.42 y pidió la siguiente entrega agrupada. Sesiones opcionales
cifradas y separadas por sitio, acceso oficial en pantalla limitada al login o importación
propia, cuerpos visibles Patreon/SubscribeStar revisables y siempre parciales, FANBOX
con acceso explícito permitido por su API, búsqueda de títulos F95, enlaces compartidos
y filtros locales, Pixeldrain individual con revisión y SHA esperado, y cola opcional
en segundo plano con notificación/pausa/timeout y dueño único. No arranca sola.

Se conservan nueve fuentes y la parte1. No equivale a compatibilidad universal de cuentas,
formatos o servicios. No sustituye suscripciones/CAPTCHA, no APIs privadas Patreon ni
HLS/DASH/DRM o listas Pixeldrain. Límites de servidores y Android documentados en
[Parte 2](docs/PARTE_2_FUENTES.md) y [guía](docs/GUIA_PARTE_2_043.md).
Room13/dependencias/assets/nativos conservados; copia19 lee1–19; credenciales fuera de copias.

## Parte 1 de 6: organización en0.42

Nueva cadencia del usuario: una entrega por parte completa antes de pedir prueba.
Esta parte reúne vista previa de renombrado/movimiento SAF, papelera restaurable,
registro operativo y reconciliación, escritura NFO con respaldo y restauración,
duplicados SHA-256, coincidencias por código NFO y listas de partes revisadas.
Conserva identidad/progreso/listas al cambiar URI y al volver a escanear.

Requiere permisos explícitos y capacidades del proveedor; movimientos dentro del
mismo proveedor, archivo seleccionado únicamente. No borra medios definitivamente.
Los auxiliares no se trasladan automáticamente. Detalles y límites de recuperación,
respaldo local y comparación en [Parte 1](docs/PARTE_1_ORGANIZACION.md).
No nuevas dependencias/permisos ni cambios Room13/copia18. Solo actividad interna.
[Pruebas](docs/PRUEBAS.md).0.42 y0.43 aceptadas por el usuario; funciones nuevas0.44 pendientes de prueba.

## RAR5 sólido en0.41

El usuario confirmó0.40. Se admite un subconjunto RAR5 sólido: entradas comprimidas
no vacías hasta64MiB, mismo diccionario hasta16MiB y total expandido declarado128MiB.
Se usa el motor aislado anterior; cada lectura reconstruye el diccionario desde el
inicio y puede tardar más. Solo se publica la entrada seleccionada con CRC/tamaño.
El CRC de entradas descartadas no se verifica: no certifica el contenedor completo.
RAR4 sólido, entradas vacías/almacenar en sólidos, volúmenes y contraseñas pendientes.
Sin cambios de binarios nativos, permisos, dependencias, Room13 o copia18.

[Alcance](docs/LECTURA_RAR_SOLIDO.md), [comprobación](docs/GUIA_RAR_041.md),
[pruebas](docs/PRUEBAS.md) y [pendientes](docs/PENDIENTES.md).0.41 pendiente de prueba del usuario.

## Nombres Unicode RAR4 en0.40

El usuario confirmó0.39. Este bloque admite nombres heredados RAR4 con acentos, ñ,
caracteres japoneses y pares UTF-16 válidos; lectura almacenada y comprimida compatible.
Índice y motor seleccionan la misma forma Unicode exacta, sin adivinar ANSI.
Rutas, duplicados, límites, CRC y copias privadas anteriores se mantienen.
Sin nuevas dependencias, permisos, componentes, cambios de Room13 o copia18.
No añade sólidos, volúmenes, contraseñas o RAR7 comprimido.

[Alcance y muestras](docs/LECTURA_RAR_UNICODE.md), [pruebas](docs/PRUEBAS.md) y
[comprobación breve](docs/GUIA_RAR_040.md). Proyecto abierto;0.40 pendiente de prueba del usuario.

## RAR/CBR comprimido en0.39

0.38 aceptada. Añade libarchive3.8.10 para entradas comprimidas compatibles RAR4/RAR5,
en servicio Android aislado, sin servidor externo. Mantiene la lectura almacenada,
índice/búsqueda, imagen/texto/PDF y posición. No se admiten todavía sólidos, volúmenes,
contraseñas, RAR7 comprimido o Unicode heredado RAR4; no es soporte universal RAR.

Cuota nativa160MiB/asignación64MiB, selección64MiB, origen512MiB, CRC antes de publicar,
FD de origen solo lectura y salida solo escritura. Cuatro ABIs con ELF16KiB. Room13/
copia18 y dependencias Java anteriores se conservan. Se añade un servicio no exportado,
proceso aislado y avisos de licencia. Ver [alcance y reconstrucción](docs/LECTURA_RAR_COMPRIMIDA.md),
[resultados](docs/PRUEBAS.md) y [pendientes](docs/PENDIENTES.md). El usuario confirmó0.39;0.40 pendiente de comprobación.

## RAR/CBR local en0.38

0.37 aceptada. Este bloque abre RAR4/RAR5 con entradas **almacenadas sin compresión**:
índice, búsqueda, imágenes, texto, PDF, navegación y posición. Las entradas comprimidas
siguen en el índice con explicación; **no es descompresión RAR completa**. No usa red o
cuentas. Límites512MiB fuente/64MiB entrada, CRC, rutas seguras y copia privada; sin
nuevas dependencias, permisos o componentes. Room13/copia18 conservados.

[Alcance, auditoría y límites](docs/LECTURA_RAR.md), [pendientes](docs/PENDIENTES.md) y
[validación](docs/PRUEBAS.md). Se evalúa libarchive para la descompresión posterior.
El usuario aceptó0.38; el proyecto permanece abierto.

## Sesión opcional y enlaces F95 en0.37

El usuario aceptó0.36. **Sesión F95** importa de forma avanzada una cabecera Cookie propia
ya disponible, cifrada solo en la tablet. No extrae Chrome, pide contraseña, inicia sesión
o completa CAPTCHA. Sin ella permanecen las consultas públicas anteriores.

Desde contenido guardado → **Enlaces F95 → Resolver enlace → revisar → Incorporar**.
Una solicitud F95 por acción, sin consultar el destino. Mantiene referencia y datos
personales; Gofile usa su clave independiente y Pixeldrain permanece referencia.
Cookie confinada a rutas F95 exactas; espera429 persistida, offline/cancelación y rotación.

[Alcance](docs/F95_SESION_Y_ENLACES.md), [comprobación breve](docs/GUIA_F95_037.md),
[qué falta](docs/PENDIENTES.md) y resultados en docs/PRUEBAS.md. El protocolo se adapta del
original fijado: la comprobación actual del script devolvió Site Unavailable, sin cuenta
real o POST masked probado. Room13/copia18/dependencias conservados; nueva pantalla
no exportada.El usuario aceptó0.37; el inicio de sesión nativo sigue pendiente.

## Enlaces Gofile en0.36

El usuario aceptó0.35. Desde el contenido guardado de una publicación, **Enlaces Gofile**
consulta una página de archivos con tu clave propia y muestra una revisión antes de
incorporarlos. La API oficial de listado requiere Premium; la clave es opcional para
Peach y se guarda cifrada solo en la tablet. Sin cuenta apta se conserva la referencia,
sin simular un video o crear cuentas automáticamente. No necesitas servidor Peach.

Tras incorporar: galería/video nativos, Ver en línea, preparación, guardar y cola existentes.
Consulta/importación de metadatos no descargan medios; subcarpetas/páginas son explícitas.
La clave no llega a archivos/otras fuentes. Se preservan ficha/adjuntos y espera429.
[Alcance y contrato](docs/GOFILE.md), [comprobación breve](docs/GUIA_GOFILE_036.md),
resultados en docs/PRUEBAS.md. Room13 y dependencias intactos; copia18 lee1–18.
Nueva pantalla nativa no exportada, sin nuevo permiso/servicio. El usuario aceptó0.36.
F95 masked/sesión, otros servicios, interfaz/formatos/sincronización y paridad siguen abiertos.

## Calidad y variantes en0.35

El usuario aceptó0.34 y señaló demoras, baja calidad o muestras en varias fuentes.
0.35 identifica previews conocidas, conserva alternativas de video de cum.st y
preselecciona la mayor altura declarada del primer archivo compatible. No fabrica HD.
**Ver videos → Consultar versiones → revisar → Usar versiones** consulta el detalle
admitido de Rule34Video/cum.st/Paheal sin descargar medios ni cambiar el cuerpo antes
de confirmar. Rule34.xxx conserva file_url, sin sustituirlo por sample/preview.

El reproductor muestra carga y dimensiones cuando Media3 las informa. Rule34Video
reutiliza el destino validado solo en RAM durante la sesión para reducir redirecciones,
con revalidación HTTPS/DNS y control de representación; no es una medición del CDN real.
[Alcance y límites](docs/CALIDAD_Y_VERSIONES.md), [comprobación breve](docs/GUIA_CALIDAD_035.md)
y resultados en docs/PRUEBAS_0_35.md. El usuario aceptó0.35.
Se conserva la corrección Media3 de0.34, firma original, Room13/copia17 y dependencias.
El bloque Gofile limitado se incorpora en0.36; la demás paridad original sigue abierta.

## Ver en línea en0.33

Publicación importada → Ver videos → **Ver en línea**. Reproducción progresiva nativa
con Media3, sin esperar un archivo completo, guardar video en disco o elegir carpeta.
Recibe datos por internet y usa un búfer temporal; volver a ver o adelantar puede
consumir datos otra vez. Sin conexión deshabilita esta opción. Salir detiene la conexión;
rotar conserva posición/pausa y puede pedir datos de nuevo. No es descarga en segundo plano.

Mismos adjuntos y rutas de fuentes, sin URL del llamador. Comprueba cabecera y rangos;
no verifica todo el SHA antes de mostrar, incluso en Pawchive. **Preparar y reproducir**
y **Cola de descargas** mantienen la verificación completa y las copias offline.
Hasta16GiB de recurso en línea; descargas completas hasta2GiB. Objetivo de búfer32MiB,
no cuota total de RAM. Adelantar exige que el servidor y el formato lo permitan.

[Uso y límites](docs/STREAMING.md), [comprobación breve](docs/GUIA_STREAMING_033.md).
0.33 presentó un defecto de integración corregido en0.34, aceptada por el usuario.
Sin cambios de manifiesto, permisos, dependencias, Room13 o copia17. Gofile y otras
referencias externas siguen pendientes; se priorizó esta función ante su consulta.

## Cola de descargas en0.32

Desde una publicación importada: **Cola de descargas → Añadir adjuntos → Continuar cola**.
También accesible desde Biblioteca para administrar trabajos. Hasta128 adjuntos,2GiB por
archivo,4GiB de copias privadas y una transferencia activa. Progreso real, pausa por fila
o por lote, recuperación tras cierre y reanudación condicionada a que la fuente confirme
el fragmento. Abrir no inicia la red; salir de la pantalla pausa. No garantiza segundo plano.

**Elegir carpeta → Guardar completas** copia los archivos verificados por lote sin otra
descarga. Videos e imágenes completos pueden abrirse directamente en el visor/reproductor
nativos. La cola operativa queda fuera de Room13/copia17, sin cambios de permisos,
servicios o dependencias. [Uso y límites](docs/COLA_DESCARGAS.md),
[comprobación mínima](docs/GUIA_COLA_032.md). El usuario aceptó0.31 y0.32. Los resultados propios de0.32 se conservan en docs/PRUEBAS_0_32.md.

## Videos desde publicaciones en0.31

**Ver videos → Preparar y reproducir** abre un adjunto de video compatible de una
publicación importada. Primero comprueba una copia privada completa y luego abre el
reproductor Media3 existente; no pide una carpeta SAF ni un servidor Peach. No es
streaming mientras descarga. Solo prepara el video elegido y permite cancelar.
Las copias válidas pueden reutilizarse sin conexión, hasta2GiB/8 copias completas;
Android puede limpiarlas. El espacio ocupado por videos abiertos reduce el límite
disponible para nuevas preparaciones. La app no elimina las copias en uso.

La selección y restauración pasan por Room y las rutas iniciales ya admitidas. El
Intent al reproductor lleva ID/clave opaca, nunca URL o ruta. El reproductor verifica
su copia sin consultar la fuente; no recibe una URL de red para Media3. Mantiene
posición/pausa al rotar. **Guardar adjunto** sigue conservando originales en carpetas.
[Guía y límites](docs/VIDEOS_PUBLICACIONES.md). Room13/copia17 sin cambios.

El usuario confirmó0.30 y0.31 y pidió avanzar bloque por bloque. Los resultados de0.31
se conservan en PRUEBAS_0_31.md. Cola/lotes/reanudación pasan a0.32 con los límites
documentados; streaming progresivo y las demás funciones siguen pendientes.

## Galería de fuentes en0.30

Las imágenes compatibles de FANBOX, Pawchive, cum.st, Rule34 Paheal, Rule34.xxx y F95zone
se abren desde una publicación importada con **Ver imágenes**. Navegación, zoom, caché
verificada sin conexión y GIF/WebP animados en Android28+. Solo se consulta la imagen
seleccionada; no se importan adjuntos automáticamente ni se amplían servidores/rutas.
Pawchive conserva su hash esperado, incluso en caché y referencias antiguas.
[Galería: alcance y uso](docs/GALERIA_FUENTES.md). Room13/copia17 sin cambios.

El usuario confirmó que0.29 resolvió el error previo de descarga en su tablet. Es una
confirmación de ese caso, no de todos los formatos o ejecución de instrumentación.
El usuario también confirmó el funcionamiento de0.30. El proyecto sigue abierto.

## Traspaso de descarga en0.29

Rule34Video puede entregar un archivo admitido mediante redirecciones HTTPS públicas.
Hasta3 saltos, con comprobación DNS de direcciones locales/especiales y TLS normal.
La URL inicial guardada no cambia; no se añade el servidor de entrega a tus fuentes.
No se amplían políticas de otras fuentes o APIs ni se envían sus claves/cookies al CDN.
Los errores indican host/HTTP sin la URL firmada. Ver docs/PRUEBAS.md para la reproducción
del fallo0.28 y la prueba de la corrección con conexiones simuladas y bytes propios.
La corrección fue aceptada por el usuario en su tablet; el entorno de desarrollo no descargó su archivo ni comprobó directamente su CDN.

## Descargas y GIF en0.28 (conservados)

Guardar adjunto descarga primero a un temporal privado y comprueba longitud/hash; luego
pide el destino. Hasta2GiB, con reserva de espacio y cancelación. Un fallo por límite o
red antes del selector no crea un archivo vacío. Si falla la copia, se intenta retirar
solo el documento recién creado; no todos los proveedores SAF permiten esa limpieza.

Fuentes → Abrir video o GIF permite elegir archivos anteriores. La cabecera identifica
MP4/GIF/PNG/JPEG/WebP/WebM/MKV compatibles aunque se llamen BIN; no renombra el archivo
anterior. Un archivo vacío no contiene datos recuperables. GIF/WebP animados usan el
visor nativo de imágenes en Android28+ (26/27 conservan el fotograma estático).

Rule34Video usa enlaces públicos de descarga con calidad y rutas admitidas. Si tenías
un BIN de referencia en la caché, vuelve a Consultar cuerpo desde la fuente. Los nodos
no admitidos o enlaces sin descarga siguen siendo referencias. Sin resolución de DRM,
JavaScript, CAPTCHA o servidores externos. Room13/copia17.

## Videos descargados en0.27 (histórico)

Fuentes → Abrir video local permite seleccionar un video que ya guardaste, incluso si
se creó antes con MIME genérico. Tras guardar un video nuevo, Reproducir descarga abre
el mismo reproductor nativo sin consultar otra vez el origen ni exigir escanear la carpeta.
La reproducción directa conserva posición al recrear la pantalla; no registra una ficha,
lista o visita de catálogo. Para esas funciones añade/actualiza su carpeta en Biblioteca.
El sistema decide los códecs disponibles; un fallo muestra un código de error seleccionable.
No se declara reparado un códec no comprobado en la tablet del usuario.

## Funciones implementadas

- Entrega conjunta: Rule34 Paheal, Rule34.xxx, Rule34Video y F95zone. Nueve proveedores
  en total; Kemono, Coomer y SimpCity excluidos. Clave propia Rule34.xxx cifrada localmente,
  consulta/revisión/importación, detalle seleccionado y guardado de rutas admitidas.
  **Pruebas propias y compilación; validación online/nativa pendiente.**
  [Alcance y uso de las cuatro fuentes](docs/FUENTES_CONJUNTAS.md).


- cum.st (OnlyHaven), quinto proveedor independiente: consulta paginada, cuerpo, revisión,
  importación offline y guardado individual de variantes admitidas. **Implementado y
  probado con datos propios; API/medios reales sin validar desde este entorno.**
  [Contrato y límites](docs/FUENTES_CUMST.md). Kemono y Coomer excluidos por el usuario.

- Guardado directo de adjuntos Pawchive admitidos, hasta2GiB en Fuentes y con SHA-256 esperado;
  reconoce referencias antiguas sin reconsultarlas. [Pawchive](docs/FUENTES_PAWCHIVE.md).

- Conector Pawchive implementado: páginas, cuerpo y referencias de adjuntos, con revisión
  e importación. **El usuario aportó evidencia de consultas en su tablet; la descarga de archivos real desde este entorno sigue sin verificar.**
  [Pawchive y límites](docs/FUENTES_PAWCHIVE.md).

- SubscribeStar: tercera fuente de tarjetas públicas, revisión/importación y lectura
  offline de adelantos. [SubscribeStar](docs/FUENTES_SUBSCRIBESTAR.md).

- Galería nativa de imágenes compatibles de seis fuentes ya consultadas e importadas,
  navegación, zoom, animación y caché privada sin conexión. [Galería de fuentes](docs/GALERIA_FUENTES.md).

- Historial local de visitas a audio/video, imágenes y lecturas; cronología paginada,
  búsqueda/filtros, último punto guardado y borrado independiente. [Historial de uso](docs/HISTORIAL_USO.md).

- Revisión de versiones y partes por indicios del nombre, selección explícita y
  grupos o listas ordenadas de partes; conserva identidad/progreso. [Versiones y partes](docs/VERSIONES_Y_PARTES.md).

- Audio en segundo plano con sesión y controles de Android, cola de audios, progreso
  y Detener audio. [Guía de audio](docs/AUDIO_SEGUNDO_PLANO.md).

- EPUB 2/3: texto nativo por capítulos en orden de lectura, índice y progreso;
  imágenes por separado. Sin CSS/DRM. [EPUB local](docs/LECTURA_EPUB.md).

- Lectura nativa 7z: índice buscable, imágenes y PDF/texto compatibles, límites
  de memoria/descompresión y reanudación. [7z local](docs/LECTURA_7Z.md).

- Lectura local TAR, TAR.GZ/TGZ y GZIP: índice, imágenes, PDF/texto compatibles y
  reanudación. Sin extracción general o red. [TAR y GZIP](docs/LECTURA_TAR_GZIP.md).

- Patreon: tarjetas del HTML público, revisión e importación y copia local del adelanto.
  El usuario confirmó resultados al desactivar su VPN. No se añadió una solución de CAPTCHA
  y fechas desconocidas cuando no están declaradas. Sin cuenta, cuerpos completos o
  adjuntos. Selector de proveedor, identidad por sitio y conservación de datos FANBOX.
  [Patreon público](docs/FUENTES_PATREON.md).


- Primera fuente directa: FANBOX público/gratuito, consultas manuales, historial con
  cursores reales, revisión antes de incorporar, cuerpos de texto y adjuntos guardados
  como metadatos locales. Descarga individual a un documento Android elegido, con
  límites y SHA-256. Sin cuenta ni host Peach. [Fuentes FANBOX](docs/FUENTES_FANBOX.md).


- Publicaciones locales con fuente, fecha/precisión, semántica, variantes y estados;
  importación revisada de follow_source/follow_item/want_item. Deseos con fechas,
  estados, registro de búsquedas y reconciliación revisada por código, reversible por
  lote. Los conectores actuales y sus límites se describen arriba. [Publicaciones y seguimiento](docs/PUBLICACIONES_Y_SEGUIMIENTO.md).


- Agencias con ficha, alias, notas, referencias y favoritos; afiliación vigente de
  personas/creadores, gestión manual y revisión de importaciones. **Ver archivos**
  reúne los de sus miembros sin copiarlos ni duplicarlos. [Agencias](docs/AGENCIAS.md).

- Metadatos del catálogo importado integrados en fichas, búsqueda, ordenación por
  título y exploración por términos. Creador como campo propio, nombres con comas
  conservados, fuentes identificadas y desacuerdos visibles. Los NFO y ediciones
  personales se conservan. [Consulta integrada](docs/METADATOS_CATALOGO.md).

- Importación nativa revisable de campos seleccionados de una copia SQLite autónoma de
  Peach original o JSON de intercambio. Mapeo explícito de rutas a raíces SAF escaneadas,
  fichas/alias/referencias/relaciones y listas compatibles; instantánea buscable con
  registros sin archivo local, exportación JSON y conservación en la copia personal.
  Alcance y límites en [Importación del catálogo](docs/IMPORTACION_CATALOGO.md).

- Elegir varias carpetas mediante el selector Android, incluida microSD si el selector
  la muestra. Se conserva únicamente autorización de lectura.
- Catálogo Room persistente, indexado reanudable por carpeta, pausa y actualización.
- Mosaico con carátulas locales o miniaturas, búsqueda en metadatos y filtros.
- Selector Videos / Imágenes / Audio / Comprimidos / Otros archivos / Todos, guardado al volver a abrir la biblioteca.
- Catálogo de las cinco familias del escáner original. ZIP/RAR/7z/TAR/GZ y documentos
  tienen ficha y organización; ISO/STRM/RMVB se registran con compatibilidad limitada,
  sin montar discos ni abrir enlaces. CBZ/CBR se clasifican también como comprimidos.
- Lectura nativa de PDF por páginas, ZIP/CBZ, TAR/TAR.GZ/TGZ/GZIP con álbum de imágenes y vista de entradas
  PDF/texto, y textos UTF-8/UTF-16. Zoom, navegación, índice buscable, favorito, marcado
  leído y reanudación independiente del progreso de audio/video. Límites en [Lectura local](docs/LECTURA_LOCAL.md).
- Exploración por reparto, estudios, artistas, dirección, series, colecciones, etiquetas,
  géneros y años; buscador de nombres, coincidencia exacta y salto desde la ficha.
- Grupos manuales de obras/versiones, con identidad y progreso por documento. Se pueden
  crear, renombrar y eliminar sin fusionar medios ni confundir grupos con secuencias.
- Fichas de identidades con UUID, nombre, tipo, notas, favorito y alias exactos. La ficha
  distingue coincidencias NFO, etiquetas personales y vínculos manuales por función.
- Referencias externas de proveedor/ID/URL como datos locales, sin abrir conexiones.
- Lista de deseos con obras sin archivo, título, código, notas, seguimiento y vínculo opcional a
  identidad/publicación/documento. Reconciliación revisada; sin descargas o reconciliación automática.
- Ámbito de identidad en la biblioteca, conservado al recrear y compartido con visor/audio.
- Galería nativa de imágenes: anterior/siguiente, pellizco, arrastre, doble toque, botones
  de zoom, ajuste a pantalla, orientación EXIF y favoritos. Vista limitada a 2048 px
  en su lado mayor para acotar memoria; GIF/WebP animados se muestran como imagen fija.
- Audio local con Media3, anterior/siguiente y progreso; desde 0.18, abrir un audio
  usa una sesión interna que puede continuar fuera de la pantalla. Ver límites y
  validación pendiente de hardware en la guía de audio.
- Reproductor Media3, pausa, búsqueda temporal, pantalla completa y pistas disponibles.
- Subtítulos locales SRT/VTT/ASS/SSA del mismo nombre, con sufijos de idioma conocidos,
  y selección manual de otro subtítulo. Codificación y estilos dependen de Media3.
- NFO de película, episodio y video musical con dirección, título original, país, colección,
  códigos/IDs, reparto/personajes, estreno, valoración y temporada/episodio. Consulte [NFO](docs/NFO.md).
- Botón Detalles en cada tarjeta: ficha nativa desplazable, texto seleccionable y datos
  personales diferenciados del origen. Búsqueda por los nuevos campos importados.
- Favoritos, visto, progreso, contador de aperturas y estadísticas básicas.
- Copia JSON y restauración de favoritos, visto y progreso para documentos coincidentes.
- Listas locales: crear, renombrar, añadir/quitar videos y cambiar su orden. Al abrir
  un video dentro de una lista, el reproductor carga su secuencia y permite anterior/siguiente.
- Títulos y etiquetas personales, conservados al reescanear y reversibles con Usar datos
  del archivo. Los cambios quedan en el catálogo privado y no modifican videos ni NFO.
- Exploración por carpetas indexadas y orden por título, incorporación, última reproducción
  u orden de la lista. Los videos migrados de 0.2.0 no tienen fecha de incorporación conocida.
- Copias JSON v11 con historial, fuentes/cuerpos, publicaciones, deseos, agencias, lectura,
  identidades, vínculos, grupos/listas y estado; se siguen leyendo v1–v10.
- Interfaz en español, columnas según ancho y adaptación a barras del sistema.

Además de FANBOX público, sus adjuntos compatibles y tarjetas públicas de Patreon, las
integraciones de otros sitios, descargas avanzadas, preferencias avanzadas, sincronización completa con el ledger original y
transcodificación no están incluidas. Consulte [la auditoría](docs/AUDITORIA.md) y
[las pruebas](docs/PRUEBAS.md) para distinguir código disponible de comportamiento verificado.
La [matriz de compatibilidad](docs/COMPATIBILIDAD_ORIGINAL.md) identifica el contenido,
las estructuras y las fuentes que aún faltan para el objetivo completo del proyecto.

## Instalar y usar

La aceptación general más reciente es 0.19.0, comunicada por el usuario. La nueva
0.20.0 está verificada localmente; no se infiere ejecución instrumentada o física.
Use **⋮ → Historial de uso** para consultar las visitas registradas desde esta versión.
Use **⋮ → Revisar versiones y partes → Buscar propuestas**, revise la evidencia y
seleccione archivos. **Guardar grupo** organiza; **Lista de partes** exige una sola
especificación y partes explícitas consecutivas desde 1. Buscar no guarda cambios.

1. Instale `Peach-Local-0.20.0-debug.apk` encima de 0.19.0, conservando la aplicación y sus datos.
   Antes de actualizar puede guardar una copia desde ⋮. Android puede pedir autorización a la app
   desde la que abre el archivo. Es una compilación de desarrollo, no una versión de tienda.
2. Abra Peach Local y toque **Añadir carpeta**. Elija una subcarpeta local con videos, imágenes o audio
   y pulse **Usar esta carpeta**. Para microSD, abra el menú lateral del selector.
3. Espere al indexado. Toque un video para reproducirlo; manténgalo pulsado para ver
   sus datos, cambiar favorito o marcarlo visto. También puede abrir **Detalles** desde la tarjeta.
4. Para SRT, use `video.mp4` y `video.es.srt` en la misma carpeta, o el botón **CC**
   del encabezado para elegirlo manualmente. El control CC del reproductor permite
   seleccionar/ocultar las pistas disponibles.
5. En **⋮** están Actualizar, Pausar/Continuar, Carpetas, Estadísticas, copias y diagnóstico.
6. El botón **Toda la biblioteca** permite explorar carpetas o abrir listas. Para editar
   un video, manténgalo pulsado y elija **Editar / organizar**. Desde ahí se añade a una lista,
   se mueve arriba/abajo en la lista actual o se cambian sus datos personales.
7. En **⋮ → Administrar lista actual** puede cambiar su nombre o eliminarla. Eliminar una lista
   mantiene los videos y su progreso. Para ver el orden manual seleccione **Orden de la lista**;
   la reproducción secuencial sigue ese orden aunque se ordenen las tarjetas por otro criterio.
8. Use **Explorar metadatos y grupos** para ver archivos relacionados por un nombre exacto.
   Cree grupos desde **Detalles → Editar / organizar**. Su uso y las diferencias con las
   listas se explican en [Organización](docs/ORGANIZACION.md).
9. En ese explorador o en ⋮, abra **Identidades y alias** o **Lista de deseos**.
   Desde la ficha de un archivo puede **Vincular a una identidad**. Las fichas ofrecen
   **Organizar** y **Ver archivos**; véase [Identidades y deseos](docs/IDENTIDADES_Y_DESEOS.md).
10. Toque un EPUB, PDF, ZIP/CBZ o texto compatible para abrir el lector local. En ZIP, **Contenido**
    busca entradas; Anterior/Siguiente recorre imágenes o páginas del PDF seleccionado.
    En EPUB, Capítulo y Anterior/Siguiente recorren el spine; Contenido ofrece imágenes aparte.
    **Marcar leído** es manual. El filtro **Con progreso** incluye las lecturas iniciadas.

Use archivos locales para la prueba sin conexión. Un proveedor de nube que aparece en
el selector puede necesitar Internet aunque Peach no tenga acceso a red. No elija
Android/data ni otras carpetas restringidas por el sistema. Los MP4 H.264/AAC son el
punto de partida; la extensión MKV por sí sola no garantiza códecs compatibles.

11. En **⋮ → Catálogo de Peach original**, elija una copia autónoma o un JSON de intercambio.
    Sin carpeta destino se guarda solo la instantánea. Para importar vínculos, indique el
    nombre de origen, su ruta base y la raíz ya escaneada, revise **Vista previa** y aplique
    **Importar lo revisado**. Esta función es opcional; la biblioteca local sigue siendo autónoma.

12. En **⋮ → Publicaciones**, cree o revise publicaciones importadas, su fuente y precisión
    de fecha. Puede añadirlas a deseos o vincular un documento. **Lista de deseos**
    ofrece estados, búsquedas registradas y revisión de códigos con deshacer por lote.
    FANBOX público y descarga individual se añaden en 0.13. [Guía de seguimiento](docs/PUBLICACIONES_Y_SEGUIMIENTO.md).

13. **⋮ → Fuentes de contenido** permite añadir un creador FANBOX. Guardar no consulta
    la red. Consultar novedades y Consultar cuerpo son acciones explícitas; Importar
    página revisada conserva tus fichas existentes. Los cuerpos guardados se leen desde
    Publicaciones → Organizar → Leer contenido consultado. [Uso y límites](docs/FUENTES_FANBOX.md).

14. En Añadir fuente puede elegir **Patreon · tarjetas públicas** y consultar el canal
    `patreonforcreators` u otro creador. Lo importado es la tarjeta/adelanto público,
    con su aviso parcial; no activa una suscripción o acceso al cuerpo completo.

## Datos, actualización y recuperación

- El catálogo vive en el almacenamiento privado de la aplicación; los videos permanecen
  en sus carpetas. No se envían a ningún servidor.
- Actualizar reenumera las carpetas y mantiene los registros personales. Una ubicación
  temporalmente inaccesible conserva su catálogo.
- Al retirar una tarjeta, reintente después de insertarla. Si Android revoca el permiso,
  use Añadir carpeta con la misma ubicación. Cambiar de proveedor o mover los archivos
  puede cambiar su identidad y no se garantiza recuperar progreso automáticamente.
- Antes de desinstalar o quitar una carpeta, use **Guardar copia de progreso**. La copia
  no lleva medios ni permisos. Para restaurarla, autorice e indexe las carpetas primero.
- Desinstalar elimina catálogo, permisos y preferencias. No elimina sus videos.
- Una actualización debe estar firmada con la misma clave. La firma debug generada en
  este entorno no se publica en el código. Un build de otra máquina podría no actualizar
  sobre el APK recibido; en ese caso exporte el progreso antes de reinstalar.
- 0.20.0 añade historial en Room v13 y registra migraciones explícitas desde v1 a v12. Conserva el catálogo,
  las ubicaciones, el progreso y los checkpoints. Las autorizaciones SAF siguen siendo
  permisos del sistema Android ligados a la instalación.
- Después de actualizar, use **⋮ → Actualizar** para leer los nuevos campos NFO de los
  archivos existentes y añadir comprimidos/otros documentos de esas ubicaciones. La migración no
  vuelve a abrir documentos por sí sola. Las copias
  usan formato v11: los NFO se recuperan de sus archivos y las instantáneas del catálogo
  original sí forman parte de la copia.
- Restaurar una copia v2/v3/v4/v5/v6 combina listas por identificador y reemplaza el contenido de las
  listas coincidentes; omite miembros que aún no están indexados. No borra listas ajenas
  a la copia. v3/v4/v5/v6 incluyen grupos; v1/v2 conservan los grupos actuales. Una copia v1
  restaura estado personal y deja las listas/ediciones actuales.
- v4/v5/v6 incluyen fichas/alias/vínculos/referencias/deseos. Reemplazan por UUID la organización
  entrante y conserva las fichas ajenas; un conflicto revierte la importación completa.
  Las copias v1/v2/v3 conservan esa organización nueva. Los documentos deben estar indexados
  para recuperar sus vínculos. La copia no contiene los medios ni los permisos SAF.
- v5 añade página/entrada/desplazamiento de lectura. Restaurar v1/v2/v3/v4 conserva las
  posiciones actuales. La caché temporal no forma parte de la copia.
- v6 añade instantáneas seleccionadas del catálogo original y sus correspondencias a
  documentos. El JSON de intercambio se exporta aparte; no es una base del original.
- v7 añade afiliaciones vigentes y su procedencia. Las copias v1–v6 conservan las
  afiliaciones actuales; v7 restaura las de las identidades incluidas, con validación
  transaccional. No incluye un historial de cambios de agencia.
- v8 añade publicaciones y seguimiento de deseos, incluidos lotes locales reversibles.
  Las copias v1–v7 conservan las publicaciones y seguimiento ampliado de obras actuales.
- v9 añade configuración de fuentes y cuerpos/adjuntos consultados, sin medios ni
  credenciales. Restaurar no inicia consultas; las copias v1–v8 conservan estos datos actuales.
- v10 amplía fuentes a FANBOX/Patreon. Se leen v1–v9 sin alterar los UUID FANBOX;
  restaurar no conecta al proveedor. Room permanece en v12.
- Las copias tienen un límite de 8 MiB. Las rutas/identificadores pueden revelar nombres
  de archivos y deben tratarse como información privada.

## Construir y probar

Para futuras actualizaciones con la misma firma, consulte `docs/FIRMA.md`.
La clave privada está respaldada por separado y se excluye del ZIP y del repositorio.

JDK 17 completo, SDK Android 36 y build-tools 35.0.0. El wrapper fija Gradle 8.13 y su
SHA-256. AGP es 8.13.0. Se requiere Internet solo para obtener las herramientas y
dependencias de compilación. La biblioteca local instalada no lo necesita; las consultas de fuentes y descargas FANBOX opcionales sí usan Internet.
El build es reproducible a partir de las versiones declaradas; no se promete una
identidad binaria bit a bit entre máquinas con claves debug distintas.

```bash
./gradlew --no-daemon testDebugUnitTest lintDebug assembleDebug assembleDebugAndroidTest
./gradlew --no-daemon connectedDebugAndroidTest
```

En Windows use `gradlew.bat` en lugar de `./gradlew`. Configure `ANDROID_HOME` o
`sdk.dir` en `local.properties`. No guarde rutas de máquina, credenciales o claves de
firma en Git. `scripts/run-gradle.py` permite ejecutar el wrapper en entornos de
desarrollo que proporcionan un proxy HTTPS; no es necesario para una instalación normal.

Salidas: `app/build/outputs/apk/debug/app-debug.apk`, informes HTML/XML dentro de
`app/build/reports` y `app/build/test-results`. El workflow incluido ejecutará
compilación, lint, unidades y pruebas de emulador cuando se suba a un repositorio con
Actions habilitado. Incluir el workflow no implica que se haya ejecutado en GitHub.

No hay código JNI ni librerías `.so` propias. El APK usa bytecode Android y códecs del
sistema: no necesita una variante de APK diferente para arm64 y x86_64. Confirme la
ABI real en **Acerca de y diagnóstico**; no se infiere del nombre comercial de la tablet.

Las pruebas locales añadidas usan Robolectric 4.16.1 con Android API 28 simulado y
SQLite en modo LEGACY. Se comprueban migraciones reales de los esquemas v1 a v11, hasta v12.
Las pruebas de imágenes nuevas utilizan también gráficos nativos de Robolectric;
se leen PNG/JPEG reales y se recorre el visor. La lectura de WAV se comprueba con
el extractor real de Media3. Esta ejecución JVM no certifica reproducción MediaCodec
ni validación nativa del lector 7z 0.16. El usuario confirmó funcionamiento general de
0.15 y resultados de Patreon después de desactivar la VPN. No se infieren todas las rutas. Los ZIP/textos usan lectores reales en las pruebas locales;
el controlador PDF usa un backend de prueba explícito. Las pruebas del renderizador PDF
Android real se compilan pero no se han ejecutado. Los resultados están en
`docs/PRUEBAS.md`; las confirmaciones del usuario de 0.2.0 a 0.13.0 se conservan aparte.

### Entornos que sincronizan archivos intermedios

Si el host introduce temporales de sincronización dentro de build/, puede aislarse la
salida con `PEACH_BUILD_ROOT=/ruta/fuera/del/workspace` y añadir
`--init-script scripts/build-outside-workspace.init.gradle` al comando Gradle. La salida
estará en PEACH_BUILD_ROOT/app. No modifica el APK ni el comportamiento de una
invocación normal. Guardar también los registros fuera del directorio sincronizado
mientras se escriben y copiarlos al finalizar evita registros parciales del host.

## Licencia y referencias

AGPL-3.0-or-later: [LICENSE](LICENSE). Peach original © 2026 longmeidao,
https://github.com/peach-mitao/peach. El código fuente correspondiente se entrega con
la aplicación. Componentes externos y avisos en [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).

El APK compilado y el alcance de pruebas no equivalen a haber validado todo Peach o
la SM-X230 física. El estado de aceptación figura en `docs/PRUEBAS.md`.

## Imágenes y audio

Los formatos, las listas mixtas y los límites están en [IMAGENES_Y_AUDIO.md](docs/IMAGENES_Y_AUDIO.md).
El catálogo abre inicialmente Videos para conservar la vista previa. Seleccione
Imágenes o Audio en el control superior. Las carátulas usadas por audio/video no se
añaden también como fotos sueltas. Para incluirlas como imágenes, puede autorizar
una carpeta que solo contenga imágenes. No se mueven ni escriben los originales.

Animación0.28: lectura desde ByteBuffer mapeado con descriptores cerrados. Proveedores
no posicionables usan una copia en memoria limitada a64MiB; para animaciones mayores
se necesita una copia local posicionable. Los resultados de guardado SAF esperan
una recarga de pantalla en curso, conservando el temporal preparado.
