# Licencias y componentes

Peach Local es una adaptación independiente, no oficial, distribuida bajo
AGPL-3.0-or-later. El texto se encuentra en LICENSE. Peach original © 2026 longmeidao:
https://github.com/peach-mitao/peach, revisión de referencia
`de22796c04919aaa057d77930c33c81313765569`.

El icono procede del prototipo independiente Peach Mobile entregado con los requisitos.
Se conserva su aviso MIT íntegro en `licenses/Peach-Mobile-icon-MIT.txt`,
© 2026 Peach Mobile Android companion contributors.

| Componente directo | Versión fijada | Licencia | Uso |
|---|---|---|---|
| AndroidX AppCompat | 1.7.1 | Apache-2.0 | Actividades, temas y diálogos |
| AndroidX RecyclerView | 1.4.0 | Apache-2.0 | Mosaico reciclado |
| AndroidX Room | 2.7.2 | Apache-2.0 | Base de datos SQLite |
| AndroidX WorkManager | 2.10.3 | Apache-2.0 | Indexado persistente |
| AndroidX Media3 | 1.8.0 | Apache-2.0 | Reproducción y pistas de texto |
| desugar_jdk_libs | 2.1.5 | GPL-2.0 con Classpath Exception y avisos de terceros | API Java desazucarada |
| JUnit | 4.13.2 | EPL-1.0 | Pruebas; no se empaqueta en la app principal |
| Robolectric | 4.16.1 | MIT | Pruebas locales de base de datos y UI; no se empaqueta en la app |
| AndroidX Test runner/rules/ext/uiautomator | 1.6.2 / 1.6.1 / 1.2.1 / 2.3.0 | Apache-2.0 | APK de pruebas |

Las dependencias transitivas conservan sus licencias: AndroidX y Kotlin (Apache-2.0),
Guava/listenablefuture y Error Prone (Apache-2.0), checker-qual (MIT), jsr305 (BSD-3-Clause),
annotations y colecciones de sus respectivos autores. La lista efectiva resuelta se
puede obtener con `./gradlew :app:dependencies --configuration debugRuntimeClasspath`.
No se sustituyen ni eliminan avisos `META-INF` empaquetados por las dependencias.

La licencia Apache-2.0 está en `licenses/Apache-2.0.txt`. Las fuentes y licencias de
AndroidX se distribuyen en Google Maven junto a sus artefactos. Media3 1.8.0 se fija
como línea estable conocida para este primer APK; no se afirma que sea la versión más
reciente. La documentación vigente consultada también describe líneas posteriores.

El desazucarado Java se suministra con los avisos del proyecto OpenJDK/jdk11 y la
Classpath Exception; deben conservarse al redistribuir su código de ejecución.
Fuente: https://github.com/google/desugar_jdk_libs (LICENSE y ASSEMBLY_EXCEPTION).
No se empaquetan FFmpeg, Python, CloudDrive2 ni los assets multimedia del Peach original.
Robolectric y su runtime de Android/SQLite se usan únicamente en la máquina de pruebas.
Fuente y licencia: https://github.com/robolectric/robolectric, etiqueta robolectric-4.16.1.

El video de prueba se generó con patrones sintéticos de FFmpeg y una señal de audio.
FFmpeg es una herramienta de desarrollo del entorno, no una biblioteca del APK.
El NFO y los subtítulos de prueba son texto creado para este proyecto.

## SQL original en pruebas 0.9.0

Los recursos de prueba original/0000_legacy_schema.sql, 0001_core_boundaries.sql,
0002_canonical_entities.sql y 0017_persistent_playlists.sql proceden sin cambios de
peach-mitao/peach, commit de22796c04919aaa057d77930c33c81313765569, © 2026 longmeidao,
AGPL-3.0-or-later. No se empaquetan como recursos del APK principal. Sus hashes constan
en docs/evidence/0.9.0/upstream-test-schemas.json.

El recurso original/0025_agency_entities.sql de pruebas se conserva sin cambios del
mismo commit original, ©2026 longmeidao, AGPL-3.0-or-later. Las pruebas extraen de
él las definiciones originales de entity_new y entity_membership, sin ejecutar el
servidor ni migrar bases del usuario. Hash en docs/evidence/0.11.0/upstream-agency.json.

Los recursos original/0018_online_follow.sql y original/0042_want_list.sql se conservan
sin cambios del mismo commit, ©2026 longmeidao, AGPL-3.0-or-later. Se extraen definiciones
de follow_source/follow_item/want_item para pruebas SQLite de proyección de solo lectura.
No están en el APK principal. Hashes en docs/evidence/0.12.0/upstream-tracking.json.

## Comprobación opcional FANBOX 0.13.0

Los DTO/lectores Android se implementan para este proyecto tras revisar follow_sources.py,
follow_providers.py y fanbox.py del commit original fijo, AGPL-3.0-or-later. No se incorpora
su backend Python ni transportes de navegador. La comprobación independiente de JDK
usa JSON-java org.json:json:20240303 solo como herramienta externa; su POM indica
Public Domain. El JAR no se entrega en el APK ni es dependencia de la app. Referencia:
https://repo.maven.apache.org/maven2/org/json/json/20240303/json-20240303.pom .
Las pruebas no empaquetan publicaciones o medios de FANBOX. El contrato en vivo guarda
conteos/hashes y el archivo de muestra se elimina tras verificarlo.

## HTML público en 0.14.0

Se incorpora org.jsoup:jsoup:1.23.2, ©2009–2026 Jonathan Hedley y colaboradores, MIT.
Se usa para analizar en memoria el HTML recibido, sin ejecutar scripts o llamar a
su cliente de red. Texto completo en licenses/MIT-jsoup.txt; el JAR conserva
META-INF/jsoup/LICENSE. Referencia oficial: https://jsoup.org/news/release-1.23.2 .
La adaptación revisó PatreonConnector y el registro de proveedores del mismo commit
original fijo de Peach, AGPL-3.0-or-later; no copia su servidor Python o navegador.
Los casos HTML de la suite son sintéticos; no se empaqueta HTML o artículos de Patreon.


## Lectura TAR/GZIP 0.15.0

Se añade Apache Commons Compress 1.28.0 (Apache-2.0), con sus dependencias Commons
IO 2.20.0, Lang3 3.18.0 y Codec 1.19.0 (Apache-2.0 y avisos de terceros incluidos).
Licencias y NOTICE completos de los cuatro JAR se copian sin cambios a licenses/
y app/src/main/assets/licenses/, con nombre distinto por artefacto. Es necesario
porque el empaquetado Android omite los nombres META-INF genéricos de esos JAR.
Los hashes resueltos y verificación de checksum Maven están en
 docs/evidence/0.15.0/archive-dependencies.json. No se añaden sus codecs opcionales
XZ/Brotli/ASM/zstd-jni ni bibliotecas .so. TAR utiliza TarFile/TarUtils; GZIP sigue
usando java.util.zip de Android. La presencia de clases de otros formatos dentro
del JAR no anuncia soporte de esos formatos en el producto.

Fuentes y avisos: https://commons.apache.org/proper/commons-compress/,
https://commons.apache.org/proper/commons-io/, https://commons.apache.org/proper/commons-lang/
y https://commons.apache.org/proper/commons-codec/. La auditoría no equivale a afirmar
que ningún componente tenga vulnerabilidades desconocidas.


## LZMA/LZMA2 en 7z 0.16.0

Se añade org.tukaani:xz:1.12, XZ for Java, bajo0BSD. El texto COPYING original de
la distribución oficial se conserva sin cambios en licenses/xz-1.12-COPYING.txt y
app/src/main/assets/licenses/xz-1.12-COPYING.txt. Fuente: https://tukaani.org/xz/java.html
(1.12,2026-03-01), repositorio https://github.com/tukaani-project/xz-java.
No se empaqueta XZ Utils ni 7zz. Commons Compress1.28.0 y sus avisos se conservan.
El ejecutable de desarrollo7-Zip26.05 se usó solo para crear fixtures propios;
no se distribuye ese ejecutable. Los fixtures cifrados usan una contraseña de prueba
pública sin cuentas reales. Se incluyen hashes/procedencia, no medios de terceros.

## EPUB de texto 0.17.0

Se reutiliza jsoup1.23.2/MIT para parse(String), sin su cliente de red, y las
APIs XML/ZIP de Android. No se añaden dependencias de ejecución o licencias.
Los fixtures EPUB2/3 contienen texto propio y un PNG sintético; el generador y
hashes están en scripts/generate-epub-fixtures.py y resources/epub170.
La referencia de formato es https://www.w3.org/TR/epub-33/; este lector parcial
no constituye implementación completa o certificación de conformidad.

## Sesión de audio0.18.0

Se añade androidx.media3:media3-session:1.8.0 y AndroidX Media 1.7.0 transitivo,
© The Android Open Source Project, Apache-2.0. El texto completo ya está presente
en licenses/Apache-2.0.txt y assets/licenses/Apache-2.0.txt. El AAR Session revisado
no distribuye NOTICE adicional. La versión está alineada con Media3 ExoPlayer/UI 1.8.0.
Fuente: https://github.com/androidx/media, documentación y distribución oficial Google
Maven. Hashes y grafo efectivo en docs/evidence/0.18.0. No se incluye Junrar/UnRAR.
El WAV de prueba repite 20 veces el tono propio previo; no incorpora música de terceros.
Solo está en el APK instrumentado, con generador/provenance y sin ejecución física
atribuida. La firma de la distribución no incluye la clave privada.

## Tipografía Manrope 0.49.0

Se incluyen dos instancias estáticas (SemiBold 600 y Bold 700) generadas sin otros cambios
a partir de Manrope[wght].ttf de https://github.com/google/fonts/tree/main/ofl/manrope ,
© 2019 The Manrope Project Authors, SIL Open Font License 1.1. Texto completo en
licenses/Manrope-OFL-1.1.txt y assets/licenses/Manrope-OFL-1.1.txt. Solo se usan para títulos.
