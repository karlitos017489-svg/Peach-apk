package com.peach.local;

import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.os.*;
import android.provider.DocumentsContract;
import android.view.*;
import android.widget.*;
import androidx.room.Room;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.Until;
import androidx.recyclerview.widget.RecyclerView;
import androidx.media3.common.Player;
import androidx.media3.ui.PlayerView;
import java.io.*;
import java.lang.reflect.Field;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Real Android views, rendering, codec player and compact volume. Only self-owned fixtures. */
@RunWith(AndroidJUnit4.class)
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public class Design480IntegrationTest {
    Context app;LibraryDatabase db,original;SourceHttp.Transport previous;int calls;
    @Before public void setup()throws Exception{UiDevice device=UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());for(int n=0;n<2&&device.hasObject(By.text("System UI isn't responding"));n++){var wait=device.findObject(By.text("Wait"));assertNotNull("Emulator SystemUI ANR must be resolved before UI verification",wait);wait.click();device.wait(Until.gone(By.text("System UI isn't responding")),5000);}assertFalse("Emulator ANR still obscures the app",device.hasObject(By.text("System UI isn't responding")));app=InstrumentationRegistry.getInstrumentation().getTargetContext();Field field=LibraryDatabase.class.getDeclaredField("instance");field.setAccessible(true);original=(LibraryDatabase)field.get(null);db=Room.inMemoryDatabaseBuilder(app,LibraryDatabase.class).allowMainThreadQueries().build();field.set(null,db);previous=SourcesActivity.transport;SourcesActivity.transport=(u,e,m,t)->{calls++;throw new IOException("No real upstream requests in this fixture");};app.getSharedPreferences("source-browser",0).edit().clear().commit();}
    @After public void cleanup()throws Exception{SourcesActivity.transport=previous;LibraryDatabase.IO.submit(()->{}).get(30,TimeUnit.SECONDS);Field field=LibraryDatabase.class.getDeclaredField("instance");field.setAccessible(true);field.set(null,original);db.close();}
    interface Check{boolean run()throws Exception;}
    void await(Check check)throws Exception{long end=SystemClock.elapsedRealtime()+20000;do{if(check.run())return;Thread.sleep(100);}while(SystemClock.elapsedRealtime()<end);assertTrue("UI condition did not complete",check.run());}
    static boolean visible(ActivityScenario<?> scenario,int id){boolean[] yes={false};scenario.onActivity(a->yes[0]=a.findViewById(id).getVisibility()==View.VISIBLE);return yes[0];}
    void capture(String name)throws Exception{InstrumentationRegistry.getInstrumentation().waitForIdleSync();UiDevice device=UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());device.waitForIdle(5000);assertFalse("SystemUI ANR obscures screenshot",device.hasObject(By.text("System UI isn't responding")));SystemClock.sleep(400);File dir=new File(app.getExternalFilesDir(null),"ui048");assertTrue(dir.isDirectory()||dir.mkdirs());File f=new File(dir,name+".png");assertTrue(UiDevice.getInstance(InstrumentationRegistry.getInstrumentation()).takeScreenshot(f));System.out.println("PEACH_UI_SCREENSHOT="+f);}
    @Test public void cachedVisualSourceAndPostStayInOneScreenAcrossRotation()throws Exception{
        SourceStore store=new SourceStore(db,SourcesActivity.transport);String source=store.create("own_design480","Estudio de campo",null);int[] colors={0xff365564,0xffa96754,0xff78639a,0xff587454,0xff375583,0xffb09254};String[] names={"Horizontes","Entre montañas","Luz del desierto","Rutas del norte","La costa","Tiempo y piedra"};
        for(int n=0;n<6;n++){Bitmap bitmap=Bitmap.createBitmap(320,320,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(bitmap);canvas.drawColor(colors[n]);Paint paint=new Paint(3);paint.setColor(0x50ffffff);canvas.drawCircle(260,60,110,paint);paint.setColor(Color.WHITE);paint.setTextSize(24);canvas.drawText("PEACH / "+(n+1),22,250,paint);paint.setTextSize(14);canvas.drawText("Muestra propia de diseño",22,278,paint);ByteArrayOutputStream output=new ByteArrayOutputStream();bitmap.compress(Bitmap.CompressFormat.PNG,100,output);bitmap.recycle();byte[] bytes=output.toByteArray();String url="https://downloads.fanbox.cc/design480-"+n+".png";var image=new SourceGallery.Image("own.png",url);var frame=new GalleryCache(app.getCacheDir()).acquirePreview(image,false,new SourceHttp.Token(),(u,f,t)->SourceHttp.copyAttachment(u,new ByteArrayInputStream(bytes),f,bytes.length,t));frame.release();
            Publication p=new Publication();p.id="native-design480-"+n;p.title=names[n];p.provider="fanbox";p.sourceRef="own_design480";p.sourceLabel="Estudio de campo";p.externalId=String.valueOf(48000+n);p.publishedAt="2026-10-"+(20+n);p.precision="approximate";db.library().insertPublication(p);PublicationContent c=new PublicationContent();c.publicationId=p.id;c.sourceId=source;c.type="image";c.text="Contenido propio para comprobar la lectura dentro de Fuentes.";c.attachments=new JSONArray().put(new JSONObject().put("name","Portada propia.png").put("kind","image").put("url",url).put("downloadable",true)).toString();db.library().putPublicationContent(c);
        }
        app.getSharedPreferences("source-browser",0).edit().putBoolean("home",false).commit();// 0.49: Fuentes recuerda la fuente abierta; sin esto abre en el inicio.
        try(var scenario=ActivityScenario.launch(SourceBrowserActivity.class)){
            await(()->{int[] count={0};scenario.onActivity(a->count[0]=((RecyclerView)a.findViewById(R.id.browser_grid)).getAdapter().getItemCount());return count[0]==6;});Thread.sleep(500);capture("native-sources");
            assertNotNull(UiDevice.getInstance(InstrumentationRegistry.getInstrumentation()).findObject(By.text("Tiempo y piedra")));UiDevice.getInstance(InstrumentationRegistry.getInstrumentation()).findObject(By.text("Tiempo y piedra")).click();assertTrue(visible(scenario,R.id.browser_detail));assertEquals(0,calls);capture("native-publication");scenario.recreate();await(()->visible(scenario,R.id.browser_detail));scenario.onActivity(a->a.findViewById(R.id.browser_back).performClick());assertTrue(visible(scenario,R.id.browser_grid));assertEquals(0,calls);
        }
    }
    @Test public void realPlayerVolumeIsCompactMutesRestoresAndDismissesBeforeStop()throws Exception{
        Uri uri=DocumentsContract.buildDocumentUri(FixtureDocumentsProvider.AUTHORITY,"v0");Intent intent=SourceFiles.play(app,uri,"Video de muestra propio.mp4");
        try(var scenario=ActivityScenario.<PlayerActivity>launch(intent)){
            await(()->{boolean[] ready={false};scenario.onActivity(a->{Player p=((PlayerView)a.findViewById(R.id.player)).getPlayer();ready[0]=p!=null&&p.getPlaybackState()==Player.STATE_READY;});return ready[0];});
            androidx.appcompat.app.AlertDialog[] dialog={null};scenario.onActivity(a->{PlayerView view=a.findViewById(R.id.player);view.showController();a.findViewById(R.id.player_volume).performClick();try{Field field=PlayerActivity.class.getDeclaredField("volumeDialog");field.setAccessible(true);dialog[0]=(androidx.appcompat.app.AlertDialog)field.get(a);}catch(Exception e){throw new AssertionError(e);}assertNotNull(dialog[0]);assertTrue(dialog[0].isShowing());assertTrue(dialog[0].getWindow().getAttributes().width<=UiAppearance.dp(a,280));Player p=view.getPlayer();float before=p.getVolume();dialog[0].findViewById(R.id.volume_mute).performClick();assertEquals(0,p.getVolume(),.001);dialog[0].findViewById(R.id.volume_mute).performClick();assertEquals(before==0?1:before,p.getVolume(),.001);assertNotNull(view.findViewById(androidx.media3.ui.R.id.exo_play_pause));});capture("native-player-volume");scenario.moveToState(androidx.lifecycle.Lifecycle.State.CREATED);assertFalse(dialog[0].isShowing());
        }
    }
    @Test public void nativeLibrarySettingsAndDownloadNavigationAreReachable()throws Exception{
        try(var scenario=ActivityScenario.launch(MainActivity.class)){scenario.onActivity(a->{Button b=a.findViewById(R.id.navSources);assertTrue(b.getHeight()>=48);assertNotNull(b.getCompoundDrawables()[1]);assertEquals("",((Button)a.findViewById(R.id.more)).getText().toString());});capture("native-library");}
        try(var scenario=ActivityScenario.launch(SettingsActivity.class)){scenario.onActivity(a->{assertNotNull(a.findViewById(R.id.settings_search));((EditText)a.findViewById(R.id.settings_search)).setText("apariencia");});capture("native-settings");}
        try(var scenario=ActivityScenario.launch(DownloadQueueActivity.class)){scenario.onActivity(a->assertNotNull(a.findViewById(R.id.queue_start)));capture("native-downloads");}
    }
}
