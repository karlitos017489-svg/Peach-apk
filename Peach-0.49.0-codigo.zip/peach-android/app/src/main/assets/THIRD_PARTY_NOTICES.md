# Licencias y componentes

Peach Local es una adaptación independiente, no oficial, distribuida bajo
AGPL-3.0-or-later. El texto se encuentra en LICENSE. Peach original © 2026 longmeidao:
https://github.com/peach-mitao/peach, revisión de referencia
`de22796c04919aaa057d77930c33c81313765569`.

El icono procede del prototipo independiente Peach Mobile entregado con los requisitos.
Se conserva su aviso MIT íntegro en `licenses/Peach-Mobile-icon-MIT.txt`,
© 2026 Peach Mobile Android companion contributors.

| Componente directo | Versión fijada | Licencia | Uso |
|---|---|---|---|
| AndroidX AppCompat | 1.7.1 | Apache-2.0 | Actividades, temas y diálogos |
| AndroidX RecyclerView | 1.4.0 | Apache-2.0 | Mosaico reciclado |
| AndroidX Room | 2.7.2 | Apache-2.0 | Base de datos SQLite |
| AndroidX WorkManager | 2.10.3 | Apache-2.0 | Indexado persistente |
| AndroidX Media3 | 1.8.0 | Apache-2.0 | Reproducción y pistas de texto |
| desugar_jdk_libs | 2.1.5 | GPL-2.0 con Classpath Exception y avisos de terceros | API Java desazucarada |
| JUnit | 4.13.2 | EPL-1.0 | Pruebas; no se empaqueta en la app principal |
| AndroidX Test runner/rules/ext/uiautomator | 1.6.2 / 1.6.1 / 1.2.1 / 2.3.0 | Apache-2.0 | APK de pruebas |

Las dependencias transitivas conservan sus licencias: AndroidX y Kotlin (Apache-2.0),
Guava/listenablefuture y Error Prone (Apache-2.0), checker-qual (MIT), jsr305 (BSD-3-Clause),
annotations y colecciones de sus respectivos autores. La lista efectiva resuelta se
puede obtener con `./gradlew :app:dependencies --configuration debugRuntimeClasspath`.
No se sustituyen ni eliminan avisos `META-INF` empaquetados por las dependencias.

La licencia Apache-2.0 está en `licenses/Apache-2.0.txt`. Las fuentes y licencias de
AndroidX se distribuyen en Google Maven junto a sus artefactos. Media3 1.8.0 se fija
como línea estable conocida para este primer APK; no se afirma que sea la versión más
reciente. La documentación vigente consultada también describe líneas posteriores.

El desazucarado Java se suministra con los avisos del proyecto OpenJDK/jdk11 y la
Classpath Exception; deben conservarse al redistribuir su código de ejecución.
Fuente: https://github.com/google/desugar_jdk_libs (LICENSE y ASSEMBLY_EXCEPTION).
No se empaquetan FFmpeg, Python, CloudDrive2 ni los assets multimedia del Peach original.

El video de prueba se generó con patrones sintéticos de FFmpeg y una señal de audio.
FFmpeg es una herramienta de desarrollo del entorno, no una biblioteca del APK.
El NFO y los subtítulos de prueba son texto creado para este proyecto.

## libarchive3.8.10 (RAR/RAR5 reader)

Copyright Tim Kientzle and individual contributors. BSD-2-Clause, with per-file notices
and BLAKE2 code under CC0 (selected option). Complete pinned source and its notices are
in third_party/libarchive/libarchive-3.8.10.tar.gz. See licenses/libarchive-3.8.10-COPYING.txt.
The JNI wrapper is part of Peach Local; no UnRAR/Junrar decoder or RAR tool is bundled.

## Tipografía Manrope 0.49.0

Se incluyen dos instancias estáticas (SemiBold 600 y Bold 700) generadas sin otros cambios
a partir de Manrope[wght].ttf de https://github.com/google/fonts/tree/main/ofl/manrope ,
© 2019 The Manrope Project Authors, SIL Open Font License 1.1. Texto completo en
licenses/Manrope-OFL-1.1.txt y assets/licenses/Manrope-OFL-1.1.txt. Solo se usan para títulos.
