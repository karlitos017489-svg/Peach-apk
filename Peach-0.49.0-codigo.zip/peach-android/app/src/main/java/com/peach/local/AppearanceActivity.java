package com.peach.local;

import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.activity.result.contract.ActivityResultContracts;

/** Personalización local: tema, color, fondo, tarjetas y movimiento. Nunca toca biblioteca ni reproducción. */
public final class AppearanceActivity extends PeachActivity {
    private TextView message;private boolean working;
    private final androidx.activity.result.ActivityResultLauncher<Intent> image=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),result->{
        if(result.getResultCode()!=RESULT_OK||result.getData()==null||!SourceFiles.local(result.getData().getData()))return;
        var uri=result.getData().getData();working=true;message.setText("Preparando fondo…");UiAppearance.IO.execute(()->{String text;
            try{UiAppearance.saveWallpaper(getApplicationContext(),uri);text="Fondo guardado para Biblioteca. Puedes retirar el original sin perder este fondo.";}catch(Exception|OutOfMemoryError e){text="No se pudo usar la imagen. Elige JPG, PNG o WebP de hasta 16 MiB; el fondo anterior se conserva.";}
            String done=text;runOnUiThread(()->{working=false;if(!isDestroyed()){message.setText(done);}});
        });
    });
    @Override protected void onCreate(Bundle state){super.onCreate(state);LinearLayout root=UiAppearance.column(this,"Apariencia");
        preview(root);
        section(root,"Tema");
        choices(root,R.id.appearance_mode,new String[]{"Sistema","Oscuro","Claro","Negro puro"},"mode",1);
        section(root,"Estilo");
        choices(root,R.id.appearance_style,new String[]{"Clásico","Cristal"},"style",1);
        TextView glassNote=PeachDesign.text(this,"Cristal: la barra inferior y el mini reproductor dejan ver, difuminado, lo que pasa por detrás.",13,"muted");glassNote.setPadding(PeachDesign.dp(this,4),PeachDesign.dp(this,6),0,0);root.addView(glassNote);
        section(root,"Color de acento");
        swatches(root);
        section(root,"Tarjetas de la biblioteca");
        choices(root,R.id.appearance_density,new String[]{"Compactas","Equilibradas","Grandes","Lista"},"density",1);
        LinearLayout toggle=PeachDesign.row(this);toggle.setPadding(PeachDesign.dp(this,4),PeachDesign.dp(this,10),0,0);
        TextView label=PeachDesign.text(this,"Mostrar la fila \"Continuar\" en Biblioteca",15,"body");toggle.addView(label,new LinearLayout.LayoutParams(0,-2,1));
        androidx.appcompat.widget.SwitchCompat row=new androidx.appcompat.widget.SwitchCompat(this);row.setId(R.id.appearance_continue);row.setContentDescription("Mostrar la fila Continuar");row.setChecked(UiAppearance.prefs(this).getBoolean("continueRow",true));
        row.setOnCheckedChangeListener((b,on)->UiAppearance.prefs(this).edit().putBoolean("continueRow",on).apply());toggle.addView(row);root.addView(toggle);
        section(root,"Animaciones");
        choices(root,R.id.appearance_motion,new String[]{"Ninguna","Suaves","Deslizamiento"},"motion",1);
        section(root,"Fondo de la biblioteca");
        LinearLayout actions=PeachDesign.row(this);
        Button add=PeachDesign.action(this,"Elegir imagen","primary",v->{if(!working)image.launch(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));});add.setId(R.id.appearance_wallpaper);
        Button remove=PeachDesign.action(this,"Quitar fondo","secondary",v->{if(working)return;if(!WallpaperStore.remove(this)){message.setText("No se pudo retirar el fondo.");return;}UiAppearance.clearWallpaperMemory();message.setText("Fondo retirado. Se usa el color del tema.");});remove.setId(R.id.appearance_remove);
        LinearLayout.LayoutParams half=new LinearLayout.LayoutParams(0,PeachDesign.dp(this,48),1);half.setMarginEnd(PeachDesign.dp(this,10));actions.addView(add,half);actions.addView(remove,new LinearLayout.LayoutParams(0,PeachDesign.dp(this,48),1));root.addView(actions);
        TextView strengthLabel=PeachDesign.text(this,"Intensidad del fondo",13,"muted");strengthLabel.setPadding(PeachDesign.dp(this,4),PeachDesign.dp(this,14),0,0);root.addView(strengthLabel);
        SeekBar strength=new SeekBar(this);strength.setId(R.id.appearance_strength);strength.setMax(70);strength.setProgress(Math.max(0,Math.min(70,UiAppearance.prefs(this).getInt("wallpaperStrength",35)-10)));strength.setContentDescription("Intensidad del fondo, de 10 a 80 por ciento");root.addView(strength,new LinearLayout.LayoutParams(-1,PeachDesign.dp(this,48)));
        strength.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){}public void onProgressChanged(SeekBar s,int p,boolean fromUser){}public void onStopTrackingTouch(SeekBar s){UiAppearance.prefs(AppearanceActivity.this).edit().putInt("wallpaperStrength",s.getProgress()+10).apply();}});
        message=PeachDesign.text(this,"Los ajustes se guardan en esta tablet. También se respeta la desactivación de animaciones de Android.",13,"muted");message.setPadding(PeachDesign.dp(this,4),PeachDesign.dp(this,16),0,PeachDesign.dp(this,8));root.addView(message);
    }
    /** Vista previa en vivo con el tema y el color actuales. */
    private void preview(LinearLayout root){
        LinearLayout card=PeachDesign.row(this);card.setId(R.id.appearance_preview);int pad=PeachDesign.dp(this,16);card.setPadding(pad,pad,pad,pad);card.setBackground(UiAppearance.rounded(this,UiAppearance.surface(this),22));
        View art=new View(this);GradientDrawable fill=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{UiAppearance.accent(this),UiAppearance.accentSoft(this,0x55)});fill.setCornerRadius(PeachDesign.dp(this,16));art.setBackground(fill);
        card.addView(art,new LinearLayout.LayoutParams(PeachDesign.dp(this,72),PeachDesign.dp(this,72)));
        LinearLayout text=PeachDesign.column(this);text.setPadding(PeachDesign.dp(this,16),0,PeachDesign.dp(this,8),0);
        TextView title=PeachDesign.text(this,"Tu biblioteca, a tu manera",18,"body");title.setTypeface(UiAppearance.display(this));text.addView(title);
        TextView body=PeachDesign.text(this,"Así se verán tus tarjetas, botones y acentos.",13,"muted");body.setPadding(0,PeachDesign.dp(this,4),0,PeachDesign.dp(this,8));text.addView(body);
        View bar=new View(this);bar.setBackground(UiAppearance.rounded(this,UiAppearance.accent(this),2));text.addView(bar,new LinearLayout.LayoutParams(PeachDesign.dp(this,120),PeachDesign.dp(this,4)));
        card.addView(text,new LinearLayout.LayoutParams(0,-2,1));
        ImageView play=new ImageView(this);play.setImageDrawable(PeachDesign.icon(this,R.drawable.ic_ui_play_filled,UiAppearance.onAccent(this)));play.setScaleType(ImageView.ScaleType.CENTER);
        GradientDrawable dot=new GradientDrawable();dot.setShape(GradientDrawable.OVAL);dot.setColor(UiAppearance.accent(this));play.setBackground(dot);card.addView(play,new LinearLayout.LayoutParams(PeachDesign.dp(this,48),PeachDesign.dp(this,48)));
        root.addView(card);
    }
    private void section(LinearLayout root,String value){TextView t=PeachDesign.text(this,value,15,"body");t.setTypeface(UiAppearance.title(this));t.setPadding(PeachDesign.dp(this,4),PeachDesign.dp(this,24),0,PeachDesign.dp(this,10));root.addView(t);}
    /** Opciones en pastillas: una sola elección visible, sin listas desplegables. */
    private void choices(LinearLayout root,int id,String[] options,String key,int fallback){
        HorizontalScrollView scroll=new HorizontalScrollView(this);scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout row=PeachDesign.row(this);row.setId(id);int current=Math.max(0,Math.min(options.length-1,UiAppearance.prefs(this).getInt(key,fallback)));
        for(int i=0;i<options.length;i++){final int index=i;Button chip=PeachDesign.chip(this,options[i],i==current,v->choose(key,fallback,index));chip.setContentDescription(options[i]+(i==current?", seleccionado":""));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,PeachDesign.dp(this,44));p.setMarginEnd(PeachDesign.dp(this,8));row.addView(chip,p);}
        scroll.addView(row);root.addView(scroll);
    }
    /** Círculos de color; el elegido lleva una marca. */
    private void swatches(LinearLayout root){
        LinearLayout row=PeachDesign.row(this);row.setId(R.id.appearance_accent);int current=UiAppearance.accentIndex(this);boolean dark=UiAppearance.dark(this);
        int[] light={0xff8d4226,0xff245998,0xff246b4e,0xff654398,0xff913b5b,0xff755814};
        for(int i=0;i<UiAppearance.COLORS.length;i++){final int index=i;int color=dark?UiAppearance.COLORS[i]:light[i];
            ImageView swatch=new ImageView(this);GradientDrawable circle=new GradientDrawable();circle.setShape(GradientDrawable.OVAL);circle.setColor(color);
            if(i==current){circle.setStroke(PeachDesign.dp(this,3),UiAppearance.text(this));swatch.setImageDrawable(PeachDesign.icon(this,R.drawable.ic_ui_check,dark?0xff16131a:0xffffffff));}
            swatch.setBackground(circle);swatch.setScaleType(ImageView.ScaleType.CENTER);swatch.setFocusable(true);swatch.setClickable(true);
            swatch.setContentDescription(UiAppearance.NAMES[i]+(i==current?", seleccionado":""));swatch.setOnClickListener(v->{PeachDesign.pop(v);choose("accent",0,index);});
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(PeachDesign.dp(this,48),PeachDesign.dp(this,48));p.setMarginEnd(PeachDesign.dp(this,12));p.gravity=Gravity.CENTER_VERTICAL;row.addView(swatch,p);}
        root.addView(row);
    }
    private void choose(String key,int fallback,int index){if(UiAppearance.prefs(this).getInt(key,fallback)==index)return;UiAppearance.prefs(this).edit().putInt(key,index).apply();recreate();}
}
