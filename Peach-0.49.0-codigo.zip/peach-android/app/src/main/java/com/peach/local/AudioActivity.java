package com.peach.local;

import android.animation.ValueAnimator;
import android.content.ComponentName;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.session.*;
import com.google.common.util.concurrent.ListenableFuture;

/**
 * Reproductor de audio: portada grande, título a la izquierda, controles amplios sin adornos,
 * volumen directo y fondo vivo con los colores de la portada.
 * Solo es un controlador: salir o recrear esta pantalla nunca libera el reproductor del servicio.
 */
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public class AudioActivity extends PeachActivity {
    private static final int BASE=0xff0b0c11,WHITE=0xfff5f5f7,DIM=0x99f5f5f7;
    private androidx.appcompat.app.AlertDialog volumeDialog;
    private MediaController controller;private ListenableFuture<MediaController> connection;
    private boolean started,requestApplied,seeking,favorite;private int generation,tone;
    private ImageView cover,backdrop;private SeekBar seek,volume;private TextView position,duration;
    private Button play,shuffle,repeat,heart;private String artFor="",favoriteFor="";private ValueAnimator drift;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable tick=new Runnable(){@Override public void run(){timeline();sleepLabel();if(started&&controller!=null&&controller.isPlaying())handler.postDelayed(this,500);}};
    private final Player.Listener events=new Player.Listener(){
        @Override public void onEvents(@NonNull Player player,@NonNull Player.Events events){show();}
        @Override public void onPlayerError(@NonNull PlaybackException error){message("No se pudo reproducir. Revisa el permiso y los códecs. Código: "+error.getErrorCodeName());}
        @Override public void onVolumeChanged(float level){if(volume!=null)volume.setProgress(Math.round(level*100));}
    };
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);setContentView(R.layout.activity_audio);requestApplied=state!=null && state.getBoolean("audioRequestApplied");tone=UiAppearance.accent(this);
        WindowCompat.setDecorFitsSystemWindows(getWindow(),false);
        View content=findViewById(R.id.audioContent);int side=PeachDesign.dp(this,28),bottom=PeachDesign.dp(this,16);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.playerRoot),(v,insets)->{var bars=insets.getInsets(WindowInsetsCompat.Type.systemBars()|WindowInsetsCompat.Type.displayCutout());content.setPadding(bars.left+side,bars.top,bars.right+side,bars.bottom+bottom);return insets;});
        cover=findViewById(R.id.audio_cover);backdrop=findViewById(R.id.audio_backdrop);seek=findViewById(R.id.audio_seek);volume=findViewById(R.id.audio_volume);position=findViewById(R.id.audio_position);duration=findViewById(R.id.audio_duration);
        play=findViewById(R.id.audio_play);shuffle=findViewById(R.id.audio_shuffle);repeat=findViewById(R.id.audio_repeat);heart=findViewById(R.id.audio_favorite);
        style();
        findViewById(R.id.back).setOnClickListener(v->finish());
        findViewById(R.id.player_volume).setOnClickListener(v->volumeDialog=PlaybackVolume.show(this,()->controller,v));
        findViewById(R.id.audio_more).setOnClickListener(this::more);
        findViewById(R.id.playerFormats).setOnClickListener(v->formats());
        findViewById(R.id.audio_queue).setOnClickListener(v->{PeachDesign.pop(v);queue();});
        findViewById(R.id.audio_timer).setOnClickListener(v->{PeachDesign.pop(v);sleepTimer();});
        heart.setOnClickListener(v->{MediaItem item=controller==null?null:controller.getCurrentMediaItem();if(item==null)return;String id=item.mediaId;favorite=!favorite;heartState();PeachDesign.pop(v);
            LibraryDatabase.IO.execute(()->{try{LibraryDatabase.get(this).library().toggleFavorite(id);}catch(Exception ignored){/* La marca se recalcula al cambiar de pista. */}});});
        play.setOnClickListener(v->{if(controller==null)return;PeachDesign.pop(v);if(controller.getPlaybackState()==Player.STATE_ENDED){controller.seekToDefaultPosition();controller.play();}else if(controller.getPlayWhenReady())controller.pause();else controller.play();});
        findViewById(R.id.audio_previous).setOnClickListener(v->{if(controller!=null){PeachDesign.pop(v);controller.seekToPrevious();}});
        findViewById(R.id.audio_next).setOnClickListener(v->{if(controller!=null){PeachDesign.pop(v);controller.seekToNext();}});
        shuffle.setOnClickListener(v->{if(controller!=null){PeachDesign.pop(v);controller.setShuffleModeEnabled(!controller.getShuffleModeEnabled());}});
        repeat.setOnClickListener(v->{if(controller==null)return;PeachDesign.pop(v);int mode=controller.getRepeatMode();controller.setRepeatMode(mode==Player.REPEAT_MODE_OFF?Player.REPEAT_MODE_ALL:mode==Player.REPEAT_MODE_ALL?Player.REPEAT_MODE_ONE:Player.REPEAT_MODE_OFF);});
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int value,boolean user){if(!user||controller==null)return;String at=MediaAdapter.duration(Math.max(0,controller.getDuration())*value/1000);position.setText(at.isEmpty()?"0:00":at);}
            public void onStartTrackingTouch(SeekBar s){seeking=true;grow(s,true);}
            public void onStopTrackingTouch(SeekBar s){seeking=false;grow(s,false);if(controller!=null&&controller.getDuration()>0)controller.seekTo(controller.getDuration()*s.getProgress()/1000);}
        });
        volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int value,boolean user){if(user)PlaybackVolume.set(AudioActivity.this,controller,value/100f);}
            public void onStartTrackingTouch(SeekBar s){grow(s,true);}
            public void onStopTrackingTouch(SeekBar s){grow(s,false);}
        });
        findViewById(R.id.audioStop).setVisibility(View.GONE);findViewById(R.id.audioStop).setEnabled(false);
        findViewById(R.id.audioStop).setOnClickListener(v->{if(controller!=null){v.setEnabled(false);var stopped=controller.sendCustomCommand(AudioService.STOP,Bundle.EMPTY);stopped.addListener(()->{if(!started)return;try{if(stopped.get().resultCode==SessionResult.RESULT_SUCCESS)finish();else{v.setEnabled(true);message("No se pudo detener el audio.");}}catch(Exception error){v.setEnabled(true);message("No se pudo detener el audio.");}},ContextCompat.getMainExecutor(this));}});
        ((TextView)findViewById(R.id.playerTitle)).setText("Audio de Peach");
        ((TextView)findViewById(R.id.audioInfo)).setText("Conectando al audio…");
        View box=findViewById(R.id.audioCoverBox);box.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->fitCover(r-l,b-t));
        content.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->fitControls(r-l-v.getPaddingLeft()-v.getPaddingRight()));
        swipeToClose(box,content);
    }
    /** Estilo fijo de reproductor (siempre oscuro): texto blanco, botones sin fondo y cristal en los secundarios. */
    private void style(){
        TextView header=findViewById(R.id.audio_header);header.setTextColor(DIM);header.setTypeface(UiAppearance.title(this));
        TextView title=findViewById(R.id.playerTitle);title.setTextColor(WHITE);title.setTypeface(UiAppearance.display(this));
        ((TextView)findViewById(R.id.audioInfo)).setTextColor(DIM);position.setTextColor(DIM);duration.setTextColor(DIM);
        cover.setBackground(UiAppearance.rounded(this,0xff1d1f28,18));cover.setClipToOutline(true);cover.setElevation(PeachDesign.dp(this,24));cover.setImageResource(R.drawable.art_audio);
        Button back=findViewById(R.id.back);plain(back);GradientDrawable grip=new GradientDrawable();grip.setCornerRadius(PeachDesign.dp(this,3));grip.setColor(0x80ffffff);
        back.setBackground(new InsetDrawable(grip,PeachDesign.dp(this,16),PeachDesign.dp(this,15),PeachDesign.dp(this,16),PeachDesign.dp(this,15)));
        for(Button b:new Button[]{findViewById(R.id.audio_previous),findViewById(R.id.audio_next),play,shuffle,repeat,heart,findViewById(R.id.audio_more),findViewById(R.id.audio_queue),findViewById(R.id.audio_timer),findViewById(R.id.player_volume)})plain(b);
        for(Button b:new Button[]{heart,findViewById(R.id.audio_more)}){GradientDrawable dot=new GradientDrawable();dot.setShape(GradientDrawable.OVAL);dot.setColor(0x26ffffff);b.setBackground(new android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(0x33ffffff),dot,null));}
        icon(findViewById(R.id.audio_more),R.drawable.ic_ui_more_horizontal,WHITE,22);
        icon(findViewById(R.id.audio_previous),R.drawable.ic_ui_previous,WHITE,40);icon(findViewById(R.id.audio_next),R.drawable.ic_ui_next,WHITE,40);
        icon(findViewById(R.id.audio_queue),R.drawable.ic_ui_queue,DIM,24);icon(findViewById(R.id.audio_timer),R.drawable.ic_ui_moon,DIM,24);icon(findViewById(R.id.player_volume),R.drawable.ic_ui_volume,DIM,22);
        ((ImageView)findViewById(R.id.audio_volume_low)).setImageDrawable(PeachDesign.icon(this,R.drawable.ic_ui_volume_low,DIM));
        slim(seek);slim(volume);volume.setProgress(Math.round(PlaybackVolume.saved(this)*100));
        backdrop.setImageDrawable(null);paint();
    }
    private void plain(Button b){b.setText("");b.setAllCaps(false);b.setStateListAnimator(null);b.setBackgroundTintList(null);b.setMinWidth(0);b.setMinimumWidth(0);b.setMinHeight(0);b.setMinimumHeight(0);b.setPadding(0,0,0,0);b.setGravity(Gravity.CENTER);
        GradientDrawable mask=new GradientDrawable();mask.setShape(GradientDrawable.OVAL);mask.setColor(0xff000000);b.setBackground(new android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(0x33ffffff),null,mask));}
    /**
     * Icono centrado dentro del botón. Solo se redibuja si cambia (otro icono, color o tamaño): el
     * reloj del reproductor lo consulta cada medio segundo y redibujarlo siempre lo hacía parpadear.
     */
    private void icon(Button b,int id,int color,int size){
        String key=id+"|"+color+"|"+size;if(key.equals(b.getTag(R.id.audio_icon_key)))return;b.setTag(R.id.audio_icon_key,key);
        var d=PeachDesign.icon(this,id,color);int px=PeachDesign.dp(this,size);d.setBounds(0,0,px,px);b.setCompoundDrawables(d,null,null,null);center(b,px);
    }
    /** El centrado se recalcula solo cuando el botón cambia de tamaño, nunca dejándolo un instante sin margen. */
    private void center(Button b,int px){
        boolean listening=b.getTag(R.id.audio_icon_size)!=null;b.setTag(R.id.audio_icon_size,px);
        if(!listening)b.addOnLayoutChangeListener((v,l,t,r,bottom,ol,ot,or,ob)->{int size=(Integer)v.getTag(R.id.audio_icon_size);int pad=Math.max(0,(r-l-size)/2);if(v.getPaddingLeft()!=pad)v.post(()->v.setPadding(pad,0,0,0));});
        int width=b.getWidth()>0?b.getWidth():b.getLayoutParams()!=null&&b.getLayoutParams().width>0?b.getLayoutParams().width:0;
        if(width>0){int pad=Math.max(0,(width-px)/2);if(b.getPaddingLeft()!=pad)b.setPadding(pad,0,0,0);}
    }
    /** Barra fina sin bolita: blanco lo recorrido, translúcido el resto. Se ensancha al arrastrar. */
    private void slim(SeekBar bar){
        int h=PeachDesign.dp(this,5);float r=h/2f;
        GradientDrawable track=new GradientDrawable();track.setCornerRadius(r);track.setColor(0x40ffffff);track.setSize(-1,h);
        GradientDrawable fill=new GradientDrawable();fill.setCornerRadius(r);fill.setColor(0xe6ffffff);fill.setSize(-1,h);
        LayerDrawable layers=new LayerDrawable(new Drawable[]{track,new ClipDrawable(fill,Gravity.START,ClipDrawable.HORIZONTAL)});layers.setId(0,android.R.id.background);layers.setId(1,android.R.id.progress);
        for(int i=0;i<2;i++){layers.setLayerGravity(i,Gravity.CENTER_VERTICAL);layers.setLayerHeight(i,h);}
        bar.setProgressDrawable(layers);GradientDrawable none=new GradientDrawable();none.setSize(1,1);none.setColor(0);bar.setThumb(none);bar.setThumbOffset(0);bar.setBackground(null);
    }
    private void grow(View bar,boolean on){bar.animate().scaleY(on?1.7f:1f).setDuration(160).start();}
    /** Aplica el color dominante de la portada al degradado del fondo. */
    private void paint(){
        GradientDrawable scrim=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{(tone&0x00ffffff)|0x55000000,(mix(tone,BASE,.55f)&0x00ffffff)|0xb3000000,(BASE&0x00ffffff)|0xf2000000});
        findViewById(R.id.audioScrim).setBackground(scrim);
        modes();playState();heartState();
    }
    private static int mix(int a,int b,float t){int ar=(a>>16)&255,ag=(a>>8)&255,ab=a&255,br=(b>>16)&255,bg=(b>>8)&255,bb=b&255;return 0xff000000|Math.round(ar+(br-ar)*t)<<16|Math.round(ag+(bg-ag)*t)<<8|Math.round(ab+(bb-ab)*t);}
    private void fitCover(int width,int height){int pad=PeachDesign.dp(this,36);int size=Math.max(PeachDesign.dp(this,120),Math.min(Math.min(width,height)-pad,PeachDesign.dp(this,480)));var p=cover.getLayoutParams();if(p.width!=size){p.width=size;p.height=size;cover.post(()->cover.setLayoutParams(p));}}
    private void fitControls(int width){int max=Math.min(width,PeachDesign.dp(this,520));for(int id:new int[]{R.id.audioTitleRow,R.id.audioTimeline,R.id.audioControls,R.id.audioVolumeRow,R.id.audio_extras}){View v=findViewById(id);var p=v.getLayoutParams();if(p.width!=max){p.width=max;v.post(()->v.setLayoutParams(p));}}}
    /** Deslizar la portada hacia abajo cierra el reproductor, como una hoja. */
    @android.annotation.SuppressLint("ClickableViewAccessibility")
    private void swipeToClose(View handle,View content){
        float[] start={0};int limit=PeachDesign.dp(this,140);
        handle.setOnTouchListener((v,e)->{switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN->{start[0]=e.getRawY();return true;}
            case MotionEvent.ACTION_MOVE->{float dy=Math.max(0,e.getRawY()-start[0]);content.setTranslationY(dy*.6f);content.setAlpha(1-Math.min(.4f,dy/(limit*4f)));return true;}
            case MotionEvent.ACTION_UP,MotionEvent.ACTION_CANCEL->{float dy=e.getRawY()-start[0];if(dy>limit&&e.getActionMasked()==MotionEvent.ACTION_UP){finish();}else{content.animate().translationY(0).alpha(1).setDuration(220).start();if(Math.abs(dy)<PeachDesign.dp(this,8))v.performClick();}return true;}
            default->{return false;}
        }});
    }
    private void more(View anchor){
        PopupMenu menu=new PopupMenu(this,anchor);
        boolean active=controller!=null&&controller.getCurrentMediaItem()!=null;
        menu.getMenu().add(0,3,0,"Cola de reproducción").setEnabled(active);
        menu.getMenu().add(0,4,1,"Temporizador para dormir").setEnabled(active);
        menu.getMenu().add(0,1,2,"Pistas y compatibilidad");
        menu.getMenu().add(0,2,3,R.string.audio_stop).setEnabled(findViewById(R.id.audioStop).isEnabled());
        menu.setOnMenuItemClickListener(item->{switch(item.getItemId()){case 1->formats();case 3->queue();case 4->sleepTimer();default->findViewById(R.id.audioStop).performClick();}return true;});menu.show();
    }
    /** Lista de la cola actual; tocar una pista salta a ella sin cambiar la selección. */
    private void queue(){
        if(controller==null)return;int count=controller.getMediaItemCount(),current=controller.getCurrentMediaItemIndex();if(count==0)return;String[] names=new String[count];
        for(int i=0;i<count;i++){CharSequence t=controller.getMediaItemAt(i).mediaMetadata.title;names[i]=(i==current?"▶  ":(i+1)+".  ")+(TextUtils.isEmpty(t)?"Audio "+(i+1):t);}
        var dialog=new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Cola · "+count+(count==1?" audio":" audios")).setItems(names,(d,which)->{if(controller!=null&&which!=controller.getCurrentMediaItemIndex()){controller.seekTo(which,0);controller.play();}}).setNegativeButton("Cerrar",null).create();
        dialog.setOnShowListener(d->{if(dialog.getListView()!=null&&current>2)dialog.getListView().setSelection(current-2);});dialog.show();
    }
    private static final int[] SLEEP_MINUTES={0,15,30,45,60,90,-1};
    /** Pausa el audio después de un tiempo o al terminar la pista actual; vive en el servicio. */
    private void sleepTimer(){
        String[] labels={"Desactivado","15 minutos","30 minutos","45 minutos","1 hora","1 hora 30 minutos","Al terminar este audio"};
        new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Temporizador para dormir").setItems(labels,(d,which)->{if(controller==null)return;Bundle args=new Bundle();args.putInt("minutes",SLEEP_MINUTES[which]);
            var result=controller.sendCustomCommand(AudioService.SLEEP,args);result.addListener(this::sleepLabel,ContextCompat.getMainExecutor(this));}).setNegativeButton("Cerrar",null).show();
    }
    private void sleepLabel(){
        TextView header=findViewById(R.id.audio_header);long at=AudioService.sleepAt();boolean on=AudioService.sleepAtEnd()||at>0;
        if(AudioService.sleepAtEnd())header.setText("Se pausa al terminar este audio");
        else if(at>0){long left=Math.max(1,(at-System.currentTimeMillis()+59_999)/60_000);header.setText("Se pausa en "+left+" min");}
        else header.setText("Reproduciendo");
        Button timer=findViewById(R.id.audio_timer);icon(timer,R.drawable.ic_ui_moon,on?WHITE:DIM,24);timer.setContentDescription(on?"Temporizador activo: "+header.getText():"Temporizador para dormir");
    }
    private void heartState(){
        icon(heart,favorite?R.drawable.ic_ui_heart_filled:R.drawable.ic_ui_heart,WHITE,20);heart.setContentDescription(favorite?"Quitar de favoritos":"Marcar como favorito");
    }
    private void loadFavorite(String id){
        favoriteFor=id;LibraryDatabase.IO.execute(()->{boolean value;try{MediaEntry m=LibraryDatabase.get(this).library().get(id);value=m!=null&&m.favorite;}catch(Exception e){value=false;}
            boolean result=value;runOnUiThread(()->{if(!isDestroyed()&&id.equals(favoriteFor)){favorite=result;heartState();}});});
    }
    private void formats(){new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Pistas y compatibilidad").setMessage(PlaybackFormat.describe(controller==null?androidx.media3.common.Tracks.EMPTY:controller.getCurrentTracks())).setPositiveButton("Cerrar",null).show();}
    protected ListenableFuture<MediaController> connect(){return new MediaController.Builder(this,new SessionToken(this,new ComponentName(this,AudioService.class)))
        .setListener(new MediaController.Listener(){@Override public void onDisconnected(@NonNull MediaController ignored){if(started){message("El audio se detuvo. Puedes abrirlo de nuevo desde la biblioteca.");findViewById(R.id.audioStop).setEnabled(false);}}
            @Override public void onError(@NonNull MediaController ignored,@NonNull SessionError error){message(error.message);}}).buildAsync();}
    @Override protected void onStart(){super.onStart();started=true;int token=++generation;connection=connect();var pending=connection;
        pending.addListener(()->{if(!started || token!=generation)return;try{controller=pending.get();controller.addListener(events);volume.setProgress(Math.round(controller.getVolume()*100));show();
            String id=getIntent().getStringExtra("mediaId");
            if(id!=null && (!requestApplied || controller.getMediaItemCount()==0)){
                var result=controller.sendCustomCommand(AudioService.SELECT,getIntent().getExtras()==null?Bundle.EMPTY:getIntent().getExtras());
                result.addListener(()->{if(!started || token!=generation)return;try{var reply=result.get();if(reply.resultCode==SessionResult.RESULT_SUCCESS){requestApplied=true;findViewById(R.id.playerError).setVisibility(View.GONE);show();}else message(reply.extras.getString("message","No se pudo abrir la selección de audio."));}catch(Exception error){message("No se pudo abrir la selección de audio.");}},ContextCompat.getMainExecutor(this));
            }
        }catch(Exception error){message("No se pudo conectar al audio. Abre el archivo desde la biblioteca.");}},ContextCompat.getMainExecutor(this));
    }
    private void show(){if(controller==null)return;MediaItem item=controller.getCurrentMediaItem();boolean active=item!=null;findViewById(R.id.audioStop).setEnabled(active);
        ((TextView)findViewById(R.id.playerTitle)).setText(active?item.mediaMetadata.title:"Audio de Peach");
        CharSequence artist=active?item.mediaMetadata.artist:null;String count=active&&controller.getMediaItemCount()>1?(controller.getCurrentMediaItemIndex()+1)+" de "+controller.getMediaItemCount():"";
        ((TextView)findViewById(R.id.audioInfo)).setText(!active?"No hay audio activo. Abre uno desde la biblioteca.":!TextUtils.isEmpty(artist)?artist+(count.isEmpty()?"":" · "+count):count.isEmpty()?"En reproducción":"En reproducción · "+count);
        if(controller.getPlayerError()==null && active)findViewById(R.id.playerError).setVisibility(View.GONE);
        if(active&&!item.mediaId.equals(artFor))artwork(item);
        if(active&&!item.mediaId.equals(favoriteFor))loadFavorite(item.mediaId);
        heart.setVisibility(active?View.VISIBLE:View.INVISIBLE);sleepLabel();
        playState();modes();timeline();handler.removeCallbacks(tick);if(controller.isPlaying())handler.postDelayed(tick,500);
    }
    /** Portada: póster o carátula del archivo; si no hay, la incrustada que lea el reproductor; si no, ilustración. */
    private void artwork(MediaItem item){
        artFor=item.mediaId;String expected=artFor;byte[] embedded=controller==null?null:controller.getMediaMetadata().artworkData;
        AudioArt.forMedia(this,expected,900,bitmap->{
            if(!expected.equals(artFor))return;
            Bitmap art=bitmap!=null?bitmap:AudioArt.decode(embedded,900);
            if(art==null){cover.setImageResource(R.drawable.art_audio);backdrop.setImageDrawable(null);tone=UiAppearance.accent(this);paint();return;}
            PeachDesign.crossfade(cover,art);
            Bitmap blur=Bitmap.createScaledBitmap(art,24,24,true);backdrop.setImageBitmap(blur);
            if(android.os.Build.VERSION.SDK_INT>=31)backdrop.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(80,80,android.graphics.Shader.TileMode.CLAMP));
            if(UiAppearance.motion(this)){backdrop.setAlpha(0);backdrop.animate().alpha(.9f).setDuration(500).start();}
            tone=AudioArt.tone(art,UiAppearance.accent(this));paint();
        });
    }
    private void playState(){
        if(play==null)return;boolean playing=controller!=null&&controller.getPlayWhenReady()&&controller.getPlaybackState()!=Player.STATE_ENDED;
        icon(play,playing?R.drawable.ic_ui_pause_filled:R.drawable.ic_ui_play_filled,WHITE,56);play.setContentDescription(playing?"Pausar":"Reproducir");
        // La portada "respira": grande al sonar, un poco más pequeña en pausa.
        float scale=playing?1f:.86f;if(cover.getScaleX()!=scale){if(UiAppearance.motion(this))cover.animate().scaleX(scale).scaleY(scale).setDuration(420).setInterpolator(new android.view.animation.OvershootInterpolator(1.1f)).start();else{cover.setScaleX(scale);cover.setScaleY(scale);}}
        motion(playing);
    }
    /** Fondo vivo: la portada difuminada se desplaza y respira despacio mientras suena. */
    private void motion(boolean playing){
        if(!UiAppearance.motion(this)){if(drift!=null){drift.cancel();drift=null;}return;}
        if(drift==null){drift=ValueAnimator.ofFloat(0f,1f);drift.setDuration(16000);drift.setRepeatMode(ValueAnimator.REVERSE);drift.setRepeatCount(ValueAnimator.INFINITE);
            drift.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
            drift.addUpdateListener(a->{float t=(float)a.getAnimatedValue();backdrop.setScaleX(1.25f+.2f*t);backdrop.setScaleY(1.25f+.2f*t);backdrop.setTranslationX((t-.5f)*backdrop.getWidth()*.08f);backdrop.setTranslationY((.5f-t)*backdrop.getHeight()*.06f);backdrop.setRotation((t-.5f)*6f);});}
        if(playing){if(drift.isPaused())drift.resume();else if(!drift.isStarted())drift.start();}else if(drift.isRunning())drift.pause();
    }
    private void modes(){
        boolean shuffled=controller!=null&&controller.getShuffleModeEnabled();int mode=controller==null?Player.REPEAT_MODE_OFF:controller.getRepeatMode();
        icon(shuffle,R.drawable.ic_ui_shuffle,shuffled?WHITE:DIM,24);shuffle.setContentDescription(shuffled?"Orden aleatorio activado":"Orden aleatorio");chip(shuffle,shuffled);
        icon(repeat,mode==Player.REPEAT_MODE_ONE?R.drawable.ic_ui_repeat_one:R.drawable.ic_ui_repeat,mode==Player.REPEAT_MODE_OFF?DIM:WHITE,24);chip(repeat,mode!=Player.REPEAT_MODE_OFF);
        repeat.setContentDescription(mode==Player.REPEAT_MODE_ONE?"Repetir este audio":mode==Player.REPEAT_MODE_ALL?"Repetir la lista":"Repetir desactivado");
    }
    /** Las opciones activas llevan una pastilla de cristal detrás del icono. */
    private void chip(Button b,boolean on){if(Boolean.valueOf(on).equals(b.getTag(R.id.audio_chip_state)))return;b.setTag(R.id.audio_chip_state,on);GradientDrawable pill=new GradientDrawable();pill.setCornerRadius(PeachDesign.dp(this,14));pill.setColor(on?0x2effffff:0);
        b.setBackground(new android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(0x33ffffff),new InsetDrawable(pill,PeachDesign.dp(this,18),PeachDesign.dp(this,6),PeachDesign.dp(this,18),PeachDesign.dp(this,6)),null));}
    private void timeline(){
        if(controller==null||seeking)return;long total=Math.max(0,controller.getDuration()),now=Math.max(0,controller.getCurrentPosition());
        seek.setProgress(total>0?(int)Math.min(1000,now*1000/total):0);
        String at=MediaAdapter.duration(now),left=MediaAdapter.duration(Math.max(0,total-now));position.setText(at.isEmpty()?"0:00":at);duration.setText(total<=0?"0:00":"−"+(left.isEmpty()?"0:00":left));
    }
    private void message(String value){if(isDestroyed())return;TextView error=findViewById(R.id.playerError);error.setText(value);error.setVisibility(View.VISIBLE);}
    @Override protected void onNewIntent(android.content.Intent intent){super.onNewIntent(intent);setIntent(intent);requestApplied=false;show();}
    @Override protected void onStop(){if(volumeDialog!=null){volumeDialog.dismiss();volumeDialog=null;}handler.removeCallbacks(tick);if(drift!=null)drift.pause();started=false;generation++;if(controller!=null)controller.removeListener(events);controller=null;if(connection!=null){MediaController.releaseFuture(connection);connection=null;}super.onStop();}
    @Override protected void onDestroy(){if(drift!=null){drift.cancel();drift=null;}super.onDestroy();}
    @Override protected void onSaveInstanceState(@NonNull Bundle state){state.putBoolean("audioRequestApplied",requestApplied);super.onSaveInstanceState(state);}
    @Override public void finish(){super.finish();overridePendingTransition(R.anim.peach_hold,UiAppearance.motion(this)?R.anim.peach_sheet_out:0);}
}
