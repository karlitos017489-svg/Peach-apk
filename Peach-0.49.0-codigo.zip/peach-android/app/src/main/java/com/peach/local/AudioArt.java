package com.peach.local;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.util.LruCache;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/**
 * Portadas de audio: primero la imagen asociada (póster/NFO), después la carátula incrustada
 * en el propio archivo (MP3/ID3, FLAC, M4A…). Solo lectura local; nunca modifica el archivo.
 */
final class AudioArt {
    private AudioArt() {}
    private static final LruCache<String,Bitmap> CACHE=new LruCache<>(6*1024*1024) {
        @Override protected int sizeOf(String key,Bitmap value) { return value.getAllocationByteCount(); }
    };
    /** Un solo hilo: la decodificación de portadas nunca compite con la base de datos. */
    static final ExecutorService IO=Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"peach-audio-art");t.setDaemon(true);return t;});

    static void clearMemory(){CACHE.evictAll();}

    /** Carátula incrustada en el archivo de audio, reducida a {@code edge} píxeles como máximo. */
    static Bitmap embedded(Context context,Uri uri,int edge) {
        MediaMetadataRetriever retriever=new MediaMetadataRetriever();
        try {
            retriever.setDataSource(context,uri);
            return decode(retriever.getEmbeddedPicture(),edge);
        } catch (Exception | OutOfMemoryError ignored) {
            return null; // Sin carátula o formato no compatible: se usa la ilustración genérica.
        } finally {
            try { retriever.release(); } catch (Exception ignored) { /* Ya liberado. */ }
        }
    }

    static Bitmap decode(byte[] data,int edge) {
        if (data==null || data.length==0 || data.length>24*1024*1024) return null;
        BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;
        BitmapFactory.decodeByteArray(data,0,data.length,bounds);
        if (bounds.outWidth<=0 || bounds.outHeight<=0) return null;
        int sample=1;while (Math.max(bounds.outWidth,bounds.outHeight)/(sample*2)>=edge) sample*=2;
        BitmapFactory.Options options=new BitmapFactory.Options();options.inSampleSize=sample;
        Bitmap bitmap=BitmapFactory.decodeByteArray(data,0,data.length,options);
        if (bitmap==null) return null;
        int longest=Math.max(bitmap.getWidth(),bitmap.getHeight());
        if (longest<=edge) return bitmap;
        float scale=edge/(float)longest;
        Bitmap scaled=Bitmap.createScaledBitmap(bitmap,Math.max(1,Math.round(bitmap.getWidth()*scale)),Math.max(1,Math.round(bitmap.getHeight()*scale)),true);
        if (scaled!=bitmap) bitmap.recycle();
        return scaled;
    }

    /** Debe llamarse fuera del hilo principal. Devuelve null cuando el audio no tiene portada. */
    static Bitmap load(Context context,MediaEntry media,int edge) {
        if (media==null) return null;
        String key=media.id+"|"+media.modified+"|"+media.poster+"|"+edge;
        Bitmap cached=CACHE.get(key);if (cached!=null) return cached;
        Bitmap bitmap=null;
        if (!media.poster.isEmpty()) {
            try { bitmap=ImageFiles.decode(context.getContentResolver(),Uri.parse(media.poster),edge).bitmap(); }
            catch (Exception | OutOfMemoryError ignored) { /* Se intenta la carátula incrustada. */ }
        }
        if (bitmap==null && MediaRules.playable(media)) bitmap=embedded(context,Uri.parse(media.uri),edge);
        if (bitmap!=null) CACHE.put(key,bitmap);
        return bitmap;
    }

    /** Carga asíncrona por identificador de la biblioteca; el resultado llega en el hilo principal. */
    static void forMedia(Activity activity,String mediaId,int edge,Consumer<Bitmap> done) {
        if (mediaId==null || mediaId.isEmpty()) { done.accept(null); return; }
        Context app=activity.getApplicationContext();
        try {
            IO.execute(()->{
                Bitmap result=null;
                try { result=load(app,LibraryDatabase.get(app).library().get(mediaId),edge); }
                catch (Exception | OutOfMemoryError ignored) { /* Ilustración genérica. */ }
                Bitmap art=result;
                activity.runOnUiThread(()->{ if (!activity.isDestroyed()) done.accept(art); });
            });
        } catch (java.util.concurrent.RejectedExecutionException ignored) { done.accept(null); }
    }

    /** Color dominante y vivo de la portada, ajustado para verse bien sobre fondo oscuro. */
    static int tone(Bitmap bitmap,int fallback) {
        if (bitmap==null || bitmap.isRecycled()) return fallback;
        Bitmap small=Bitmap.createScaledBitmap(bitmap,16,16,true);
        double weight=0,r=0,g=0,b=0;float[] hsv=new float[3];
        for (int y=0;y<16;y++) for (int x=0;x<16;x++) {
            int pixel=small.getPixel(x,y);Color.colorToHSV(pixel,hsv);
            double w=0.15+hsv[1]*hsv[2];weight+=w;
            r+=Color.red(pixel)*w;g+=Color.green(pixel)*w;b+=Color.blue(pixel)*w;
        }
        if (small!=bitmap) small.recycle();
        if (weight<=0) return fallback;
        Color.colorToHSV(Color.rgb((int)(r/weight),(int)(g/weight),(int)(b/weight)),hsv);
        if (hsv[1]<0.12f) return fallback; // Portada casi gris: se conserva el acento elegido.
        hsv[1]=Math.max(0.35f,Math.min(0.75f,hsv[1]));hsv[2]=Math.max(0.78f,Math.min(0.95f,hsv[2]));
        return Color.HSVToColor(hsv);
    }
}
