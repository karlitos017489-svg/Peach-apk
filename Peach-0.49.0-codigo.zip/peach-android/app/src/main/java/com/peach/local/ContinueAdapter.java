package com.peach.local;

import android.content.Context;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;

/** Fila horizontal "Continuar": lo que dejaste a medias, lo más reciente primero. Solo lectura. */
final class ContinueAdapter extends RecyclerView.Adapter<ContinueAdapter.Holder> {
    static final int LIMIT=12;
    private final Consumer<MediaEntry> open;private List<MediaEntry> items=List.of();
    ContinueAdapter(Consumer<MediaEntry> open){this.open=open;}

    /** Videos y audios empezados y no terminados, ordenados por última reproducción. */
    static List<MediaEntry> pick(List<MediaEntry> media) {
        List<MediaEntry> started=new ArrayList<>();
        for (MediaEntry m:media) if (!m.missing && !m.watched && m.position>0 && m.duration>0 && MediaRules.playable(m)) started.add(m);
        started.sort(Comparator.comparingLong((MediaEntry m)->m.lastPlayed).reversed());
        return started.size()>LIMIT?List.copyOf(started.subList(0,LIMIT)):List.copyOf(started);
    }
    void submit(List<MediaEntry> next){
        if (next.size()==items.size()) { boolean same=true;for (int i=0;i<next.size()&&same;i++){MediaEntry a=next.get(i),b=items.get(i);same=a.id.equals(b.id)&&a.position==b.position&&a.poster.equals(b.poster);} if (same) return; }
        items=next;notifyDataSetChanged();
    }
    @Override public int getItemCount(){return items.size();}

    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent,int type){
        Context c=parent.getContext();
        LinearLayout card=PeachDesign.column(c);card.setPadding(0,0,PeachDesign.dp(c,12),0);card.setFocusable(true);card.setClickable(true);
        card.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(UiAppearance.accentSoft(c,0x26)),null,UiAppearance.rounded(c,0xff000000,16)));
        FrameLayout frame=new FrameLayout(c);
        ImageView image=new ImageView(c);image.setScaleType(ImageView.ScaleType.CENTER_CROP);image.setBackground(UiAppearance.rounded(c,UiAppearance.surface(c),16));image.setClipToOutline(true);
        frame.addView(image,new FrameLayout.LayoutParams(-1,-1));
        ImageView play=new ImageView(c);play.setImageDrawable(PeachDesign.icon(c,R.drawable.ic_ui_play_filled,UiAppearance.onAccent(c)));play.setScaleType(ImageView.ScaleType.CENTER);
        android.graphics.drawable.GradientDrawable dot=new android.graphics.drawable.GradientDrawable();dot.setShape(android.graphics.drawable.GradientDrawable.OVAL);dot.setColor(UiAppearance.accent(c));play.setBackground(dot);play.setElevation(PeachDesign.dp(c,4));
        FrameLayout.LayoutParams corner=new FrameLayout.LayoutParams(PeachDesign.dp(c,38),PeachDesign.dp(c,38),Gravity.BOTTOM|Gravity.START);corner.setMargins(PeachDesign.dp(c,10),0,0,PeachDesign.dp(c,14));frame.addView(play,corner);
        ProgressBar bar=new ProgressBar(c,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(1000);
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(UiAppearance.accent(c)));bar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0x55ffffff));
        FrameLayout.LayoutParams bottom=new FrameLayout.LayoutParams(-1,PeachDesign.dp(c,3),Gravity.BOTTOM);bottom.setMargins(PeachDesign.dp(c,10),0,PeachDesign.dp(c,10),PeachDesign.dp(c,6));frame.addView(bar,bottom);
        card.addView(frame,new LinearLayout.LayoutParams(PeachDesign.dp(c,208),PeachDesign.dp(c,118)));
        TextView title=PeachDesign.text(c,"",14,"body");title.setTypeface(UiAppearance.title(c));title.setSingleLine(true);title.setEllipsize(TextUtils.TruncateAt.END);title.setPadding(PeachDesign.dp(c,2),PeachDesign.dp(c,8),0,0);
        TextView info=PeachDesign.text(c,"",12,"muted");info.setSingleLine(true);info.setPadding(PeachDesign.dp(c,2),PeachDesign.dp(c,2),0,PeachDesign.dp(c,6));
        card.addView(title,new LinearLayout.LayoutParams(PeachDesign.dp(c,208),-2));card.addView(info,new LinearLayout.LayoutParams(PeachDesign.dp(c,208),-2));
        card.setLayoutParams(new RecyclerView.LayoutParams(-2,-2));
        return new Holder(card,image,title,info,bar);
    }
    @Override public void onBindViewHolder(@NonNull Holder h,int position){
        MediaEntry m=items.get(position);Context c=h.itemView.getContext();
        h.title.setText(m.displayTitle());
        long left=Math.max(0,m.duration-m.position)/60000;
        h.info.setText(MediaRules.label(m.mediaType)+" · "+(left<1?"Menos de 1 min":"Quedan "+left+" min"));
        h.bar.setProgress((int)Math.min(1000,m.position*1000/Math.max(1,m.duration)));
        Thumbnails.load(c,m,h.image);
        h.itemView.setContentDescription("Continuar "+m.displayTitle()+". "+h.info.getText());
        h.itemView.setOnClickListener(v->open.accept(m));
    }
    static final class Holder extends RecyclerView.ViewHolder {
        final ImageView image;final TextView title,info;final ProgressBar bar;
        Holder(View v,ImageView image,TextView title,TextView info,ProgressBar bar){super(v);this.image=image;this.title=title;this.info=info;this.bar=bar;}
    }
}
