package com.peach.local;

import android.app.Application;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.*;
import androidx.lifecycle.*;
import androidx.activity.result.*;
import androidx.activity.result.contract.ActivityResultContracts;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

/** Persistent user-controlled queue. Leaving the screen pauses network transfers. */
public final class DownloadQueueActivity extends PeachActivity {
    static DownloadQueue.Fetcher fetcher=PartialDownload::get;
    public static final class Draft extends AndroidViewModel {
        final ExecutorService control=Executors.newSingleThreadExecutor(),transfer=Executors.newSingleThreadExecutor();
        final MutableLiveData<Integer> updates=new MutableLiveData<>(0);DownloadQueue queue;List<SourceAttachments.Item> attachments=List.of();List<DownloadQueue.Job> rows=List.of();
        String publication="",status="Leyendo cola…";boolean loaded,busy;volatile boolean paused,starting;SourceHttp.Token localToken=new SourceHttp.Token();Intent pendingOpen;
        public Draft(Application app){super(app);}
        interface Job{void run()throws Exception;}
        void work(Job job){control.execute(()->{try{job.run();}catch(Exception e){status=e instanceof IOException?Objects.toString(e.getMessage(),"No se pudo completar."):"No se pudo completar la operación de la cola.";}finally{updates.postValue(1);}});}
        void load(String id){if(loaded)return;loaded=true;publication=SourceVideos.id(id)?id:"";work(()->{queue=DownloadQueue.get(getApplication());String warning="";try{queue.recoverExports(getApplication());}catch(IOException e){warning=e.getMessage();}if(!publication.isEmpty())attachments=SourceAttachments.load(LibraryDatabase.get(getApplication()),publication);status=warning.isEmpty()?"Elige adjuntos desde una publicación y pulsa Continuar cola. Al salir se pausa; los fragmentos comprobados se conservan.":warning;});}
        void add(List<SourceAttachments.Item> selected){work(()->status="Añadidos a la cola: "+queue.enqueue(publication,selected)+". Pulsa Continuar cola.");}
        void start(){if(queue==null||queue.running()||queue.background()||starting)return;paused=false;starting=true;updates.setValue(1);work(()->{try{if(paused){starting=false;return;}queue.continueAll();transfer.execute(()->{try{queue.run(LibraryDatabase.get(getApplication()),fetcher);}catch(IOException e){status="No se pudo mantener la cola. Los archivos privados se conservan.";}finally{starting=false;updates.postValue(1);}});}catch(Exception e){starting=false;throw e;}});}
        void pause(){paused=true;if(queue!=null&&queue.background())try{getApplication().startService(new Intent(getApplication(),QueueDownloadService.class).setAction(QueueDownloadService.PAUSE));}catch(Exception ignored){}localToken.cancel();if(queue!=null){queue.signalPause();work(()->queue.pauseAll());}}
        void action(String id,String action){work(()->{switch(action){case "pause"->queue.pause(id);case "retry"->queue.retry(id);case "remove"->queue.remove(id);case "open"->{localToken=new SourceHttp.Token();queue.verify(id,localToken);DownloadQueue.Job j; synchronized(queue){j=queue.job(id).copy();}if(!Set.of("image","video").contains(j.kind))throw new IOException("Guarda este archivo en una carpeta y ábrelo desde Biblioteca.");pendingOpen=SourceFiles.openMedia(getApplication(),QueueFilesProvider.uri(getApplication(),id),j.name,j.kind);}default->throw new IOException("Acción no disponible.");}});}
        void folder(Uri uri){work(()->{queue.folder(uri);status="Carpeta de destino guardada. Pulsa Guardar completas para copiar los archivos verificados.";});}
        void export(){if(busy||queue==null)return;busy=true;localToken=new SourceHttp.Token();work(()->{try{int count=queue.export(getApplication(),localToken);status="Archivos guardados en carpeta: "+count+". Las copias privadas se conservan hasta retirarlas.";}finally{busy=false;}});}
        @Override protected void onCleared(){paused=true;localToken.cancel();if(queue!=null&&!queue.background()){queue.signalPause();control.execute(()->{try{queue.pauseAll();}catch(IOException ignored){}});}control.shutdown();transfer.shutdownNow();}
    }
    Draft draft;TextView status;ListView list;ArrayAdapter<String> adapter;Button add,start,pause,folder,export;ProgressBar progress;boolean resumed;DownloadQueue observed;
    final ActivityResultLauncher<Intent> tree=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),result->{if(result.getResultCode()!=RESULT_OK||result.getData()==null||result.getData().getData()==null)return;Uri uri=result.getData().getData();if(!SourceFiles.local(uri))return;
        try{int offered=result.getData().getFlags(),access=0;if((offered&Intent.FLAG_GRANT_READ_URI_PERMISSION)!=0)access|=Intent.FLAG_GRANT_READ_URI_PERMISSION;if((offered&Intent.FLAG_GRANT_WRITE_URI_PERMISSION)!=0)access|=Intent.FLAG_GRANT_WRITE_URI_PERMISSION;if((offered&Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)!=0&&access!=0)getContentResolver().takePersistableUriPermission(uri,access);draft.folder(uri);}catch(Exception e){draft.status="No se pudo conservar el acceso a la carpeta. Elígela otra vez.";render();}});
    @Override protected void onCreate(Bundle state){super.onCreate(state);draft=new ViewModelProvider(this).get(Draft.class);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);int pad=(int)(12*getResources().getDisplayMetrics().density);root.setPadding(pad,pad,pad,pad);setContentView(root);
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root,(v,insets)->{var b=insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars()|androidx.core.view.WindowInsetsCompat.Type.displayCutout());v.setPadding(pad+b.left,pad+b.top,pad+b.right,pad+b.bottom);return insets;});
        LinearLayout heading=PeachDesign.row(this);TextView title=PeachDesign.text(this,"Descargas",30,"heading");heading.addView(title,new LinearLayout.LayoutParams(0,UiAppearance.dp(this,72),1));LinearLayout options=PeachDesign.column(this);options.setVisibility(View.GONE);heading.addView(PeachDesign.iconButton(this,R.drawable.ic_ui_more,"Opciones de descargas",v->options.setVisibility(options.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE)));root.addView(heading);
        TextView note=PeachDesign.text(this,"Tus archivos, listos para guardar o reproducir.",13,"muted");root.addView(note);
        status=new TextView(this);status.setId(R.id.queue_status);status.setTextIsSelectable(true);root.addView(status);progress=new ProgressBar(this);root.addView(progress);
        LinearLayout first=line(root);add=button(first,"Añadir adjuntos",R.id.queue_add,v->choose());start=button(first,"Continuar cola",R.id.queue_start,v->draft.start());pause=button(first,"Pausar cola",R.id.queue_pause,v->{draft.pause();render();});
        root.addView(options);button(line(options),"Descargar en segundo plano",View.generateViewId(),v->background());
        LinearLayout second=line(options);folder=button(second,"Elegir carpeta",R.id.queue_folder,v->tree.launch(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)));
        export=button(second,"Guardar completas",R.id.queue_export,v->draft.export());
        list=new ListView(this);list.setId(R.id.queue_list);list.setDivider(new android.graphics.drawable.ColorDrawable(0));list.setDividerHeight(UiAppearance.dp(this,8));list.setPadding(0,UiAppearance.dp(this,12),0,UiAppearance.dp(this,8));list.setClipToPadding(false);
        adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,new ArrayList<>()){@Override public View getView(int position,View convert,android.view.ViewGroup parent){TextView row=(TextView)super.getView(position,convert,parent);
            row.setTextColor(UiAppearance.text(DownloadQueueActivity.this));row.setTextSize(14);int h=UiAppearance.dp(DownloadQueueActivity.this,16),v=UiAppearance.dp(DownloadQueueActivity.this,14);row.setPadding(h,v,h,v);
            row.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(UiAppearance.accentSoft(DownloadQueueActivity.this,0x26)),UiAppearance.rounded(DownloadQueueActivity.this,UiAppearance.surface(DownloadQueueActivity.this),16),null));return row;}};adapter.setNotifyOnChange(false);list.setAdapter(adapter);android.widget.FrameLayout listBox=new android.widget.FrameLayout(this);listBox.addView(list,new android.widget.FrameLayout.LayoutParams(-1,-1));listBox.addView(empty(),new android.widget.FrameLayout.LayoutParams(-1,-1));root.addView(listBox,new LinearLayout.LayoutParams(-1,0,1));list.setOnItemClickListener((p,v,i,id)->{if(i<draft.rows.size())item(draft.rows.get(i));});
        root.addView(PeachDesign.nav(this,2));draft.updates.observe(this,n->{render();offerOpen();});draft.load(getIntent().getStringExtra("publicationId"));render();
    }
    /** Estado vacío: explica cómo empezar y lleva a Fuentes en un toque. */
    View empty(){LinearLayout box=PeachDesign.column(this);box.setGravity(android.view.Gravity.CENTER);int pad=UiAppearance.dp(this,24);box.setPadding(pad,pad,pad,pad);
        android.widget.ImageView icon=new android.widget.ImageView(this);icon.setImageDrawable(PeachDesign.icon(this,R.drawable.ic_ui_download,UiAppearance.accent(this)));icon.setScaleType(android.widget.ImageView.ScaleType.CENTER);
        android.graphics.drawable.GradientDrawable dot=new android.graphics.drawable.GradientDrawable();dot.setShape(android.graphics.drawable.GradientDrawable.OVAL);dot.setColor(UiAppearance.accentSoft(this,0x26));icon.setBackground(dot);box.addView(icon,new LinearLayout.LayoutParams(UiAppearance.dp(this,72),UiAppearance.dp(this,72)));
        TextView title=PeachDesign.text(this,"Aún no hay descargas",20,"body");title.setTypeface(UiAppearance.display(this));title.setGravity(android.view.Gravity.CENTER);title.setPadding(0,UiAppearance.dp(this,16),0,UiAppearance.dp(this,6));box.addView(title);
        TextView help=PeachDesign.text(this,"Abre una publicación en Fuentes y elige los archivos que quieras guardar. Aparecerán aquí con su progreso.",14,"muted");help.setGravity(android.view.Gravity.CENTER);help.setMaxWidth(UiAppearance.dp(this,420));box.addView(help);
        Button go=PeachDesign.action(this,"Ir a Fuentes","primary",v->PeachDesign.go(this,SourceBrowserActivity.class));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,UiAppearance.dp(this,48));p.topMargin=UiAppearance.dp(this,18);box.addView(go,p);
        list.setEmptyView(box);return box;}
    LinearLayout line(LinearLayout root){LinearLayout row=new LinearLayout(this);root.addView(row);return row;}
    Button button(LinearLayout row,String text,int id,View.OnClickListener action){Button b=new Button(this);b.setId(id);b.setText(text);b.setOnClickListener(action);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,UiAppearance.dp(this,48),1);int m=UiAppearance.dp(this,4);p.setMargins(m,m,m,m);row.addView(b,p);return b;}
    void render(){if(isDestroyed())return;boolean ready=draft.queue!=null;if(ready&&observed!=draft.queue){observed=draft.queue;observed.changes.observe(this,n->render());}
        boolean running=ready&&draft.queue.running();add.setVisibility(ready&&!draft.attachments.isEmpty()?View.VISIBLE:View.GONE);add.setEnabled(ready&&!draft.attachments.isEmpty()&&!draft.busy);start.setEnabled(ready&&!running&&!draft.queue.background()&&!draft.starting&&!draft.busy);pause.setEnabled(running||draft.starting||draft.busy||ready&&draft.queue.background());folder.setEnabled(ready&&!draft.busy);export.setEnabled(ready&&!draft.busy&&!draft.queue.folder.isEmpty());progress.setVisibility(running||draft.busy?View.VISIBLE:View.GONE);
        status.setText(draft.status+(ready?(draft.queue.folder.isEmpty()?"\nCarpeta de destino: sin elegir.":"\nCarpeta de destino seleccionada."):""));draft.rows=ready?draft.queue.snapshot():List.of();int position=list.getFirstVisiblePosition();View child=list.getChildAt(0);int top=child==null?0:child.getTop();adapter.clear();adapter.addAll(draft.rows.stream().map(DownloadQueue::label).toList());adapter.notifyDataSetChanged();if(position<draft.rows.size())list.setSelectionFromTop(position,top);
    }
    void background(){if(draft.queue==null||draft.queue.running()||draft.starting||draft.queue.background())return;new AlertDialog.Builder(this).setTitle("Descargas en segundo plano").setMessage("Continuará la cola actual al salir. Una notificación permite pausarla. Android puede detenerla por batería o tiempo; los fragmentos comprobados se conservan. No arranca sola al reiniciar.").setPositiveButton("Iniciar",(d,w)->{try{if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},430);QueueDownloadService.start(this,draft.queue);draft.status="Segundo plano solicitado. Revisa o pausa la cola aquí.";}catch(Exception e){draft.status="No se pudo iniciar segundo plano. Usa Continuar cola con la pantalla abierta o espera a que se pause el trabajo actual.";}render();}).setNegativeButton("Cancelar",null).show();}
    void choose(){if(draft.attachments.isEmpty())return;boolean[] checked=new boolean[draft.attachments.size()];AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Elegir adjuntos · hasta128 en cola").setMultiChoiceItems(draft.attachments.stream().map(SourceAttachments.Item::name).toArray(String[]::new),checked,(d,i,value)->checked[i]=value)
        .setNeutralButton("Todos",null).setPositiveButton("Añadir",(d,w)->{List<SourceAttachments.Item> selected=new ArrayList<>();for(int i=0;i<checked.length;i++)if(checked[i])selected.add(draft.attachments.get(i));draft.add(selected);}).setNegativeButton("Cancelar",null).create();
        dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->{Arrays.fill(checked,true);for(int i=0;i<checked.length;i++)dialog.getListView().setItemChecked(i,true);}));dialog.show();
    }
    void item(DownloadQueue.Job j){List<String> labels=new ArrayList<>(),actions=new ArrayList<>();if(j.state.equals("ready")&&Set.of("image","video").contains(j.kind)){labels.add("Abrir archivo descargado");actions.add("open");}
        if(Set.of("running","queued","verifying").contains(j.state)){labels.add("Pausar esta descarga");actions.add("pause");}else if(Set.of("paused","error").contains(j.state)){labels.add("Preparar reintento · pulsa Continuar cola");actions.add("retry");}
        labels.add("Retirar de cola y eliminar su copia privada");actions.add("remove");new AlertDialog.Builder(this).setTitle(j.name).setItems(labels.toArray(String[]::new),(d,i)->draft.action(j.id,actions.get(i))).setNeutralButton("Detalles",(a,b)->new AlertDialog.Builder(this).setTitle(j.name).setMessage(j.message+(!j.exported.isEmpty()?"\nEl archivo guardado en tu carpeta se conserva.":"")).setPositiveButton("Cerrar",null).show()).setNegativeButton("Cerrar",null).show();
    }
    void offerOpen(){if(!resumed||isDestroyed()||isFinishing()||draft.pendingOpen==null)return;Intent intent=draft.pendingOpen;draft.pendingOpen=null;try{startActivity(intent);}catch(Exception e){draft.status="No se pudo abrir esa copia. Puedes guardarla en una carpeta.";render();}}
    @Override protected void onResume(){super.onResume();resumed=true;offerOpen();}
    @Override protected void onPause(){resumed=false;super.onPause();}
    @Override protected void onStop(){if(!isChangingConfigurations()&&(draft.queue==null||!draft.queue.background()))draft.pause();super.onStop();}
}
