package com.peach.local;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import java.util.ArrayList;
import java.util.List;

/**
 * Estilo "cristal": superficies translúcidas que dejan ver, difuminado, el contenido que pasa por detrás.
 * Android no difumina vistas de fondo por sí solo, así que se dibuja a 1/8 de resolución solo la franja
 * que queda detrás de cada panel, se difumina y se usa como fondo. Si el dibujo falla (por ejemplo,
 * imágenes de hardware) o el usuario elige "Clásico", queda una superficie sólida legible.
 */
final class Glass {
    private Glass() {}
    private static final int SCALE=8,FRAME_MS=33,MAX_W=400,MAX_H=160;

    static boolean enabled(Context c){return UiAppearance.prefs(c).getInt("style",1)==1;}

    /** Color translúcido del panel; casi opaco en modo Clásico. */
    static int tint(Context c){boolean glass=enabled(c);int base=UiAppearance.surface(c)&0x00ffffff;return base|((glass?(UiAppearance.dark(c)?0xa6:0xb8):0xff)<<24);}

    /** Borde fino y brillo superior que dan la sensación de vidrio. */
    static Drawable sheen(Context c,int radiusDp){
        float r=UiAppearance.dp(c,radiusDp);boolean dark=UiAppearance.dark(c);
        GradientDrawable fill=new GradientDrawable();fill.setCornerRadius(r);fill.setColor(tint(c));
        GradientDrawable light=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{dark?0x1fffffff:0x66ffffff,0x00ffffff,0x00ffffff});light.setCornerRadius(r);
        GradientDrawable edge=new GradientDrawable();edge.setCornerRadius(r);edge.setColor(0);edge.setStroke(Math.max(1,UiAppearance.dp(c,1)),dark?0x2effffff:0x1a000000);
        return new LayerDrawable(new Drawable[]{fill,light,edge});
    }

    /**
     * Envuelve {@code content} en un panel de cristal con esquinas de {@code radiusDp}.
     * El panel captura lo que hay detrás dentro de {@code source} (la vista raíz de la pantalla).
     */
    static FrameLayout wrap(Activity activity,View content,int radiusDp){
        Context c=activity;FrameLayout panel=new FrameLayout(c);
        GradientDrawable shape=new GradientDrawable();shape.setCornerRadius(UiAppearance.dp(c,radiusDp));shape.setColor(0xff000000);
        panel.setBackground(null);panel.setOutlineProvider(new android.view.ViewOutlineProvider(){@Override public void getOutline(View v,android.graphics.Outline o){o.setRoundRect(0,0,v.getWidth(),v.getHeight(),UiAppearance.dp(c,radiusDp));}});
        panel.setClipToOutline(true);panel.setElevation(UiAppearance.dp(c,10));
        // El cristal es el FONDO del panel (difuminado + brillo + borde): nunca cambia su tamaño.
        Drawable face=sheen(c,radiusDp);panel.setBackground(face);panel.setTag(R.id.glass_sheen,face);
        if(content.getParent() instanceof ViewGroup old)old.removeView(content);
        panel.addView(content,new FrameLayout.LayoutParams(-1,-2));
        if(enabled(c))Engine.of(activity).add(panel);
        return panel;
    }

    /**
     * Un motor por pantalla. Captura solo ante cambios reales: desplazamiento (fluido, ~30 por segundo)
     * o reacomodo de la pantalla, más una captura de cierre 0,3 s después para recoger imágenes recién
     * cargadas. Una captura nunca provoca otra, así que con la pantalla quieta el motor no trabaja.
     */
    static final class Engine {
        private final Activity activity;private final List<View[]> panels=new ArrayList<>();
        private long last;private boolean pending,settling,broken;
        private final Runnable run=()->{pending=false;capture();settle();};
        private final Runnable settled=()->{settling=false;capture();};
        private Engine(Activity a){activity=a;}
        static Engine of(Activity a){View decor=a.getWindow().getDecorView();Object tag=decor.getTag(R.id.glass_engine);
            if(tag instanceof Engine e)return e;Engine e=new Engine(a);decor.setTag(R.id.glass_engine,e);
            ViewTreeObserver observer=decor.getViewTreeObserver();observer.addOnScrollChangedListener(e::request);observer.addOnGlobalLayoutListener(e::request);return e;}
        void add(View panel){panels.add(new View[]{panel});}
        void request(){
            if(broken||panels.isEmpty()||pending)return;pending=true;
            long wait=Math.max(0,FRAME_MS-(SystemClock.uptimeMillis()-last));activity.getWindow().getDecorView().postDelayed(run,wait);
        }
        private void settle(){if(settling)return;settling=true;activity.getWindow().getDecorView().postDelayed(settled,300);}
        /** La raíz de la pantalla es el primer hijo de android.R.id.content; los paneles viven fuera de ella. */
        private View source(){ViewGroup content=activity.findViewById(android.R.id.content);return content==null?null:PeachDesign.screenRoot(content);}
        void capture(){
            last=SystemClock.uptimeMillis();View source=source();if(source==null||activity.isDestroyed())return;
            int[] origin=new int[2],at=new int[2];source.getLocationInWindow(origin);
            Drawable backdrop=activity.getWindow().getDecorView().getBackground();
            for(View[] pair:panels){
                View panel=pair[0];if(panel.getWidth()==0||panel.getHeight()==0||!panel.isShown())continue;
                int w=Math.max(1,Math.min(MAX_W,panel.getWidth()/SCALE)),h=Math.max(1,Math.min(MAX_H,panel.getHeight()/SCALE));float sx=w/(float)panel.getWidth(),sy=h/(float)panel.getHeight();
                // Imagen de trabajo propia: nunca se modifica la que está en pantalla.
                Bitmap bitmap=panel.getTag(R.id.glass_scratch) instanceof Bitmap b&&b.getWidth()==w&&b.getHeight()==h?b:Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);panel.setTag(R.id.glass_scratch,bitmap);
                bitmap.eraseColor(UiAppearance.background(activity));
                Canvas canvas=new Canvas(bitmap);panel.getLocationInWindow(at);canvas.scale(sx,sy);canvas.translate(-at[0],-at[1]);
                try{
                    // Se dibuja el fondo de la ventana tal cual: cambiar sus límites lo invalidaría y provocaría otro fotograma.
                    if(backdrop!=null&&!backdrop.getBounds().isEmpty())backdrop.draw(canvas);
                    canvas.translate(origin[0],origin[1]);source.draw(canvas);
                }catch(RuntimeException error){broken=true;for(View[] p:panels)p[0].setBackground((Drawable)p[0].getTag(R.id.glass_sheen));return;} // Imágenes de hardware: queda el panel sólido.
                int[] pixels=blurred(bitmap,2);
                // Solo se redibuja si el fondo cambió de verdad: así una captura nunca provoca la siguiente.
                if(panel.getTag(R.id.glass_engine) instanceof int[] previous&&java.util.Arrays.equals(previous,pixels))continue;
                panel.setTag(R.id.glass_engine,pixels);Bitmap shown=Bitmap.createBitmap(pixels,w,h,Bitmap.Config.ARGB_8888);
                android.graphics.drawable.BitmapDrawable frosted=new android.graphics.drawable.BitmapDrawable(activity.getResources(),shown);frosted.setFilterBitmap(true);
                panel.setBackground(new LayerDrawable(new Drawable[]{frosted,(Drawable)panel.getTag(R.id.glass_sheen)}));
            }
        }
    }

    /** Desenfoque de caja en dos pasadas sobre una imagen diminuta; cuesta microsegundos. */
    static void blurInPlace(Bitmap bitmap,int radius){int w=bitmap.getWidth(),h=bitmap.getHeight();bitmap.setPixels(blurred(bitmap,radius),0,w,0,0,w,h);}
    /** Píxeles difuminados de la imagen (sin modificarla). */
    static int[] blurred(Bitmap bitmap,int radius){
        int w=bitmap.getWidth(),h=bitmap.getHeight();int[] in=new int[w*h],out=new int[w*h];bitmap.getPixels(in,0,w,0,0,w,h);
        for(int pass=0;pass<2;pass++){box(in,out,w,h,radius,true);box(out,in,w,h,radius,false);}
        return in;
    }
    private static void box(int[] src,int[] dst,int w,int h,int r,boolean horizontal){
        int lines=horizontal?h:w,length=horizontal?w:h;
        for(int line=0;line<lines;line++){
            long a=0,red=0,g=0,b=0;int count=0;
            for(int i=-r;i<=r;i++){int k=Math.max(0,Math.min(length-1,i));int p=src[horizontal?line*w+k:k*w+line];a+=p>>>24;red+=(p>>16)&255;g+=(p>>8)&255;b+=p&255;count++;}
            for(int i=0;i<length;i++){
                int index=horizontal?line*w+i:i*w+line;dst[index]=(int)(a/count)<<24|(int)(red/count)<<16|(int)(g/count)<<8|(int)(b/count);
                int out=Math.max(0,i-r),in=Math.min(length-1,i+r+1);int po=src[horizontal?line*w+out:out*w+line],pi=src[horizontal?line*w+in:in*w+line];
                a+=(pi>>>24)-(po>>>24);red+=((pi>>16)&255)-((po>>16)&255);g+=((pi>>8)&255)-((po>>8)&255);b+=(pi&255)-(po&255);
            }
        }
    }
}
