package com.peach.local;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Button;
import android.widget.LinearLayout;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.work.WorkManager;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class MainActivity extends PeachActivity {
    private LibraryDatabase db;
    private MediaAdapter adapter;
    private EditText search;
    private Spinner filter;
    private Spinner order;
    private Spinner typeFilter;
    private List<Playlist> playlists=List.of();
    private List<PlaylistItem> membership=List.of();
    private List<MediaGroup> groups=List.of();
    private List<MediaGroupItem> groupMembership=List.of();
    private List<CatalogEntity> entities=List.of();
    private List<EntityAlias> aliases=List.of();
    private List<MediaEntityLink> entityLinks=List.of();
    private List<EntityMembership> affiliations=List.of();
    private String selectedEntity="";
    private java.util.Set<String> reading=java.util.Set.of();
    private String selectedFacet="",selectedTerm="",selectedGroup="";
    private String selectedRoot="",selectedFolder="",selectedPlaylist="";
    private List<MediaEntry> media=List.of();
    private List<LibraryRoot> roots=List.of();
    private boolean scanning;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable applySearch=this::showMedia;
    private final ActivityResultLauncher<Intent> folderPicker=registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(),result -> {
            if (result.getResultCode()!=RESULT_OK || result.getData()==null || result.getData().getData()==null) return;
            Intent data=result.getData(); Uri tree=data.getData();
            try {
                if (!"content".equals(tree.getScheme()) || !DocumentsContract.isTreeUri(tree))
                    throw new SecurityException();
                int flags=data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION;
                if (flags==0) throw new SecurityException();
                getContentResolver().takePersistableUriPermission(tree,flags);
                LibraryDatabase.IO.execute(() -> {
                    LibraryRoot root=new LibraryRoot(); root.uri=tree.toString(); root.label="Carpeta de medios";
                    Uri document=DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));
                    try (var cursor=getContentResolver().query(document,
                        new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME},null,null,null)) {
                        if (cursor!=null && cursor.moveToFirst() && cursor.getString(0)!=null) root.label=cursor.getString(0);
                    } catch (Exception ignored) { /* A safe generic label remains available. */ }
                    db.runInTransaction(() -> {
                        if (db.library().addRoot(root)!=-1)
                            db.library().enqueue(new ScanDirectory(root.uri,document.toString(),root.label));
                        else db.library().rootState(root.uri,1);
                    });
                    ScanWorker.enqueue(this);
                });
            } catch (Exception error) { message("No se pudo conservar el permiso. Elige una carpeta local otra vez."); }
        });
    private final ActivityResultLauncher<Intent> exportPicker=registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(),result -> {
            if (result.getResultCode()!=RESULT_OK || result.getData()==null) return;
            Uri uri=result.getData().getData(); if (uri==null || !"content".equals(uri.getScheme())) return;
            LibraryDatabase.IO.execute(() -> {
                try (OutputStream out=getContentResolver().openOutputStream(uri,"wt")) {
                    if (out==null) throw new java.io.IOException(); BackupStore.write(db.library(),out);
                    message("Copia de progreso, organización y deseos guardada.");
                } catch (Exception e) { message("No se pudo guardar la copia."); }
            });
        });
    private final ActivityResultLauncher<Intent> importPicker=registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(),result -> {
            if (result.getResultCode()!=RESULT_OK || result.getData()==null) return;
            Uri uri=result.getData().getData(); if (uri==null || !"content".equals(uri.getScheme())) return;
            LibraryDatabase.IO.execute(() -> {
                try (InputStream in=getContentResolver().openInputStream(uri)) {
                    if (in==null) throw new java.io.IOException(); int count=BackupStore.read(db,in);
                    message("Restaurados "+count+" registros de tu biblioteca actual.");
                } catch (Exception e) { message("No se pudo restaurar esa copia."); }
            });
        });
    @Override public void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_main);
        WindowCompat.setDecorFitsSystemWindows(getWindow(),false);
        View root=findViewById(R.id.root); int padding=(int)(16*getResources().getDisplayMetrics().density);
        ViewCompat.setOnApplyWindowInsetsListener(root,(v,insets) -> {
            Insets bars=insets.getInsets(WindowInsetsCompat.Type.systemBars()|WindowInsetsCompat.Type.displayCutout());
            v.setPadding(padding+bars.left,padding+bars.top,padding+bars.right,padding+bars.bottom); return insets;
        });
        db=LibraryDatabase.get(this);
        search=findViewById(R.id.search); filter=findViewById(R.id.filter);
        typeFilter=findViewById(R.id.typeFilter);
        typeFilter.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,
            new String[]{"Todos los archivos","Videos","Imágenes","Audio","Comprimidos","Otros archivos"}));
        typeFilter.setSelection(Math.max(0,Math.min(5,getPreferences(MODE_PRIVATE).getInt("type",1))));
        selectedRoot=getPreferences(MODE_PRIVATE).getString("root","");
        selectedFolder=getPreferences(MODE_PRIVATE).getString("folder","");
        selectedPlaylist=getPreferences(MODE_PRIVATE).getString("playlist","");
        selectedFacet=getPreferences(MODE_PRIVATE).getString("facet","");
        selectedTerm=getPreferences(MODE_PRIVATE).getString("term","");
        selectedGroup=getPreferences(MODE_PRIVATE).getString("group","");
        selectedEntity=getPreferences(MODE_PRIVATE).getString("entity","");
        order=findViewById(R.id.order);
        order.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,
            new String[]{"Título A–Z","Título Z–A","Incorporación reciente","Última reproducción","Orden de la lista"}));
        order.setSelection(getPreferences(MODE_PRIVATE).getInt("order",0));
        filter.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,
            new String[]{"Todos","Favoritos","Sin ver / escuchar","Con progreso","Vistos / escuchados"}));
        filter.setSelection(getPreferences(MODE_PRIVATE).getInt("filter",0));
        search.setText(getPreferences(MODE_PRIVATE).getString("query",""));
        adapter=new MediaAdapter(this::play,this::detail);
        RecyclerView grid=findViewById(R.id.grid);
        int width=getResources().getConfiguration().screenWidthDp;
        int density=UiAppearance.prefs(this).getInt("density",1);
        grid.setLayoutManager(density==3?new androidx.recyclerview.widget.LinearLayoutManager(this):new GridLayoutManager(this,Math.max(1,(width-32)/(density==0?145:density==2?260:180))));
        grid.setItemViewCacheSize(6);
        if(!UiAppearance.motion(this))grid.setItemAnimator(null);
        View panel=findViewById(R.id.filterPanel);panel.setVisibility(state!=null&&state.getBoolean("filtersOpen")?View.VISIBLE:View.GONE);
        findViewById(R.id.toggleFilters).setOnClickListener(v->{if(UiAppearance.motion(this)){android.transition.AutoTransition transition=new android.transition.AutoTransition();transition.setDuration(150);android.transition.TransitionManager.beginDelayedTransition((android.view.ViewGroup)findViewById(R.id.root),transition);}panel.setVisibility(panel.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE);v.setContentDescription(panel.getVisibility()==View.VISIBLE?"Ocultar filtros":"Mostrar filtros");});
        findViewById(R.id.navSources).setOnClickListener(v->{PeachDesign.pop(v);PeachDesign.go(this,SourceBrowserActivity.class);});
        findViewById(R.id.navDownloads).setOnClickListener(v->{PeachDesign.pop(v);PeachDesign.go(this,DownloadQueueActivity.class);});
        findViewById(R.id.navSettings).setOnClickListener(v->{PeachDesign.pop(v);PeachDesign.go(this,SettingsActivity.class);});
        grid.setAdapter(adapter);
        continueAdapter=new ContinueAdapter(this::play);
        RecyclerView row=findViewById(R.id.continue_row);row.setLayoutManager(new androidx.recyclerview.widget.LinearLayoutManager(this,RecyclerView.HORIZONTAL,false));row.setAdapter(continueAdapter);row.setItemAnimator(null);
        grid.addOnScrollListener(new RecyclerView.OnScrollListener(){@Override public void onScrolled(@androidx.annotation.NonNull RecyclerView view,int dx,int dy){boolean top=!view.canScrollVertically(-1);if(top!=gridAtTop&&(dy!=0||top)){gridAtTop=top;showContinue();}}});
        ((TextView)((android.view.ViewGroup)findViewById(R.id.continue_section)).getChildAt(0)).setTypeface(UiAppearance.title(this));
        buildChips();
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after) {}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count) {
                handler.removeCallbacks(applySearch); handler.postDelayed(applySearch,150);
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        filter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent,View view,int position,long id) { showMedia(); }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        order.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent,View view,int position,long id) { showMedia(); }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        findViewById(R.id.scope).setOnClickListener(v->chooseScope());
        findViewById(R.id.explore).setOnClickListener(v->explore());
        typeFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent,View view,int position,long id) {showMedia();}
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        findViewById(R.id.addFolder).setOnClickListener(v -> folderPicker.launch(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)));
        findViewById(R.id.more).setOnClickListener(this::menu);
        db.library().observeMedia().observe(this,items -> { media=items; requestMedia(); });
        db.library().observeRoots().observe(this,items -> { roots=items; showScan(); });
        db.library().observePlaylists().observe(this,items->{
            playlists=items;
            if (!selectedPlaylist.isEmpty() && items.stream().noneMatch(p->p.id.equals(selectedPlaylist))) selectedPlaylist="";
            requestMedia();
        });
        db.library().observePlaylistItems().observe(this,items->{ membership=items;requestMedia(); });
        db.library().observeGroups().observe(this,items->{
            groups=items;
            if(!selectedGroup.isEmpty() && items.stream().noneMatch(g->g.id.equals(selectedGroup)))selectedGroup="";
            requestMedia();
        });
        db.library().observeGroupItems().observe(this,items->{groupMembership=items;requestMedia();});
        db.library().observeEntities().observe(this,items->{entities=items;
            if(!selectedEntity.isEmpty() && items.stream().noneMatch(e->e.id.equals(selectedEntity)))selectedEntity="";requestMedia();});
        db.library().observeAliases().observe(this,items->{aliases=items;requestMedia();});
        db.library().observeEntityLinks().observe(this,items->{entityLinks=items;requestMedia();});
        db.library().observeMemberships().observe(this,items->{affiliations=items;requestMedia();});
        db.library().observeReaderProgress().observe(this,items->{java.util.Set<String> ids=new java.util.HashSet<>();for(ReaderProgress p:items)ids.add(p.mediaId);reading=ids;requestMedia();});
        acceptEntity(getIntent());acceptTool(getIntent());
        WorkManager.getInstance(this).getWorkInfosForUniqueWorkLiveData(ScanWorker.UNIQUE).observe(this,infos -> {
            scanning=infos.stream().anyMatch(info -> !info.getState().isFinished()); showScan();
        });
    }
    private ContinueAdapter continueAdapter;private boolean gridAtTop=true;private List<MediaEntry> continueItems=List.of();
    /** Accesos rápidos visibles; los filtros avanzados siguen en el panel de Filtros. */
    private static final String[] CHIPS={"Todo","Favoritos","Continuar","Videos","Audio","Imágenes","Listas","Deseos","Historial"};
    private void buildChips(){
        LinearLayout row=findViewById(R.id.library_chips);row.removeAllViews();
        for(int i=0;i<CHIPS.length;i++){final int n=i;Button chip=PeachDesign.chip(this,CHIPS[i],false,v->{PeachDesign.pop(v);chip(n);});
            LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-2,PeachDesign.dp(this,40));params.setMarginEnd(PeachDesign.dp(this,8));row.addView(chip,params);}
        syncChips();
    }
    private void chip(int n){
        switch(n){
            case 0 -> {clearScope();search.setText("");filter.setSelection(0);typeFilter.setSelection(0);}
            case 1 -> {clearScope();filter.setSelection(1);typeFilter.setSelection(0);}
            case 2 -> {clearScope();filter.setSelection(3);typeFilter.setSelection(0);}
            case 3,4,5 -> {clearScope();filter.setSelection(0);typeFilter.setSelection(n==3?1:n==4?3:2);}
            case 6 -> {choosePlaylist(null);return;}
            case 7 -> {organization(1,"");return;}
            default -> {startActivity(new Intent(this,HistoryActivity.class));return;}
        }
        showMedia();
    }
    /** Resalta el acceso que corresponde a los filtros actuales (también si se cambian desde el panel). */
    private void syncChips(){
        LinearLayout row=findViewById(R.id.library_chips);if(row==null||filter==null||typeFilter==null)return;
        boolean scoped=!selectedRoot.isEmpty()||!selectedPlaylist.isEmpty()||!selectedFacet.isEmpty()||!selectedGroup.isEmpty()||!selectedEntity.isEmpty();
        int f=filter.getSelectedItemPosition(),t=typeFilter.getSelectedItemPosition(),active=-1;
        if(!scoped){if(f==0&&t==0)active=0;else if(f==1&&t==0)active=1;else if(f==3&&t==0)active=2;else if(f==0&&t==1)active=3;else if(f==0&&t==3)active=4;else if(f==0&&t==2)active=5;}
        if(!selectedPlaylist.isEmpty())active=6;
        for(int i=0;i<row.getChildCount();i++){Button b=(Button)row.getChildAt(i);if(b.isSelected()!=(i==active))PeachDesign.chipState(b,i==active);}
    }
    private void showContinue(){
        View section=findViewById(R.id.continue_section);if(section==null)return;
        boolean plain=search.getText().length()==0&&filter.getSelectedItemPosition()==0&&selectedRoot.isEmpty()&&selectedPlaylist.isEmpty()&&selectedFacet.isEmpty()&&selectedGroup.isEmpty()&&selectedEntity.isEmpty();
        boolean show=plain&&gridAtTop&&!continueItems.isEmpty()&&UiAppearance.prefs(this).getBoolean("continueRow",true);
        if((section.getVisibility()==View.VISIBLE)==show)return;
        if(UiAppearance.motion(this)){android.transition.ChangeBounds bounds=new android.transition.ChangeBounds();bounds.setDuration(220);android.transition.TransitionSet set=new android.transition.TransitionSet().addTransition(bounds).addTransition(new android.transition.Fade().setDuration(180));android.transition.TransitionManager.beginDelayedTransition((android.view.ViewGroup)findViewById(R.id.root),set);}
        section.setVisibility(show?View.VISIBLE:View.GONE);
    }
    private boolean renderPending;
    private final Runnable renderOnce=()->{renderPending=false;showMedia();};
    private void requestMedia(){if(!renderPending){renderPending=true;handler.post(renderOnce);}}
    private void showMedia() {
        if (adapter==null || search==null) return;
        int selected=filter.getSelectedItemPosition(); String query=search.getText().toString();
        List<MediaEntry> visible=LibraryView.select(EntityIndex.select(CatalogIndex.select(media,selectedFacet,selectedTerm,selectedGroup,groupMembership),selectedEntity,entities,aliases,entityLinks,affiliations),query,selected,selectedRoot,selectedFolder,
            selectedPlaylist,membership,order.getSelectedItemPosition(),selectedType(),reading);
        adapter.submitList(visible);
        continueItems=ContinueAdapter.pick(media);continueAdapter.submit(continueItems);syncChips();showContinue();
        findViewById(R.id.empty).setVisibility(visible.isEmpty()?View.VISIBLE:View.GONE);
        ((TextView)findViewById(R.id.emptyHelp)).setText(media.isEmpty()?getString(R.string.empty_help):"No hay resultados para esta búsqueda o filtro. Toca «Todo» para ver toda tu biblioteca.");
        TextView emptyTitle=findViewById(R.id.emptyTitle);emptyTitle.setText(media.isEmpty()?"Tu biblioteca empieza aquí":"Nada por aquí");emptyTitle.setTypeface(UiAppearance.display(this));
        ((TextView)findViewById(R.id.summary)).setText(media.isEmpty()?"Añade una carpeta para empezar":visible.size()==media.size()?media.size()+" archivos en tu biblioteca":visible.size()+" de "+media.size()+" archivos");
        String label=selectedFolder.isEmpty()?getString(R.string.all_library):selectedFolder;
        if (!selectedPlaylist.isEmpty()) for (Playlist list:playlists) if (list.id.equals(selectedPlaylist)) label=getString(R.string.list_scope,list.name);
        if(!selectedFacet.isEmpty())label=CatalogIndex.label(selectedFacet)+" · "+selectedTerm;
        if(!selectedGroup.isEmpty())for(MediaGroup group:groups)if(group.id.equals(selectedGroup))label="Grupo · "+group.name;
        if(!selectedEntity.isEmpty())for(CatalogEntity entity:entities)if(entity.id.equals(selectedEntity))label="Identidad · "+entity.name;
        ((Button)findViewById(R.id.scope)).setText(label);
    }
    private void showScan() {
        int directories=roots.stream().mapToInt(r->r.directories).sum();
        int warnings=roots.stream().mapToInt(r->r.warnings).sum();
        boolean failed=roots.stream().anyMatch(r->r.state==2);
        boolean pending=roots.stream().anyMatch(r->r.state!=0);
        String status=roots.isEmpty()?"Listo para añadir tu primera carpeta.":failed?
            "Una carpeta no está accesible. Revisa la microSD o vuelve a añadir la carpeta.":
            scanning?"Indexando · "+directories+" carpetas revisadas. Puedes pausar desde ⋮.":
            pending?"Escaneo pendiente · toca ⋮ y Continuar escaneo.":
            "Biblioteca guardada · "+roots.size()+" ubicaciones · "+directories+" carpetas revisadas";
        if (warnings>0) status+=" · "+warnings+" NFO omitidos";
        TextView line=findViewById(R.id.scanStatus);line.setText(status);
        // En estado normal no se muestra: solo aparece cuando hay escaneo, avisos o algo que revisar.
        line.setVisibility(!roots.isEmpty()&&!failed&&!scanning&&!pending&&warnings==0?View.GONE:View.VISIBLE);
    }
    private void play(MediaEntry m) {
        if(DocumentRules.readable(m.name)){startActivity(new Intent(this,ReaderActivity.class).putExtra("mediaId",m.id));return;}
        if(!MediaRules.IMAGE.equals(m.mediaType) && !MediaRules.playable(m)){detail(m);return;}
        Intent intent=new Intent(this,MediaRules.IMAGE.equals(m.mediaType)?ImageViewerActivity.class:MediaRules.AUDIO.equals(m.mediaType)?AudioActivity.class:PlayerActivity.class)
            .putExtra("mediaId",m.id).putExtra("playlistId",selectedPlaylist).putExtra("root",selectedRoot)
            .putExtra("folder",selectedFolder).putExtra("query",search.getText().toString())
            .putExtra("filter",filter.getSelectedItemPosition()).putExtra("order",order.getSelectedItemPosition());
        intent.putExtra("facet",selectedFacet).putExtra("term",selectedTerm).putExtra("group",selectedGroup);
        intent.putExtra("entityId",selectedEntity);
        startActivity(intent);
    }
    private String selectedType() {
        return switch(typeFilter.getSelectedItemPosition()) {case 1->MediaRules.VIDEO;case 2->MediaRules.IMAGE;case 3->MediaRules.AUDIO;case 4->MediaRules.ARCHIVE;case 5->MediaRules.OTHER;default->"";};
    }
    /** Panel inferior: portada, acciones rápidas (favorito, lista, visto) y datos. El resto en "Más opciones". */
    private void detail(MediaEntry m) {
        LinearLayout sheet=PeachDesign.column(this);int pad=PeachDesign.dp(this,20);
        View handle=new View(this);handle.setBackground(UiAppearance.rounded(this,UiAppearance.surfaceHigh(this),3));
        LinearLayout.LayoutParams grip=new LinearLayout.LayoutParams(PeachDesign.dp(this,40),PeachDesign.dp(this,5));grip.gravity=android.view.Gravity.CENTER_HORIZONTAL;grip.setMargins(0,PeachDesign.dp(this,10),0,PeachDesign.dp(this,6));sheet.addView(handle,grip);
        LinearLayout head=PeachDesign.row(this);head.setPadding(pad,PeachDesign.dp(this,8),pad,0);
        android.widget.ImageView cover=new android.widget.ImageView(this);cover.setBackground(UiAppearance.rounded(this,UiAppearance.surfaceHigh(this),16));cover.setClipToOutline(true);
        head.addView(cover,new LinearLayout.LayoutParams(PeachDesign.dp(this,96),PeachDesign.dp(this,96)));Thumbnails.load(this,m,cover);
        LinearLayout names=PeachDesign.column(this);names.setPadding(PeachDesign.dp(this,16),0,0,0);
        TextView name=PeachDesign.text(this,m.displayTitle(),20,"body");name.setTypeface(UiAppearance.display(this));name.setMaxLines(3);name.setEllipsize(android.text.TextUtils.TruncateAt.END);names.addView(name);
        TextView kind=PeachDesign.text(this,MediaAdapter.summary(m),13,"muted");kind.setPadding(0,PeachDesign.dp(this,4),0,0);names.addView(kind);
        head.addView(names,new LinearLayout.LayoutParams(0,-2,1));sheet.addView(head);
        LinearLayout quick=PeachDesign.row(this);quick.setPadding(pad,PeachDesign.dp(this,16),pad,PeachDesign.dp(this,4));
        Button heart=quickAction(m.favorite?R.drawable.ic_ui_heart_filled:R.drawable.ic_ui_heart,m.favorite?"Favorito":"Me gusta",m.favorite);heart.setId(R.id.sheet_favorite);
        final boolean[] liked={m.favorite};
        heart.setOnClickListener(v->{liked[0]=!liked[0];quickState(heart,liked[0]?R.drawable.ic_ui_heart_filled:R.drawable.ic_ui_heart,liked[0]?"Favorito":"Me gusta",liked[0]);PeachDesign.pop(v);doIo(()->db.library().toggleFavorite(m.id));});
        Button list=quickAction(R.drawable.ic_ui_list_add,"A una lista",false);list.setId(R.id.sheet_playlist);list.setOnClickListener(v->choosePlaylist(m));
        final boolean[] seen={m.watched};String seenLabel=DocumentRules.readable(m.name)?"Leído":MediaRules.AUDIO.equals(m.mediaType)?"Escuchado":"Visto";
        Button watched=quickAction(R.drawable.ic_ui_check,seenLabel,m.watched);watched.setId(R.id.sheet_watched);
        watched.setOnClickListener(v->{seen[0]=!seen[0];quickState(watched,R.drawable.ic_ui_check,seenLabel,seen[0]);PeachDesign.pop(v);doIo(()->db.library().toggleWatched(m.id));});
        for(Button b:new Button[]{heart,list,watched}){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,PeachDesign.dp(this,48),1);p.setMarginEnd(PeachDesign.dp(this,8));quick.addView(b,p);}
        sheet.addView(quick);
        sheet.addView(MediaDetailsView.create(this,m),new LinearLayout.LayoutParams(-1,-2));
        var builder=new AlertDialog.Builder(this).setView(sheet)
            .setNeutralButton("Más opciones",(d,w)->mediaActions(m))
            .setNegativeButton("Cerrar",null);
        if(DocumentRules.readable(m.name) || MediaRules.IMAGE.equals(m.mediaType) || MediaRules.playable(m))
            builder.setPositiveButton(DocumentRules.readable(m.name)?"Abrir lectura":MediaRules.IMAGE.equals(m.mediaType)?"Ver imagen":"Reproducir",(d,w)->play(m));
        AlertDialog dialog=builder.create();
        if(dialog.getWindow()!=null){var window=dialog.getWindow();window.setGravity(android.view.Gravity.BOTTOM);
            android.graphics.drawable.GradientDrawable panel=new android.graphics.drawable.GradientDrawable();panel.setColor(UiAppearance.surface(this));float r=PeachDesign.dp(this,28);panel.setCornerRadii(new float[]{r,r,r,r,0,0,0,0});window.setBackgroundDrawable(panel);
            if(UiAppearance.motion(this))window.setWindowAnimations(R.style.PeachSheetAnimation);}
        dialog.setOnShowListener(d->{if(dialog.getWindow()!=null){int width=Math.min(getResources().getDisplayMetrics().widthPixels,PeachDesign.dp(this,640));dialog.getWindow().setLayout(width,android.view.ViewGroup.LayoutParams.WRAP_CONTENT);}
            for(int which:new int[]{AlertDialog.BUTTON_POSITIVE,AlertDialog.BUTTON_NEUTRAL,AlertDialog.BUTTON_NEGATIVE}){Button b=dialog.getButton(which);if(b!=null){b.setAllCaps(false);b.setTextColor(which==AlertDialog.BUTTON_POSITIVE?UiAppearance.accent(this):UiAppearance.text(this));if(which==AlertDialog.BUTTON_POSITIVE)b.setTypeface(UiAppearance.title(this));}}});
        dialog.show();
    }
    private Button quickAction(int icon,String label,boolean on){Button b=new Button(this);quickState(b,icon,label,on);return b;}
    private void quickState(Button b,int icon,String label,boolean on){
        b.setText(label);b.setAllCaps(false);b.setTextSize(13);b.setStateListAnimator(null);b.setBackgroundTintList(null);b.setMinWidth(0);b.setMinimumWidth(0);b.setPadding(PeachDesign.dp(this,8),0,PeachDesign.dp(this,8),0);
        b.setTextColor(on?UiAppearance.accent(this):UiAppearance.text(this));b.setCompoundDrawablePadding(PeachDesign.dp(this,6));
        android.graphics.drawable.Drawable d=PeachDesign.icon(this,icon,on?UiAppearance.accent(this):UiAppearance.text(this));d.setBounds(0,0,PeachDesign.dp(this,18),PeachDesign.dp(this,18));b.setCompoundDrawables(d,null,null,null);
        b.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(UiAppearance.accentSoft(this,0x33)),UiAppearance.rounded(this,on?UiAppearance.accentSoft(this,0x29):UiAppearance.surfaceHigh(this),24),null));
        b.setContentDescription(label+(on?", activado":""));
    }
    private void menu(View anchor) {
        PopupMenu menu=new PopupMenu(this,anchor);
        menu.getMenu().add(0,1,0,R.string.update).setEnabled(!scanning);
        menu.getMenu().add(0,2,1,scanning?R.string.pause_scan:R.string.resume_scan);
        menu.getMenu().add(0,3,2,"Carpetas");
        menu.getMenu().add(0,25,3,"Ajustes");
        menu.setOnMenuItemClickListener(item->handleTool(item.getItemId()));menu.show();
    }
    boolean handleTool(int tool){if(tool==9&&selectedPlaylist.isEmpty()){message("Selecciona una lista desde Filtros → Ubicación para administrarla.");return true;}if(tool==11&&selectedGroup.isEmpty()){message("Selecciona un grupo desde Filtros → Explorar para administrarlo.");return true;}
            switch (tool) {
                case 25 -> startActivity(new Intent(this,SettingsActivity.class));
                case 24 -> startActivity(new Intent(this,DeviceCheckActivity.class));
                case 22 -> startActivity(new Intent(this,AppearanceActivity.class));
                case 23 -> startActivity(new Intent(this,StorageActivity.class));
                case 21 -> startActivity(new Intent(this,ExchangeActivity.class));
                case 20 -> startActivity(new Intent(this,FileOrganizationActivity.class));
                case 19 -> startActivity(new Intent(this,DownloadQueueActivity.class));
                case 1 -> LibraryDatabase.IO.execute(()->ScanWorker.prepareRefresh(this));
                case 2 -> { if (scanning) WorkManager.getInstance(this).cancelUniqueWork(ScanWorker.UNIQUE); else ScanWorker.enqueue(this); }
                case 3 -> folders();
                case 4 -> stats();
                case 5 -> exportPicker.launch(new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/json")
                    .addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"Peach-progreso.json"));
                case 6 -> new AlertDialog.Builder(this).setTitle("Restaurar progreso")
                    .setMessage("La copia reemplazará estado y organización con los mismos identificadores, incluidas identidades, alias y deseos. Añade y escanea primero las carpetas para recuperar vínculos a sus archivos.")
                    .setPositiveButton("Elegir copia",(d,w)->importPicker.launch(new Intent(Intent.ACTION_OPEN_DOCUMENT)
                        .setType("application/json").addCategory(Intent.CATEGORY_OPENABLE)))
                    .setNegativeButton("Cancelar",null).show();
                case 7 -> new AlertDialog.Builder(this).setTitle("Peach Local "+BuildConfig.VERSION_NAME)
                    .setMessage("Adaptación Android independiente · AGPL-3.0-or-later\n"+
                        "Peach original: peach-mitao/peach · © 2026 longmeidao\n"+
                        "Componentes AndroidX: Apache-2.0\nIcono: prototipo Peach Mobile, MIT\n\n"+
                        "Android "+Build.VERSION.RELEASE+" · API "+Build.VERSION.SDK_INT+"\n"+
                        "Modelo: "+Build.MODEL+"\nABI: "+String.join(", ",Build.SUPPORTED_ABIS)+"\n\n"+
                        "Catálogo y reproducción locales. Sin analítica. Las fuentes opcionales se consultan solo a petición; utilizan Internet.\n"+
                        "Nueva navegación visual, fuentes con vistas previas y reproductor renovado. Nueve fuentes. Room v13, copia v19 e intercambio v1. Las capacidades de cada sitio dependen de su acceso y formatos compatibles.")
                    .setPositiveButton("Cerrar",null).show();
                case 8 -> choosePlaylist(null);
                case 9 -> managePlaylist();
                case 10 -> explore();
                case 11 -> manageGroup();
                case 12 -> organization(0,"");
                case 13 -> organization(1,"");
                case 14 -> startActivity(new Intent(this,CatalogActivity.class));
                case 15 -> startActivity(new Intent(this,SourceBrowserActivity.class).putExtra("savedOnly",true));
                case 16 -> startActivity(new Intent(this,SourceBrowserActivity.class));
                case 17 -> versions();
                case 18 -> startActivity(new Intent(this,HistoryActivity.class));
                default -> { return false; }
            }
        return true;
    }
    private void acceptTool(Intent intent){int tool=intent.getIntExtra("libraryTool",0);intent.removeExtra("libraryTool");if(tool>0)handler.post(()->handleTool(tool));}
    private void folders() {
        if (roots.isEmpty()) { message("Todavía no hay carpetas añadidas."); return; }
        String[] labels=roots.stream().map(r->r.label+(r.state==2?" · acceso pendiente":"")).toArray(String[]::new);
        new AlertDialog.Builder(this).setTitle("Carpetas de biblioteca").setItems(labels,(d,index)-> {
            LibraryRoot root=roots.get(index);
            new AlertDialog.Builder(this).setTitle(root.label)
                .setMessage("Quitar esta ubicación borra sus registros de Peach, incluidos favoritos, progreso e historial de visitas. Tus archivos se conservan.")
                .setPositiveButton("Quitar de Peach",(dialog,w)-> {
                    if (scanning) { message("Pausa el escaneo y espera a que termine antes de quitar una carpeta."); return; }
                    LibraryDatabase.IO.execute(()-> {
                        db.runInTransaction(()-> { db.library().forgetMedia(root.uri); db.library().clearQueue(root.uri); db.library().forgetRoot(root.uri); });
                        runOnUiThread(()->{ if (selectedRoot.equals(root.uri)) { selectedRoot="";selectedFolder="";showMedia(); } });
                        try { getContentResolver().releasePersistableUriPermission(Uri.parse(root.uri),Intent.FLAG_GRANT_READ_URI_PERMISSION); }
                        catch (Exception ignored) { /* The grant may already have been revoked. */ }
                    });
                }).setNegativeButton("Conservar",null).show();
        }).setNegativeButton("Cerrar",null).show();
    }
    private void stats() {
        long bytes=media.stream().mapToLong(m->m.bytes).sum();
        long favorites=media.stream().filter(m->m.favorite).count(),watched=media.stream().filter(m->m.watched).count();
        long plays=media.stream().mapToLong(m->m.playCount).sum();
        new AlertDialog.Builder(this).setTitle("Tu biblioteca")
            .setMessage(media.size()+" medios · "+media.stream().filter(m->MediaRules.VIDEO.equals(m.mediaType)).count()+" videos · "+
                media.stream().filter(m->MediaRules.IMAGE.equals(m.mediaType)).count()+" imágenes · "+
                media.stream().filter(m->MediaRules.AUDIO.equals(m.mediaType)).count()+" audios · "+
                media.stream().filter(m->MediaRules.ARCHIVE.equals(m.mediaType)).count()+" comprimidos · "+
                media.stream().filter(m->MediaRules.OTHER.equals(m.mediaType)).count()+" otros\n"+android.text.format.Formatter.formatShortFileSize(this,bytes)+
                " de medios indexados\n"+favorites+" favoritos\n"+watched+" vistos\n"+plays+" aperturas de reproducción")
            .setPositiveButton("Cerrar",null).show();
    }
    private void chooseScope() {
        new AlertDialog.Builder(this).setTitle("Ver biblioteca").setItems(new String[]{"Toda la biblioteca","Explorar carpetas","Listas de reproducción","Metadatos y grupos"},(d,index)-> {
            if (index==0) { clearScope();showMedia(); }
            if (index==1) chooseFolderRoot();
            if (index==2) choosePlaylist(null);
            if (index==3) explore();
        }).setNegativeButton("Cerrar",null).show();
    }
    private void clearScope() {
        selectedRoot="";selectedFolder="";selectedPlaylist="";selectedFacet="";selectedTerm="";selectedGroup="";selectedEntity="";
    }
    private void explore() {
        List<String> labels=new ArrayList<>();labels.add("Grupos / versiones");
        for(CatalogIndex.Facet facet:CatalogIndex.FACETS)labels.add(facet.label());
        labels.add("Identidades y alias");labels.add("Lista de deseos");labels.add("Revisar versiones y partes");
        new AlertDialog.Builder(this).setTitle("Explorar biblioteca").setItems(labels.toArray(String[]::new),(d,index)-> {
            if(index==0)chooseGroup(null);
            else if(index<=CatalogIndex.FACETS.size())chooseTerm(CatalogIndex.FACETS.get(index-1));
            else if(index==labels.size()-1)versions();
            else organization(index==labels.size()-2?1:0,"");
        }).setNegativeButton("Cerrar",null).show();
    }
    private void versions(){startActivity(new Intent(this,VersionsActivity.class).putExtra("root",selectedRoot).putExtra("folder",selectedFolder));}
    private void organization(int section,String target) {
        Intent intent=new Intent(this,OrganizationActivity.class).putExtra("section",section).putExtra("targetMediaId",target);
        if(!selectedFacet.isEmpty())for(EntityIndex.Kind kind:EntityIndex.KINDS)if(kind.facets().contains(selectedFacet))
            intent.putExtra("suggestKind",kind.key()).putExtra("suggestName",selectedTerm);
        startActivity(intent);
    }
    private void acceptEntity(Intent intent) {
        if(intent.hasExtra("entityId")) {
            String id=intent.getStringExtra("entityId");intent.removeExtra("entityId");clearScope();selectedEntity=id==null?"":id;
            search.setText("");typeFilter.setSelection(0);filter.setSelection(0);order.setSelection(0);showMedia();
        }
    }
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);acceptEntity(intent);acceptTool(intent);}
    private void chooseTerm(CatalogIndex.Facet facet) {
        List<CatalogIndex.Term> terms=CatalogIndex.terms(media,facet.key());
        searchableChoices(facet.label(),terms.stream().map(t->t.value()+" · "+t.count()+" archivos").toList(),index->{
            selectTerm(facet.key(),terms.get(index).value());
        });
    }
    private void selectTerm(String facet,String term) {
        clearScope();selectedFacet=facet;selectedTerm=term;
        search.setText("");filter.setSelection(0);typeFilter.setSelection(0);order.setSelection(0);showMedia();
    }
    private void exploreMedia(MediaEntry target) {
        List<String> labels=new ArrayList<>(),facets=new ArrayList<>(),values=new ArrayList<>();
        for(CatalogIndex.Facet facet:CatalogIndex.FACETS)for(String term:CatalogIndex.values(target,facet.key())) {
            labels.add(facet.label()+" · "+term);facets.add(facet.key());values.add(term);
        }
        searchableChoices("Metadatos de este archivo",labels,index->selectTerm(facets.get(index),values.get(index)));
    }
    private void searchableChoices(String title,List<String> labels,java.util.function.IntConsumer select) {
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);
        EditText query=new EditText(this);query.setSingleLine(true);query.setHint("Buscar en "+title);body.addView(query);
        android.widget.ListView list=new android.widget.ListView(this);
        int height=(int)(Math.min(360,getResources().getConfiguration().screenHeightDp/2)*getResources().getDisplayMetrics().density);
        body.addView(list,new LinearLayout.LayoutParams(-1,height));
        TextView empty=new TextView(this);empty.setText("No hay elementos coincidentes.");body.addView(empty);list.setEmptyView(empty);
        List<Integer> indexes=new ArrayList<>();
        ArrayAdapter<String> choices=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,new ArrayList<>());
        list.setAdapter(choices);
        java.util.function.Consumer<String> update=text->{
            indexes.clear();choices.clear();
            String needle=text.trim().toLowerCase(java.util.Locale.ROOT);
            for(int i=0;i<labels.size();i++)if(labels.get(i).toLowerCase(java.util.Locale.ROOT).contains(needle)) {
                indexes.add(i);choices.add(labels.get(i));
            }
            choices.notifyDataSetChanged();
        };
        update.accept("");
        query.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after) {}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count) {update.accept(s.toString());}
            @Override public void afterTextChanged(Editable s) {}
        });
        var dialog=new AlertDialog.Builder(this).setTitle(title).setView(body).setNegativeButton("Cerrar",null).create();
        list.setOnItemClickListener((parent,view,position,id)->{int index=indexes.get(position);dialog.dismiss();select.accept(index);});
        dialog.show();
    }
    private void chooseGroup(MediaEntry target) {
        List<MediaGroup> snapshot=new ArrayList<>(groups);
        String[] labels=snapshot.stream().map(g->g.name+" · "+groupMembership.stream().filter(i->i.groupId.equals(g.id)).count()+" archivos").toArray(String[]::new);
        new AlertDialog.Builder(this).setTitle(target==null?"Grupos / versiones":"Añadir a un grupo")
            .setItems(labels,(d,index)-> {
                String id=snapshot.get(index).id;
                if(target==null)selectGroup(id);else doIo(()->{new GroupStore(db).add(id,target.id);message("Archivo añadido al grupo.");});
            }).setPositiveButton("Crear grupo",(d,w)->nameDialog("Crear grupo","",name->doIo(()-> {
                final String[] created={""};
                db.runInTransaction(()->{created[0]=new GroupStore(db).create(name);if(target!=null)new GroupStore(db).add(created[0],target.id);});
                runOnUiThread(()->selectGroup(created[0]));
            }))).setNegativeButton("Cerrar",null).show();
    }
    private void selectGroup(String id) {
        clearScope();selectedGroup=id;search.setText("");filter.setSelection(0);typeFilter.setSelection(0);order.setSelection(0);showMedia();
    }
    private void manageGroup() {
        String id=selectedGroup;
        MediaGroup group=groups.stream().filter(g->g.id.equals(id)).findFirst().orElse(null);if(group==null)return;
        new AlertDialog.Builder(this).setTitle(group.name).setItems(new String[]{"Cambiar nombre","Eliminar grupo"},(d,index)-> {
            if(index==0)nameDialog("Cambiar nombre",group.name,name->doIo(()->new GroupStore(db).rename(id,name)));
            else new AlertDialog.Builder(this).setTitle("Eliminar grupo")
                .setMessage("Se eliminará la agrupación. Los archivos, listas, favoritos y progreso se conservan.")
                .setPositiveButton("Eliminar grupo",(dialog,w)->doIo(()->db.library().deleteGroup(id)))
                .setNegativeButton("Conservar",null).show();
        }).setNegativeButton("Cerrar",null).show();
    }
    private void chooseFolderRoot() {
        if (roots.isEmpty()) { message("Añade una carpeta para explorarla.");return; }
        new AlertDialog.Builder(this).setTitle("Ubicaciones de biblioteca")
            .setItems(roots.stream().map(r->r.label).toArray(String[]::new),(d,index)->browseDirectory(roots.get(index),roots.get(index).label))
            .setNegativeButton("Cerrar",null).show();
    }
    private void browseDirectory(LibraryRoot root,String path) {
        List<String> children=LibraryView.children(media,root.uri,path);
        new AlertDialog.Builder(this).setTitle(path).setItems(children.toArray(String[]::new),
            (d,index)->browseDirectory(root,path+" / "+children.get(index)))
            .setPositiveButton("Ver medios aquí",(d,w)-> {
                clearScope();selectedRoot=root.uri;selectedFolder=path;showMedia();
            }).setNeutralButton("Subir",(d,w)-> {
                int split=path.lastIndexOf(" / ");
                if (split<0) chooseFolderRoot(); else browseDirectory(root,path.substring(0,split));
            }).setNegativeButton("Cerrar",null).show();
    }
    private void choosePlaylist(MediaEntry target) {
        List<Playlist> snapshot=new ArrayList<>(playlists);
        String[] names=snapshot.stream().map(p->p.name+" · "+membership.stream().filter(i->i.playlistId.equals(p.id)).count()+" medios").toArray(String[]::new);
        new AlertDialog.Builder(this).setTitle(target==null?"Listas de reproducción":"Añadir a una lista")
            .setItems(names,(d,index)-> {
                String id=snapshot.get(index).id;
                if (target==null) selectPlaylist(id);
                else doIo(()->{new PlaylistStore(db).add(id,target.id);message("Elemento añadido a la lista.");});
            }).setPositiveButton("Crear lista",(d,w)->nameDialog("Crear lista","",name->doIo(()-> {
                String id=new PlaylistStore(db).create(name);
                if (target!=null) new PlaylistStore(db).add(id,target.id);
                runOnUiThread(()->selectPlaylist(id));
            }))).setNegativeButton("Cerrar",null).show();
    }
    private void selectPlaylist(String id) {
        clearScope();selectedPlaylist=id;typeFilter.setSelection(0);order.setSelection(4);showMedia();
    }
    private void managePlaylist() {
        String id=selectedPlaylist;
        Playlist list=playlists.stream().filter(p->p.id.equals(id)).findFirst().orElse(null);
        if (list==null) return;
        new AlertDialog.Builder(this).setTitle(list.name).setItems(new String[]{"Cambiar nombre","Eliminar lista"},(d,index)-> {
            if (index==0) nameDialog("Cambiar nombre",list.name,name->doIo(()->new PlaylistStore(db).rename(id,name)));
            else new AlertDialog.Builder(this).setTitle("Eliminar lista")
                .setMessage("Se eliminará esta lista. Los archivos, favoritos y progreso se conservan.")
                .setPositiveButton("Eliminar lista",(dialog,w)->doIo(()->db.library().deletePlaylist(id)))
                .setNegativeButton("Conservar",null).show();
        }).setNegativeButton("Cerrar",null).show();
    }
    private void nameDialog(String title,String initial,java.util.function.Consumer<String> onSave) {
        EditText input=new EditText(this);input.setSingleLine(true);input.setText(initial);
        input.setHint("Nombre");input.setSelectAllOnFocus(true);
        var dialog=new AlertDialog.Builder(this).setTitle(title).setView(input)
            .setPositiveButton("Guardar",null).setNegativeButton("Cancelar",null).create();
        dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            try {String name=PlaylistStore.validName(input.getText().toString(),80);onSave.accept(name);dialog.dismiss();}
            catch (IllegalArgumentException e) {input.setError("Usa entre 1 y 80 caracteres.");}
        }));dialog.show();
    }
    private void mediaActions(MediaEntry media) {
        String listId=selectedPlaylist;
        List<String> actions=new ArrayList<>(List.of("Editar título y etiquetas","Añadir a una lista",
            media.favorite?"Quitar favorito":"Marcar favorito",media.watched?"Marcar sin ver":"Marcar visto"));
        actions.add("Añadir a un grupo / versiones");
        actions.add("Explorar metadatos de este archivo");
        actions.add("Vincular a una identidad");
        if(!selectedGroup.isEmpty())actions.add("Quitar de este grupo");
        if (!listId.isEmpty()) actions.addAll(List.of("Subir en la lista","Bajar en la lista","Quitar de esta lista"));
        actions.add("Organizar archivo / escribir NFO");
        new AlertDialog.Builder(this).setTitle(media.displayTitle()).setItems(actions.toArray(String[]::new),(d,index)-> {
            String action=actions.get(index);
            if(action.equals("Organizar archivo / escribir NFO")){startActivity(new Intent(this,FileOrganizationActivity.class).putExtra("mediaId",media.id));return;}
            if(action.equals("Añadir a un grupo / versiones")){chooseGroup(media);return;}
            if(action.equals("Explorar metadatos de este archivo")){exploreMedia(media);return;}
            if(action.equals("Vincular a una identidad")){organization(0,media.id);return;}
            if(action.equals("Quitar de este grupo")){String group=selectedGroup;doIo(()->db.library().removeGroupItem(group,media.id));return;}
            if(action.equals("Subir en la lista") || action.equals("Bajar en la lista")) {
                order.setSelection(4);doIo(()->new PlaylistStore(db).move(listId,media.id,action.equals("Subir en la lista")?-1:1));return;
            }
            if(action.equals("Quitar de esta lista")){doIo(()->db.library().removePlaylistItem(listId,media.id));return;}
            switch (index) {
                case 0 -> editMedia(media);
                case 1 -> choosePlaylist(media);
                case 2 -> doIo(()->db.library().toggleFavorite(media.id));
                case 3 -> doIo(()->db.library().toggleWatched(media.id));
                default -> { }
            }
        }).setNegativeButton("Cerrar",null).show();
    }
    private void editMedia(MediaEntry media) {
        LinearLayout fields=new LinearLayout(this);fields.setOrientation(LinearLayout.VERTICAL);
        int padding=(int)(20*getResources().getDisplayMetrics().density);fields.setPadding(padding,0,padding,0);
        TextView titleLabel=new TextView(this);titleLabel.setText(R.string.edit_title);fields.addView(titleLabel);
        EditText title=new EditText(this);title.setSingleLine(true);title.setText(media.displayTitle());fields.addView(title);
        TextView tagsLabel=new TextView(this);tagsLabel.setText(R.string.edit_tags);fields.addView(tagsLabel);
        EditText tags=new EditText(this);tags.setText(media.displayTags());tags.setMaxLines(4);fields.addView(tags);
        var dialog=new AlertDialog.Builder(this).setTitle("Editar datos locales").setView(fields)
            .setPositiveButton("Guardar",null).setNegativeButton("Cancelar",null)
            .setNeutralButton("Usar datos del archivo",(d,w)->doIo(()->db.library().editMetadata(media.id,null,null))).create();
        dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            try {
                String newTitle=PlaylistStore.validName(title.getText().toString(),300),newTags=tags.getText().toString().trim();
                if (newTags.length()>2000) {tags.setError("Usa hasta 2000 caracteres.");return;}
                String titleOverride=newTitle.equals(media.title)?null:newTitle;
                String tagsOverride=newTags.equals(media.tags)?null:newTags;
                doIo(()->db.library().editMetadata(media.id,titleOverride,tagsOverride));dialog.dismiss();
            } catch (IllegalArgumentException e) {title.setError("Usa entre 1 y 300 caracteres.");}
        }));dialog.show();
    }
    private void doIo(Runnable action) {
        LibraryDatabase.IO.execute(()->{try {action.run();}catch(Exception e){message("No se pudo guardar el cambio. Inténtalo otra vez.");}});
    }
    private void message(String text) { runOnUiThread(()->Toast.makeText(this,text,Toast.LENGTH_LONG).show()); }
    @Override protected void onPause() {
        getPreferences(MODE_PRIVATE).edit().putString("query",search.getText().toString())
            .putInt("filter",filter.getSelectedItemPosition()).putInt("order",order.getSelectedItemPosition()).putInt("type",typeFilter.getSelectedItemPosition())
            .putString("root",selectedRoot).putString("folder",selectedFolder).putString("playlist",selectedPlaylist)
            .putString("facet",selectedFacet).putString("term",selectedTerm).putString("group",selectedGroup)
            .putString("entity",selectedEntity)
            .apply(); super.onPause();
    }
    @Override protected void onSaveInstanceState(Bundle state){state.putBoolean("filtersOpen",findViewById(R.id.filterPanel).getVisibility()==View.VISIBLE);super.onSaveInstanceState(state);}
    @Override protected void onDestroy() { handler.removeCallbacks(applySearch);handler.removeCallbacks(renderOnce); super.onDestroy(); }
}
