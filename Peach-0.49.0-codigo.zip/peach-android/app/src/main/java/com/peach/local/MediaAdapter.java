package com.peach.local;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import java.util.function.Consumer;

public final class MediaAdapter extends ListAdapter<MediaEntry,MediaAdapter.Holder> {
    private final Consumer<MediaEntry> play, detail;
    /** Las tarjetas entran escalonadas solo la primera vez que se muestran en esta pantalla. */
    private final java.util.Set<String> shown=new java.util.HashSet<>();
    public MediaAdapter(Consumer<MediaEntry> play,Consumer<MediaEntry> detail) {
        super(new DiffUtil.ItemCallback<>() {
            @Override public boolean areItemsTheSame(@NonNull MediaEntry a,@NonNull MediaEntry b) { return a.id.equals(b.id); }
            @Override public boolean areContentsTheSame(@NonNull MediaEntry a,@NonNull MediaEntry b) {
                return a.displayTitle().equals(b.displayTitle()) && a.displayTags().equals(b.displayTags()) && a.position==b.position && a.duration==b.duration &&
                    a.favorite==b.favorite && a.watched==b.watched && a.missing==b.missing &&
                    a.modified==b.modified && a.poster.equals(b.poster) && a.bytes==b.bytes &&
                    a.nfoDetails.equals(b.nfoDetails) && a.catalogMetadata.equals(b.catalogMetadata) && a.plot.equals(b.plot) && a.year.equals(b.year) &&
                    a.studio.equals(b.studio) && a.actors.equals(b.actors) && a.folder.equals(b.folder) && a.name.equals(b.name) && a.mediaType.equals(b.mediaType);
            }
        });
        this.play=play; this.detail=detail;
        setStateRestorationPolicy(RecyclerView.Adapter.StateRestorationPolicy.PREVENT_WHEN_EMPTY);
    }
    @Override public int getItemViewType(int position){return 0;}
    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent,int type) {
        Context context=parent.getContext();int density=UiAppearance.prefs(context).getInt("density",1);boolean list=density==3;
        View view=LayoutInflater.from(context).inflate(list?R.layout.media_row:R.layout.media_card,parent,false);
        Holder holder=new Holder(view);
        // Estilo aplicado una sola vez por tarjeta, no en cada desplazamiento.
        view.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(UiAppearance.accentSoft(context,0x26)),null,UiAppearance.rounded(context,0xff000000,20)));
        UiAppearance.polish(view);
        holder.image.getLayoutParams().height=UiAppearance.dp(context,list?76:density==0?124:density==2?220:172);
        holder.image.setBackground(UiAppearance.rounded(context,UiAppearance.surface(context),list?12:18));holder.image.setClipToOutline(true);
        holder.title.setTextColor(UiAppearance.text(context));holder.title.setTypeface(UiAppearance.title(context));
        holder.info.setTextColor(UiAppearance.secondary(context));
        Button details=(Button)holder.details;PeachDesign.iconButton(details,R.drawable.ic_ui_more,"Detalles");
        details.setCompoundDrawables(PeachDesign.icon(context,R.drawable.ic_ui_more,list?UiAppearance.secondary(context):0xffffffff),null,null,null);
        if(!list){android.graphics.drawable.GradientDrawable dot=new android.graphics.drawable.GradientDrawable();dot.setShape(android.graphics.drawable.GradientDrawable.OVAL);dot.setColor(0x66000000);
            details.setBackground(new android.graphics.drawable.InsetDrawable(dot,UiAppearance.dp(context,8)));details.setPadding(UiAppearance.dp(context,13),0,0,0);}
        holder.favorite.setImageDrawable(PeachDesign.icon(context,R.drawable.ic_ui_heart_filled,UiAppearance.accent(context)));
        android.graphics.drawable.GradientDrawable badge=new android.graphics.drawable.GradientDrawable();badge.setShape(android.graphics.drawable.GradientDrawable.OVAL);badge.setColor(UiAppearance.dark(context)?0x99000000:0xe6ffffff);holder.favorite.setBackground(badge);
        holder.length.setBackground(UiAppearance.rounded(context,0xb3000000,8));holder.length.setTextColor(0xffffffff);
        holder.progress.setProgressTintList(android.content.res.ColorStateList.valueOf(UiAppearance.accent(context)));
        holder.progress.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(list?UiAppearance.surfaceHigh(context):0x55ffffff));
        return holder;
    }
    @Override public void onBindViewHolder(@NonNull Holder holder,int position) {
        MediaEntry m=getItem(position);Context context=holder.itemView.getContext();
        holder.title.setText(m.displayTitle());
        holder.info.setText(summary(m));
        holder.favorite.setVisibility(m.favorite?View.VISIBLE:View.GONE);
        String length=duration(m.duration);boolean timed=!length.isEmpty()&&(MediaRules.VIDEO.equals(m.mediaType)||MediaRules.AUDIO.equals(m.mediaType));
        holder.length.setVisibility(timed?View.VISIBLE:View.GONE);holder.length.setText(length);
        int done=m.duration>0?(int)Math.min(1000,m.position*1000/m.duration):0;
        holder.progress.setProgress(done);holder.progress.setVisibility(done>0&&!m.watched?View.VISIBLE:View.INVISIBLE);
        Thumbnails.load(context,m,holder.image);
        holder.itemView.setContentDescription(m.displayTitle()+(m.favorite?", favorito":"")+". "+holder.info.getText()+". Mantén pulsado para ver detalles.");
        holder.itemView.setOnClickListener(v -> play.accept(m));
        holder.itemView.setOnLongClickListener(v -> { detail.accept(m); return true; });
        holder.details.setContentDescription("Detalles de "+m.displayTitle());
        holder.details.setOnClickListener(v->detail.accept(m));
        enter(holder.itemView,m.id,position);
    }
    /** Una línea corta: tipo · estado · año. El tamaño y los datos técnicos quedan en Detalles. */
    static String summary(MediaEntry m) {
        if(m.missing)return "Archivo no disponible";
        boolean reading=DocumentRules.readable(m.name);
        String kind=reading?DocumentRules.label(m.name):MediaRules.label(m.mediaType);
        String state=reading?(m.watched?"Leído":""):!MediaRules.catalogNotice(m).isEmpty()?"Solo catálogo":
            m.watched?(MediaRules.AUDIO.equals(m.mediaType)?"Escuchado":"Visto"):m.position>0?"Continuar":"";
        StringBuilder text=new StringBuilder(kind);
        if(!state.isEmpty())text.append(" · ").append(state);
        if(!m.displayYear().isEmpty())text.append(" · ").append(m.displayYear());
        return text.toString();
    }
    static String duration(long millis) {
        if(millis<1000)return "";long seconds=millis/1000,h=seconds/3600,min=seconds%3600/60,sec=seconds%60;
        return h>0?String.format(java.util.Locale.ROOT,"%d:%02d:%02d",h,min,sec):String.format(java.util.Locale.ROOT,"%d:%02d",min,sec);
    }
    private void enter(View view,String id,int position) {
        if(!shown.add(id) || !UiAppearance.motion(view.getContext()) || shown.size()>400){view.setAlpha(1);view.setTranslationY(0);return;}
        view.setAlpha(0);view.setTranslationY(UiAppearance.dp(view.getContext(),18));
        view.animate().alpha(1).translationY(0).setStartDelay(Math.min(position,12)*35L).setDuration(300)
            .setInterpolator(new android.view.animation.DecelerateInterpolator(1.8f)).start();
    }
    @Override public void onViewRecycled(@NonNull Holder holder){holder.itemView.animate().cancel();holder.itemView.setAlpha(1);holder.itemView.setTranslationY(0);}
    static final class Holder extends RecyclerView.ViewHolder {
        final TextView title,info,length; final ImageView image,favorite; final ProgressBar progress;final View details;
        Holder(View view) {
            super(view); title=view.findViewById(R.id.title); info=view.findViewById(R.id.info);
            image=view.findViewById(R.id.thumbnail); progress=view.findViewById(R.id.progress);
            details=view.findViewById(R.id.details_button);favorite=view.findViewById(R.id.card_favorite);length=view.findViewById(R.id.card_duration);
        }
    }
}
