package com.peach.local;

import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import com.google.common.util.concurrent.ListenableFuture;

/**
 * Mini reproductor fijo sobre la barra de navegación. Solo se conecta cuando ya existe audio
 * activo en {@link AudioService}; nunca inicia el servicio ni cambia la cola de reproducción.
 */
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
final class NowPlayingBar implements DefaultLifecycleObserver {
    private final AppCompatActivity activity;
    final LinearLayout root;
    private final ImageView cover;private final TextView title,info;private final Button toggle;private final ProgressBar line;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private MediaController controller;private ListenableFuture<MediaController> pending;
    private boolean started;private String artFor="";
    /** Último estado conocido: las demás pestañas lo muestran al instante, sin esperar a reconectar. */
    private static String lastId,lastTitle,lastInfo;private static boolean lastPlaying;private static android.graphics.Bitmap lastArt;
    private final Player.Listener events=new Player.Listener(){@Override public void onEvents(@NonNull Player player,@NonNull Player.Events e){update();}};
    private final Runnable tick=new Runnable(){@Override public void run(){progress();if(started&&controller!=null&&controller.isPlaying())handler.postDelayed(this,500);}};

    /** Crea la barra (oculta) y la enlaza al ciclo de vida de la pantalla. */
    static View create(Activity activity) {
        if (!(activity instanceof AppCompatActivity owner)) { View empty=new View(activity);empty.setVisibility(View.GONE);return empty; }
        NowPlayingBar bar=new NowPlayingBar(owner);owner.getLifecycle().addObserver(bar);return bar.root;
    }

    private NowPlayingBar(AppCompatActivity a) {
        activity=a;int dp8=PeachDesign.dp(a,8);
        root=PeachDesign.column(a);root.setId(R.id.now_playing);visible(false);
        root.setBackground(UiAppearance.rounded(a,UiAppearance.surfaceHigh(a),20));root.setClipToOutline(true);
        root.setElevation(PeachDesign.dp(a,6));
        LinearLayout row=PeachDesign.row(a);row.setPadding(dp8,dp8,PeachDesign.dp(a,4),dp8);
        cover=new ImageView(a);cover.setScaleType(ImageView.ScaleType.CENTER_CROP);cover.setBackground(UiAppearance.rounded(a,UiAppearance.surface(a),12));cover.setClipToOutline(true);
        cover.setImageResource(R.drawable.art_audio);cover.setContentDescription(null);
        row.addView(cover,new LinearLayout.LayoutParams(PeachDesign.dp(a,46),PeachDesign.dp(a,46)));
        LinearLayout labels=PeachDesign.column(a);labels.setPadding(PeachDesign.dp(a,12),0,PeachDesign.dp(a,6),0);
        title=PeachDesign.text(a,"",15,"body");title.setTypeface(UiAppearance.title(a));title.setSingleLine(true);title.setEllipsize(TextUtils.TruncateAt.END);
        info=PeachDesign.text(a,"",12,"muted");info.setSingleLine(true);info.setEllipsize(TextUtils.TruncateAt.END);
        labels.addView(title);labels.addView(info);row.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
        toggle=PeachDesign.iconButton(a,R.drawable.ic_ui_pause_filled,"Pausar",v->{if(controller==null)return;PeachDesign.pop(v);if(controller.getPlayWhenReady())controller.pause();else controller.play();});
        toggle.setId(R.id.now_playing_toggle);row.addView(toggle,new LinearLayout.LayoutParams(PeachDesign.dp(a,52),PeachDesign.dp(a,52)));
        root.addView(row,new LinearLayout.LayoutParams(-1,-2));
        line=new ProgressBar(a,null,android.R.attr.progressBarStyleHorizontal);line.setMax(1000);line.setProgressTintList(android.content.res.ColorStateList.valueOf(UiAppearance.accent(a)));
        line.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0x22ffffff));
        root.addView(line,new LinearLayout.LayoutParams(-1,PeachDesign.dp(a,3)));
        root.setFocusable(true);root.setClickable(true);
        root.setForeground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(UiAppearance.accentSoft(a,0x33)),null,UiAppearance.rounded(a,0xff000000,20)));
        root.setOnClickListener(v->activity.startActivity(new Intent(activity,AudioActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)));
        LinearLayout.LayoutParams margins=new LinearLayout.LayoutParams(-1,-2);margins.setMargins(0,0,0,dp8);root.setLayoutParams(margins);
    }

    /** Panel de cristal que envuelve la barra (o la propia barra si no hay panel). */
    static void follow(View player,View panel){player.setTag(R.id.now_playing_toggle,panel);}
    private View host(){return root.getTag(R.id.now_playing_toggle) instanceof View v?v:root;}
    private void visible(boolean on){int v=on?View.VISIBLE:View.GONE;root.setVisibility(v);host().setVisibility(v);}
    @Override public void onStart(@NonNull LifecycleOwner owner){started=true;restore();connect();}
    /** Pinta el último estado guardado si hay audio activo; si no, oculta la barra. */
    private void restore(){
        if(AudioService.liveToken()==null||lastId==null){visible(false);return;}
        title.setText(lastTitle);info.setText(lastInfo);playIcon(lastPlaying);
        if(!lastId.equals(artFor)){artFor=lastId;if(lastArt!=null)cover.setImageBitmap(lastArt);else cover.setImageResource(R.drawable.art_audio);}
        visible(true);
    }
    private void playIcon(boolean playing){toggle.setCompoundDrawables(PeachDesign.icon(activity,playing?R.drawable.ic_ui_pause_filled:R.drawable.ic_ui_play_filled,UiAppearance.text(activity)),null,null,null);toggle.setContentDescription(playing?"Pausar":"Reproducir");}
    @Override public void onStop(@NonNull LifecycleOwner owner){
        started=false;handler.removeCallbacks(tick);
        if(controller!=null){controller.removeListener(events);controller=null;}
        if(pending!=null){MediaController.releaseFuture(pending);pending=null;}
    }

    private void connect() {
        SessionToken token=AudioService.liveToken();
        if (token==null) { visible(false); return; }
        ListenableFuture<MediaController> future;
        try { future=new MediaController.Builder(activity,token).buildAsync(); }
        catch (RuntimeException error) { visible(false); return; }
        pending=future;
        future.addListener(()->{
            if (!started || pending!=future) return;
            try { controller=future.get();controller.addListener(events);update(); }
            catch (Exception error) { visible(false); }
        },ContextCompat.getMainExecutor(activity));
    }

    private void update() {
        if (!started || controller==null) return;
        MediaItem item=controller.getCurrentMediaItem();
        if (item==null || controller.getPlaybackState()==Player.STATE_IDLE && controller.getMediaItemCount()==0) { lastId=null;lastArt=null;visible(false); return; }
        CharSequence name=item.mediaMetadata.title;CharSequence artist=item.mediaMetadata.artist;
        title.setText(TextUtils.isEmpty(name)?"Audio de Peach":name);
        info.setText(!TextUtils.isEmpty(artist)?artist:"Reproduciendo · "+(controller.getCurrentMediaItemIndex()+1)+" de "+controller.getMediaItemCount());
        boolean playing=controller.getPlayWhenReady();playIcon(playing);
        if(!item.mediaId.equals(lastId))lastArt=null;lastId=item.mediaId;lastTitle=title.getText().toString();lastInfo=info.getText().toString();lastPlaying=playing;
        root.setContentDescription("Reproduciendo ahora: "+title.getText()+". Toca para abrir el reproductor.");
        if (!item.mediaId.equals(artFor)) {
            artFor=item.mediaId;cover.setImageResource(R.drawable.art_audio);String expected=artFor;
            AudioArt.forMedia(activity,expected,256,bitmap->{ if (bitmap!=null && expected.equals(artFor)) { PeachDesign.crossfade(cover,bitmap); if (expected.equals(lastId)) lastArt=bitmap; } });
        }
        if (host().getVisibility()!=View.VISIBLE) { visible(true); PeachDesign.reveal(host()); }
        progress();handler.removeCallbacks(tick);if (controller.isPlaying()) handler.postDelayed(tick,500);
    }

    private void progress() {
        if (controller==null) return;long duration=controller.getDuration();
        line.setProgress(duration>0?(int)Math.min(1000,controller.getCurrentPosition()*1000/duration):0);
    }
}
