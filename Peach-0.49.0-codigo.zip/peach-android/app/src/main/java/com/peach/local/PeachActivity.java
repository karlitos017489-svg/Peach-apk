package com.peach.local;

import android.os.Bundle;
import androidx.appcompat.app.*;

/** Shared native styling; reader/video canvases retain their own content controls. */
public abstract class PeachActivity extends AppCompatActivity {
    private String appearance;
    private String stamp(){return UiAppearance.prefs(this).getAll().toString()+"|"+UiAppearance.wallpaper(this).lastModified()+"|"+UiAppearance.wallpaper(this).length();}
    @Override protected void onCreate(Bundle state){
        boolean canvas=this instanceof PlayerActivity||this instanceof AudioActivity||this instanceof ImageViewerActivity||this instanceof ReaderActivity;
        int mode=canvas?1:UiAppearance.prefs(this).getInt("mode",1);getDelegate().setLocalNightMode(mode==0?AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM:mode==2?AppCompatDelegate.MODE_NIGHT_NO:AppCompatDelegate.MODE_NIGHT_YES);
        setTheme(UiAppearance.theme(this));super.onCreate(state);appearance=stamp();
        getWindow().setBackgroundDrawableResource(canvas?android.R.color.black:android.R.color.transparent);
        if(!canvas)getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(UiAppearance.background(this)));
        if(getIntent().getBooleanExtra(PeachDesign.TAB,false))overridePendingTransition(0,0);else if(UiAppearance.motion(this)){int style=UiAppearance.prefs(this).getInt("motion",1);overridePendingTransition(style==2?R.anim.peach_slide_in:R.anim.peach_fade_in,R.anim.peach_hold);}else overridePendingTransition(0,0);
    }
    @Override protected void onPostCreate(Bundle state){super.onPostCreate(state);
        if(!(this instanceof PlayerActivity||this instanceof AudioActivity||this instanceof ImageViewerActivity||this instanceof ReaderActivity))UiAppearance.polish(findViewById(android.R.id.content));
        if(this instanceof MainActivity){UiAppearance.applyWallpaper(this);PeachDesign.main(this);((android.widget.TextView)findViewById(R.id.navLibrary)).setTextColor(UiAppearance.accent(this));((android.widget.TextView)findViewById(R.id.summary)).setTextColor(UiAppearance.secondary(this));((android.widget.TextView)findViewById(R.id.scanStatus)).setTextColor(UiAppearance.secondary(this));}
    }
    @Override protected void onNewIntent(android.content.Intent intent){super.onNewIntent(intent);if(intent.getBooleanExtra(PeachDesign.TAB,false)){overridePendingTransition(0,0);PeachDesign.tabEnter(this);}}
    @Override protected void onResume(){super.onResume();if(appearance!=null&&!appearance.equals(stamp())){appearance=stamp();recreate();}}
    @Override public void finish(){super.finish();if(UiAppearance.motion(this))overridePendingTransition(R.anim.peach_hold,R.anim.peach_fade_out);else overridePendingTransition(0,0);}
}
