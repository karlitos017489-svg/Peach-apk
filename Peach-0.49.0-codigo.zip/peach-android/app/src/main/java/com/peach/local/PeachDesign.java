package com.peach.local;

import android.app.Activity;
import android.content.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import androidx.core.view.*;

/** Shared native design system. Icons always have spoken labels and 48 dp touch targets. */
final class PeachDesign {
    static int dp(Context c,int n){return UiAppearance.dp(c,n);}
    static <T extends View> T role(T view,String role){view.setTag(R.id.design_role,role);finish(view);return view;}
    static Drawable icon(Context c,int id,int color){Drawable d=androidx.appcompat.content.res.AppCompatResources.getDrawable(c,id).mutate();d.setTint(color);d.setBounds(0,0,dp(c,22),dp(c,22));return d;}
    static void finish(View v){
        Context c=v.getContext();String role=String.valueOf(v.getTag(R.id.design_role));
        if(v instanceof TextView t){
            t.setTextColor(role.equals("muted")?UiAppearance.secondary(c):role.equals("accent")||role.equals("nav-on")?UiAppearance.accent(c):UiAppearance.text(c));
            if(role.equals("heading")){t.setTextSize(30);t.setTypeface(UiAppearance.display(c));t.setLetterSpacing(-0.01f);t.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);}
            if(role.equals("section")){t.setTextSize(20);t.setTypeface(UiAppearance.title(c));}
        }
        if(v instanceof Button chip&&role.equals("chip")){chipState(chip,chip.isSelected());return;}
        if(v instanceof Button b){
            b.setAllCaps(false);b.setMinWidth(dp(c,48));b.setMinHeight(dp(c,48));b.setMinimumWidth(dp(c,48));b.setMinimumHeight(dp(c,48));b.setTextSize(role.startsWith("nav")?11:14);
            b.setGravity(Gravity.CENTER);b.setStateListAnimator(null);b.setBackgroundTintList(null);
            int color=role.equals("primary")?UiAppearance.accent(c):role.equals("nav-on")?(UiAppearance.accent(c)&0x00ffffff)|0x24000000:role.equals("quiet")||role.equals("icon")||role.startsWith("nav")?android.graphics.Color.TRANSPARENT:UiAppearance.surfaceHigh(c);
            if(role.equals("icon")){GradientDrawable mask=new GradientDrawable();mask.setShape(GradientDrawable.OVAL);mask.setColor(0xff000000);b.setBackground(new RippleDrawable(android.content.res.ColorStateList.valueOf(UiAppearance.accentSoft(c,0x40)),null,mask));}
            else b.setBackground(new RippleDrawable(android.content.res.ColorStateList.valueOf(UiAppearance.accentSoft(c,0x33)),UiAppearance.rounded(c,color,role.startsWith("nav")?22:16),null));
            if(role.equals("primary")){b.setTextColor(UiAppearance.onAccent(c));b.setTypeface(UiAppearance.title(c));}
            else if(!role.startsWith("nav")&&!role.equals("icon"))button(b);
            if(!role.startsWith("nav"))press(b);
            b.setPadding(dp(c,role.equals("icon")?12:14),dp(c,6),dp(c,role.equals("icon")?12:14),dp(c,6));
        }
    }
    static TextView text(Context c,String value,int size,String role){TextView t=new TextView(c);t.setText(value);t.setTextSize(size);role(t,role);return t;}
    static Button action(Context c,String label,String role,View.OnClickListener click){Button b=new Button(c);b.setText(label);role(b,role);b.setOnClickListener(click);return b;}
    static Button iconButton(Context c,int id,String label,View.OnClickListener click){Button b=action(c,"","icon",click);b.setContentDescription(label);b.setCompoundDrawables(icon(c,id,UiAppearance.text(c)),null,null,null);b.setLayoutParams(new LinearLayout.LayoutParams(dp(c,48),dp(c,48)));return b;}
    static void iconButton(Button b,int id,String label){b.setText("");b.setContentDescription(label);role(b,"icon");b.setCompoundDrawables(icon(b.getContext(),id,UiAppearance.text(b.getContext())),null,null,null);}
    static LinearLayout row(Context c){LinearLayout l=new LinearLayout(c);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    static LinearLayout column(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);return l;}
    static void gap(LinearLayout root,int height){View v=new View(root.getContext());root.addView(v,new LinearLayout.LayoutParams(1,dp(root.getContext(),height)));}
    static void insets(Activity a,View root,int padding){WindowCompat.setDecorFitsSystemWindows(a.getWindow(),false);ViewCompat.setOnApplyWindowInsetsListener(root,(v,i)->{var b=i.getInsets(WindowInsetsCompat.Type.systemBars()|WindowInsetsCompat.Type.displayCutout()|WindowInsetsCompat.Type.ime());int p=dp(a,padding);v.setPadding(b.left+p,b.top,b.right+p,b.bottom);return i;});}
    static void navButton(Button b,int icon,String text,boolean active){b.setText(text);role(b,active?"nav-on":"nav");b.setCompoundDrawablePadding(dp(b.getContext(),4));b.setCompoundDrawables(null,icon(b.getContext(),icon,active?UiAppearance.accent(b.getContext()):UiAppearance.secondary(b.getContext())),null,null);b.setContentDescription(text+(active?", sección actual":""));}
    static View nav(Activity a,int active){
        LinearLayout bar=row(a);bar.setPadding(dp(a,6),dp(a,5),dp(a,6),dp(a,5));
        int[] icons={R.drawable.ic_ui_library,R.drawable.ic_ui_sources,R.drawable.ic_ui_download,R.drawable.ic_ui_settings};String[] names={"Biblioteca","Fuentes","Descargas","Ajustes"};
        Class<?>[] screens={MainActivity.class,SourceBrowserActivity.class,DownloadQueueActivity.class,SettingsActivity.class};
        for(int i=0;i<4;i++){final int n=i;Button b=new Button(a);navButton(b,icons[i],names[i],i==active);bar.addView(b,new LinearLayout.LayoutParams(0,dp(a,60),1));b.setOnClickListener(v->{if(n==active)return;pop(v);go(a,screens[n]);});}
        return dock(a,bar);
    }
    /** Acciones destructivas en rojo suave para distinguirlas antes de tocarlas. */
    static boolean destructive(CharSequence label){String t=String.valueOf(label).trim().toLowerCase(java.util.Locale.ROOT);for(String w:new String[]{"eliminar","borrar","quitar","descartar","vaciar"})if(t.startsWith(w))return true;return false;}
    static int danger(Context c){return UiAppearance.dark(c)?0xffff8a80:0xffb3261e;}
    /** Texto de botones secundarios: peso medio y rojo si la acción es destructiva. */
    static void button(Button b){b.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));if(destructive(b.getText()))b.setTextColor(danger(b.getContext()));}
    /** Respuesta al toque: el botón se hunde un poco. Respeta "Animaciones: Ninguna". */
    @android.annotation.SuppressLint("ClickableViewAccessibility")
    static void press(View v){if(!UiAppearance.motion(v.getContext()))return;v.setOnTouchListener((view,event)->{int action=event.getActionMasked();
        if(action==android.view.MotionEvent.ACTION_DOWN)view.animate().scaleX(.96f).scaleY(.96f).setDuration(90).start();
        else if(action==android.view.MotionEvent.ACTION_UP||action==android.view.MotionEvent.ACTION_CANCEL)view.animate().scaleX(1).scaleY(1).setDuration(160).setInterpolator(new android.view.animation.OvershootInterpolator(2f)).start();
        return false;});}
    /**
     * Barra inferior fija: se superpone a la pantalla con la misma posición y tamaño en las cuatro
     * secciones (antes cada pantalla la dibujaba con márgenes distintos y "saltaba"). Lleva encima el
     * mini reproductor. Devuelve un espaciador que la pantalla coloca al final de su contenido.
     */
    static View dock(Activity a,View bar){
        android.widget.FrameLayout content=a.findViewById(android.R.id.content);
        LinearLayout stack=column(a);stack.setId(R.id.nav_dock);stack.setClipChildren(false);stack.setClipToPadding(false);
        View mini=NowPlayingBar.create(a);
        if(mini instanceof LinearLayout player){android.widget.FrameLayout glass=Glass.wrap(a,player,22);glass.setVisibility(player.getVisibility());player.setBackground(null);player.setElevation(0);
            NowPlayingBar.follow(player,glass);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(a,8);stack.addView(glass,p);}
        if(bar.getParent() instanceof android.view.ViewGroup old)old.removeView(bar);
        stack.addView(Glass.wrap(a,bar,30),new LinearLayout.LayoutParams(-1,-2));
        int side=dp(a,16),gap=dp(a,12);
        android.widget.FrameLayout.LayoutParams at=new android.widget.FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);at.setMargins(side,0,side,gap);
        content.addView(stack,at);
        ViewCompat.setOnApplyWindowInsetsListener(stack,(v,insets)->{var b=insets.getInsets(WindowInsetsCompat.Type.systemBars()|WindowInsetsCompat.Type.displayCutout());
            android.widget.FrameLayout.LayoutParams lp=(android.widget.FrameLayout.LayoutParams)v.getLayoutParams();lp.setMargins(side+b.left,0,side+b.right,gap+b.bottom);v.setLayoutParams(lp);return insets;});
        View spacer=new View(a);spacer.setId(R.id.nav_spacer);spacer.setLayoutParams(new LinearLayout.LayoutParams(1,0));
        content.getViewTreeObserver().addOnGlobalLayoutListener(()->reserve(content,stack,spacer));
        return spacer;
    }
    /**
     * Deja sitio para la barra: si lo último de la pantalla es una lista, la lista pasa por detrás del
     * cristal con relleno inferior; si no, el espaciador empuja el contenido hacia arriba.
     */
    static void reserve(android.view.ViewGroup content,View dock,View spacer){
        if(content.getChildCount()<2||dock.getHeight()==0||content.getHeight()==0)return;
        if(content.getChildAt(content.getChildCount()-1)!=dock)dock.bringToFront();
        View root=screenRoot(content);if(root==null)return;
        // Todo en coordenadas del contenedor; si la barra aún no tiene posición válida, no se calcula nada.
        int gap=dp(dock.getContext(),8),dockTop=dock.getTop()-gap;if(dockTop<=0||dock.getBottom()>content.getHeight())return;
        int limit=content.getHeight()-dockTop;// Nunca se reserva más que la altura real de la barra y su margen.
        int[] base=new int[2],at=new int[2];content.getLocationInWindow(base);
        View list=scrollable(root,spacer);
        if(list!=null){
            list.getLocationInWindow(at);int bottomInContent=at[1]-base[1]+list.getHeight();int overlap=Math.max(0,Math.min(limit,bottomInContent-dockTop));
            int own=list.getTag(R.id.nav_dock) instanceof Integer i?i:list.getPaddingBottom();if(!(list.getTag(R.id.nav_dock) instanceof Integer))list.setTag(R.id.nav_dock,own);
            int bottom=own+overlap;
            // Solo si cambia: RecyclerView pide un reacomodo cada vez que se llama, aunque el valor sea el mismo.
            if(list instanceof android.view.ViewGroup g&&g.getClipToPadding())g.setClipToPadding(false);
            if(list.getPaddingBottom()!=bottom)list.setPadding(list.getPaddingLeft(),list.getPaddingTop(),list.getPaddingRight(),bottom);
            if(spacer.getLayoutParams()!=null&&spacer.getLayoutParams().height!=0){spacer.getLayoutParams().height=0;spacer.requestLayout();}
        }else if(spacer.getParent()!=null&&spacer.getLayoutParams()!=null){
            spacer.getLocationInWindow(at);int top=at[1]-base[1];
            // Altura para que el final del contenido quede justo encima de la barra; acotada para no crecer sin fin.
            int need=Math.max(0,Math.min(limit,top+spacer.getHeight()-dockTop));
            if(Math.abs(need-spacer.getLayoutParams().height)>1){spacer.getLayoutParams().height=need;spacer.requestLayout();}
        }
    }
    /** La raíz de la pantalla: el primer hijo de android.R.id.content que no es la barra. */
    static View screenRoot(android.view.ViewGroup content){for(int i=0;i<content.getChildCount();i++){View v=content.getChildAt(i);if(v.getId()!=R.id.nav_dock)return v;}return null;}
    /** La lista que llega hasta el final de la pantalla (justo antes del espaciador), si existe. */
    static View scrollable(View root,View spacer){
        if(!(root instanceof android.view.ViewGroup g))return null;
        int end=g.indexOfChild(spacer);if(end<0)end=g.getChildCount();
        for(int i=end-1;i>=0;i--){View child=g.getChildAt(i);if(child.getVisibility()==View.GONE||child==spacer)continue;return find(child);}
        return null;
    }
    private static View find(View v){
        if(v instanceof androidx.recyclerview.widget.RecyclerView||v instanceof android.widget.ScrollView||v instanceof android.widget.AbsListView)return v;
        if(v instanceof android.widget.FrameLayout f)for(int i=0;i<f.getChildCount();i++){View c=f.getChildAt(i);if(c.getVisibility()!=View.GONE){View r=find(c);if(r!=null)return r;}}
        return null;
    }
    /** Cambia de sección conservando cada pantalla (búsqueda, desplazamiento y resultados). */
    static void go(Activity a,Class<?> screen){a.startActivity(new Intent(a,screen).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT|Intent.FLAG_ACTIVITY_NO_ANIMATION).putExtra(TAB,true));a.overridePendingTransition(0,0);}
    static final String TAB="peachTab";
    /** Al cambiar de pestaña solo el contenido aparece con un fundido breve; la barra no se mueve. */
    static void tabEnter(Activity a){if(!UiAppearance.motion(a))return;android.view.ViewGroup content=a.findViewById(android.R.id.content);if(content==null||content.getChildCount()==0)return;View root=content.getChildAt(0);root.setAlpha(.35f);root.animate().alpha(1).setDuration(160).start();}
    /** Pequeño rebote al tocar; respeta la opción "Sin animaciones". */
    static void pop(View v){if(!UiAppearance.motion(v.getContext()))return;v.animate().cancel();v.setScaleX(.86f);v.setScaleY(.86f);v.animate().scaleX(1).scaleY(1).setDuration(320).setInterpolator(new android.view.animation.OvershootInterpolator(3f)).start();}
    /** Aparición suave desde abajo. */
    static void reveal(View v){v.setVisibility(View.VISIBLE);if(!UiAppearance.motion(v.getContext())){v.setAlpha(1);v.setTranslationY(0);return;}v.setAlpha(0);v.setTranslationY(dp(v.getContext(),16));v.animate().alpha(1).translationY(0).setDuration(260).setInterpolator(new android.view.animation.DecelerateInterpolator(1.6f)).start();}
    /** Cambio de imagen con fundido cruzado. */
    static void crossfade(android.widget.ImageView view,android.graphics.Bitmap bitmap){
        view.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        if(!UiAppearance.motion(view.getContext())||view.getDrawable()==null){view.setImageBitmap(bitmap);return;}
        TransitionDrawable fade=new TransitionDrawable(new Drawable[]{view.getDrawable(),new BitmapDrawable(view.getResources(),bitmap)});fade.setCrossFadeEnabled(true);view.setImageDrawable(fade);fade.startTransition(280);
    }
    /** Pastilla seleccionable (chips de Biblioteca y opciones de Apariencia). */
    static Button chip(Context c,String label,boolean selected,View.OnClickListener click){Button b=new Button(c);b.setText(label);b.setTag(R.id.design_role,"chip");b.setOnClickListener(click);chipState(b,selected);return b;}
    static void chipState(Button b,boolean selected){Context c=b.getContext();b.setAllCaps(false);b.setTextSize(14);b.setMinHeight(dp(c,40));b.setMinimumHeight(dp(c,40));b.setMinWidth(0);b.setMinimumWidth(0);b.setStateListAnimator(null);b.setBackgroundTintList(null);b.setPadding(dp(c,16),0,dp(c,16),0);b.setSelected(selected);
        b.setTextColor(selected?UiAppearance.onAccent(c):UiAppearance.text(c));b.setTypeface(selected?UiAppearance.title(c):Typeface.DEFAULT);
        b.setBackground(new RippleDrawable(android.content.res.ColorStateList.valueOf(UiAppearance.accentSoft(c,0x40)),UiAppearance.rounded(c,selected?UiAppearance.accent(c):UiAppearance.surfaceHigh(c),20),null));}
    static void main(Activity a){
        int[] ids={R.id.navLibrary,R.id.navSources,R.id.navDownloads,R.id.navSettings};int[] icons={R.drawable.ic_ui_library,R.drawable.ic_ui_sources,R.drawable.ic_ui_download,R.drawable.ic_ui_settings};String[] names={"Biblioteca","Fuentes","Descargas","Ajustes"};
        for(int i=0;i<4;i++)navButton(a.findViewById(ids[i]),icons[i],names[i],i==0);
        View nav=a.findViewById(R.id.mainNav);nav.setBackground(null);if(nav.getLayoutParams() instanceof android.view.ViewGroup.MarginLayoutParams m)m.bottomMargin=0;
        if(a.findViewById(R.id.nav_dock)==null)dock(a,nav);
        TextView heading=a.findViewById(R.id.library_title);if(heading!=null)role(heading,"heading");
        iconButton(a.findViewById(R.id.more),R.drawable.ic_ui_more,"Más opciones de biblioteca");
        iconButton(a.findViewById(R.id.addFolder),R.drawable.ic_ui_plus,"Añadir carpeta");
        Button filters=a.findViewById(R.id.toggleFilters);filters.setText("");filters.setContentDescription("Filtrar biblioteca");role(filters,"icon");filters.setCompoundDrawables(icon(a,R.drawable.ic_ui_filter,UiAppearance.secondary(a)),null,null,null);
        EditText search=a.findViewById(R.id.search);searchBox(search);
    }
    static void searchBox(EditText search){Context c=search.getContext();role(search,"search");search.setTextColor(UiAppearance.text(c));search.setHintTextColor(UiAppearance.secondary(c));search.setBackgroundTintList(null);search.setBackground(UiAppearance.rounded(c,UiAppearance.surface(c),16));search.setPadding(dp(c,16),dp(c,10),dp(c,12),dp(c,10));search.setCompoundDrawables(icon(c,R.drawable.ic_ui_search,UiAppearance.secondary(c)),null,null,null);search.setCompoundDrawablePadding(dp(c,12));search.setTextSize(15);}
    static void player(Activity a,boolean audio){
        View root=a.findViewById(R.id.playerRoot);root.setBackgroundColor(audio?0xff0d0f18:0xff000000);
        iconButton(a.findViewById(R.id.back),R.drawable.ic_ui_back,"Volver");iconButton(a.findViewById(R.id.subtitle),R.drawable.ic_ui_subtitle,"Añadir subtítulo");iconButton(a.findViewById(R.id.fullscreen),R.drawable.ic_ui_fullscreen,"Pantalla completa");iconButton(a.findViewById(R.id.playerFormats),R.drawable.ic_ui_info,"Pistas y compatibilidad");
        iconButton(a.findViewById(R.id.player_volume),R.drawable.ic_ui_volume,"Volumen");
        for(int id:new int[]{R.id.back,R.id.subtitle,R.id.fullscreen,R.id.playerFormats,R.id.player_volume})round((Button)a.findViewById(id),id==R.id.player_volume?0x59000000:0);
        TextView title=a.findViewById(R.id.playerTitle);role(title,"section");title.setTextSize(17);title.setTextColor(0xfff3f4f8);title.setShadowLayer(dp(a,6),0,0,0x99000000);
        role(a.findViewById(R.id.audioInfo),"muted");Button stop=a.findViewById(R.id.audioStop);role(stop,"quiet");
        View top=a.findViewById(R.id.player_top);if(top!=null)top.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0xb3000000,0x66000000,0x00000000}));
        TextView hint=a.findViewById(R.id.player_seek_hint);if(hint!=null){GradientDrawable bubble=new GradientDrawable();bubble.setShape(GradientDrawable.OVAL);bubble.setColor(0x80000000);hint.setBackground(bubble);hint.setTypeface(UiAppearance.title(a));}
        a.findViewById(R.id.fullscreen).setVisibility(View.GONE);
        View player=a.findViewById(R.id.player);if(player!=null)videoControls(player,UiAppearance.accent(a));
    }
    /** Botón de icono circular con respuesta al toque; {@code fill} permite un fondo translúcido sobre el video. */
    static void round(Button b,int fill){GradientDrawable dot=new GradientDrawable();dot.setShape(GradientDrawable.OVAL);dot.setColor(fill);GradientDrawable mask=new GradientDrawable();mask.setShape(GradientDrawable.OVAL);mask.setColor(0xff000000);
        b.setBackground(new RippleDrawable(android.content.res.ColorStateList.valueOf(0x40ffffff),dot,mask));}
    /** Controles Media3 del video: play grande con el color de acento y barra de progreso a juego. */
    @androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
    static void videoControls(View player,int accent){
        Context c=player.getContext();
        View play=player.findViewById(androidx.media3.ui.R.id.exo_play_pause);
        if(play instanceof android.widget.ImageButton button){GradientDrawable circle=new GradientDrawable();circle.setShape(GradientDrawable.OVAL);circle.setColor(accent);
            button.setBackground(new RippleDrawable(android.content.res.ColorStateList.valueOf(0x40000000),circle,null));button.setImageTintList(android.content.res.ColorStateList.valueOf(0xff15131a));button.setElevation(dp(c,6));}
        for(int id:new int[]{androidx.media3.ui.R.id.exo_prev,androidx.media3.ui.R.id.exo_next,androidx.media3.ui.R.id.exo_rew,androidx.media3.ui.R.id.exo_ffwd,androidx.media3.ui.R.id.exo_rew_with_amount,androidx.media3.ui.R.id.exo_ffwd_with_amount}){
            View v=player.findViewById(id);if(v!=null){GradientDrawable mask=new GradientDrawable();mask.setShape(GradientDrawable.OVAL);mask.setColor(0xff000000);v.setBackground(new RippleDrawable(android.content.res.ColorStateList.valueOf(0x40ffffff),null,mask));}}
        View bar=player.findViewById(androidx.media3.ui.R.id.exo_progress);
        if(bar instanceof androidx.media3.ui.DefaultTimeBar time){time.setPlayedColor(accent);time.setScrubberColor(accent);time.setBufferedColor(0x80ffffff);time.setUnplayedColor(0x33ffffff);}
    }
}
