package com.peach.local;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.util.*;

/** Searchable settings hub; original library tools remain owned by MainActivity. */
public final class SettingsActivity extends PeachActivity {
    private LinearLayout items;private final List<Item> all=new ArrayList<>();
    record Item(String group,String name,String summary,int icon,int tool,Class<?> screen){}
    @Override protected void onCreate(Bundle state){super.onCreate(state);
        LinearLayout root=PeachDesign.column(this);root.setId(R.id.settings_root);setContentView(root);PeachDesign.insets(this,root,20);
        LinearLayout head=PeachDesign.row(this);head.addView(PeachDesign.text(this,"Ajustes",30,"heading"),new LinearLayout.LayoutParams(0,PeachDesign.dp(this,78),1));head.addView(PeachDesign.iconButton(this,R.drawable.ic_ui_close,"Cerrar ajustes",v->finish()));root.addView(head);
        EditText search=new EditText(this);search.setId(R.id.settings_search);search.setHint("Buscar un ajuste o herramienta");search.setSingleLine();PeachDesign.searchBox(search);root.addView(search,new LinearLayout.LayoutParams(-1,PeachDesign.dp(this,52)));PeachDesign.gap(root,16);
        ScrollView scroll=new ScrollView(this);scroll.setClipToPadding(false);items=PeachDesign.column(this);scroll.addView(items);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));root.addView(PeachDesign.nav(this,3));
        add("Personalización","Apariencia","Tema, color, fondo, tarjetas y animaciones",R.drawable.ic_ui_image,0,AppearanceActivity.class);
        add("Tu contenido","Listas de reproducción","Crea, ordena y reproduce tus listas",R.drawable.ic_ui_list_add,8,null);
        add("Tu contenido","Lista de deseos","Obras que quieres encontrar",R.drawable.ic_ui_heart,13,null);
        add("Tu contenido","Historial de uso","Tus archivos abiertos recientemente",R.drawable.ic_ui_history,0,HistoryActivity.class);
        add("Tu contenido","Publicaciones guardadas","Lee lo que guardaste desde Fuentes",R.drawable.ic_ui_sources,15,null);
        add("Tu contenido","Estadísticas","Resumen de tu biblioteca",R.drawable.ic_ui_info,4,null);
        add("Biblioteca","Carpetas","Ubicaciones y permisos de tus archivos",R.drawable.ic_ui_folder,3,null);
        add("Biblioteca","Metadatos y grupos","Explora autores, etiquetas y colecciones",R.drawable.ic_ui_filter,10,null);
        add("Biblioteca","Identidades y alias","Relaciona nombres, creadores y obras",R.drawable.ic_ui_sources,12,null);
        add("Biblioteca","Versiones y partes","Relaciona versiones de una misma obra",R.drawable.ic_ui_file,17,null);
        add("Biblioteca","Organizar archivos y papelera","Mueve, renombra y recupera documentos",R.drawable.ic_ui_folder,0,FileOrganizationActivity.class);
        add("Biblioteca","Administrar lista actual","Cambia la lista seleccionada en Biblioteca",R.drawable.ic_ui_library,9,null);
        add("Biblioteca","Administrar grupo actual","Edita el grupo seleccionado en Biblioteca",R.drawable.ic_ui_library,11,null);
        add("Fuentes y descargas","Cuentas y sesiones","Acceso de tus cuentas por sitio",R.drawable.ic_ui_sources,0,AccountActivity.class);
        add("Fuentes y descargas","Descubrir enlaces y títulos F95","Opciones avanzadas de búsqueda",R.drawable.ic_ui_search,0,SourceDiscoveryActivity.class);
        add("Copias y almacenamiento","Guardar copia de progreso","Exporta el estado y la organización",R.drawable.ic_ui_download,5,null);
        add("Copias y almacenamiento","Restaurar copia de progreso","Recupera una copia que guardaste",R.drawable.ic_ui_refresh,6,null);
        add("Copias y almacenamiento","Importación y sincronización","Intercambio revisado entre bibliotecas",R.drawable.ic_ui_refresh,0,ExchangeActivity.class);
        add("Copias y almacenamiento","Catálogo de Peach original","Importación y compatibilidad del catálogo",R.drawable.ic_ui_library,0,CatalogActivity.class);
        add("Copias y almacenamiento","Almacenamiento y caché","Espacio ocupado y limpieza de copias temporales",R.drawable.ic_ui_folder,0,StorageActivity.class);
        add("Ayuda","Comprobar funcionamiento","Pruebas locales e informe de diagnóstico",R.drawable.ic_ui_info,0,DeviceCheckActivity.class);
        add("Ayuda","Acerca de Peach","Versión, licencias y compatibilidad",R.drawable.ic_ui_info,7,null);
        render("");search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int f){}public void onTextChanged(CharSequence s,int a,int b,int c){render(s.toString());}public void afterTextChanged(android.text.Editable e){}});
    }
    private void add(String group,String name,String summary,int icon,int tool,Class<?> screen){all.add(new Item(group,name,summary,icon,tool,screen));}
    private void render(String query){items.removeAllViews();String last="",q=query.trim().toLowerCase(Locale.ROOT);for(Item item:all){if(!q.isEmpty()&&!(item.group+" "+item.name+" "+item.summary).toLowerCase(Locale.ROOT).contains(q))continue;
            if(!last.equals(item.group)){TextView title=PeachDesign.text(this,item.group,14,"muted");title.setTypeface(UiAppearance.title(this));title.setPadding(PeachDesign.dp(this,4),PeachDesign.dp(this,22),0,PeachDesign.dp(this,10));items.addView(title);last=item.group;}
            LinearLayout row=PeachDesign.row(this);row.setPadding(PeachDesign.dp(this,12),PeachDesign.dp(this,10),PeachDesign.dp(this,10),PeachDesign.dp(this,10));
            row.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(UiAppearance.accentSoft(this,0x26)),UiAppearance.rounded(this,UiAppearance.surface(this),18),null));
            ImageView icon=new ImageView(this);icon.setImageDrawable(PeachDesign.icon(this,item.icon,UiAppearance.accent(this)));icon.setScaleType(ImageView.ScaleType.CENTER);icon.setBackground(UiAppearance.rounded(this,UiAppearance.accentSoft(this,0x24),12));
            row.addView(icon,new LinearLayout.LayoutParams(PeachDesign.dp(this,40),PeachDesign.dp(this,40)));LinearLayout labels=PeachDesign.column(this);labels.setPadding(PeachDesign.dp(this,14),0,PeachDesign.dp(this,8),0);TextView name=PeachDesign.text(this,item.name,16,"body");name.setTypeface(UiAppearance.title(this));labels.addView(name);TextView summary=PeachDesign.text(this,item.summary,12,"muted");summary.setPadding(0,PeachDesign.dp(this,4),0,0);labels.addView(summary);row.addView(labels,new LinearLayout.LayoutParams(0,-2,1));ImageView arrow=new ImageView(this);arrow.setImageDrawable(PeachDesign.icon(this,R.drawable.ic_ui_chevron,UiAppearance.secondary(this)));row.addView(arrow);
            row.setFocusable(true);row.setContentDescription(item.name+". "+item.summary);row.setOnClickListener(v->{if(item.screen!=null)startActivity(new Intent(this,item.screen));else startActivity(new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("libraryTool",item.tool));});items.addView(row,new LinearLayout.LayoutParams(-1,-2));PeachDesign.gap(items,6);
        }if(items.getChildCount()==0)items.addView(PeachDesign.text(this,"No hay ajustes con ese nombre.",16,"muted"));PeachDesign.gap(items,20);}
}
