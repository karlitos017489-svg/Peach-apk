package com.peach.local;

import android.app.Application;
import android.content.*;
import android.os.*;
import android.text.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.*;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.lifecycle.*;
import androidx.recyclerview.widget.*;
import java.util.*;
import org.json.*;

/** Consumer source explorer. A query, its results and a post share one native screen. */
public final class SourceBrowserActivity extends PeachActivity {
    public static final class Draft extends SourcesActivity.Draft {
        List<SourceBrowserItems.Item> items=List.of();List<F95Search.Hit> hits=List.of();
        String input="",localFilter="",provider="fanbox",openId="",actionId="",action="";int type,sort;boolean savedOnly,onlinePreviews,initialized,showHits,home=true,scrollTop,announce;
        /** Páginas ya vistas de la fuente actual (en memoria): volver atrás no consulta la red. */
        final Map<Integer,List<SourceBrowserItems.Item>> pages=new HashMap<>();String pagesFor="";long pagesChecked;
        /** Página que se está mirando; -1 = la última cargada de la fuente. */
        int viewing=-1;
        SourceBrowserItems.Item opened;Parcelable scroll;int detailScroll;
        public Draft(Application app){super(app);var p=app.getSharedPreferences("source-browser",0);selected=p.getString("selected","");provider=p.getString("provider","fanbox");if(!SourceProviders.KEYS.contains(provider))provider="fanbox";input=p.getString("input","");home=p.getBoolean("home",true);status="Busca por creador, etiqueta o enlace. Las portadas se cargan al consultar.";}
        interface Task{void run(Draft draft)throws Exception;}
        void run(Task task){super.work(d->task.run(this));}
        FollowSource current(){return sources.stream().filter(s->s.id.equals(selected)).findFirst().orElse(null);}
        @Override void load()throws Exception{super.load();
            // Si la fuente que tenías abierta ya no existe (por ejemplo, la eliminaste), se vuelve al inicio.
            if(!savedOnly&&!showHits&&openId.isEmpty()&&current()==null)home=true;
            remember(current());items=SourceBrowserItems.combine(current(),review,db.library().publications(),db.library().publicationContents(),savedOnly);
            opened=null;if(!openId.isEmpty()){opened=items.stream().filter(i->i.publication().id.equals(openId)).findFirst().orElse(null);if(opened==null){Publication p=db.library().publication(openId);if(p!=null)opened=new SourceBrowserItems.Item(p,db.library().publicationContent(openId),false,"Guardada");}}
        }
        void search(){String value=input.trim(),chosen=provider;if(value.isEmpty()){status="Escribe un nombre, una etiqueta o un enlace.";updates.setValue(1);return;}
            run(d->{d.home=false;d.openId="";d.hits=List.of();d.showHits=false;d.localFilter="";d.savedOnly=false;String p=chosen,ref;
                if(value.contains("https://")){SourceLink link=SourceLink.parse(value);p=link.provider();ref=link.ref();}
                else{
                    FollowSource known=sources.stream().filter(s->s.provider.equals(chosen)&&(s.label.equalsIgnoreCase(value)||s.ref.equalsIgnoreCase(value))).findFirst().orElse(null);
                    if(known!=null){p=known.provider;ref=known.ref;}
                    else if(chosen.equals("f95zone")&&!value.matches("[0-9]+")){d.showHits=true;d.hits=F95Search.search(value,SourceCredentials.local(getApplication()),SourceDiscoveryActivity.transport,token);d.status=d.hits.isEmpty()?"No se encontraron títulos con esa búsqueda.":"Elige un título para ver sus publicaciones aquí mismo.";return;}
                    else ref=SourceProviders.ref(p,value);
                }
                d.provider=p;d.selected=SourceProviders.key(p,ref);FollowSource existing=db.library().source(d.selected);if(existing==null)d.selected=store.create(p,ref,FanboxConnector.clipped(ref,80),null);d.onlinePreviews=true;store.fetch(d.selected,false,token);d.status="Resultados actualizados. Toca una portada para abrir su contenido.";
            });
        }
        void choose(String id,boolean fetchMissing){if(busy)return;run(d->{home=false;selected=id;openId="";hits=List.of();showHits=false;localFilter="";savedOnly=false;FollowSource s=db.library().source(id);if(s==null)return;provider=s.provider;input=s.label;status="Contenido de "+s.label;if(fetchMissing&&s.checkedAt==0&&!s.paused){onlinePreviews=true;store.fetch(id,false,token);}});}
        /** Guarda la página recién cargada y cuántas publicaciones trae, para numerar 1, 2, 3… desde la más reciente. */
        void remember(FollowSource s){
            if(s==null){pages.clear();pagesFor="";viewing=-1;return;}
            if(!s.id.equals(pagesFor)){pages.clear();pagesFor=s.id;viewing=-1;pagesChecked=s.checkedAt;}
            if(s.checkedAt!=pagesChecked){pagesChecked=s.checkedAt;viewing=-1;
                // Al actualizar desde la página 1 pueden aparecer publicaciones nuevas: las posiciones cambian y se reinicia el conteo.
                if(s.cachePage==0){pages.clear();ledger().edit().putString(s.id,"{}").apply();}}
            List<SourceBrowserItems.Item> live=new ArrayList<>();if(review!=null)for(var row:review.rows())live.add(new SourceBrowserItems.Item(row.publication(),row.content(),true,row.state()));
            if(s.checkedAt>0&&!live.isEmpty()){pages.put(s.cachePage,List.copyOf(live));
                try{JSONObject counts=new JSONObject(ledger().getString(s.id,"{}"));counts.put(String.valueOf(s.cachePage),live.size());ledger().edit().putString(s.id,counts.toString()).apply();}catch(JSONException ignored){/* Solo se pierde la numeración global. */}}
        }
        SharedPreferences ledger(){return getApplication().getSharedPreferences("source-pages",0);}
        /** Posición (desde 0) de la primera publicación de la página; -1 si falta conocer alguna página anterior. */
        int start(String id,int page){try{JSONObject counts=new JSONObject(ledger().getString(id,"{}"));int sum=0;for(int i=0;i<page;i++){if(!counts.has(String.valueOf(i)))return -1;sum+=counts.getInt(String.valueOf(i));}return sum;}catch(JSONException e){return -1;}}
        String saveOpened()throws Exception{if(opened==null)throw new java.io.IOException("Vuelve a abrir la publicación.");String id=opened.publication().id;if(opened.pending()){if(review==null)throw new java.io.IOException("Vuelve a consultar esta página.");return store.applyOne(review,id);}return id;}
        void remember(){getApplication().getSharedPreferences("source-browser",0).edit().putString("selected",selected).putString("provider",provider).putString("input",input).putBoolean("home",home).apply();}
    }
    private Draft draft;private LinearLayout root,shell,homeHeader,resultsHeader,tabs,detail;
    private FrameLayout body;private RecyclerView grid;private Cards cards;
    private EditText query;private Button provider,refresh,older,newer,cancel;private LinearLayout pager;private TextView pageLabel;private TextView status,title,count,example;
    private SourcePreviewLoader previews;private boolean rendering,started;
    private final ActivityResultLauncher<Intent> save=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),result->{draft.savePickerOpen=false;if(result.getResultCode()==RESULT_OK&&result.getData()!=null&&SourceFiles.local(result.getData().getData())){draft.pendingSaveUri=result.getData().getData().toString();offerPrepared();}else{draft.clearPrepared();draft.status="Guardado cancelado.";render();}});
    @Override public void onCreate(Bundle state){super.onCreate(state);draft=new ViewModelProvider(this).get(Draft.class);previews=new SourcePreviewLoader(this);
        if(!draft.initialized){draft.initialized=true;if(state!=null){draft.input=state.getString("input",draft.input);draft.selected=state.getString("selected",draft.selected);draft.openId=state.getString("openPublication","");draft.savedOnly=state.getBoolean("savedOnly",false);draft.localFilter=state.getString("localFilter","");draft.type=state.getInt("type",0);draft.sort=state.getInt("sort",0);draft.provider=state.getString("provider",draft.provider);draft.home=state.getBoolean("home",draft.home);}
            if(state==null){draft.savedOnly=getIntent().getBooleanExtra("savedOnly",false);if(draft.savedOnly)draft.home=false;}String id=getIntent().getStringExtra("publicationId");if(id!=null&&SourceVideos.id(id)){draft.openId=id;draft.home=false;}}
        root=PeachDesign.column(this);setContentView(root);PeachDesign.insets(this,root,18);shell=PeachDesign.column(this);root.addView(shell);

        // 1) Inicio: un solo buscador claro. El sitio elegido se ve siempre y se cambia con un toque.
        homeHeader=PeachDesign.column(this);shell.addView(homeHeader);
        LinearLayout head=PeachDesign.row(this);head.addView(PeachDesign.text(this,"Fuentes",30,"heading"),new LinearLayout.LayoutParams(0,dp(72),1));
        Button tools=PeachDesign.iconButton(this,R.drawable.ic_ui_more,"Más opciones de fuentes",this::tools);tools.setId(R.id.browser_settings);head.addView(tools);homeHeader.addView(head);
        LinearLayout card=PeachDesign.column(this);card.setPadding(dp(16),dp(14),dp(16),dp(16));card.setBackground(UiAppearance.rounded(this,UiAppearance.surface(this),24));
        TextView ask=PeachDesign.text(this,"¿Qué quieres encontrar?",18,"body");ask.setTypeface(UiAppearance.title(this));card.addView(ask);
        LinearLayout where=PeachDesign.row(this);where.setPadding(0,dp(10),0,dp(10));where.addView(PeachDesign.text(this,"Buscar en",14,"muted"));
        provider=new Button(this);provider.setId(R.id.browser_provider);provider.setOnClickListener(v->pickSite());
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-2,dp(40));pp.leftMargin=dp(10);where.addView(provider,pp);card.addView(where);
        LinearLayout search=PeachDesign.row(this);
        query=new EditText(this);query.setId(R.id.browser_search);query.setSingleLine(true);query.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8192)});query.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);PeachDesign.searchBox(query);query.setBackground(UiAppearance.rounded(this,UiAppearance.surfaceHigh(this),16));query.setText(draft.input);
        search.addView(query,new LinearLayout.LayoutParams(0,dp(54),1));
        // En pantallas angostas el botón es solo la lupa, para dejar sitio a lo que escribes.
        boolean narrow=getResources().getConfiguration().screenWidthDp<480;
        Button go=PeachDesign.action(this,narrow?"":"Buscar","primary",v->search());go.setId(R.id.browser_go);go.setContentDescription("Buscar en la fuente");
        if(narrow){var lens=PeachDesign.icon(this,R.drawable.ic_ui_search,UiAppearance.onAccent(this));go.setCompoundDrawables(lens,null,null,null);go.setPadding(dp(16),0,0,0);}
        else{var lens=PeachDesign.icon(this,R.drawable.ic_ui_search,UiAppearance.onAccent(this));go.setCompoundDrawables(lens,null,null,null);go.setCompoundDrawablePadding(dp(8));go.setPadding(dp(18),0,dp(20),0);}
        LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(narrow?dp(54):-2,dp(54));gp.leftMargin=dp(10);search.addView(go,gp);card.addView(search);
        example=PeachDesign.text(this,"",13,"muted");example.setPadding(dp(4),dp(10),0,0);card.addView(example);
        homeHeader.addView(card);
        query.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int f){}public void afterTextChanged(Editable e){}public void onTextChanged(CharSequence s,int a,int b,int c){if(!rendering)draft.input=s.toString();}});
        query.setOnEditorActionListener((v,action,event)->{if(action==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH){search();return true;}return false;});

        // 2) Resultados: siempre se ve de qué fuente y de qué sitio vienen, con pestañas por tipo.
        resultsHeader=PeachDesign.column(this);shell.addView(resultsHeader);
        LinearLayout bar=PeachDesign.row(this);
        Button back=PeachDesign.iconButton(this,R.drawable.ic_ui_back,"Volver a Fuentes",v->goHome());back.setId(R.id.browser_home);bar.addView(back);
        LinearLayout names=PeachDesign.column(this);names.setPadding(dp(6),0,dp(6),0);
        title=PeachDesign.text(this,"",22,"body");title.setId(R.id.browser_title);title.setTypeface(UiAppearance.display(this));title.setMaxLines(1);title.setEllipsize(TextUtils.TruncateAt.END);names.addView(title);
        count=PeachDesign.text(this,"",13,"muted");count.setMaxLines(1);count.setEllipsize(TextUtils.TruncateAt.END);names.addView(count);
        bar.addView(names,new LinearLayout.LayoutParams(0,-2,1));
        refresh=PeachDesign.iconButton(this,R.drawable.ic_ui_refresh,"Actualizar esta fuente",v->fetch(false));refresh.setId(R.id.browser_refresh);bar.addView(refresh);
        Button more=PeachDesign.iconButton(this,R.drawable.ic_ui_more,"Opciones de esta fuente",this::sourceMenu);more.setId(R.id.browser_filter);bar.addView(more);
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(68));resultsHeader.addView(bar,bp);
        HorizontalScrollView tabScroll=new HorizontalScrollView(this);tabScroll.setHorizontalScrollBarEnabled(false);tabs=PeachDesign.row(this);tabs.setId(R.id.browser_mode);tabScroll.addView(tabs);
        String[] kinds={"Todo","Imágenes","Videos","Texto"};
        for(int k=0;k<kinds.length;k++){final int type=k;Button tab=PeachDesign.chip(this,kinds[k],false,v->{PeachDesign.pop(v);draft.type=type;render();});LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-2,dp(40));tp.setMarginEnd(dp(8));tabs.addView(tab,tp);}
        LinearLayout.LayoutParams tsp=new LinearLayout.LayoutParams(-1,-2);tsp.topMargin=dp(4);tsp.bottomMargin=dp(6);resultsHeader.addView(tabScroll,tsp);

        status=PeachDesign.text(this,"",13,"muted");status.setId(R.id.browser_status);status.setMaxLines(3);status.setEllipsize(TextUtils.TruncateAt.END);status.setPadding(dp(4),dp(10),0,dp(6));shell.addView(status);
        cancel=PeachDesign.action(this,"Cancelar búsqueda","secondary",v->{draft.token.cancel();draft.status="Cancelando…";render();});shell.addView(cancel,new LinearLayout.LayoutParams(-2,dp(44)));

        body=new FrameLayout(this);root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        grid=new RecyclerView(this);grid.setId(R.id.browser_grid);
        int columns=Math.max(1,(getResources().getConfiguration().screenWidthDp-36)/190);GridLayoutManager layout=new GridLayoutManager(this,columns);
        layout.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup(){@Override public int getSpanSize(int position){return cards.full(position)?columns:1;}});
        grid.setLayoutManager(layout);grid.setClipToPadding(false);grid.setPadding(0,dp(6),0,dp(12));cards=new Cards();grid.setAdapter(cards);if(!UiAppearance.motion(this))grid.setItemAnimator(null);
        body.addView(grid,new FrameLayout.LayoutParams(-1,-1));
        detail=PeachDesign.column(this);detail.setId(R.id.browser_detail);detail.setVisibility(View.GONE);body.addView(detail,new FrameLayout.LayoutParams(-1,-1));
        // Paginador: siempre se ve en qué página estás y qué publicaciones (#41–60) estás viendo.
        pager=PeachDesign.row(this);pager.setId(R.id.browser_pager);pager.setPadding(dp(6),dp(4),dp(6),dp(4));pager.setBackground(UiAppearance.rounded(this,UiAppearance.surface(this),24));
        newer=PeachDesign.action(this,"‹  Anterior","secondary",v->turn(-1));newer.setId(R.id.browser_newer);pager.addView(newer,new LinearLayout.LayoutParams(dp(132),dp(44)));
        pageLabel=PeachDesign.text(this,"",14,"body");pageLabel.setId(R.id.browser_page);pageLabel.setGravity(Gravity.CENTER);pageLabel.setTypeface(UiAppearance.title(this));pageLabel.setMaxLines(2);pager.addView(pageLabel,new LinearLayout.LayoutParams(0,-2,1));
        older=PeachDesign.action(this,"Siguiente  ›","secondary",v->turn(1));older.setId(R.id.browser_older);pager.addView(older,new LinearLayout.LayoutParams(dp(132),dp(44)));
        LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(-1,-2);op.topMargin=dp(6);root.addView(pager,op);
        root.addView(PeachDesign.nav(this,1));
        getOnBackPressedDispatcher().addCallback(this,new OnBackPressedCallback(true){@Override public void handleOnBackPressed(){if(!draft.openId.isEmpty())closePost();else if(!draft.home)goHome();else finish();}});
        draft.updates.observe(this,n->{render();offerPrepared();launchPending();});if(!draft.busy)draft.run(d->{});
    }
    int dp(int n){return PeachDesign.dp(this,n);}
    /** Color propio de cada sitio: aparece igual en el buscador, en tus fuentes y en los resultados. */
    static int siteColor(String key){return switch(key==null?"":key){case "fanbox"->0xfff2b33d;case "patreon"->0xfff96854;case "subscribestar"->0xffe8c547;case "pawchive"->0xff7c9cff;case "cumst"->0xffc27cff;case "rule34paheal"->0xff5fcf8f;case "rule34xxx"->0xff4fc3f7;case "rule34video"->0xffff8a65;case "f95zone"->0xffef6f6f;default->0xff9aa3b5;};}
    /** Etiqueta del sitio: pastilla con su color y su nombre. */
    TextView badge(String key){TextView t=new TextView(this);t.setText(SourceBrowserItems.name(key));t.setTextSize(12);t.setTypeface(UiAppearance.title(this));int c=siteColor(key);
        t.setTextColor(UiAppearance.dark(this)?c:darker(c));t.setBackground(UiAppearance.rounded(this,(c&0x00ffffff)|0x2e000000,10));t.setPadding(dp(10),dp(3),dp(10),dp(3));t.setSingleLine(true);return t;}
    static int darker(int c){return 0xff000000|(int)(((c>>16)&255)*.62)<<16|(int)(((c>>8)&255)*.62)<<8|(int)((c&255)*.62);}
    /** Qué escribir en cada sitio, en palabras sencillas. */
    String hintFor(String key){return switch(key){case "rule34paheal","rule34xxx"->"Escribe una etiqueta (por ejemplo, el nombre de un personaje) o pega un enlace.";case "f95zone"->"Escribe el título del juego o pega el enlace del hilo.";case "pawchive","cumst"->"Pega el enlace del creador (o escribe servicio/ID).";case "rule34video"->"Escribe el nombre del autor o pega el enlace de su página.";default->"Escribe el nombre del creador o pega el enlace de su página.";};}
    void hint(){query.setHint(switch(draft.provider){case "rule34paheal","rule34xxx"->"Etiqueta o enlace";case "f95zone"->"Título o enlace del hilo";case "pawchive","cumst"->"Enlace del creador";default->"Nombre del creador o enlace";});example.setText(hintFor(draft.provider));
        provider.setText(SourceBrowserItems.name(draft.provider)+"  ▾");provider.setAllCaps(false);provider.setTextSize(14);provider.setTypeface(UiAppearance.title(this));int c=siteColor(draft.provider);provider.setTextColor(UiAppearance.dark(this)?c:darker(c));
        provider.setMinWidth(0);provider.setMinimumWidth(0);provider.setMinHeight(0);provider.setMinimumHeight(0);provider.setPadding(dp(14),0,dp(14),0);provider.setStateListAnimator(null);provider.setBackgroundTintList(null);
        provider.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf((c&0x00ffffff)|0x40000000),UiAppearance.rounded(this,(c&0x00ffffff)|0x2e000000,20),null));
        provider.setContentDescription("Sitio donde buscar: "+SourceBrowserItems.name(draft.provider)+". Toca para cambiarlo.");}
    /** Lista clara de sitios: nombre, color y qué escribir en cada uno. */
    void pickSite(){if(draft.busy)return;
        LinearLayout list=PeachDesign.column(this);list.setPadding(dp(12),dp(4),dp(12),dp(8));ScrollView scroll=new ScrollView(this);scroll.addView(list);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("¿Dónde quieres buscar?").setView(scroll).setNegativeButton("Cerrar",null).create();
        for(String key:SourceProviders.KEYS){LinearLayout row=PeachDesign.row(this);row.setPadding(dp(12),dp(12),dp(12),dp(12));boolean on=key.equals(draft.provider);
            row.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(UiAppearance.accentSoft(this,0x26)),UiAppearance.rounded(this,on?UiAppearance.accentSoft(this,0x22):0,16),null));
            View dot=new View(this);android.graphics.drawable.GradientDrawable circle=new android.graphics.drawable.GradientDrawable();circle.setShape(android.graphics.drawable.GradientDrawable.OVAL);circle.setColor(siteColor(key));dot.setBackground(circle);row.addView(dot,new LinearLayout.LayoutParams(dp(14),dp(14)));
            LinearLayout text=PeachDesign.column(this);text.setPadding(dp(14),0,0,0);TextView name=PeachDesign.text(this,SourceBrowserItems.name(key),16,"body");name.setTypeface(UiAppearance.title(this));text.addView(name);
            TextView help=PeachDesign.text(this,hintFor(key),13,"muted");text.addView(help);row.addView(text,new LinearLayout.LayoutParams(0,-2,1));
            if(on){ImageView check=new ImageView(this);check.setImageDrawable(PeachDesign.icon(this,R.drawable.ic_ui_check,UiAppearance.accent(this)));row.addView(check);}
            row.setOnClickListener(v->{draft.provider=key;hint();dialog.dismiss();query.requestFocus();});row.setContentDescription(SourceBrowserItems.name(key)+". "+hintFor(key));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(4);list.addView(row,rp);}
        dialog.show();
    }
    void goHome(){if(draft.busy)draft.token.cancel();previews.reset();draft.home=true;draft.savedOnly=false;draft.hits=List.of();draft.showHits=false;draft.localFilter="";draft.type=0;render();if(grid!=null)grid.scrollToPosition(0);}
    void search(){if(draft.busy)return;((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(query.getWindowToken(),0);query.clearFocus();previews.reset();draft.type=0;draft.search();}
    /** Página que se ve ahora (0 = la más reciente). */
    int shownPage(){FollowSource s=draft.current();return s==null?0:draft.viewing>=0?draft.viewing:s.cachePage;}
    /**
     * Anterior/Siguiente: las páginas ya vistas se muestran al instante desde memoria. Siguiente solo consulta
     * la fuente al llegar a una página nueva; Anterior hasta la página 1 vuelve a consultar novedades si hace falta.
     */
    void turn(int step){FollowSource s=draft.current();if(s==null||draft.busy)return;int target=shownPage()+step;if(target<0)return;
        if(draft.pages.containsKey(target)){draft.viewing=target==s.cachePage?-1:target;draft.scrollTop=true;draft.status=pageText(s,target);render();return;}
        if(step>0&&shownPage()==s.cachePage){fetch(true);return;}
        if(step<0&&target==0){fetch(false);return;}
    }
    /** "Página 3 · publicaciones 41–60" (o la cantidad, si aún no se conoce la posición exacta). */
    String pageText(FollowSource s,int page){List<SourceBrowserItems.Item> list=draft.pages.get(page);int n=list==null?0:list.size(),start=draft.start(s.id,page);
        return "Página "+(page+1)+(n==0?"":start>=0?" · publicaciones "+(start+1)+"–"+(start+n):" · "+n+" publicaciones");}
    void fetch(boolean previous){if(draft.busy||draft.current()==null||draft.savedOnly)return;draft.scrollTop=true;previews.reset();String id=draft.selected;draft.run(d->{d.hits=List.of();d.showHits=false;d.openId="";d.onlinePreviews=true;d.store.fetch(id,previous,d.token);d.viewing=-1;d.status="Contenido actualizado.";d.announce=true;});}
    void filters(){LinearLayout form=PeachDesign.column(this);form.setPadding(dp(20),dp(8),dp(20),dp(12));EditText text=new EditText(this);text.setHint("Buscar en estos resultados");text.setSingleLine(true);text.setText(draft.localFilter);form.addView(text);
        Spinner order=new Spinner(this);order.setId(R.id.browser_order);order.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Más recientes primero","Más antiguos primero","Título A–Z"}));order.setSelection(draft.sort);form.addView(order);
        new AlertDialog.Builder(this).setTitle("Buscar y ordenar").setView(form).setPositiveButton("Aplicar",(d,w)->{draft.localFilter=text.getText().toString();draft.sort=order.getSelectedItemPosition();render();}).setNeutralButton("Quitar",(d,w)->{draft.localFilter="";draft.sort=0;render();}).setNegativeButton("Cerrar",null).show();}
    void render(){if(isDestroyed()||grid==null)return;rendering=true;FollowSource current=draft.current();boolean opened=!draft.openId.isEmpty(),home=draft.home&&!opened;
        shell.setVisibility(opened?View.GONE:View.VISIBLE);detail.setVisibility(opened?View.VISIBLE:View.GONE);grid.setVisibility(opened?View.GONE:View.VISIBLE);
        homeHeader.setVisibility(home?View.VISIBLE:View.GONE);resultsHeader.setVisibility(home?View.GONE:View.VISIBLE);
        query.setEnabled(!draft.busy);provider.setEnabled(!draft.busy);if(!query.hasFocus()&&!query.getText().toString().equals(draft.input))query.setText(draft.input);hint();
        refresh.setVisibility(draft.savedOnly||draft.showHits||current==null?View.GONE:View.VISIBLE);refresh.setEnabled(!draft.busy&&current!=null&&!current.paused);refresh.setAlpha(refresh.isEnabled()?1f:.35f);
        cancel.setVisibility(draft.busy?View.VISIBLE:View.GONE);
        for(int i=0;i<tabs.getChildCount();i++){Button tab=(Button)tabs.getChildAt(i);if(tab.isSelected()!=(i==draft.type))PeachDesign.chipState(tab,i==draft.type);}
        ((View)tabs.getParent()).setVisibility(draft.showHits?View.GONE:View.VISIBLE);
        // Página que se ve: la última cargada o una ya vista (desde memoria). Cada publicación lleva su número desde la más reciente.
        boolean paged=!home&&!draft.savedOnly&&!draft.showHits&&current!=null;int page=paged?shownPage():0;
        List<SourceBrowserItems.Item> base=paged&&draft.viewing>=0&&draft.pages.containsKey(draft.viewing)?draft.pages.get(draft.viewing):draft.items;
        Map<String,Integer> numbers=new HashMap<>();
        if(paged&&draft.pages.containsKey(page)){List<SourceBrowserItems.Item> rows=draft.pages.get(page);int start=draft.start(current.id,page);for(int n=0;n<rows.size();n++)numbers.put(rows.get(n).publication().id,start>=0?start+n+1:-(n+1));}
        if(paged&&draft.announce){draft.announce=false;draft.status=pageText(current,page);}
        List<SourceBrowserItems.Item> selected=SourceBrowserItems.select(base,draft.localFilter,draft.type,draft.sort);
        title.setText(draft.savedOnly?"Guardadas":draft.showHits?"Títulos en F95zone":current==null?"Resultados":current.label);
        count.setText(draft.savedOnly?selected.size()+" publicaciones de todas tus fuentes":draft.showHits?draft.hits.size()+" títulos · elige uno para ver sus publicaciones":current==null?"":SourceBrowserItems.name(current.provider)+" · "+selected.size()+(selected.size()==1?" resultado":" resultados")+" · página "+(page+1)+(draft.localFilter.isEmpty()?"":" · filtrado"));
        if(current!=null&&!draft.savedOnly&&!draft.showHits)count.setTextColor(UiAppearance.dark(this)?siteColor(current.provider):darker(siteColor(current.provider)));else count.setTextColor(UiAppearance.secondary(this));
        String message=draft.busy?"Buscando… puedes cancelar sin perder lo guardado.":draft.status;// En el inicio solo se muestran avisos útiles (errores, "escribe algo") o el progreso; no mensajes de una fuente.
        boolean quietHome=home&&!draft.busy&&(message.startsWith("Busca por creador")||message.startsWith("Resultados actualizados")||message.startsWith("Contenido")||message.startsWith("Se añadieron")||message.startsWith("Publicación"));
        status.setText(message);status.setVisibility(!quietHome&&(draft.busy||!message.isEmpty())?View.VISIBLE:View.GONE);
        boolean hasOlder=!home&&!draft.savedOnly&&!draft.showHits&&current!=null&&SourceProviders.history(current.provider)&&current.checkedAt>0&&!current.paused&&(!SourceProviders.manifested(current.provider)||!current.pageUrls.equals("[]"));
        boolean canNewer=paged&&page>0&&(draft.pages.containsKey(page-1)||page-1==0),canOlder=paged&&(draft.pages.containsKey(page+1)||page==current.cachePage&&hasOlder);
        pager.setVisibility(!opened&&paged&&(canNewer||canOlder||page>0)?View.VISIBLE:View.GONE);pageLabel.setText(paged?pageText(current,page):"");
        newer.setEnabled(!draft.busy&&canNewer);newer.setAlpha(newer.isEnabled()?1f:.4f);older.setEnabled(!draft.busy&&canOlder);older.setAlpha(older.isEnabled()?1f:.4f);
        older.setContentDescription(draft.pages.containsKey(page+1)?"Ver la página "+(page+2):"Cargar la página "+(page+2));newer.setContentDescription("Ver la página "+page);
        if(home)cards.home(draft.sources);else cards.update(draft.showHits?List.of():selected,draft.hits,numbers);
        if(draft.scrollTop&&!draft.busy){draft.scrollTop=false;draft.scroll=null;grid.scrollToPosition(0);}
        if(draft.scroll!=null&&!opened){grid.getLayoutManager().onRestoreInstanceState(draft.scroll);draft.scroll=null;}if(opened)renderPost();draft.remember();rendering=false;
    }
    void openPost(SourceBrowserItems.Item item){if(draft.busy)return;draft.scroll=grid.getLayoutManager().onSaveInstanceState();draft.openId=item.publication().id;draft.detailScroll=0;draft.opened=item;draft.onlinePreviews=true;render();
        if(item.pending()&&item.content()!=null&&SourceProviders.summary(item.content().type)&&SourceProviders.detail(item.publication().provider)){String source=draft.selected,external=item.publication().externalId;draft.run(d->{d.store.detail(source,external,d.token);d.status="Publicación abierta.";});}
    }
    void closePost(){draft.token.cancel();draft.openId="";draft.opened=null;draft.detailScroll=0;render();}
    void renderPost(){int restoredScroll=draft.detailScroll;detail.removeAllViews();LinearLayout bar=PeachDesign.row(this);Button back=PeachDesign.iconButton(this,R.drawable.ic_ui_back,"Volver a los resultados",v->closePost());back.setId(R.id.browser_back);bar.addView(back);LinearLayout labelBox=PeachDesign.row(this);labelBox.setPadding(dp(6),0,0,0);if(draft.opened!=null)labelBox.addView(badge(draft.opened.publication().provider));bar.addView(labelBox,new LinearLayout.LayoutParams(0,dp(56),1));if(draft.busy)bar.addView(PeachDesign.action(this,"Cancelar","quiet",v->draft.token.cancel()));else bar.addView(PeachDesign.iconButton(this,R.drawable.ic_ui_more,"Opciones de publicación",this::postTools));detail.addView(bar);
        if(draft.opened==null){detail.addView(PeachDesign.text(this,draft.busy?"Abriendo contenido…":"No se encontró esa publicación.",16,"muted"));return;}
        var item=draft.opened;Publication p=item.publication();PublicationContent c=item.content();ScrollView scroll=new ScrollView(this);LinearLayout content=PeachDesign.column(this);content.setPadding(dp(4),0,dp(4),dp(18));scroll.addView(content);detail.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));scroll.setOnScrollChangeListener((View.OnScrollChangeListener)(v,x,y,oldx,oldy)->draft.detailScroll=y);
        TextView heading=PeachDesign.text(this,p.title,24,"body");heading.setTypeface(UiAppearance.display(this));heading.setTextIsSelectable(true);heading.setPadding(0,dp(12),0,dp(8));content.addView(heading);content.addView(PeachDesign.text(this,p.sourceLabel+(p.publishedAt==null||p.publishedAt.isEmpty()?"":" · "+p.publishedAt.substring(0,Math.min(10,p.publishedAt.length()))),13,"muted"));PeachDesign.gap(content,16);
        if(c==null){content.addView(PeachDesign.text(this,"Aún no hay contenido guardado. Vuelve a la fuente y actualízala para consultar esta publicación.",16,"muted"));return;}
        if(SourcePreviewLoader.image(p,c)!=null){ImageView hero=new ImageView(this);hero.setId(R.id.browser_image);hero.setScaleType(ImageView.ScaleType.CENTER_CROP);hero.setBackground(UiAppearance.rounded(this,UiAppearance.surface(this),18));hero.setClipToOutline(true);content.addView(hero,new LinearLayout.LayoutParams(-1,dp(Math.min(300,getResources().getConfiguration().screenHeightDp/3))));hero.setContentDescription("Vista previa de "+p.title);previews.bind(hero,p,c,draft.onlinePreviews);hero.setOnClickListener(v->media(false));PeachDesign.gap(content,12);}
        LinearLayout media=PeachDesign.row(this);boolean images=false,videos=false;try{images=!SourceGallery.select(p,c).images().isEmpty();videos=!SourceVideos.select(p,c).videos().isEmpty();}catch(Exception ignored){}
        if(videos){Button play=PeachDesign.action(this,"Reproducir","primary",v->media(true));play.setId(R.id.browser_online);play.setEnabled(!draft.busy);media.addView(play,new LinearLayout.LayoutParams(0,dp(50),1));}if(images){Button image=PeachDesign.action(this,"Ver imágenes","quiet",v->media(false));image.setEnabled(!draft.busy);media.addView(image,new LinearLayout.LayoutParams(0,dp(50),1));}if(media.getChildCount()>0){content.addView(media);PeachDesign.gap(content,12);}
        if(draft.busy)content.addView(PeachDesign.text(this,"Cargando el contenido de esta publicación…",13,"muted"));else if(!draft.status.isBlank()&&!draft.status.equals("Publicación abierta."))content.addView(PeachDesign.text(this,draft.status,13,"muted"));else if(c.partial)content.addView(PeachDesign.text(this,"Vista disponible de la fuente · Puede contener solo un adelanto",12,"muted"));
        TextView text=PeachDesign.text(this,c.text.isBlank()?"Sin texto en esta publicación.":c.text,16,"body");text.setTextIsSelectable(true);text.setLineSpacing(dp(4),1);text.setPadding(0,dp(14),0,dp(18));content.addView(text);
        try{JSONArray files=new JSONArray(c.attachments);if(files.length()>0)content.addView(PeachDesign.text(this,"Archivos de la publicación",20,"section"));for(int n=0;n<files.length();n++){JSONObject a=files.getJSONObject(n);LinearLayout row=PeachDesign.row(this);TextView name=PeachDesign.text(this,a.getString("name"),14,"body");name.setMaxLines(2);name.setEllipsize(TextUtils.TruncateAt.END);name.setPadding(0,dp(10),dp(10),dp(10));row.addView(name,new LinearLayout.LayoutParams(0,-2,1));Button download=PeachDesign.iconButton(this,R.drawable.ic_ui_download,"Guardar "+a.getString("name"),v->saveAttachment(a));download.setEnabled(!draft.busy);row.addView(download);content.addView(row);}}catch(JSONException ignored){}
        int y=restoredScroll;scroll.post(()->scroll.scrollTo(0,y));
    }
    void media(boolean video){if(draft.busy)return;draft.run(d->{String id=d.saveOpened();d.actionId=id;d.action=video?"video":"images";});}
    void launchPending(){if(draft.busy||!started||draft.action.isEmpty())return;String action=draft.action,id=draft.actionId;draft.action="";draft.actionId="";
        if(action.equals("organize")){startActivity(new Intent(this,OrganizationActivity.class).putExtra("section",8).putExtra("focusPublication",id));return;}
        if(action.equals("versions")){startActivity(new Intent(this,SourceVideoActivity.class).putExtra("publicationId",id));return;}
        if(action.equals("queue")){startActivity(new Intent(this,DownloadQueueActivity.class).putExtra("publicationId",id));return;}
        if(action.equals("links")){new AlertDialog.Builder(this).setTitle("Enlaces de la publicación").setItems(new String[]{"Pixeldrain","Gofile","Enlaces F95"},(d,n)->startActivity(new Intent(this,n==0?PixeldrainActivity.class:n==1?ExternalLinksActivity.class:F95LinksActivity.class).putExtra("publicationId",id))).setNegativeButton("Cerrar",null).show();return;}
        if(action.equals("images")){startActivity(new Intent(this,SourceGalleryActivity.class).putExtra("publicationId",id));return;}
        if(action.equals("video")){try{var selection=SourceVideos.select(draft.opened.publication(),draft.opened.content());var video=selection.videos().get(VideoVariants.best(selection.videos()));if(getSharedPreferences("source-video",0).getBoolean("offline",false))startActivity(new Intent(this,SourceVideoActivity.class).putExtra("publicationId",id));else startActivity(SourceVideoStream.intent(this,id,VideoCache.keyFor(video.url())));}catch(Exception e){Toast.makeText(this,"No hay un video compatible. Revisa las opciones de la publicación.",Toast.LENGTH_LONG).show();}}
    }
    void saveAttachment(JSONObject a){try{String url=a.getString("url");if(!SourceHttp.canSave(url,a.getBoolean("downloadable"))){Toast.makeText(this,"Este enlace se conserva como referencia; no admite guardado directo.",Toast.LENGTH_LONG).show();return;}String name=SourceFiles.name(a.getString("name"),url),kind=a.optString("kind","file"),hash=PixeldrainUrls.expected(a);new AlertDialog.Builder(this).setTitle("Guardar archivo").setItems(new String[]{"Directo a nube o carpeta","Preparar copia y elegir destino"},(dialog,which)->{if(which==0)startActivity(DirectSaveActivity.intent(this,url,name,hash));else draft.run(d->d.prepare(url,name,kind,hash));}).setNegativeButton("Cerrar",null).show();}catch(Exception e){Toast.makeText(this,"Archivo no válido.",Toast.LENGTH_SHORT).show();}}
    void offerPrepared(){if(draft.busy||isFinishing()||isDestroyed())return;if(!draft.pendingSaveUri.isEmpty()){var uri=android.net.Uri.parse(draft.pendingSaveUri);draft.pendingSaveUri="";draft.run(d->d.savePrepared(uri));return;}if(draft.prepared!=null&&!draft.savePickerOpen){draft.savePickerOpen=true;try{save.launch(SourceFiles.create(draft.preparedName));}catch(Exception e){draft.clearPrepared();draft.status="No se pudo abrir el destino.";render();}}}
    void postTools(View anchor){if(draft.opened==null)return;PopupMenu menu=new PopupMenu(this,anchor);menu.getMenu().add(0,1,0,"Guardar publicación");menu.getMenu().add(0,2,1,"Versiones y reproducción sin conexión");menu.getMenu().add(0,3,2,"Añadir archivos a descargas");menu.getMenu().add(0,4,3,"Enlaces de la publicación");menu.getMenu().add(0,5,4,"Ver datos de la publicación");menu.getMenu().add(0,6,5,"Organizar, notas y estado");menu.setOnMenuItemClickListener(mi->{var p=draft.opened.publication();if(mi.getItemId()==1)draft.run(d->{d.saveOpened();d.status="Publicación guardada.";});else if(mi.getItemId()==5)new AlertDialog.Builder(this).setTitle("Datos").setMessage(SourceBrowserItems.name(p.provider)+"\n"+p.sourceRef+"\n"+p.url+"\n"+draft.opened.state()).setPositiveButton("Cerrar",null).show();else{int choice=mi.getItemId();draft.run(d->{d.actionId=d.saveOpened();d.action=choice==2?"versions":choice==3?"queue":choice==6?"organize":"links";});}return true;});menu.show();}
    /** Menú del inicio: solo lo general (cuentas, guardadas, búsqueda avanzada y ajustes). */
    void tools(View anchor){PopupMenu menu=new PopupMenu(this,anchor);
        menu.getMenu().add(0,1,0,"Cuentas y sesiones");menu.getMenu().add(0,7,1,"Guardadas");menu.getMenu().add(0,5,2,"Descubrir enlaces y títulos F95");menu.getMenu().add(0,6,3,"Ajustes");
        menu.setOnMenuItemClickListener(mi->{switch(mi.getItemId()){case 1->startActivity(new Intent(this,AccountActivity.class));case 5->startActivity(new Intent(this,SourceDiscoveryActivity.class));case 6->startActivity(new Intent(this,SettingsActivity.class));
            case 7->{if(!draft.busy){previews.reset();draft.run(d->{d.home=false;d.savedOnly=true;d.openId="";d.hits=List.of();d.showHits=false;d.localFilter="";d.type=0;d.status="";});}}}return true;});menu.show();}
    /** Menú de una fuente: buscar dentro de los resultados, ordenar y administrar esa fuente. */
    void sourceMenu(View anchor){PopupMenu menu=new PopupMenu(this,anchor);FollowSource current=draft.current();boolean source=current!=null&&!draft.savedOnly&&!draft.showHits;
        menu.getMenu().add(0,8,0,"Buscar y ordenar en estos resultados");
        if(source){menu.getMenu().add(0,4,1,"Guardar esta página").setEnabled(draft.review!=null&&!draft.review.rows().isEmpty());menu.getMenu().add(0,2,2,"Administrar esta fuente");
            if(Set.of("rule34xxx","f95zone").contains(current.provider))menu.getMenu().add(0,3,3,current.provider.equals("f95zone")?"Sesión de F95zone":"Clave API de Rule34.xxx");}
        menu.setOnMenuItemClickListener(mi->{switch(mi.getItemId()){case 8->filters();case 2->manageSource();case 3->credentials();
            case 4->new AlertDialog.Builder(this).setTitle("Guardar esta página").setMessage("Conserva las publicaciones compatibles de esta página para consultarlas sin conexión. No descarga sus archivos.").setPositiveButton("Guardar",(d,w)->draft.run(m->{int n=m.store.apply(m.review);m.status=n+" publicaciones guardadas.";})).setNegativeButton("Cerrar",null).show();}return true;});menu.show();}
    void manageSource(){FollowSource s=draft.current();if(s==null||draft.busy)return;new AlertDialog.Builder(this).setTitle(s.label).setItems(new String[]{"Cambiar nombre",s.paused?"Reanudar consultas":"Pausar consultas","Eliminar fuente","Vincular identidad"},(d,i)->{if(i==0){EditText input=new EditText(this);input.setSingleLine();input.setText(s.label);new AlertDialog.Builder(this).setTitle("Nombre de la fuente").setView(input).setPositiveButton("Guardar",(a,w)->draft.run(m->m.store.edit(s.id,input.getText().toString(),s.entityId,s.paused))).setNegativeButton("Cerrar",null).show();}else if(i==1)draft.run(m->m.store.edit(s.id,s.label,s.entityId,!s.paused));else if(i==2)new AlertDialog.Builder(this).setTitle("Eliminar fuente").setMessage("Tus publicaciones y archivos guardados se conservan.").setPositiveButton("Eliminar",(a,w)->draft.run(m->{m.store.remove(s.id);m.home=true;})).setNegativeButton("Conservar",null).show();else linkIdentity(s);}).setNegativeButton("Cerrar",null).show();}
    void linkIdentity(FollowSource s){List<CatalogEntity> entities=List.copyOf(draft.entities);List<String> names=new ArrayList<>(List.of("Sin identidad vinculada"));for(var e:entities)names.add(e.name+" · "+EntityIndex.kind(e.kind).label());new AlertDialog.Builder(this).setTitle("Identidad de la fuente").setItems(names.toArray(String[]::new),(d,n)->draft.run(m->m.store.edit(s.id,s.label,n==0?null:entities.get(n-1).id,s.paused))).setNegativeButton("Cerrar",null).show();}
    void credentials(){FollowSource s=draft.current();if(s==null)return;if(s.provider.equals("f95zone")){F95SessionDialog.show(this,value->draft.run(d->{new F95Secrets(this).write(value);F95SessionDialog.invalidate(d.db);}),()->draft.run(d->{new F95Secrets(this).clear();F95SessionDialog.invalidate(d.db);}));return;}LinearLayout form=PeachDesign.column(this);form.setPadding(dp(20),dp(8),dp(20),dp(12));EditText user=new EditText(this);user.setHint("user_id");user.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);user.setSaveEnabled(false);form.addView(user);EditText key=new EditText(this);key.setHint("api_key");key.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);key.setSaveEnabled(false);form.addView(key);AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Clave API Rule34.xxx").setView(form).setPositiveButton("Guardar",null).setNeutralButton("Borrar clave",(a,w)->draft.run(d->{new SourceSecrets(this).clear();for(FollowSource peer:d.db.library().sources())if(peer.provider.equals("rule34xxx"))d.store.edit(peer.id,peer.label,peer.entityId,peer.paused);d.status="Clave retirada. Los archivos y publicaciones se conservan.";})).setNegativeButton("Cerrar",null).create();dialog.setOnShowListener(v->{dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(b->{try{var api=new SourceCredentials.ApiKey(user.getText().toString().trim(),key.getText().toString().trim());draft.run(d->{new SourceSecrets(this).write(api);for(FollowSource peer:d.db.library().sources())if(peer.provider.equals("rule34xxx"))d.store.edit(peer.id,peer.label,peer.entityId,peer.paused);d.status="Clave guardada. Pulsa Buscar para consultar.";});key.setText("");dialog.dismiss();}catch(IllegalArgumentException e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}});});dialog.show();}
    /** Una sola cuadrícula para el inicio (tus fuentes) y los resultados (publicaciones). */
    private final class Cards extends RecyclerView.Adapter<Cards.Holder>{
        static final int HEADER=0,SOURCE=1,SAVED=2,POST=3,HIT=4,EMPTY=5;
        final List<Object[]> rows=new ArrayList<>();
        boolean full(int position){if(position<0||position>=rows.size())return false;int t=(Integer)rows.get(position)[0];return t==HEADER||t==EMPTY;}
        void home(List<FollowSource> sources){rows.clear();
            rows.add(new Object[]{HEADER,"Tus fuentes",sources.isEmpty()?"Aún no sigues ninguna. Busca arriba un creador o una etiqueta y aparecerá aquí.":"Toca una para ver sus publicaciones."});
            for(FollowSource s:sources)rows.add(new Object[]{SOURCE,s});rows.add(new Object[]{SAVED});notifyDataSetChanged();}
        Map<String,Integer> numbers=Map.of();
        void update(List<SourceBrowserItems.Item> v,List<F95Search.Hit> h,Map<String,Integer> n){numbers=n;rows.clear();
            if(!h.isEmpty())for(F95Search.Hit hit:h)rows.add(new Object[]{HIT,hit});
            else if(v.isEmpty())rows.add(new Object[]{EMPTY});
            else for(var item:v)rows.add(new Object[]{POST,item});
            notifyDataSetChanged();}
        @Override public int getItemCount(){return rows.size();}
        @Override public int getItemViewType(int position){return (Integer)rows.get(position)[0];}
        @Override public Holder onCreateViewHolder(ViewGroup parent,int type){
            android.content.Context c=SourceBrowserActivity.this;LinearLayout card=PeachDesign.column(c);RecyclerView.LayoutParams lp=new RecyclerView.LayoutParams(-1,-2);
            if(type==HEADER){lp.setMargins(dp(4),dp(18),dp(4),dp(6));card.setLayoutParams(lp);TextView h=PeachDesign.text(c,"",20,"body");h.setTypeface(UiAppearance.title(c));card.addView(h);TextView sub=PeachDesign.text(c,"",13,"muted");sub.setPadding(0,dp(2),0,0);card.addView(sub);return new Holder(card,null,h,sub,null);}
            if(type==SOURCE||type==SAVED){lp.setMargins(dp(5),dp(5),dp(5),dp(5));card.setLayoutParams(lp);card.setPadding(dp(16),dp(14),dp(12),dp(14));card.setFocusable(true);card.setClickable(true);
                card.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(UiAppearance.accentSoft(c,0x26)),UiAppearance.rounded(c,UiAppearance.surface(c),20),null));
                LinearLayout top=PeachDesign.row(c);LinearLayout chipBox=PeachDesign.row(c);top.addView(chipBox,new LinearLayout.LayoutParams(0,-2,1));ImageView arrow=new ImageView(c);arrow.setImageDrawable(PeachDesign.icon(c,R.drawable.ic_ui_chevron,UiAppearance.secondary(c)));top.addView(arrow);card.addView(top);
                TextView name=PeachDesign.text(c,"",17,"body");name.setTypeface(UiAppearance.title(c));name.setMaxLines(1);name.setEllipsize(TextUtils.TruncateAt.END);name.setPadding(0,dp(10),0,dp(2));card.addView(name);
                TextView meta=PeachDesign.text(c,"",12,"muted");meta.setMaxLines(1);meta.setEllipsize(TextUtils.TruncateAt.END);card.addView(meta);return new Holder(card,null,name,meta,chipBox);}
            if(type==EMPTY){lp.setMargins(dp(4),dp(40),dp(4),dp(12));card.setLayoutParams(lp);card.setGravity(Gravity.CENTER);ImageView icon=new ImageView(c);icon.setScaleType(ImageView.ScaleType.CENTER);
                android.graphics.drawable.GradientDrawable dot=new android.graphics.drawable.GradientDrawable();dot.setShape(android.graphics.drawable.GradientDrawable.OVAL);dot.setColor(UiAppearance.accentSoft(c,0x26));icon.setBackground(dot);card.addView(icon,new LinearLayout.LayoutParams(dp(72),dp(72)));
                TextView name=PeachDesign.text(c,"",19,"body");name.setTypeface(UiAppearance.display(c));name.setGravity(Gravity.CENTER);name.setPadding(0,dp(14),0,dp(4));card.addView(name);TextView meta=PeachDesign.text(c,"",14,"muted");meta.setGravity(Gravity.CENTER);meta.setMaxWidth(dp(440));card.addView(meta);return new Holder(card,icon,name,meta,null);}
            lp.setMargins(dp(5),dp(5),dp(5),dp(14));card.setLayoutParams(lp);card.setFocusable(true);card.setClickable(true);
            FrameLayout frame=new FrameLayout(c);ImageView image=new ImageView(c);image.setScaleType(ImageView.ScaleType.CENTER_CROP);image.setBackground(UiAppearance.rounded(c,UiAppearance.surface(c),18));image.setClipToOutline(true);frame.addView(image,new FrameLayout.LayoutParams(-1,-1));
            LinearLayout chipBox=PeachDesign.row(c);FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.START);cp.setMargins(dp(10),0,0,dp(10));frame.addView(chipBox,cp);
            card.addView(frame,new LinearLayout.LayoutParams(-1,dp(170)));
            TextView name=PeachDesign.text(c,"",15,"body");name.setTypeface(UiAppearance.title(c));name.setMaxLines(2);name.setEllipsize(TextUtils.TruncateAt.END);name.setPadding(dp(2),dp(10),dp(2),dp(2));card.addView(name);
            TextView meta=PeachDesign.text(c,"",12,"muted");meta.setMaxLines(1);meta.setEllipsize(TextUtils.TruncateAt.END);meta.setPadding(dp(2),0,dp(2),0);card.addView(meta);
            card.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(UiAppearance.accentSoft(c,0x26)),null,UiAppearance.rounded(c,0xff000000,18)));
            return new Holder(card,image,name,meta,chipBox);
        }
        /** Pastilla oscura sobre la portada: "Video", "3 imágenes"… */
        TextView kind(String text){TextView t=new TextView(SourceBrowserActivity.this);t.setText(text);t.setTextSize(11);t.setTextColor(0xffffffff);t.setTypeface(UiAppearance.title(SourceBrowserActivity.this));t.setBackground(UiAppearance.rounded(SourceBrowserActivity.this,0xb3000000,10));t.setPadding(dp(8),dp(3),dp(8),dp(3));return t;}
        @Override public void onBindViewHolder(Holder h,int i){Object[] row=rows.get(i);int type=(Integer)row[0];
            switch(type){
                case HEADER->{h.name.setText((String)row[1]);h.meta.setText((String)row[2]);}
                case SOURCE->{FollowSource s=(FollowSource)row[1];h.chips.removeAllViews();h.chips.addView(badge(s.provider));h.name.setText(s.label);
                    h.meta.setText(s.paused?"En pausa":s.checkedAt>0?(System.currentTimeMillis()-s.checkedAt<60_000?"Actualizada hace un momento":"Actualizada "+android.text.format.DateUtils.getRelativeTimeSpanString(s.checkedAt,System.currentTimeMillis(),android.text.format.DateUtils.MINUTE_IN_MILLIS)):"Toca para ver sus publicaciones");
                    h.itemView.setContentDescription(s.label+", en "+SourceBrowserItems.name(s.provider)+". Abrir.");h.itemView.setOnClickListener(v->{if(draft.busy)return;previews.reset();draft.type=0;draft.choose(s.id,true);});
                    h.itemView.setOnLongClickListener(v->{if(draft.busy)return true;draft.selected=s.id;manageSource();return true;});}
                case SAVED->{h.chips.removeAllViews();TextView all=badge("");all.setText("Todas");h.chips.addView(all);h.name.setText("Guardadas");h.meta.setText("Lo que guardaste de todas tus fuentes");h.itemView.setContentDescription("Publicaciones guardadas. Abrir.");
                    h.itemView.setOnClickListener(v->{if(draft.busy)return;previews.reset();draft.run(d->{d.home=false;d.savedOnly=true;d.openId="";d.hits=List.of();d.showHits=false;d.localFilter="";d.type=0;d.status="";});});}
                case HIT->{F95Search.Hit hit=(F95Search.Hit)row[1];h.name.setText(hit.title());h.meta.setText(hit.labels());h.image.setTag("");h.image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);h.image.setImageDrawable(PeachDesign.icon(SourceBrowserActivity.this,R.drawable.ic_ui_sources,siteColor("f95zone")));h.chips.removeAllViews();h.chips.addView(kind("F95zone"));
                    h.itemView.setOnClickListener(v->{draft.input="https://f95zone.to/threads/"+hit.thread()+"/";previews.reset();draft.search();});h.itemView.setContentDescription(hit.title()+". Abrir hilo.");}
                case EMPTY->{boolean filtered=draft.type!=0||!draft.localFilter.isEmpty();h.image.setImageDrawable(PeachDesign.icon(SourceBrowserActivity.this,draft.busy?R.drawable.ic_ui_refresh:R.drawable.ic_ui_search,UiAppearance.accent(SourceBrowserActivity.this)));
                    h.name.setText(draft.busy?"Buscando…":filtered?"Nada de este tipo aquí":draft.savedOnly?"Aún no tienes nada guardado":"Sin resultados todavía");
                    h.meta.setText(draft.busy?"Esto puede tardar unos segundos.":filtered?"Prueba con la pestaña «Todo».":draft.savedOnly?"Abre una publicación y usa ⋯ → Guardar publicación.":"Toca ↻ para consultar esta fuente o vuelve y prueba otra búsqueda.");
                    h.itemView.setOnClickListener(null);}
                default->{var item=(SourceBrowserItems.Item)row[1];Publication p=item.publication();h.name.setText(p.title);
                    String date=p.publishedAt==null||p.publishedAt.isEmpty()?"":p.publishedAt.substring(0,Math.min(10,p.publishedAt.length()));
                    h.meta.setText(draft.savedOnly?SourceBrowserItems.name(p.provider)+(p.sourceLabel==null||p.sourceLabel.isEmpty()?"":" · "+p.sourceLabel):date.isEmpty()?SourceBrowserItems.summary(item):date);
                    h.chips.removeAllViews();String what=SourceBrowserItems.summary(item);
                    // Número desde la más reciente (#41); si aún no se conoce la posición global, el de la página (n.º 3).
                    Integer number=numbers.get(p.id);if(number!=null){TextView tag=kind(number>0?"#"+number:"n.º "+(-number));tag.setId(R.id.card_number);tag.setBackground(UiAppearance.rounded(SourceBrowserActivity.this,UiAppearance.accentSoft(SourceBrowserActivity.this,0xe6),10));tag.setTextColor(UiAppearance.onAccent(SourceBrowserActivity.this));LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-2,-2);np.setMarginEnd(dp(6));h.chips.addView(tag,np);}if(!what.startsWith("Sin contenido")&&!what.equals("Publicación de texto"))h.chips.addView(kind(what.contains("video")?(what.contains("imagen")?"Video · imágenes":"Video"):what.split(" · ")[0]));
                    previews.bind(h.image,p,item.content(),draft.onlinePreviews);h.itemView.setContentDescription(p.title+". "+what+". Abrir publicación.");h.itemView.setOnClickListener(v->openPost(item));}
            }
        }
        final class Holder extends RecyclerView.ViewHolder{final ImageView image;final TextView name,meta;final LinearLayout chips;Holder(View v,ImageView image,TextView name,TextView meta,LinearLayout chips){super(v);this.image=image;this.name=name;this.meta=meta;this.chips=chips;}}
    }
    @Override protected void onStart(){super.onStart();started=true;previews.resume();if(cards!=null)cards.notifyDataSetChanged();launchPending();}
    @Override protected void onResume(){super.onResume();if(draft!=null&&!draft.busy)draft.run(d->{});}
    @Override protected void onStop(){started=false;if(grid!=null&&draft.openId.isEmpty())draft.scroll=grid.getLayoutManager().onSaveInstanceState();previews.cancel();draft.remember();if(!isChangingConfigurations()&&!draft.savePickerOpen)draft.token.cancel();super.onStop();}
    @Override protected void onDestroy(){previews.close();super.onDestroy();}
    @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);out.putString("openPublication",draft.openId);out.putString("input",draft.input);out.putString("selected",draft.selected);out.putBoolean("savedOnly",draft.savedOnly);out.putString("localFilter",draft.localFilter);out.putInt("type",draft.type);out.putInt("sort",draft.sort);out.putString("provider",draft.provider);out.putBoolean("home",draft.home);}
}
