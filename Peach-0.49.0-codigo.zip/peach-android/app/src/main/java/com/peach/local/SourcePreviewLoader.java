package com.peach.local;
import android.content.Context;
import android.graphics.Bitmap;
import android.util.LruCache;
import android.widget.ImageView;
import java.util.*;
import java.util.concurrent.*;

/** Only visible result cards request images, after an explicit search/refresh. Never fetches videos. */
final class SourcePreviewLoader {
    static GalleryCache.Fetcher fetcher=SourceHttp::image;
    private static final LruCache<String,Bitmap> memory=new LruCache<>(8*1024*1024){@Override protected int sizeOf(String k,Bitmap b){return b.getAllocationByteCount();}};
    private final ThreadPoolExecutor worker=new ThreadPoolExecutor(2,2,20,TimeUnit.SECONDS,new ArrayBlockingQueue<>(24),new ThreadPoolExecutor.AbortPolicy());
    private final Set<SourceHttp.Token> tokens=ConcurrentHashMap.newKeySet();private final Set<String> failed=ConcurrentHashMap.newKeySet();private final Context app;private volatile int epoch;private volatile boolean active=true;
    SourcePreviewLoader(Context c){app=c.getApplicationContext();}
    static void clearMemory(){memory.evictAll();}
    static SourceGallery.Image image(Publication p,PublicationContent c){if(p==null||c==null)return null;try{
        var images=SourceGallery.select(p,c).images();if(!images.isEmpty())return images.get(0);
        var a=new org.json.JSONArray(c.attachments);for(int i=0;i<a.length();i++){var preview=a.getJSONObject(i).optJSONObject("peachPreview");if(preview!=null){String url=preview.getString("url"),name=preview.getString("name");if(name.length()<=140&&SourceThumbs.admitted(p.provider,url))return new SourceGallery.Image(name,url);}}
    }catch(Exception ignored){}return null;}
    void bind(ImageView view,Publication p,PublicationContent c,boolean online){
        SourceGallery.Image image=image(p,c);String video=image==null?firstVideo(p,c):null;
        String key=image!=null?GalleryCache.key(image.url())+"|"+image.expectedHash():video!=null?"frame|"+VideoCache.keyFor(video):"";view.setTag(key);
        if(video!=null){view.setScaleType(ImageView.ScaleType.FIT_XY);view.setImageDrawable(new VideoTile(app));frame(view,key,video);return;}
        view.setScaleType(ImageView.ScaleType.CENTER_INSIDE);view.setImageDrawable(PeachDesign.icon(app,image==null?R.drawable.ic_ui_file:R.drawable.ic_ui_image,UiAppearance.secondary(app)));if(image==null)return;
        Bitmap cached=memory.get(key);if(cached!=null){view.setScaleType(ImageView.ScaleType.CENTER_CROP);view.setImageBitmap(cached);return;}if(!active||failed.contains(key))return;int generation=epoch;SourceHttp.Token token=new SourceHttp.Token();tokens.add(token);
        try{worker.execute(()->{GalleryCache.Frame frame=null;try{token.check();Bitmap result;if(SourceThumbs.special(p.provider,image.url()))result=SourceThumbs.acquire(app.getCacheDir(),p.provider,image,!online,token);else{frame=new GalleryCache(app.getCacheDir()).acquirePreview(image,!online,token,fetcher);result=frame.image().bitmap();}token.check();memory.put(key,result);frame=null;view.post(()->{if(active&&epoch==generation&&key.equals(view.getTag())){view.setScaleType(ImageView.ScaleType.CENTER_CROP);view.setImageBitmap(result);}});}catch(Exception|OutOfMemoryError ignored){if(!token.cancelled)failed.add(key);}finally{if(frame!=null)frame.release();tokens.remove(token);}});}catch(RejectedExecutionException ignored){tokens.remove(token);}
    }
    /** Primer video de la publicación, si no trae ninguna imagen ni portada declarada. */
    static String firstVideo(Publication p,PublicationContent c){if(p==null||c==null)return null;try{var videos=SourceVideos.select(p,c).videos();return videos.isEmpty()?null:videos.get(0).url();}catch(Exception ignored){return null;}}
    /** Fotograma de la copia local del video (si ya se preparó o reprodujo). Sin red. */
    private void frame(ImageView view,String key,String url){
        Bitmap cached=memory.get(key);if(cached!=null){view.setScaleType(ImageView.ScaleType.CENTER_CROP);view.setImageBitmap(cached);return;}
        if(!active||failed.contains(key))return;int generation=epoch;
        try{worker.execute(()->{Bitmap result=null;try{result=SourceVideoFrames.local(app.getCacheDir(),url);}catch(Exception|OutOfMemoryError ignored){/* Queda la tarjeta de video. */}
            if(result==null){failed.add(key);return;}Bitmap done=result;memory.put(key,done);
            view.post(()->{if(active&&epoch==generation&&key.equals(view.getTag())){view.setScaleType(ImageView.ScaleType.CENTER_CROP);PeachDesign.crossfade(view,done);}});});}
        catch(RejectedExecutionException ignored){/* Cola llena: se intentará al volver a mostrar la tarjeta. */}
    }
    /** Tarjeta de video dibujada: degradado con el color de acento, botón ▶ y la etiqueta "VIDEO". */
    static final class VideoTile extends android.graphics.drawable.Drawable {
        private final android.graphics.Paint paint=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);private final int accent,base;private final float density;
        VideoTile(Context c){accent=UiAppearance.accent(c);base=UiAppearance.dark(c)?0xff1a1c25:0xff2a2d38;density=c.getResources().getDisplayMetrics().density;}
        @Override public void draw(@androidx.annotation.NonNull android.graphics.Canvas canvas){
            android.graphics.Rect b=getBounds();if(b.isEmpty())return;
            paint.setShader(new android.graphics.LinearGradient(b.left,b.top,b.right,b.bottom,new int[]{base,mix(base,accent,.35f),0xff0b0c11},null,android.graphics.Shader.TileMode.CLAMP));canvas.drawRect(b,paint);paint.setShader(null);
            float r=Math.min(b.width(),b.height())*.16f,cx=b.exactCenterX(),cy=b.exactCenterY();
            paint.setColor(0x33ffffff);canvas.drawCircle(cx,cy,r*1.25f,paint);paint.setColor(0xf2ffffff);canvas.drawCircle(cx,cy,r,paint);
            android.graphics.Path play=new android.graphics.Path();float t=r*.42f;play.moveTo(cx-t*.7f,cy-t);play.lineTo(cx+t,cy);play.lineTo(cx-t*.7f,cy+t);play.close();paint.setColor(0xff15131a);canvas.drawPath(play,paint);
            paint.setColor(0xccffffff);paint.setTextSize(11*density);paint.setFakeBoldText(true);paint.setLetterSpacing(.12f);canvas.drawText("VIDEO",b.left+12*density,b.bottom-12*density,paint);paint.setFakeBoldText(false);paint.setLetterSpacing(0);
        }
        private static int mix(int a,int b,float t){int ar=(a>>16)&255,ag=(a>>8)&255,ab=a&255,br=(b>>16)&255,bg=(b>>8)&255,bb=b&255;return 0xff000000|Math.round(ar+(br-ar)*t)<<16|Math.round(ag+(bg-ag)*t)<<8|Math.round(ab+(bb-ab)*t);}
        @Override public void setAlpha(int alpha){paint.setAlpha(alpha);}
        @Override public void setColorFilter(android.graphics.ColorFilter filter){paint.setColorFilter(filter);}
        @Override public int getOpacity(){return android.graphics.PixelFormat.OPAQUE;}
    }
    void resume(){active=true;failed.clear();}
    void cancel(){active=false;epoch++;tokens.forEach(SourceHttp.Token::cancel);worker.getQueue().clear();tokens.clear();}
    void reset(){cancel();resume();}
    void close(){cancel();worker.shutdownNow();}
}
