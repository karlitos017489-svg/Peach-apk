package com.peach.local;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Arrays;
import java.util.Comparator;

/**
 * Miniaturas de video para Fuentes, sacadas solo de copias que ya están en el dispositivo
 * (video preparado o reproducido antes). Nunca descarga ni transmite nada para obtenerlas.
 */
final class SourceVideoFrames {
    private SourceVideoFrames() {}
    static final int LIMIT=200,EDGE=512;private static final Object LOCK=new Object();

    /** Fotograma guardado para esta dirección de video, o uno nuevo si el video ya está en la caché local. */
    static Bitmap local(File cache,String url){
        String key=VideoCache.keyFor(url);File dir=new File(cache,"peach-video-frames");File frame=new File(dir,key+".jpg");
        synchronized(LOCK){
            if(frame.isFile())try{Bitmap b=BitmapFactory.decodeFile(frame.getPath());if(b!=null){frame.setLastModified(System.currentTimeMillis());return b;}}catch(RuntimeException|OutOfMemoryError ignored){/* Se regenera. */}
            File video=cached(new File(cache,"peach-source-video"),key);if(video==null)return null;
            Bitmap bitmap=extract(video);if(bitmap==null)return null;
            try{if(dir.isDirectory()||dir.mkdirs()){File part=new File(dir,key+".part");try(FileOutputStream out=new FileOutputStream(part)){bitmap.compress(Bitmap.CompressFormat.JPEG,82,out);}if(!part.renameTo(frame))part.delete();trim(dir);}}
            catch(Exception ignored){/* La miniatura se muestra igual; solo no queda guardada. */}
            return bitmap;
        }
    }
    /** El archivo completo de la caché de videos (no los parciales ni sus metadatos). */
    static File cached(File root,String key){
        File[] files=root.listFiles((d,n)->n.startsWith(key+".")&&!n.endsWith(".meta")&&!n.endsWith(".part")&&!n.endsWith(".tmp"));
        if(files==null)return null;for(File f:files)if(f.isFile()&&f.length()>0)return f;return null;
    }
    /** Un fotograma representativo (cerca del 10 % del video), reducido a {@link #EDGE} píxeles. */
    static Bitmap extract(File video){
        MediaMetadataRetriever retriever=new MediaMetadataRetriever();
        try{
            retriever.setDataSource(video.getPath());
            long micros=1_000_000L;String length=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            try{if(length!=null)micros=Math.max(0,Long.parseLong(length)*100);}catch(NumberFormatException ignored){/* Primer segundo. */}
            Bitmap frame=android.os.Build.VERSION.SDK_INT>=27?retriever.getScaledFrameAtTime(micros,MediaMetadataRetriever.OPTION_CLOSEST_SYNC,EDGE,EDGE):retriever.getFrameAtTime(micros,MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            return frame;
        }catch(Exception|OutOfMemoryError e){return null;}
        finally{try{retriever.release();}catch(Exception ignored){/* Ya liberado. */}}
    }
    static void trim(File dir){File[] list=dir.listFiles((d,n)->n.endsWith(".jpg"));if(list==null||list.length<=LIMIT)return;Arrays.sort(list,Comparator.comparingLong(File::lastModified));for(int i=0;i<list.length-LIMIT;i++)list[i].delete();}
    static int clear(File cache){File[] list=new File(cache,"peach-video-frames").listFiles();int n=0;if(list!=null)for(File f:list)if(f.delete())n++;return n;}
}
