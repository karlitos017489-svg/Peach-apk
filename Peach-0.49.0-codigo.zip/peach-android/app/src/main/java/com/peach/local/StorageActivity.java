package com.peach.local;

import android.os.Bundle;
import android.widget.*;
import java.io.File;

/** Only app-owned disposable caches; never queue downloads, user documents, credentials or state. */
public final class StorageActivity extends PeachActivity {
    private TextView status;private Button clean;private boolean busy;
    @Override protected void onCreate(Bundle state){super.onCreate(state);LinearLayout root=UiAppearance.column(this,"Almacenamiento y caché");status=new TextView(this);root.addView(status);
        TextView help=new TextView(this);help.setText("La caché agiliza portadas, imágenes y videos preparados. Limpiarla puede requerir descargarlos de nuevo. Se conservan los videos abiertos, las preparaciones activas, las descargas de la cola, tus archivos, cuentas y biblioteca.");root.addView(help);
        clean=new Button(this);clean.setText("Limpiar caché que no está en uso");clean.setOnClickListener(v->new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Limpiar caché").setMessage("Se retirarán solo las copias temporales libres de imágenes y videos, y las miniaturas de memoria.").setPositiveButton("Limpiar",(d,w)->refresh(true)).setNegativeButton("Cancelar",null).show());root.addView(clean);Button update=new Button(this);update.setText("Actualizar espacio");update.setOnClickListener(v->refresh(false));root.addView(update);Button recovery=new Button(this);recovery.setText("Revisar transferencias a nube");recovery.setOnClickListener(v->startActivity(new android.content.Intent(this,DirectSaveActivity.class)));root.addView(recovery);refresh(false);}
    void refresh(boolean clear){if(busy)return;busy=true;clean.setEnabled(false);status.setText("Calculando…");UiAppearance.IO.execute(()->{String result;try{
        int count=0;if(clear){Thumbnails.clearMemory();SourcePreviewLoader.clearMemory();UiAppearance.clearWallpaperMemory();count+=new VideoCache(getCacheDir()).clearUnused();count+=SourceVideoFrames.clear(getCacheDir());count+=new GalleryCache(getCacheDir()).clearUnused();count+=SourceThumbs.clear(getCacheDir());}
        result=(clear?"Copias temporales retiradas: "+count+"\n":"")+"Caché de imágenes: "+size(new File(getCacheDir(),"peach-source-gallery"))+"\nVistas previas: "+size(new File(getCacheDir(),"peach-source-thumbs"))+"\nCaché de videos: "+size(new File(getCacheDir(),"peach-source-video"))+"\nEspacio disponible en la app: "+android.text.format.Formatter.formatShortFileSize(this,getFilesDir().getUsableSpace())+"\n\nLas descargas de la cola se administran desde Descargas. El espacio temporal del proveedor de nube se administra en su propia app.";
        }catch(Exception e){result="No se pudo calcular o limpiar toda la caché. Los archivos personales se conservan.";}String done=result;runOnUiThread(()->{busy=false;if(!isDestroyed()){status.setText(done);clean.setEnabled(true);}});});}
    String size(File directory){long total=0;File[] all=directory.listFiles();if(all!=null)for(File f:all)if(f.isFile())total+=f.length();return android.text.format.Formatter.formatShortFileSize(this,total);}
}
