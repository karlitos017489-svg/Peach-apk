package com.peach.local;

import android.app.Activity;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import java.io.*;

/** Local appearance only. No network, media grants or library state. */
final class UiAppearance {
    static final java.util.concurrent.ExecutorService IO=java.util.concurrent.Executors.newFixedThreadPool(2);
    static final String PREFS="peach-appearance";
    static final int[] COLORS={0xffedab8d,0xff8eb9f3,0xff8dcfb0,0xffbca2e8,0xffe8a0bc,0xffe2c47f};
    static final String[] NAMES={"Durazno","Azul","Menta","Lavanda","Rosa","Arena"};
    static android.content.SharedPreferences prefs(Context c){return c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
    static boolean dark(Context c){if(c instanceof PlayerActivity||c instanceof AudioActivity||c instanceof ImageViewerActivity||c instanceof ReaderActivity)return true;int mode=prefs(c).getInt("mode",1);return mode==1||mode==3||mode==0&&(c.getResources().getConfiguration().uiMode&0x30)==0x20;}
    /** Modo 3: negro puro para pantallas OLED; solo cambia fondos y superficies. */
    static boolean black(Context c){return dark(c)&&prefs(c).getInt("mode",1)==3&&!(c instanceof AudioActivity);}
    static int background(Context c){return dark(c)?(black(c)?0xff000000:0xff0b0c11):0xfff6f6f9;}
    static int surface(Context c){return dark(c)?(black(c)?0xff111216:0xff171922):0xffffffff;}
    /** Superficie elevada: chips, mini reproductor y botones secundarios. */
    static int surfaceHigh(Context c){return dark(c)?(black(c)?0xff1c1d23:0xff22252f):0xffeceef3;}
    /** Color de acento con transparencia, para fondos suaves de iconos y selección. */
    static int accentSoft(Context c,int alpha){return (accent(c)&0x00ffffff)|(alpha<<24);}
    /** Texto legible encima del color de acento. */
    static int onAccent(Context c){return dark(c)?0xff16131a:0xffffffff;}
    private static Typeface display,title;
    /** Manrope Bold para encabezados; si no carga, se usa la fuente del sistema. */
    static Typeface display(Context c){if(display==null){try{display=androidx.core.content.res.ResourcesCompat.getFont(c.getApplicationContext(),R.font.manrope_bold);}catch(Exception ignored){/* La fuente del sistema queda disponible. */}if(display==null)display=Typeface.create("sans-serif",Typeface.BOLD);}return display;}
    /** Manrope SemiBold para títulos de tarjetas y secciones. */
    static Typeface title(Context c){if(title==null){try{title=androidx.core.content.res.ResourcesCompat.getFont(c.getApplicationContext(),R.font.manrope_semibold);}catch(Exception ignored){/* La fuente del sistema queda disponible. */}if(title==null)title=Typeface.create("sans-serif-medium",Typeface.NORMAL);}return title;}
    static int text(Context c){return dark(c)?0xfff1f3f8:0xff18212f;}
    static int secondary(Context c){return dark(c)?0xffb8c2d2:0xff536175;}
    static int accentIndex(Context c){return Math.max(0,Math.min(COLORS.length-1,prefs(c).getInt("accent",0)));}
    static int accent(Context c){int index=accentIndex(c);return dark(c)?COLORS[index]:new int[]{0xff8d4226,0xff245998,0xff246b4e,0xff654398,0xff913b5b,0xff755814}[index];}
    static int theme(Context c){return new int[]{R.style.PeachPeach,R.style.PeachBlue,R.style.PeachMint,R.style.PeachLavender,R.style.PeachRose,R.style.PeachSand}[accentIndex(c)];}
    static boolean motion(Context c){return prefs(c).getInt("motion",1)>0&&android.animation.ValueAnimator.areAnimatorsEnabled();}
    static int dp(Context c,int value){return Math.round(value*c.getResources().getDisplayMetrics().density);}
    static GradientDrawable rounded(Context c,int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(c,radius));return d;}
    static void polish(View view){
        Context c=view.getContext();
        if(view instanceof androidx.media3.ui.PlayerView)return;
        if(view.getTag(R.id.design_role)!=null){PeachDesign.finish(view);}
        else if(view instanceof Button b&&!(view instanceof CompoundButton)){b.setAllCaps(false);b.setMinHeight(dp(c,48));b.setTextColor(text(c));
            GradientDrawable face=rounded(c,surfaceHigh(c),16);b.setTextSize(14); b.setPadding(dp(c,16),dp(c,6),dp(c,16),dp(c,6));b.setStateListAnimator(null);b.setBackgroundTintList(null);
            b.setBackground(new RippleDrawable(android.content.res.ColorStateList.valueOf(accentSoft(c,0x33)),face,null));
            PeachDesign.button(b);PeachDesign.press(b);
        }else if(view instanceof TextView t){t.setTextColor(text(c));if(t instanceof EditText){t.setHintTextColor(secondary(c));t.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent(c)));}}
        if(view instanceof ProgressBar p){p.setProgressTintList(android.content.res.ColorStateList.valueOf(accent(c)));p.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(accent(c)));}
        if(view instanceof ViewGroup group)for(int i=0;i<group.getChildCount();i++)polish(group.getChildAt(i));
    }
    static LinearLayout column(Activity activity,String title){
        ScrollView scroll=new ScrollView(activity);scroll.setFillViewport(true);LinearLayout root=new LinearLayout(activity);root.setOrientation(LinearLayout.VERTICAL);int pad=dp(activity,18);root.setPadding(pad,pad,pad,pad);scroll.addView(root);activity.setContentView(scroll);
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(scroll,(v,insets)->{var b=insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars()|androidx.core.view.WindowInsetsCompat.Type.displayCutout()|androidx.core.view.WindowInsetsCompat.Type.ime());v.setPadding(b.left,b.top,b.right,b.bottom);return insets;});
        LinearLayout header=PeachDesign.row(activity);header.addView(PeachDesign.iconButton(activity,R.drawable.ic_ui_back,"Volver",v->activity.finish()));TextView heading=PeachDesign.text(activity,title,24,"section");heading.setGravity(Gravity.CENTER_VERTICAL);heading.setPadding(dp(activity,10),0,0,0);header.addView(heading,new LinearLayout.LayoutParams(0,dp(activity,68),1));root.addView(header);return root;
    }
    static File wallpaper(Context c){return WallpaperStore.file(c);}
    static volatile Bitmap wallpaperBitmap;static volatile String wallpaperKey="";
    static synchronized void clearWallpaperMemory(){wallpaperBitmap=null;wallpaperKey="";}
    static void applyWallpaper(Activity activity){
        IO.execute(()->{try{WallpaperStore.Snapshot snapshot=WallpaperStore.load(activity);
            activity.runOnUiThread(()->{if(activity.isDestroyed()||!snapshot.key().equals(WallpaperStore.key(activity)))return;
                int strength=Math.max(10,Math.min(80,prefs(activity).getInt("wallpaperStrength",35)));int base=background(activity);
                ColorDrawable veil=new ColorDrawable((base&0xffffff)|((255-strength*255/100)<<24));activity.getWindow().setBackgroundDrawable(new LayerDrawable(new Drawable[]{new WallpaperImage(snapshot.bitmap()),veil}));});
            }catch(Exception|OutOfMemoryError ignored){/* Keep the normal readable background. */}
        });
    }
    static void saveWallpaper(Context c,android.net.Uri uri)throws IOException {WallpaperStore.save(c,uri);}
}
