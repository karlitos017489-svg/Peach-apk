package com.peach.local;

import javax.net.ssl.HttpsURLConnection;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.function.BooleanSupplier;

/** Selected progressive video only. No disk cache, arbitrary request headers or stored CDN URL. */
final class VideoStream {
    static final long MAX_RESOURCE=16L*1024*1024*1024;
    enum Reason { OFFLINE, ACCESS, REQUEST, SEEK, RANGE, CHANGED, FORMAT, NETWORK, WAIT, SIZE }
    static final class Problem extends IOException {
        final Reason reason;final int httpStatus;
        Problem(Reason reason){this(reason,0);}
        Problem(Reason reason,int status){super(message(reason)+(status>=100&&status<=599?"\nHTTP: "+status+".":""));this.reason=reason;httpStatus=status>=100&&status<=599?status:0;}
    }
    static String message(Reason r){return switch(r){
        case OFFLINE->"Ver en línea necesita conexión. Desactiva Sin conexión o usa una copia preparada.";
        case ACCESS->"La fuente no permite abrir este video en línea. Puede requerir acceso en su sitio.";
        case REQUEST->"Peach no pudo preparar una solicitud compatible con el reproductor. Vuelve a abrir el video desde su publicación.";
        case SEEK->"La fuente no permite comprobar este salto del video. Vuelve a su publicación y usa Preparar y reproducir.";
        case RANGE->"La posición solicitada está fuera de este video. Vuelve a abrirlo desde la publicación.";
        case CHANGED->"El archivo o su servidor de entrega cambió durante la reproducción. Vuelve a abrirlo desde la publicación.";
        case FORMAT->"La fuente no devolvió un video MP4, WebM o Matroska compatible para reproducir en línea.";
        case WAIT->"La fuente pidió esperar. Vuelve a intentarlo más tarde desde la publicación.";
        case SIZE->"El archivo supera el límite de 16 GiB para reproducción en línea.";
        case NETWORK->"No se pudo mantener la conexión del video. Revisa internet y vuelve a abrirlo desde la publicación.";
    };}
    static final class Session implements AutoCloseable {
        final String url,key;final SourceHttp.ConnectionFactory factory;final MediaRedirects.Resolver resolver;final BooleanSupplier online;
        final Set<SourceHttp.Token> active=new HashSet<>();
        boolean enabled,closed,headerChecked;String etag="",modified="",target="",delivery="";long total=-1,retryAt;
        Session(String url,BooleanSupplier online){this(url,online,u->(HttpsURLConnection)new URL(u).openConnection(),InetAddress::getAllByName);}
        Session(String url,BooleanSupplier online,SourceHttp.ConnectionFactory factory,MediaRedirects.Resolver resolver){
            if(!SourceHttp.downloadable(url))throw new IllegalArgumentException("Video no admitido.");this.url=url;key=PartialDownload.key(url);this.online=online;this.factory=factory;this.resolver=resolver;
        }
        synchronized void resume(){if(!closed)enabled=true;}
        synchronized void pause(){enabled=false;for(var token:active)token.cancel();}
        @Override public synchronized void close(){closed=true;pause();delivery="";}
        synchronized void check(SourceHttp.Token token)throws IOException{token.check();if(closed||!enabled)throw new InterruptedIOException("Reproducción detenida.");if(!online.getAsBoolean())throw new Problem(Reason.OFFLINE);}
        Transfer open(long position)throws IOException {
            if(position<0||position>MAX_RESOURCE)throw new Problem(Reason.SIZE);
            SourceHttp.Token token=new SourceHttp.Token();synchronized(this){check(token);if(retryAt>System.currentTimeMillis())throw new Problem(Reason.WAIT);active.add(token);}
            boolean success=false;try{
                boolean probe;synchronized(this){probe=position>0&&!headerChecked;}
                if(probe)try(Transfer first=connect(0,token,false)){} // Header only, never the entire file.
                Transfer result=connect(position,token,true);success=true;return result;
            }catch(SourceHttp.Failure e){if(e.status==429){synchronized(this){retryAt=System.currentTimeMillis()+Math.min(86400,Math.max(1,e.retrySeconds))*1000L;}throw new Problem(Reason.WAIT,e.status);}throw new Problem(e.status==401||e.status==403?Reason.ACCESS:Reason.NETWORK,e.status);
            }catch(Problem e){throw e;}catch(IOException|RuntimeException e){throw new Problem(Reason.NETWORK);}
            finally{if(!success)finish(token);}
        }
        Transfer connect(long position,SourceHttp.Token token,boolean release)throws IOException {
            check(token);String validator;boolean checked;synchronized(this){validator=etag.isEmpty()?modified:etag;checked=headerChecked;}
            if(position>0&&checked&&validator.isEmpty()&&!PawchiveUrls.downloadable(url))throw new Problem(Reason.SEEK);
            HttpsURLConnection c=null;InputStream input=null;boolean success=false;
            try{c=connection(position,validator,token);check(token);
                int status=c.getResponseCode();long length=c.getContentLengthLong(),resource=length;String tag=SourceHttp.header(c.getHeaderField("ETag"));if(!PartialDownload.strong(tag))tag="";String date=tag.isEmpty()?strongDate(c.getHeaderField("Last-Modified"),c.getHeaderField("Date")):"";
                String finalKey=PartialDownload.key(c.getURL().toString());long expected=length;
                if(status==416){String raw=Objects.toString(c.getHeaderField("Content-Range"),"");long end=-1;try{if(raw.matches("bytes \\*/[0-9]{1,19}"))end=Long.parseLong(raw.substring(8));}catch(NumberFormatException ignored){}
                    synchronized(this){if(headerChecked&&position==end&&end==total){Transfer result=new Transfer(this,token,c,new ByteArrayInputStream(new byte[0]),0,position,release);c=null;success=true;return result;}}
                    throw new Problem(end>=0&&position>end?Reason.RANGE:Reason.SEEK);
                }
                if(position>0){var range=PartialDownload.range(c.getHeaderField("Content-Range"),MAX_RESOURCE);if(status!=206||range==null||range.start()!=position||range.end()!=range.total()-1||length>=0&&length!=range.end()-range.start()+1)throw new Problem(Reason.SEEK);resource=range.total();expected=range.end()-range.start()+1;}
                else if(status!=200)throw new Problem(Reason.FORMAT);
                if(resource>MAX_RESOURCE)throw new Problem(Reason.SIZE);if(resource==0)throw new Problem(Reason.FORMAT);
                String mime=Objects.toString(c.getContentType(),"").toLowerCase(Locale.ROOT),encoding=Objects.toString(c.getHeaderField("Content-Encoding"),"").trim();
                if(mime.contains("text/")||mime.contains("json")||mime.startsWith("multipart/")||mime.contains("mpegurl")||mime.contains("dash+xml")||!encoding.isEmpty()&&!encoding.equalsIgnoreCase("identity"))throw new Problem(Reason.FORMAT);
                synchronized(this){if(headerChecked&&(!target.equals(finalKey)||total>=0&&resource>=0&&total!=resource||!etag.isEmpty()&&!etag.equals(tag)||etag.isEmpty()&&!modified.isEmpty()&&!modified.equals(SourceHttp.header(c.getHeaderField("Last-Modified")))))throw new Problem(Reason.CHANGED);}
                input=c.getInputStream();
                if(position==0){byte[] head=new byte[(int)(expected>=0?Math.min(4096,expected):4096)];int count=0;
                    while(count<head.length){check(token);int n=input.read(head,count,head.length-count);if(n<0)break;if(n==0)continue;count+=n;}
                    if(expected>=0&&count<Math.min(expected,head.length))throw new Problem(Reason.NETWORK);
                    LocalMedia.Format format;try{format=LocalMedia.header(Arrays.copyOf(head,count));}catch(IOException e){throw new Problem(Reason.FORMAT);}
                    if(!"video".equals(format.kind()))throw new Problem(Reason.FORMAT);
                    input=new SequenceInputStream(new ByteArrayInputStream(head,0,count),input);
                }
                synchronized(this){check(token);if(!headerChecked){etag=tag;modified=date;target=finalKey;total=resource;headerChecked=true;}else if(total<0&&resource>=0)total=resource;if(MediaRedirects.videoSource(url))delivery=c.getURL().toString();}
                Transfer result=new Transfer(this,token,c,input,expected,position,release);c=null;input=null;success=true;return result;
            }finally{if(!success){if(input!=null)try{input.close();}catch(IOException ignored){}if(c!=null)c.disconnect();token.connection=null;}}
        }
        /**
         * Fecha de modificación usable como validador fuerte (RFC 9110 §8.8.2.2): solo si el servidor la envía
         * junto con su hora (Date) y es al menos 60 s anterior. Permite adelantar videos de servidores sin ETag
         * (p. ej. Rule34Video) sin renunciar a comprobar que el archivo no cambió: se envía en If-Range y se exige
         * la misma fecha, el mismo tamaño total y la misma dirección final en cada salto.
         */
        static String strongDate(String lastModified,String date){
            String value=SourceHttp.header(lastModified),now=SourceHttp.header(date);if(value.isEmpty()||now.isEmpty()||value.length()>64)return "";
            try{var f=java.time.format.DateTimeFormatter.RFC_1123_DATE_TIME;long changed=java.time.ZonedDateTime.parse(value,f).toEpochSecond(),served=java.time.ZonedDateTime.parse(now,f).toEpochSecond();return served-changed>=60?value:"";}
            catch(RuntimeException e){return "";}
        }
        HttpsURLConnection connection(long position,String validator,SourceHttp.Token token)throws IOException {
            String hint;synchronized(this){hint=delivery;}
            if(!hint.isEmpty()&&!hint.equals(url))try{return SourceHttp.openDelivery(url,hint,token,factory,resolver,position,validator);}catch(SourceHttp.Failure e){if(!Set.of(403,404,410).contains(e.status))throw e;synchronized(this){delivery="";}token.check();}
            return SourceHttp.open(url,"","",token,false,factory,resolver,position,validator);
        }
        synchronized void finish(SourceHttp.Token token){token.cancel();active.remove(token);}
    }
    static final class Transfer implements AutoCloseable {
        final Session session;final SourceHttp.Token token;final HttpsURLConnection connection;final InputStream input;final long position,length;final boolean release;
        long read;boolean closed;
        Transfer(Session session,SourceHttp.Token token,HttpsURLConnection connection,InputStream input,long length,long position,boolean release){this.session=session;this.token=token;this.connection=connection;this.input=input;this.length=length;this.position=position;this.release=release;}
        int read(byte[] bytes,int offset,int count)throws IOException {
            if(offset<0||count<0||offset>bytes.length-count)throw new IndexOutOfBoundsException();if(count==0)return 0;if(closed)throw new IOException("Lectura cerrada.");session.check(token);if(length>=0&&read==length)return -1;
            int wanted=length>=0?(int)Math.min(count,length-read):count,n;
            try{n=input.read(bytes,offset,wanted);session.check(token);}catch(Problem e){throw e;}catch(IOException e){throw new Problem(Reason.NETWORK);}
            if(n<0){if(length>=0&&read<length)throw new Problem(Reason.NETWORK);return -1;}
            if(position+read>MAX_RESOURCE-n)throw new Problem(Reason.SIZE);read+=n;return n;
        }
        @Override public void close(){if(closed)return;closed=true;try{input.close();}catch(IOException ignored){}finally{connection.disconnect();token.connection=null;if(release)session.finish(token);}}
    }
}
