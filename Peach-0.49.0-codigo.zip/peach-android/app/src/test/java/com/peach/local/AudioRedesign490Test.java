package com.peach.local;

import android.content.Intent;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.view.View;
import android.widget.TextView;
import androidx.media3.session.*;
import com.google.common.util.concurrent.ListenableFuture;
import java.io.ByteArrayInputStream;
import org.junit.*;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowLooper;
import static org.junit.Assert.*;

/** Reproductor de audio 0.49: portada, controles propios y mini reproductor "Reproduciendo ahora". */
@Config(sdk=28,qualifiers="w1280dp-h800dp-land-mdpi") @GraphicsMode(GraphicsMode.Mode.NATIVE)
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public class AudioRedesign490Test extends AudioTestSupport {
    public static class TestAudioActivity extends AudioActivity {static AudioService service;@Override protected ListenableFuture<MediaController> connect(){return new MediaController.Builder(this,service.session().getToken()).buildAsync();}}
    void loaded(AudioActivity a)throws Exception{for(int i=0;i<300&&!a.findViewById(R.id.audioStop).isEnabled();i++){idle();Thread.sleep(5);}assertTrue(a.findViewById(R.id.audioStop).isEnabled());}
    MediaEntry withCover(String id,String title,int color){
        MediaEntry row=new MediaEntry();row.id=id;row.name=id+".mp3";row.title=title;row.uri="content://fixture/"+id;row.mediaType=MediaRules.AUDIO;
        row.poster="content://own490-art/"+id;byte[] bytes=Redesign490Test.png(color,"PEACH");Shadows.shadowOf(RuntimeEnvironment.getApplication().getContentResolver()).registerInputStreamSupplier(Uri.parse(row.poster),()->new ByteArrayInputStream(bytes));
        db.library().insertMedia(row);return row;
    }
    @Test public void playerShowsCoverToneAndPlayPauseControlsTheSharedService()throws Exception{
        withCover("c","Luz del desierto",0xff8a4fd0);TestAudioActivity.service=service;UiAppearance.prefs(RuntimeEnvironment.getApplication()).edit().putInt("motion",0).commit();
        Intent intent=new Intent(RuntimeEnvironment.getApplication(),TestAudioActivity.class).putExtra("mediaId","c");
        try(var screen=Robolectric.buildActivity(TestAudioActivity.class,intent).setup().visible()){
            TestAudioActivity a=screen.get();loaded(a);
            assertTrue(((TextView)a.findViewById(R.id.playerTitle)).getText().toString().contains("Luz del desierto"));
            assertEquals(View.GONE,a.findViewById(R.id.subtitle).getVisibility());
            android.widget.ImageView cover=a.findViewById(R.id.audio_cover);
            for(int i=0;i<300&&!(cover.getDrawable() instanceof TransitionDrawable||cover.getDrawable() instanceof BitmapDrawable);i++){AudioArt.IO.submit(()->{}).get();idle();Thread.sleep(5);}
            assertTrue("La portada del audio se muestra",cover.getDrawable() instanceof TransitionDrawable||cover.getDrawable() instanceof BitmapDrawable);
            assertTrue(service.engine.getPlayWhenReady());
            a.findViewById(R.id.audio_play).performClick();idle();assertFalse(service.engine.getPlayWhenReady());
            assertEquals("Reproducir",a.findViewById(R.id.audio_play).getContentDescription().toString());
            a.findViewById(R.id.audio_play).performClick();idle();assertTrue(service.engine.getPlayWhenReady());
            ShadowLooper.idleMainLooper(1,java.util.concurrent.TimeUnit.SECONDS);
            View root=a.findViewById(android.R.id.content);root.measure(View.MeasureSpec.makeMeasureSpec(1280,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(800,View.MeasureSpec.EXACTLY));root.layout(0,0,1280,800);idle();
            root.measure(View.MeasureSpec.makeMeasureSpec(1280,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(800,View.MeasureSpec.EXACTLY));root.layout(0,0,1280,800);idle();
            Redesign490Test.render(root,"audio-player",1280,800);
            a.findViewById(R.id.audioStop).performClick();idle();assertTrue(a.isFinishing());assertNull(AudioService.liveToken());
        }
    }
    @Test public void miniPlayerAppearsOnlyWithActiveAudioAndOpensThePlayer()throws Exception{
        var context=RuntimeEnvironment.getApplication();androidx.work.testing.WorkManagerTestInitHelper.initializeTestWorkManager(context,new androidx.work.Configuration.Builder().setExecutor(Runnable::run).setTaskExecutor(Runnable::run).build());
        try{
            assertNotNull(AudioService.liveToken());
            try(var screen=Robolectric.buildActivity(MainActivity.class).setup().visible()){idle();assertEquals(View.GONE,screen.get().findViewById(R.id.now_playing).getVisibility());}
            withCover("d","La costa",0xff2f7f6a);await(service.select(AudioSelectionTest.args("d")));idle();
            try(var screen=Robolectric.buildActivity(MainActivity.class).setup().visible()){MainActivity a=screen.get();
                View bar=a.findViewById(R.id.now_playing);for(int i=0;i<300&&bar.getVisibility()!=View.VISIBLE;i++){idle();Thread.sleep(5);}
                assertEquals(View.VISIBLE,bar.getVisibility());assertTrue(bar.getContentDescription().toString().contains("La costa"));
                a.findViewById(R.id.now_playing_toggle).performClick();idle();assertFalse(service.engine.getPlayWhenReady());
                bar.performClick();Intent opened=Shadows.shadowOf(a).getNextStartedActivity();assertEquals(AudioActivity.class.getName(),opened.getComponent().getClassName());assertNull(opened.getStringExtra("mediaId"));
                for(int i=0;i<100;i++){AudioArt.IO.submit(()->{}).get();idle();}
                View root=a.findViewById(android.R.id.content);root.measure(View.MeasureSpec.makeMeasureSpec(1280,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(800,View.MeasureSpec.EXACTLY));root.layout(0,0,1280,800);idle();
                Redesign490Test.render(root,"library-now-playing",1280,800);
                // Al salir de la pantalla se conserva el último estado (sin parpadeo al cambiar de pestaña)…
                screen.pause().stop();assertEquals(View.VISIBLE,bar.getVisibility());
            }
            // …y cuando el audio se detiene de verdad, la barra ya no aparece en ninguna pantalla.
            MediaController c=controller();await(c.sendCustomCommand(AudioService.STOP,android.os.Bundle.EMPTY));idle();assertNull(AudioService.liveToken());
            try(var screen=Robolectric.buildActivity(MainActivity.class).setup().visible()){idle();assertEquals(View.GONE,screen.get().findViewById(R.id.now_playing).getVisibility());
            }
        }finally{idle();androidx.work.testing.WorkManagerTestInitHelper.closeWorkDatabase();UiAppearance.prefs(RuntimeEnvironment.getApplication()).edit().clear().commit();}
    }
    @Test public void sleepTimerQueueAndFavoriteWorkFromTheAudioScreen()throws Exception{
        TestAudioActivity.service=service;UiAppearance.prefs(RuntimeEnvironment.getApplication()).edit().putInt("motion",0).commit();
        Intent intent=new Intent(RuntimeEnvironment.getApplication(),TestAudioActivity.class).putExtra("mediaId","a");
        try(var screen=Robolectric.buildActivity(TestAudioActivity.class,intent).setup().visible()){
            TestAudioActivity a=screen.get();loaded(a);
            MediaController c=controller();android.os.Bundle args=new android.os.Bundle();args.putInt("minutes",30);
            assertEquals(SessionResult.RESULT_SUCCESS,await(c.sendCustomCommand(AudioService.SLEEP,args)).resultCode);
            assertTrue(AudioService.sleepAt()>System.currentTimeMillis()+29*60_000L);
            ShadowLooper.idleMainLooper(30,java.util.concurrent.TimeUnit.MINUTES);idle();assertFalse(service.engine.getPlayWhenReady());assertEquals(0,AudioService.sleepAt());
            args.putInt("minutes",-1);await(c.sendCustomCommand(AudioService.SLEEP,args));assertTrue(AudioService.sleepAtEnd());
            args.putInt("minutes",0);await(c.sendCustomCommand(AudioService.SLEEP,args));assertFalse(AudioService.sleepAtEnd());assertEquals(0,AudioService.sleepAt());
            for(int i=0;i<50;i++){idle();}
            a.findViewById(R.id.audio_favorite).performClick();idle();assertTrue(db.library().get("a").favorite);
            assertEquals("Quitar de favoritos",a.findViewById(R.id.audio_favorite).getContentDescription().toString());
            a.findViewById(R.id.audio_more).performClick();var popup=org.robolectric.shadows.ShadowPopupMenu.getLatestPopupMenu();assertEquals(4,popup.getMenu().size());
            org.robolectric.shadows.ShadowPopupMenu shadow=Shadows.shadowOf(popup);assertNotNull(shadow);
            assertTrue(popup.getMenu().findItem(3).isEnabled());assertTrue(popup.getMenu().findItem(4).isEnabled());
        }
    }
    @Test public void buttonsStayStillWhilePlayingInsteadOfFlickering()throws Exception{
        TestAudioActivity.service=service;Intent intent=new Intent(RuntimeEnvironment.getApplication(),TestAudioActivity.class).putExtra("mediaId","a");
        try(var screen=Robolectric.buildActivity(TestAudioActivity.class,intent).setup().visible()){
            TestAudioActivity a=screen.get();loaded(a);View root=a.findViewById(android.R.id.content);
            root.measure(View.MeasureSpec.makeMeasureSpec(1280,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(800,View.MeasureSpec.EXACTLY));root.layout(0,0,1280,800);idle();
            assertTrue(service.engine.getPlayWhenReady());
            int[] ids={R.id.audio_timer,R.id.audio_shuffle,R.id.audio_repeat,R.id.audio_queue,R.id.audio_play,R.id.audio_favorite};
            Object[] icons=new Object[ids.length],backs=new Object[ids.length];int[] pads=new int[ids.length];
            for(int i=0;i<ids.length;i++){android.widget.Button b=a.findViewById(ids[i]);icons[i]=b.getCompoundDrawables()[0];backs[i]=b.getBackground();pads[i]=b.getPaddingLeft();}
            // Varios "tics" del reloj del reproductor (cada 0,5 s) con la música sonando.
            for(int n=0;n<10;n++){ShadowLooper.idleMainLooper(500,java.util.concurrent.TimeUnit.MILLISECONDS);root.layout(0,0,1280,800);}
            for(int i=0;i<ids.length;i++){android.widget.Button b=a.findViewById(ids[i]);String name=a.getResources().getResourceEntryName(ids[i]);
                assertSame("Icono estable: "+name,icons[i],b.getCompoundDrawables()[0]);assertSame("Fondo estable: "+name,backs[i],b.getBackground());assertEquals("Posición estable: "+name,pads[i],b.getPaddingLeft());}
            assertTrue("El icono queda centrado",((android.widget.Button)a.findViewById(R.id.audio_timer)).getPaddingLeft()>0);
        }
    }
    @Test public void embeddedArtworkIsBoundedAndGreyCoversKeepTheChosenAccent(){
        Bitmap big=Bitmap.createBitmap(3000,1500,Bitmap.Config.ARGB_8888);big.eraseColor(0xff3366cc);var out=new java.io.ByteArrayOutputStream();big.compress(Bitmap.CompressFormat.PNG,100,out);
        Bitmap decoded=AudioArt.decode(out.toByteArray(),900);assertNotNull(decoded);assertTrue(Math.max(decoded.getWidth(),decoded.getHeight())<=900);
        assertNull(AudioArt.decode(new byte[]{1,2,3},900));assertNull(AudioArt.decode(null,900));
        int tone=AudioArt.tone(decoded,0xff112233);assertNotEquals(0xff112233,tone);float[] hsv=new float[3];Color.colorToHSV(tone,hsv);assertTrue(hsv[2]>=0.78f);
        Bitmap grey=Bitmap.createBitmap(40,40,Bitmap.Config.ARGB_8888);grey.eraseColor(0xff808080);assertEquals(0xff112233,AudioArt.tone(grey,0xff112233));
    }
}
