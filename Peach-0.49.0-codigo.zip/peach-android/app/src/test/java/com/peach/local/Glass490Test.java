package com.peach.local;

import android.content.Context;
import android.graphics.*;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView;
import java.io.*;
import java.util.concurrent.TimeUnit;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;

import static org.junit.Assert.*;

/** Ronda cristal 0.49: barra fija idéntica en las cuatro secciones, cristal y miniaturas de video en Fuentes. */
@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land-mdpi") @SQLiteMode(SQLiteMode.Mode.LEGACY) @GraphicsMode(GraphicsMode.Mode.NATIVE)
public class Glass490Test {
    LibraryUiTest fixture;Context app;LibraryDatabase db;SourceHttp.Transport previous;GalleryCache.Fetcher previousImages;
    @Before public void setup(){app=RuntimeEnvironment.getApplication();UiAppearance.prefs(app).edit().clear().putInt("motion",0).commit();fixture=new LibraryUiTest();fixture.initializeScheduler();db=LibraryDatabase.get(app);
        previous=SourcesActivity.transport;previousImages=SourcePreviewLoader.fetcher;SourcesActivity.transport=(u,e,m,t)->{throw new IOException("Sin red en pruebas");};SourcePreviewLoader.fetcher=(u,f,t)->{throw new IOException("Sin red en pruebas");};SourcePreviewLoader.clearMemory();}
    @After public void close()throws Exception{SourcesActivity.transport=previous;SourcePreviewLoader.fetcher=previousImages;fixture.closeFixture();UiAppearance.prefs(app).edit().clear().commit();}
    static void idle()throws Exception{for(int i=0;i<3;i++){LibraryDatabase.IO.submit(()->{}).get(10,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}}
    static void layout(android.app.Activity a){View v=a.getWindow().getDecorView();v.measure(View.MeasureSpec.makeMeasureSpec(1280,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(800,View.MeasureSpec.EXACTLY));v.layout(0,0,1280,800);v.getViewTreeObserver().dispatchOnGlobalLayout();Shadows.shadowOf(Looper.getMainLooper()).idle();v.measure(View.MeasureSpec.makeMeasureSpec(1280,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(800,View.MeasureSpec.EXACTLY));v.layout(0,0,1280,800);v.getViewTreeObserver().dispatchOnGlobalLayout();Shadows.shadowOf(Looper.getMainLooper()).idle();}
    static Rect dock(android.app.Activity a){View d=a.findViewById(R.id.nav_dock);assertNotNull("Barra fija presente",d);int[] at=new int[2];d.getLocationInWindow(at);
        View bar=a.findViewById(R.id.navLibrary)!=null?(View)a.findViewById(R.id.navLibrary).getParent():null;return new Rect(at[0],at[1]+d.getHeight()-(bar==null?0:bar.getHeight()),at[0]+d.getWidth(),at[1]+d.getHeight());}
    static Rect barOf(android.app.Activity a){View d=a.findViewById(R.id.nav_dock);ViewGroup stack=(ViewGroup)d;View bar=stack.getChildAt(stack.getChildCount()-1);int[] at=new int[2];bar.getLocationInWindow(at);return new Rect(at[0],at[1],at[0]+bar.getWidth(),at[1]+bar.getHeight());}

    @Test public void bottomBarHasTheSamePlaceAndSizeInAllFourSectionsAndLivesOutsideTheContent()throws Exception{
        Rect library,sources,downloads,settings;
        try(var c=Robolectric.buildActivity(MainActivity.class).setup().visible()){idle();layout(c.get());library=barOf(c.get());
            assertEquals(c.get().findViewById(android.R.id.content),c.get().findViewById(R.id.nav_dock).getParent());assertNotNull(c.get().findViewById(R.id.navSources));}
        try(var c=Robolectric.buildActivity(SourceBrowserActivity.class).setup().visible()){layout(c.get());sources=barOf(c.get());shutdown(c.get());}
        try(var c=Robolectric.buildActivity(DownloadQueueActivity.class).setup().visible()){layout(c.get());downloads=barOf(c.get());}
        try(var c=Robolectric.buildActivity(SettingsActivity.class).setup().visible()){layout(c.get());settings=barOf(c.get());}
        assertTrue("La barra tiene tamaño real: "+library,library.width()>600&&library.height()>=48&&library.height()<=100&&library.top>600);
        assertEquals(library,sources);assertEquals(library,downloads);assertEquals(library,settings);
    }
    @Test public void listsReachBehindTheBarAndNonScrollingScreensReserveSpaceWithoutGrowingForever()throws Exception{
        try(var c=Robolectric.buildActivity(SettingsActivity.class).setup().visible()){layout(c.get());View scroll=PeachDesign.scrollable(c.get().findViewById(R.id.settings_root),c.get().findViewById(R.id.nav_spacer));
            assertTrue(scroll instanceof android.widget.ScrollView);assertTrue(scroll.getPaddingBottom()>=c.get().findViewById(R.id.nav_dock).getHeight()/2);assertFalse(((ViewGroup)scroll).getClipToPadding());}
        try(var c=Robolectric.buildActivity(DownloadQueueActivity.class).setup().visible()){layout(c.get());View spacer=c.get().findViewById(R.id.nav_spacer);
            assertTrue(spacer.getHeight()>0);assertTrue("Acotado a la barra",spacer.getHeight()<=800-c.get().findViewById(R.id.nav_dock).getTop()+8);}
    }
    @Test public void glassCapturesTheContentBehindAndClassicStaysSolid()throws Exception{
        try(var c=Robolectric.buildActivity(SettingsActivity.class).setup().visible()){layout(c.get());for(int i=0;i<5;i++){Shadows.shadowOf(Looper.getMainLooper()).idleFor(java.time.Duration.ofMillis(400));}
            assertTrue("Capa difuminada",panel(c.get()).getBackground() instanceof android.graphics.drawable.LayerDrawable);}
        UiAppearance.prefs(app).edit().putInt("style",0).commit();
        try(var c=Robolectric.buildActivity(SettingsActivity.class).setup().visible()){layout(c.get());Shadows.shadowOf(Looper.getMainLooper()).idleFor(java.time.Duration.ofMillis(800));assertFalse(panel(c.get()).getBackground() instanceof android.graphics.drawable.LayerDrawable&&((android.graphics.drawable.LayerDrawable)panel(c.get()).getBackground()).getDrawable(0) instanceof android.graphics.drawable.BitmapDrawable);assertEquals(0xff,Glass.tint(app)>>>24);}
        Bitmap b=Bitmap.createBitmap(8,4,Bitmap.Config.ARGB_8888);b.eraseColor(0xff000000);b.setPixel(0,0,0xffffffff);int[] px=Glass.blurred(b,1);assertTrue((px[0]&0xff)<255&&(px[1]&0xff)>0);
    }
    static View panel(android.app.Activity a){ViewGroup stack=(ViewGroup)a.findViewById(R.id.nav_dock);return stack.getChildAt(stack.getChildCount()-1);}
    @Test public void declaredVideoPosterBecomesPreviewOnlyFromTheSitesOwnServers()throws Exception{
        String url="https://www.patreon.com/artist/posts/own-1234",media="https://c10.patreonusercontent.com/4/patreon-media/p/post/1234/";
        String html="<link rel='canonical' href='"+url+"'><div class='patreon-post-content'><p>Own</p><video src='"+media+"own.mp4' poster='"+media+"own-poster.jpg'></video><video src='"+media+"two.mp4' poster='https://evil.test/x.jpg'></video></div>";
        JSONArray a=VisiblePostBody.parse("patreon","artist","1234",url,html).getJSONArray("attachments");
        assertEquals(media+"own-poster.jpg",a.getJSONObject(0).getJSONObject("peachPreview").getString("url"));assertFalse(a.getJSONObject(1).has("peachPreview"));
        Publication p=SourceDesign480Test.post("poster490","patreon","artist","Con portada");PublicationContent body=new PublicationContent();body.publicationId=p.id;body.attachments=a.toString();
        assertEquals(media+"own-poster.jpg",SourcePreviewLoader.image(p,body).url());
    }
    @Test public void localFramesAreReusedAndNeverRequireTheNetwork()throws Exception{
        File cache=app.getCacheDir();String url="https://downloads.fanbox.cc/files/post/1/own490.mp4";
        assertNull(SourceVideoFrames.local(cache,url));
        File dir=new File(cache,"peach-video-frames");dir.mkdirs();Bitmap frame=Bitmap.createBitmap(64,36,Bitmap.Config.ARGB_8888);frame.eraseColor(0xff336699);
        try(var out=new FileOutputStream(new File(dir,VideoCache.keyFor(url)+".jpg"))){frame.compress(Bitmap.CompressFormat.JPEG,90,out);}
        assertNotNull(SourceVideoFrames.local(cache,url));
        File videos=new File(cache,"peach-source-video");videos.mkdirs();String key=VideoCache.keyFor("https://downloads.fanbox.cc/files/post/1/other.mp4");
        new File(videos,key+".meta").createNewFile();assertNull(SourceVideoFrames.cached(videos,key));
        try(var out=new FileOutputStream(new File(videos,key+".mp4"))){out.write(new byte[]{1});}assertNotNull(SourceVideoFrames.cached(videos,key));
        assertTrue(SourceVideoFrames.clear(cache)>=1);
    }
    @Test public void videoPostsWithoutImagesShowAVideoTileInsteadOfAFileIcon()throws Exception{
        var store=new SourceStore(db,SourcesActivity.transport);String source=store.create("artist","Estudio de campo",null);
        for(int n=0;n<4;n++){Publication p=SourceDesign480Test.post("video490-"+n,"fanbox","artist",n==0?"Clip de campo":"Entrega "+n);p.sourceLabel="Estudio de campo";p.publishedAt="2026-10-2"+n;p.precision="approximate";db.library().insertPublication(p);
            PublicationContent c=new PublicationContent();c.publicationId=p.id;c.sourceId=source;c.text="Muestra";c.attachments=new JSONArray().put(new JSONObject().put("name","clip.mp4").put("url","https://downloads.fanbox.cc/files/post/"+n+"/clip.mp4").put("kind","video").put("downloadable",true)).toString();db.library().putPublicationContent(c);}
        Publication p=db.library().publications().get(0);PublicationContent c=db.library().publicationContent(p.id);assertNotNull(SourcePreviewLoader.firstVideo(p,c));
        try(var screen=Robolectric.buildActivity(SourceBrowserActivity.class).setup().visible()){var a=screen.get();idle();layout(a);
            // Camino real: en el inicio aparece la tarjeta de la fuente; al tocarla se ven sus publicaciones.
            var d=new androidx.lifecycle.ViewModelProvider(a).get(SourceBrowserActivity.Draft.class);
            // Espera a que la pantalla termine de cargar sus fuentes en segundo plano antes de buscar la tarjeta.
            for(int i=0;i<3;i++){d.worker.submit(()->{}).get(20,TimeUnit.SECONDS);idle();}
            if(!d.home){a.findViewById(R.id.browser_home).performClick();for(int i=0;i<3;i++){d.worker.submit(()->{}).get(20,TimeUnit.SECONDS);idle();}}layout(a);
            View card=Browser480Test.find(a.findViewById(R.id.browser_grid),v->v.isClickable()&&Browser480Test.find(v,t->t instanceof android.widget.TextView tv&&tv.getText().toString().equals("Estudio de campo"))!=null);
            assertNotNull("Tarjeta de la fuente en el inicio",card);card.performClick();for(int i=0;i<3;i++){d.worker.submit(()->{}).get(20,TimeUnit.SECONDS);idle();}layout(a);Thread.sleep(200);idle();layout(a);
            assertFalse(d.home);
            RecyclerView grid=a.findViewById(R.id.browser_grid);assertTrue(grid.getAdapter().getItemCount()>=4);
            boolean tile=Browser480Test.find(grid,v->v instanceof ImageView i&&i.getDrawable() instanceof SourcePreviewLoader.VideoTile)!=null;assertTrue("Tarjeta de video visible",tile);
            Redesign490Test.render(a.findViewById(android.R.id.content),"sources-video",1280,800);shutdown(a);}
        Bitmap canvasTarget=Bitmap.createBitmap(160,90,Bitmap.Config.ARGB_8888);var t=new SourcePreviewLoader.VideoTile(app);t.setBounds(0,0,160,90);t.draw(new Canvas(canvasTarget));assertNotEquals(0,canvasTarget.getPixel(80,45));
    }
    static void shutdown(SourceBrowserActivity a)throws Exception{var draft=new androidx.lifecycle.ViewModelProvider(a).get(SourceBrowserActivity.Draft.class);draft.token.cancel();draft.worker.shutdown();draft.worker.awaitTermination(20,TimeUnit.SECONDS);}
    static void shutdown(android.app.Activity a)throws Exception{if(a instanceof SourceBrowserActivity s)shutdown(s);}
    @Test public void renderGlassScreens()throws Exception{
        Redesign490Test r=new Redesign490Test();r.app=app;r.fixture=fixture;r.library();
        for(String mode:new String[]{"dark","light"}){UiAppearance.prefs(app).edit().putInt("mode",mode.equals("dark")?1:2).putInt("motion",0).commit();
            try(var c=Robolectric.buildActivity(MainActivity.class).setup().visible()){idle();Redesign490Test.chip(c.get(),"Todo").performClick();idle();layout(c.get());Thread.sleep(300);idle();layout(c.get());
                for(int i=0;i<4;i++)Shadows.shadowOf(Looper.getMainLooper()).idleFor(java.time.Duration.ofMillis(400));layout(c.get());
                Redesign490Test.render(c.get().getWindow().getDecorView(),"glass-library-"+mode,1280,800);}}
        UiAppearance.prefs(app).edit().putInt("mode",1).commit();
        try(var c=Robolectric.buildActivity(AppearanceActivity.class).setup().visible()){layout(c.get());Redesign490Test.render(c.get().getWindow().getDecorView(),"appearance-glass",1280,800);}
    }
}
