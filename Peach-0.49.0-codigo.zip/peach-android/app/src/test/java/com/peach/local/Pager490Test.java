package com.peach.local;

import android.content.Context;
import android.os.Looper;
import android.view.View;
import android.widget.TextView;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

/** Paginación de Fuentes 0.49: página actual, números de publicación y volver atrás sin red. */
@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land-mdpi") @SQLiteMode(SQLiteMode.Mode.LEGACY) @GraphicsMode(GraphicsMode.Mode.NATIVE)
public class Pager490Test {
    LibraryUiTest fixture;Context app;SourceHttp.Transport previous;GalleryCache.Fetcher previousImages;SourceBrowserActivity activity;
    final ArrayDeque<SourceHttp.Response> replies=new ArrayDeque<>();final List<String> urls=new ArrayList<>();
    static final String PAGE="https://api.fanbox.cc/post.listCreator?creatorId=artist&limit=10&firstId=";
    @Before public void setup()throws Exception{app=RuntimeEnvironment.getApplication();UiAppearance.prefs(app).edit().clear().putInt("motion",0).commit();
        app.getSharedPreferences("source-browser",0).edit().clear().commit();app.getSharedPreferences("source-pages",0).edit().clear().commit();
        fixture=new LibraryUiTest();fixture.initializeScheduler();previous=SourcesActivity.transport;previousImages=SourcePreviewLoader.fetcher;SourcePreviewLoader.clearMemory();
        SourcesActivity.transport=(u,e,m,t)->{urls.add(u);SourceHttp.Response r=replies.poll();if(r==null)throw new java.io.IOException("Sin respuesta preparada");return r;};
        SourcePreviewLoader.fetcher=(u,f,t)->{throw new java.io.IOException("Sin red en pruebas");};}
    @After public void close()throws Exception{if(activity!=null){var d=draft();d.token.cancel();d.worker.shutdown();d.worker.awaitTermination(20,TimeUnit.SECONDS);}SourcesActivity.transport=previous;SourcePreviewLoader.fetcher=previousImages;fixture.closeFixture();UiAppearance.prefs(app).edit().clear().commit();}
    SourceBrowserActivity.Draft draft(){return new ViewModelProvider(activity).get(SourceBrowserActivity.Draft.class);}
    void idle()throws Exception{var d=draft();for(int i=0;i<4;i++){d.worker.submit(()->{}).get(20,TimeUnit.SECONDS);org.robolectric.Shadows.shadowOf(Looper.getMainLooper()).idle();}Glass490Test.layout(activity);}
    /** Una página de FANBOX con publicaciones numeradas de {@code from} hacia abajo. */
    void page(int from,int count)throws Exception{JSONArray posts=new JSONArray();for(int n=0;n<count;n++)posts.put(FanboxConnectorTest.post(String.valueOf(from-n)).put("title","Publicación "+(from-n)));replies.add(FanboxConnectorTest.response(new JSONObject().put("posts",posts)));}
    String label(){return ((TextView)activity.findViewById(R.id.browser_page)).getText().toString();}
    Set<String> numbers(){Set<String> out=new TreeSet<>();RecyclerView grid=activity.findViewById(R.id.browser_grid);collect(grid,out);return out;}
    void collect(View v,Set<String> out){if(v.getId()==R.id.card_number&&v instanceof TextView t)out.add(t.getText().toString());if(v instanceof android.view.ViewGroup g)for(int i=0;i<g.getChildCount();i++)collect(g.getChildAt(i),out);}

    @Test public void pagesShowWhereYouAreNumberEachPostAndGoBackWithoutTheNetwork()throws Exception{
        page(30,10);
        try(var c=Robolectric.buildActivity(SourceBrowserActivity.class).setup().visible()){activity=c.get();idle();
            ((android.widget.EditText)activity.findViewById(R.id.browser_search)).setText("artist");activity.findViewById(R.id.browser_go).performClick();idle();
            assertEquals("Página 1 · publicaciones 1–10",label());assertTrue(numbers().contains("#1"));assertTrue(numbers().contains("#10"));
            assertFalse("En la página 1 no hay anterior",activity.findViewById(R.id.browser_newer).isEnabled());assertTrue(activity.findViewById(R.id.browser_older).isEnabled());
            // Siguiente → página 2 (consulta la fuente: índice de páginas + la página).
            replies.add(FanboxConnectorTest.response(new JSONObject().put("pageUrls",new JSONArray().put(PAGE+"30").put(PAGE+"20").put(PAGE+"10"))));page(20,10);
            activity.findViewById(R.id.browser_older).performClick();idle();
            assertEquals("Página 2 · publicaciones 11–20",label());assertTrue(numbers().contains("#11"));assertFalse(numbers().contains("#1"));
            assertTrue(((TextView)activity.findViewById(R.id.browser_status)).getText().toString().contains("publicaciones 11–20"));
            // Siguiente → página 3.
            page(10,7);activity.findViewById(R.id.browser_older).performClick();idle();
            assertEquals("Página 3 · publicaciones 21–27",label());int requests=urls.size();
            Redesign490Test.render(activity.findViewById(android.R.id.content),"sources-pager",1280,800);
            // Anterior → página 2 y luego página 1: desde memoria, sin consultar la red.
            activity.findViewById(R.id.browser_newer).performClick();idle();assertEquals("Página 2 · publicaciones 11–20",label());assertTrue(numbers().contains("#20"));
            activity.findViewById(R.id.browser_newer).performClick();idle();assertEquals("Página 1 · publicaciones 1–10",label());assertTrue(numbers().contains("#1"));
            assertEquals("Volver atrás no consulta la fuente",requests,urls.size());
            // Siguiente otra vez: también desde memoria hasta llegar a la última cargada.
            activity.findViewById(R.id.browser_older).performClick();idle();assertEquals("Página 2 · publicaciones 11–20",label());
            activity.findViewById(R.id.browser_older).performClick();idle();assertEquals("Página 3 · publicaciones 21–27",label());assertEquals(requests,urls.size());
            assertTrue(((TextView)activity.findViewById(R.id.browser_title)).getText().length()>0);
            assertTrue(((TextView)activity.findViewById(R.id.browser_status)).getText().toString().contains("Página 3"));
        }
    }
    @Test public void refreshingFromPageOneRestartsNumberingBecausePositionsMayChange()throws Exception{
        page(30,10);
        try(var c=Robolectric.buildActivity(SourceBrowserActivity.class).setup().visible()){activity=c.get();idle();
            ((android.widget.EditText)activity.findViewById(R.id.browser_search)).setText("artist");activity.findViewById(R.id.browser_go).performClick();idle();
            replies.add(FanboxConnectorTest.response(new JSONObject().put("pageUrls",new JSONArray().put(PAGE+"30").put(PAGE+"20"))));page(20,10);activity.findViewById(R.id.browser_older).performClick();idle();
            assertEquals("Página 2 · publicaciones 11–20",label());
            page(32,10);activity.findViewById(R.id.browser_refresh).performClick();idle();
            assertEquals("Página 1 · publicaciones 1–10",label());assertFalse("La página 2 vieja ya no se ofrece desde memoria",draft().pages.containsKey(1));
        }
    }
}
