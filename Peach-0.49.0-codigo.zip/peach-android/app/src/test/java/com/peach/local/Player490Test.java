package com.peach.local;

import android.content.Context;
import android.net.Uri;
import android.os.Looper;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowDialog;
import org.robolectric.util.ReflectionHelpers;
import static org.junit.Assert.*;

/** Reproductor de video y botones 0.49: gestos, controles y estilos compartidos. */
@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land-mdpi") @SQLiteMode(SQLiteMode.Mode.LEGACY) @GraphicsMode(GraphicsMode.Mode.NATIVE)
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public class Player490Test {
    LibraryUiTest fixture;Context app;
    @Before public void setup(){app=RuntimeEnvironment.getApplication();UiAppearance.prefs(app).edit().clear().putInt("motion",0).commit();fixture=new LibraryUiTest();fixture.initializeScheduler();}
    @After public void close()throws Exception{fixture.closeFixture();UiAppearance.prefs(app).edit().clear().commit();}
    static void tap(View v,float x,long time){MotionEvent down=MotionEvent.obtain(time,time,MotionEvent.ACTION_DOWN,x,300,0);MotionEvent up=MotionEvent.obtain(time,time+40,MotionEvent.ACTION_UP,x,300,0);v.dispatchTouchEvent(down);v.dispatchTouchEvent(up);down.recycle();up.recycle();}
    static void layout(View root){root.measure(View.MeasureSpec.makeMeasureSpec(1280,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(800,View.MeasureSpec.EXACTLY));root.layout(0,0,1280,800);Shadows.shadowOf(Looper.getMainLooper()).idle();}

    @Test public void doubleTapInTheMiddlePausesAndShowsFeedbackWhileSidesNeverCrashWithoutMedia(){
        try(var screen=Robolectric.buildActivity(PlayerActivity.class,SourceFiles.play(app,Uri.parse("content://own.player490/video"),"own.mp4")).create().visible()){
            PlayerActivity a=screen.get();ExoPlayer player=new ExoPlayer.Builder(a).build();ReflectionHelpers.setField(a,"player",player);player.setPlayWhenReady(true);
            PlayerView view=a.findViewById(R.id.player);layout(a.findViewById(android.R.id.content));
            long now=SystemClock.uptimeMillis();tap(view,640,now);tap(view,640,now+120);
            assertFalse(player.getPlayWhenReady());TextView hint=a.findViewById(R.id.player_seek_hint);assertEquals(View.VISIBLE,hint.getVisibility());
            now=SystemClock.uptimeMillis()+1000;tap(view,100,now);tap(view,100,now+120);tap(view,1200,now+600);tap(view,1200,now+720);
            assertEquals(0,player.getCurrentPosition());
            ReflectionHelpers.setField(a,"player",null);player.release();
        }
    }
    @Test public void videoBarIsOverlaidWithRoundControlsAndVolumeStaysInFullscreen()throws Exception{
        try(var screen=Robolectric.buildActivity(PlayerActivity.class,SourceFiles.play(app,Uri.parse("content://own.player490/video"),"Rutas del norte.mp4")).create().visible()){
            PlayerActivity a=screen.get();ExoPlayer player=new ExoPlayer.Builder(a).build();ReflectionHelpers.setField(a,"player",player);
            PlayerView view=a.findViewById(R.id.player);view.setPlayer(player);((TextView)a.findViewById(R.id.playerTitle)).setText("Rutas del norte");view.setControllerShowTimeoutMs(0);view.showController();
            PeachDesign.videoControls(view,UiAppearance.accent(a));layout(a.findViewById(android.R.id.content));
            assertTrue(a.findViewById(R.id.player_top).getBackground()!=null);
            assertEquals(a.findViewById(R.id.playerRoot),a.findViewById(R.id.player_top).getParent());
            Redesign490Test.render(a.findViewById(android.R.id.content),"video-player",1280,800);
            a.findViewById(R.id.fullscreen).performClick();assertEquals(View.GONE,a.findViewById(R.id.playerBar).getVisibility());assertTrue(a.findViewById(R.id.player_volume).hasOnClickListeners());
            ReflectionHelpers.setField(a,"player",null);view.setPlayer(null);player.release();
        }
    }
    @Test public void destructiveButtonsAreRedAndOthersKeepTheThemeText(){
        Button remove=new Button(app);remove.setText("Eliminar fuente");Button keep=new Button(app);keep.setText("Guardar");
        UiAppearance.polish(remove);UiAppearance.polish(keep);
        assertEquals(PeachDesign.danger(app),remove.getCurrentTextColor());assertEquals(UiAppearance.text(app),keep.getCurrentTextColor());
        assertTrue(PeachDesign.destructive("Quitar de Peach"));assertTrue(PeachDesign.destructive("  borrar clave"));assertFalse(PeachDesign.destructive("Reproducir"));
    }
    @Test public void renderDownloadsAndSourcesWithTheNewButtons()throws Exception{
        try(var screen=Robolectric.buildActivity(DownloadQueueActivity.class).setup().visible()){layout(screen.get().findViewById(android.R.id.content));Redesign490Test.render(screen.get().findViewById(android.R.id.content),"downloads",1280,800);}
        try(var screen=Robolectric.buildActivity(SourceBrowserActivity.class).setup().visible()){layout(screen.get().findViewById(android.R.id.content));Redesign490Test.render(screen.get().findViewById(android.R.id.content),"sources",1280,800);
            var draft=new androidx.lifecycle.ViewModelProvider(screen.get()).get(SourceBrowserActivity.Draft.class);draft.token.cancel();draft.worker.shutdown();draft.worker.awaitTermination(20,java.util.concurrent.TimeUnit.SECONDS);}
        assertNull(ShadowDialog.getLatestDialog());
    }
}
