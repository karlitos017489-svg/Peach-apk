package com.peach.local;

import android.content.Context;
import android.content.Intent;
import android.graphics.*;
import android.net.Uri;
import android.os.Looper;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;
import java.io.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.shadows.*;
import static org.junit.Assert.*;

/** Rediseño 0.49: accesos rápidos, fila Continuar, panel de detalles, navegación y Apariencia. */
@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land-mdpi") @SQLiteMode(SQLiteMode.Mode.LEGACY) @GraphicsMode(GraphicsMode.Mode.NATIVE)
public class Redesign490Test {
    LibraryUiTest fixture;Context app;
    @Before public void setup(){app=RuntimeEnvironment.getApplication();UiAppearance.prefs(app).edit().clear().commit();fixture=new LibraryUiTest();fixture.initializeScheduler();}
    @After public void close()throws Exception{fixture.closeFixture();UiAppearance.prefs(app).edit().clear().commit();}

    LibraryDao db(){return LibraryDatabase.get(app).library();}
    static void idle()throws Exception{for(int i=0;i<3;i++){LibraryDatabase.IO.submit(()->{}).get(10,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();}}
    static MediaEntry media(String id,String title,String type,String name){MediaEntry m=new MediaEntry();m.id=id;m.title=title;m.name=name;m.mediaType=type;m.uri="content://own490/"+id;m.folder="Muestras";return m;}
    static byte[] png(int color,String label){Bitmap b=Bitmap.createBitmap(480,480,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(b);c.drawColor(color);Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(0x40ffffff);c.drawCircle(360,110,170,p);p.setColor(0x33000000);c.drawCircle(90,430,230,p);p.setColor(0xffffffff);p.setTextSize(44);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));c.drawText(label,36,400,p);ByteArrayOutputStream out=new ByteArrayOutputStream();b.compress(Bitmap.CompressFormat.PNG,100,out);b.recycle();return out.toByteArray();}
    void cover(MediaEntry m,int color){byte[] bytes=png(color,m.title.split(" ")[0]);m.poster="content://own490-poster/"+m.id;Shadows.shadowOf(app.getContentResolver()).registerInputStreamSupplier(Uri.parse(m.poster),()->new ByteArrayInputStream(bytes));}
    void library(){
        String[][] rows={{"v1","Rutas del norte","video","rutas.mp4"},{"v2","Entre montañas","video","montanas.mp4"},{"a1","Luz del desierto","audio","luz.mp3"},{"a2","La costa al amanecer","audio","costa.flac"},{"i1","Horizontes","image","horizontes.png"},{"v3","Tiempo y piedra","video","piedra.mkv"}};
        int[] colors={0xff365564,0xffa96754,0xff78639a,0xff587454,0xff375583,0xffb09254};
        for(int i=0;i<rows.length;i++){MediaEntry m=media(rows[i][0],rows[i][1],rows[i][2],rows[i][3]);cover(m,colors[i]);m.year="2026";
            if(i==0){m.favorite=true;m.position=125_000;m.duration=600_000;m.lastPlayed=2000;}
            if(i==2){m.position=60_000;m.duration=240_000;m.lastPlayed=3000;m.favorite=true;}
            if(i==1){m.duration=5_400_000;m.watched=true;}
            db().insertMedia(m);}
    }
    static int count(MainActivity a){return ((RecyclerView)a.findViewById(R.id.grid)).getAdapter().getItemCount();}
    static Button chip(MainActivity a,String label){LinearLayout row=a.findViewById(R.id.library_chips);for(int i=0;i<row.getChildCount();i++){Button b=(Button)row.getChildAt(i);if(b.getText().toString().equals(label))return b;}throw new AssertionError(label);}

    @Test public void quickChipsFilterTheLibraryAndStayInSyncWithTheFilterPanel()throws Exception{
        library();
        try(var screen=Robolectric.buildActivity(MainActivity.class).setup().visible()){MainActivity a=screen.get();idle();
            chip(a,"Todo").performClick();idle();assertEquals(6,count(a));assertTrue(chip(a,"Todo").isSelected());
            chip(a,"Favoritos").performClick();idle();assertEquals(2,count(a));assertEquals(1,((Spinner)a.findViewById(R.id.filter)).getSelectedItemPosition());
            chip(a,"Audio").performClick();idle();assertEquals(2,count(a));assertTrue(chip(a,"Audio").isSelected());assertFalse(chip(a,"Favoritos").isSelected());
            chip(a,"Continuar").performClick();idle();assertEquals(2,count(a));
            ((Spinner)a.findViewById(R.id.filter)).setSelection(0);((Spinner)a.findViewById(R.id.typeFilter)).setSelection(1);idle();assertTrue(chip(a,"Videos").isSelected());assertEquals(3,count(a));
            chip(a,"Historial").performClick();assertEquals(HistoryActivity.class.getName(),Shadows.shadowOf(a).getNextStartedActivity().getComponent().getClassName());
        }
    }
    @Test public void continueRowListsStartedMediaNewestFirstAndCanBeHidden()throws Exception{
        library();
        try(var screen=Robolectric.buildActivity(MainActivity.class).setup().visible()){MainActivity a=screen.get();idle();chip(a,"Todo").performClick();idle();
            assertEquals(View.VISIBLE,a.findViewById(R.id.continue_section).getVisibility());
            RecyclerView row=a.findViewById(R.id.continue_row);assertEquals(2,row.getAdapter().getItemCount());
            ((EditText)a.findViewById(R.id.search)).setText("rutas");Shadows.shadowOf(Looper.getMainLooper()).idleFor(java.time.Duration.ofMillis(400));idle();assertEquals(View.GONE,a.findViewById(R.id.continue_section).getVisibility());
        }
        List<MediaEntry> picked=ContinueAdapter.pick(db().allMedia());assertEquals("a1",picked.get(0).id);assertEquals("v1",picked.get(1).id);
        UiAppearance.prefs(app).edit().putBoolean("continueRow",false).commit();
        try(var screen=Robolectric.buildActivity(MainActivity.class).setup().visible()){MainActivity a=screen.get();idle();chip(a,"Todo").performClick();idle();assertEquals(View.GONE,a.findViewById(R.id.continue_section).getVisibility());}
    }
    @Test public void continueSelectionIgnoresFinishedMissingAndUnplayableEntriesAndIsBounded(){
        List<MediaEntry> all=new ArrayList<>();
        for(int i=0;i<20;i++){MediaEntry m=media("m"+i,"T"+i,"video","t"+i+".mp4");m.position=1000;m.duration=10_000;m.lastPlayed=i;all.add(m);}
        all.get(19).watched=true;all.get(18).missing=true;MediaEntry image=media("img","Foto","image","f.png");image.position=5;image.duration=10;all.add(image);
        List<MediaEntry> picked=ContinueAdapter.pick(all);assertEquals(ContinueAdapter.LIMIT,picked.size());assertEquals("m17",picked.get(0).id);
        assertTrue(picked.stream().noneMatch(m->m.watched||m.missing||m.mediaType.equals("image")));
    }
    @Test public void cardsShowShortSummaryDurationAndFavoriteBadge(){
        MediaEntry m=media("x","Título","video","x.mp4");m.year="2024";assertEquals("Video · 2024",MediaAdapter.summary(m));
        m.position=10;assertEquals("Video · Continuar · 2024",MediaAdapter.summary(m));m.watched=true;assertEquals("Video · Visto · 2024",MediaAdapter.summary(m));
        MediaEntry a=media("y","Pista","audio","y.mp3");a.watched=true;assertEquals("Audio · Escuchado",MediaAdapter.summary(a));
        m.missing=true;assertEquals("Archivo no disponible",MediaAdapter.summary(m));
        assertEquals("",MediaAdapter.duration(400));assertEquals("4:05",MediaAdapter.duration(245_000));assertEquals("1:30:00",MediaAdapter.duration(5_400_000));
    }
    @Test public void navigationReusesOpenSectionsInsteadOfRestartingThem()throws Exception{
        try(var screen=Robolectric.buildActivity(MainActivity.class).setup().visible()){MainActivity a=screen.get();idle();
            a.findViewById(R.id.navSources).performClick();Intent next=Shadows.shadowOf(a).getNextStartedActivity();assertEquals(SourceBrowserActivity.class.getName(),next.getComponent().getClassName());assertTrue((next.getFlags()&Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)!=0);assertFalse(a.isFinishing());}
        try(var screen=Robolectric.buildActivity(SettingsActivity.class).setup().visible()){var a=screen.get();
            View library=Browser480Test.find(a.findViewById(android.R.id.content),v->v instanceof Button b&&"Biblioteca".contentEquals(b.getText()));assertNotNull(library);library.performClick();
            Intent next=Shadows.shadowOf(a).getNextStartedActivity();assertEquals(MainActivity.class.getName(),next.getComponent().getClassName());assertTrue((next.getFlags()&Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)!=0);assertFalse(a.isFinishing());}
    }
    @Test public void detailSheetOffersQuickFavoriteListAndWatchedAndKeepsAllActions()throws Exception{
        library();
        try(var screen=Robolectric.buildActivity(MainActivity.class).setup().visible()){MainActivity a=screen.get();idle();chip(a,"Todo").performClick();idle();layout(a);
            RecyclerView grid=a.findViewById(R.id.grid);View card=null;for(int i=0;i<grid.getChildCount();i++){var h=(MediaAdapter.Holder)grid.getChildViewHolder(grid.getChildAt(i));if(h.title.getText().toString().equals("Entre montañas"))card=h.details;}
            assertNotNull(card);card.performClick();idle();
            AlertDialog sheet=(AlertDialog)ShadowDialog.getLatestDialog();assertNotNull(sheet.findViewById(R.id.detail_text));
            assertEquals(Gravity.BOTTOM,sheet.getWindow().getAttributes().gravity&Gravity.VERTICAL_GRAVITY_MASK);
            sheet.findViewById(R.id.sheet_favorite).performClick();idle();assertTrue(db().get("v2").favorite);
            sheet.findViewById(R.id.sheet_watched).performClick();idle();assertFalse(db().get("v2").watched);
            render(sheet.getWindow().getDecorView(),"detail-sheet",720,640);
            sheet.getButton(AlertDialog.BUTTON_NEUTRAL).performClick();idle();assertNotNull(((AlertDialog)ShadowDialog.getLatestDialog()).getListView());
        }
    }
    @Test public void favoriteBadgeAndDurationAppearOnCards()throws Exception{
        library();
        try(var screen=Robolectric.buildActivity(MainActivity.class).setup().visible()){MainActivity a=screen.get();idle();chip(a,"Todo").performClick();idle();layout(a);
            RecyclerView grid=a.findViewById(R.id.grid);boolean favorite=false,length=false;
            for(int i=0;i<grid.getChildCount();i++){var h=(MediaAdapter.Holder)grid.getChildViewHolder(grid.getChildAt(i));String t=h.title.getText().toString();
                if(t.equals("Rutas del norte")){favorite=h.favorite.getVisibility()==View.VISIBLE;assertFalse(t.startsWith("★"));}
                if(t.equals("Entre montañas"))length=h.length.getVisibility()==View.VISIBLE&&h.length.getText().toString().equals("1:30:00");}
            assertTrue(favorite);assertTrue(length);
        }
    }
    @Test public void appearanceUsesChipsSwatchesAndPureBlackTheme()throws Exception{
        try(var screen=Robolectric.buildActivity(AppearanceActivity.class).setup().visible()){var a=screen.get();idle();
            ViewGroup modes=a.findViewById(R.id.appearance_mode);assertEquals(4,modes.getChildCount());assertTrue(modes.getChildAt(1).isSelected());
            render(a.findViewById(android.R.id.content),"appearance-dark",1280,800);
            modes.getChildAt(3).performClick();idle();assertEquals(3,UiAppearance.prefs(app).getInt("mode",-1));}
        assertTrue(UiAppearance.dark(app));assertEquals(0xff000000,UiAppearance.background(app));
        try(var screen=Robolectric.buildActivity(AppearanceActivity.class).setup().visible()){var a=screen.get();idle();
            ((ViewGroup)a.findViewById(R.id.appearance_density)).getChildAt(3).performClick();idle();assertEquals(3,UiAppearance.prefs(app).getInt("density",-1));
            ((CompoundButton)a.findViewById(R.id.appearance_continue)).setChecked(false);assertFalse(UiAppearance.prefs(app).getBoolean("continueRow",true));}
        UiAppearance.prefs(app).edit().putInt("mode",2).commit();assertFalse(UiAppearance.dark(app));assertEquals(0xfff6f6f9,UiAppearance.background(app));
    }
    @Test public void renderRedesignedScreensForVisualReview()throws Exception{
        library();UiAppearance.prefs(app).edit().putInt("motion",0).commit();
        for(String mode:new String[]{"dark","light","black"}){
            UiAppearance.prefs(app).edit().putInt("motion",0).putInt("mode",mode.equals("dark")?1:mode.equals("light")?2:3).putInt("accent",mode.equals("light")?1:0).commit();
            try(var screen=Robolectric.buildActivity(MainActivity.class).setup().visible()){MainActivity a=screen.get();idle();chip(a,"Todo").performClick();idle();layout(a);Thread.sleep(400);idle();layout(a);render(a.findViewById(android.R.id.content),"library-"+mode,1280,800);}
        }
        UiAppearance.prefs(app).edit().putInt("mode",1).putInt("accent",0).putInt("density",3).commit();
        try(var screen=Robolectric.buildActivity(MainActivity.class).setup().visible()){MainActivity a=screen.get();idle();chip(a,"Todo").performClick();idle();layout(a);Thread.sleep(400);idle();layout(a);render(a.findViewById(android.R.id.content),"library-list",1280,800);}
        UiAppearance.prefs(app).edit().putInt("density",1).commit();
        RuntimeEnvironment.setQualifiers("w600dp-h960dp-port-mdpi");
        try(var screen=Robolectric.buildActivity(MainActivity.class).setup().visible()){MainActivity a=screen.get();idle();chip(a,"Todo").performClick();idle();layout(a,600,960);Thread.sleep(400);idle();layout(a,600,960);render(a.findViewById(android.R.id.content),"library-portrait",600,960);}
        RuntimeEnvironment.setQualifiers("w1280dp-h800dp-land-mdpi");
        try(var screen=Robolectric.buildActivity(SettingsActivity.class).setup().visible()){layout(screen.get());render(screen.get().findViewById(android.R.id.content),"settings",1280,800);}
    }
    static void layout(android.app.Activity a){layout(a,1280,800);}
    static void layout(android.app.Activity a,int w,int h){View v=a.findViewById(android.R.id.content);v.measure(View.MeasureSpec.makeMeasureSpec(w,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(h,View.MeasureSpec.EXACTLY));v.layout(0,0,w,h);Shadows.shadowOf(Looper.getMainLooper()).idle();}
    static void render(View v,String name,int w,int h)throws Exception{
        if(v.getWidth()!=w||v.getHeight()!=h){v.measure(View.MeasureSpec.makeMeasureSpec(w,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(h,View.MeasureSpec.AT_MOST));v.layout(0,0,w,Math.max(1,v.getMeasuredHeight()));}
        Bitmap b=Bitmap.createBitmap(w,Math.max(1,v.getHeight()),Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(b);canvas.drawColor(UiAppearance.background(v.getContext()));v.draw(canvas);
        File dir=new File("build/reports/ui049");dir.mkdirs();try(var out=new FileOutputStream(new File(dir,name+".png"))){assertTrue(b.compress(Bitmap.CompressFormat.PNG,100,out));}b.recycle();
    }
}
