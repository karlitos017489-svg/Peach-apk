package com.peach.local;

import android.content.Context;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowDialog;
import static org.junit.Assert.*;

/** Fuentes 0.49: inicio con un buscador claro, tus fuentes como tarjetas y resultados con pestañas por tipo. */
@RunWith(RobolectricTestRunner.class) @Config(sdk=28,qualifiers="w1280dp-h800dp-land-mdpi") @SQLiteMode(SQLiteMode.Mode.LEGACY) @GraphicsMode(GraphicsMode.Mode.NATIVE)
public class Sources490Test {
    LibraryUiTest fixture;Context app;LibraryDatabase db;SourceHttp.Transport previous;GalleryCache.Fetcher previousImages;int calls;SourceBrowserActivity activity;
    @Before public void setup()throws Exception{app=RuntimeEnvironment.getApplication();UiAppearance.prefs(app).edit().clear().putInt("motion",0).commit();app.getSharedPreferences("source-browser",0).edit().clear().commit();
        fixture=new LibraryUiTest();fixture.initializeScheduler();db=LibraryDatabase.get(app);previous=SourcesActivity.transport;previousImages=SourcePreviewLoader.fetcher;SourcePreviewLoader.clearMemory();
        SourcesActivity.transport=(u,e,m,t)->{calls++;try{return FanboxConnectorTest.response(new JSONObject().put("posts",new JSONArray().put(FanboxConnectorTest.post("1").put("title","Clip de campo")).put(FanboxConnectorTest.post("2").put("title","Galería de rocas"))));}catch(Exception x){throw new IOException(x);}};
        SourcePreviewLoader.fetcher=(u,f,t)->{throw new IOException("Sin red en pruebas");};}
    @After public void close()throws Exception{if(activity!=null){var d=draft();d.token.cancel();d.worker.shutdown();d.worker.awaitTermination(20,TimeUnit.SECONDS);}SourcesActivity.transport=previous;SourcePreviewLoader.fetcher=previousImages;fixture.closeFixture();UiAppearance.prefs(app).edit().clear().commit();}
    SourceBrowserActivity.Draft draft(){return new ViewModelProvider(activity).get(SourceBrowserActivity.Draft.class);}
    void idle()throws Exception{var d=draft();for(int i=0;i<3;i++){d.worker.submit(()->{}).get(20,TimeUnit.SECONDS);org.robolectric.Shadows.shadowOf(Looper.getMainLooper()).idle();}}
    void layout(){Glass490Test.layout(activity);}
    void search(String text)throws Exception{((android.widget.EditText)activity.findViewById(R.id.browser_search)).setText(text);activity.findViewById(R.id.browser_go).performClick();idle();layout();}

    @Test public void openingShowsOnlyTheSearchAndYourSourcesWithoutTouchingTheNetwork()throws Exception{
        try(var c=Robolectric.buildActivity(SourceBrowserActivity.class).setup().visible()){activity=c.get();idle();layout();
            assertEquals(0,calls);assertTrue(draft().home);
            assertTrue(activity.findViewById(R.id.browser_search).isShown());assertTrue(activity.findViewById(R.id.browser_provider).isShown());
            assertFalse("Sin cabecera de resultados en el inicio",activity.findViewById(R.id.browser_refresh).isShown());assertFalse(activity.findViewById(R.id.browser_mode).isShown());
            assertNotNull(Browser480Test.find(activity.findViewById(R.id.browser_grid),v->v instanceof TextView t&&t.getText().toString().equals("Tus fuentes")));
            assertNotNull(Browser480Test.find(activity.findViewById(R.id.browser_grid),v->v instanceof TextView t&&t.getText().toString().equals("Guardadas")));
            Redesign490Test.render(activity.findViewById(android.R.id.content),"sources-home-empty",1280,800);}
    }
    @Test public void pickingASiteShowsWhatToTypeAndSearchingOpensThatSourcesResults()throws Exception{
        try(var c=Robolectric.buildActivity(SourceBrowserActivity.class).setup().visible()){activity=c.get();idle();layout();
            activity.findViewById(R.id.browser_provider).performClick();var dialog=ShadowDialog.getLatestDialog();assertTrue(dialog.isShowing());
            View paheal=Browser480Test.find(dialog.getWindow().getDecorView(),v->v.isClickable()&&Browser480Test.find(v,t->t instanceof TextView tv&&tv.getText().toString().equals("Rule34 Paheal"))!=null);assertNotNull(paheal);
            View list=Browser480Test.find(dialog.getWindow().getDecorView(),v->v instanceof android.widget.ScrollView);Redesign490Test.render(((android.view.ViewGroup)list).getChildAt(0),"sources-site-picker",640,900);
            paheal.performClick();assertEquals("rule34paheal",draft().provider);assertFalse(dialog.isShowing());
            assertTrue(((Button)activity.findViewById(R.id.browser_provider)).getText().toString().startsWith("Rule34 Paheal"));
            activity.findViewById(R.id.browser_provider).performClick();Browser480Test.find(ShadowDialog.getLatestDialog().getWindow().getDecorView(),v->v.isClickable()&&Browser480Test.find(v,t->t instanceof TextView tv&&tv.getText().toString().equals("FANBOX"))!=null).performClick();
            search("artist");assertEquals(1,calls);assertFalse(draft().home);
            assertTrue(activity.findViewById(R.id.browser_refresh).isShown());assertFalse("El buscador del inicio se oculta",activity.findViewById(R.id.browser_search).isShown());
            assertTrue(((TextView)activity.findViewById(R.id.browser_title)).getText().length()>0);
            RecyclerView grid=activity.findViewById(R.id.browser_grid);assertEquals(2,grid.getAdapter().getItemCount());
            Redesign490Test.render(activity.findViewById(android.R.id.content),"sources-results",1280,800);
            activity.findViewById(R.id.browser_home).performClick();idle();layout();assertTrue(draft().home);
            assertNotNull("La búsqueda queda como tarjeta en Tus fuentes",Browser480Test.find(grid,v->v.isClickable()&&Browser480Test.find(v,t->t instanceof TextView tv&&tv.getText().toString().equals("FANBOX"))!=null));
            Redesign490Test.render(activity.findViewById(android.R.id.content),"sources-home",1280,800);
            activity.getOnBackPressedDispatcher().onBackPressed();assertTrue(activity.isFinishing());
        }
    }
    @Test public void typeTabsFilterResultsAndBackFromResultsReturnsHomeBeforeLeaving()throws Exception{
        try(var c=Robolectric.buildActivity(SourceBrowserActivity.class).setup().visible()){activity=c.get();idle();layout();search("artist");
            android.view.ViewGroup tabs=activity.findViewById(R.id.browser_mode);assertEquals(4,tabs.getChildCount());assertTrue(tabs.getChildAt(0).isSelected());
            tabs.getChildAt(2).performClick();layout();assertEquals(2,draft().type);assertTrue(tabs.getChildAt(2).isSelected());
            RecyclerView grid=activity.findViewById(R.id.browser_grid);assertEquals(1,grid.getAdapter().getItemCount());
            assertNotNull("Mensaje claro cuando la pestaña no tiene nada",Browser480Test.find(grid,v->v instanceof TextView t&&t.getText().toString().contains("Todo")));
            tabs.getChildAt(0).performClick();assertEquals(2,grid.getAdapter().getItemCount());
            activity.getOnBackPressedDispatcher().onBackPressed();assertTrue(draft().home);assertFalse(activity.isFinishing());
        }
    }
    @Test public void deletedRememberedSourceFallsBackToHomeInsteadOfAnEmptyPage()throws Exception{
        app.getSharedPreferences("source-browser",0).edit().putBoolean("home",false).putString("selected","fanbox:gone").commit();
        try(var c=Robolectric.buildActivity(SourceBrowserActivity.class).setup().visible()){activity=c.get();idle();assertTrue(draft().home);}
    }
    @Test public void savedCardOpensSavedPostsFromAllSources()throws Exception{
        Publication p=new Publication();p.id="own-saved490";p.title="Mi publicación guardada";p.provider="fanbox";db.library().insertPublication(p);
        try(var c=Robolectric.buildActivity(SourceBrowserActivity.class).setup().visible()){activity=c.get();idle();layout();
            View saved=Browser480Test.find(activity.findViewById(R.id.browser_grid),v->v.isClickable()&&Browser480Test.find(v,t->t instanceof TextView tv&&tv.getText().toString().equals("Guardadas"))!=null);
            assertNotNull(saved);saved.performClick();idle();layout();assertTrue(draft().savedOnly);assertFalse(draft().home);
            assertEquals("Guardadas",((TextView)activity.findViewById(R.id.browser_title)).getText().toString());assertEquals(1,((RecyclerView)activity.findViewById(R.id.browser_grid)).getAdapter().getItemCount());assertEquals(0,calls);}
    }
}
