package com.peach.local;
import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import org.junit.*;
import static org.junit.Assert.*;

/** Real streaming state machine, own MP4, simulated HTTPS/DNS; no upstream requests. */
public class VideoStreamTest {
    static final String URL="https://downloads.fanbox.cc/own-stream.mp4";
    static class Reply extends PartialDownloadTest.Reply {
        int consumed;
        Reply(String url,int status,byte[] own,String tag)throws Exception{super(url,status,own,tag);mime="video/mp4";}
        @Override public InputStream getInputStream()throws IOException{if(failInput)return super.getInputStream();reads++;return new FilterInputStream(new ByteArrayInputStream(bytes)){
            @Override public int read(byte[] b,int offset,int count)throws IOException{int n=super.read(b,offset,count);if(n>0)consumed+=n;return n;}
            @Override public void close()throws IOException{inputClosed=true;super.close();}
        };}
    }
    byte[] own;VideoStream.Session session;
    @Before public void before()throws Exception{own=SourceVideosTest.own();}
    @After public void after(){if(session!=null){session.close();assertTrue(session.active.isEmpty());}}
    VideoStream.Session make(String url,Reply... responses){session=new VideoStream.Session(url,()->true,new RedirectHttpTest.Factory(responses),MediaRedirectsTest.PUBLIC);session.resume();return session;}
    Reply full()throws Exception{return new Reply(URL,200,own,"\"own-v1\"");}
    Reply suffix(String url,int offset,String tag)throws Exception{Reply r=new Reply(url,206,Arrays.copyOfRange(own,offset,own.length),tag);r.headers.put("Content-Range","bytes "+offset+"-"+(own.length-1)+"/"+own.length);return r;}
    interface Operation{void run()throws Exception;}
    static void problem(VideoStream.Reason reason,Operation operation)throws Exception{try{operation.run();fail();}catch(VideoStream.Problem e){assertEquals(e.getMessage(),reason,e.reason);assertNull(e.getCause());assertFalse(e.toString().contains("https://"));assertFalse(e.toString().contains("OWN_SECRET"));}}
    @Test public void startsAfterOnly4096BytesWithoutWaitingForTheCompleteVideo()throws Exception{
        Reply reply=full();make(URL,reply);try(var input=session.open(0)){assertEquals(4096,reply.consumed);assertTrue(reply.consumed<own.length);assertEquals(own.length,input.length);byte[] first=new byte[24];assertEquals(24,input.read(first,0,first.length));assertArrayEquals(Arrays.copyOf(own,24),first);assertEquals(4096,reply.consumed);assertEquals(0,input.read(first,0,0));}assertTrue(reply.closed&&reply.inputClosed);
    }
    @Test public void sequentialReadReturnsExactOwnBytesAndDetectsTruncatedBody()throws Exception{
        Reply reply=full();make(URL,reply);try(var input=session.open(0);var out=new ByteArrayOutputStream()){byte[] b=new byte[65536];int n;while((n=input.read(b,0,b.length))!=-1)out.write(b,0,n);assertArrayEquals(own,out.toByteArray());}
        Reply shortReply=new Reply(URL,200,Arrays.copyOf(own,5000),"\"own\"");shortReply.declared=own.length;make(URL,shortReply);try(var input=session.open(0)){byte[] b=new byte[4096];assertEquals(4096,input.read(b,0,b.length));assertEquals(904,input.read(b,0,b.length));problem(VideoStream.Reason.NETWORK,()->input.read(b,0,b.length));}assertTrue(shortReply.closed&&shortReply.inputClosed);
    }
    @Test public void seeksUsingExact206AndStrongIfRangeWithoutDownloadingTheSkippedPrefix()throws Exception{
        Reply first=full(),next=suffix(URL,90000,"\"own-v1\"");make(URL,first,next);try(var ignored=session.open(0)){}try(var input=session.open(90000)){assertEquals(own.length-90000,input.length);byte[] b=new byte[32];assertEquals(32,input.read(b,0,b.length));assertArrayEquals(Arrays.copyOfRange(own,90000,90032),b);assertEquals(32,next.consumed);assertEquals("bytes=90000-",next.getRequestProperty("Range"));assertEquals("\"own-v1\"",next.getRequestProperty("If-Range"));}assertEquals(4096,first.consumed);
    }
    static final String CHANGED="Mon, 02 Mar 2026 10:00:00 GMT",SERVED="Sat, 31 Oct 2026 18:00:00 GMT";
    Reply dated(Reply r,String modified,String served){if(modified!=null)r.headers.put("Last-Modified",modified);if(served!=null)r.headers.put("Date",served);return r;}
    @Test public void serverWithoutEtagButStableLastModifiedCanSeekWithDateIfRange()throws Exception{
        // Caso Rule34Video: sin ETag, pero con fecha de modificación antigua respecto a la hora del servidor.
        Reply first=dated(new Reply(URL,200,own,null),CHANGED,SERVED),next=dated(suffix(URL,90000,null),CHANGED,SERVED);make(URL,first,next);
        try(var ignored=session.open(0)){}
        try(var input=session.open(90000)){byte[] b=new byte[32];assertEquals(32,input.read(b,0,b.length));assertArrayEquals(Arrays.copyOfRange(own,90000,90032),b);
            assertEquals("bytes=90000-",next.getRequestProperty("Range"));assertEquals(CHANGED,next.getRequestProperty("If-Range"));}
    }
    @Test public void dateValidatorStillBlocksChangedFilesRecentDatesAndMissingServerTime()throws Exception{
        // Si la fecha del salto no coincide, el archivo cambió: se bloquea.
        Reply first=dated(new Reply(URL,200,own,null),CHANGED,SERVED),moved=dated(suffix(URL,90000,null),"Tue, 03 Mar 2026 10:00:00 GMT",SERVED);make(URL,first,moved);
        try(var ignored=session.open(0)){}problem(VideoStream.Reason.CHANGED,()->session.open(90000));
        // Fecha demasiado reciente (menos de 60 s) o sin hora del servidor: no es validador fuerte; se mantiene el bloqueo.
        for(String[] pair:new String[][]{{"Sat, 31 Oct 2026 17:59:30 GMT",SERVED},{CHANGED,null},{"no es una fecha",SERVED}}){
            Reply head=dated(new Reply(URL,200,own,null),pair[0],pair[1]);make(URL,head);try(var ignored=session.open(0)){}problem(VideoStream.Reason.SEEK,()->session.open(50000));}
        assertEquals("",VideoStream.Session.strongDate(CHANGED,null));assertEquals(CHANGED,VideoStream.Session.strongDate(CHANGED,SERVED));
    }
    @Test public void missingOrWeakEtagAllowsInitialPlaybackButPreventsUnconfirmedSeek()throws Exception{
        for(String tag:new String[]{null,"W/\"weak\""}){Reply first=new Reply(URL,200,own,tag);make(URL,first);try(var ignored=session.open(0)){}problem(VideoStream.Reason.SEEK,()->session.open(50000));assertEquals(1,first.reads);}
    }
    @Test public void rangeIgnoredNeverDownloadsAndDiscardsTheWholePrefixToSeek()throws Exception{
        Reply first=full(),ignored=full();make(URL,first,ignored);try(var i=session.open(0)){}problem(VideoStream.Reason.SEEK,()->session.open(70000));assertEquals(0,ignored.reads);assertTrue(ignored.closed);
    }
    @Test public void malformedOrShort206AndUnexpectedInitialPartialNeverReachDecoder()throws Exception{
        for(int mode=0;mode<4;mode++){Reply first=full(),bad=suffix(URL,10000,"\"own-v1\"");if(mode==0)bad.headers.put("Content-Range","bytes 10001-"+(own.length-1)+"/"+own.length);if(mode==1)bad.declared++;if(mode==2)bad.headers.put("Content-Range","bytes 10000-20000/"+own.length);if(mode==3)bad.headers.put("Content-Range","bytes 10000-20000/*");make(URL,first,bad);try(var i=session.open(0)){}problem(VideoStream.Reason.SEEK,()->session.open(10000));assertEquals(0,bad.reads);assertTrue(bad.closed);}
        Reply partial=suffix(URL,0,"\"own-v1\"");make(URL,partial);problem(VideoStream.Reason.FORMAT,()->session.open(0));assertEquals(0,partial.reads);
    }
    @Test public void changedEtagOrLengthIsNotMixedIntoAnExistingVideo()throws Exception{
        for(boolean tag:new boolean[]{true,false}){Reply first=full(),second=suffix(URL,10000,tag?"\"changed\"":"\"own-v1\"");if(!tag){second.headers.put("Content-Range","bytes 10000-"+own.length+"/"+(own.length+1));second.declared++;}make(URL,first,second);try(var i=session.open(0)){}problem(VideoStream.Reason.CHANGED,()->session.open(10000));assertEquals(0,second.reads);}
    }
    @Test public void restoredSeekProbesOnlyHeaderBeforeOpeningRequestedRange()throws Exception{
        Reply first=full(),second=suffix(URL,80000,"\"own-v1\"");make(URL,first,second);try(var i=session.open(80000)){assertEquals(4096,first.consumed);assertTrue(first.closed&&first.inputClosed);byte[] b=new byte[20];i.read(b,0,b.length);assertArrayEquals(Arrays.copyOfRange(own,80000,80020),b);}assertEquals(20,second.consumed);
    }
    @Test public void unknownLengthAndLargeResourceNeedNoCompleteFileAllocation()throws Exception{
        Reply unknown=full();unknown.declared=-1;make(URL,unknown);try(var i=session.open(0)){assertEquals(-1,i.length);assertEquals(4096,unknown.consumed);}
        Reply large=full();large.declared=3L*1024*1024*1024;make(URL,large);try(var i=session.open(0)){assertEquals(large.declared,i.length);assertEquals(4096,large.consumed);}
        Reply tooLarge=full();tooLarge.declared=VideoStream.MAX_RESOURCE+1;make(URL,tooLarge);problem(VideoStream.Reason.SIZE,()->session.open(0));assertEquals(0,tooLarge.reads);
    }
    @Test public void mimeCompressionManifestAndDisguisedHtmlOrImageAreRejected()throws Exception{
        for(int mode=0;mode<6;mode++){Reply r=full();switch(mode){case 0->r.mime="text/html";case 1->r.headers.put("Content-Encoding","gzip");case 2->r.mime="application/vnd.apple.mpegurl";case 3->{r.bytes="<html>OWN_SECRET</html>".getBytes();r.declared=r.bytes.length;}case 4->{r.bytes="GIF89a-own".getBytes();r.declared=r.bytes.length;}case 5->r.mime="multipart/byteranges";}make(URL,r);problem(VideoStream.Reason.FORMAT,()->session.open(0));assertTrue(r.closed);if(r.reads>0)assertTrue(r.inputClosed);}
    }
    @Test public void publicRuleVideoHandoffKeepsTlsRouteAndNeverSendsCallerAuth()throws Exception{
        String original=MediaRedirectsTest.ORIGINAL,cdn=MediaRedirectsTest.CDN;Reply hop=new Reply(original,302,new byte[0],null),file=new Reply(cdn,200,own,"\"own\"");hop.location=cdn;make(original,hop,file);try(var i=session.open(0)){byte[] b=new byte[32];assertEquals(32,i.read(b,0,b.length));assertNull(file.getRequestProperty("Authorization"));assertNull(file.getRequestProperty("Cookie"));assertFalse(file.getInstanceFollowRedirects());}assertEquals(0,hop.reads);assertTrue(hop.closed&&file.closed);
        Reply bad=new Reply(original,302,new byte[0],null);bad.location="https://router.local/own";make(original,bad);problem(VideoStream.Reason.NETWORK,()->session.open(0));assertTrue(bad.closed);
    }
    @Test public void offlinePauseAndClosePreventNetworkAndReleaseActiveConnections()throws Exception{
        Reply r=full();AtomicBoolean online=new AtomicBoolean(false);session=new VideoStream.Session(URL,online::get,new RedirectHttpTest.Factory(r),MediaRedirectsTest.PUBLIC);session.resume();problem(VideoStream.Reason.OFFLINE,()->session.open(0));assertEquals(0,r.reads);online.set(true);try(var i=session.open(0)){session.pause();assertTrue(r.closed);try{i.read(new byte[1],0,1);fail();}catch(IOException expected){}}assertTrue(session.active.isEmpty());session.close();session.resume();try{session.open(0);fail();}catch(IOException expected){}assertEquals(1,r.reads);
    }
    @Test public void http429IsNotRetriedAndPrivateUrlNeverAppearsInErrors()throws Exception{
        Reply denied=new Reply(URL,429,new byte[0],null);denied.headers.put("Retry-After","300");var factory=new RedirectHttpTest.Factory(denied);session=new VideoStream.Session(URL,()->true,factory,MediaRedirectsTest.PUBLIC);session.resume();problem(VideoStream.Reason.WAIT,()->session.open(0));problem(VideoStream.Reason.WAIT,()->session.open(0));assertEquals(1,factory.requests.size());
        Reply fail=full();fail.failInput=true;make(URL,fail);problem(VideoStream.Reason.NETWORK,()->session.open(0));assertTrue(fail.closed);Reply access=new Reply(URL,403,new byte[0],null);make(URL,access);problem(VideoStream.Reason.ACCESS,()->session.open(0));
    }
    @Test public void exactEnd416IsEofAndBeyondEndIsAnError()throws Exception{
        Reply first=full(),end=new Reply(URL,416,new byte[0],null),beyond=new Reply(URL,416,new byte[0],null);end.headers.put("Content-Range","bytes */"+own.length);beyond.headers.putAll(end.headers);make(URL,first,end,beyond);try(var i=session.open(0)){}try(var i=session.open(own.length)){assertEquals(0,i.length);assertEquals(-1,i.read(new byte[1],0,1));}problem(VideoStream.Reason.RANGE,()->session.open(own.length+1));assertTrue(end.closed&&beyond.closed);assertEquals(0,end.reads);
    }
    @Test public void immutablePawReferenceCanSeekWithoutEtagInUnverifiedOnlineMode()throws Exception{
        String hash=PartialDownload.hex(PartialDownload.digest().digest(own)),url="https://file.pawchive.pw/data/"+hash.substring(0,2)+"/"+hash.substring(2,4)+"/"+hash+".mp4";Reply first=new Reply(url,200,own,null),second=suffix(url,10000,null);make(url,first,second);try(var i=session.open(0)){}try(var i=session.open(10000)){byte[] b=new byte[10];i.read(b,0,b.length);assertArrayEquals(Arrays.copyOfRange(own,10000,10010),b);}assertNull(second.getRequestProperty("If-Range"));
    }
    @Test public void cancellationAtResponseNeverStartsReadingTheBody()throws Exception{
        Reply r=new Reply(URL,200,own,"\"own\""){@Override public int getResponseCode(){session.pause();return 200;}};make(URL,r);problem(VideoStream.Reason.NETWORK,()->session.open(0));assertTrue(r.closed);assertEquals(0,r.reads);assertTrue(session.active.isEmpty());
    }
    @Test public void realHttpDenialRetainsStatusWithoutConfusingItWithALocalRequestFailure()throws Exception{
        Reply denied=new Reply(URL,403,new byte[0],null);make(URL,denied);try{session.open(0);fail();}catch(VideoStream.Problem e){assertEquals(VideoStream.Reason.ACCESS,e.reason);assertEquals(403,e.httpStatus);assertTrue(e.getMessage().contains("HTTP: 403"));assertFalse(e.toString().contains("https://"));assertNull(e.getCause());}
        var internal=new VideoStream.Problem(VideoStream.Reason.REQUEST);assertEquals(0,internal.httpStatus);assertTrue(internal.getMessage().contains("Peach"));assertFalse(internal.getMessage().contains("La fuente"));assertFalse(internal.getMessage().contains("HTTP:"));
    }
}
