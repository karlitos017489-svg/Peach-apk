package com.peach.local;
import java.net.URI;
import org.json.*;
/** Explicit one-page API contract check; no body/media/attachment URLs are retained. */
public final class CumstLiveSmoke {
    public static void main(String[] args)throws Exception{
        String proxy=System.getenv("HTTPS_PROXY");if(proxy!=null){URI u=URI.create(proxy);if(u.getHost()!=null && u.getPort()>0){System.setProperty("https.proxyHost",u.getHost());System.setProperty("https.proxyPort",Integer.toString(u.getPort()));}}
        String ref=CumstUrls.creator(args.length>0?args[0]:"patreon/0");JSONObject report=new JSONObject().put("checkedAt",java.time.Instant.now().toString()).put("transport","SourceHttp.direct and CumstConnector via JDK HTTPS; not Android instrumentation").put("thirdPartyBodiesPackaged",false).put("mediaRequested",false);
        try{var page=new CumstConnector(SourceHttp.direct()).list(ref,0,"","",new SourceHttp.Token());report.put("result","parsed").put("candidates",page.candidates().length()).put("partial",true);}catch(Exception e){report.put("result","unavailable").put("reason",e.getMessage());}
        System.out.println(report.toString(2));
    }
}
