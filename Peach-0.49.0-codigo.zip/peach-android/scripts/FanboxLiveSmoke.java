package com.peach.local;

import java.io.*;
import java.net.URI;
import org.json.*;

/** Optional direct public contract check. Does not save article bodies or media. */
public final class FanboxLiveSmoke {
    public static void main(String[] args)throws Exception {
        String proxy=System.getenv("HTTPS_PROXY");if(proxy!=null){URI u=URI.create(proxy);if(u.getHost()!=null && u.getPort()>0){System.setProperty("https.proxyHost",u.getHost());System.setProperty("https.proxyPort",Integer.toString(u.getPort()));}}
        String ref=FanboxConnector.creator(args.length==0?"official":args[0]);FanboxConnector c=new FanboxConnector(SourceHttp.direct());SourceHttp.Token token=new SourceHttp.Token();var page=c.newest(ref,"","",token);JSONArray pages=c.pages(ref,token);JSONObject report=new JSONObject().put("creator",ref).put("checkedAt",java.time.Instant.now().toString()).put("publicCandidates",page.candidates().length()).put("skippedRestrictedOrPaid",page.skipped()).put("historyPages",pages.length()).put("transport","SourceHttp.direct via JDK HTTPS; not Android instrumentation");
        if(page.candidates().length()>0){String id=page.candidates().getJSONObject(0).getString("id");JSONObject content=c.detail(ref,id,token);report.put("samplePostId",id).put("bodyType",content.getString("type")).put("textCharacters",content.getString("text").length()).put("attachments",content.getJSONArray("attachments").length()).put("partial",content.getBoolean("partial"));
            if(args.length>1 && args[1].equals("--download-first")){JSONArray attachments=content.getJSONArray("attachments");for(int i=0;i<attachments.length();i++){JSONObject a=attachments.getJSONObject(i);if(a.getBoolean("downloadable")){File file=File.createTempFile("peach-public-smoke-",".tmp");try{SourceHttp.Download result=SourceHttp.download(a.getString("url"),file,token);report.put("downloadBytes",result.bytes()).put("downloadSha256",result.sha256());}finally{if(!file.delete() && file.exists())throw new IOException("Cannot remove smoke media.");}break;}}}
        }
        System.out.println(report.toString(2));
    }
}
