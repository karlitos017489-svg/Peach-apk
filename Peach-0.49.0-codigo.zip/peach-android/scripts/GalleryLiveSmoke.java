package com.peach.local;
import java.io.*;
import java.net.URI;
import org.json.*;
/** Optional one-body/one-image contract check; no third-party body or image is retained. */
public final class GalleryLiveSmoke {
    public static void main(String[] args)throws Exception {
        String proxy=System.getenv("HTTPS_PROXY");if(proxy!=null){URI u=URI.create(proxy);if(u.getHost()!=null && u.getPort()>0){System.setProperty("https.proxyHost",u.getHost());System.setProperty("https.proxyPort",Integer.toString(u.getPort()));}}
        String ref=FanboxConnector.creator(args.length>0?args[0]:"official"),post=args.length>1?args[1]:"12383501";
        JSONObject report=new JSONObject().put("checkedAt",java.time.Instant.now().toString()).put("creator",ref).put("postId",post).put("transport","SourceHttp.image via JDK HTTPS; not Android instrumentation").put("imageLimit",SourceHttp.IMAGE_LIMIT).put("thirdPartyMediaPackaged",false);
        File file=File.createTempFile("peach-gallery-smoke-",".tmp");
        try {
            JSONObject content=new FanboxConnector(SourceHttp.direct()).detail(ref,post,new SourceHttp.Token());JSONArray items=content.getJSONArray("attachments");report.put("result","no-compatible-image");
            for(int i=0;i<items.length();i++){JSONObject a=items.getJSONObject(i);if("image".equals(a.getString("kind")) && a.getBoolean("downloadable") && SourceHttp.downloadable(a.getString("url"))){var result=SourceHttp.image(a.getString("url"),file,new SourceHttp.Token());report.put("result","downloaded").put("bytes",result.bytes()).put("sha256",result.sha256()).put("host",URI.create(a.getString("url")).getHost());break;}}
        }catch(IOException | IllegalArgumentException e){report.put("result","unavailable").put("reason",e.getMessage());}
        finally{if(!file.delete() && file.exists())throw new IOException("No se pudo retirar la muestra temporal.");report.put("sampleDeleted",!file.exists());}
        System.out.println(report.toString(2));
    }
}
