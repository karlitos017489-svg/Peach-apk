package com.peach.local;
import java.net.URI;
import org.json.*;
/** One explicit public page. Reports counts/identity only; no page or third-party text is retained. */
public final class SubscribeStarLiveSmoke {
    public static void main(String[] args)throws Exception {
        String proxy=System.getenv("HTTPS_PROXY");if(proxy!=null){URI u=URI.create(proxy);if(u.getHost()!=null && u.getPort()>0){System.setProperty("https.proxyHost",u.getHost());System.setProperty("https.proxyPort",Integer.toString(u.getPort()));}}
        String ref=SubscribeStarUrls.creator(args.length>0?args[0]:"ribalinux");JSONObject report=new JSONObject().put("creator",ref).put("checkedAt",java.time.Instant.now().toString()).put("transport","SourceHttp.direct and SubscribeStarConnector via JDK HTTPS; not Android instrumentation").put("thirdPartyBodiesPackaged",false);
        try{var page=new SubscribeStarConnector(SourceHttp.direct()).newest(ref,"","",new SourceHttp.Token());report.put("result","parsed").put("candidates",page.candidates().length()).put("skipped",page.skipped());if(page.candidates().length()>0){var row=page.candidates().getJSONObject(0);report.put("firstPostId",row.getString("id")).put("firstPrecision",row.getString("precision")).put("partial",row.getBoolean("partial")).put("attachments",row.getJSONArray("attachments").length());}}
        catch(Exception e){report.put("result","unavailable").put("reason",e.getMessage());}
        System.out.println(report.toString(2));
    }
}
