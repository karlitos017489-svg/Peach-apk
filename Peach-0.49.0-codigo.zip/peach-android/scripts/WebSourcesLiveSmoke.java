package com.peach.local;
import java.net.URI;
import org.json.*;
/** Explicit synthetic references, aggregate outcomes only; never account credentials/media. */
public final class WebSourcesLiveSmoke {
    public static void main(String[] args)throws Exception{
        String proxy=System.getenv("HTTPS_PROXY");if(proxy!=null){URI u=URI.create(proxy);if(u.getHost()!=null && u.getPort()>0){System.setProperty("https.proxyHost",u.getHost());System.setProperty("https.proxyPort",Integer.toString(u.getPort()));}}
        JSONObject result=new JSONObject().put("checkedAt",java.time.Instant.now().toString()).put("transport","Production compiled SourceHttp and WebSourceConnector via JDK; not Android instrumentation").put("mediaRequested",false).put("credentialsProvided",false).put("bodiesPackaged",false);JSONArray outcomes=new JSONArray();
        for(String provider:new String[]{"rule34paheal","rule34xxx","rule34video","f95zone"}){
            int[] calls={0};var direct=SourceHttp.direct();var connector=new WebSourceConnector((u,e,m,t)->{calls[0]++;return direct.get(u,e,m,t);},()->null);JSONObject entry=new JSONObject().put("provider",provider);
            try{var page=connector.list(provider,provider.equals("f95zone")?"999999999999":"peach_contract_fixture_unassigned",0,"","",new SourceHttp.Token());entry.put("result","parsed-synthetic-reference").put("candidates",page.page().candidates().length());}catch(Exception e){entry.put("result",provider.equals("rule34xxx")?"requires-local-user-key":"unavailable").put("reason",e.getMessage());}entry.put("requests",calls[0]);outcomes.put(entry);
        }
        System.out.println(result.put("outcomes",outcomes).toString(2));
    }
}
