#!/usr/bin/env python3
"""Read pinned upstream source without executing it; emit media-family evidence."""
import argparse
import ast
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("upstream", type=Path)
parser.add_argument("--commit", required=True)
args = parser.parse_args()
source = args.upstream / "src/peach/scan.py"
families = {}
for node in ast.parse(source.read_text(encoding="utf-8")).body:
    if isinstance(node, ast.Assign):
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id in {"VIDEO", "IMAGE", "AUDIO", "ARCHIVE"}:
                families[target.id.lower()] = sorted(ast.literal_eval(node.value))
if len(families) != 4:
    raise SystemExit("Expected four explicit media-extension families")
files = ["src/peach/scan.py", "migrations/0002_canonical_entities.sql",
         "src/peach/catalog_versions.py", "src/peach/entities.py", "src/peach/wants.py",
         "docs/ARCHITECTURE.md", "docs/REUSE.md"]
print(json.dumps({"repository": "https://github.com/peach-mitao/peach",
    "commit": args.commit, "families": families,
    "other": "medium_of returns other for remaining suffixes; scan applies sidecar exclusions",
    "source_sha256": {name: hashlib.sha256((args.upstream / name).read_bytes()).hexdigest() for name in files}},
    ensure_ascii=False, indent=2))
