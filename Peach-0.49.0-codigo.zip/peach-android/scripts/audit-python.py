#!/usr/bin/env python3
"""Read pinned upstream dependencies and record exact wheel availability from PyPI.

An absent wheel is an evidence point, not proof that cross-compilation is impossible.
Usage: python scripts/audit-python.py /path/to/upstream /path/to/result.json
"""
import concurrent.futures
import datetime
import json
from pathlib import Path
import subprocess
import sys
import tomllib
import urllib.request

upstream = Path(sys.argv[1])
project = tomllib.loads((upstream / "pyproject.toml").read_text())

def inspect(requirement):
    name, version = requirement.split("==")
    url = f"https://pypi.org/pypi/{name}/{version}/json"
    result = {"requirement": requirement, "source": url}
    try:
        with urllib.request.urlopen(url, timeout=40) as response:
            data = json.load(response)
        wheels = [f["filename"] for f in data.get("urls", []) if f["filename"].endswith(".whl")]
        result.update(pure_python=any("none-any.whl" in f for f in wheels),
                      android_wheels=[f for f in wheels if "android" in f.lower()], wheel_count=len(wheels))
    except Exception as error:
        result["error"] = f"{type(error).__name__}: {error}"
    return result

with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
    dependencies = list(pool.map(inspect, project["project"]["dependencies"]))
result = {"time_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "commit": subprocess.check_output(["git", "-C", str(upstream), "rev-parse", "HEAD"], text=True).strip(),
          "requires_python": project["project"]["requires-python"], "dependencies": dependencies}
Path(sys.argv[2]).write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
print(f"Recorded {len(dependencies)} dependencies; {sum('error' in d for d in dependencies)} retrieval failures")
