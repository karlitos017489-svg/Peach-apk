#!/usr/bin/env python3
"""Collect completed runner protocol and exact package-update evidence, preserving earlier failures."""
from pathlib import Path
import argparse,json,re,collections,shutil,hashlib
p=argparse.ArgumentParser();p.add_argument('--directory',required=True);a=p.parse_args();R=Path(__file__).resolve().parents[1];src=Path(a.directory);out=R/'docs/evidence/0.47.0';dest=out/'android';dest.mkdir(exist_ok=True)
def parse(text):
 fields={};cases={};started=set();expected=0
 for line in text.splitlines():
  if line.startswith('INSTRUMENTATION_STATUS: '):
   key,sep,value=line[len('INSTRUMENTATION_STATUS: '):].partition('=')
   if sep:fields[key]=value
  elif line.startswith('INSTRUMENTATION_STATUS_CODE: '):
   code=int(line.split(': ',1)[1]);expected=max(expected,int(fields.get('numtests','0')))
   if fields.get('class') and fields.get('test'):
    pair=(fields['class'],fields['test'])
    if code==1:started.add(pair)
    elif code<=0:cases[pair]=code
   fields={}
 c=collections.Counter(cases.values());unfinished=len(started-set(cases))
 return {'expected':expected,'completed_cases':len(cases),'executed':sum(c[n] for n in (0,-1,-2))+unfinished,'started_cases':len(started),'unfinished_cases':unfinished,'process_crashed':'shortMsg=Process crashed.' in text,'passed':c[0],'failures':c[-2],'errors':c[-1],'skipped':c[-3]+c[-4],'runner_finished':bool(re.search(r'INSTRUMENTATION_CODE: -1\b',text)),'cases':[{'class':cl,'test':t,'code':code} for (cl,t),code in cases.items()]}
attempts=[]
for name,phase in [('new047-instrumentation28.txt','initial_fixture_startup_crash'),('004-fixed-new-four.txt','fixture_fixed_rar_failed'),('007-native-fixed-four.txt','native_rar_fixed_four_passed'),('full-first-native-failures.txt','first_full_suite_before_zip64_and_fixture_wait_fixes')]:
 f=dest/name
 if f.exists():attempts.append(dict(phase=phase,**parse(f.read_text())))
steps=src/'steps'
def result(name):return json.loads((steps/(name+'.json')).read_text())
final=result('13-final-full-suite');measured=parse(final['stdout'])
assert final['code']==0 and not final['timed_out_or_stopped'] and measured['runner_finished'],final
assert measured['expected']==measured['completed_cases']==73 and measured['unfinished_cases']==measured['failures']==measured['errors']==0 and not measured['process_crashed'],measured
attempts.append(dict(phase='final_full_suite_after_recovery',**measured))
seed=result('03-seed-baseline');assert seed['code']==0 and 'OK (1 test)' in seed['stdout']
before=result('07-before-hashes');after=result('10-after-hashes');assert before['code']==after['code']==0
hashes=lambda text:{line.split(None,1)[1]:line.split(None,1)[0] for line in text.strip().splitlines()}
b=hashes(before['stdout']);assert b==hashes(after['stdout']) and {'databases/peach-local.db','shared_prefs/peach-appearance.xml'}<=set(b)
assert 'versionCode=46 ' in result('08-package046')['stdout'] and 'versionCode=47 ' in result('11-package047')['stdout'] and 'Success' in result('09-final047-install')['stdout']
candidate=json.loads((src/'candidate.json').read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert candidate['apk_sha256']==sha(R/'app/build/outputs/apk/debug/app-debug.apk') and candidate['test_apk_sha256']==sha(R/'app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk')
run=dest/'final-run';shutil.copytree(steps,run/'steps',dirs_exist_ok=True)
for name in ['candidate.json','upgrade-passed.json','status.json','getprop.txt','boot.log','run.log','crash.txt','logcat.txt','run-final.py','packages.json']:
 if (src/name).exists():shutil.copy2(src/name,run/name)
summary={'compiled':73,**{k:v for k,v in measured.items() if k!='cases'},'environment':{'kind':'official Android emulator, software TCG, no KVM','sdk':28,'android':'9','abi':'x86_64','physical_samsung':False,'real_cloud_or_private_accounts':False},'candidate':candidate,'attempts':attempts,'api36_boot_incomplete':True,'upgrade046_to047':{'executed':True,'baseline_native_worker_passed':True,'seeded_media':1105,'favorite_and_progress_verified_before_update':True,'own_appearance_preferences':True,'database_and_wal_and_prefs_sha256_identical':True,'files':b,'scope':'Disposable API28/x86_64 emulator. Exact own DB/WAL/SHM and prefs bytes across signed package update; not Samsung, persisted external SAF grants, real accounts or keystore update certification.'}}
(out/'native-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='attempts'},ensure_ascii=False,indent=2))
