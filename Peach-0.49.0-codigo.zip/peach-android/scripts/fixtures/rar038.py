#!/usr/bin/env python3
"""Self-authored stored RAR fixtures, cross-read with system libarchive (test tool only)."""
import struct,zlib,pathlib,json,ctypes,hashlib
R=pathlib.Path(__file__).resolve().parents[2];D=R/'app/src/test/resources/rar038';D.mkdir(parents=True,exist_ok=True)
def v(n):
 b=bytearray()
 while n>=128:b.append((n&127)|128);n>>=7
 b.append(n);return bytes(b)
def h5(t,f,body=b'',extra=b'',data=b''):
 f|=bool(extra)|2*bool(data)| (2 if t==2 else 0);b=v(t)+v(f)+(v(len(extra)) if extra else b'')+(v(len(data)) if f&2 else b'')+body+extra;s=v(len(b));return struct.pack('<I',zlib.crc32(s+b))+s+b+data
def h4(t,f,b=b''):
 x=struct.pack('<BHH',t,f,len(b)+7)+b;return struct.pack('<H',zlib.crc32(x)&65535)+x
png=(R/'app/src/test/resources/media/small.png').read_bytes()
files={'images/10.png':png,'images/2.png':png,'notes.txt':'Texto propio Peach: estratos y minerales.'.encode(),'empty.txt':b'','nested.rar':b'no anidado','video.mp4':b'no video interno'}
def a4():
 out=b'Rar!\x1a\x07\x00'+h4(0x73,0,b'\0'*6)
 for name,data in files.items():
  n=name.encode();body=struct.pack('<IIBIIBBHI',len(data),len(data),3,zlib.crc32(data),0,20,0x30,len(n),0o100644)+n
  out+=h4(0x74,0x8000,body)+data
 return out+h4(0x7b,0)
def a5():
 out=b'Rar!\x1a\x07\x01\x00'+h5(1,0,v(0))
 for name,data in files.items():
  if name=='notes.txt':name='notas/ñ.txt'
  n=name.encode();body=v(4)+v(len(data))+v(0o100644)+struct.pack('<I',zlib.crc32(data))+v(0)+v(1)+v(len(n))+n
  out+=h5(2,0,body,data=data)
 return out+h5(5,0,v(0))
for name,b in [('album-rar4.cbr',a4()),('album-rar5.rar',a5())]:(D/name).write_bytes(b)
# A separately maintained decoder must read each fixture and produce its original bytes.
a=ctypes.CDLL('libarchive.so.13')
for name,restype,args in [('archive_read_new',ctypes.c_void_p,[]),('archive_read_support_format_all',ctypes.c_int,[ctypes.c_void_p]),('archive_read_support_filter_all',ctypes.c_int,[ctypes.c_void_p]),('archive_read_open_filename',ctypes.c_int,[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_size_t]),('archive_read_next_header',ctypes.c_int,[ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p)]),('archive_entry_pathname',ctypes.c_char_p,[ctypes.c_void_p]),('archive_read_data',ctypes.c_ssize_t,[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_size_t]),('archive_read_free',ctypes.c_int,[ctypes.c_void_p]),('archive_version_string',ctypes.c_char_p,[])]:
 f=getattr(a,name);f.restype=restype;f.argtypes=args
report={'cross_reader':a.archive_version_string().decode(),'fixtures':[],'content':'self-authored text and existing self-authored PNG; no user files'}
for p in sorted(D.glob('*')):
 reader=a.archive_read_new();a.archive_read_support_format_all(reader);a.archive_read_support_filter_all(reader);assert a.archive_read_open_filename(reader,str(p).encode(),10240)==0
 names=[];entry=ctypes.c_void_p();buf=ctypes.create_string_buffer(8192)
 try:
  while True:
   ret=a.archive_read_next_header(reader,ctypes.byref(entry))
   if ret==1:break
   assert ret==0,(p.name,ret)
   name=a.archive_entry_pathname(entry).decode();body=b''
   while True:
    n=a.archive_read_data(reader,buf,len(buf));assert n>=0
    if n==0:break
    body+=buf.raw[:n]
   assert body==files.get('notes.txt' if name=='notas/ñ.txt' else name);names.append(name)
 finally:a.archive_read_free(reader)
 assert len(names)==len(files)
 report['fixtures'].append({'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'entries':names,'all_payloads_match':True})
V=R/'docs/evidence/0.38.0';V.mkdir(parents=True,exist_ok=True);(V/'fixture-cross-reader.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False))
