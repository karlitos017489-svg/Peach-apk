#!/usr/bin/env python3
"""Own fixtures only. External RAR trial tools are never included in the project/APK."""
import pathlib,argparse,tempfile,struct,subprocess,json,hashlib
p=argparse.ArgumentParser();p.add_argument('--rar4',required=True);p.add_argument('--rar5',required=True);a=p.parse_args();R=pathlib.Path(__file__).resolve().parents[2];D=R/'app/src/test/resources/rar039';D.mkdir(exist_ok=True)
width,height=120,80;row=b'\x00\x00\xff'*60+b'\xff\x00\x00'*60;pixels=row*height
bmp=b'BM'+struct.pack('<IHHI',54+len(pixels),0,0,54)+struct.pack('<IiiHHIIiiII',40,width,height,1,24,0,len(pixels),2835,2835,0,0)+pixels
(D/'page.bmp').write_bytes(bmp)
with tempfile.TemporaryDirectory(prefix='peach-rar-own-') as tmp:
 d=pathlib.Path(tmp);(d/'images').mkdir();png=(R/'app/src/test/resources/media/small.png').read_bytes()
 for n in ['2.png','10.png']:(d/'images'/n).write_bytes(png)
 (d/'notes.txt').write_text('Peach: estratos sedimentarios y minerales.\n'*2000);(d/'page.bmp').write_bytes(bmp)
 for era,tool in [('rar4',a.rar4),('rar5',a.rar5)]:
  for method in [1,3,5]:
   out=D/f'own-{era}-m{method}.cbr';out.unlink(missing_ok=True)
   subprocess.run([str(pathlib.Path(tool).resolve()),'a','-idq','-r','-s-','-ma4' if era=='rar4' else '-ma5',f'-m{method}','-md4m','-htc','-qo-',str(out),'images','notes.txt','page.bmp'],cwd=d,check=True)
with tempfile.TemporaryDirectory(prefix='peach-rar-budget-') as tmp:
 d=pathlib.Path(tmp);(d/'large.txt').write_text('Peach: estratos sedimentarios y minerales.\n'*100000)
 out=D/'budget-rar5.cbr';out.unlink(missing_ok=True)
 subprocess.run([str(pathlib.Path(a.rar5).resolve()),'a','-idq','-s-','-ma5','-m3','-md4m','-htc','-qo-',str(out),'large.txt'],cwd=d,check=True)
report={'content':'own BMP, prior own synthetic PNG and own repeated geology text','producers':['RAR6.24 RAR4','RAR7.23 RAR5 -ma5'],'producer_binaries_not_distributed':True,'files':[dict(file=f.name,bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in sorted(D.iterdir())]}
(R/'docs/evidence/0.39.0/fixtures.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report))
