#!/usr/bin/env python3
"""Own Unicode filenames and media only; external RAR fixture tool not redistributed."""
import argparse,pathlib,tempfile,struct,zlib,subprocess,hashlib,json
p=argparse.ArgumentParser();p.add_argument('--rar4',required=True);a=p.parse_args()
R=pathlib.Path(__file__).resolve().parents[2];D=R/'app/src/test/resources/rar040';D.mkdir(exist_ok=True)
names=['notas/niñez.txt','日本語/地層.txt','emoji/roca-🪨.txt','imágenes/2.bmp']
text='Peach: estratos sedimentarios y minerales.\n'.encode()*2000
bmp=(R/'app/src/test/resources/rar039/page.bmp').read_bytes()
contents={n:bmp if n.endswith('.bmp') else text for n in names}
tool=str(pathlib.Path(a.rar4).resolve())
with tempfile.TemporaryDirectory(prefix='peach-unicode040-') as t:
 d=pathlib.Path(t)
 for n,b in contents.items():
  f=d/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
 for method in (0,3):
  out=D/f'official-unicode-m{method}.cbr';out.unlink(missing_ok=True)
  subprocess.run([tool,'a','-idq','-r','-s-','-ma4',f'-m{method}','-md4m','-htc','-qo-',str(out),*[n for n in names if not n.startswith('emoji/')]],cwd=d,check=True)
def header(t,f,body=b''):
 b=struct.pack('<BHH',t,f,7+len(body))+body
 return struct.pack('<H',zlib.crc32(b)&65535)+b
def legacy(name):
 # Literal UTF-16 instructions, prefix is deliberately NOT the displayed name.
 # The index and the native engine must both use Unicode rather than the prefix.
 u=name.replace('/','\\').encode('utf-16le');units=[u[i:i+2] for i in range(0,len(u),2)]
 encoded=b''
 for i in range(0,len(units),4):encoded+=b'\xaa'+b''.join(units[i:i+4])
 return b'x'*len(units)+b'\0\0'+encoded
records={};b=(R/'app/src/test/resources/rar039/own-rar4-m3.cbr').read_bytes();at=7
while at<len(b):
 kind,flags,size=struct.unpack_from('<BHH',b,at+2);packed=struct.unpack_from('<I',b,at+7)[0] if flags&0x8000 else 0
 if kind==0x74:
  length=struct.unpack_from('<H',b,at+26)[0];name=b[at+32:at+32+length].decode().replace('\\','/')
  records[name]=(b[at+25],b[at+size:at+size+packed])
 at+=size+packed
for compressed in (False,True):
 out=b'Rar!\x1a\x07\0'+header(0x73,0,b'\0'*6)
 for name,data in contents.items():
  raw=legacy(name);method,payload=records['page.bmp' if name.endswith('.bmp') else 'notes.txt'] if compressed else (0x30,data)
  body=struct.pack('<IIBIIBBHI',len(payload),len(data),3,zlib.crc32(data),0,29,method,len(raw),0o100644)+raw
  out+=header(0x74,0x8220,body)+payload
 (D/('legacy-compressed.cbr' if compressed else 'legacy-stored.cbr')).write_bytes(out+header(0x7b,0))
# Official external reader independently validates our synthetic headers and exact data.
report={'names':names,'content':'own repeated geology text and own red/blue BMP from 0.39','tool':'official RAR6.24, external fixture tool only','tool_not_redistributed':True,'fixtures':[]}
for f in sorted(D.glob('*.cbr')):
 subprocess.run([tool,'t','-idq',str(f)],check=True,capture_output=True)
 selected=[]
 for name,expected in contents.items():
  if name.startswith('emoji/') and f.name.startswith('official'):continue
  # RAR6.24/Linux's legacy filename display loses non-BMP surrogates. Wildcard
  # checks its payload, NOT exact Unicode name fidelity; pinned JNI tests cover that.
  selector='emoji/*' if name.startswith('emoji/') else name
  result=subprocess.run([tool,'p','-idq','-inul',str(f),selector],capture_output=True,check=True)
  assert result.stdout==expected,(f.name,name,len(result.stdout))
  selected.append({'name':name,'exact_name_checked_by_official_tool':selector==name,'bytes':len(expected),'sha256':hashlib.sha256(expected).hexdigest()})
 report['fixtures'].append({'file':f.name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'official_reader_all_bytes_match':True,'selections':selected})
V=R/'docs/evidence/0.40.0';V.mkdir(parents=True,exist_ok=True);(V/'fixtures.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
assets=R/'app/src/androidTest/assets/rar040';assets.mkdir(exist_ok=True)
for name in ('legacy-stored.cbr','legacy-compressed.cbr'):(assets/name).write_bytes((D/name).read_bytes())
print(json.dumps(report,ensure_ascii=False))
