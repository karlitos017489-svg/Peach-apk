#!/usr/bin/env python3
"""Own solid RAR5 samples; official external fixture tool is never redistributed."""
from pathlib import Path
import argparse,subprocess,tempfile,json,hashlib,os,struct,zlib
p=argparse.ArgumentParser();p.add_argument('--rar',required=True);a=p.parse_args()
R=Path(__file__).resolve().parents[2];D=R/'app/src/test/resources/rar041';D.mkdir(exist_ok=True)
names=['01/notas-ñ.txt','02/capa-日本語.txt','03/imagen.bmp','04/final.txt']
note='Peach: estratos sedimentarios y minerales.\n'.encode()*2000
contents={names[0]:note,names[1]:note+b'Segunda capa.\n',names[2]:(R/'app/src/test/resources/rar039/page.bmp').read_bytes(),names[3]:note+b'Ultima capa.\n'}
tool=str(Path(a.rar).resolve());report={'tool':'official external RAR6.24','tool_redistributed':False,'content':'own geology text and red/blue BMP','fixtures':[]}
with tempfile.TemporaryDirectory(prefix='peach-solid041-') as tmp:
    t=Path(tmp)
    for n,b in contents.items():
        f=t/n;f.parent.mkdir(exist_ok=True,parents=True);f.write_bytes(b);os.utime(f,(1700000000,1700000000))
    for method in (1,3,5):
        f=D/f'own-solid-rar5-m{method}.cbr';f.unlink(missing_ok=True)
        subprocess.run([tool,'a','-idq','-ma5','-s',f'-m{method}','-md4m','-htc','-qo-',str(f),*names],cwd=t,check=True)
        subprocess.run([tool,'t','-idq',str(f)],capture_output=True,check=True)
        selected=[]
        for n,b in contents.items():
            data=subprocess.run([tool,'p','-idq','-inul',str(f),n],capture_output=True,check=True).stdout
            assert data==b
            selected.append({'name':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
        report['fixtures'].append({'file':f.name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'selections':selected})
# Controlled damage of our own archive; recalculate header CRC to isolate data CRC.
def vint(b,at):
    value=shift=0
    while True:
        v=b[at];at+=1;value|=(v&127)<<shift
        if v<128:return value,at
        shift+=7
original=(D/'own-solid-rar5-m3.cbr').read_bytes();at=8;blocks=[]
while at<len(original):
    size,start=vint(original,at+4);end=start+size;kind,c=vint(original,start);flags,c=vint(original,c);packed=0
    if flags&1:_,c=vint(original,c)
    if flags&2:packed,c=vint(original,c)
    if kind==2:
        ff,c=vint(original,c);_,c=vint(original,c);_,c=vint(original,c)
        if ff&2:c+=4
        assert ff&4
        blocks.append((at,end,c,packed))
    at=end+packed
assert len(blocks)==4
for label,index in [('bad-first-crc',0),('bad-last-crc',-1)]:
    at,end,crc,packed=blocks[index];b=bytearray(original);b[crc]^=1
    struct.pack_into('<I',b,at,zlib.crc32(b[at+4:end]))
    (D/(label+'.cbr')).write_bytes(b)
at,end,crc,packed=blocks[0];b=bytearray(original);b[end+packed//2]^=0x80;(D/'bad-first-data.cbr').write_bytes(b)
report['controlled_mutations']=['bad-first-crc.cbr','bad-last-crc.cbr','bad-first-data.cbr']
V=R/'docs/evidence/0.41.0';V.mkdir(parents=True,exist_ok=True);(V/'fixtures.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
assets=R/'app/src/androidTest/assets/rar041';assets.mkdir(exist_ok=True)
(assets/'own-solid-rar5-m3.cbr').write_bytes((D/'own-solid-rar5-m3.cbr').read_bytes())
print(json.dumps(report,ensure_ascii=False))
