#!/usr/bin/env python3
"""Own synthetic H.264/AAC and existing own RAR sample; no user/upstream media."""
from pathlib import Path
import subprocess,hashlib,json,shutil
r=Path(__file__).resolve().parents[1];d=r/'app/src/main/assets/check470';d.mkdir(exist_ok=True)
command=['ffmpeg','-hide_banner','-loglevel','error','-f','lavfi','-i','testsrc2=size=160x90:rate=10','-f','lavfi','-i','sine=frequency=440:sample_rate=44100','-t','1','-c:v','libx264','-profile:v','baseline','-level','2.0','-pix_fmt','yuv420p','-g','10','-c:a','aac','-b:a','32k','-movflags','+faststart','-metadata','title=Peach own diagnostic fixture','-y',str(d/'sample.mp4')]
subprocess.run(command,check=True);shutil.copyfile(r/'app/src/androidTest/assets/rar041/own-solid-rar5-m3.cbr',d/'sample.cbr')
manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(d.iterdir()) if p.suffix in ('.mp4','.cbr')}
(d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
provenance={'content':'Own lavfi color/test pattern and synthesized 440 Hz sine; no upstream or personal media. Own RAR5 text/BMP sample from scripts/fixtures/rar041.py, external RAR tool not redistributed.','ffmpeg':subprocess.check_output(['ffmpeg','-version'],text=True).splitlines()[0],'command':command[:-1]+['sample.mp4'],'files':manifest}
(r/'docs/evidence/0.47.0/fixture-provenance.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2)+'\n')
