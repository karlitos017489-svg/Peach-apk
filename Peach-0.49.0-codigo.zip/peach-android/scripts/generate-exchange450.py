#!/usr/bin/env python3
"""Own small data exchange example. No user content, credentials, grants or network."""
from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parents[1];out=r/'app/src/test/resources/exchange450';out.mkdir(exist_ok=True)
raw='Muestra propia de Peach: capas, minerales y estratos.\n'.encode()
root='r-'+hashlib.sha256(b'own-example-root').hexdigest();media='m-'+hashlib.sha256(b'own-example-text').hexdigest()
state={'format':'peach-local-state','version':19}
for section in ['items','playlists','groups','entities','aliases','entityLinks','entityReferences','wants','readerProgress','catalogSnapshots','memberships','wantTracking','publications','sources','publicationContent','usageSessions']:state[section]=[]
state['items']=[{'id':media,'favorite':True,'watched':False,'position':0,'duration':0,'lastPlayed':0,'playCount':0,'userTitle':'Lectura de ejemplo propia','userTags':'capas'}]
state['readerProgress']=[{'mediaId':media,'entry':'','page':0,'scroll':0,'updatedAt':1700000000000}]
data={'state':state,'roots':[{'id':root,'label':'Ejemplo propio'}], 'media':[{'id':media,'root':root,'path':'documentos/muestra.txt','name':'muestra.txt','bytes':len(raw),'missing':False}], 'metadata':[{'mediaId':media,'title':'muestra','tags':'','actors':'','studio':'','plot':'','year':'','nfoDetails':'{}','addedAt':1700000000000}]}
canonical=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
packet={'format':'peach-local-exchange','version':1,'peer':'45000000-0000-4000-8000-000000000001','label':'Ejemplo propio Peach','packet':'45000000-0000-4000-8000-000000000002','createdAt':1700000000000,'sequence':1,'data':data,'sha256':hashlib.sha256(canonical(data).encode()).hexdigest()}
(out/'Peach-ejemplo-intercambio.json').write_text(canonical(packet)+'\n',encoding='utf-8');(out/'documentos').mkdir(exist_ok=True);(out/'documentos/muestra.txt').write_bytes(raw)
(out/'LEEME.md').write_text('''# Ejemplo propio de intercambio

Extrae este ZIP en una carpeta propia. En Peach añade/escanea esa carpeta (la raíz que
contiene `documentos`). Abre Menú → Importación y sincronización → Elegir intercambio,
y selecciona `Peach-ejemplo-intercambio.json`. Vincula «Ejemplo propio» con esa carpeta.
Revisa favorito, título y etiquetas por campo; los conflictos conservan lo local salvo
que elijas Entrante. Aplica solo lo que desees. No importa automáticamente los medios;
el TXT se reconoce al escanear la carpeta. No hay contraseñas o cuentas en este ejemplo.
La fecha fija del ejemplo no es una fecha real de uso. Puedes probar Deshacer si no has
hecho nuevos cambios en la biblioteca. No uses este archivo como base de otra persona.
''',encoding='utf-8')
assets=r/'app/src/androidTest/assets/exchange450';assets.mkdir(exist_ok=True);shutil.copy2(out/'Peach-ejemplo-intercambio.json',assets/'Peach-ejemplo-intercambio.json')
(out/'provenance.json').write_text(json.dumps({'kind':'own synthetic metadata/text, fixed fake UUIDs/dates','files':[{'name':str(f.relative_to(out)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(out.rglob('*')) if f.is_file() and f.name!='provenance.json']},indent=2)+'\n')
print('own exchange example generated')
