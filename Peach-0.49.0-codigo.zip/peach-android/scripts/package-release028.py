#!/usr/bin/env python3
"""Package clean source/history and verified deliverables; never includes a signing key."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,tempfile,zipfile
p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--build-root',required=True);a=p.parse_args();R=Path(__file__).resolve().parents[1];D=Path(a.out)
def git(*args):return subprocess.run(['git',*args],cwd=R,capture_output=True,check=True).stdout
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not git('status','--porcelain')
head=git('rev-parse','HEAD').decode().strip();assert git('rev-parse','HEAD^').decode().strip()=='ea9b30420cbb499eec4f7ca6e31af02e195f9b8e'
files=[n for n in git('ls-files','-z').decode().split('\0') if n]
for n in files:
 assert not n.lower().endswith(('.jks','.keystore')),n
 assert 'Peach-progreso.json' not in n,n
 assert (R/n).read_bytes()==git('show','HEAD:'+n),n
v=json.loads((D/'Peach-Local-verificacion-0.28.0.json').read_text());assert v['unit']['tests']==601 and v['unit']['failures']==0
for k in ('apk','test_apk'):assert sha(D/v[k]['file'])==v[k]['sha256']
bundle=D/'Peach-Local-historial-0.28.0.bundle';git('bundle','create',str(bundle),'--all');git('bundle','verify',str(bundle))
v['source']={'commit':head,'parent':'ea9b30420cbb499eec4f7ca6e31af02e195f9b8e','tracked_files':len(files),'bundle_sha256':sha(bundle)}
(D/'Peach-Local-verificacion-0.28.0.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
(D/'CONTINUAR.md').write_text(f'''# Continuar Peach Local0.28.0\n\nHEAD {head}; {len(files)} archivos versionados. La fuente coincide con el commit.\n\nUsuario informa que0.27 no resolvió BIN/GIF y descarga superior a128MiB dejaba0 bytes.\n0.28: enlaces públicos de calidad en Rule34Video; preparación privada antes de SAF;\n2GiB/1hora con controles de espacio; inspección de cabecera; apertura de GIF y animación\nAndroid28+ con fuente ByteBuffer y descriptores cerrados (mapa de archivo o fallback\nacotado64MiB si no es posicionable). Si SAF informa0 tras copiar no se habilita éxito.\n\n601 pruebas locales/94 clases aprobadas; lint0 errores, avisos detallados en informe.\n30 pruebas Android compiladas,0 ejecutadas. Ninguna confirmación física nueva; el caso\nreal y el proyecto siguen abiertos. No pedir otra vez claves, JSON privado o todo el\ncontexto. La captura no se empaquetó. Los medios de prueba son sintéticos propios.\n\nRoom13 intacto, copia17 lee1–17, nueve fuentes. Excluidos Kemono/Coomer/SimpCity.\nReconsultar el cuerpo para renovar los BIN de referencia antiguos; los0 bytes antiguos\ndeben descargarse de nuevo, sin borrar automáticamente archivos del usuario.\n\nAPK conserva firma original; instalar sin desinstalar. Clave privada de firma fuera\ndel ZIP: no regenerarla si se necesitan actualizaciones sobre la misma instalación.\nLicencia y atribuciones AGPL3+ conservadas. Ver docs/PRUEBAS.md, COMPATIBILIDAD_ORIGINAL.md,\nPLAN_FUENTES.md y GUIA_DESCARGAS_028.md. scripts/verify-release028.py verifica la entrega.\nLa fuente está en peach-android/ y el bundle contiene el historial completo.\n''')
with tempfile.TemporaryDirectory(prefix='peach-028-package-') as temp:
 archive=Path(temp)/'Peach-Local-proyecto-y-pruebas-0.28.0.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n in files:z.write(R/n,'peach-android/'+n)
  for f in sorted(D.iterdir()):
   if f.is_file() and not f.name.endswith(('.zip','.pending')):z.write(f,f.name)
  report=Path(a.build_root)/'app/reports/tests/testDebugUnitTest'
  for f in sorted(report.rglob('*')):
   if f.is_file():z.write(f,'test-report/'+str(f.relative_to(report)))
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  for n in files:assert z.read('peach-android/'+n)==(R/n).read_bytes(),n
 final=D/archive.name;pending=D/(archive.name+'.pending');shutil.copyfile(archive,pending);pending.replace(final);assert sha(final)==sha(archive)
 v['source_zip']={'file':final.name,'bytes':final.stat().st_size,'sha256':sha(final)}
(D/'Peach-Local-verificacion-0.28.0.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'commit':head,'tracked_files':len(files),'source_zip':v['source_zip']},ensure_ascii=False,indent=2))
