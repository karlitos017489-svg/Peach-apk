#!/usr/bin/env python3
"""Package clean source/history and verified deliverables; never includes a signing key."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,tempfile,zipfile
p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--build-root',required=True);a=p.parse_args();R=Path(__file__).resolve().parents[1];D=Path(a.out)
def git(*args):return subprocess.run(['git',*args],cwd=R,capture_output=True,check=True).stdout
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not git('status','--porcelain')
head=git('rev-parse','HEAD').decode().strip();assert git('rev-parse','HEAD^').decode().strip()=='3beee890f9d36726d4d37251ea3b72fd85943227'
files=[n for n in git('ls-files','-z').decode().split('\0') if n]
for n in files:
 assert not n.lower().endswith(('.jks','.keystore')),n
 assert 'Peach-progreso.json' not in n,n
 assert (R/n).read_bytes()==git('show','HEAD:'+n),n
v=json.loads((D/'Peach-Local-verificacion-0.30.0.json').read_text());assert v['unit']['tests']==638 and v['unit']['failures']==0
for k in ('apk','test_apk'):assert sha(D/v[k]['file'])==v[k]['sha256']
bundle=D/'Peach-Local-historial-0.30.0.bundle';git('bundle','create',str(bundle),'--all');git('bundle','verify',str(bundle))
v['source']={'commit':head,'parent':'3beee890f9d36726d4d37251ea3b72fd85943227','tracked_files':len(files),'bundle_sha256':sha(bundle)}
(D/'Peach-Local-verificacion-0.30.0.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
(D/'CONTINUAR.md').write_text(f"""# Continuar Peach Local0.30.0

HEAD {head}; {len(files)} archivos versionados; fuente y bundle íntegros.

El usuario confirmó que0.29 resolvió el error previo de redirección en su tablet y
pidió continuar.0.30 amplía la galería a imágenes compatibles importadas de FANBOX,
Pawchive, cum.st, Rule34 Paheal, Rule34.xxx y F95zone, conservando hosts/rutas y
separación entre proveedores. Pawchive conserva SHA esperado al descargar/leer caché;
se reevalúan referencias antiguas con bandera falsa sin modificar los cuerpos.
GIF/WebP por cabecera se animan en API28+ mediante ByteBuffer mapeado inmutable;
API26 conserva primer fotograma. Pausa/reanudación, navegación, rotación y caché
sin conexión.16MiB/imagen,64MiB/128 imágenes; sin precarga. Caches descartables.

638 pruebas locales/100 clases aprobadas;37 dirigidas aprobadas. Lint0 errores/40 avisos.
32 instrumentadas compiladas,0 ejecutadas: no dispositivo/emulador conectado. La HTTP
se simula y las imágenes son propias. No hubo consultas a medios del usuario/fuentes.
Primera compilación dirigida falló en helper de prueba por Files.writeString; se corrigió
y los logs se conservan. No hay fallo final, CloseGuard, error de API o SQLite en XML.

Room13/copia17, permisos, dependencias, assets y nativos intactos;254 clases Peach
conservadas. Nueve proveedores; Kemono/Coomer/SimpCity excluidos. Las tarjetas de
Patreon/SubscribeStar y video Rule34Video no se convierten en galerías de imágenes.
Videos guardados mantienen la apertura local de0.29. Siguen pendientes video remoto,
Gofile/masked, cuentas/cuerpos adicionales, lotes/reanudación y demás paridad original.

Instalar sobre0.29 sin desinstalar. Firma original comprobada; nunca regenerar la clave
para continuar actualizando esa instalación. La clave privada está fuera del ZIP y
se conserva por separado. Esta versión nueva sigue pendiente de confirmación física.
El proyecto no está terminado. Ver PRUEBAS.md, PLAN_FUENTES.md, GALERIA_FUENTES.md,
GUIA_GALERIA_030.md y COMPATIBILIDAD_ORIGINAL.md. Fuente completo en peach-android/,
historial completo en bundle, APK principal y APK de pruebas incluidos.
""")
with tempfile.TemporaryDirectory(prefix='peach-030-package-') as temp:
 archive=Path(temp)/'Peach-Local-proyecto-y-pruebas-0.30.0.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n in files:z.write(R/n,'peach-android/'+n)
  for f in sorted(D.iterdir()):
   if f.is_file() and not f.name.endswith(('.zip','.pending')):z.write(f,f.name)
  report=Path(a.build_root)/'app/reports/tests/testDebugUnitTest'
  for f in sorted(report.rglob('*')):
   if f.is_file():z.write(f,'test-report/'+str(f.relative_to(report)))
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  for n in files:assert z.read('peach-android/'+n)==(R/n).read_bytes(),n
 final=D/archive.name;pending=D/(archive.name+'.pending');shutil.copyfile(archive,pending);pending.replace(final);assert sha(final)==sha(archive)
 v['source_zip']={'file':final.name,'bytes':final.stat().st_size,'sha256':sha(final)}
(D/'Peach-Local-verificacion-0.30.0.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'commit':head,'tracked_files':len(files),'source_zip':v['source_zip']},ensure_ascii=False,indent=2))
