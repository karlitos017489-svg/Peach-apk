#!/usr/bin/env python3
"""Package clean source/history and verified deliverables; never includes a signing key."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,tempfile,zipfile
p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--build-root',required=True);a=p.parse_args();R=Path(__file__).resolve().parents[1];D=Path(a.out)
def git(*args):return subprocess.run(['git',*args],cwd=R,capture_output=True,check=True).stdout
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not git('status','--porcelain')
head=git('rev-parse','HEAD').decode().strip();assert git('rev-parse','HEAD^').decode().strip()=='7ccfd338f44fc820857255fbbce48bd73c2d105f'
files=[n for n in git('ls-files','-z').decode().split('\0') if n]
for n in files:
 assert not n.lower().endswith(('.jks','.keystore')),n
 assert 'Peach-progreso.json' not in n,n
 assert (R/n).read_bytes()==git('show','HEAD:'+n),n
v=json.loads((D/'Peach-Local-verificacion-0.35.0.json').read_text());assert v['unit']['tests']==765 and v['unit']['failures']==0
for k in ('apk','test_apk'):assert sha(D/v[k]['file'])==v[k]['sha256']
bundle=D/'Peach-Local-historial-0.35.0.bundle';git('bundle','create',str(bundle),'--all');git('bundle','verify',str(bundle))
v['source']={'commit':head,'parent':'7ccfd338f44fc820857255fbbce48bd73c2d105f','tracked_files':len(files),'bundle_sha256':sha(bundle)}
(D/'Peach-Local-verificacion-0.35.0.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
(D/'CONTINUAR.md').write_text(f"""# Continuar Peach Local0.35.0

HEAD {head}; {len(files)} archivos versionados. Padre7ccfd338f44fc820857255fbbce48bd73c2d105f.
Usuario aceptó0.34 y reportó demora/baja calidad/previews en VARIAS fuentes: Rule34Video,
cum.st y otro Rule34. No preguntar de nuevo ni limitar diagnóstico a una.0.35 aún requiere
aceptación en su tablet; proyecto abierto, no paridad completa.

0.35 etiquetas preview/versión/archivo/variante, altura numérica p y bytes declarados.
Mayor altura en primer grupo no preview; manual/rotación. cum.st conserva alternativas
video, evita póster mayor, omite locked/manifiestos y reserva principales antes de extras
bajo100 adjuntos. Rule34.xxx usa file_url nunca sample/preview. No fabricar HD/duración.
Consultar versiones: consulta explícita individual a detalle R34Video/Paheal o API cum.st
existentes, sin medios; revisión y Usar versiones para escribir. Preserva ficha/notas/
vínculos/archivos, protege identidad/cuerpo obsoletos/pausa/429/cancelación/vacío/downgrade.

VideoStream reutiliza destino Rule34Video validado SOLO RAM durante sesión, nueva DNS/
HTTPS por apertura, elimina al cerrar.403/404/410 un retorno al origen;429 no. Cambio de
representación/destino aún falla; nada persistido en Room/JSON/cache/Intent.3 solicitudes
controladas frente a4 anteriores, no benchmark de CDN real. Player buffering/dimensiones
según Media3. Mantiene fix Icy-MetaData0.34, streaming16GiB/objetivo32MiB/5–15s, sin video
en disco. Streaming NO verifica SHA completo antes de mostrar, incluido Pawchive.
Preparación/cola/guardar conservan comprobación completa, límites y copias offline.

765 JVM/116 clases,0 fallos/errores/omitidas. Dirigidas51/24/76 aprobadas, subconjuntos no
sumar a765.44 Android compiladas/0 ejecutadas, sin adb/KVM. No se descargó medio upstream
ni abrieron cuentas/claves/JSON privado. Solo HTML/JSON/MP4 propios y HTTPS/DNS simulados.
No inferir primer fotograma/sonido/duración física o calidad/CDN real de estas pruebas.
Lint0 errores, avisos exactos JSON. Room13/JSON17, manifiesto/runtime/assets/nativos
intactos. Campos JSON opcionales roundtrip; clases anteriores conservadas. APK35/0.35.0,
min26target36, firma original/v2/16KiB. Instalar sobre0.34 sin borrar/desinstalar/reimportar.
Clave original fuera del ZIP, no regenerar. APK/testAPK/fuente/bundle/evidencia incluidos.

Ver PRUEBAS.md, CALIDAD_Y_VERSIONES.md, GUIA_CALIDAD_035.md, STREAMING.md, PLAN_FUENTES.md y
matriz. Scripts verify/report/package-release035.py reproducen entrega. Historial completo
conservado incluido defecto0.33 y corrección0.34. Guía mínima unRule34Video y opcionalcum.st,
no nueve fuentes/APKs experimentales. APK adjunto0.34 coincidió por bytes con entrega.

Siguiente previsto: auditar Gofile/enlaces externos/masked, solo contratos verificables.
Nueve fuentes existentes; Kemono/Coomer/SimpCity excluidos. Cuerpos/cuentas, interfaz,
formatos, sincronización y demás paridad abiertos. No pedir claves/URLs privadas.
""")
with tempfile.TemporaryDirectory(prefix='peach-035-package-') as temp:
 archive=Path(temp)/'Peach-Local-proyecto-y-pruebas-0.35.0.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n in files:z.write(R/n,'peach-android/'+n)
  for f in sorted(D.iterdir()):
   if f.is_file() and not f.name.endswith(('.zip','.pending')):z.write(f,f.name)
  report=Path(a.build_root)/'app/reports/tests/testDebugUnitTest'
  for f in sorted(report.rglob('*')):
   if f.is_file():z.write(f,'test-report/'+str(f.relative_to(report)))
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  for n in files:assert z.read('peach-android/'+n)==(R/n).read_bytes(),n
 final=D/archive.name;pending=D/(archive.name+'.pending');shutil.copyfile(archive,pending);pending.replace(final);assert sha(final)==sha(archive)
 v['source_zip']={'file':final.name,'bytes':final.stat().st_size,'sha256':sha(final)}
(D/'Peach-Local-verificacion-0.35.0.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'commit':head,'tracked_files':len(files),'source_zip':v['source_zip']},ensure_ascii=False,indent=2))
