#!/usr/bin/env python3
"""Package clean source/history and verified deliverables; never includes a signing key."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,tempfile,zipfile
p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--build-root',required=True);a=p.parse_args();R=Path(__file__).resolve().parents[1];D=Path(a.out)
def git(*args):return subprocess.run(['git',*args],cwd=R,capture_output=True,check=True).stdout
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not git('status','--porcelain')
head=git('rev-parse','HEAD').decode().strip();assert git('rev-parse','HEAD^').decode().strip()=='d477afb9d5b8ac485abd5896ddc950eaf91a92a4'
files=[n for n in git('ls-files','-z').decode().split('\0') if n]
for n in files:
 assert not n.lower().endswith(('.jks','.keystore')),n
 assert 'Peach-progreso.json' not in n,n
 assert (R/n).read_bytes()==git('show','HEAD:'+n),n
v=json.loads((D/'Peach-Local-verificacion-0.36.0.json').read_text());assert v['unit']['tests']==800 and v['unit']['failures']==0
for k in ('apk','test_apk'):assert sha(D/v[k]['file'])==v[k]['sha256']
bundle=D/'Peach-Local-historial-0.36.0.bundle';git('bundle','create',str(bundle),'--all');git('bundle','verify',str(bundle))
v['source']={'commit':head,'parent':'d477afb9d5b8ac485abd5896ddc950eaf91a92a4','tracked_files':len(files),'bundle_sha256':sha(bundle)}
(D/'Peach-Local-verificacion-0.36.0.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
(D/'CONTINUAR.md').write_text(f"""# Continuar Peach Local0.36.0

HEAD {head}; {len(files)} archivos versionados. Padre d477afb9d5b8ac485abd5896ddc950eaf91a92a4.
Usuario aceptó0.35 y pidió continuar.0.36 todavía requiere aceptación en su tablet.
Finalidad: APK nativo autónomo SM-X230, sin PC/Termux/servidor Peach; paridad compatible.
Proyecto ABIERTO. No repetir preguntas/instalaciones intermedias o afirmar paridad completa.

Gofile es un expansor de recursos, NO décima fuente. Auditado follow_gofile.py/tests y
snapshots del original de22796c04919aaa057d77930c33c81313765569 y módulos oficiales actuales.
API lista con Bearer propio y Premium documentado. Sin clave no consulta. No crear
invitados, buscar tokens del usuario, calcular WT web o ejecutar scripts/WebView.
Solo GET API exacto, sin redirección, clave en header, nunca medios/otras fuentes/URL/
Room/copia/Intent/log. Una consulta real sin clave a UUID ficticio dio401/error-token;
no cuenta autenticada/listado real ni medio upstream probado. Huellas en evidence0.36.

Publicación importada → contenido guardado → Enlaces Gofile → configurar clave opcional
propia en tablet → Consultar archivos → revisar → Incorporar. Pantalla nativa no exportada,
Intent solo publicaciónID; abrir no hace red. Página100 y subcarpetas explícitas,
máximo5000 páginas/200 destinos conocidos, sin recursión automática/medios al consultar.
Status JSON200 y gates de acceso validados. HTTP429 se procesa antes de cuerpo, incluso
inválido/comprimido; error-rateLimit200 también espera persistida hasta24h por respuesta,
no se reinicia al cambiar/borrar clave. Otros proveedores no quedan bloqueados.

Token AES-GCM/AndroidKeyStore separado de Rule34.xxx, AtomicFile/IV nuevo/noBackup,
sin fallback texto. Diálogo FLAG_SECURE/no prellenado/no saved state/limpieza al cerrar.
Consulta no aplica. Aplicación aditiva transaccional valida publicación/cuerpo/clave,
pausa/espera/cancelación, máximo100 y no vacío, mantiene cuerpo/ficha/notas/vínculos/
archivos/historial. Mismo root/fileID renueva URL sin duplicados. Refresh real SourceStore
 y VideoVersionReview conservan adjuntos Gofile; éstos no ocultan downgrade nativo.

Archivos directos store*.gofile.io/download con ID coherente, HTTPS, no query/creds/puerto/
traversal, DNS público por apertura. Redirect solo URL exacta. No token/Cookie/Origin/
Referer al archivo. Galería/video/stream/preparación/guardar/cola nativos reutilizados.
No hash esperado Gofile/md5 verificado; streaming NO SHA completo antes de mostrar.
Mantiene16GiB streaming/32MiB objetivo/5–15s, preparación2GiB/8 copias, cola128/4GiB,
galería16MiB/imagen/64MiB/128. No HLS/DASH/HD inventado/transcodificación/remotoZIPPDF.
Si enlace firmado/sesión/ruta no admitida, referencia y diagnóstico, no archivo0bytes.

Room13/esquemas igual; JSON18 escribe/lee1–18, valida grupo/ID/URL Gofile.0.35 rechaza18;
no aconsejar downgrade para restaurar copia nueva. Nueva actividad única no exportada,
sin nuevo permiso/servicio/proveedor/dependencia. Assets/nativos anteriores conservados.
APK36/0.36.0,min26target36, firma original/v2/16KiB. Instalar sobre0.35 sin desinstalar/
borrar/reimportar. Clave de firma fuera del ZIP: nunca regenerarla para actualizar.

800 JVM/120 clases sin fallos/errores/omitidas,35 nuevos en4 clases.46 Android compiladas,
0 ejecutadas, sin adb/KVM; dos nuevas Room/copia18 y aliasKeystore exclusivo. AES JVM sí
probado con clave de test; no asumir AndroidKeyStore físico. Periodo real Media3 entrega
muestra H.264 propia mediante HTTPS/DNS simulados. No latencia/CDN/codec físico verificados.
Primer intento dirigido falló al compilar fixture final extendido; segundo29/1 detectó
cancelación onStop ausente; corregida manteniendo rotación, luego100/100. Gate798 pasó;
tras2 casos nuevos/HTTP429 robusto, gate final800 pasó. Logs/XML intermedios conservados.
Lint0 errores, avisos exactos JSON; runtime graph356 igual. No supresiones nuevas.

Ver GOFILE.md, GUIA_GOFILE_036.md, PRUEBAS.md, PLAN_FUENTES.md y matriz. Scripts
verify/report/package-release036.py producen entrega con fuente limpio/bundle/historia/
APKs/XML/HTML/logs/hashes/CRC. Reportes anteriores preservados incluido0.35. Sin capturas,
JSON privado/credenciales/key/medios terceros. Solo datos propios y prueba metadata anónima.
Guía mínima; sin clave apta basta comprobar límite, no pedir contratar cuenta ni repetir9fuentes.

Nueve conectores; Kemono/Coomer/SimpCity excluidos. Pendientes F95 sesión/masked/contraseñas,
otros servicios/rutas firmadas/con cookies, cuentas/cuerpos adicionales, interfaz, formatos,
sincronización y paridad original. No tratar esta entrega como proyecto terminado.
""")
with tempfile.TemporaryDirectory(prefix='peach-036-package-') as temp:
 archive=Path(temp)/'Peach-Local-proyecto-y-pruebas-0.36.0.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n in files:z.write(R/n,'peach-android/'+n)
  for f in sorted(D.iterdir()):
   if f.is_file() and not f.name.endswith(('.zip','.pending')):z.write(f,f.name)
  report=Path(a.build_root)/'app/reports/tests/testDebugUnitTest'
  for f in sorted(report.rglob('*')):
   if f.is_file():z.write(f,'test-report/'+str(f.relative_to(report)))
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  for n in files:assert z.read('peach-android/'+n)==(R/n).read_bytes(),n
 final=D/archive.name;pending=D/(archive.name+'.pending');shutil.copyfile(archive,pending);pending.replace(final);assert sha(final)==sha(archive)
 v['source_zip']={'file':final.name,'bytes':final.stat().st_size,'sha256':sha(final)}
(D/'Peach-Local-verificacion-0.36.0.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'commit':head,'tracked_files':len(files),'source_zip':v['source_zip']},ensure_ascii=False,indent=2))
