#!/usr/bin/env python3
"""Package exact clean source, history, APKs and evidence. Signing key excluded."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,tempfile,zipfile
p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--build-root',required=True);a=p.parse_args();R=Path(__file__).resolve().parents[1];D=Path(a.out);P='fc1d1faacf0b3cbdc01ab0a8f1f197eacb6d4857'
def git(*args):return subprocess.run(['git',*args],cwd=R,capture_output=True,check=True).stdout
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not git('status','--porcelain');head=git('rev-parse','HEAD').decode().strip();assert git('rev-parse','HEAD^').decode().strip()==P
files=[n for n in git('ls-files','-z').decode().split('\0') if n]
for n in files:
 assert not n.lower().endswith(('.jks','.keystore')) and 'Peach-progreso.json' not in n,n
 assert (R/n).read_bytes()==git('show','HEAD:'+n),n
v=json.loads((D/'Peach-Local-verificacion-0.38.0.json').read_text());assert v['unit']['tests']==860 and v['unit']['failures']==0
for k in ('apk','test_apk'):assert sha(D/v[k]['file'])==v[k]['sha256']
bundle=D/'Peach-Local-historial-0.38.0.bundle';git('bundle','create',str(bundle),'--all');git('bundle','verify',str(bundle))
v['source']={'commit':head,'parent':P,'tracked_files':len(files),'bundle_sha256':sha(bundle)};(D/'Peach-Local-verificacion-0.38.0.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
(D/'CONTINUAR.md').write_text(f'''# Continuar Peach Local 0.38.0

HEAD {head}, padre{P}, {len(files)} archivos versionados.0.37 aceptada,0.38 pendiente
aceptación. Proyecto ABIERTO: APK autónomo nativo SM-X230, sin PC/Termux/servidor Peach.
No navegador integrado ni paridad completa declarada. Firma original fuera del paquete:
NO regenerar la clave; actualización sobre0.37 sin desinstalar. Room13/copia18 lee1–18.

0.38 RAR/CBR parcial: RarBook propio parsea RAR4 portable/RAR5 UTF-8 en firma inicial,
CRC de cabeceras e índice natural/búsqueda, lee solo entradas almacenadas sin compresión
con CRC32. Imágenes/texto/PDF existentes, posición/rotación/favorito/leído/historial.
RAR5 versión0/1 almacenada no equivale a decodificar RAR7. RAR4 Unicode comprimido/ANSI
no portable rechazados. Fuente y total declarado512MiB; vista64MiB;10.000 cabeceras,
8MiB acumuladas,2MiB cabecera RAR5; CRC antes de publicar/no hashes de entradas no abiertas.
Reindex al seleccionar con descriptor nuevo, salida privada fija/cleanup/cancel/90s índice y90s copia.
Comprimidos/cifrados/links/sin CRC/extras desconocidos solo índice con explicación.
Sólidos/volúmenes/cabeceras cifradas/SFX/rutas inseguras/daños/trailing rechazados.
No red, extracción general, videos/anidados, contraseñas, librería nativa o dependencia.

Auditoría: Junrar8.1.2 sí anuncia RAR hasta7; licencia UnRAR con restricción, no incorporada
por decisión de compatibilidad AGPL pendiente. libarchive3.8.2 BSD preferida para evaluar
la descompresión posterior. NDK/JNI/ABIs/diccionarios/memoria/cancelación/aislamiento y
pruebas reales pendientes. No llamar esta entrega descompresor completo.
RARLAB technote.htm y estructura RAR4 libarchive leídos, technote.txt no disponible.
Huellas de fuentes primarias/evidencia en docs/evidence/0.38.0/audit-resources.json.
Fixtures propios scripts/fixtures/rar038.py y samples del ZIP, cruzados íntegramente
con libarchive3.7.4 host (herramienta de prueba, NO enAPK). Indicador data vacío corregido
durante generación. No datos/capturas/credenciales privadas en paquete.

860JVM/127clases aprobadas;28nuevas (RarBook18/RarReader5/RarUi5). Lint0errores, avisos
exactos JSON.50Android compiladas/0ejecutadas;2nuevas RARPNG y copia/Room aislados.
Sin adb/KVM. Dos compilaciones intermedias de test fallidas (paréntesis, Files.readString)
corregidas; full inicial859/2fallos por contratos antiguos RAR-nolector actualizados
con controles ARJ/nolector y nuevo ruteoCBR. Logs guardados y resultado dirigido/final. No confundir PDF doble de JVM con
PdfRenderer nativo. API26/28 imágenes en Robolectric. No sesiones/fuentes/CDN reales o
medios privados probados. APKs firma original/v2/alineación16KiB. Manifest/permisos/
componentes/assets/nativos/runtimegraph/esquemas/BackupStore previos iguales a0.37;
clases previas retenidas, suite completa cubre funciones existentes.

Mantener nueve fuentes; Kemono/Coomer/SimpCity excluidos.0.37 F95 sesión avanzada opcional
importada manualmente, sin login nativo/extracciónChrome/soluciónCAPTCHA. No exigir al
usuario buscar cookie para pruebas, ni pedirla por chat. Su consulta posterior preguntó
cómo conseguirla; se explicó limitación en tablet. Login nativo sigue pendiente.
Gofile requiere clave/cuenta apta segúnAPI; no enviar CookieF95 a destinos.
Streaming conserva32MiB RAM/16GiB recurso, NO SHA completo antes de mostrar, incluidoPaw.
Descarga completa2GiB conserva comprobaciones, cola y galería previas intactas.

Próximo bloque previsto: evaluar/integrar descompresión RAR con libarchive y límites
nativos verificables, posiblemente etapas técnicas. No añadir decoder sin auditar o
prometer todos losRAR/CBR. Siguen seis frentes PENDIENTES.md, varios bloques cada uno,
sin porcentaje/fecha fiable. Guía mínima opcional, no pedir repetir nueve fuentes.
PRUEBAS.md actual y PRUEBAS_0_37.md histórico; README/matriz/plan/LECTURA_RAR.md explican
parcialidad. Fuente/historia/evidencia/XML/HTML/APKs listos en paquete. No clave de firma.
''')
with tempfile.TemporaryDirectory(prefix='peach-038-package-') as temp:
 archive=Path(temp)/'Peach-Local-proyecto-y-pruebas-0.38.0.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n in files:z.write(R/n,'peach-android/'+n)
  for f in sorted(D.iterdir()):
   if f.is_file() and not f.name.endswith(('.zip','.pending')):z.write(f,f.name)
  for f in (R/'app/src/test/resources/rar038').iterdir():z.write(f,'samples/'+f.name)
  report=Path(a.build_root)/'app/reports/tests/testDebugUnitTest'
  for f in sorted(report.rglob('*')):
   if f.is_file():z.write(f,'test-report/'+str(f.relative_to(report)))
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  for n in files:assert z.read('peach-android/'+n)==(R/n).read_bytes(),n
 final=D/archive.name;pending=D/(archive.name+'.pending');shutil.copyfile(archive,pending);pending.replace(final);assert sha(final)==sha(archive)
 v['source_zip']={'file':final.name,'bytes':final.stat().st_size,'sha256':sha(final)}
(D/'Peach-Local-verificacion-0.38.0.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'commit':head,'tracked_files':len(files),'source_zip':v['source_zip']},ensure_ascii=False,indent=2))
