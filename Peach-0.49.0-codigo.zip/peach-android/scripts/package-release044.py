#!/usr/bin/env python3
"""Package committed source/evidence and own samples. Signing credentials are excluded."""
from pathlib import Path
import argparse,hashlib,json,subprocess,zipfile
p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args();R=Path(__file__).resolve().parents[1];D=Path(a.out);PARENT='0d6ba7c13b290ddb08efed71d297fda57e83218a'
def git(*args):return subprocess.run(['git',*args],cwd=R,capture_output=True,check=True).stdout
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not git('status','--porcelain');head=git('rev-parse','HEAD').decode().strip();assert git('rev-parse','HEAD^').decode().strip()==PARENT
files=[n for n in git('ls-files','-z').decode().split('\0') if n]
for n in files:
 assert not n.lower().endswith(('.jks','.keystore')) and 'Peach-progreso.json' not in n,n
 assert (R/n).read_bytes()==git('show','HEAD:'+n),n
v=json.loads((D/'Peach-Local-verificacion-0.44.0.json').read_text());assert v['unit']['tests']==1052 and v['unit']['failures']==0
for k in ('apk','test_apk'):assert sha(D/v[k]['file'])==v[k]['sha256']
small=D/'Peach-0.44.0-descarga.zip'
with zipfile.ZipFile(small,'w',zipfile.ZIP_DEFLATED) as z:z.write(D/v['apk']['file'],v['apk']['file'])
with zipfile.ZipFile(small) as z:assert hashlib.sha256(z.read(v['apk']['file'])).hexdigest()==v['apk']['sha256']
samples=D/'Peach-Local-muestras-parte-3-0.44.0.zip'
with zipfile.ZipFile(samples,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted((R/'app/src/test/resources/formats440').iterdir()):z.write(f,f.name)
 z.writestr('LEEME.txt','Muestras propias pequeñas de Peach0.44. Contraseña de PDF/7z: test-only. No son medios de tu biblioteca. RAR32/64 son fixtures de cabecera derivada con payload propio, no corpus universal. El APK no requiere PC/7zip/FFmpeg. Autoriza/importa la carpeta en Android solo si deseas probarlos. No se añaden automáticamente.\n')
bundle=D/'Peach-Local-historial-0.44.0.bundle';git('bundle','create',str(bundle),'--all');git('bundle','verify',str(bundle))
v['source']={'commit':head,'parent':PARENT,'tracked_files':len(files),'bundle_sha256':sha(bundle)}
v['download_zip']={'file':small.name,'bytes':small.stat().st_size,'sha256':sha(small),'contains_exact_signed_apk':True}
v['samples']={'file':samples.name,'bytes':samples.stat().st_size,'sha256':sha(samples),'own_synthetic_data_only':True}
(D/'Peach-Local-verificacion-0.44.0.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
(D/'CONTINUAR.md').write_text(f'''# Continuar Peach0.44 · Parte3de6

Commit{head}, padre{PARENT}. Partes1/0.42 y2/0.43 aceptadas por el usuario.
0.44 entregada para prueba; no inferir aceptación. Corregir fallos de esta parte antes
parte4import/sync; después5UI/rendimiento y6validación/cierre. UnAPK por parteagrupada.
1052JVM/150clases0fallos,32nuevas;64Androidcompiladas0ejecutadas. Lint0/{v['lint']['warnings']}.
Firmaoriginal/v2/16KiB, min26/target36,Room13/backup19/manifest/permisos/dep/assets/4.so
conservados. No contraseñaPDF/7z persistida. No JKS en fuente oentregables; claveprivada
separada libfile_69aa5bd50a608191bc9935894330dc6d. Nunca regenerar. Cert9fc537c4c8d0461a8565414c7a30169e592120cd314b500bee7c707f8a748484.

ZIP64 bounded,7zclavecabeceraplana/KDFlimitado,RAR5solido64MiBdict,EPUBNAV/NCX/fragmento/
fontsofuscadasomitidas,PDFpassword/searchAPI35+,textoactual/subtitulosUnicode1252 eInfo.
RAR4solid/RARpassword/volumen/RAR7/ANSIambiguo,ZIPcifrado,7zpasswordheadercodificado,
EPUBmaquetado/inline/DRM/OCR/hardwarecodecsnoadmitidos siguenlímites, no implementados.
MuestrasRAR32/64sonheaderderivadasdepayloadpropio;JNI Linux real, noAndroid. Ochoformatos
extractorreal ysubtitleMediaSource/SampleStreampasaron, sinclaimdecodificaciónfísica.
NuevoAPK necesita pruebaSM-X230; guía enGUIA_PARTE_3_044 yalcancePARTE_3_FORMATOS.
Muestras opcionales PDF/7z clave test-only, no privada. No redfuentes/cuentas/mediosupstream
usados; parte2módulos intactos y originaltransportstream. HistóricoerroresenDEVELOPMENT.

Nuevefuentes;Kemono/Coomer/SimpCityexcluidos;sinPC/Termux/backendobligatorio.
Entorno inicialscratchestaba atrasado, se recuperó exacto0.43 de bundleLibrary;
fuente actual y bundle aquí son base. Toolchains/firma/buildoutputs fuera de fuente.
No subagentes. Fecha29oct2026America/Hermosillo. Proyecto abierto; leerPLAN/PENDIENTESactual.
''')
archive=D/'Peach-Local-proyecto-y-pruebas-0.44.0.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n in files:z.write(R/n,'peach-android/'+n)
 for f in sorted(D.iterdir()):
  if f.is_file() and not f.name.endswith(('.zip','.pending')):z.write(f,f.name)
 report=R/'app/build/reports/tests/testDebugUnitTest'
 for f in sorted(report.rglob('*')):
  if f.is_file():z.write(f,'test-report/'+str(f.relative_to(report)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert not any(n.lower().endswith(('.jks','.keystore')) for n in z.namelist())
 for n in files:assert z.read('peach-android/'+n)==(R/n).read_bytes(),n
v['source_zip']={'file':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive)}
(D/'Peach-Local-verificacion-0.44.0.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v[k] for k in ('source','apk','download_zip','samples','source_zip')},ensure_ascii=False,indent=2))
