#!/usr/bin/env python3
"""Package the exact committed source and signed deliverables, never signing credentials."""
from pathlib import Path
import argparse,hashlib,json,subprocess,zipfile
p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args();R=Path(__file__).resolve().parents[1];D=Path(a.out);BASE='9560bf2f4e5b70f5534e58b5a16a238b3ad34664'
def git(*args):return subprocess.run(['git',*args],cwd=R,capture_output=True,check=True).stdout
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not git('status','--porcelain');head=git('rev-parse','HEAD').decode().strip();assert git('rev-parse','HEAD^').decode().strip()==BASE
files=[n for n in git('ls-files','-z').decode().split('\0') if n]
for n in files:
 assert not n.lower().endswith(('.jks','.keystore','.p12')),n
 assert (R/n).read_bytes()==git('show','HEAD:'+n),n
v=json.loads((D/'Peach-Local-verificacion-0.46.0.json').read_text());assert v['unit']['tests']==1132 and v['unit']['failures']==0
for k in ('apk','test_apk'):assert sha(D/v[k]['file'])==v[k]['sha256']
small=D/'Peach-0.46.0-descarga.zip'
with zipfile.ZipFile(small,'w',zipfile.ZIP_DEFLATED) as z:z.write(D/v['apk']['file'],v['apk']['file'])
with zipfile.ZipFile(small) as z:assert hashlib.sha256(z.read(v['apk']['file'])).hexdigest()==v['apk']['sha256']
bundle=D/'Peach-Local-historial-0.46.0.bundle';git('bundle','create',str(bundle),'--all');git('bundle','verify',str(bundle))
v['source']={'commit':head,'parent':BASE,'tracked_files':len(files),'bundle_sha256':sha(bundle)}
v['download_zip']={'file':small.name,'bytes':small.stat().st_size,'sha256':sha(small),'contains_exact_signed_apk':True}
(D/'Peach-Local-verificacion-0.46.0.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
(D/'CONTINUAR.md').write_text(f'''# Continuar Peach 0.46 · Parte 5 de 6

Commit {head}; padre {BASE}. El usuario aceptó partes 1–4 / versiones 0.42–0.45.
0.46 se entrega para prueba. Resolver sus fallos; tras confirmación seguir parte 6,
validación Android/correcciones. No declarar paridad universal o cierre del proyecto.

Navegación y filtros sencillos, temas/colores/fondo/tarjetas/movimiento, volumen por
reproductor Media3; UiAppearance/PeachActivity se comparten entre pantallas. Canvases
oscuros para lectores/imagen/video conservan controles propios. Fondo limitado a
Biblioteca, entrada 16 MiB y copia reducida 1440 px privada. Ajustes en esta tablet.

DirectTransfer/DirectSaveActivity/DirectSaveJournal: nuevo URI SAF, flujo de fuente
permitida al proveedor sin archivo completo en Peach. Provider puede usar caché propia
o subir después; no API Google propia o confirmación remota. Límite 2 GiB, una
transferencia por proceso, cancelación al salir, sin resume/auto-red al reiniciar.
ViewModel al rotar; diario privado máximo 16 referencias, limpieza exacta de solo nuevo
URI, revisión manual también desde Ajustes/Almacenamiento. Si se pierde permiso, usar
app del proveedor. Preparación anterior y cola permanecen disponibles. Extensión/MIME
iniciales son metadata; Preparar copia puede corregirlos desde bytes antes del picker.

Thumbnails: solicitudes compartidas con referencias débiles, 8 MiB/dos workers/cola 48.
Main agrupa renders por datos; caché limpia videos libres respetando PINS/PREPARING y
la cola. No datos originales o secretos en limpieza. Ver guía/alcance/PRUEBAS/evidencia.

1132 JVM en 157 clases, 0 fallos/errores/omitidas; 32 casos nuevos y los 1100 anteriores.
69 Android compiladas, 0 ejecutadas; dos nuevas usan solo el proveedor de fixtures del
APK test. Lint 0 errores/{v['lint']['warnings']} avisos. Firma original/v2 y 16 KiB.
Room 13/esquemas/DAO, BackupStore 19, Exchange 1, SourceHttp, dependencias/grafo 356,
assets y cuatro .so conservados; sin permisos/servicios/proveedores principales nuevos.
Tres actividades nuevas internas no exportadas. No dispositivo/KVM o Drive/cuentas
reales probados. Los renders nativos de Robolectric no son capturas físicas.

Tests previos de selección de adjuntos eligen Preparar copia en el nuevo diálogo;
pruebas de filtros abren el panel antes de cambiar Spinner. Mismas aserciones/casos.
Fallos de desarrollo y lint guardados; no se suprimieron controles para aprobar.

Clave privada separada: libfile_69aa5bd50a608191bc9935894330dc6d. Nunca poner JKS en
repo o ZIP. Certificado: 9fc537c4c8d0461a8565414c7a30169e592120cd314b500bee7c707f8a748484.
Nueve fuentes; Kemono, Coomer y SimpCity excluidos. SM-X230 autónoma sin PC/Termux/backend.
No subagentes. Fecha: 29 de octubre de 2026, America/Hermosillo. Leer PLAN y PENDIENTES.
''')
archive=D/'Peach-Local-proyecto-y-pruebas-0.46.0.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n in files:z.write(R/n,'peach-android/'+n)
 for f in sorted(D.iterdir()):
  if f.is_file() and not f.name.endswith(('.zip','.pending')):z.write(f,f.name)
 for f in sorted((R/'app/build/reports/tests/testDebugUnitTest').rglob('*')):
  if f.is_file():z.write(f,'test-report/'+str(f.relative_to(R/'app/build/reports/tests/testDebugUnitTest')))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert not any(n.lower().endswith(('.jks','.keystore','.p12')) for n in z.namelist())
 for n in files:assert z.read('peach-android/'+n)==(R/n).read_bytes(),n
v['source_zip']={'file':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive)}
(D/'Peach-Local-verificacion-0.46.0.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v[k] for k in ('source','apk','download_zip','source_zip')},ensure_ascii=False,indent=2))
