#!/usr/bin/env python3
"""Write the delivery report only after verification of the complete 0.33 build."""
from pathlib import Path
import argparse,json,shutil
p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args()
R=Path(__file__).resolve().parents[1];D=Path(a.out)
v=json.loads((D/'Peach-Local-verificacion-0.33.0.json').read_text())
assert v['unit']=={'tests':735,'failures':0,'errors':0,'skipped':0,'classes':111}
assert v['lint']['errors']==0 and v['instrumentation']=={'compiled':40,'executed':0}
apk,test,lint,classes=[v[k] for k in ['apk','test_apk','lint','peach_classes']]
text=f'''# Peach Local 0.33.0 — reproducción en línea

27 de octubre de2026, America/Hermosillo. Samsung Galaxy Tab A11+ SM-X230.

El usuario aceptó0.32, pidió continuar y preguntó por ver archivos como YouTube sin
descargarlos completos antes. Se explicó el consumo de internet/búfer y se comunicó
la prioridad de Ver en línea antes de la auditoría Gofile. Esta entrega implementa
video progresivo nativo;0.33 todavía requiere su aceptación en la tablet. El proyecto
sigue abierto, sin afirmar paridad completa con Peach original.

## Resultado y uso

Fuentes → publicación importada → Ver videos → elegir video → Ver en línea.
Se deshabilita con Sin conexión. Abre el reproductor Media3 existente sin preparar un
archivo completo o pedir carpeta. Recibe datos y conserva un búfer temporal en RAM;
no significa consumo cero de internet. Ver todo el video puede transferir tantos datos
como una descarga y volver/adelantar puede repetir transferencias. Un clip pequeño
puede caber entero en el búfer. No se promete latencia instantánea en cualquier fuente.

Preparar y reproducir, la galería, Guardar adjunto y cola0.32 siguen disponibles con
sus verificaciones y copias offline. El streaming no comprueba SHA completo antes de
mostrar imágenes, incluido Pawchive. Su ruta inmutable se usa como identidad para un
salto; no se presenta como verificación de todos los bytes. Para comprobar/conservar
el original se usa preparación/descarga completa, que mantiene el SHA esperado Pawchive.

Salir del reproductor cancela conexiones. Rotar conserva sesión, posición y pausa,
pero el nuevo reproductor puede necesitar red otra vez. No hay servicio de video en
segundo plano o copia offline implícita. Conserva pantalla completa, pistas incluidas
y diagnóstico/fallback de decodificadores disponibles; el selector de subtítulo local
queda en los flujos anteriores. Este modo no añade subtítulos externos o un catálogo/
visita ficticios. Los archivos incorporados a Biblioteca conservan su progreso habitual.

## Arquitectura y límites

SourceVideoActivity conserva preparación completa y añade el botón. El Intent contiene
solo publicación/clave hash. SourceVideoStream vuelve a resolver desde Room y selecciona
el adjunto admitido de ese proveedor. Un ID ausente/clave incorrecta o URL/ruta extra del
llamador no autoriza la red. La carga de metadatos no consulta el archivo.

PlayerActivity configura ProgressiveMediaSource con StreamDataSource vinculado a una
sesión y URI peach-stream opaca. No hay DefaultHttpDataSource/fallback que autorice una
URL arbitraria. Solo GET sin cabeceras del llamador ni cambio de URI. VideoStream usa
SourceHttp con las rutas HTTPS, redirección pública y DNS anteriores; no añade servidores,
cuentas, cookies, claves o servicios. El manifiesto es idéntico a0.32 por bytes.

El transporte inspecciona hasta4096bytes de cabecera MP4/MOV/WebM/Matroska, conservándolos
para el extractor. Posición restaurada distinta de cero consulta primero solo la cabecera
y después su rango. No abre archivo de video en disco, caché de video o cola para este
modo. Objetivo del búfer32MiB, ventanas5–15s, inicio1s/rebúfer2s y sin búfer posterior;
no equivale a cuota total de RAM, latencia garantizada o limitación de los decodificadores.
Máximo16GiB por recurso en línea; tamaño desconocido se limita al leer. Las descargas
completas siguen2GiB. Las pruebas de tamaño grande usan solo cabecera y longitud declarada,
sin transferir un archivo real de3GiB.

Para saltos exige Range/If-Range,206 exacto, Content-Range/inicio/final/tamaño y un ETag
fuerte conservado, salvo identidad Pawchive. Guarda en la sesión una huella del destino
y tamaño conocido y rechaza cambios. Sin validador suficiente admite el inicio secuencial
y rechaza el salto. Si el servidor ignora Range no descarga/descarta todo el prefijo para
simularlo. Algunos MP4 necesitan saltar para obtener su índice, incluso para empezar;
pueden requerir preparación completa.416 al final conocido es EOF, más allá se comunica
como posición fuera de rango a Media3. MIME incompatible, HTML/JSON/GIF, gzip/multipart,
rangos inválidos y cuerpos truncados fallan sin crear un BIN o supuesto completo de0bytes.

No hay reintentos automáticos del cargador;429 conserva espera en sesión. Los errores
redactan causas/URLs crudas, conservando códigos y explicaciones de formato/decodificador.
Los callbacks de un reproductor anterior se ignoran tras sustituirlo para no afectar al
nuevo al rotar/reinicializar. Cancelación comprueba el token también antes de recibir
respuesta HTTP. SourceHttp solo cambia esa comprobación y su User-Agent de versión.

Sin HLS/DASH, calidad adaptativa, transcodificación, emisiones en vivo, cuentas nuevas,
Gofile/masked o lectura remota de comprimidos/documentos. Las tarjetas Patreon/SubscribeStar
no se convierten en videos completos. Las calidades ya reconocidas siguen como adjuntos
separados. Formato/servidor/códec condicionan la reproducción; no hay códec universal.

## Pruebas ejecutadas

**735 pruebas locales en111 clases:0 fallos,0 errores,0 omitidas.** Conserva706 y añade29:

- VideoStreamTest16: primeros bytes tras cabecera sin esperar todo el archivo, lectura
  exacta/truncada, saltos206/If-Range, ETag ausente/débil, rango ignorado y malformado,
  representación/tamaño cambiados, restauración de posición con consulta pequeña,
  longitud desconocida/grande/límite, MIME/HTML/imagen/compresión, redirección y acceso,
  pausa/offline/cierre, espera429/redacción, EOF416, Pawchive y cancelación al responder.
- StreamDataSourceTest6: extractor MP4 real que emite muestras H.264 antes de leer todo
  el MP4 y salto por su índice con nuevas muestras; solicitud acotada, URI/cabeceras
  opacas, rechazo de URI/método/cabeceras ajenos, eventos de transferencia y contrato
  Media3 de posición al final/fuera de rango. No solo se comprueba una cadena de texto.
- StreamUiTest7: botón/Intent sin preparación o SAF, modo offline con alternativa previa,
  resolución sin red/caché, sesión/posición4200ms/pausa retenidas al rotar, salida/cierre
  y vuelta, identidad ausente/clave inválida y errores con diagnóstico sin secretos.

Primera compilación falló por nombre de override de Media3; se corrigió a
getRetryDelayMsFor sin cambiar librerías. Núcleo16/16 y adaptador/extractor22/22 aprobaron.
Primera dirigida36 con1 fallo de fixture: asumía que la carpeta de VideoCache existía,
cuando no crearla es válido en streaming. Se comprueba ahora ausencia o carpeta vacía.
Segunda dirigida37 con1 fallo real del mapeo de mensajes: el orden numérico de los códigos
no incluye todos los de decodificación en un intervalo. Se sustituyó por casos explícitos.
Se conservan logs/XML de ambos fallos. La batería final completa735/735 incluye la
corrección y todas las pruebas anteriores, sin relajar controles o suprimir resultados.

**Lint0 errores/{lint['warnings']} avisos**, sin supresiones nuevas.
Categorías: `{json.dumps(lint['categories'],ensure_ascii=False)}`.
Grafo runtime idéntico al de0.32, {v['runtime_dependency_graph_lines']} líneas. No se añadió
o actualizó dependencia. XML finales sin CloseGuard/recurso sin cerrar, NoSuchMethodError
o SQLiteException. Permanecen deprecaciones/J2ObjC y los mensajes previos de fixtures de
imagen inválida, sin fallos finales. Compilación principal y de pruebas aprobadas.

**40 pruebas Android compiladas,0 ejecutadas.** Tres nuevas comprueban adaptador nativo/
cabecera MP4 sin archivo completo, rango de posición y pausa/conexión/Intent opaco.
No hay dispositivo adb conectado ni /dev/kvm. No se presenta compilación como ejecución
en SM-X230. El primer fotograma, sonido y latencia físicos de streaming siguen pendientes.

Se usa solo el MP4 propio de2,925,145bytes y fixtures anteriores. HTTPS/DNS simulados;
no se descargan medios upstream, cuentas, JSON privado del usuario o capturas. El APK
principal no incluye el MP4 de pruebas. Los tests acreditan el software simulado, no
disponibilidad de cada fuente, TLS de su CDN real o todos los contenedores/códecs.

## Conservación y entrega

Room13 y esquemas por bytes intactos; JSON17 lee1–17. Manifiesto/permisos, runtime,
assets y librerías nativas anteriores conservados. Clases Peach {classes['before']}→{classes['after']},
0 retiradas. Sin actividad, proveedor, servicio, permiso o dependencia nuevos. Mantiene
AGPL3+ y atribuciones. Continúan nueve conectores; Kemono/Coomer/SimpCity excluidos.

APK **{apk['file']}**, {apk['bytes']:,} bytes.
SHA-256 `{apk['sha256']}`.
APK de pruebas dentro del ZIP: {test['bytes']:,} bytes,
SHA-256 `{test['sha256']}`. No hace falta instalarlo al usuario.
Ambos APK con firma original/v2 comprobadas; principal alineado16KiB,
com.peach.local,33/0.33.0,min26/target36. Instalar sobre0.32 sin desinstalar. La clave
original permanece fuera del proyecto/ZIP; nunca regenerarla para actualizar.

```
python3 scripts/run-gradle.py --init-script scripts/build-outside-workspace.init.gradle :app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:assembleDebugAndroidTest --console=plain
```

Java17.0.21+9/Gradle8.13/AGP8.13.0/SDK36/build-tools35.0.0. Build externo mediante
PEACH_BUILD_ROOT, keystore original fuera del repo y truststore del sistema. Scripts
verify-release033.py/report-release033.py/package-release033.py conservan comprobaciones,
fuente limpio, historial Git, APKs, logs/XML/HTML, hashes y validación CRC/bytes del ZIP.

STREAMING.md y GUIA_STREAMING_033.md explican alcance y una prueba breve con un video;
no se pide repetir nueve fuentes. PLAN_FUENTES.md/matriz registran aceptación0.32 y
prioridad nueva. Próxima auditoría prevista: Gofile/referencias externas. Cuerpos/cuentas,
interfaz, formatos, sincronización y demás paridad original continúan pendientes.

Referencias primarias consultadas:
[Media3 progressive](https://developer.android.com/media/media3/exoplayer/progressive),
[DataSource](https://developer.android.com/reference/androidx/media3/datasource/DataSource),
[seeking](https://developer.android.com/media/media3/exoplayer/troubleshooting).
Las referencias explican APIs; los resultados propios se acreditan en evidence/0.33.0.
'''
(R/'docs/PRUEBAS.md').write_text(text)
for src,dst in [('PRUEBAS.md','Peach-Local-informe-0.33.0.md'),('COMPATIBILIDAD_ORIGINAL.md','Peach-Local-compatibilidad-original-0.33.0.md'),('GUIA_STREAMING_033.md','Peach-Local-guia-streaming-0.33.0.md'),('PLAN_FUENTES.md','PLAN_FUENTES.md')]:shutil.copy2(R/'docs'/src,D/dst)
print(json.dumps({'report':str(D/'Peach-Local-informe-0.33.0.md'),'unit':v['unit'],'lint':lint},ensure_ascii=False))
