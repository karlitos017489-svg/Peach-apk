#!/usr/bin/env python3
"""Report completed integration regression verification; never infer device/CDN execution."""
from pathlib import Path
import argparse,json,shutil
p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args();R=Path(__file__).resolve().parents[1];D=Path(a.out)
v=json.loads((D/'Peach-Local-verificacion-0.34.0.json').read_text())
assert v['unit']=={'tests':740,'failures':0,'errors':0,'skipped':0,'classes':112}
assert v['lint']['errors']==0 and v['instrumentation']=={'compiled':42,'executed':0}
apk,test,lint,classes=[v[k] for k in ['apk','test_apk','lint','peach_classes']]
text=f'''# Peach Local 0.34.0 — corrección de Ver en línea

27 de octubre de2026, America/Hermosillo. Samsung Galaxy Tab A11+ SM-X230.

El usuario informó un fallo de0.33 con captura del reproductor: mensaje de acceso a la
fuente y ERROR_CODE_IO_UNSPECIFIED2000. No se da por aceptada0.33. La captura no muestra
estado HTTP, host o proveedor, por lo que no acredita HTTP403 o necesidad de cuenta.
Se priorizó corregir la reproducción antes de continuar Gofile.0.32 sigue como última
aceptada;0.34 requiere comprobar el mismo video en su tablet. El proyecto sigue abierto.

## Causa y corrección

Se reprodujo el mismo mensaje usando StreamDataSource0.33 sin modificar, con sus bytes
idénticos al commit819bfaa1cebe0bf6b6032335589451756b899bf3. El cargador real
ProgressiveMediaSource/ProgressiveMediaPeriod construye un DataSpec con Icy-MetaData:1,
incluso para MP4. La validación propia rechazaba cualquier httpRequestHeaders no vacío
y emitía ACCESS antes de abrir la conexión de video. Las pruebas anteriores invocaban
directamente el extractor con DataSpec escrito por el test, omitiendo esa integración.
Las pruebas de pantalla comprobaban identidad/ciclo de vida, sin exigir preparación
exitosa o muestras entregadas por el periodo. Esa fue una limitación real de la cobertura.

La inspección javap del runtime Media31.8.0 usado por el APK confirma createIcyMetadataHeaders
y buildDataSpec. Jar SHA-256
`9365c4bea65f1be2046ff3c12597812a20c0ec7e137b28cdfa43c4b3cd80fb06`.
Los volcados, huella del código de producción0.33, fixture compatible con ese checkout,
log y XML de la reproducción fallida están en evidence/0.34.0. Se emplea solo un MP4
propio y HTTPS/DNS simulados; no se consultó el medio de la captura.

0.34 acepta únicamente la indicación Icy-MetaData con valor exactamente1, sin distinguir
mayúsculas en el nombre. La consume y no la transmite a HTTP; este transporte no activa
metadatos ICY intercalados. La sesión, URL de proveedor, cabeceras controladas de SourceHttp
y políticas HTTPS/DNS/redirección son las mismas. Las otras cabeceras del llamador,
incluidas Authorization/Cookie/Range/Referer, permanecen rechazadas. También se conservan
la URI opaca vinculada, GET sin cuerpo y offset admitido. No se desactiva la validación
para permitir todos los headers o cualquier URL.

Un rechazo local ahora usa REQUEST con mensaje de Peach y sin estado HTTP. ACCESS queda
para401/403 recibidos del servidor. Los fallos HTTP conservan un número100–599 saneado
en el diagnóstico, sin causa cruda, URL firmada o credenciales. Los códigos Media3 y
diagnósticos de decodificador se mantienen. SourceHttp solo actualiza su User-Agent de
versión; no añade cookies, cuentas, hosts, referers o claves para evitar un rechazo real.

## Pruebas

**740 pruebas locales en112 clases:0 fallos,0 errores,0 omitidas.** Mantiene735 y añade5:

- ProgressivePipelineTest3: Media3 construye su propia solicitud, prepara el periodo,
  selecciona la pista H.264 y entrega bytes de una muestra por SampleStream; respuesta
  real403 simulada pasa primero la validación local y conserva su estado; modo offline
  impide HTTP aun con la indicación interna correcta. No sustituye la solicitud por una
  construida a mano ni se limita a comprobar el texto de un botón.
- StreamDataSourceTest añade1 caso: acepta la indicación interna en ambas capitalizaciones,
  no la transmite, y rechaza otros valores/Authorization/Cookie/Range/Referer sin consultar
  HTTP. Las6 pruebas anteriores de extracción/salto/URI/longitud/transferencia permanecen.
- VideoStreamTest añade1 caso: diferencia un403 HTTP con ACCESS/status403 y causa vacía
  de un REQUEST local sin HTTP o atribución a la fuente. Los16 casos anteriores permanecen.

La regresión inicial sobre producción0.33 falla de la forma prevista:1 prueba/1 fallo,
prepared=false, cabecera Icy-MetaData:1 y el mismo mensaje ACCESS de la captura. No se
cuenta como prueba aprobada. Tras corregir producción, primera dirigida31 con1 fallo de
sincronización en StreamUiTest: ahora que el cargador sí puede abrir el video, la prueba
exigía que su registro de transferencias ya estuviera vacío inmediatamente al salir.
Media3 termina ese cleanup de forma asíncrona. Se comprueba cancelación inmediata de los
tokens y se espera su liberación con un límite de5s, manteniendo la aserción de cierre.
No se eliminó esa comprobación o vació artificialmente el registro en producción.

Final dirigida **34/34** y batería completa **740/740** aprobadas. Se conservan XML/logs
fallidos y finales, sin convertirlos en éxito. El caso corregido acredita preparación
y muestra comprimida mediante el cargador/periodo reales, sumado a los tests anteriores
de extractor y saltos. No acredita por sí solo que el hardware haya mostrado/sonado esa
muestra en la SM-X230 o que el servidor concreto del usuario esté accesible.

**Lint0 errores/{lint['warnings']} avisos**, sin supresiones nuevas. Categorías:
`{json.dumps(lint['categories'],ensure_ascii=False)}`.
Grafo runtime idéntico a0.33, {v['runtime_dependency_graph_lines']} líneas; no se actualizó
o añadió biblioteca. XML finales sin CloseGuard/recurso sin cerrar, NoSuchMethodError
o SQLiteException. Permanecen avisos de deprecación/J2ObjC y mensajes previos de fixtures
de imagen inválida, sin fallos finales. Compilación principal y de pruebas aprobadas.

**42 pruebas Android compiladas,0 ejecutadas.** Dos nuevas verifican consumo del hint
sin reenvío y periodo progresivo nativo con muestra de video, usando el MP4 propio y
HTTPS simulado. No hay dispositivo adb conectado ni /dev/kvm; el resultado de disponibilidad
se conserva. No se afirma ejecución física, acceso real a CDN o resolución de autenticación.

No se descargaron medios upstream, recuperaron cuentas/claves/JSON privado o copiaron
capturas al ZIP. El único MP4 es propio de2,925,145bytes, solo en assets de pruebas;
no se incluye en el APK principal. La captura se usó únicamente para leer el diagnóstico.

## Funciones conservadas y entrega

Ver en línea mantiene búfer temporal con objetivo32MiB, recurso máximo16GiB y sin
archivo de video en disco/selector SAF. Salir cancela, rotar conserva posición/pausa
pudiendo pedir red otra vez. Range/If-Range/ETag/Paw inmutable, validación206/416 y ausencia
de reintentos automáticos se conservan. Streaming no comprueba SHA completo antes de
mostrar, incluido Pawchive; preparación/cola/guardar siguen comprobando la copia completa
y mantienen sus límites. Galería, lectores, biblioteca e historial existentes permanecen;
abrir el stream no inserta ficha o visita ficticia. No se añade HLS/DASH, calidad adaptativa,
transcodificación, cuenta, fuente o resolución Gofile/masked.

Room13/esquemas y JSON17 (lee1–17) intactos. Manifiesto/permisos, dependencias, assets y
nativos anteriores idénticos por bytes. Clases Peach {classes['before']}→{classes['after']},
0 retiradas. Sin actividad/proveedor/servicio nuevos. AGPL3+ y atribuciones conservadas.
Nueve conectores anteriores; Kemono/Coomer/SimpCity excluidos.

APK **{apk['file']}**, {apk['bytes']:,} bytes,
SHA-256 `{apk['sha256']}`.
APK de pruebas incluido en ZIP: {test['bytes']:,} bytes,
SHA-256 `{test['sha256']}`. No hace falta instalarlo al usuario.
Ambos con firma original/v2 comprobadas; principal alineado16KiB,
com.peach.local,34/0.34.0,min26/target36. Instalar sobre0.33 sin desinstalar/borrar datos/
reimportar. Clave original fuera del proyecto y ZIP; nunca regenerarla para actualizar.

```
python3 scripts/run-gradle.py --init-script scripts/build-outside-workspace.init.gradle :app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:assembleDebugAndroidTest --console=plain
```

Java17.0.21+9/Gradle8.13/AGP8.13.0/SDK36/build-tools35.0.0, build externo PEACH_BUILD_ROOT,
keystore original separado y truststore del sistema. verify/report/package-release034.py
comprueban firma/resultados/conservación y empaquetan fuente limpio, historial Git,
APKs, XML/HTML/logs, hashes y CRC/bytes. La reproducción negativa puede repetirse en
checkout aislado819bfaa copiando el fixture baseline033 como ProgressivePipelineTest.java
y ejecutando ese test. La fuente y bundle conservan todos los antecedentes.

GUIA_STREAMING_034.md propone solo volver al video de la captura y comprobar imagen/
sonido/pausa; no repetir nueve fuentes o instalar APKs de prueba intermedios. STREAMING.md,
PLAN_FUENTES.md y matriz distinguen el defecto0.33 de la corrección aún sin aceptación
física. Gofile se pospone hasta cerrar este recorrido. Cuerpos/cuentas, interfaz, formatos,
sincronización y la demás paridad original siguen abiertas. No se declara terminado Peach.
'''
(R/'docs/PRUEBAS.md').write_text(text)
for src,dst in [('PRUEBAS.md','Peach-Local-informe-0.34.0.md'),('COMPATIBILIDAD_ORIGINAL.md','Peach-Local-compatibilidad-original-0.34.0.md'),('GUIA_STREAMING_034.md','Peach-Local-guia-streaming-0.34.0.md'),('PLAN_FUENTES.md','PLAN_FUENTES.md')]:shutil.copy2(R/'docs'/src,D/dst)
print(json.dumps({'report':str(D/'Peach-Local-informe-0.34.0.md'),'unit':v['unit'],'lint':lint},ensure_ascii=False))
