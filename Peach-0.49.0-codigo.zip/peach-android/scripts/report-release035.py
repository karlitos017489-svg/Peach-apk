#!/usr/bin/env python3
"""Report measured local verification; no inferred device or live-CDN result."""
from pathlib import Path
import argparse,json,shutil
p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args()
R=Path(__file__).resolve().parents[1];D=Path(a.out)
v=json.loads((D/'Peach-Local-verificacion-0.35.0.json').read_text())
assert v['unit']=={'tests':765,'failures':0,'errors':0,'skipped':0,'classes':116}
assert v['lint']['errors']==0 and v['instrumentation']=={'compiled':44,'executed':0}
apk,test,lint,classes=[v[k] for k in ['apk','test_apk','lint','peach_classes']]
text=f'''# Peach Local 0.35.0 — calidad, variantes y consulta revisable

28 de octubre de2026 UTC. Samsung Galaxy Tab A11+ SM-X230. Proyecto abierto.

El usuario aceptó0.34 y reportó demoras, baja calidad o muestras de videos en varios
proveedores: Rule34Video, cum.st y otro Rule34. La primera respuesta limitada a una
fuente quedó corregida por su aclaración. El APK0.34 adjuntado se comprobó localmente:
10,161,085bytes, SHA b48576848e90a933226369e15f95c485272418018bb8d2ceefde36f7eaefda6e,
idéntico al entregado. Solo se conserva esa evidencia, sin copiar el adjunto al proyecto.
La aceptación del usuario no equivale a ejecución propia de instrumentación o prueba0.35.

## Comportamiento implementado

VideoVariants distingue preview conocida, versión de descarga, archivo publicado o
variante. Muestra altura numérica p y tamaño declarados cuando existen; no inventa
resolución/duración. Preselecciona mayor altura reconocida dentro del primer grupo no
preview, con bytes como desempate; no salta a otro archivo independiente por ser mayor.
La elección manual permanece al rotar. Indicios preview por nombre/ruta no prueban
duración: un clip corto puede ser el original y una fuente puede ofrecer solo muestras.

Rule34Video marca data-preview del listado y recupera enlaces MP4/WebM del detalle con
su calidad declarada. Reconoce previews antiguas por procedencia/nombre. cum.st conserva
alternativas de video del mismo adjunto en vez de una sola elegida por bytes, evitando
preferir un póster mayor; omite locked y manifiestos. Usa únicamente campos/rutas del
contrato anterior, sin suponer dimensiones nuevas de API. Mantiene100 adjuntos máximos:
primero principales de cada original, después extras de video, con aviso al no caber.
Rule34.xxx sigue file_url; sample_url/preview_url no lo sustituyen. Paheal mantiene el
medio principal del detalle. No hay archivo HD ficticio, transcodificación o HLS/DASH.

Consultar versiones consulta explícitamente una publicación individual existente de
Rule34Video, Paheal o cum.st, aun fuera de la página pendiente. No descarga medios ni
se aplica automáticamente: revisión → Usar versiones o Conservar actuales. Solo el
primer botón confirmado escribe el cuerpo/adjuntos. Ficha, notas, vínculos, archivos
guardados e historial se conservan. Se comprueban identidad y sello del cuerpo dentro
de transacción; cambio concurrente, cancelación, fuente pausada o espera impiden aplicar.
Un resultado vacío o solo previews frente a archivo no preview actual no reemplaza
el cuerpo.429 conserva espera en fuente vinculada; sin conexión bloquea la consulta.
No se añade consulta individual o credencial nueva a Rule34.xxx.

VideoStream puede reutilizar en RAM el destino Rule34Video ya validado para rangos.
SourceHttp vuelve a comprobar HTTPS/DNS público en cada apertura; las políticas de
otros proveedores/API e ingreso inicial permanecen.403/404/410 permiten un regreso al
origen admitido;429 no evita su espera mediante ese regreso. Cambios de representación
o huella del destino aún se rechazan, sin mezclar bytes. URL solo en sesión, eliminada
al cerrar, nunca Room/copia/cache/Intent. En el fixture origen→CDN→CDN usa3 solicitudes
frente a4 del recorrido repetido; no es una medición real de latencia o disponibilidad.

PlayerActivity muestra buffering, estado y dimensiones cuando Media3 las comunica.
Mantiene objetivo32MiB/5–15s y límite16GiB online, sin copia completa en disco. Índice
del contenedor, códec, red o servidor pueden seguir demorando el inicio. Preparación,
guardar y cola conservan sus límites/comprobación completa y opción offline. Streaming
no verifica el SHA completo antes de mostrar, incluido Pawchive. El fix Media30.34
para Icy-MetaData:1 permanece con sus validaciones, sin cookies/cuentas nuevas.

## Resultados ejecutados

**765 pruebas JVM en116 clases;0 fallos,0 errores y0 omitidas.**25 nuevas:

- VideoVariantQualityTest7: preview antigua, selección por grupo, variantes cum.st,
  principales antes de extras, locked/manifiesto, file_url y roundtrip copia17.
- VideoVersionReviewTest8: consulta individual sin medios, revisión/aplicación,
  datos personales, identidad/cuerpo obsoletos, borrado, proveedores, cancelación,
  pausa/429, resultados vacíos y protección frente a downgrade a previews.
- StreamDeliveryReuseTest6: número de conexiones, rangos/bytes exactos, expiración,
  cambio de destino,429, DNS privado, cierre e aislamiento de otros proveedores/API.
- VideoVersionUiTest4: etiquetas, consulta explícita, conservar/aplicar, selección,
  offline, rotación y salida sin diálogo/escritura tardíos.

Compilación inicial aprobada. Dirigida existente51/51, primera metadata24/24 y dirigida
combinada76/76 aprobadas. Batería completa765/765 y build principal/androidTest aprobados.
Esos subconjuntos no se suman como pruebas distintas a765. Se conservan logs/XML y
reporte HTML completo. No hubo ejecución Gradle fallida en este bloque. XML finales
sin CloseGuard de recurso sin cerrar, NoSuchMethodError o SQLiteException.

Lint **0 errores/{lint['warnings']} avisos**; categorías reales:
`{json.dumps(lint['categories'],ensure_ascii=False)}`.
Sin supresiones nuevas. La cantidad de sugerencias de versiones de GradleDependency
puede variar según metadatos disponibles; las bibliotecas no se actualizaron.
Grafo debugRuntimeClasspath idéntico a0.34, {v['runtime_dependency_graph_lines']} líneas.

**44 pruebas Android compiladas,0 ejecutadas.** Dos nuevas prueban Room aislado y copia17
con variantes. adb sin dispositivo y /dev/kvm ausente, evidencia conservada. Los fixtures
usan HTML/JSON y MP4 propios, HTTPS/DNS simulados:0 solicitudes de medios upstream,
sin videos/cuentas/claves/JSON privado del usuario. No se acredita decodificación física,
tiempo del primer fotograma, duración completa o disponibilidad real de las fuentes.
La prueba de nombres/calidades no equivale a verificar el esquema completo de cum.st.

## Conservación y artefactos

Room13/esquemas y copiaJSON17 (lee1–17) iguales. Campos opcionales de variante dentro
del JSON de adjuntos, roundtrip comprobado; lectores previos pueden ignorarlos.
Manifiesto/permisos, runtime, assets y nativos idénticos a0.34. Clases Peach
{classes['before']}→{classes['after']},0 retiradas. Sin servicio/actividad/proveedor nuevo.
Nueve conectores, exclusiones Kemono/Coomer/SimpCity y AGPL3+/atribuciones conservados.

APK **{apk['file']}**, {apk['bytes']:,} bytes,
SHA-256 `{apk['sha256']}`.
APK de pruebas incluido en ZIP: {test['bytes']:,} bytes,
SHA-256 `{test['sha256']}`. No hace falta instalar el APK de pruebas.
Ambos firma original/v2; principal zipalign16KiB comprobado. com.peach.local,
35/0.35.0,min26/target36. Instalar sobre0.34 sin desinstalar/borrar datos/reimportar.
Clave original fuera del repositorio/ZIP: no regenerarla.

```
python3 scripts/run-gradle.py --init-script scripts/build-outside-workspace.init.gradle :app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:assembleDebugAndroidTest --console=plain
```

Java17.0.21+9, Gradle8.13, AGP8.13.0, SDK36/build-tools35.0.0. Build externo
PEACH_BUILD_ROOT, keystore separado y truststore del sistema. verify/report/package-release035.py
comprueban firma/conservación/resultados y empaquetan fuente limpio, historial Git,
APKs, XML/HTML/logs, hashes y CRC/bytes. Reportes históricos preservados, incluido0.34.

CALIDAD_Y_VERSIONES.md explica límites; GUIA_CALIDAD_035.md propone un caso Rule34Video y,
si ya se tiene, otro cum.st. No repetir nueve fuentes ni APKs experimentales.0.35 aún
no tiene aceptación física. Gofile/masked, cuerpos/cuentas, interfaz, formatos y resto
de sincronización/paridad siguen abiertos. El proyecto no se declara terminado.
'''
(R/'docs/PRUEBAS.md').write_text(text)
for src,dst in [('PRUEBAS.md','Peach-Local-informe-0.35.0.md'),('COMPATIBILIDAD_ORIGINAL.md','Peach-Local-compatibilidad-original-0.35.0.md'),('GUIA_CALIDAD_035.md','Peach-Local-guia-calidad-0.35.0.md'),('PLAN_FUENTES.md','PLAN_FUENTES.md')]:shutil.copy2(R/'docs'/src,D/dst)
print(json.dumps({'report':str(D/'Peach-Local-informe-0.35.0.md'),'unit':v['unit'],'lint':lint},ensure_ascii=False))
