#!/usr/bin/env python3
"""Report actual verification without inferring a live account or native execution."""
from pathlib import Path
import argparse,json,shutil
p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args();R=Path(__file__).resolve().parents[1];D=Path(a.out)
v=json.loads((D/'Peach-Local-verificacion-0.37.0.json').read_text())
assert v['unit']=={'tests':832,'failures':0,'errors':0,'skipped':0,'classes':124}
assert v['lint']['errors']==0 and v['instrumentation']=={'compiled':48,'executed':0}
apk,test,lint,classes=[v[k] for k in ['apk','test_apk','lint','peach_classes']]
text=f'''# Peach Local0.37.0 — sesión F95 opcional y enlaces masked

28 de octubre de2026, America/Hermosillo. Samsung Galaxy Tab A11+ SM-X230.
El usuario aceptó0.36 y pidió siguiente bloque/preguntó cuánto falta.0.37 todavía no
tiene su aceptación en tablet. Proyecto abierto: APK nativo autónomo y paridad compatible.

## Auditoría y alcance

Se leyó F95ZoneConnector/follow_sources.py y el snapshot f95-masked-gofile-media del
original fijo de22796c04919aaa057d77930c33c81313765569. Cookie opcional para /latest y
un POST al masked original con xhr=1&download=1; JSON status=ok/msg contiene el destino.
El original mantiene cookie en F95, no en Gofile/Pixeldrain. El snapshot de28-agosto-2026
documenta sesión necesaria y CAPTCHA como respuesta posible. No se añade SimpCity.

La comprobación actual de https://f95zone.to/assets/js/masked.js recibió HTTP200 pero
**195 bytes HTML Site Unavailable**, no el script de1255bytes del snapshot. Fuente/snapshot
se recuperaron HTTP200; huellas en audit-resources.json. No se considera protocolo vivo
confirmado por ese200.0 sesiones/cuentas reales,0 POST masked reales y0 medios upstream.
Solo se implementa el subconjunto del protocolo fijado y se prueban respuestas propias.

## Cambios implementados

Sesión F95 permite importar de forma avanzada una cabecera Cookie propia que ya se tenga,
opcional, sin pedir contraseña o leer Chrome. No hay WebView, inicio de sesión nativo,
obtención de cookies, solución CAPTCHA, cambio de fingerprint o reintento de acceso.
Sin sesión continúa el transporte público anterior. Límite8KiB/64 pares, sintaxis cookie,
xf_user o xf_session no vacía, sin controles/duplicados/inyección. toString oculta el valor.

F95Secrets cifra AES-GCM con IV nuevo/AndroidKeyStore, alias y archivos separados de
Rule34.xxx/Gofile, AtomicFile y exclusión mutua entre instancias. Fuera de backups, sin
fallback plano. Diálogo FLAG_SECURE/no prellenado/no saved view state/limpieza al cerrar.
Guardar no valida cuenta o hace red. Cambiar/borrar invalida planes y ETag/LastModified/
fecha de validación de fuentes F95, manteniendo caché/cuerpos y espera vigente.

F95Http solo recibe rutas exactas f95zone.to. GET con sesión admite hasta3 redirects al
mismo hilo, no login/otro hilo/host/adjunto; Cookie permanece en ese host. POST masked
no admite redirect. Cuerpo fijo y headers propios; sin Bearer/headers de otras fuentes.
HTTPS/DNS público por apertura, TLS del sistema,15s conexión/lectura,60s lectura acotada,
HTML/JSON2MiB; UTF-8, MIME/encoding y JSON32niveles para resolución. No Set-Cookie jar.
Contenido/cabeceras de HTML se limpian de secretos conocidos antes de persistirse.

F95LinksActivity no exportada recibe solo publicaciónID. Lee enlaces importados al abrir,
sin red. Resolver uno consulta exclusivamente el masked original; jamás el destino.
Sin sesión/offline/pausa/espera no solicita. Solo status=ok y URL admisible produce una
revisión; CAPTCHA/error/eco de sesión/destino ajeno mantiene referencia, sin archivo falso.
Destino Gofile es carpeta canónica, no video; Pixeldrain /u/ID es referencia; archivo de
attachments.f95zone.to de contrato anterior puede usar las opciones nativas existentes.

Incorporar exige confirmación y transacción con identidad/cuerpo/original/sesión vigentes,
cancelación y máximo100. Añade un destino sin reemplazar ficha, notas, texto, otros adjuntos,
referencia masked o archivos guardados; duplicados no se añaden. Reimportar origen conserva
destinos resueltos y Gofile anterior. No fichas/historial ficticios. Navegar a Gofile pasa
solo publicaciónID; su API sigue usando Bearer propio, sin Cookie F95. No amplía sus permisos.

HTTP429 se procesa antes del cuerpo y persiste espera F95 hasta24h por respuesta, incluidas
sus fuentes de hilo. Se conserva al cerrar/cambiar/borrar sesión y no bloquea otros sitios.
401/403 conservan diagnóstico/status saneado sin afirmar que un login real funcionó.
Salir cancela, rotar conserva un trabajador y no aplica/abre automáticamente. También se
clasifican videos directos F95 e imágenes img src admitidos para los medios nativos;
hosts/rutas/credenciales del transporte de archivos no se amplían o reciben Cookie.

## Validación ejecutada

**832 pruebas JVM/124 clases,0 fallos,0 errores,0 omitidas**. Conserva800 y añade32:

- F95ProtocolTest9: sintaxis/ocultación, POST exacto/cuerpo y no target fetch, redirects
  GET solo hilo, POST redirect/HTML CAPTCHA rechazados, origen/DNS/cancelación,401/403/
  429 sin lectura del error, límites/UTF-8/encoding, puerto privado separado y transporte
  público anterior, redacción y clasificación de video/img-src sin consultar medios.
- F95SecretsTest4: roundtrip/IV/cifrado sin texto, tamper/clave incorrecta/Keystore no
  disponible sin fallback, espera entre instancias/cambio/borrado, concurrencia atómica.
- F95ReviewTest13: consulta sin aplicar, datos personales, sesión ausente/proveedor/link
  ajenos, cuerpo/identidad/sesión obsoletos o borrado, cancelación, CAPTCHA/secretos/destinos,
  espera global y aislamiento, pausa, máximo/duplicados, directos/Pixeldrain referencia,
  copia18, reimportación real del origen, Gofile con Bearer propio sin Cookie y cambio
  de sesión invalidando planes/condicionales mientras conserva caché/espera/cuerpos.
- F95UiTest6: apertura local/revisión/confirmación, offline/sin sesión, rotación sin
  duplicados/autonavegación, cancelación inmediata al salir, diálogo seguro/borrado y
  salto Gofile solo conID sin secreto/URL o consulta automática.

Compilación inicial aprobada. Primera dirigida49/49 en6 clases, combinada128/128 en16
clases aprobadas. Se añadió el caso de invalidación de caché al cambiar sesión antes
de la batería final832/832. Subconjuntos no se suman como tests distintos. No hubo
ejecuciones Gradle fallidas en este bloque; se archivan logs y XML dirigidos/finales.
XML finales sin CloseGuard/recurso sin cerrar, NoSuchMethodError o SQLiteException.

Lint **0 errores/{lint['warnings']} avisos**, sin supresiones nuevas:
`{json.dumps(lint['categories'],ensure_ascii=False)}`.
Grafo runtime idéntico a0.36, {v['runtime_dependency_graph_lines']} líneas. Ninguna biblioteca
actualizada/añadida. Permanecen deprecación/J2ObjC/fixtures de imagen inválida, sin fallos.

**48 pruebas Android compiladas,0 ejecutadas.** Dos nuevas para revisión/copia18 Room
aislado y sesión/espera con alias Keystore exclusivo. Sin tocar sesiones reales o datos
instalados; no adb conectado ni /dev/kvm, evidencia registrada. AES JVM se ejecuta con
clave de test, no se presenta como AndroidKeyStore real en SM-X230. HTTPS/DNS/cookies/
páginas/JSON propios; no cuenta/POST/media real, actual protocolo vivo o hardware probado.

## Conservación, entrega y cuánto falta

Room13/esquemas y BackupStore18 idénticos por bytes a0.36. Campos de procedencia opcionales
dentro de adjuntos existentes, validados al restaurar; URLs descargables previas intactas.
Sin nuevo formato obligatorio de copia o secreto respaldado. Manifiesto solo añade
F95LinksActivity no exportada; permisos/servicios/proveedores y dependencias iguales.
Assets/nativos anteriores idénticos; clases Peach {classes['before']}→{classes['after']},
0 retiradas. AGPL3+/atribuciones y nueve conectores/exclusiones Kemono/Coomer/SimpCity
conservados. Galería, cola, lectores, offline, límites de descarga/streaming y hash previos
permanecen; streaming sigue sin comprobar SHA completo antes de mostrar, incluido Pawchive.

APK **{apk['file']}**, {apk['bytes']:,} bytes,
SHA-256 `{apk['sha256']}`.
TestAPK en ZIP: {test['bytes']:,} bytes,
SHA-256 `{test['sha256']}`. No hace falta instalar el APK de pruebas.
Firma original/v2 en ambos; principal zipalign16KiB. com.peach.local37/0.37.0,
min26/target36. Instalar sobre0.36 sin borrar/desinstalar/reimportar. Keystore original
fuera de repositorio/ZIP: no regenerarlo para actualizar.

```
python3 scripts/run-gradle.py --init-script scripts/build-outside-workspace.init.gradle :app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:assembleDebugAndroidTest --console=plain
```

Java17.0.21+9/Gradle8.13/AGP8.13.0/SDK36/build-tools35.0.0, PEACH_BUILD_ROOT externo,
keystore aparte y truststore del sistema. verify/report/package-release037.py comprueban
resultados/firma/conservación, fuente limpio/bundle/historial, APKs, XML/HTML/logs/hashes/CRC.
Los informes anteriores, incluido0.36, se conservan. Sin capturas, JSON privado, sesiones,
claves de usuario/firma o medios terceros en la entrega; solo fixtures propios.

PENDIENTES.md responde a la pregunta del usuario: seis frentes grandes —fuentes/accesos/
metadatos, formatos, organización, sincronización/servicios opcionales, interfaz/rendimiento,
validación final—, no seis APK garantizados. No hay porcentaje o fecha fiable; cada frente
puede requerir varios bloques. La base funcional existe, pero no se afirma paridad total.
Siguiente prioridad prevista: evaluar RAR/CBR para lectura Android compatible, según
dependencias, licencias, formatos y memoria. No dar por concluido el proyecto.

F95_SESION_Y_ENLACES.md y GUIA_F95_037.md explican el uso/límites. Sin cabecera propia ya
disponible basta comprobar apertura/offline/sin sesión; no pedir credenciales al chat,
repetir9fuentes o hacer al usuario obtener una sesión para validar el APK. Login nativo,
cuentas/contratos actuales y el resto de la matriz original siguen pendientes.
'''
(R/'docs/PRUEBAS.md').write_text(text)
for src,dst in [('PRUEBAS.md','Peach-Local-informe-0.37.0.md'),('COMPATIBILIDAD_ORIGINAL.md','Peach-Local-compatibilidad-original-0.37.0.md'),('GUIA_F95_037.md','Peach-Local-guia-f95-0.37.0.md'),('PENDIENTES.md','Peach-Local-pendientes-0.37.0.md'),('PLAN_FUENTES.md','PLAN_FUENTES.md')]:shutil.copy2(R/'docs'/src,D/dst)
print(json.dumps({'report':str(D/'Peach-Local-informe-0.37.0.md'),'unit':v['unit'],'lint':lint},ensure_ascii=False))
