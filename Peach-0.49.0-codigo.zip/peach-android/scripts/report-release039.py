#!/usr/bin/env python3
from pathlib import Path
import argparse,json,shutil
p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args();R=Path(__file__).resolve().parents[1];D=Path(a.out);v=json.loads((D/'Peach-Local-verificacion-0.39.0.json').read_text());u=v['unit'];lint=v['lint'];apk=v['apk'];test=v['test_apk']
assert u=={'tests':881,'failures':0,'errors':0,'skipped':0,'classes':131};assert v['instrumentation']=={'compiled':52,'executed':0}
text=f'''# Peach Local 0.39.0 — descompresión RAR/CBR compatible

28 de octubre de2026, America/Hermosillo. Samsung Galaxy Tab A11+ SM-X230.
El usuario confirmó descarga y funcionamiento de0.38.0 y pidió el siguiente bloque.
0.39 pendiente de aceptación propia. Proyecto abierto; no se declara paridad completa.

## Resultado

APK autónomo con libarchive3.8.10 compilado para ARM64, ARMv7, x86_64 y x86. Descompresión
selectiva de entradas compatibles RAR4/RAR5, proceso Android aislado/no exportado, AIDL
por descriptores, sin rutas, URLs, cuentas o servidor externo. Las entradas almacenadas
mantienen el lector Java de0.38. Índice, búsqueda, imágenes/texto/PDF, zoom/navegación,
posición/favorito/leído e historial conservan sus controles anteriores. No anidados/AV.

RarBook comprueba y revalida cabeceras, CRC y límites antes del motor. Origen solo lectura,
salida solo escritura. Wrapper JNI valida tipo regular, nombre, tamaño y CRC, sin seguir
links. Cliente vuelve a comprobar tamaño/CRC antes de publicar la vista. Errores/muerte/
cancelación eliminan parcial y preservan la vista anterior/original. No mensajes nativos
crudos o secretos en IPC. Servicio comprueba UID llamante, no añade permiso/red/arranque
externo o servicio permanente. Solo se carga la biblioteca dentro del proceso aislado.

RAR4 métodos31–35 y RAR5 algoritmo0 métodos1–5/diccionario<=64MiB, con variantes limitadas
por parser y motor. **No soporte universal RAR/CBR**: sólidos, volúmenes/SFX, contraseñas,
Unicode comprimido heredado RAR4/ANSI ambiguo, RAR7 comprimido y extras no reconocidos
siguen pendientes. Fuente/total declarado512MiB, selección64MiB. Cuota malloc160MiB,
asignación64MiB, no máximo de RAM total del proceso. Android RLIMIT_FSIZE64MiB. Plazo
nativo85s en callbacks/salida y watchdog90s que solicita terminar proceso; vinculación10s.
No se promete un tiempo absoluto ante bloqueos de sistema/JNI/Binder. Detalles completos
en LECTURA_RAR_COMPRIMIDA.md, incluido comportamiento al pausar/rotar la actividad.

## Dependencia y compilación

Estable oficial libarchive3.8.10 del14-octubre-2026, fuente completa fijada/SHA256 dentro
del proyecto, licencias BSD/per-file y BLAKE2 CC0, avisos incluidos. NDKr30/30.0.16248370,
API26. Cuatro ELF con PT_LOAD16KiB, dependencias solo libc/libm/libdl y sin símbolos del
helper host que abre rutas de test. RarNativeTest helpers se compilan solo en Linux.
No Junrar/UnRAR ni compresor RAR en APK/proyecto. Binarios precompilados y script con
fuente para reconstrucción. NDK y herramientas de fixtures permanecen fuera del paquete.

Intentos intermedios de compilación nativa detectaron enlaces simbólicos del ZIP NDK
extraídos como texto y falta del include android_lf.h de contrib/android. Se restauraron
los symlinks, se añadió el include oficial y se reconstruyeron los cuatro ABIs. Son
correcciones del entorno/build, no una ejecución física Android. Auditoría y logs incluidos.

## Pruebas ejecutadas

**{u['tests']} JVM/Robolectric en{u['classes']} clases;0 fallos,0 errores,0 omitidas**.
Conserva860 y añade21 en4 clases:

- RarNativeTest6: motor JNI/C real Linux. Seis archivos propios RAR4/RAR5, niveles1/3/5,
  recuperan texto,2PNG y BMP byte a byte (24 selecciones). Presupuesto insuficiente,
  CRC/tamaño esperado incorrectos, daños/truncado/ausencia,15 relecturas sin estado o
  asignaciones residuales, y composición con parser Java. Cuota se prueba con muestra
  propia mayor, no una asignación ficticia; restante de asignaciones verificado0.
- RarIpcTest7: IPC/controlador con dobles, descriptores y confirmación de tamaño/CRC,
  rechazo nativo/leak, conexión rechazada, cancelación previa/activa, watchdog de1s en
  test y códigos/mensajes acotados. Desvinculación/cleanup y vista anterior comprobados.
- RarServiceTest4: admisión y cancelación antes de empezar, envelope inválido sin
  cargar motor, cancelación por ID activo y cierre por flag de fuga. Dobles sin matar JVM.
- RarDecodedReaderTest4: RAR4/RAR5 con BMP/texto por pipeline de descriptores simulado,
  render real de colores, almacenados evitan motor, rechazo RAR7/diccionario grande/sin
  CRC antes de native, cambio de índice y cancelación reenviada. No equivale a ejecutar
  ABI Android/Binder real; eso queda para la instrumentación.

Se actualizaron tres expectativas anteriores: etiqueta ya indica lectura parcial y los
casos de índice sin descompresor usan RAR7 comprimido todavía fuera del alcance, con las
mismas aserciones de preservación. Nuevos archivos válidos prueban la rama comprimida.

Primer intento de tests falló al usar ServiceController como AutoCloseable; se corrigió
el fixture con destroy explícito. Segundo dirigido45/1: muestra de cuota demasiado
pequeña no llegaba al límite; se creó la muestra mayor y la prueba pasó. Tercer dirigido
49/1: se había supuesto que un PNG del RAR oficial estaba almacenado; sí estaba comprimido.
Se usó una entrada almacenar explícita para ese control, manteniendo la comprobación de
la rama comprimida. Suite completa final881/881, sin suprimir controles. Logs/XML incluidos. Tras el full se ampliaron avisos per-file
de licencia en assets y se repitieron lint/ensamblado de ambos APK sin cambiar el código
ejecutado por las pruebas; ambos builds exitosos se conservan.

Lint **0 errores/{lint['warnings']} avisos**, categorías XML/JSON/HTML exactas. No nueva
supresión.52 pruebas Android **compiladas,0 ejecutadas**, incluidas2 nuevas con servicio
real y medios propios RAR4/RAR5. No adb conectado/KVM, no instalación o ejecución en
SM-X230 desde aquí. Alineación ELF/APK no prueba ejecución en un Android de16KiB.
No se probaron cuentas, fuentes/CDN reales, medios privados o latencia/códecs físicos.

## Integridad y entrega

Room13/esquemas y BackupStore/copia18 lee1–18 iguales a0.38. Dependencias Maven/runtime
sin cambios. Manifest añade solo RarService no exportado/aislado; permisos iguales.
Assets anteriores idénticos salvo avisos ampliados y nueva licencia;4 librerías nativas
nuevas. Clases Peach {v['peach_classes']['before']}→{v['peach_classes']['after']},0 eliminadas.
Firma original/v2, alineación APK16KiB, versión39/0.39.0, min26/target36 comprobadas.

APK: {apk['bytes']} bytes; SHA256 `{apk['sha256']}`.
APK de instrumentación: {test['bytes']} bytes; SHA256 `{test['sha256']}`.
Instala sobre0.38 sin desinstalar. ZIP pequeño de descarga contiene exactamente el mismo
APK; ZIP del proyecto incluye fuente/historia, APKs, informes, XML/HTML y muestras propias.
No claves, cookies, screenshots del usuario o compresores trial incluidos.

Funciones anteriores y nueve fuentes conservadas por suite completa. Kemono/Coomer/
SimpCity excluidos. F95 login nativo y seis frentes siguen abiertos. Streaming no hace
SHA completo antes de mostrar (incluidoPaw); descarga completa mantiene comprobaciones.
La siguiente prioridad es cerrar compatibilidad RAR pendiente según viabilidad, validar
Android real y continuar los frentes restantes; no porcentaje, fecha o cierre inventados.
'''
(R/'docs/PRUEBAS.md').write_text(text);(D/'Peach-Local-informe-0.39.0.md').write_text(text)
guide='''# Comprobación breve0.39 — RAR/CBR comprimido

Instala sobre0.38 sin desinstalar. No necesitas Cookie F95, PC, Termux o servidor.
No hace falta repetir las nueve fuentes. Si quieres comprobar el bloque, en samples del
ZIP del proyecto están own-rar4-m3.cbr y own-rar5-m3.cbr, con medios sintéticos propios.
Añade/escanea su carpeta y ábrelos en la biblioteca. En Contenido selecciona page.bmp
(imagen roja/azul) y notes.txt; cierra/reabre para comprobar la posición. Puedes usar tus
archivos compatibles sin extraer muestras. El lector no cambia los originales.

Si indica variante no compatible, sólidos, volúmenes, cifrado, Unicode heredado RAR4
o RAR7 comprimido siguen pendientes; no es una solicitud de servidor externo.
Error de CRC/memoria preserva el archivo y la vista anterior.0.39 no admite todos losRAR.

La suite local tiene881 pruebas aprobadas;52 Android solo compiladas. Las nuevas prueban
el motor Android aislado cuando se ejecuten realmente. La comprobación en tablet cubre
esa parte del entorno que no se puede verificar con el motor Linux o los dobles de IPC.
El ZIP pequeño de descarga contiene el mismo APK firmado. Extrae e instala eseAPK.
'''
(R/'docs/GUIA_RAR_039.md').write_text(guide);(D/'Peach-Local-guia-rar-0.39.0.md').write_text(guide)
for f,n in [('COMPATIBILIDAD_ORIGINAL.md','Peach-Local-compatibilidad-original-0.39.0.md'),('PENDIENTES.md','Peach-Local-pendientes-0.39.0.md')]:shutil.copyfile(R/'docs'/f,D/n)
print(json.dumps({'unit':u,'lint':lint,'report_written':True}))
