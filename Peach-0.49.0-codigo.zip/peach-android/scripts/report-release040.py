#!/usr/bin/env python3
from pathlib import Path
import argparse,json,shutil
p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args();R=Path(__file__).resolve().parents[1];D=Path(a.out);v=json.loads((D/'Peach-Local-verificacion-0.40.0.json').read_text());u=v['unit'];lint=v['lint'];apk=v['apk']
text=f'''# Peach Local 0.40.0 — nombres Unicode RAR4

28 de octubre de2026, America/Hermosillo. Samsung Galaxy Tab A11+ SM-X230.
El usuario confirmó descarga y funcionamiento de0.39.0 y autorizó el siguiente bloque.
0.40 pendiente de comprobación del usuario. Proyecto abierto; no se declara paridad completa.

## Resultado

El lector RAR/CBR admite ahora nombres Unicode heredados RAR4: acentos, ñ, japonés y
pares UTF-16 válidos. Funciona con entradas almacenadas y comprimidas ya compatibles.
Conserva nombres exactos, índice/búsqueda, imagen/texto/PDF y selección por el motor
aislado de0.39. No adivina ANSI ni modifica o renombra el archivo original.

Parser acotado de cuatro instrucciones del campo Unicode,4096bytes de entrada y
4096bytes UTF-8 de salida. Rechaza truncados, instrucciones fuera del prefijo y
sustitutos aislados. Rutas y duplicados se validan después de decodificar. El prefijo
ANSI no sustituye el nombre Unicode al seleccionar contenido; nombres internos nunca
se usan como rutas de salida. Índice revalidado y tamaño/CRC comprobados antes de publicar.

No modifica el código ni los binarios del motor libarchive3.8.10, servicio aislado,
IPC, cuotas, watchdog o cancelación anteriores. Selección64MiB/fuente512MiB; cuota
nativa160MiB/asignación64MiB, no máximo de RAM total. Los límites de0.39 se conservan.
Sólidos, volúmenes/SFX, contraseñas, ANSI ambiguo, RAR7 comprimido y variantes/extras
sin CRC compatibles siguen pendientes. No se afirma soporte universal RAR/CBR.

## Validación ejecutada

{u['tests']} pruebas JVM/Robolectric en{u['classes']} clases;{u['failures']} fallos,
{u['errors']} errores,{u['skipped']} omitidas. Conserva881 y añade25 en3clases:

- Rar4NamesTest15: cuatro instrucciones, corrección y rebose del byte bajo,
  secuencias, UTF-8 directo/ASCII, pares UTF-16, truncados, límites y5000 campos cortos
  deterministas para comprobar errores controlados. Sin adivinar ANSI.
- RarUnicodeIndexTest7: archivos propios almacenados creados con herramienta oficial
  y cabeceras sintéticas; contenido exacto, rutas/controles/duplicados, cambio del
  índice y CRC dañado conservando la vista anterior y sin publicar parciales.
- RarUnicodeNativeTest3: JNI/C real Linux con archivos comprimidos propios y selección
  Unicode exacta; rechazo de nombres parecidos o prefijos ANSI y15 relecturas alternadas
  Unicode/ASCII sin estado anterior o asignaciones nativas residuales.

Dirigida RAR74/74 aprobada. El motor host se reconstruyó de la fuente fijada; su SHA256
coincidió con el avance recuperado. Cuatro archivos propios contienen texto de geología
y BMP rojo/azul; dos creados con RAR oficial6.24 y dos cabeceras Unicode sintéticas con
datos propios comprimidos anteriormente. El lector oficial comprobó todos los bytes;
su selector emoji usó comodín y no acredita el nombre exacto. Esa comprobación se hace
con JNI/libarchive. Herramienta externa no redistribuida. Fixtures/SHA en evidence/0.40.0.

Lint{lint['errors']} errores/{lint['warnings']} avisos; categorías exactas en JSON/XML.
Son11 avisos de disponibilidad de versiones más que en0.39, al consultar con caché
renovada; no cambian las versiones fijadas ni hay nuevas categorías de problemas
de código. Sin nuevas supresiones.
{v['instrumentation']['compiled']} pruebas Android compiladas,0 ejecutadas, incluidas
2 nuevas para Unicode almacenado y servicio aislado real cuando se ejecuten.
ADB no informó dispositivos y no hay KVM. No se ejecutó Android ABI/Binder real,
instalación/actualización física ni pruebas de cuentas, CDNs o contenido privado.
El funcionamiento comunicado para0.39 no se atribuye automáticamente a0.40.

Intentos intermedios: el primer offline falló por caché de dependencias incompleta;
una ejecución de red se interrumpió sin resultado de pruebas. Con certificados del
entorno se descargaron las dependencias fijadas. La primera compilación de tests
detectó3 usos de Files.readString/writeString fuera de la API Android disponible;
se usaron los helpers/bytes anteriores, sin quitar las aserciones. Dirigida final74/74.
Suite completa y ensamblado/lint finales exitosos; logs incluidos. Sin nuevas supresiones.

## Integridad y uso

APK{apk['bytes']}bytes; SHA256 `{apk['sha256']}`.
Firma original/v2 y alineación APK16KiB verificadas; versión40/0.40.0,min26/target36.
Room13, esquemas, BackupStore/copia18 lee1–18, manifiesto, permisos, dependencias y
grafo runtime de{v['runtime_dependency_graph_lines']} líneas conservados. Assets y
cuatro bibliotecas nativas idénticos byte a byte a0.39. Clases Peach
{v['peach_classes']['before']}→{v['peach_classes']['after']},0 eliminadas.

Instala sobre0.39 sin desinstalar. El ZIP pequeño contiene exactamente el mismo APK.
El paquete completo incluye fuente/historial, APKs, informes, XML/HTML y muestras propias.
No claves, cookies, medios privados o herramientas RAR/NDK en el paquete.

Nueve fuentes y funciones anteriores conservadas por regresión; Kemono/Coomer/SimpCity
siguen excluidos. Login F95 nativo y los seis frentes continúan abiertos. Próxima prioridad:
evaluar RAR sólido dentro del proceso aislado y sus presupuestos, validar Android real
y continuar los otros frentes. No se propone porcentaje o fecha final sin evidencia.
'''
(R/'docs/PRUEBAS.md').write_text(text);(D/'Peach-Local-informe-0.40.0.md').write_text(text)
for src,dst in [('COMPATIBILIDAD_ORIGINAL.md','compatibilidad-original'),('PENDIENTES.md','pendientes'),('GUIA_RAR_040.md','guia-rar')]:shutil.copy2(R/'docs'/src,D/f'Peach-Local-{dst}-0.40.0.md')
plan=f'''\n\n## Confirmación0.39 y bloque0.40: nombres Unicode RAR4

28 de octubre de2026, America/Hermosillo. El usuario confirmó que descargó0.39,
la probó y todo funciona; pidió continuar. Aceptación informada, no ejecución propia
de instrumentación ni validación exhaustiva de todo RAR.

0.40 admite nombres Unicode heredados RAR4 para entradas almacenadas/comprimidas
ya compatibles. Cuatro instrucciones, UTF-16 válido/UTF-8 exacto hasta4096bytes;
sin adivinar ANSI. Índice y motor seleccionan el mismo nombre. Rutas/duplicados después
de decodificar, revalidación, CRC/límites y conservación de original/vista previos.
No se amplían métodos de datos: sólidos, volúmenes/SFX, contraseñas, ANSI ambiguo,
RAR7 comprimido y variantes/extras sin CRC siguen pendientes. No soporte universal.

{u['tests']} JVM/{u['classes']} clases,0fallos/errores/omitidas;25nuevas. Dirigida74/74.
{v['instrumentation']['compiled']} Android compiladas/0ejecutadas,2nuevas. JNI Linux real,
4muestras propias,bytes comprobados también por RAR oficial; emoji del lector oficial
por comodín, exactitud del nombre comprobada por JNI.5000campos cortos de prueba.
Lint0errores/{lint['warnings']}avisos. Fallos intermedios de caché/API de tests corregidos
y documentados, sin quitar controles/supresiones nuevas. Sin Android físico/cuentas/CDN.

Firma original/v2/zipalign16KiB, APK40/0.40.0. Room13/copia18/esquemas/manifiesto/
permisos/runtimegraph{v['runtime_dependency_graph_lines']} y assets/4.so idénticos a0.39;
motor/servicio/IPC sin cambios. ClasesPeach{v['peach_classes']['before']}→{v['peach_classes']['after']},0eliminadas.
Entregar APK+ZIPpequeño idéntico y proyecto/pruebas; nunca incluir clave.
0.40 pendiente de comprobación propia del usuario. Nueve fuentes, exclusiones y seis
frentes se mantienen. Próximo: evaluar sólidos con límites y validar Android real,
después continuar frentes. Proyecto ABIERTO, sin porcentaje o fecha inventados.
'''
p=R/'docs/PLAN_FUENTES.md';s=p.read_text();assert '## Confirmación0.39 y bloque0.40' not in s;p.write_text(s+plan);shutil.copy2(p,D/'PLAN_FUENTES.md')
