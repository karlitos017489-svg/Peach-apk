#!/usr/bin/env python3
"""Publish measured Part 1 results and the agreed six-part delivery cadence."""
from pathlib import Path
import argparse,json,shutil
p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args();R=Path(__file__).resolve().parents[1];D=Path(a.out);v=json.loads((D/'Peach-Local-verificacion-0.42.0.json').read_text())
text=f'''# Peach Local 0.42.0 — Parte 1 de 6: organización de archivos

28 de octubre de 2026, America/Hermosillo. Galaxy Tab A11+ SM-X230.
El usuario solicita una entrega agrupada por cada parte, para probar el APK antes
de avanzar a la siguiente. Sustituye la estimación anterior de 15–20 subbloques.
Última aceptación física explícita: 0.40. La aceptación de 0.41 no se presume.
Esta entrega está lista para comprobación de la parte 1, proyecto abierto.

## Resultado

Organización nativa SAF con vista previa y Aplicar explícito: renombrar, mover,
papelera, historial/deshacer y reconciliación de operaciones interrumpidas.
Mantiene ID, favoritos, progreso, listas y grupos; el escaneo reconoce la ubicación
actual del documento. SHA-256 antes/después de cambios físicos. No sobrescribe
conflictos ni repite operaciones al abrir la pantalla. Excluye papelera del escaneo.

Escritura NFO audio/video: vista previa XML, combinación de campos compatibles,
conservación de nodos no modelados/IDs/valoraciones/roles sin cambios, respaldo
exacto previo, verificación de resultado y deshacer. Recuperación explícita tras
escritura parcial, con comprobación del contenido actual y exportación del respaldo.
No exporta secretos ni estado de reproducción. Rechaza entidades/DTD y XML inválido.

Revisión por SHA-256 para contenido idéntico; por código NFO para posibles obras o
versiones, incluso entre carpetas. Guardar grupos requiere revisión/selección y
revalidación. No elimina duplicados ni fusiona identidades o progreso. Listas de
partes con marcas numéricas consecutivas/coherentes y misma firma de versión.
Continúa la revisión de versiones por nombre anterior.

## Pruebas y corrección detectada

{v['unit']['tests']} pruebas JVM/Robolectric, {v['unit']['classes']} clases:
0 fallos, 0 errores, 0 omitidas. Conserva las 930 anteriores y añade 36:
FileOrganizerTest 27, NfoWriterTest 6 y FileOrganizationUiTest 3.
Prueban transporte simulado, Room real de prueba, journal privado de prueba,
rename/move/trash/undo, continuidad de estado, cancelación, colisiones, permisos,
resultados inciertos, interrupción al deshacer, journal corrupto, NFO parcial,
restauración/respaldo/alteraciones externas, revisión de duplicados y partes,
rotación y ausencia de aplicación automática. No son ejecución real del SAF Android.

Primera ejecución completa: 963 pruebas y un fallo anterior de menú al insertar
la nueva acción antes de un índice existente. Corregido en producción agregando
la acción al final; se conservan intactas las pruebas anteriores. Se añadieron
3 casos de recuperación. Dirigida final 44/44; completa final 966/966.
Logs/XML de la ejecución fallida y de la final se conservan como evidencia.

Lint: 0 errores y {v['lint']['warnings']} avisos, sin aumento respecto a 0.41,
sin nuevas supresiones. APK principal y AndroidTest compilados correctamente.
{v['instrumentation']['compiled']} pruebas Android compiladas, 0 ejecutadas.
Las dos nuevas comprueban ContentResolver con un DocumentsProvider de prueba
limitado a archivos desechables y XML nativo cuando se ejecuten en Android.
La prueba de proveedor no simula autorización persistente real: selector/grants,
proveedores del usuario, instalación/actualización y funcionamiento en SM-X230
requieren la prueba física del usuario. No hay dispositivo/KVM conectado aquí.
No se operaron archivos personales, cuentas, CDNs ni medios privados.

## Integridad

Versión 42/0.42.0, minSdk26/target36. Firma original/v2 y alineación16KiB
verificadas. APK {v['apk']['bytes']} bytes, SHA256 `{v['apk']['sha256']}`.
Mismos permisos y dependencias; grafo runtime {v['runtime_dependency_graph_lines']} líneas
idéntico a 0.41. Solo una actividad interna adicional en el manifiesto principal.
Room13/esquemas, LibraryDatabase, BackupStore/copia18 lee1–18 conservados.
Assets y cuatro bibliotecas nativas idénticos byte a byte. Ninguna clase Peach
anterior eliminada: {v['peach_classes']['before']} → {v['peach_classes']['after']}.
Proveedor/pruebas/fixtures no incorporados al APK principal.

## Límites y prueba del usuario

Mover requiere operación nativa entre carpetas del mismo proveedor. Se modifica
solo el archivo elegido; NFO/subtítulos/portadas auxiliares no se mueven solos.
No hay borrado definitivo de medios ni vaciado de papelera. No se afirma paridad
completa con un ledger canónico del original. Límites: archivo16GiB, NFO1MiB,
journal500registros/16MiB, revisión20.000filas/16GiB previstos/500propuestas.
Registro privado excluido de copias: desinstalar/borrar datos pierde deshacer y
respaldos, aunque los medios físicos permanecen. No hay transacción atómica entre
proveedor y Room ni plazo absoluto ante un proveedor bloqueado. Los detalles están
en PARTE_1_ORGANIZACION.md. Instalar sobre versión anterior sin desinstalar.

Probar primero con copias de archivos: renombrar/deshacer, mover/deshacer,
papelera/restaurar, escribir NFO/deshacer y revisar duplicados/partes.
Tras la prueba de esta parte y correcciones necesarias, continuar parte2 fuentes/
cuentas/descargas; parte3 formatos/lectores; parte4 importación/exportación/sync;
parte5 interfaz/rendimiento; parte6 validación Android/correcciones.
Nueve fuentes conservadas; Kemono/Coomer/SimpCity excluidos. APK autónomo.
'''
(R/'docs/PRUEBAS.md').write_text(text);(D/'Peach-Local-informe-0.42.0.md').write_text(text)
guide='''# Probar la parte 1 — Peach 0.42.0

1. Instala el APK sobre tu versión actual, sin desinstalar ni borrar datos.
2. Usa primero copias de un video o audio y sus archivos auxiliares.
3. Pausa el escaneo y espera a que termine. Abre Menú → Organizar archivos / papelera.
4. Selecciona el archivo y autoriza lectura/escritura de su misma carpeta raíz.
5. Prueba Renombrar → Vista previa → Aplicar. En Historial / papelera, Deshacer.
6. Elige una carpeta destino del mismo proveedor y prueba Mover y Deshacer.
7. Prueba Papelera y Deshacer: debe volver el archivo con sus favoritos/progreso.
8. Prueba Escribir NFO, revisa el XML y aplica. Deshacer debe restaurar el NFO previo
   exactamente, o retirar el recién creado. El historial permite exportar respaldos.
9. Revisa Contenido idéntico / Código NFO. Solo guarda grupos o listas tras revisar.

La vista previa no modifica archivos. Se mueve solo el archivo seleccionado:
subtítulos, NFO y portadas no se trasladan automáticamente. Los movimientos requieren
que Android permita mover dentro del mismo proveedor; una carpeta sin esa capacidad
se rechaza. No hay borrado definitivo de medios. Conserva la app instalada para
mantener historial y respaldos. Si aparece revisión pendiente, usa Reconciliar estado
antes de repetir: comprueba ubicaciones sin volver a ejecutar el cambio físico.

Esta es la parte 1 de 6. Al confirmar la prueba, sigue la parte 2 (fuentes/cuentas/
descargas), luego formatos, sincronización, interfaz y validación final.
'''
(R/'docs/GUIA_PARTE_1_042.md').write_text(guide);(D/'Peach-Local-guia-parte-1-0.42.0.md').write_text(guide)
for src,dst in [('COMPATIBILIDAD_ORIGINAL.md','compatibilidad-original'),('PENDIENTES.md','pendientes'),('PARTE_1_ORGANIZACION.md','organizacion')]:shutil.copy2(R/'docs'/src,D/f'Peach-Local-{dst}-0.42.0.md')
plan='''\n\n## Entrega agrupada 0.42: parte 1 de 6, organización de archivos

28 de octubre de 2026, America/Hermosillo. Usuario solicita terminar cada parte
completa y entregar APK para probar: parte1 organización; parte2 fuentes/cuentas/
descargas; parte3 formatos/lectores; parte4 importación/exportación/sincronización;
parte5 interfaz/rendimiento; parte6 validación Android/correcciones. La cifra previa
15–20 subbloques no define entregas. Última aceptación física explícita0.40;
0.41 no se presume aceptada,0.42 pendiente de comprobación.

0.42 agrupa vista previa/Aplicar, renombrar/mover SAF nativo mismo proveedor,
papelera/deshacer/journal/reconciliación, escritura NFO con respaldo/merge/recuperación,
revisión SHA256 y códigoNFO, grupos y listas de partes entre carpetas. Mantiene ID y
estado individual. Sin borrado definitivo de medios, auxsidecars automáticos,
movimientos entre proveedores ni fusión canónica de identidades. Operación física
solo mediante acción explícita en app. Límites/recuperación en PARTE_1_ORGANIZACION.

966JVM/139clases,0fallos/errores/omitidas;36nuevas. Primera completa963/1fallo por
índice de menú alterado: corregida producción, pruebas anteriores intactas;3casos
extras de recuperación y dirigida44/44, completa final966/966. Lint0errores/70avisos
sin incremento.58Android compiladas/0ejecutadas;2nuevas proveedor/ContentResolver y
XML cuando se ejecuten, no autorización persistente real. Sin dispositivo/cuentas/
CDNs/medios privados ni operaciones sobre archivos personales desde este entorno.

Firma original/v2/zipalign16KiB, versión42/0.42.0. Room13/esquemas/LibraryDatabase/
BackupStore/copia18lee1–18/permisos/runtimegraph356/assets/4.so conservados.
Una actividad interna adicional,0clases previas eliminadas (343→357).
Entregar APK, ZIP pequeño APK idéntico, proyecto/pruebas/guía. Nunca incluir clave.
Tras prueba de parte1 y correcciones necesarias, seguir parte2. Proyecto ABIERTO.
'''
p=R/'docs/PLAN_FUENTES.md';s=p.read_text();marker='## Entrega agrupada 0.42: parte 1 de 6, organización de archivos'
if marker not in s:p.write_text(s+plan)
shutil.copy2(p,D/'PLAN_FUENTES.md')
