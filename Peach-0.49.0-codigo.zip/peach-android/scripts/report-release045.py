#!/usr/bin/env python3
from pathlib import Path
import argparse,json,shutil
p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args();R=Path(__file__).resolve().parents[1];D=Path(a.out);v=json.loads((D/'Peach-Local-verificacion-0.45.0.json').read_text())
s=f'''# Peach Local0.45.0 · Parte4de6

29 de octubre de2026, America/Hermosillo. SM-X230. El usuario confirmó «Todo funciona»
para0.44/parte3 y autorizó continuar. Se entrega parte4 agrupada para prueba; no se
presume aceptación nueva ni ejecución física propia. Después de corregir/aceptar,
seguir parte5interfaz/rendimiento y parte6validación/correcciones. Proyecto abierto.

## Resultado

Menú Importación y sincronización: formatoportable1 con estado19/inventario relativo/
metadatos/NFO/addedAt. Tokens opacos en referencias tipadas, mapa explícito de raíces/
ruta/tamaño/familia o vínculo individual; no prueba de identidad por bytes. Las
carpetas necesitan escaneo completo; duplicados o vínculos ambiguos no se eligen.
Lo no vinculado permanece en el paquete. Se protegen miembros de listas, relaciones
y bindings de catálogos existentes que carecen de correspondencia remota completa.

Comparación3way por campo usando versión local/entrante/última importada de ese origen.
Primera diferencia existente es conflicto/local por defecto; nuevas filas compatibles
son propuestas. Progreso AV/lectura, visitas, catálogos y conjuntos ordenados se eligen
como unidades. No sumar contadores, borrar por ausencia o inventar un medio disponible.
Valida esquema/tipos/UTF8/profundidad/cuotas y relaciones en Room separado antes de
transacción. Origen y contador monótono persistidos independientemente del reloj:
rechaza versiones anteriores, mismo número con otro contenido y revisión con base/
documento/biblioteca/inventario/URI/escaneo cambiados. Mutex de commits en el proceso.
SHA canónico detecta cambios; no autentica al autor o un contador fabricado.

Exportar prepara antes del selector, crea nueva versión SAF, escribe/cierra/relee antes
de anunciar éxito y retira solo el destino nuevo fallido cuando puede. El documento
anterior nunca se sobreescribe. Importar relee el elegido antes de aplicar. Nube solo
si un proveedor Android instalado/autorizado la ofrece; sin cliente/API propio de115,
PikPak/OneDrive/Drive/CloudDrive/OpenList, agenda o segundo plano de sincronización.
No servidor, PC o Termux. Proveedor cloud real/consistencia entre nodos no comprobados.

Diario AtomicFile privado antes de terminar commit; Deshacer exacto si no hay cambios
posteriores, retira nuevas filas de la importación/restaura anteriores sin tocar archivos,
cuentas o permisos. No-op conserva la recuperación útil. Room/archivos no son transacción
distribuida: si falla guardar base después del commit, informa datos aplicados y mantiene
Deshacer; no anuncia rollback inexistente. Cuatro bases, estado8MiB/paquete16MiB/diario64MiB,
50.000medios/1.000raíces/180.000filas/20.000cambios/depth40 y revisión paginada100.
Son cuotas de datos, no RAM total o plazo absoluto de ContentProvider. Paquetes demasiado
grandes se rechazan; división/selección de bibliotecas grandes no incluida.

No medios, credenciales/vault, permisos, colas/descargas, papelera, diarios físicos o
preferencias de dispositivo en paquete. JSON sin cifrar puede contener notas, historial,
cuerpos y enlaces personales. No retorno universal del ledger original. Copias clásicas
v1–19 y catálogo SQLite/JSON previo siguen disponibles sin alterar sus contratos.
Alcance exhaustivo y límites en PARTE_4_INTERCAMBIO.md/GUIA_PARTE_4_045.md.

## Verificación medida

{v['unit']['tests']}pruebas JVM/Robolectric/{v['unit']['classes']}clases,0fallos/errores/
omitidas. Conserva1052 previas y añade48: Exchange450Test20, ExchangeGraph450Test19 y
ExchangeUi450Test9. Datos propios en dos bases Room y contextos separados, no prueba de
red entre dos tablets. Cubren exportación sin credenciales/grants, tipos/SHA/Unicode,
mapas ambiguos/duplicados/familias, grafos/listas/lectura/addedAt/historial, primeras
resoluciones y3way bidireccional, idempotencia, no bajas remotas, bases/versiones/forks,
estado obsoleto, fallo de diario/rollback, Undo exacto/obsoleto, fuente sin cambio de
revisión, datos no vinculados y bindings protegidos. UI real de actividad/controlador:
selectores, elección por raíz, revisión/apply/rotación, solo lectura explícita,
documento cambiado, guardado/readback/limpieza de URI nueva, y todas las páginas de una
revisión220cambios (100/100/20). Proveedor simulado propio, no nube real.

Historial conservado: compile inicial de helpers tuvo accesos directos a campos de otro
record, variable lambda repetida y constructor ViewModel que se dejó público. Dirigida
20/20,29/29. Primera UI37/2: await de test se adelantaba al Handler del diálogo y hacía
suposición de carpeta limpia; corregido drenaje del Handler e aislamiento de fixtures,
sin eliminar guardas. Segunda37/8 por limpieza de ruta aún inexistente; guardada su
existencia. Tercera39/1 por ruta retenida en factory AndroidViewModel de Robolectric;
se limpió el directorio del modelo real del test, no una ruta asumida;39/39. Paginación
9/1 usaba getListView de un diálogo cuyo ListView está dentro de setView: test ahora
busca la vista real y mantiene las mismas aserciones de páginas completas.

Primera full1093/1 únicamente por ejemplo generado con Python frente a escaping de
slash de JSONObject.quote. Se implementó serialización canónica propia estable y se
añadió regresión con slash/acentos/emoji/controles; no se debilitó SHA. Se incorporaron
secuencias persistidas y guards de fork/base/replay, dirigida46/46. Full1099/0 y después
fallo al compilar prueba Android por importBundle faltante, corregido y ensamblado
aprobado. La revisión final añadió protección de bindings de catálogos sin mapa y un
caso completo nuevo; última suite{v['unit']['tests']}/0, lint y ambos APK aprobados.
Los logs y XML previos/finales distinguen errores de fixtures, producción y límites;
no se quitaron pruebas para aprobar.

Lint0errores/{v['lint']['warnings']}avisos. Delta contra0.44:3GradleDependency del chequeo
de versiones y4SetTextI18n. El grafo runtime{v['runtime_dependency_graph_lines']}líneas
es idéntico; no se actualizaron librerías para silenciar avisos ni añadieron supresiones.
{v['instrumentation']['compiled']}tests Android compilados,0ejecutados. Tres nuevos para
Room/mapeo/Undo en datos propios, ContentResolver real con documento desechable de un
proveedor solo del APKtest y JSON/ejemplo/corrupción. No adbdevice/KVM, instalación,
permisos SAF reales, muerte de proceso, batería, proveedor cloud, cuenta o datos privados
comprobados. Instrumentación compilada no se presenta como validación física.

## Conservación y artefactos

Todos los archivos de producción previos salvo MainActivity son byteidénticos a0.44;
Main añade menú21 y actualiza diagnóstico obsoleto. Recursos, Room13/esquemas/DAO,
BackupStore/copia19/lectura1–19, dependencias/assets y4.so idénticos. Fuentes/cuentas/
descargas/lectores/organización conservados. Único componente nuevo: ExchangeActivity
interno/noexportado, sin permisos/servicios/proveedores nuevos en principal. El
proveedor de prueba no está en APK principal. DEXPeach {v['peach_classes']['before']}→
{v['peach_classes']['after']}, {v['peach_classes']['added']}clases añadidas,0eliminadas.
Firmaoriginal/v2 y alineación16KiB verificadas; version45/0.45.0,min26,target36.
CertSHA256 {v['signature_certificate_sha256']}.
APK {v['apk']['bytes']}bytes; SHA256 {v['apk']['sha256']}.

EntregarAPK/ZIPidéntico, guía/ejemplo propio y proyecto/historia/pruebas/evidencia/APKtest.
Nunca firma privada. Instalar sobre0.44 sin desinstalar/borrar datos. Partes5–6 pendientes.
'''
old=R/'docs/PRUEBAS_0_44.md'
if not old.exists():shutil.copy2(R/'docs/PRUEBAS.md',old)
(R/'docs/PRUEBAS.md').write_text(s);(D/'Peach-Local-informe-0.45.0.md').write_text(s)
for src,dst in [('GUIA_PARTE_4_045.md','guia-parte-4'),('PARTE_4_INTERCAMBIO.md','importacion-y-sincronizacion'),('PENDIENTES.md','pendientes'),('COMPATIBILIDAD_ORIGINAL.md','compatibilidad-original')]:shutil.copy2(R/'docs'/src,D/f'Peach-Local-{dst}-0.45.0.md')
shutil.copy2(R/'docs/PLAN_FUENTES.md',D/'PLAN_FUENTES.md')
(R/'docs/evidence/0.45.0/DEVELOPMENT.md').write_text(s)
