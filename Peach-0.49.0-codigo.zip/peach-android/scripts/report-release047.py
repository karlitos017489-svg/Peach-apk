#!/usr/bin/env python3
"""Prepare release documents exclusively from completed measurements."""
from pathlib import Path
import argparse,json,shutil
p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args();R=Path(__file__).resolve().parents[1];D=Path(a.out);docs=R/'docs';v=json.loads((D/'Peach-Local-verificacion-0.47.0.json').read_text());n=v['instrumentation'];u=v['unit'];warn=v['lint']['warnings'];assert not (u['failures'] or u['errors'] or n['failures'] or n['errors'])
skipped=[c['class'].split('.')[-1]+'#'+c['test'] for c in n['attempts'][-1]['cases'] if c['code'] in (-3,-4)]
brief=f"{u['tests']} JVM/Robolectric en {u['classes']} clases, 0 fallos/errores/omitidas. Android: {n['compiled']} compiladas, {n['executed']} ejecutadas y {n['passed']} aprobadas, {n['skipped']} omitida(s), 0 fallos/errores; los {n['completed_cases']} casos terminaron."
limits='Emulador oficial Android 9/API28 x86_64 por software, sin KVM. No Samsung/ARM64, Drive/cuentas reales, batería o salida física certificadas. Android16/API36 se intentó sin completar arranque; no se ejecutaron tests allí.'
scope='''# Parte 6 de 6 · Validación y correcciones · 0.47.0

29 de octubre de 2026, America/Hermosillo. El usuario aceptó 0.46 / parte 5 y autorizó
continuar. 0.47 se entrega para prueba; todavía no está aceptada en la tablet.

Fondos: AtomicFile recupera escrituras interrumpidas, retirada completa de auxiliares,
revisión independiente de tamaño/fecha y recorte centrado que preserva proporciones.
Volumen: diálogo retirado antes de liberar reproductor/controlador al salir. Un segundo
destino directo rechazado se limpia fuera de la UI, sin liberar la transferencia activa.

RAR: se elimina la recursión entre TLS emulado y asignador limitado, usando claves
pthread de libc. Cuatro ABI reconstruidas con NDKr30/API26, fuente libarchive3.8.10,
cuotas/CRC/tiempos/descriptor-only IPC y servicio aislado conservados. ZIP/ZIP64 usa
Commons Compress ya dependiente para evitar el fallo de offsets de ZipFile en Android
antiguo; preflight ZipDirectory, cuotas, nombres, métodos y CRC se conservan.

Ajustes y menú de Biblioteca → Comprobar funcionamiento. Abrir solo consulta el último
informe propio. Iniciar ejecuta ocho muestras propias: firma/versión, archivos privados,
Room temporal/copia/intercambio, PNG, PDF, una salida H.264, una salida AAC y RAR5 sólido.
No lee tu biblioteca/archivos personales ni cuentas/red/fuentes/nube; no emite sonido.
Rotar conserva la operación; salir cancela. Cancelar deja resultado parcial. Timeout
queda No comprobado, nunca Correcto. Los bloqueos nativos/proveedor no tienen garantía
de plazo absoluto; RAR conserva watchdog anterior. MediaCodec usa buffers sin superficie
ni AudioTrack; no certifica salida física, todos los códecs/perfiles o reproducción completa.

Informe privado AtomicFile, exportación explícita a nuevo documento con relectura.
Fallo retira solo el nuevo destino cuando puede y conserva el informe local. Incluye
app/modelo/Android/ABI/tiempos/resultados; no títulos/rutas personales, credenciales,
seriales o cuentas. No envío automático. Solo probes de tests marcan testProbesInjected;
la app normal y las pruebas nativas usan motores reales.

La suite histórica de instrumentación usa la base principal de su perfil de pruebas.
Su APK es exclusivamente para emulador/perfil desechable. La comprobación del APK normal
usa una Room temporal aislada y sí está diseñada para la instalación del usuario.
'''
scope+='\n## Resultados\n\n'+brief+'\n\n'+limits+'\n\n'
scope+='Se verificó actualización firmada 0.46→0.47 con1105 medios propios y favorito/progreso\ncomprobados antes. DB/WAL/SHM y preferencias de apariencia conservaron SHA256 exactos.\nEsto no certifica permisos externos SAF, cuentas reales o KeyStore durante actualización.\nSigue GUIA_PARTE_6_047.md en la tablet. La sexta entrega no cierra incompatibilidades\nanteriores o paridad universal. Nueve fuentes; Kemono/Coomer/SimpCity excluidos.\n'
(docs/'PARTE_6_VALIDACION.md').write_text(scope)
p=docs/'PLAN_FUENTES.md';plan=p.read_text();marker='0.47 sigue en validación, no entregada ni aceptada.';idx=plan.index(marker);plan=plan[:idx]+f'''0.47 entrega parte 6 para prueba, todavía no aceptada por el usuario.
{brief}
Lint 0 errores/{warn} avisos. Firma original/v2/zipalign16KiB, min26/target36.
{limits}
Actualización del APK final046→047 conservó DB/WAL/SHM y preferencias por SHA256 exacto,
con1105medios propios y favorito/progreso verificados antes. No certifica grants SAF
externos, KeyStore durante actualización, cuentas privadas o proveedor Drive real.

RAR corregido: claves pthread evitan TLS recursivo, cuatro ABI reconstruidas, mismas
cuotas/CRC/aislamiento y libarchive3.8.10. ZIP64 usa Commons ya dependiente, mismos
preflight/límites/nombres/métodos/CRC. Fondo atómico/recorte, cierre de volumen y limpieza
fuera de UI del segundo destino rechazado. Comprobación manual de ocho muestras propias,
Room aislada, informe privado/exportable sin cuentas/red/archivos personales o sonido.

Fixtures Android protegidos MANAGE_DOCUMENTS, runner obtiene solo grants del proveedor
propio. Historial usa lectura de streams compatible API28; audio compara posición ya
pausada/estable y UI espera datos, conservando asserts. Fallos iniciales/evidencia en
PRUEBAS y docs/evidence/0.47.0. No se quitaron casos ni se rebajaron controles.
El entorno se interrumpió antes del primer cierre; se recuperó checkpoint y se repitió
suite completa con el APK actual. La instrumentación se ejecutó en perfil desechable;
su APK histórico usa la base principal de ese perfil. El diagnóstico normal es aislado.

Room13/DAO/copia19/intercambio1/transporte/grafo356/permisos/assets previos intactos.
Tres assets propios añadidos y una actividad interna no exportada. Nueve fuentes;
Kemono/Coomer/SimpCity excluidos. Guia GUIA_PARTE_6_047.md, alcance PARTE_6_VALIDACION.md.
Se llega a la sexta entrega acordada; faltan aceptación física, correcciones que aparezcan
y los pendientes originales documentados. No afirmar paridad universal o cierre definitivo.
''';p.write_text(plan)
p=docs/'PENDIENTES.md';s=p.read_text().replace('La instrumentación compilada y lo ejecutado se detallan por separado en PRUEBAS.md.','Se ejecutaron los 73 casos en API28/x86_64: '+str(n['passed'])+' aprobados y '+str(n['skipped'])+' omitido(s) por API; detalle en PRUEBAS.md.');s=s.replace('fondos atómicos y recorte proporcionado, cierre de volumen, limpieza de segundo destino fuera de UI;','RAR nativo y ZIP64 corregidos, fondos atómicos y recorte proporcionado, cierre de volumen, limpieza de segundo destino fuera de UI;');p.write_text(s)
p=R/'README.md';s=p.read_text().replace('Esta entrega corrige fondos interrumpidos y proporciones, cierre del volumen al salir','Esta entrega corrige RAR comprimido y ZIP64 en Android, fondos interrumpidos y proporciones, cierre del volumen al salir');s=s.replace('La sexta entrega requiere validación en la tablet; añadir diagnósticos o compilar\ninstrumentación no certifica paridad universal, cuentas reales o nube.','La sexta entrega requiere validación en la tablet. '+brief+'\nLa emulación y sus muestras no certifican paridad universal, cuentas reales o nube.');p.write_text(s)
p=docs/'COMPATIBILIDAD_ORIGINAL.md';s=p.read_text().replace('ejecución\nde instrumentación o ABI Android real desde este entorno.','ejecución universal en todas las ABI. En 0.47 sí se ejecutó instrumentación\nAndroid API28/x86_64; las otras ABI solo se compilaron.');s+='\n0.47 corrige ejecución del asignador RAR en ABI Android y lectura ZIP64 mediante\nCommons ya dependiente; se conservan límites de admisión y fuente libarchive.\n'+brief+'\n'+limits+'\n';p.write_text(s)
report=f'''# Peach Local 0.47.0 · Parte 6 de 6

29 de octubre de 2026, America/Hermosillo. Base0.46/parte5 aceptada por el usuario;
0.47 para prueba. Instalar encima sin desinstalar ni borrar datos.

## Resultado

{brief}
Se conservan los 1132 casos anteriores y se añaden20: Validation4709, Lifecycle4706,
CheckUi4704 y Native4701. Lint0 errores/{warn} avisos; delta frente a0.46:
{json.dumps(v['lint']['added_categories'],ensure_ascii=False)}. Sin nuevas supresiones.

Omisiones Android: {', '.join(skipped) if skipped else 'ninguna'}.
El PDF con búsqueda/clave API35+ debe comprobarse en la tablet; el PDF de muestra normal
sí se creó/renderizó en la comprobación nativa. {limits}
El APK final probado coincide por SHA con el que se entrega. La suite histórica usa
solo un perfil desechable; el diagnóstico normal usa base temporal aislada.

Actualización real de paquete0.46→0.47 en el emulador:1105medios propios, favorito/progreso
verificados antes, DB/WAL/SHM y preferencias de apariencia idénticos por SHA256 después.
No equivale a actualización Samsung, permisos SAF externos, KeyStore de cuentas durante
actualización o Drive real. Las pruebas de cuentas usan sesiones falsas/claves propias.

## Cambios

Ver PARTE_6_VALIDACION.md. Recuperación/retirada atómica del fondo y recorte proporcionado;
diálogo de volumen antes de liberar motor; limpieza del segundo destino fuera de UI.
RAR elimina recursión de TLS emulado mediante claves pthread de libc, sin cambiar
libarchive3.8.10, cuotas160MiB/asignación64MiB, CRC, límite85s/cliente90s o aislamiento.
Cuatro ABI API26 reconstruidas con mismo NDKr30 y alineación16KiB; ejecución medida x86_64.
ZIP64 evita fallo de offsets de ZipFile Android usando Commons ya dependiente; mantiene
ZipDirectory, cuotas de índice/entradas, nombres, Store/Deflate y verificación CRC.

Ocho checks manuales de muestras propias; no red/cuentas/archivos del usuario/sonido.
Room de prueba aislada. Cancelar/salir dejan parcial, rotar conserva, timeout no aprueba.
Una salida de codec a buffer no equivale a pantalla/altavoz o todos los perfiles.
Informe privado AtomicFile, exportación JSON explícita con relectura y limpieza solo
del destino nuevo fallido. Modelo/Android/ABI, sin secretos/títulos/seriales; sin envío.

## Fallos y correcciones durante desarrollo

Compile inicial: RoomDatabase/PdfDocument no AutoCloseable, cierre finally. Dirigida37/2:
MIME JSON explícito y prueba Room en trabajador como producción, misma aserción de datos
intactos. Luego37/37. Instrumentación inicial se cerró por proveedores de fixtures sin
MANAGE_DOCUMENTS; se corrige protección y bootstrap de grants desde su APK propietario,
sin ampliar permisos de la app. Prueba RAR real reveló SIGSEGV: __emutls_get_address y
malloc limitado recursivos. Se corrige TLS y se reconstruyen cuatro ABI. Test JNI nuevo
concurrente: una cuota1MiB falla, otra160MiB produce bytes exactos, ocho rondas con hilos
reutilizados y ausencia de fugas. Primer fixture de éxito usaba<1MiB; se usa el grande
en ambos lados manteniendo la aserción>1MiB. Dirigida nativa15/1→15/15; cuatro Android
nuevas y ocho componentes aprobados tras corregir el motor.

Suite Android73 inicial: tres fallos y una omisión. ZIP64 se corrige en producción;
fixture de historial evita InputStream.readAllBytes inexistente en API28. Audio mide
posición estable no nula tras pausa asíncrona antes de recrear, con las mismas aserciones
de pausa/no reinicio/continuidad/ausencia de error y sin tolerancia numérica. Los tres
casos afectados pasaron. Suites JVM detectaron esperas insuficientes en Organization y
LibraryUi: se esperan los datos del adaptador con plazo10s, se conservan asserts exactos.
El entorno cayó antes del cierre anterior. Recuperado desde checkpoint; reconstrucción
inicial falló por faltar lanzador jlink del JRE, restaurado junto a herramientas JDK.
Después se repitieron suites completas. Evidencia inicial/final/XML/logs conservada;
no se quitaron casos, bajaron aserciones o suprimió lint para aprobar.

## Conservación y entrega

Room13/esquemas/DAO, BackupStore19/lecturas1–19, PortableState/Exchange1 y SourceHttp
byteidénticos. Grafo runtime {v['runtime_dependency_graph_lines']} líneas idéntico. Assets
anteriores intactos; tres muestras diagnósticas propias nuevas con manifiesto SHA.
Ocho Java anteriores modificados, C de asignador y cuatro.so corregidos. ZipDirectory,
ArchiveFiles y DocumentRules sin cambios. Permisos iguales; una actividad interna no
exportada, sin servicios/proveedores principales nuevos. DEX Peach
{v['peach_classes']['before']}→{v['peach_classes']['after']}, ninguna clase anterior eliminada.
Firma original/v2, zipalign16KiB, min26/target36. Certificado SHA256:
{v['signature_certificate_sha256']}.
APK {v['apk']['bytes']}bytes; SHA256 {v['apk']['sha256']}.

Se entregan APK, ZIP con el mismo APK, guía, alcance, informe/verificación y proyecto
completo con bundle/evidencia/APK de instrumentación. Nunca clave privada. Seguir guía
para actualización, datos, fondo, volumen, diagnóstico y usos anteriores en SM-X230.
Drive/proveedor y salida física se validan allí. Proyecto abierto a correcciones y
pendientes originales; no paridad universal. Nueve fuentes, exclusiones vigentes.
'''
(docs/'PRUEBAS.md').write_text(report);(D/'Peach-Local-informe-0.47.0.md').write_text(report)
for src,dst in [('GUIA_PARTE_6_047.md','Peach-Local-guia-parte-6-0.47.0.md'),('PARTE_6_VALIDACION.md','Peach-Local-alcance-parte-6-0.47.0.md'),('PENDIENTES.md','Peach-Local-pendientes-0.47.0.md'),('COMPATIBILIDAD_ORIGINAL.md','Peach-Local-compatibilidad-original-0.47.0.md'),('PLAN_FUENTES.md','PLAN_FUENTES.md')]:shutil.copy2(docs/src,D/dst)
