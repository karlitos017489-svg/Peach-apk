#!/usr/bin/env python3
"""Reproduce the screenshot error with baseline production source and simulated HTTPS."""
from pathlib import Path
import hashlib,json,os,subprocess,tempfile
root=Path(__file__).resolve().parents[1];baseline='c7acd7577c739418e158c1cd91e1983449fd810d'
names=['SourceHttp','PawchiveUrls','CumstUrls','WebSourceUrls','SubscribeStarUrls','PatreonUrls','SourceCredentials']
jdk=Path(os.environ['JAVA_HOME'])/'bin';hashes={}
with tempfile.TemporaryDirectory(prefix='peach-028-repro-') as temp:
 temp=Path(temp);sources=[]
 for name in names:
  ref='app/src/main/java/com/peach/local/'+name+'.java';data=subprocess.run(['git','show',baseline+':'+ref],cwd=root,capture_output=True,check=True).stdout
  file=temp/(name+'.java');file.write_bytes(data);sources.append(file);hashes[ref]=hashlib.sha256(data).hexdigest()
 subprocess.run([str(jdk/'javac'),'-d',str(temp),*[str(p) for p in sources],str(root/'scripts/Reproduce028Redirect.java')],check=True)
 output=subprocess.run([str(jdk/'java'),'-cp',str(temp),'com.peach.local.Reproduce028Redirect'],capture_output=True,text=True,check=True)
 result=json.loads(output.stdout);result['baseline_commit']=baseline;result['production_source_sha256']=hashes
 print(json.dumps(result,ensure_ascii=False,indent=2))
