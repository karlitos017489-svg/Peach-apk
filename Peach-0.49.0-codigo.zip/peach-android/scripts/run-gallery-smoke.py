#!/usr/bin/env python3
"""Optional one-body/one-image public contract check; never runs as part of unit tests or APK startup."""
import argparse
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('--json-runtime', type=Path, required=True,
                    help='org.json:json:20240303 JAR from Maven Central; tooling only')
parser.add_argument('--creator', default='official')
parser.add_argument('--post', default='12383501')
args = parser.parse_args()
jar = args.json_runtime.resolve()
expected = '3cf6cd6892e32e2b4c1c39e0f52f5248a2f5b37646fdfbb79a66b46b618414ed'
if hashlib.sha256(jar.read_bytes()).hexdigest() != expected:
    parser.error('The smoke-only JSON runtime checksum differs from the pinned artifact.')
root = Path(__file__).resolve().parents[1]
java_home = os.environ.get('JAVA_HOME')
java = str(Path(java_home) / 'bin/java') if java_home else shutil.which('java')
javac = str(Path(java_home) / 'bin/javac') if java_home else shutil.which('javac')
if not java or not javac:
    parser.error('A complete JDK 17 is required.')
with tempfile.TemporaryDirectory(prefix='peach-fanbox-smoke-') as directory:
    classes = Path(directory)
    sources = [root / 'app/src/main/java/com/peach/local/PatreonUrls.java',
               root / 'app/src/main/java/com/peach/local/SourcePage.java',
               root / 'app/src/main/java/com/peach/local/SourceHttp.java',
               root / 'app/src/main/java/com/peach/local/MediaRedirects.java',
               root / 'app/src/main/java/com/peach/local/WebSourceUrls.java',
               root / 'app/src/main/java/com/peach/local/SourceCredentials.java',
               root / 'app/src/main/java/com/peach/local/CumstUrls.java',
               root / 'app/src/main/java/com/peach/local/PawchiveUrls.java',
               root / 'app/src/main/java/com/peach/local/SubscribeStarUrls.java',
               root / 'app/src/main/java/com/peach/local/FanboxConnector.java',
               root / 'scripts/GalleryLiveSmoke.java']
    subprocess.run([javac, '-cp', str(jar), '-d', str(classes), *map(str, sources)], check=True)
    command = [java, '-Dsun.net.http.allowRestrictedHeaders=true']
    if os.environ.get('PEACH_JAVA_TRUST_STORE'):
        command += ['-Djavax.net.ssl.trustStore=' + os.environ['PEACH_JAVA_TRUST_STORE']]
    command += ['-cp', str(classes) + os.pathsep + str(jar),
                'com.peach.local.GalleryLiveSmoke', args.creator, args.post]
    subprocess.run(command, check=True)
