#!/usr/bin/env python3
"""Run the pinned wrapper; use the current network proxy if the host supplies one.

No proxy values or credentials are written to project files or logs.
"""
import os
from pathlib import Path
import subprocess
import sys
import shlex
from urllib.parse import urlparse

root = Path(__file__).resolve().parents[1]
command = [str(root / "gradlew"), "--no-daemon", *sys.argv[1:]]
properties = []
proxy = urlparse(os.environ.get("HTTPS_PROXY", ""))
if proxy.hostname and proxy.port:
    properties.extend([f"-Dhttps.proxyHost={proxy.hostname}", f"-Dhttps.proxyPort={proxy.port}",
                    f"-Dhttp.proxyHost={proxy.hostname}", f"-Dhttp.proxyPort={proxy.port}",
                    "-Dhttp.nonProxyHosts=localhost|127.*"])
if os.environ.get("PEACH_JAVA_TRUST_STORE"):
    properties.append("-Djavax.net.ssl.trustStore=" + os.environ["PEACH_JAVA_TRUST_STORE"])
environment = os.environ.copy()
environment["GRADLE_OPTS"] = environment.get("GRADLE_OPTS", "") + " " + shlex.join(properties)
sys.exit(subprocess.call(command + properties, cwd=root, env=environment))
