#!/usr/bin/env python3
"""Opt-in check of the public SubscribeStar card adapter. No account, private API or JavaScript."""
import argparse
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('--json-runtime', type=Path, required=True)
parser.add_argument('--html-runtime', type=Path, required=True)
parser.add_argument('--creator', default='ribalinux')
args = parser.parse_args()
artifacts = [(args.json_runtime.resolve(), '3cf6cd6892e32e2b4c1c39e0f52f5248a2f5b37646fdfbb79a66b46b618414ed'),
             (args.html_runtime.resolve(), 'e9d8c856856680427f096d156f02a414289985c930998fcb519ce5be39b42003')]
for path, digest in artifacts:
    if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        parser.error('Runtime artifact checksum differs from the pinned artifact.')
root = Path(__file__).resolve().parents[1]
home = os.environ.get('JAVA_HOME')
java = str(Path(home) / 'bin/java') if home else shutil.which('java')
javac = str(Path(home) / 'bin/javac') if home else shutil.which('javac')
if not java or not javac:
    parser.error('A complete JDK17 is required.')
with tempfile.TemporaryDirectory(prefix='peach-subscribestar-smoke-') as directory:
    classes = Path(directory)
    classpath = os.pathsep.join(str(path) for path, _ in artifacts)
    base = root / 'app/src/main/java/com/peach/local'
    sources = [base / (name + '.java') for name in ['SourceHttp', 'WebSourceUrls', 'SourceCredentials', 'CumstUrls', 'PawchiveUrls', 'PatreonUrls', 'SubscribeStarUrls', 'SourcePage', 'FanboxConnector', 'SubscribeStarConnector']]
    sources.append(root / 'scripts/SubscribeStarLiveSmoke.java')
    subprocess.run([javac, '-cp', classpath, '-d', str(classes), *map(str, sources)], check=True)
    command = [java]
    if os.environ.get('PEACH_JAVA_TRUST_STORE'):
        command.append('-Djavax.net.ssl.trustStore=' + os.environ['PEACH_JAVA_TRUST_STORE'])
    command += ['-cp', str(classes) + os.pathsep + classpath, 'com.peach.local.SubscribeStarLiveSmoke', args.creator]
    subprocess.run(command, check=True)
