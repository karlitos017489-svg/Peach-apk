#!/usr/bin/env python3
"""Verify a completed 0.32 build; no device execution or network claims."""
from pathlib import Path
import argparse,collections,hashlib,json,re,shutil,struct,subprocess,xml.etree.ElementTree as E,zipfile
p=argparse.ArgumentParser();p.add_argument('--build-root',required=True);p.add_argument('--baseline-apk',required=True);p.add_argument('--tools',required=True);p.add_argument('--log',required=True);p.add_argument('--out',required=True);args=p.parse_args()
R=Path(__file__).resolve().parents[1];B=Path(args.build_root)/'app';D=Path(args.out);D.mkdir(parents=True,exist_ok=True);V=R/'docs/evidence/0.32.0';V.mkdir(parents=True,exist_ok=True);tools=Path(args.tools)
def run(a):return subprocess.run([str(x) for x in a],capture_output=True,text=True,check=True).stdout
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
suites=[E.parse(p).getroot() for p in (B/'test-results/testDebugUnitTest').glob('TEST-*.xml')]
counts={k:sum(int(s.attrib.get(k,0)) for s in suites) for k in ('tests','failures','errors','skipped')}
assert counts['tests']>=706 and not sum(counts[k] for k in ('failures','errors','skipped')),counts
for f in (B/'test-results/testDebugUnitTest').glob('TEST-*.xml'):
 text=f.read_text();assert 'A resource was acquired at attached stack trace but never released' not in text,f
 assert 'NoSuchMethodError' not in text and 'SQLiteException' not in text,f
assert 'BUILD SUCCESSFUL' in Path(args.log).read_text()
issues=list(E.parse(B/'reports/lint-results-debug.xml').getroot().findall('issue'));assert not [i for i in issues if i.attrib['severity'] in ('Error','Fatal')]
for p in (B/'test-results/testDebugUnitTest').glob('TEST-*.xml'):
 t=V/'unit-results'/p.name;t.parent.mkdir(exist_ok=True);shutil.copy2(p,t)
for n in ['lint-results-debug.xml','lint-results-debug.txt','lint-results-debug.html']:
 if (B/'reports'/n).exists():shutil.copy2(B/'reports'/n,V/n)
shutil.copy2(args.log,V/'gradle-final.log')
apk=D/'Peach-Local-0.32.0-debug.apk';testapk=D/'Peach-Local-0.32.0-androidTest.apk'
shutil.copy2(B/'outputs/apk/debug/app-debug.apk',apk);shutil.copy2(B/'outputs/apk/androidTest/debug/app-debug-androidTest.apk',testapk)
sign=run([tools/'apksigner','verify','--verbose','--print-certs',apk]);assert '9fc537c4c8d0461a8565414c7a30169e592120cd314b500bee7c707f8a748484' in sign
assert 'Verified using v2 scheme (APK Signature Scheme v2): true' in sign
align=run([tools/'zipalign','-c','-P','16','-v','4',apk]);assert 'Verification suc' in align
badging=run([tools/'aapt','dump','badging',apk]);assert "versionCode='32'" in badging and "versionName='0.32.0'" in badging
assert "sdkVersion:'26'" in badging and "targetSdkVersion:'36'" in badging
testsign=run([tools/'apksigner','verify','--verbose','--print-certs',testapk]);assert '9fc537c4c8d0461a8565414c7a30169e592120cd314b500bee7c707f8a748484' in testsign
assert 'Verified using v2 scheme (APK Signature Scheme v2): true' in testsign
permissions=run([tools/'aapt','dump','permissions',apk]);assert permissions==run([tools/'aapt','dump','permissions',args.baseline_apk])
def classes(z):
 out=set()
 for n in z.namelist():
  if not re.fullmatch(r'classes\d*\.dex',n):continue
  b=z.read(n);sn,so=struct.unpack_from('<II',b,56);tn,to=struct.unpack_from('<II',b,64);cn,co=struct.unpack_from('<II',b,96)
  def string(i):
   o=struct.unpack_from('<I',b,so+i*4)[0]
   while b[o]&128:o+=1
   o+=1;return b[o:b.index(0,o)].decode('utf8',errors='replace')
  for j in range(cn):
   ti=struct.unpack_from('<I',b,co+j*32)[0];s=string(struct.unpack_from('<I',b,to+ti*4)[0])
   if s.startswith('Lcom/peach/local/') and '$$' not in s:out.add(s)
 return out
with zipfile.ZipFile(apk) as z,zipfile.ZipFile(args.baseline_apk) as old:
 assert z.testzip() is None
 for n in old.namelist():
  if n.startswith(('assets/','lib/')):assert z.read(n)==old.read(n),n
 prior,current=classes(old),classes(z);assert not prior-current,prior-current
 assert not any(n.endswith(('own-animated.gif','own-animated.webp','sample.mp4')) for n in z.namelist())
for f in (R/'app/schemas').rglob('*.json'):
 old=subprocess.run(['git','show','00addf7c7e32c5ae83c405ef0fead2b17744e007:'+str(f.relative_to(R))],cwd=R,capture_output=True,check=True).stdout;assert f.read_bytes()==old
gradle=subprocess.run(['git','show','00addf7c7e32c5ae83c405ef0fead2b17744e007:app/build.gradle'],cwd=R,capture_output=True,text=True,check=True).stdout
assert (R/'app/build.gradle').read_text()==gradle.replace('versionCode 31','versionCode 32').replace("versionName '0.31.0'","versionName '0.32.0'")
native=sum(len(re.findall(r'@Test\b',f.read_text())) for f in (R/'app/src/androidTest/java').rglob('*.java'));assert native==37,native
v={'version':'0.32.0','date':'2026-10-27','timezone':'America/Hermosillo','baseline':'00addf7c7e32c5ae83c405ef0fead2b17744e007','unit':dict(counts,classes=len(suites)),'lint':{'errors':0,'warnings':len(issues),'categories':dict(collections.Counter(i.attrib['id'] for i in issues))},'instrumentation':{'compiled':native,'executed':0},'room':{'version':13,'schemas_unchanged':True,'schema_sha256':sha(R/'app/schemas/com.peach.local.LibraryDatabase/13.json')},'backup':{'writes':17,'reads':'1–17'},'download_limits':{'legacy_internal_default_bytes':128*1024*1024,'source_ui_bytes':2*1024*1024*1024,'image_gallery_bytes':16*1024*1024,'source_download_deadline_seconds':3600,'free_space_reserve_bytes':64*1024*1024,'unknown_length_free_space_check_every_bytes':8*1024*1024},'gif_decode':{'minimum_animated_api':28,'max_view_edge':1024,'seekable_source':'read-only mapped ByteBuffer','nonseekable_encoded_limit_bytes':64*1024*1024,'descriptors_closed_before_animation':True},'final_unclosed_resource_warning':False,'media_redirect_handoff':{'initial_route_grammar_unchanged':True,'origin':'previously admitted Rule34Video direct file only','targets':'transient public HTTPS; DNS private/reserved rejection','max_redirects':3,'resolved_target_stored':False,'api_other_provider_policies_unchanged':True,'tls_verification_unchanged':True},'permissions_unchanged':True,'runtime_dependencies_unchanged':True,'assets_native_libs_unchanged':True,'peach_classes':{'before':len(prior),'after':len(current),'removed':0},'signature_original':True,'signature_v2':True,'zipalign16k':True,'apk':{'file':apk.name,'bytes':apk.stat().st_size,'sha256':sha(apk)},'test_apk':{'file':testapk.name,'bytes':testapk.stat().st_size,'sha256':sha(testapk)},'intentional_live_source_media_tests':0,'http_image_tests_use_simulated_https':True,'actual_upstream_media_requests':0,'private_user_media_downloaded':False,'user_screenshot_packaged':False,'physical_playback_verified':False,'real_public_download_contract_online_verified':False}
def graph(path):
 text=path.read_text();start=text.index('debugRuntimeClasspath -');end=text.index('\n(c) -',start);return text[start:end].strip()
old_graph=graph(R/'docs/evidence/0.31.0/gradle-dependencies.log');new_graph=graph(V/'gradle-dependencies.log');assert new_graph==old_graph
v['runtime_dependency_graph_lines']=len(new_graph.splitlines())
v['gallery']={'providers':['fanbox','pawchive','cumst','rule34paheal','rule34xxx','f95zone'],'imported_content_only':True,'provider_host_isolation':True,'legacy_false_paw_references_revalidated':True,'paw_expected_sha_checked_online_and_offline':True,'animated_gif_webp_api':28,'api26_still_frame_tested':True,'animation_input':'immutable read-only ByteBuffer with closed file descriptor','max_static_edge':2048,'max_animation_edge':1024,'cache_budget_bytes':64*1024*1024,'cache_max_images':128,'no_prefetch':True,'automatic_catalog_media_or_history_insertions':False}
v['parent_acceptance']={'version':'0.31.0','type':'user reported success and requested block-by-block implementation','not_instrumentation_execution':True}
manifest=run([tools/'aapt','dump','xmltree',apk,'AndroidManifest.xml'])
block=manifest.split('com.peach.local.SourceVideoActivity',1)[1].split('E: activity',1)[0]
assert 'android:exported' in block and ('0x0' in block.split('android:exported',1)[1].split('\n',1)[0])
for component,element in [('DownloadQueueActivity','activity'),('QueueFilesProvider','provider')]:
 block=manifest.split('com.peach.local.'+component,1)[1].split('E: '+element,1)[0]
 assert 'android:exported' in block and '0x0' in block.split('android:exported',1)[1].split('\n',1)[0]
 if element=='provider':assert '0x0' in block.split('android:grantUriPermissions',1)[1].split('\n',1)[0]
(V/'apk-manifest.txt').write_text(manifest)
v['source_video']={'selection':'imported publication ID + validated video attachment','initial_url_contracts_unchanged':True,'complete_private_download_before_playback':True,'streaming_while_downloading':False,'saf_destination_required':False,'cache_completed_budget_bytes':2*1024*1024*1024,'cache_max_completed_files':8,'transfer_limit_reduced_by_pins_and_other_preparations':True,'pinned_files_not_evicted_by_app':True,'cache_disposable_by_android':True,'offline_checks_length_hash_header_and_paw_expected_hash':True,'player_intent':'publication ID + SHA256 URL selection key only','player_reloads_from_room_and_never_downloads':True,'private_local_file_read_via_media3':True,'rotation_pin_retained_in_viewmodel':True,'background_preparation_cancelled':True,'no_automatic_network_at_screen_open_or_player_restore':True,'no_url_or_cdn_target_in_cache_metadata':True,'new_activity_exported':False,'original_activity_unchanged':True,'separate_resumable_batch_queue':True}
v['download_queue']={'max_jobs':128,'max_file_bytes':2*1024**3,'private_budget_bytes':4*1024**3,'concurrent_transfers':1,'foreground_screen_required':True,'leave_screen_pauses':True,'rotation_keeps_same_viewmodel':True,'startup_network':False,'explicit_resume_required':True,'storage':'noBackupFilesDir operational manifest v1 + owned parts/ready files','backup_json_includes_queue':False,'checkpoint_bytes':4*1024**2,'checkpoint_sha_clone_fallback':'periodic checkpoints skipped when digest cloning unavailable; pause/error/completion still checkpoint','prefix_sha_verified_before_resume':True,'resume_requires':'strong ETag + If-Range + final URL fingerprint, or immutable expected Pawchive SHA','resolved_url_stored':False,'range_206_validated':True,'range_ignored_200_replaces':True,'invalid_206_or_416_restarts_once':True,'unknown_total_shows_no_percent':True,'http429_persisted_wait':True,'batch_saf_export_without_redownload':True,'export_checks_length_when_exposed':True,'new_destination_only_cleanup_best_effort':True,'interrupted_export_owned_uri_journal':True,'exported_files_kept_on_private_removal':True,'read_only_internal_provider':True,'provider_exported':False,'uri_grants':False,'removal_blocked_while_descriptor_open':True,'no_new_permission_service_or_dependency':True,'room_unchanged':True,'automatic_catalog_or_history_insertions':False,'actual_source_media_requests':0}
for f in [V/'verification.json',D/'Peach-Local-verificacion-0.32.0.json']:f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
for name,value in [('signature',sign),('alignment',align),('badging',badging),('permissions',permissions)]: (V/('apk-'+name+'.txt')).write_text(value)
(V/'test-apk-signature.txt').write_text(testsign)
print(json.dumps(v,ensure_ascii=False,indent=2))
