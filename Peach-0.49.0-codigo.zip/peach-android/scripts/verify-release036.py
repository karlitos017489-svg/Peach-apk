#!/usr/bin/env python3
"""Verify a completed 0.36 build; no device execution or network claims."""
from pathlib import Path
import argparse,collections,hashlib,json,re,shutil,struct,subprocess,xml.etree.ElementTree as E,zipfile
p=argparse.ArgumentParser();p.add_argument('--build-root',required=True);p.add_argument('--baseline-apk',required=True);p.add_argument('--tools',required=True);p.add_argument('--log',required=True);p.add_argument('--out',required=True);args=p.parse_args()
R=Path(__file__).resolve().parents[1];B=Path(args.build_root)/'app';D=Path(args.out);D.mkdir(parents=True,exist_ok=True);V=R/'docs/evidence/0.36.0';V.mkdir(parents=True,exist_ok=True);tools=Path(args.tools)
def run(a):return subprocess.run([str(x) for x in a],capture_output=True,text=True,check=True).stdout
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
suites=[E.parse(p).getroot() for p in (B/'test-results/testDebugUnitTest').glob('TEST-*.xml')]
counts={k:sum(int(s.attrib.get(k,0)) for s in suites) for k in ('tests','failures','errors','skipped')}
assert counts['tests']>=800 and not sum(counts[k] for k in ('failures','errors','skipped')),counts
for f in (B/'test-results/testDebugUnitTest').glob('TEST-*.xml'):
 text=f.read_text();assert 'A resource was acquired at attached stack trace but never released' not in text,f
 assert 'NoSuchMethodError' not in text and 'SQLiteException' not in text,f
assert 'BUILD SUCCESSFUL' in Path(args.log).read_text()
issues=list(E.parse(B/'reports/lint-results-debug.xml').getroot().findall('issue'));assert not [i for i in issues if i.attrib['severity'] in ('Error','Fatal')]
for p in (B/'test-results/testDebugUnitTest').glob('TEST-*.xml'):
 t=V/'unit-results'/p.name;t.parent.mkdir(exist_ok=True);shutil.copy2(p,t)
for n in ['lint-results-debug.xml','lint-results-debug.txt','lint-results-debug.html']:
 if (B/'reports'/n).exists():shutil.copy2(B/'reports'/n,V/n)
shutil.copy2(args.log,V/'gradle-final.log')
apk=D/'Peach-Local-0.36.0-debug.apk';testapk=D/'Peach-Local-0.36.0-androidTest.apk'
shutil.copy2(B/'outputs/apk/debug/app-debug.apk',apk);shutil.copy2(B/'outputs/apk/androidTest/debug/app-debug-androidTest.apk',testapk)
sign=run([tools/'apksigner','verify','--verbose','--print-certs',apk]);assert '9fc537c4c8d0461a8565414c7a30169e592120cd314b500bee7c707f8a748484' in sign
assert 'Verified using v2 scheme (APK Signature Scheme v2): true' in sign
align=run([tools/'zipalign','-c','-P','16','-v','4',apk]);assert 'Verification suc' in align
badging=run([tools/'aapt','dump','badging',apk]);assert "versionCode='36'" in badging and "versionName='0.36.0'" in badging
assert "sdkVersion:'26'" in badging and "targetSdkVersion:'36'" in badging
testsign=run([tools/'apksigner','verify','--verbose','--print-certs',testapk]);assert '9fc537c4c8d0461a8565414c7a30169e592120cd314b500bee7c707f8a748484' in testsign
assert 'Verified using v2 scheme (APK Signature Scheme v2): true' in testsign
permissions=run([tools/'aapt','dump','permissions',apk]);assert permissions==run([tools/'aapt','dump','permissions',args.baseline_apk])
def classes(z):
 out=set()
 for n in z.namelist():
  if not re.fullmatch(r'classes\d*\.dex',n):continue
  b=z.read(n);sn,so=struct.unpack_from('<II',b,56);tn,to=struct.unpack_from('<II',b,64);cn,co=struct.unpack_from('<II',b,96)
  def string(i):
   o=struct.unpack_from('<I',b,so+i*4)[0]
   while b[o]&128:o+=1
   o+=1;return b[o:b.index(0,o)].decode('utf8',errors='replace')
  for j in range(cn):
   ti=struct.unpack_from('<I',b,co+j*32)[0];s=string(struct.unpack_from('<I',b,to+ti*4)[0])
   if s.startswith('Lcom/peach/local/') and '$$' not in s:out.add(s)
 return out
with zipfile.ZipFile(apk) as z,zipfile.ZipFile(args.baseline_apk) as old:
 assert z.testzip() is None
 for n in old.namelist():
  if n.startswith(('assets/','lib/')):assert z.read(n)==old.read(n),n
 prior,current=classes(old),classes(z);assert not prior-current,prior-current
 assert not any(n.endswith(('own-animated.gif','own-animated.webp','sample.mp4')) for n in z.namelist())
for f in (R/'app/schemas').rglob('*.json'):
 old=subprocess.run(['git','show','d477afb9d5b8ac485abd5896ddc950eaf91a92a4:'+str(f.relative_to(R))],cwd=R,capture_output=True,check=True).stdout;assert f.read_bytes()==old
gradle=subprocess.run(['git','show','d477afb9d5b8ac485abd5896ddc950eaf91a92a4:app/build.gradle'],cwd=R,capture_output=True,text=True,check=True).stdout
assert (R/'app/build.gradle').read_text()==gradle.replace('versionCode 35','versionCode 36').replace("versionName '0.35.0'","versionName '0.36.0'")
native=sum(len(re.findall(r'@Test\b',f.read_text())) for f in (R/'app/src/androidTest/java').rglob('*.java'));assert native==46,native
v={'version':'0.36.0','date':'2026-10-28','timezone':'America/Hermosillo','baseline':'d477afb9d5b8ac485abd5896ddc950eaf91a92a4','unit':dict(counts,classes=len(suites)),'lint':{'errors':0,'warnings':len(issues),'categories':dict(collections.Counter(i.attrib['id'] for i in issues))},'instrumentation':{'compiled':native,'executed':0},'room':{'version':13,'schemas_unchanged':True,'schema_sha256':sha(R/'app/schemas/com.peach.local.LibraryDatabase/13.json')},'backup':{'writes':18,'reads':'1–18'},'download_limits':{'legacy_internal_default_bytes':128*1024*1024,'source_ui_bytes':2*1024*1024*1024,'image_gallery_bytes':16*1024*1024,'source_download_deadline_seconds':3600,'free_space_reserve_bytes':64*1024*1024,'unknown_length_free_space_check_every_bytes':8*1024*1024},'gif_decode':{'minimum_animated_api':28,'max_view_edge':1024,'seekable_source':'read-only mapped ByteBuffer','nonseekable_encoded_limit_bytes':64*1024*1024,'descriptors_closed_before_animation':True},'final_unclosed_resource_warning':False,'media_redirect_handoff':{'initial_route_grammar_unchanged':True,'origin':'previously admitted Rule34Video direct file only','targets':'transient public HTTPS; DNS private/reserved rejection','max_redirects':3,'resolved_target_persisted':False,'session_only_delivery_hint':True,'api_other_provider_policies_unchanged':True,'tls_verification_unchanged':True},'permissions_unchanged':True,'runtime_dependencies_unchanged':True,'assets_native_libs_unchanged':True,'peach_classes':{'before':len(prior),'after':len(current),'removed':0},'signature_original':True,'signature_v2':True,'zipalign16k':True,'apk':{'file':apk.name,'bytes':apk.stat().st_size,'sha256':sha(apk)},'test_apk':{'file':testapk.name,'bytes':testapk.stat().st_size,'sha256':sha(testapk)},'intentional_live_source_media_tests':0,'http_image_tests_use_simulated_https':True,'actual_upstream_media_requests':0,'private_user_media_downloaded':False,'user_screenshot_packaged':False,'physical_playback_verified':False,'real_public_download_contract_online_verified':False}
def graph(path):
 text=path.read_text();start=text.index('debugRuntimeClasspath -');end=text.index('\n(c) -',start);return text[start:end].strip()
old_graph=graph(R/'docs/evidence/0.35.0/gradle-dependencies.log');new_graph=graph(V/'gradle-dependencies.log');assert new_graph==old_graph
v['runtime_dependency_graph_lines']=len(new_graph.splitlines())
v['gallery']={'providers':['fanbox','pawchive','cumst','rule34paheal','rule34xxx','f95zone'],'imported_content_only':True,'provider_host_isolation':True,'legacy_false_paw_references_revalidated':True,'paw_expected_sha_checked_online_and_offline':True,'animated_gif_webp_api':28,'api26_still_frame_tested':True,'animation_input':'immutable read-only ByteBuffer with closed file descriptor','max_static_edge':2048,'max_animation_edge':1024,'cache_budget_bytes':64*1024*1024,'cache_max_images':128,'no_prefetch':True,'automatic_catalog_media_or_history_insertions':False}
v['parent_acceptance']={'version':'0.35.0','type':'user confirmed all functions and requested next block','last_user_accepted_release':'0.35.0','not_instrumentation_execution':True}
manifest=run([tools/'aapt','dump','xmltree',apk,'AndroidManifest.xml'])
block=manifest.split('com.peach.local.SourceVideoActivity',1)[1].split('E: activity',1)[0]
assert 'android:exported' in block and ('0x0' in block.split('android:exported',1)[1].split('\n',1)[0])
for component,element in [('DownloadQueueActivity','activity'),('QueueFilesProvider','provider')]:
 block=manifest.split('com.peach.local.'+component,1)[1].split('E: '+element,1)[0]
 assert 'android:exported' in block and '0x0' in block.split('android:exported',1)[1].split('\n',1)[0]
 if element=='provider':assert '0x0' in block.split('android:grantUriPermissions',1)[1].split('\n',1)[0]
(V/'apk-manifest.txt').write_text(manifest)
v['source_video']={'selection':'imported publication ID + validated video attachment','initial_url_contracts_unchanged':True,'complete_private_download_before_playback':True,'streaming_while_downloading':False,'saf_destination_required':False,'cache_completed_budget_bytes':2*1024*1024*1024,'cache_max_completed_files':8,'transfer_limit_reduced_by_pins_and_other_preparations':True,'pinned_files_not_evicted_by_app':True,'cache_disposable_by_android':True,'offline_checks_length_hash_header_and_paw_expected_hash':True,'player_intent':'publication ID + SHA256 URL selection key only','player_reloads_from_room_and_never_downloads':True,'private_local_file_read_via_media3':True,'rotation_pin_retained_in_viewmodel':True,'background_preparation_cancelled':True,'no_automatic_network_at_screen_open_or_player_restore':True,'no_url_or_cdn_target_in_cache_metadata':True,'new_activity_exported':False,'original_full_preparation_retained':True,'separate_resumable_batch_queue':True}
v['download_queue']={'max_jobs':128,'max_file_bytes':2*1024**3,'private_budget_bytes':4*1024**3,'concurrent_transfers':1,'foreground_screen_required':True,'leave_screen_pauses':True,'rotation_keeps_same_viewmodel':True,'startup_network':False,'explicit_resume_required':True,'storage':'noBackupFilesDir operational manifest v1 + owned parts/ready files','backup_json_includes_queue':False,'checkpoint_bytes':4*1024**2,'checkpoint_sha_clone_fallback':'periodic checkpoints skipped when digest cloning unavailable; pause/error/completion still checkpoint','prefix_sha_verified_before_resume':True,'resume_requires':'strong ETag + If-Range + final URL fingerprint, or immutable expected Pawchive SHA','resolved_url_stored':False,'range_206_validated':True,'range_ignored_200_replaces':True,'invalid_206_or_416_restarts_once':True,'unknown_total_shows_no_percent':True,'http429_persisted_wait':True,'batch_saf_export_without_redownload':True,'export_checks_length_when_exposed':True,'new_destination_only_cleanup_best_effort':True,'interrupted_export_owned_uri_journal':True,'exported_files_kept_on_private_removal':True,'read_only_internal_provider':True,'provider_exported':False,'uri_grants':False,'removal_blocked_while_descriptor_open':True,'no_new_permission_service_or_dependency':True,'room_unchanged':True,'automatic_catalog_or_history_insertions':False,'actual_source_media_requests':0}
old_manifest=subprocess.run(['git','show','d477afb9d5b8ac485abd5896ddc950eaf91a92a4:app/src/main/AndroidManifest.xml'],cwd=R,capture_output=True,text=True,check=True).stdout
assert (R/'app/src/main/AndroidManifest.xml').read_text()==old_manifest.replace('        <activity android:name=".SourceVideoActivity" android:exported="false" />','        <activity android:name=".SourceVideoActivity" android:exported="false" />\n        <activity android:name=".ExternalLinksActivity" android:exported="false" />')
external=manifest.split('com.peach.local.ExternalLinksActivity',1)[1].split('E: activity',1)[0]
assert '0x0' in external.split('android:exported',1)[1].split('\n',1)[0]
old_backup=subprocess.run(['git','show','d477afb9d5b8ac485abd5896ddc950eaf91a92a4:app/src/main/java/com/peach/local/BackupStore.java'],cwd=R,capture_output=True,text=True,check=True).stdout
assert 'number.longValue()>17' in old_backup

v['progressive_streaming']={'implemented':True,'explicit_button':'Ver en línea','entry':'imported video publication ID + selection key only','intent_url_or_path':False,'media3_uri':'opaque peach-stream application URI','source':'ProgressiveMediaSource + bound StreamDataSource + SourceHttp','whole_file_required_before_playback':False,'full_file_or_disk_cache_written':False,'ram_buffer_target_bytes':32*1024*1024,'buffer_target_is_not_total_process_memory_cap':True,'min_max_buffer_ms':[5000,15000],'start_rebuffer_ms':[1000,2000],'resource_limit_bytes':16*1024**3,'old_complete_download_limit_unchanged':True,'header_probe_max_bytes':4096,'restored_seek_header_probe_only':True,'strong_validator_and_range_required_for_seek':True,'paw_immutable_identity_allows_seek':True,'full_sha_before_display_verified':False,'paw_full_sha_before_display_verified':False,'full_download_paw_checks_retained':True,'ignored_range_download_and_skip':False,'changed_representation_or_delivery_fails':True,'416_exact_end_is_eof':True,'416_beyond_end_media3_out_of_range':True,'automatic_load_retries':False,'session_429_wait':True,'stream_stops_on_player_stop':True,'rotation_retains_identity_position_pause':True,'restoration_may_request_network_again':True,'background_video_service_added':False,'no_new_activity_provider_permission_or_dependency':True,'manifest_unchanged':True,'no_catalog_history_insertions':True,'external_url_resolution_or_gofile_added':False,'hls_dash_adaptive_transcoding_added':False,'real_media3_extractor_emits_own_video_samples_before_full_read':True,'real_media3_extractor_indexed_seek_tested':True,'physical_first_frame_latency_verified':False,'actual_upstream_media_requests':0}
v['progressive_integration_fix']={'baseline_stream_data_source_unmodified_during_reproduction':True,'baseline_version':'0.33.0','same_access_message_reproduced_without_upstream_requests':True,'pinned_media3_1_8_bytecode_inspected':True,'actual_progressive_media_period_prepares_and_supplies_video_sample':True,'internally_generated_header_consumed':'Icy-MetaData: 1 only, case-insensitive name','hint_forwarded_to_http':False,'other_caller_http_headers_admitted':False,'opaque_uri_get_body_offset_guards_retained':True,'local_request_failure_reason':'REQUEST, no HTTP status','actual_server_401_403_reason':'ACCESS, sanitized HTTP status retained','auth_cookies_hosts_permissions_or_deps_added':False,'native_tests_added':2,'user_screenshot_or_media_packaged':False,'user_source_cdn_access_verified':False,'physical_playback_verified':False}
v['video_variants']={'declared_quality_only':True,'numeric_p_height_recognized':True,'measured_duration_or_original_completeness':False,'default':'highest declared numeric p in first nonpreview group, declared bytes tie-breaker','manual_selection_retained_on_rotation':True,'preview_labels':True,'cumst_video_alternatives_retained':True,'cumst_locked_variants_omitted':True,'primary_before_extra_budget':100,'rule34xxx_file_url_not_sample_or_preview':True,'metadata_refresh_providers':['rule34video','cumst','rule34paheal'],'metadata_refresh_explicit_review_before_apply':True,'metadata_query_downloads_media':False,'stale_empty_preview_downgrade_rejected':True,'pause_cooldown_cancel_respected':True,'room_schema_or_json_version_changed':False,'optional_attachment_json_roundtrip':True,'upscaling_or_transcoding':False,'player_buffering_and_reported_dimensions':True,'delivery_hint':'session RAM only, cleared on close; fresh DNS/HTTPS validation','cached_delivery_expiry_refresh_http':[403,404,410],'cached_delivery_429_origin_fallback':False,'representation_change_still_rejected':True,'controlled_redirect_requests_before':4,'controlled_redirect_requests_after':3,'real_cdn_latency_benchmark':False,'source_live_contract_verified':False,'new_jvm_tests':25,'new_native_tests_compiled':2}
v['source_video']['initial_url_contracts_unchanged']=False
v['source_video']['previous_provider_contracts_retained']=True
v['gallery']['resource_extensions']=['gofile: explicitly reviewed imported API attachments']
v['video_variants'].pop('room_schema_or_json_version_changed',None)
v['video_variants']['room_schema_changed']=False
v['video_variants']['backup_version_changed']=True
v['progressive_streaming']['external_url_resolution_or_gofile_added']=True
v['progressive_streaming']['manifest_unchanged']=False
v['progressive_streaming']['no_new_activity_provider_permission_or_dependency']=False
v['gofile']={'role':'optional resource expander, not a tenth follow provider','api':'GET api.gofile.io/contents/{id}?page=N&pageSize=100','own_account_token_required':True,'documented_premium_listing_required':True,'token_in_authorization_only':True,'api_redirects':False,'automatic_accounts_uploads_mutations_or_web_signatures':False,'other_source_headers_or_cookies':False,'token_sent_to_media':False,'token_storage':'separate AES-GCM AndroidKeyStore vault + AtomicFile, noBackupFilesDir','plaintext_fallback':False,'credential_dialog_secure_not_prefilled_no_saved_view_state':True,'api_json_limit_bytes':2097152,'api_json_max_depth':32,'one_metadata_request_per_action':True,'max_pages':5000,'max_known_targets':200,'automatic_recursive_requests':False,'query_or_apply_downloads_media':False,'review_before_additive_apply':True,'stale_identity_body_key_pause_cancel_checks':True,'empty_over_budget_atomic_preservation':True,'other_source_body_refresh_keeps_resolved_assets':True,'native_version_downgrade_guard_ignores_external_assets':True,'attachment_budget':100,'download_origin':'store*.gofile.io constrained download path, matching file id, no query or credentials','download_public_dns_each_open':True,'media_redirect':'same exact URL only','other_provider_previous_contracts_retained':True,'api429_persisted_across_key_change_or_removal':True,'masked_f95_password_or_captcha_resolution_added':False,'gofile_expected_hash_verified':False,'actual_authorized_account_listing_verified':False,'actual_upstream_media_requests':0,'instrumented_keystore_execution':False,'new_native_activity_exported':False,'new_permission_service_provider_runtime_dependency':False,'backup18_reads':'1–18; 0.35 rejects 18','new_jvm_tests':35,'new_native_tests_compiled':2}
v['unauthenticated_metadata_probe']=json.loads((V/'unauthenticated-synthetic-probe.json').read_text())
for f in [V/'verification.json',D/'Peach-Local-verificacion-0.36.0.json']:f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
for name,value in [('signature',sign),('alignment',align),('badging',badging),('permissions',permissions)]: (V/('apk-'+name+'.txt')).write_text(value)
(V/'test-apk-signature.txt').write_text(testsign)
print(json.dumps(v,ensure_ascii=False,indent=2))
