#!/usr/bin/env python3
"""Verify 0.39 APK and executed evidence; distinguish compiled/device checks."""
from pathlib import Path
import argparse,collections,hashlib,json,re,shutil,struct,subprocess,xml.etree.ElementTree as E,zipfile
p=argparse.ArgumentParser();p.add_argument('--build-root',required=True);p.add_argument('--baseline-apk',required=True);p.add_argument('--tools',required=True);p.add_argument('--log',required=True);p.add_argument('--out',required=True);a=p.parse_args()
R=Path(__file__).resolve().parents[1];B=Path(a.build_root)/'app';D=Path(a.out);D.mkdir(parents=True,exist_ok=True);V=R/'docs/evidence/0.39.0';V.mkdir(parents=True,exist_ok=True);T=Path(a.tools);PARENT='ccee4825e351fba6310f1bc21ca01e32b237f34a';CERT='9fc537c4c8d0461a8565414c7a30169e592120cd314b500bee7c707f8a748484'
def run(args):return subprocess.run([str(x) for x in args],cwd=R,capture_output=True,text=True,check=True).stdout
def prior(name):return subprocess.run(['git','show',PARENT+':'+name],cwd=R,capture_output=True,check=True).stdout
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
suites=[E.parse(p).getroot() for p in (B/'test-results/testDebugUnitTest').glob('TEST-*.xml')];counts={k:sum(int(s.attrib.get(k,0)) for s in suites) for k in ('tests','failures','errors','skipped')}
assert counts['tests']>=881 and not sum(counts[k] for k in ('failures','errors','skipped')),counts
for p in (B/'test-results/testDebugUnitTest').glob('TEST-*.xml'):
 text=p.read_text();assert not any(s in text for s in ['A resource was acquired at attached stack trace but never released','NoSuchMethodError','SQLiteException']),p
 (V/'unit-results').mkdir(exist_ok=True);shutil.copy2(p,V/'unit-results'/p.name)
assert 'BUILD SUCCESSFUL' in Path(a.log).read_text();shutil.copy2(a.log,V/'gradle-final.log')
issues=E.parse(B/'reports/lint-results-debug.xml').getroot().findall('issue');assert not [i for i in issues if i.attrib['severity'] in ('Error','Fatal')]
for n in ['lint-results-debug.xml','lint-results-debug.txt','lint-results-debug.html']:shutil.copy2(B/'reports'/n,V/n)
apk=D/'Peach-Local-0.39.0-debug.apk';testapk=D/'Peach-Local-0.39.0-androidTest.apk';shutil.copy2(B/'outputs/apk/debug/app-debug.apk',apk);shutil.copy2(B/'outputs/apk/androidTest/debug/app-debug-androidTest.apk',testapk)
for path,key in [(apk,'apk'),(testapk,'test-apk')]:
 sig=run([T/'apksigner','verify','--verbose','--print-certs',path]);assert CERT in sig and 'Verified using v2 scheme (APK Signature Scheme v2): true' in sig;(V/(key+'-signature.txt')).write_text(sig)
align=run([T/'zipalign','-c','-P','16','-v','4',apk]);assert 'Verification suc' in align;(V/'apk-alignment.txt').write_text(align)
badging=run([T/'aapt','dump','badging',apk]);assert "versionCode='39'" in badging and "versionName='0.39.0'" in badging and "sdkVersion:'26'" in badging and "targetSdkVersion:'36'" in badging;(V/'apk-badging.txt').write_text(badging)
permissions=run([T/'aapt','dump','permissions',apk]);assert permissions==run([T/'aapt','dump','permissions',a.baseline_apk]);(V/'apk-permissions.txt').write_text(permissions)
(V/'apk-manifest.txt').write_text(run([T/'aapt','dump','xmltree',apk,'AndroidManifest.xml']))
def classes(z):
 out=set()
 for n in z.namelist():
  if not re.fullmatch(r'classes\d*\.dex',n):continue
  b=z.read(n);sn,so=struct.unpack_from('<II',b,56);tn,to=struct.unpack_from('<II',b,64);cn,co=struct.unpack_from('<II',b,96)
  def string(i):
   o=struct.unpack_from('<I',b,so+i*4)[0]
   while b[o]&128:o+=1
   o+=1;return b[o:b.index(0,o)].decode('utf8',errors='replace')
  for j in range(cn):
   ti=struct.unpack_from('<I',b,co+j*32)[0];s=string(struct.unpack_from('<I',b,to+ti*4)[0])
   if s.startswith('Lcom/peach/local/') and '$$' not in s:out.add(s)
 return out
with zipfile.ZipFile(apk) as z,zipfile.ZipFile(a.baseline_apk) as old:
 assert z.testzip() is None
 ns=lambda q:{n for n in q.namelist() if n.startswith(('assets/','lib/'))}
 expected_native={'lib/'+x['abi']+'/libpeach_rar.so' for x in json.loads((V/'native-audit.json').read_text())['abis']}
 assert ns(z)-ns(old)==expected_native|{'assets/licenses/libarchive-3.8.10-COPYING.txt'}
 for n in ns(old):
  if n=='assets/THIRD_PARTY_NOTICES.md':assert z.read(n).startswith(old.read(n))
  else:assert z.read(n)==old.read(n),n
 for x in json.loads((V/'native-audit.json').read_text())['abis']:assert hashlib.sha256(z.read('lib/'+x['abi']+'/libpeach_rar.so')).hexdigest()==x['sha256']
 before,after=classes(old),classes(z);assert not before-after
 assert not any('rar038/' in n or 'rar039/' in n for n in z.namelist()) # Fixtures only in test APK/resources and delivery samples.
for f in (R/'app/schemas').rglob('*.json'):assert f.read_bytes()==prior(str(f.relative_to(R)))
n='app/src/main/java/com/peach/local/BackupStore.java';assert (R/n).read_bytes()==prior(n)
manifest=prior('app/src/main/AndroidManifest.xml').decode();assert (R/'app/src/main/AndroidManifest.xml').read_text()==manifest.replace('        <activity android:name=".ReaderActivity"','        <service android:name=".RarService" android:exported="false" android:isolatedProcess="true" android:process=":rar" />\n        <activity android:name=".ReaderActivity"')
expected_gradle=prior('app/build.gradle').decode().replace('versionCode 38','versionCode 39').replace("versionName '0.38.0'","versionName '0.39.0'").replace('buildFeatures { buildConfig true }','buildFeatures { buildConfig true; aidl true }').replace("systemProperty 'robolectric.dependency.repo.url'", "if (System.getenv('PEACH_RAR_HOST_LIBRARY')) systemProperty 'peach.rar.host.library', System.getenv('PEACH_RAR_HOST_LIBRARY')\n            systemProperty 'robolectric.dependency.repo.url'")
assert (R/'app/build.gradle').read_text()==expected_gradle

def graph(p):
 s=p.read_text();a=s.index('debugRuntimeClasspath -');b=s.index('\n(c) -',a);return s[a:b].strip()
g=graph(V/'gradle-dependencies.log');assert g==graph(R/'docs/evidence/0.38.0/gradle-dependencies.log')
native=sum(len(re.findall(r'@Test\b',f.read_text())) for f in (R/'app/src/androidTest/java').rglob('*.java'));assert native==52
new={s.attrib['name']:int(s.attrib['tests']) for s in suites if s.attrib['name'].split('.')[-1] in ['RarNativeTest','RarIpcTest','RarServiceTest','RarDecodedReaderTest']};assert sum(new.values())==counts['tests']-860
v={'version':'0.39.0','date':'2026-10-28','timezone':'America/Hermosillo','baseline':PARENT,'parent_acceptance':{'version':'0.38.0','type':'user confirmed download and all checks work, then requested next block','not_instrumentation_execution':True},'unit':dict(counts,classes=len(suites)),'new_jvm_tests':new,'lint':{'errors':0,'warnings':len(issues),'categories':dict(collections.Counter(i.attrib['id'] for i in issues))},'instrumentation':{'compiled':native,'executed':0},'room':{'version':13,'schemas_unchanged':True,'schema_sha256':sha(R/'app/schemas/com.peach.local.LibraryDatabase/13.json')},'backup':{'writes':18,'reads':'1–18','BackupStore_unchanged':True},'runtime_dependencies_unchanged':True,'runtime_dependency_graph_lines':len(g.splitlines()),'old_assets_retained_except_appended_notice':True,'old_native_libs_retained':True,'new_native_libs':4,'permissions_unchanged':True,'new_component':'RarService: exported=false, isolatedProcess=true, process=:rar','signature_original':True,'signature_v2':True,'zipalign16k':True,'peach_classes':{'before':len(before),'after':len(after),'removed':0},'apk':{'file':apk.name,'bytes':apk.stat().st_size,'sha256':sha(apk)},'test_apk':{'file':testapk.name,'bytes':testapk.stat().st_size,'sha256':sha(testapk)},'rar':{'compressed_decoding':True,'engine':'libarchive3.8.10','stored_java_reader_retained':True,'native_audit':json.loads((V/'native-audit.json').read_text()),'supported_subset':['RAR4 methods31–35, portable names','RAR5 algorithm0 methods1–5 dictionary<=64MiB'],'unsupported':['solid','multivolume','SFX','encrypted headers/passwords','legacy RAR4 compressed Unicode/ambiguous ANSI','RAR7 compressed','missing CRC and unrecognized extras'],'descriptor_only_ipc':True,'isolated_process':True,'uid_caller_checked':True,'source_read_only':True,'output_write_only':True,'watchdog_seconds':90,'native_callback_deadline_seconds':85,'bind_timeout_seconds':10,'absolute_system_hang_deadline_claimed':False,'source_limit_bytes':512*1024**2,'entry_limit_bytes':64*1024**2,'independent_java_size_crc_before_publish':True,'no_native_paths_or_raw_errors_in_ipc':True,'original_file_untouched':True,'host_jni_engine_executed':True,'android_abi_execution':False,'real_cross_process_android_binder_execution':False,'ipc_tests':'controlled Robolectric doubles','fixtures':json.loads((V/'fixtures.json').read_text())},'actual_upstream_media_requests':0,'private_user_media_packaged':False,'physical_device_execution':False,'final_unclosed_resource_warning':False}
for f in [V/'verification.json',D/'Peach-Local-verificacion-0.39.0.json']:f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v[k] for k in ['unit','new_jvm_tests','lint','instrumentation','peach_classes','apk']},ensure_ascii=False,indent=2))
