#!/usr/bin/env python3
"""Verify the delivered APK and actual Gradle evidence against 0.39.0."""
from pathlib import Path
import argparse,collections,hashlib,json,re,shutil,struct,subprocess,xml.etree.ElementTree as E,zipfile
p=argparse.ArgumentParser()
for name in ('baseline-apk','tools','out','log'):p.add_argument('--'+name,required=True)
a=p.parse_args();R=Path(__file__).resolve().parents[1];B=R/'app/build';D=Path(a.out);D.mkdir(parents=True,exist_ok=True);V=R/'docs/evidence/0.40.0';V.mkdir(exist_ok=True);T=Path(a.tools)
PARENT='ed891252165122fb2e137401a544f7a76a4c7b25';CERT='9fc537c4c8d0461a8565414c7a30169e592120cd314b500bee7c707f8a748484'
def run(args):return subprocess.run([str(x) for x in args],cwd=R,capture_output=True,text=True,check=True).stdout
def prior(name):return subprocess.run(['git','show',PARENT+':'+name],cwd=R,capture_output=True,check=True).stdout
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
suites=[E.parse(p).getroot() for p in (B/'test-results/testDebugUnitTest').glob('TEST-*.xml')]
counts={k:sum(int(s.attrib.get(k,0)) for s in suites) for k in ('tests','failures','errors','skipped')}
assert counts=={'tests':906,'failures':0,'errors':0,'skipped':0},counts
for f in (B/'test-results/testDebugUnitTest').glob('TEST-*.xml'):
    text=f.read_text();assert not any(s in text for s in ('A resource was acquired at attached stack trace but never released','NoSuchMethodError','SQLiteException')),f
    (V/'unit-results').mkdir(exist_ok=True);shutil.copy2(f,V/'unit-results'/f.name)
assert 'BUILD SUCCESSFUL' in Path(a.log).read_text();shutil.copy2(a.log,V/'gradle-final.log')
issues=E.parse(B/'reports/lint-results-debug.xml').getroot().findall('issue')
assert not [i for i in issues if i.attrib['severity'] in ('Error','Fatal')]
old_issues=E.parse(R/'docs/evidence/0.39.0/lint-results-debug.xml').getroot().findall('issue')
new_counts=collections.Counter(i.attrib['id'] for i in issues);old_counts=collections.Counter(i.attrib['id'] for i in old_issues)
lint_delta=dict(new_counts-old_counts);assert set(lint_delta)<=set(('GradleDependency','AndroidGradlePluginVersion','NewerVersionAvailable')),lint_delta

for n in ('lint-results-debug.xml','lint-results-debug.txt','lint-results-debug.html'):shutil.copy2(B/'reports'/n,V/n)
apk=D/'Peach-Local-0.40.0-debug.apk';test=D/'Peach-Local-0.40.0-androidTest.apk'
shutil.copy2(B/'outputs/apk/debug/app-debug.apk',apk);shutil.copy2(B/'outputs/apk/androidTest/debug/app-debug-androidTest.apk',test)
for path,key in ((apk,'apk'),(test,'test-apk')):
    sig=run([T/'apksigner','verify','--verbose','--print-certs',path]);assert CERT in sig and 'Verified using v2 scheme (APK Signature Scheme v2): true' in sig;(V/(key+'-signature.txt')).write_text(sig)
align=run([T/'zipalign','-c','-P','16','-v','4',apk]);assert 'Verification suc' in align;(V/'apk-alignment.txt').write_text(align)
badging=run([T/'aapt','dump','badging',apk]);assert all(s in badging for s in ("versionCode='40'","versionName='0.40.0'","sdkVersion:'26'","targetSdkVersion:'36'"));(V/'apk-badging.txt').write_text(badging)
permissions=run([T/'aapt','dump','permissions',apk]);assert permissions==run([T/'aapt','dump','permissions',a.baseline_apk]);(V/'apk-permissions.txt').write_text(permissions)
def classes(z):
    out=set()
    for n in z.namelist():
        if not re.fullmatch(r'classes\d*\.dex',n):continue
        b=z.read(n);sn,so=struct.unpack_from('<II',b,56);tn,to=struct.unpack_from('<II',b,64);cn,co=struct.unpack_from('<II',b,96)
        def string(i):
            o=struct.unpack_from('<I',b,so+i*4)[0]
            while b[o]&128:o+=1
            o+=1;return b[o:b.index(0,o)].decode('utf8',errors='replace')
        for j in range(cn):
            ti=struct.unpack_from('<I',b,co+j*32)[0];s=string(struct.unpack_from('<I',b,to+ti*4)[0])
            if s.startswith('Lcom/peach/local/') and '$$' not in s:out.add(s)
    return out
with zipfile.ZipFile(apk) as z,zipfile.ZipFile(a.baseline_apk) as old:
    assert z.testzip() is None
    assets=lambda q:{n for n in q.namelist() if n.startswith(('assets/','lib/'))}
    assert assets(z)==assets(old)
    for n in assets(old):assert z.read(n)==old.read(n),n
    before,after=classes(old),classes(z);assert not before-after
    assert after-before=={'Lcom/peach/local/Rar4Names;'},after-before
    assert not any('rar040/' in n for n in z.namelist())
for f in (R/'app/schemas').rglob('*.json'):assert f.read_bytes()==prior(str(f.relative_to(R)))
for n in ('app/src/main/java/com/peach/local/BackupStore.java','app/src/main/AndroidManifest.xml','app/src/main/cpp/rar_engine.c','app/src/main/java/com/peach/local/RarClient.java','app/src/main/java/com/peach/local/RarService.java'):
    assert (R/n).read_bytes()==prior(n),n
assert (R/'app/build.gradle').read_text()==prior('app/build.gradle').decode().replace('versionCode 39','versionCode 40').replace("versionName '0.39.0'","versionName '0.40.0'")
def graph(p):
    s=p.read_text();start=s.index('debugRuntimeClasspath -');end=s.index('\n(c) -',start);return s[start:end].strip()
g=graph(V/'gradle-dependencies.log');assert g==graph(R/'docs/evidence/0.39.0/gradle-dependencies.log')
compiled=sum(len(re.findall(r'@Test\b',f.read_text())) for f in (R/'app/src/androidTest/java').rglob('*.java'));assert compiled==54
new={s.attrib['name']:int(s.attrib['tests']) for s in suites if s.attrib['name'].split('.')[-1] in ('Rar4NamesTest','RarUnicodeIndexTest','RarUnicodeNativeTest')};assert sum(new.values())==25
v={'version':'0.40.0','date':'2026-10-28','timezone':'America/Hermosillo','baseline':PARENT,'parent_acceptance':{'version':'0.39.0','type':'user confirmed download and everything works','not_instrumentation_execution':True},'unit':dict(counts,classes=len(suites)),'new_jvm_tests':new,'lint':{'errors':0,'warnings':len(issues),'additional_version_availability_warnings':lint_delta,'categories':dict(collections.Counter(i.attrib['id'] for i in issues))},'instrumentation':{'compiled':compiled,'executed':0},'room':{'version':13,'schemas_unchanged':True},'backup':{'writes':18,'reads':'1–18','BackupStore_unchanged':True},'runtime_dependencies_unchanged':True,'runtime_dependency_graph_lines':len(g.splitlines()),'assets_and_native_libs_byte_identical':True,'manifest_and_permissions_unchanged':True,'signature_original':True,'signature_v2':True,'zipalign16k':True,'peach_classes':{'before':len(before),'after':len(after),'removed':0},'apk':{'file':apk.name,'bytes':apk.stat().st_size,'sha256':sha(apk)},'test_apk':{'file':test.name,'bytes':test.stat().st_size,'sha256':sha(test)},'rar4_names':{'legacy_unicode':True,'four_operations':True,'input_max_bytes':4096,'output_max_utf8_bytes':4096,'valid_utf16_pairs':True,'ambiguous_ansi_guessed':False,'paths_and_duplicates_checked_after_decode':True,'original_untouched':True,'stored_java_reader_retained':True,'native_engine_changed':False,'host_jni_executed':True,'android_abi_or_binder_executed':False,'fixtures':json.loads((V/'fixtures.json').read_text()),'unsupported':['solid','multivolume','SFX','passwords','ambiguous ANSI','RAR7 compressed','missing CRC and unrecognized extras']},'actual_upstream_media_requests':0,'private_media_packaged':False,'physical_device_execution':False}
for f in (V/'verification.json',D/'Peach-Local-verificacion-0.40.0.json'):f.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v[k] for k in ('unit','new_jvm_tests','lint','instrumentation','peach_classes','apk')},ensure_ascii=False,indent=2))
